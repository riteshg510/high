package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.util.Objects;

/**
 * Composite primary key for T222CodCmodExtAGP entity.
 */
public class T222CodCmodExtAGPId implements Serializable {

    private String cmodApplicationGroup;
    private String cmodUserGroupName;

    // Constructors
    public T222CodCmodExtAGPId() {
    }

    public T222CodCmodExtAGPId(String cmodApplicationGroup, String cmodUserGroupName) {
        this.cmodApplicationGroup = cmodApplicationGroup;
        this.cmodUserGroupName = cmodUserGroupName;
    }

    // Getters and Setters
    public String getCmodApplicationGroup() {
        return cmodApplicationGroup;
    }

    public void setCmodApplicationGroup(String cmodApplicationGroup) {
        this.cmodApplicationGroup = cmodApplicationGroup;
    }

    public String getCmodUserGroupName() {
        return cmodUserGroupName;
    }

    public void setCmodUserGroupName(String cmodUserGroupName) {
        this.cmodUserGroupName = cmodUserGroupName;
    }

    // equals and hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        T222CodCmodExtAGPId that = (T222CodCmodExtAGPId) o;
        return Objects.equals(cmodApplicationGroup, that.cmodApplicationGroup) &&
               Objects.equals(cmodUserGroupName, that.cmodUserGroupName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cmodApplicationGroup, cmodUserGroupName);
    }
}