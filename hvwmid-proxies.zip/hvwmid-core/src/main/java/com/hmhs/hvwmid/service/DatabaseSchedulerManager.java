package com.hmhs.hvwmid.service;

import jakarta.annotation.PostConstruct;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.concurrent.ScheduledFuture;

@Service
public class DatabaseSchedulerManager {
    private final TaskScheduler scheduler;
    private final CMODDataRefreshService cmodDataRefreshService;
    private final ImageParmDataService imageParmDataService;

    private ScheduledFuture<?> scheduledFuture;
    private String lastCmodCronValue = "";
    private String lastParmDataCronValue = "";

    public DatabaseSchedulerManager(TaskScheduler scheduler, CMODDataRefreshService cmodDataRefreshService,
            ImageParmDataService imageParmDataService) {
        this.scheduler = scheduler;
        this.cmodDataRefreshService = cmodDataRefreshService;
        this.imageParmDataService = imageParmDataService;
    }

    @PostConstruct
    public void start() {
        String cmodCron = imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", "0 0 2 * * *");
        String parmDataCron = imageParmDataService.getParmDataByKey("HVWCRON", "refreshParmData", "0 0 2 * * *");
        
        scheduleXmlRefreshTaskFromDb(cmodCron);
        scheduleRefreshParamDataTaskFromDb(parmDataCron);
    }

 
    
    public void scheduleXmlRefreshTaskFromDb(String cron) {
        // Cancel previous schedule if it exists
        if (scheduledFuture != null && !scheduledFuture.isCancelled()) {
            scheduledFuture.cancel(false);
        }

        CronTrigger trigger = new CronTrigger(cron, ZoneId.of("America/New_York"));
        scheduledFuture = scheduler.schedule(() -> {
            cmodDataRefreshService.refreshCMODData();
        }, trigger);
    }

    
    public void scheduleRefreshParamDataTaskFromDb(String cron) {
        // Cancel previous schedule if it exists
        if (scheduledFuture != null && !scheduledFuture.isCancelled()) {
            scheduledFuture.cancel(false);
        }

        CronTrigger trigger = new CronTrigger(cron, ZoneId.of("America/New_York"));
        scheduledFuture = scheduler.schedule(() -> {
            imageParmDataService.refreshParmData();
        }, trigger);
    }

    /**
     * Checks if the cron schedules have changed in the database and updates schedules accordingly
     * Runs every hour to monitor for parameter changes
     */
    @Scheduled(cron = "0 0 * * * *", zone = "America/New_York")
    public void checkAndUpdateSchedulesIfChanged() {
        try {
            String currentCmodCronValue = imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", "0 0 2 * * *");
            String currentParmDataCronValue = imageParmDataService.getParmDataByKey("HVWCRON", "refreshParmData", "0 0 2 * * *");
            
            boolean cmodChanged = !currentCmodCronValue.equals(lastCmodCronValue);
            boolean parmDataChanged = !currentParmDataCronValue.equals(lastParmDataCronValue);
            
            // If either cron value has changed, reschedule the respective tasks
            if (cmodChanged) {
                lastCmodCronValue = currentCmodCronValue;
                scheduleXmlRefreshTaskFromDb(currentCmodCronValue);
            }
            
            if (parmDataChanged) {
                lastParmDataCronValue = currentParmDataCronValue;
                scheduleRefreshParamDataTaskFromDb(currentParmDataCronValue);
            }
        } catch (Exception e) {
            // Log error but don't let it stop the scheduler
            System.err.println("Error checking database for schedule changes: " + e.getMessage());
        }
    }

}
