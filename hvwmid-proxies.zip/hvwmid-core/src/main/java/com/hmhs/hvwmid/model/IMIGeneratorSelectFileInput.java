package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IMIGeneratorSelectFileInput {
	

	@JsonProperty("inputFileTxt")
    private String inputFileTxt;
	
	@JsonProperty("documentCountTxt")
    private String documentCountTxt;
	
	@JsonProperty("filePriorityTxt")
    private String filePriorityTxt;
	
	@JsonProperty("naicCodeTxt")
    private String naicCodeTxt;
	
	@JsonProperty("outputDirTxt")
    private String outputDirTxt;
	
	@JsonProperty("select")
    private String select;
	
	@JsonProperty("toggleIntakeDir")
    private String toggleIntakeDir;
    
    public String getInputFileTxt() {
        return inputFileTxt;
    }

    public void setInputFileTxt(String inputFileTxt) {
        this.inputFileTxt = inputFileTxt;
    }

    public String getDocumentCountTxt() {
        return documentCountTxt;
    }

    public void setDocumentCountTxt(String documentCountTxt) {
        this.documentCountTxt = documentCountTxt;
    }
    
    public String getFilePriorityTxt() {
        return filePriorityTxt;
    }

    public void setFilePriorityTxt(String filePriorityTxt) {
        this.filePriorityTxt = filePriorityTxt;
    }
    
    public String getNaicCodeTxt() {
        return naicCodeTxt;
    }

    public void setNaicCodeTxt(String naicCodeTxt) {
        this.naicCodeTxt = naicCodeTxt;
    }
    
    public String getOutputDirTxt() {
        return outputDirTxt;
    }

    public void setOutputDirTxt(String outputDirTxt) {
        this.outputDirTxt = outputDirTxt;
    }
    
    public String getSelect() {
        return select;
    }

    public void setSelect(String select) {
        this.select = select;
    }
    
    public String getToggleIntakeDir() {
        return toggleIntakeDir;
    }

    public void setToggleIntakeDir(String toggleIntakeDir) {
        this.toggleIntakeDir = toggleIntakeDir;
    }

}
