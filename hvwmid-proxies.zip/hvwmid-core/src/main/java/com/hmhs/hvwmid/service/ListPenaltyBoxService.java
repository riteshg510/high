package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ListPenaltyBoxService {

    @Autowired
    private RestClientUtil restClientUtil;

    @Value("${api.images.listpenaltybox.url}")
    String url = null; // /penaltybox/users

    private static final String X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS = "x-highmark-businessProcessDifferentiatorIds";
    private static final String BPDID_FIELD = "bpdid";

    public ResponseEntity<Object> getAll(Map<String, String> otherFields, String authToken) {
        return executeAction("/get-all", otherFields, authToken);
    }

    public ResponseEntity<Object> add(Map<String, String> otherFields, String authToken) {
        return executeAction("/add", otherFields, authToken);
    }

    public ResponseEntity<Object> delete(Map<String, String> otherFields, String authToken) {
        return executeAction("/delete", otherFields, authToken);
    }

    public ResponseEntity<Object> reset(Map<String, String> otherFields, String authToken) {
        return executeAction("/reset", otherFields, authToken);
    }

    public ResponseEntity<Object> extend(Map<String, String> otherFields, String authToken) {

        return executeAction("/extend", otherFields, authToken);
    }

    public ResponseEntity<Object> executeAction(String endpoint, Map<String, String> otherFields, String authToken) {
        final ResponseEntity<Map> response = getFromBack(endpoint, otherFields, authToken);

        List<Map> result = getResults(response.getBody());

        return new ResponseEntity<>(result, response.getStatusCode());
    }

    private ResponseEntity<Map> getFromBack(String endpoint, Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>(otherFields);

        Map<String, String> extraHeaders = generateExtraHeaders(otherFields);

        return restClientUtil.postRequest(url+endpoint, authToken, requestBody, extraHeaders);
    }

    private static Map<String, String> generateExtraHeaders(Map<String, String> otherFields) {
        Map<String, String> extraHeaders = new HashMap<>();

        if (otherFields.containsKey(BPDID_FIELD) && !StringUtils.isBlank(otherFields.get(BPDID_FIELD))) {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, otherFields.get(BPDID_FIELD));
        } else {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, "1");
        }

        return extraHeaders;
    }

    private List<Map> getResults(Map response){
        List<Map> result = new ArrayList<>();
        if(response.containsKey("results")){
            Map applIds = (Map) response.get("results");
            if(applIds.containsKey("row")){
                List applList = (List) applIds.get("row");
                for(Object applObj: applList){
                    Map appl = (Map) applObj;
                    Map<String, Object> values = new HashMap();
                    values.put("userId", appl.get("userID"));
                    values.put("endTime", appl.get("endTime"));
                    values.put("startTime", appl.get("startTime"));
                    String description = (String) appl.get("description");
                    if(description.contains("::")){
                        values.put("description", description.substring(0, description.indexOf("::")));
                        values.put("audit", description.substring(description.indexOf("::")+2).trim());
                    }else{
                        values.put("description", description);
                        values.put("audit", "");
                    }
                    result.add(values);
                }
            }
        }
        return result;
    }
}