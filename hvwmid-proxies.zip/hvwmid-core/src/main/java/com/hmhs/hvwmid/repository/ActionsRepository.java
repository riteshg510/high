package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblActions;

/**
 * @author Ramanjaneyulu Manam on Sept 16, 2024
 */
@Repository
public interface ActionsRepository extends CrudRepository<TblActions, String> {
	
	/**
	 * @param formId
	 * @return
	 */ 

	List<TblActions> getActionsByFormIdOrderByActionOrderAsc(String formId); 

}
