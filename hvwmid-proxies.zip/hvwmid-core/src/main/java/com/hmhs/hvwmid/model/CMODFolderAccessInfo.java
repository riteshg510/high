package com.hmhs.hvwmid.model;

import java.util.List;

/**
 * DTO representing folder access information for CMOD security access.
 * Contains applications and their access details within a folder.
 */
public class CMODFolderAccessInfo {

    private String folderName;
    private List<CMODApplicationAccessInfo> applications;
    private boolean isEmpty;

    // Constructors
    public CMODFolderAccessInfo() {
    }

    public CMODFolderAccessInfo(String folderName, List<CMODApplicationAccessInfo> applications) {
        this.folderName = folderName;
        this.applications = applications;
        this.isEmpty = applications == null || applications.isEmpty();
    }

    // Getters and Setters
    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public List<CMODApplicationAccessInfo> getApplications() {
        return applications;
    }

    public void setApplications(List<CMODApplicationAccessInfo> applications) {
        this.applications = applications;
        this.isEmpty = applications == null || applications.isEmpty();
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean isEmpty) {
        this.isEmpty = isEmpty;
    }
}