package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Model class representing an IMI update retrieve request.
 * Contains the field type and ID value for searching IMI records for update operations.
 * 
 * @author HighView Development Team
 * @since 1.0
 */
public class IMIUpdateRetrieveRequest {

    @JsonProperty("field")
    private String field;

    @JsonProperty("fieldquery")
    private String fieldQuery;

    // Getters and Setters
    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }
    


	public String getFieldQuery() {
		return fieldQuery;
	}

	public void setFieldQuery(String fieldQuery) {
		this.fieldQuery = fieldQuery;
	}

	@Override
    public String toString() {
        return "IMIUpdateRetrieveRequest{" +
                "field='" + field + '\'' +
                ", fieldQuery='" + fieldQuery + '\'' +
                '}';
    }
}
