package com.hmhs.hvwmid.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblUserCabinets;

@Repository
public interface UserCabinetRepository extends CrudRepository<TblUserCabinets, Long> {

	/**
	 * Find cabinets by user ID.
	 */
	@Query("SELECT uc.cabinetId FROM TblUserCabinets uc WHERE uc.userId = :userId")
	List<String> findCabinetIdsByUserId(@Param("userId") String userId);

	public Optional<TblUserCabinets> findByUserIdAndCabinetId(String userId, String cabinetId);

}