package com.hmhs.hvwmid.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Sept 6, 2024
 */
@Entity
@Table(name = "T222_HVW_SECTION_DETAILS")
public class TblSectionDetails {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String fieldId;
	@Column(precision = 5, scale = 2)
	private BigDecimal columnNumber;
	@Column(name = "createTimestamp", columnDefinition = "TIMESTAMP")
	private LocalDateTime createTimestamp;
	@Column(length = 2048)
	private String defaultValue;
	private String fieldName;
	private int fieldOrder;
	private int fieldType;
	@Lob
	private byte[] htmlContent;
	private String isDependentOn;
	@Column(length = 64)
	private String label;
	private int maximum;
	private int minimum;
	private Short multiSelect;
	@Column(length = 1024)
	private String notes;
	@Column(length = 32)
	private String pickListId;
	@Column(length = 8192)
	private String pickListOptions; 
	private int pickListOrder;
	private Short readOnly;
	private Short required;
	@Column(length = 32)
	private String sectionId;
	@Column(length = 1024)
	private String validationMessage;
	@Column(length = 1024)
	private String validationRules;
	private Short visible;

	// This Expression fields are used for java script validation.
	@Column(length = 4095)
	private String name;
	@Column(length = 4095)
	private String displayExp;
	@Column(length = 4095)
	private String requiredExp;

	public String getFieldId() {
		return fieldId.toUpperCase();
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId.toUpperCase();
	} 

	public BigDecimal getColumnNumber() {
		return columnNumber;
	}

	public void setColumnNumber(BigDecimal columnNumber) {
		this.columnNumber = columnNumber;
	}

	public LocalDateTime getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDateTime createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getFieldName() {
		if (fieldName != null)
			fieldName = fieldName.toLowerCase();
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		if (fieldName != null)
			fieldName = fieldName.toLowerCase();
		this.fieldName = fieldName;
	}

	public int getFieldOrder() {
		return fieldOrder;
	}

	public void setFieldOrder(int fieldOrder) {
		this.fieldOrder = fieldOrder;
	}

	public int getFieldType() {
		return fieldType;
	}

	public void setFieldType(int fieldType) {
		this.fieldType = fieldType;
	}

	public byte[] getHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(byte[] htmlContent) {
		this.htmlContent = htmlContent;
	}

	public String getIsDependentOn() {
		return isDependentOn;
	}

	public void setIsDependentOn(String isDependentOn) {
		this.isDependentOn = isDependentOn;
	}

	public String getLabel() {
		return capitalize(label);
	}

	public void setLabel(String label) {
		this.label = capitalize(label);
	}

	public int getMaximum() {
		return maximum;
	}

	public void setMaximum(int maximum) {
		this.maximum = maximum;
	}

	public int getMinimum() {
		return minimum;
	}

	public void setMinimum(int minimum) {
		this.minimum = minimum;
	}

	public Short getMultiSelect() {
		return multiSelect;
	}

	public void setMultiSelect(Short multiSelect) {
		this.multiSelect = multiSelect;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getPickListId() {
		return pickListId.toUpperCase();
	}

	public void setPickListId(String pickListId) {		
		this.pickListId = Optional.ofNullable(pickListId)
                .map(String::toUpperCase)
                .orElse("");
	}

	public String getPickListOptions() {
		return pickListOptions;
	}

	public void setPickListOptions(String pickListOptions) {
		this.pickListOptions = pickListOptions;
	}

	public int getPickListOrder() {
		return pickListOrder;
	}

	public void setPickListOrder(int pickListOrder) {
		this.pickListOrder = pickListOrder;
	}

	public Short getReadOnly() {
		return readOnly;
	}

	public void setReadOnly(Short readOnly) {
		this.readOnly = readOnly;
	}

	public Short getRequired() {
		return required;
	}

	public void setRequired(Short required) {
		this.required = required;
	}

	public String getSectionId() {
		return sectionId.toUpperCase();
	}

	public void setSectionId(String sectionId) {
		this.sectionId = sectionId.toUpperCase();
	}

	public String getValidationMessage() {
		return validationMessage;
	}

	public void setValidationMessage(String validationMessage) {
		this.validationMessage = validationMessage;
	}

	public String getValidationRules() {
		return validationRules;
	}

	public void setValidationRules(String validationRules) {
		this.validationRules = validationRules;
	}

	public Short getVisible() {
		return visible;
	}

	public void setVisible(Short visible) {
		this.visible = visible;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDisplayExp() {
		return displayExp;
	}

	public void setDisplayExp(String displayExp) {
		this.displayExp = displayExp;
	}

	public String getRequiredExp() {
		return requiredExp;
	}

	public void setRequiredExp(String requiredExp) {
		this.requiredExp = requiredExp;
	}

	// String capitalize is used for Label
	static String capitalize(String input) {
		if (input == null || input.isEmpty()) {
			return "";
		}
		return Arrays.stream(input.split("\\s+")).map(word -> word.substring(0, 1).toUpperCase() + word.substring(1))
				.collect(Collectors.joining(" "));
	}

}
