package com.hmhs.hvwmid.dto;

public class PolicyResponse {
    private Integer bpdId;
    private Integer policyCode;
    private String policyId;
    private Integer policyDays;
    private String policyEditFlag;
    private String policyEditPgmName;
    private String policyIdType;
    private String policyBaseDate; // LocalDate -> String
    private String modUser;
    private String modDate; // LocalDateTime -> String
    private String policyDescription;

    public Integer getBpdId() {
        return bpdId;
    }

    public void setBpdId(Integer bpdId) {
        this.bpdId = bpdId;
    }

    public Integer getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(Integer policyCode) {
        this.policyCode = policyCode;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public Integer getPolicyDays() {
        return policyDays;
    }

    public void setPolicyDays(Integer policyDays) {
        this.policyDays = policyDays;
    }

    public String getPolicyEditFlag() {
        return policyEditFlag;
    }

    public void setPolicyEditFlag(String policyEditFlag) {
        this.policyEditFlag = policyEditFlag;
    }

    public String getPolicyEditPgmName() {
        return policyEditPgmName;
    }

    public void setPolicyEditPgmName(String policyEditPgmName) {
        this.policyEditPgmName = policyEditPgmName;
    }

    public String getPolicyIdType() {
        return policyIdType;
    }

    public void setPolicyIdType(String policyIdType) {
        this.policyIdType = policyIdType;
    }

    public String getPolicyBaseDate() {
        return policyBaseDate;
    }

    public void setPolicyBaseDate(String policyBaseDate) {
        this.policyBaseDate = policyBaseDate;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public String getModDate() {
        return modDate;
    }

    public void setModDate(String modDate) {
        this.modDate = modDate;
    }

    public String getPolicyDescription() {
        return policyDescription;
    }

    public void setPolicyDescription(String policyDescription) {
        this.policyDescription = policyDescription;
    }
}
