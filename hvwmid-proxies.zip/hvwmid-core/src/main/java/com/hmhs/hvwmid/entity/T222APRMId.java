package com.hmhs.hvwmid.entity;

import java.io.Serializable;

public class T222APRMId implements Serializable {
    private String parmId;
    private String parmKey;

    public String getParmId() {
        return parmId;
    }

    public void setParmId(final String parmId) {
        this.parmId = parmId;
    }

    public String getParmKey() {
        return parmKey;
    }

    public void setParmKey(final String parmKey) {
        this.parmKey = parmKey;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        final T222APRMId that = (T222APRMId) o;
        return parmId.equals(that.parmId) && parmKey.equals(that.parmKey);
    }

    @Override
    public int hashCode() {
        return 31 * parmId.hashCode() + parmKey.hashCode();
    }
}