package com.hmhs.hvwmid.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.ReportAction;
import com.hmhs.hvwmid.model.ReportChild;
import com.hmhs.hvwmid.model.ReportForm;
import com.hmhs.hvwmid.model.ReportHelp;
import com.hmhs.hvwmid.model.ReportLayout;
import com.hmhs.hvwmid.utils.JsonUtil;
import com.hmhs.hvwmid.utils.RestClientUtil;

@Service
public class CmodFolderService {

    private static final Logger logger = LogManager.getLogger(CmodFolderService.class);
    private static final String DATES_PATH = "./data/Dates.json";
    private static final String SERVICE_NAME = "CMOD";
    private static final String UPLOAD_PREFIX = "UPLOAD";
    private static final String CMOD_PREFIX = "CMOD";

    @Value("${api.fields.url}")
    private String fieldsUrl;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    RestClientUtil restClientUtil;

    @Autowired
    private UploadActionService uploadActionService;

    @Autowired
    private CMODAppService cmodAppService;

    /**
     * Normalizes a folder ID by removing any CMOD prefix and UPLOAD prefix.
     * 
     * @param folderId The original folder ID
     * @return The normalized folder ID with prefixes removed
     */
    String normalizeFolderId(final String folderId) {
        if (folderId == null) {
            return null;
        }

        String normalized = folderId;

        // Remove CMOD prefix if present
        if (normalized.startsWith(CMOD_PREFIX)) {
            normalized = normalized.substring(CMOD_PREFIX.length());
        }

        // Remove UPLOAD prefix if present
        if (normalized.startsWith(UPLOAD_PREFIX)) {
            normalized = normalized.substring(UPLOAD_PREFIX.length());
        }

        return normalized;
    }

    /**
     * Checks if the given folder is an upload folder
     * 
     * @param folderId The folder ID (can be with or without prefixes)
     * @return true if it's an upload folder, false otherwise
     */
    boolean isUploadFolder(final String folderId) {
        if (folderId == null) {
            return false;
        }

        // First check the original folder ID for CMODUPLOAD prefix
        if (folderId.startsWith(CMOD_PREFIX + UPLOAD_PREFIX)) {
            return true;
        }

        // Then check for just UPLOAD prefix
        if (folderId.startsWith(UPLOAD_PREFIX)) {
            return true;
        }

        // For backward compatibility, also check the normalized version (after removing
        // CMOD prefix)
        if (folderId.startsWith(CMOD_PREFIX)) {
            final String withoutCmod = folderId.substring(CMOD_PREFIX.length());
            return withoutCmod.startsWith(UPLOAD_PREFIX);
        }

        return false;
    }

    /**
     * Generates the CMOD folder data structure for the UI.
     * 
     * @param folderId  The folder ID
     * @param sHelp     The help text
     * @param authToken The authentication token
     * @return JSON representation of the folder data
     * @throws IOException If an error occurs during processing
     */
    public String getCmodFolderData(final String folderId, final String sHelp, final String authToken)
            throws IOException {
        try {
            final ReportForm form = new ReportForm();

            // Normalize folder ID
            final String normalizedFolderId = normalizeFolderId(folderId);
            logger.debug("Normalized folder ID: {} -> {}", folderId, normalizedFolderId);

            // Check if this is an upload folder
            final boolean isUpload = isUploadFolder(folderId);
            logger.debug("Folder {} is upload folder: {}", folderId, isUpload);

            // Get appropriate actions
            form.setActions(createFormActions(normalizedFolderId, authToken, isUpload));

            // Get layouts
            form.setLayout(createFormLayouts(folderId, sHelp, authToken, isUpload));

            // Set form name based on folder type
            if (isUpload) {
                // Use normalizedFolderId for display, but fallback to folderId if null
                String displayFolder = (normalizedFolderId != null && !normalizedFolderId.isEmpty())
                        ? normalizedFolderId
                        : folderId;
                form.setFormName("Upload " + displayFolder + " Document");
            } else {
                form.setFormName("CMOD Search");
            }
            form.setType("form");

            if (sHelp != null && !sHelp.isEmpty()) {
                form.setHelp(new ReportHelp(sHelp));
            }

            return JsonUtil.toPrettyJson(form);
        } catch (final HVWException e) {
            // Propagate HVWExceptions directly
            throw e;
        } catch (final Exception e) {
            // Wrap other exceptions
            logger.error("Error generating CMOD folder data for folderId {}: {}", folderId, e.getMessage(), e);
            throw new HVWException(503, "Error generating CMOD folder data: " + e.getMessage(), SERVICE_NAME);
        }
    }

    /**
     * Creates the actions for the form including upload if the user has permission.
     * 
     * @param folderName   The normalized folder name
     * @param authToken    The authentication token
     * @param isUploadForm Whether this is an upload form
     * @return List of report actions
     */
    List<ReportAction> createFormActions(final String folderName, final String authToken,
            final boolean isUploadForm) {
        // For upload folders, only have upload action and reset
        if (isUploadForm) {
            final ReportAction goToSearchAction = createAction("goToSearch", "link", "Go To Search", "secondary", null);
            goToSearchAction.setNavigateUrl("pages/single-report/CMOD" + folderName);

            return List.of(
                    createAction("upload", "submit", "Upload", "primary", "report-archive/prepare-upload"),
                    createAction("reset", "reset", "Reset", "secondary", null),
                    goToSearchAction);
        }

        // For regular search folders
        final List<ReportAction> actions = new ArrayList<>(List.of(
                createAction("search", "submit", "Search", "primary", "report-archive/indexes/search-folder"),
                createAction("reset", "reset", "Reset", "secondary", null),
                createAction("clear", "clear", "Clear", "secondary", null)));

        // Check if upload action should be shown
        try {
            final boolean showUploadAction = uploadActionService.shouldShowUploadAction(folderName, authToken);
            if (showUploadAction) {
                logger.debug("Upload action will be shown for folder: {}", folderName);

                // Add upload action
                final ReportAction uploadAction = createAction("upload", "link", "Upload", "secondary", null);
                uploadAction.setNavigateUrl("pages/report-upload/CMODUPLOAD" + folderName);
                actions.add(uploadAction);
            }
        } catch (final Exception e) {
            logger.error("Error checking upload action permission: {}", e.getMessage(), e);
            // Continue without upload action if there's an error
        }

        return actions;
    }

    /**
     * Creates the layouts for the form.
     * 
     * @param folderId     The folder ID
     * @param help         The help text
     * @param authToken    The authentication token
     * @param isUploadForm Whether this is an upload form
     * @return List of report layouts
     * @throws IOException If an error occurs during processing
     */
    List<ReportLayout> createFormLayouts(final String folderId, final String help, final String authToken,
            final boolean isUploadForm) throws IOException {
        try {
            // Read fields and create sections
            final ReportChild foldername = new ReportChild();
            foldername.setDisplay(true);
            foldername.setName("Folder Name");
            foldername.setInputType("text");
            foldername.setLayoutType("property");
            foldername.setType("string");

            // Normalize folder ID
            final String normalizedFolderId = normalizeFolderId(folderId);
            logger.debug("Folder ID normalization: original='{}', normalized='{}'", folderId, normalizedFolderId);
            foldername.setDefaultValue(normalizedFolderId);
            foldername.setReadonly(true);
            foldername.setId("odFolderName");
            foldername.setQueryParamId("CMOD_FOLDER_NAME");

            // Create appropriate sections based on form type
            if (isUploadForm) {
                // For upload form, we don't need date fields but need a file upload field
                final List<ReportChild> uploadFields = createFileUploadFields();

                // Add application selection dropdown with folder-specific choices
                final List<ReportChild> appSelectionFields = createApplicationSelectionFields(folderId);

                // Get index fields
                final List<ReportChild> indexFields = getIndexFields(folderId, authToken, null, isUploadForm);

                // Only continue if we successfully retrieved index fields
                if (indexFields.isEmpty()) {
                    logger.warn("No index fields were retrieved for folderId {}", folderId);
                }

                return List.of(
                        createSection(List.of(foldername), "Folder", "Folder_ID", "Folder_SID"),
                        createSection(appSelectionFields, "Application", "APP_ID", "APP_SID"),
                        createSection(uploadFields, "Upload File", "UPLOAD_ID", "UPLOAD_SID"),
                        createSection(indexFields, "Indexes", "INDEXSECTION_ID", "INDEXSECTION_SID"));
            } else {
                // For regular search form, include date fields
                final List<ReportChild> dateFields = readFieldsFromJson(DATES_PATH);

                // Get index fields with posting date info
                final Map<String, List<String>> postingDateValues = new HashMap<>();
                final List<ReportChild> indexFields = getIndexFields(folderId, authToken, postingDateValues,
                        isUploadForm);

                // Only continue if we successfully retrieved index fields
                if (indexFields.isEmpty()) {
                    logger.warn("No index fields were retrieved for folderId {}", folderId);
                }

                // Update date fields with default values if available
                if (!postingDateValues.isEmpty() && postingDateValues.containsKey("POSTING DATE")) {
                    logger.debug("Default date values found for POSTING DATE, using service-provided values.");
                    final List<String> dateValues = postingDateValues.get("POSTING DATE");
                    if (dateValues != null && dateValues.size() >= 2) {
                        for (final ReportChild dateField : dateFields) {
                            if ("startdate".equals(dateField.getId()) && dateValues.get(0) != null
                                    && !dateValues.get(0).isEmpty()) {
                                dateField.setDefaultValue(dateValues.get(0));
                            } else if ("enddate".equals(dateField.getId()) && dateValues.get(1) != null
                                    && !dateValues.get(1).isEmpty()) {
                                dateField.setDefaultValue(dateValues.get(1));
                            }
                        }
                    }
                } else {
                    logger.debug(
                            "No default date values found, setting startdate to 3 months ago and enddate to today in yyyy-MM-dd format.");
                    // If no default date values, set startdate to 3 months ago and enddate to today
                    // in yyyy-MM-dd format
                    java.time.LocalDate today = java.time.ZonedDateTime.now(java.time.ZoneId.of("America/New_York"))
                            .toLocalDate();
                    java.time.LocalDate threeMonthsAgo = today.minusMonths(3);
                    for (final ReportChild dateField : dateFields) {
                        if ("startdate".equals(dateField.getId())) {
                            dateField.setDefaultValue(threeMonthsAgo.toString());
                        } else if ("enddate".equals(dateField.getId())) {
                            dateField.setDefaultValue(today.toString());
                        }
                    }
                }

                return List.of(
                        createSection(List.of(foldername), "Folder", "SearchFolder_ID", "Folder_SID"),
                        createSection(dateFields, "Dates", "DATES_ID", "DATES_SID"),
                        createSection(indexFields, "Indexes", "INDEXSECTION_ID", "INDEXSECTION_SID"));
            }
        } catch (final HVWException e) {
            // Propagate HVWExceptions directly
            throw e;
        } catch (final Exception e) {
            // Wrap other exceptions
            logger.error("Error creating form layouts for folderId {}: {}", folderId, e.getMessage(), e);
            throw new HVWException(503, "Error creating form layouts: " + e.getMessage(), SERVICE_NAME);
        }
    }

    /**
     * Gets the index fields for the specified folder.
     * 
     * @param folderId  The folder ID
     * @param authToken The authentication token
     * @return List of index fields
     */

    public List<ReportChild> getIndexFields(final String folderId, final String authToken, boolean isUploadForm) {
        return getIndexFields(folderId, authToken, null, isUploadForm);
    }

    /**
     * Gets index fields for a folder.
     * 
     * @param folderId      The folder ID
     * @param authToken     The authentication token
     * @param dateValuesMap Map to collect posting date values
     * @return The index fields
     */
    List<ReportChild> getIndexFields(final String folderId, final String authToken,
            final Map<String, List<String>> dateValuesMap, boolean isUploadForm) {
        try {
            logger.info("Calling index service with URL: {}", fieldsUrl);
            logger.debug("Authorization token provided: {}", authToken != null ? "Yes" : "No");

            // Properly normalize the folder ID - remove both CMOD and UPLOAD prefixes
            final String normalizedFolderId = normalizeFolderId(folderId);
            logger.debug("Normalized folder ID for index service: {} -> {}", folderId, normalizedFolderId);

            final ResponseEntity<Map> response = restClientUtil.postRequest(
                    fieldsUrl,
                    authToken,
                    Map.of("odFolder", normalizedFolderId));

            if (!response.getStatusCode().is2xxSuccessful()) {
                logger.error("Error response from fields service: {}", response.getStatusCode());
                throw HVWException.parseErrorResponse(response, SERVICE_NAME);
            }

            if (response.getBody() == null) {
                throw new HVWException(503, "Empty response from fields service", SERVICE_NAME);
            }

            return transformFieldsFromDetailFormat(response.getBody(), folderId, dateValuesMap, isUploadForm);

        } catch (final HVWException e) {
            logger.error("Service error fetching index fields for folder {}: {}", folderId, e.getMessage());
            throw e;
        } catch (final Exception e) {
            logger.error("Error fetching index fields for folder {}: {}", folderId, e.getMessage(), e);
            throw new HVWException(503, "Error fetching index fields: " + e.getMessage(), SERVICE_NAME);
        }
    }

    /**
     * Transforms the response fields into the required format.
     * 
     * @param responseBody The response body from the API
     * @param folderName   The folder name
     * @return List of transformed fields
     */
    @SuppressWarnings("unused")
    private List<ReportChild> transformFieldsFromDetailFormat(final Map<String, Object> responseBody,
            final String folderName) {
        return transformFieldsFromDetailFormat(responseBody, folderName, null, false);
    }

    /**
     * Transforms the response fields into the required format and collects posting
     * date values.
     * 
     * @param responseBody  The response body from the API
     * @param folderName    The folder name
     * @param dateValuesMap Map to collect posting date values
     * @return List of transformed fields
     * @throws HVWException If an error occurs when transforming fields or if the
     *                      response is invalid
     */
    List<ReportChild> transformFieldsFromDetailFormat(
            final Map<String, Object> responseBody,
            final String folderName,
            final Map<String, List<String>> dateValuesMap, boolean isUploadForm) {

        if (responseBody == null) {
            throw new HVWException(503, "Null response body from fields service", SERVICE_NAME);
        }

        // Check if response contains service message with error
        HVWException.checkServiceMessage(responseBody, SERVICE_NAME);

        if (!responseBody.containsKey("folderSearchCriteria")) {
            throw new HVWException(503, "Missing folderSearchCriteria in response", SERVICE_NAME);
        }

        final List<Map<String, Object>> fields = (List<Map<String, Object>>) responseBody.get("folderSearchCriteria");

        if (fields == null || fields.isEmpty()) {
            logger.warn("No folder search criteria fields found for folder: {}", folderName);
            throw new HVWException(404, "No field criteria found for folder: " + folderName, SERVICE_NAME);
        }

        final List<ReportChild> resultFields = new ArrayList<>();

        try {
            for (final Map<String, Object> field : fields) {
                final ReportChild transformedField = new ReportChild();

                final String fieldName = (String) field.get("name");
                // Handle POSTING DATE with defaultValueAvailable set to true
                if ("POSTING DATE".equals(fieldName)) {
                    if (Boolean.TRUE.equals(field.get("defaultValueAvailable"))) {
                        final List<String> searchValues = (List<String>) field.get("searchValues");
                        if (searchValues != null && searchValues.size() >= 2 && dateValuesMap != null) {
                            // Store the date values for later use with the date fields
                            dateValuesMap.put(fieldName, searchValues);
                        }
                    }

                    // Skip adding "POSTING DATE" to resultFields for normal pages
                    if (!isUploadForm) {
                        logger.debug("Excluding 'POSTING DATE' field for folder: {}", folderName);
                        continue;
                    }
                }

                if (fieldName == null) {
                    logger.warn("Skipping field with null name in folder: {}", folderName);
                    continue;
                }

                transformedField.setId(fieldName.toUpperCase());
                transformedField.setName(fieldName);
                transformedField.setInputType("text");
                transformedField.setType("string");
                transformedField.setDisplay(true);
                transformedField.setRequired(false);
                transformedField.setLayoutType("property");

                // Set maxLength from maxEntryChars if available
                if (field.containsKey("maxEntryChars")) {
                    final Integer maxEntryChars = Integer.valueOf(field.get("maxEntryChars").toString());
                    transformedField.setMaxLength(maxEntryChars);
                }

                resultFields.add(transformedField);
            }

            return resultFields;
        } catch (final Exception e) {
            logger.error("Error transforming fields for folder {}: {}", folderName, e.getMessage(), e);
            throw new HVWException(503, "Error transforming fields: " + e.getMessage(), SERVICE_NAME);
        }
    }

    /**
     * Creates a section with the specified fields.
     * 
     * @param fields The fields for the section
     * @param name   The section name
     * @param id     The section ID
     * @param sid    The section SID
     * @return A configured ReportLayout object
     */
    ReportLayout createSection(final List<ReportChild> fields, final String name, final String id,
            final String sid) {
        // Divide fields into columns
        final List<ReportChild> columnsChildren = divideFieldsIntoColumns(fields);

        // Create columns layout
        final ReportChild columns = new ReportChild();
        columns.setLayoutType("columns");
        columns.setChildren(columnsChildren);

        // Add columns to section
        final List<ReportChild> sectionChildren = new ArrayList<>();
        sectionChildren.add(columns);

        if (name.equals("SearchFolder_ID")) {
            // Add hidden srchop field (only for search page)
            ReportChild srchop = new ReportChild();
            srchop.setId("srchop");
            srchop.setName("srchop");
            srchop.setInputType("hidden");
            srchop.setType("string");
            srchop.setDisplay(false);
            srchop.setDefaultValue("A");
            sectionChildren.add(srchop);
        }

        final ReportLayout section = new ReportLayout();
        section.setLayoutType("section");
        section.setName(name);
        section.setId(id);
        section.setSid(sid);
        section.setCollapsible(false);
        section.setDefaultCollapsed(false);
        section.setChildren(sectionChildren);

        return section;
    }

    /**
     * Creates a column from a list of fields.
     * 
     * @param fields The fields for the column
     * @return A configured ReportChild object representing a column
     */
    private ReportChild createColumn(final List<ReportChild> fields) {
        final ReportChild column = new ReportChild();
        column.setLayoutType("column");
        column.setCollapsible(false);
        column.setDefaultCollapsed(false);
        column.setChildren(fields);
        return column;
    }

    /**
     * Divides fields into columns based on the number of fields.
     *
     * @param fields The fields to divide
     * @return List of columns containing the fields arranged row-wise
     */
    List<ReportChild> divideFieldsIntoColumns(final List<ReportChild> fields) {
        final List<ReportChild> columns = new ArrayList<>();
        final int totalFields = fields.size();
        // Special case for exactly 2 fields
        if (fields.size() == 2) {
            columns.add(createColumn(List.of(fields.get(0))));
            columns.add(createColumn(List.of(fields.get(1))));
            return columns;
        }

        // Add queryParamId to each field (field1, field2, ...) only if not already set
        for (int i = 0; i < totalFields; i++) {
            ReportChild field = fields.get(i);
            if (field.getQueryParamId() == null || field.getQueryParamId().isEmpty()) {
                field.setQueryParamId("field" + (i + 1));
            }
        }

        if (totalFields <= 5) {
            // Single column
            final ReportChild singleColumn = createColumn(fields);
            columns.add(singleColumn);
        } else {
            int numCols = (totalFields <= 10) ? 2 : (int) Math.ceil(totalFields / 5.0);
            // Initialize column containers
            List<List<ReportChild>> colLists = new ArrayList<>();
            for (int i = 0; i < numCols; i++) {
                colLists.add(new ArrayList<>());
            }

            // Fill row-wise into columns
            for (int i = 0; i < totalFields; i++) {
                int colIndex = i % numCols;
                colLists.get(colIndex).add(fields.get(i));
            }

            // Create columns
            for (List<ReportChild> colFields : colLists) {
                columns.add(createColumn(colFields));
            }
        }

        return columns;
    }

    /**
     * Divides fields into columns based on the number of fields.
     * 
     * @param fields The fields to divide
     * @return List of columns containing the fields
     */
    List<ReportChild> divideFieldsIntoColumnsold(final List<ReportChild> fields) {
        final List<ReportChild> columns = new ArrayList<>();
        final int totalFields = fields.size();

        if (totalFields <= 5) {
            // Single column
            final ReportChild singleColumn = createColumn(fields);
            columns.add(singleColumn);
        } else if (totalFields <= 10) {
            // Two columns, split equally
            final int mid = (int) Math.ceil(totalFields / 2.0);
            columns.add(createColumn(fields.subList(0, mid)));
            columns.add(createColumn(fields.subList(mid, totalFields)));
        } else {
            // Break into multiple columns with 5 fields each
            int index = 0;
            while (index < totalFields) {
                final int end = Math.min(index + 5, totalFields);
                columns.add(createColumn(fields.subList(index, end)));
                index += 5;
            }
        }

        return columns;
    }

    /**
     * Reads fields from a JSON file.
     * 
     * @param filePath The path to the JSON file
     * @return List of fields from the JSON file
     * @throws IOException If an error occurs while reading the file
     */
    List<ReportChild> readFieldsFromJson(final String filePath) throws IOException {
        try (InputStream inputStream = getClass().getClassLoader()
                .getResourceAsStream(filePath.startsWith("./") ? filePath.substring(2) : filePath)) {
            if (inputStream == null) {
                logger.error("Resource not found: {}", filePath);
                throw new HVWException(503, "Resource not found: " + filePath, SERVICE_NAME);
            }

            return objectMapper.readValue(inputStream, new TypeReference<List<ReportChild>>() {
            });
        } catch (final HVWException e) {
            throw e;
        } catch (final Exception e) {
            logger.error("Error reading resource file {}: {}", filePath, e.getMessage(), e);
            throw new HVWException(503, "Error reading resource: " + filePath + " - " + e.getMessage(), SERVICE_NAME);
        }
    }

    /**
     * Creates file upload fields for the upload form
     * 
     * @return List of fields including a file upload field
     */
    List<ReportChild> createFileUploadFields() {
        final List<ReportChild> fields = new ArrayList<>();

        // Create file upload field
        final ReportChild fileUpload = new ReportChild();
        fileUpload.setDisplay(true);
        fileUpload.setName("Upload Document");
        fileUpload.setInputType("file");
        fileUpload.setLayoutType("property");
        fileUpload.setType("file");
        fileUpload.setId("binary");
        fileUpload.setRequired(true);
        /*
         * // Add file type description
         * final ReportChild fileTypeDesc = new ReportChild();
         * fileTypeDesc.setDisplay(true);
         * fileTypeDesc.setName("Supported File Types");
         * fileTypeDesc.setInputType("text");
         * fileTypeDesc.setLayoutType("property");
         * fileTypeDesc.setType("string");
         * fileTypeDesc.setId("fileTypes");
         * fileTypeDesc.setDefaultValue("PDF, TIF, TIFF, JPG, JPEG, PNG");
         * fileTypeDesc.setReadonly(true);
         */

        fields.add(fileUpload);
        // fields.add(fileTypeDesc);

        return fields;
    }

    /**
     * Creates fields for application selection.
     * 
     * @param folderId The folder ID to get relevant applications for
     * @return List of fields for application selection
     */
    List<ReportChild> createApplicationSelectionFields(final String folderId) {
        logger.debug("Creating application selection fields for folder: {}", folderId);

        final ReportChild appField = new ReportChild();
        appField.setDisplay(true);
        appField.setName("Application");
        appField.setInputType("select");
        appField.setLayoutType("property");
        appField.setType("string");
        appField.setRequired(true);
        appField.setId("applicationId");

        // Get application choices from service
        try {
            // Use the folder-specific method instead of getting all applications
            final List<Map<String, String>> choices = cmodAppService.getApplicationChoicesForFolder(folderId);
            if (choices != null && !choices.isEmpty()) {
                appField.setChoiceList(choices);
                logger.debug("Added {} application choices to dropdown for folder {}", choices.size(), folderId);

                // Log the choices for debugging
                if (logger.isDebugEnabled()) {
                    for (final Map<String, String> choice : choices) {
                        logger.debug("  Choice - key: '{}', displayName: '{}'",
                                choice.get("key"), choice.get("displayName"));
                    }
                }
            } else {
                logger.warn("No application choices found for folder {}", folderId);
                // Add a default choice to prevent UI errors
                appField.setChoiceList(List.of(Map.of(
                        "key", "",
                        "displayName", "No applications found for this folder")));
            }
        } catch (final Exception e) {
            logger.error("Error getting application choices for folder {}: {}", folderId, e.getMessage(), e);
            // Add a default choice to prevent UI errors
            appField.setChoiceList(List.of(Map.of(
                    "key", "",
                    "displayName", "Error loading applications")));
        }

        return List.of(appField);
    }

    /**
     * Creates a report action with the specified parameters.
     * 
     * @param action  The action name
     * @param type    The action type
     * @param label   The action label
     * @param variant The action variant
     * @param url     The API URL
     * @return A configured ReportAction object
     */
    private ReportAction createAction(final String action, final String type, final String label, final String variant,
            final String url) {
        final ReportAction ra = new ReportAction();
        ra.setAction(action);
        ra.setActionType(type);
        ra.setLabel(label);
        ra.setVariant(variant);
        ra.setApiUrl(url);
        return ra;
    }
}