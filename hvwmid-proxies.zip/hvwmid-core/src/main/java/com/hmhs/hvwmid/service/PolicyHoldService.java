package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;
import com.hmhs.hvwmid.entity.T222ImgRmaPolicyHold;
import com.hmhs.hvwmid.repository.T222ImgRmaPolicyHoldRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PolicyHoldService {
    private static final Logger logger = LogManager.getLogger(PolicyHoldService.class);

    private final T222ImgRmaPolicyHoldRepository t222ImgRmaPolicyHoldRepository;

    public PolicyHoldService(T222ImgRmaPolicyHoldRepository t222ImgRmaPolicyHoldRepository) {
        this.t222ImgRmaPolicyHoldRepository = t222ImgRmaPolicyHoldRepository;
    }

    public void create(String loginUser, String holds, T222ImgRmaPolicy policy) {
        String[] holdCodes = holds.split(",");
        for (String holdCodeStr : holdCodes) {
            if (!holdCodeStr.isBlank()) {
                logger.info("Creating new Policy-Hold relation... Policy code: {} Hold code: {}", policy.getPolicyCode(), holdCodeStr);
                Integer holdCode = Integer.valueOf(holdCodeStr.trim());

                T222ImgRmaPolicyHold policyHold = new T222ImgRmaPolicyHold();
                policyHold.setBpdId(policy.getBpdId());
                policyHold.setPolicyCode(policy.getPolicyCode());
                policyHold.setHoldCode(holdCode);
                policyHold.setModUser(loginUser);
                policyHold.setModDate(LocalDateTime.now());

                t222ImgRmaPolicyHoldRepository.save(policyHold);
                logger.info("Policy-Hold relation created. Policy code: {} Hold code: {}", policy.getPolicyCode(), holdCodeStr);
            }
        }
    }

    public void update(String loginUser, String holds, T222ImgRmaPolicy policy) {
        // 1. Get new holds
        Set<Integer> newHoldCodes = Arrays.stream(holds.split(","))
                .filter(s -> !s.isBlank())
                .map(s -> Integer.valueOf(s.trim()))
                .collect(Collectors.toSet());

        // 2. Get existing policy holds
        List<T222ImgRmaPolicyHold> existingHolds = t222ImgRmaPolicyHoldRepository
                .findByPolicyCodeAndBpdId(policy.getPolicyCode(), policy.getBpdId());

        Set<Integer> existingHoldCodes = existingHolds.stream()
                .map(T222ImgRmaPolicyHold::getHoldCode)
                .collect(Collectors.toSet());

        // 3. If the same do nothing
        if (existingHoldCodes.equals(newHoldCodes)) {
            logger.info("No changes in holds for policy {}. Skipping update.", policy.getPolicyCode());
            return;
        }

        // 4. Find which to add and which to remove
        Set<Integer> toDelete = new HashSet<>(existingHoldCodes);
        toDelete.removeAll(newHoldCodes);

        Set<Integer> toAdd = new HashSet<>(newHoldCodes);
        toAdd.removeAll(existingHoldCodes);

        // 5. Delete
        if (!toDelete.isEmpty()) {
            logger.info("Deleting holds {} for policy {}", toDelete, policy.getPolicyCode());
            t222ImgRmaPolicyHoldRepository.deleteByPolicyCodeAndBpdIdAndHoldCodeIn(
                    policy.getPolicyCode(), policy.getBpdId(), toDelete
            );
        }

        // 6. Adding new holds
        for (Integer holdCode : toAdd) {
            logger.info("Adding new hold {} for policy {}", holdCode, policy.getPolicyCode());

            T222ImgRmaPolicyHold policyHold = new T222ImgRmaPolicyHold();
            policyHold.setBpdId(policy.getBpdId());
            policyHold.setPolicyCode(policy.getPolicyCode());
            policyHold.setHoldCode(holdCode);
            policyHold.setModUser(loginUser);
            policyHold.setModDate(LocalDateTime.now());

            t222ImgRmaPolicyHoldRepository.save(policyHold);
        }

        logger.info("Holds updated for policy {}. Added: {}, Removed: {}",
                policy.getPolicyCode(), toAdd, toDelete);
    }

    public void deleteByHoldCode(Integer holdCode) {
        logger.info("Deleting policy-hold relations for HOLD_CODE: {}", holdCode);
        t222ImgRmaPolicyHoldRepository.deleteByHoldCode(holdCode);
        logger.info("Policy-Hold relations deleted for HOLD_CODE: {}", holdCode);
    }

    public void deleteByPolicyCode(Integer policyCode) {
        logger.info("Deleting policy-hold relations for POLICY_CODE: {}", policyCode);
        t222ImgRmaPolicyHoldRepository.deleteByPolicyCode(policyCode);
        logger.info("Policy-Hold relations deleted for POLICY_CODE: {}", policyCode);
    }

    public Set<Integer> getHoldIdsByBpdIdIn(List<Integer> bpdIds) {
        return t222ImgRmaPolicyHoldRepository.findHoldCodesByBpdId(bpdIds);
    }
}
