package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

/**
 * Entity representing T222_COD_CMOD_EXT_AGP table.
 * Maps users to CMOD application groups for security access control.
 */
@Entity
@Table(name = "T222_COD_CMOD_EXT_AGP")
@IdClass(T222CodCmodExtAGPId.class)
public class T222CodCmodExtAGP {

    @Id
    @Column(name = "CMOD_APPLICATION_GROUP", length = 50)
    private String cmodApplicationGroup;

    @Id
    @Column(name = "CMOD_USER_GROUP_NAME", length = 50)
    private String cmodUserGroupName;

    @Column(name = "CMOD_USER_QR", length = 10)
    private String cmodUserQR;

    @Column(name = "CMOD_USER_GROUP_INDICATOR", length = 1)
    private String cmodUserGroupIndicator;

    // Constructors
    public T222CodCmodExtAGP() {
    }

    public T222CodCmodExtAGP(String cmodApplicationGroup, String cmodUserGroupName, 
                            String cmodUserQR, String cmodUserGroupIndicator) {
        this.cmodApplicationGroup = cmodApplicationGroup;
        this.cmodUserGroupName = cmodUserGroupName;
        this.cmodUserQR = cmodUserQR;
        this.cmodUserGroupIndicator = cmodUserGroupIndicator;
    }

    // Getters and Setters
    public String getCmodApplicationGroup() {
        return cmodApplicationGroup;
    }

    public void setCmodApplicationGroup(String cmodApplicationGroup) {
        this.cmodApplicationGroup = cmodApplicationGroup;
    }

    public String getCmodUserGroupName() {
        return cmodUserGroupName;
    }

    public void setCmodUserGroupName(String cmodUserGroupName) {
        this.cmodUserGroupName = cmodUserGroupName;
    }

    public String getCmodUserQR() {
        return cmodUserQR;
    }

    public void setCmodUserQR(String cmodUserQR) {
        this.cmodUserQR = cmodUserQR;
    }

    public String getCmodUserGroupIndicator() {
        return cmodUserGroupIndicator;
    }

    public void setCmodUserGroupIndicator(String cmodUserGroupIndicator) {
        this.cmodUserGroupIndicator = cmodUserGroupIndicator;
    }
}