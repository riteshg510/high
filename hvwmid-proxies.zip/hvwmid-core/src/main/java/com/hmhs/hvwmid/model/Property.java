package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonComponent
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class Property extends BaseLayout {

	private Object childFields;
	private List<BaseLayout> children;
	private List<ChoiceList> choiceList;
	private String choicelistApi;
	private boolean choiceListMultiSelect;
	private String dateFormat;
	private Object defaultValue;
	private String description;
	private String display;
	private String example;
	private String falseLabel;
	private String htmlText;
	private String id;
	private String inputType;
	private String js;
	private String layoutType;
	private String lookupApi;
	private int maxLength;
	private int maxValue;
	private int minLength;
	private int minValue;
	private boolean multiline;
	private String name;
	private Object parentFields;
	private String pattern;
	private String patternMessage;
	private boolean readonly;
	private String required;
	private String sid;
	private String trueLabel;
	private String type;
	private boolean multiple;
	private boolean allowFutureDate;

	public Object getChildFields() {
		return childFields;
	}

	public void setChildFields(Object childFields) {
		this.childFields = childFields;
	}

	public List<BaseLayout> getChildren() {
		return children;
	}

	public void setChildren(List<BaseLayout> children) {
		this.children = children;
	}

	public List<ChoiceList> getChoiceList() {
		return choiceList;
	}

	public void setChoiceList(List<ChoiceList> choiceList) {
		this.choiceList = choiceList;
	}

	public String getChoicelistApi() {
		return choicelistApi;
	}

	public void setChoicelistApi(String choicelistApi) {
		this.choicelistApi = choicelistApi;
	}

	public boolean isChoiceListMultiSelect() {
		return choiceListMultiSelect;
	}

	public void setChoiceListMultiSelect(boolean choiceListMultiSelect) {
		this.choiceListMultiSelect = choiceListMultiSelect;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public Object getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(Object defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplay() {
		return display;
	}

	public void setDisplay(String display) {
		this.display = display;
	}

	public String getExample() {
		return example;
	}

	public void setExample(String example) {
		this.example = example;
	}

	public String getFalseLabel() {
		return falseLabel;
	}

	public void setFalseLabel(String falseLabel) {
		this.falseLabel = falseLabel;
	}

	public String getHtmlText() {
		return htmlText;
	}

	public void setHtmlText(String htmlText) {
		this.htmlText = htmlText;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInputType() {
		return inputType;
	}

	public void setInputType(String inputType) {
		this.inputType = inputType;
	}

	public String getJs() {
		return js;
	}

	public void setJs(String js) {
		this.js = js;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getLookupApi() {
		return lookupApi;
	}

	public void setLookupApi(String lookupApi) {
		this.lookupApi = lookupApi;
	}

	public int getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	public int getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(int maxValue) {
		this.maxValue = maxValue;
	}

	public int getMinLength() {
		return minLength;
	}

	public void setMinLength(int minLength) {
		this.minLength = minLength;
	}

	public int getMinValue() {
		return minValue;
	}

	public void setMinValue(int minValue) {
		this.minValue = minValue;
	}

	public boolean isMultiline() {
		return multiline;
	}

	public void setMultiline(boolean multiline) {
		this.multiline = multiline;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getParentFields() {
		return parentFields;
	}

	public void setParentFields(Object parentFields) {
		this.parentFields = parentFields;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getPatternMessage() {
		return patternMessage;
	}

	public void setPatternMessage(String patternMessage) {
		this.patternMessage = patternMessage;
	}

	public boolean isReadonly() {
		return readonly;
	}

	public void setReadonly(boolean readonly) {
		this.readonly = readonly;
	}

	public String getRequired() {
		return required;
	}

	public void setRequired(String required) {
		this.required = required;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getTrueLabel() {
		return trueLabel;
	}

	public void setTrueLabel(String trueLabel) {
		this.trueLabel = trueLabel;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean isMultiple() {
		return multiple;
	}

	public void setMultiple(boolean multiple) {
		this.multiple = multiple;
	}

	public boolean isAllowFutureDate() {
		return allowFutureDate;
	}

	public void setAllowFutureDate(boolean allowFutureDate) {
		this.allowFutureDate = allowFutureDate;
	}

}
