package com.hmhs.hvwmid.mapper;

import com.hmhs.hvwmid.dto.PolicyResponse;
import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;

import java.time.format.DateTimeFormatter;

public class PolicyMapper {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static PolicyResponse toResponse(T222ImgRmaPolicy entity) {
        if (entity == null) {
            return null;
        }
        PolicyResponse response = new PolicyResponse();
        response.setBpdId(entity.getBpdId());
        response.setPolicyCode(entity.getPolicyCode());
        response.setPolicyId(entity.getPolicyId());
        response.setPolicyDays(entity.getPolicyDays());
        response.setPolicyEditFlag(entity.getPolicyEditFlag());
        response.setPolicyEditPgmName(entity.getPolicyEditPgmName());
        response.setPolicyIdType(entity.getPolicyIdType());
        response.setPolicyBaseDate(entity.getPolicyBaseDate() != null ? entity.getPolicyBaseDate().format(DATE_FORMATTER) : null);
        response.setModUser(entity.getModUser());
        response.setModDate(entity.getModDate() != null ? entity.getModDate().format(DATETIME_FORMATTER) : null);
        response.setPolicyDescription(entity.getPolicyDescription());
        return response;
    }
}