package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ramanjaneyulu Manam on Oct 18, 2024
 */
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TableDefinition {

	Short allowMultipleSort;
	Short allowResizeColumns;
	Pagination pagination;
	List<Field> columns;

	public Short getAllowMultipleSort() {
		return allowMultipleSort;
	}

	public void setAllowMultipleSort(Short allowMultipleSort) {
		this.allowMultipleSort = allowMultipleSort;
	}

	public Short getAllowResizeColumns() {
		return allowResizeColumns;
	}

	public void setAllowResizeColumns(Short allowResizeColumns) {
		this.allowResizeColumns = allowResizeColumns;
	}

	public List<Field> getColumns() {
		return columns;
	}

	public void setColumns(List<Field> columns) {
		this.columns = columns;
	}

	public Pagination getPagination() {
		return pagination;
	}

	public void setPagination(Pagination pagination) {
		this.pagination = pagination;
	}

}
