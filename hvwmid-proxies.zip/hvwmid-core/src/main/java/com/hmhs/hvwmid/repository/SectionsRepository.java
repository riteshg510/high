package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblSections;

/**
 * @author Ramanjaneyulu Manam on Sept 9, 2024
 */
@Repository
public interface SectionsRepository extends CrudRepository<TblSections, Integer> {

	/**
	 * @param formId
	 * @return
	 */
	List<TblSections> getSectionsByFormId(String formId);

	/**
	 * @param sectionId
	 * @return
	 */
	List<TblSections> getSectionsByParentSectionId(String sectionId);

	/**
	 * @param formId
	 * @param parentSectionId
	 * @return
	 */
	List<TblSections> getSectionDataByParentSectionIdAndFormIdOrderByParentColumnNumberAsc(String psid, String fid);
}
