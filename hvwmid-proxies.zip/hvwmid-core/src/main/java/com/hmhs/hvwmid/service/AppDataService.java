package com.hmhs.hvwmid.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.entity.TblActions;
import com.hmhs.hvwmid.entity.TblCabinets;
import com.hmhs.hvwmid.entity.TblColumns;
import com.hmhs.hvwmid.entity.TblDepartment;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblHelpPages;
import com.hmhs.hvwmid.entity.TblLdapCabinets;
import com.hmhs.hvwmid.entity.TblPickListItems;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblSections;
import com.hmhs.hvwmid.entity.TblTables;
import com.hmhs.hvwmid.entity.TblTemplates;

/**
 * @author Ramanjaneyulu Manam on Sep 18, 2024
 */
public interface AppDataService {

	/**
	 * @param formId
	 * @return
	 */
	List<TblActions> getActionsByFormId(String formId);

	/**
	 * @param userCabinetIds
	 * @return
	 */
	List<TblCabinets> getCabinetsByCabinetIds(List<String> userCabinetIds);

	/**
	 * @param listCabinetsNames
	 * @return
	 */
	List<TblCabinets> getCabinetsByCabinetsNames(List<String> listCabinetsNames);

	/**
	 * @param departmentId
	 * @return
	 */
	List<TblCabinets> getCabinetsByDepartmentId(String departmentId);

	/**
	 * @param userCabinetIds
	 * @return
	 */
	List<String> getDepartmentIdsByUserCabinetIds(List<String> userCabinetIds);

	/**
	 * @return
	 */
	List<TblDepartment> findAllDepartment();

	/**
	 * @param deptIdList
	 * @return
	 */
	List<TblDepartment> getDepartmentsByDeptIds(List<String> deptIdList);

	/**
	 * @param groupName
	 * @return
	 */
	List<TblLdapCabinets> getCabinetsNamesByGroupName(String groupName);

	/**
	 * @param fid
	 * @return
	 */
	TblForms getForm(String fid);

	/**
	 * @param filename
	 * @return
	 */
	List<TblForms> getFormIdByFileName(String filename);

	/**
	 * @param pid
	 * @return
	 */
	List<TblPickListItems> getPickList(String pid);

	/**
	 * @param pid
	 * @param key
	 * @return
	 */
	List<TblPickListItems> getPickList(String pid, String pkey);

	/**
	 * @param layoutChildId as sid
	 * @return
	 */
	List<TblSectionDetails> getSectionDetailsBySectionId(String sid);
	
	/**
	 * @param layoutChildId as sectionId
	 * @return
	 */
	List<TblSectionDetails> getSectionDetailsBySectionIdOrderByFieldOrderAsc(String sectionId);

	/**
	 * @param sectionId
	 * @param fieldName
	 * @return
	 */
	List<String> getChildList(String sectionId, String fieldName);

	/**
	 * @param fid
	 * @return
	 */
	List<TblSections> getSections(String fid);

	/**
	 * @param psid
	 * @return
	 */
	List<TblSections> getSectionsByParentSectionId(String psid, String fid);

	/**
	 * @param tableId
	 * @return
	 */
	List<TblColumns> getColumns(String tableId);

	/**
	 * @param tableId
	 * @return
	 */
	TblTables getTableByTableId(String tableId);

	/**
	 * @param templateName
	 * @return
	 */
	List<TblTemplates> getTempletByName(String templateName);

	/**
	 * @param id
	 * @return
	 */
	ImageData getImageDataFilename(String id);

	/**
	 * @param pagingSort
	 * @return
	 */
	Page<ImageData> findAll(Pageable pagingSort);

	/**
	 * @param formDescription
	 * @param pagingSort
	 * @return
	 */
	Page<ImageData> findByFormDescriptionContaining(String formDescription, Pageable pagingSort);

	/**
	 * @param odFolderName
	 * @return
	 */
	TblHelpPages getHelpPages(String odFolderName);

	/**
	 * @param cabinetId
	 */
	String updateCabinetsTable(String cabinetId);

	/**
	 * @param TableName
	 */
	TblTables getTableByTableName(String tableName);
	
	/**
	 * @return
	 */
	List<String> getLDAPGroups();

}
