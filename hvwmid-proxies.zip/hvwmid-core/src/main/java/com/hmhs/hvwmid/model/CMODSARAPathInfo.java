package com.hmhs.hvwmid.model;

import java.util.Map;

/**
 * DTO representing SARA (Security Access Role Administration) path information.
 * Contains hierarchical path structure for CMOD security access.
 */
public class CMODSARAPathInfo {

    private String rootPath;
    private Map<String, String> highviewPaths;
    private Map<String, String> renoPaths;

    // Constructors
    public CMODSARAPathInfo() {
    }

    public CMODSARAPathInfo(String rootPath, Map<String, String> highviewPaths, Map<String, String> renoPaths) {
        this.rootPath = rootPath;
        this.highviewPaths = highviewPaths;
        this.renoPaths = renoPaths;
    }

    // Getters and Setters
    public String getRootPath() {
        return rootPath;
    }

    public void setRootPath(String rootPath) {
        this.rootPath = rootPath;
    }

    public Map<String, String> getHighviewPaths() {
        return highviewPaths;
    }

    public void setHighviewPaths(Map<String, String> highviewPaths) {
        this.highviewPaths = highviewPaths;
    }

    public Map<String, String> getRenoPaths() {
        return renoPaths;
    }

    public void setRenoPaths(Map<String, String> renoPaths) {
        this.renoPaths = renoPaths;
    }
}