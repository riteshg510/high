package com.hmhs.hvwmid.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblColumns;
import com.hmhs.hvwmid.entity.TblHelpPages;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblSections;
import com.hmhs.hvwmid.entity.TblTables;
import com.hmhs.hvwmid.layouts.LayoutsAndActions;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService;

/**
 * @author Ramanjaneyulu Manam on Oct 21, 2024
 */
public class ApiSection {
	private static final Logger logger = LogManager.getLogger(ApiSection.class);
	@Autowired
	LoggerService loggerService;
	private AppDataService service;

	public AppDataService getService() {
		return service;
	}

	public void setService(AppDataService service) {
		this.service = service;
	}

	/**
	 * @param response
	 * @param tableId
	 * @param otherFields
	 * @return
	 */
	public TableDefinition getTableDefinition(TableDefinition response, String tableId,
			Map<String, String> otherFields) {
		try {
			TblTables table;
			if (tableId != null && !tableId.trim().isEmpty() && tableId.length() == 32) {
				table = service.getTableByTableId(tableId);
			} else if (otherFields != null && !otherFields.isEmpty()) {
				table = service.getTableByTableName(tableId);
				if (table != null) {
					tableId = table.getTableId();
				}
			} else {
				logger.warn("Both tableId and otherFields are empty.");
				return response;
			}

			if (table == null) {
				logger.error("Table not found for ID: " + tableId);
				return response;
			}

			response.setAllowMultipleSort(table.getMultipleSort());
			response.setAllowResizeColumns(table.getResizeColumns());

			List<Field> columns = new ArrayList<>();
			LayoutsAndActions las = new LayoutsAndActions();

			for (TblColumns col : service.getColumns(table.getTableId())) {
				Field field = new Field();
				field.setId(col.getName());
				field.setName(col.getLabel());
				field.setType(col.getType());
				field.setSortable(col.getSortable());
				field.setFilterable(col.getFilterable());

				switch (col.getType()) {
					case "boolean":
					case "integer":
						field.setTrueLabel("yes");
						field.setFalseLabel("no");
						break;
					case "date":
						field.setDateFormat(col.getDateFormat());
						if (col.getColumnWidth() > 0) {
							field.setColumnWidth(col.getColumnWidth());
						}
						break;
					case "string":
						field.setUrl(col.getUrl());
						if (col.getColumnWidth() > 0) {
							field.setColumnWidth(col.getColumnWidth());
						}
						if (col.getPickListOptions() != null && col.getPickListOptions().contains(",")) {
							field.setChoiceList(las.getChoiceList(col.getPickListOptions()));
						}
						break;
					default:
						logger.info("Unhandled type in switch: {}", col.getType());
						break;
				}
				columns.add(field);
			}
			// for extra columns (otherFields) headings
			if (otherFields != null && !otherFields.isEmpty()) {
				Map<String, String> sortedHeading = otherFields.entrySet().stream()
						.filter(entry -> !entry.getKey().replaceAll("\\D", "").isEmpty()) // ignore keys with no digits
						.sorted(Comparator
								.comparingInt(entry -> Integer.parseInt(entry.getKey().replaceAll("\\D", ""))))
						.collect(Collectors.toMap(
								Map.Entry::getKey,
								Map.Entry::getValue,
								(e1, e2) -> e1,
								LinkedHashMap::new));

				if (otherFields.containsKey("applidcd")) {
					String value = otherFields.get("applidcd");
					Set<String> rankColumns = Set.of("1039", "1059");
					if (rankColumns.contains(value)) {
						Field newColumn = new Field();
						newColumn.setId("rank");
						newColumn.setName("Rank");
						newColumn.setType("integer");
						newColumn.setSortable((short) 1);
						newColumn.setFilterable((short) 1);
						columns.add(0, newColumn);
					}
				}

				sortedHeading.forEach((id, value) -> {
					if (id.startsWith("heading")) {
						Field newColumnHeader = new Field();
						newColumnHeader.setId(id.replace("heading", "key"));
						newColumnHeader.setName(value);
						newColumnHeader.setType("string");
						newColumnHeader.setSortable((short) 1);
						newColumnHeader.setFilterable((short) 1);
						String dtHeader = value.toLowerCase();
						if (dtHeader.contains("date")) {
							if (dtHeader.contains("mmdd") || dtHeader.contains("mm-dd")
									|| dtHeader.contains("mm/dd")) {
								int start = value.indexOf('(');
								int end = value.indexOf(')');
								if (start != -1 && end != -1 && end > start) {
									String userDateFormat = value.substring(start + 1, end);
									newColumnHeader.setDateFormat(userDateFormat);
								}
							} else {
								newColumnHeader.setDateFormat(HVWConstants.YYMMDD);
							}
							newColumnHeader.setType("date");
						}
						columns.add(newColumnHeader);
					}
				});
			}

			response.setColumns(columns);
			response.setPagination(new Pagination());

		} catch (Exception e) {
			logger.error("Exception in getTableDefinition: ", e);
			loggerService.log("ERROR", 0, 0, 0, "", "getTableDefinition()", "", "503",
					(e.getMessage() != null && e.getMessage().length() > 250) ? e.getMessage().substring(0, 250)
							: e.getMessage());
		}
		return response;
	}

	/**
	 * @param odFolderName
	 * @return
	 */
	public List<TblSectionDetails> getHtmlContentByFolderName(String odFolderName) {
		TblHelpPages tblHelpPages = service.getHelpPages(odFolderName);
		if (tblHelpPages != null) {
			List<TblSections> tblSections = service.getSections(tblHelpPages.getFormId());
			if (tblSections != null && !tblSections.isEmpty()) {
				return service.getSectionDetailsBySectionId(tblSections.get(0).getSectionId());
			}
		}
		return new ArrayList<>();
	}
}
