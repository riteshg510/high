package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "T222ADSG")
@IdClass(T222ADSGId.class)
public class T222ADSG {

    @Id
    @Column(name = "IMI_DOCUMENT_ID", nullable = false)
    private Integer imiDocumentId;

    @Id
    @Column(name = "SEGMENT_SEQ_NO", nullable = false)
    private Integer segmentSeqNo;

    @Column(name = "SEGMENT_NAME", length = 3, nullable = false)
    private String segmentName;

    @Column(name = "SEGMENT_STATUS_CODE", length = 1, nullable = false)
    private String segmentStatusCode;

    @Column(name = "SEGMENT_REASON_CODE", length = 8)
    private String segmentReasonCode;

    @Column(name = "SEGMENT_DATA", length = 1024, nullable = false)
    private String segmentData;

    public Integer getImiDocumentId() {
        return imiDocumentId;
    }

    public void setImiDocumentId(final Integer imiDocumentId) {
        this.imiDocumentId = imiDocumentId;
    }

    public Integer getSegmentSeqNo() {
        return segmentSeqNo;
    }

    public void setSegmentSeqNo(final Integer segmentSeqNo) {
        this.segmentSeqNo = segmentSeqNo;
    }

    public String getSegmentName() {
        return segmentName;
    }

    public void setSegmentName(final String segmentName) {
        this.segmentName = segmentName;
    }

    public String getSegmentStatusCode() {
        return segmentStatusCode;
    }

    public void setSegmentStatusCode(final String segmentStatusCode) {
        this.segmentStatusCode = segmentStatusCode;
    }

    public String getSegmentReasonCode() {
        return segmentReasonCode;
    }

    public void setSegmentReasonCode(final String segmentReasonCode) {
        this.segmentReasonCode = segmentReasonCode;
    }

    public String getSegmentData() {
        return segmentData;
    }

    public void setSegmentData(final String segmentData) {
        this.segmentData = segmentData;
    }
} 