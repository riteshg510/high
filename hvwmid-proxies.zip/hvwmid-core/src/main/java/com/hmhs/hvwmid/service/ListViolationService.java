package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ListViolationService {

    private static final Logger logger = LogManager.getLogger(ListViolationService.class);

    @Autowired
    private RestClientUtil restClientUtil;

    @Value("${api.images.listviolation.url}")
    String url = null; // /violation/filter

    private static final String X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS = "x-highmark-businessProcessDifferentiatorIds";
    private static final String BPDID_FIELD = "bpdid";

    public ResponseEntity<Object> filter(Map<String, String> otherFields, String authToken) {
        return executeAction(otherFields, authToken);
    }

    public ResponseEntity<Object> executeAction(Map<String, String> otherFields, String authToken) {
        final ResponseEntity<Map> response = getFromBack(otherFields, authToken);

        List<Map> result = getResults(response.getBody());

        return new ResponseEntity<>(result, response.getStatusCode());
    }

    private ResponseEntity<Map> getFromBack(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>(otherFields);

        Map<String, String> extraHeaders = generateExtraHeaders(otherFields);

        return restClientUtil.postRequest(url+"/filter", authToken, requestBody, extraHeaders);
    }

    private static Map<String, String> generateExtraHeaders(Map<String, String> otherFields) {
        Map<String, String> extraHeaders = new HashMap<>();

        if (otherFields.containsKey(BPDID_FIELD) && !StringUtils.isBlank(otherFields.get(BPDID_FIELD))) {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, otherFields.get(BPDID_FIELD));
        } else {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, "1");
        }

        return extraHeaders;
    }

    private List<Map> getResults(Map response){
        List<Map> result = new ArrayList<>();
        if(response.containsKey("results")){
            Map applIds = (Map) response.get("results");
            if(applIds.containsKey("row")){
                List applList = (List) applIds.get("row");
                for(Object applObj: applList){
                    Map appl = (Map) applObj;
                    Map<String, Object> values = new HashMap<>();
                    values.put("userId", appl.get("userId"));
                    values.put("tranId", appl.get("transactionID"));
                    values.put("date", appl.get("violationTime"));
                    values.put("acf2Resource", appl.get("racfResource2"));
                    values.put("acf2String", appl.get("racfString2"));
                    values.put("description", appl.get("description"));
                    values.put("application", appl.get("application"));
                    result.add(values);

                }
            }
        }
        return result;
    }
}