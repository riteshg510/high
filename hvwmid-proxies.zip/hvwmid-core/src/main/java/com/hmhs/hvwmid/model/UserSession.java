package com.hmhs.hvwmid.model;

public class UserSession {
	
	String userId = "lid1iit";
	
	int requestId = 0;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

}
