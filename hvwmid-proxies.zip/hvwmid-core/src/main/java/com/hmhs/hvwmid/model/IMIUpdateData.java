package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Model class representing an IMI update response data.
 * Contains the response information from IMI update operations.
 * 
 * @author HighView Development Team
 * @since 1.0
 */
public class IMIUpdateData {

    @JsonProperty("responseMessage")
    private String responseMessage;

    @JsonProperty("baseMessage")
    private BaseMessage baseMessage;

    // Default constructor
    public IMIUpdateData() {
    }

    // Constructor with response message
    public IMIUpdateData(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    // Getters and Setters
    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public BaseMessage getBaseMessage() {
        return baseMessage;
    }

    public void setBaseMessage(BaseMessage baseMessage) {
        this.baseMessage = baseMessage;
    }

    @Override
    public String toString() {
        return "IMIUpdateData{" +
                "responseMessage='" + responseMessage + '\'' +
                ", baseMessage=" + baseMessage +
                '}';
    }

    /**
     * Inner class for base message information
     */
    public static class BaseMessage {
        
        @JsonProperty("returnCode")
        private String returnCode;
        
        @JsonProperty("returnCodeDescription")
        private String returnCodeDescription;

        public String getReturnCode() {
            return returnCode;
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public String getReturnCodeDescription() {
            return returnCodeDescription;
        }

        public void setReturnCodeDescription(String returnCodeDescription) {
            this.returnCodeDescription = returnCodeDescription;
        }

        @Override
        public String toString() {
            return "BaseMessage{" +
                    "returnCode='" + returnCode + '\'' +
                    ", returnCodeDescription='" + returnCodeDescription + '\'' +
                    '}';
        }
    }
}
