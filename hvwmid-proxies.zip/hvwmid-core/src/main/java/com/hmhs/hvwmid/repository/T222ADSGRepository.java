package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.T222ADSG;
import com.hmhs.hvwmid.entity.T222ADSGId;

@Repository
public interface T222ADSGRepository extends JpaRepository<T222ADSG, T222ADSGId> {

    /**
     * Retrieves segment data for a specific document ID and segment names.     
     * 
     * @param imiDocumentId the document ID to search for
     * @param segmentNames list of segment names to filter by
     * @return list of T222ADSG entities matching the criteria
     */
    @Query("SELECT t FROM T222ADSG t WHERE t.imiDocumentId = :imiDocumentId AND t.segmentName IN :segmentNames")
    List<T222ADSG> findByImiDocumentIdAndSegmentNameIn(@Param("imiDocumentId") Integer imiDocumentId, 
                                                       @Param("segmentNames") List<String> segmentNames);

    /**
     * Alternative method using Spring Data JPA naming convention
     * for finding records by document ID and segment name
     */
    //List<T222ADSG> findByImiDocumentIdAndSegmentNameIn(Integer imiDocumentId, List<String> segmentNames);

    /**
     * Find all records by document ID
     */
    List<T222ADSG> findByImiDocumentId(Integer imiDocumentId);

    /**
     * Find all records by segment name
     */
    List<T222ADSG> findBySegmentName(String segmentName);
} 