package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.util.Objects;

public class T222ImgRmaPolicyHoldId implements Serializable {
    private Integer bpdId;
    private Integer policyCode;
    private Integer holdCode;

    public Integer getBpdId() { return bpdId; }
    public void setBpdId(Integer bpdId) { this.bpdId = bpdId; }

    public Integer getPolicyCode() { return policyCode; }
    public void setPolicyCode(Integer policyCode) { this.policyCode = policyCode; }

    public Integer getHoldCode() { return holdCode; }
    public void setHoldCode(Integer holdCode) { this.holdCode = holdCode; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof T222ImgRmaPolicyHoldId)) return false;
        T222ImgRmaPolicyHoldId that = (T222ImgRmaPolicyHoldId) o;
        return Objects.equals(bpdId, that.bpdId) &&
               Objects.equals(policyCode, that.policyCode) &&
               Objects.equals(holdCode, that.holdCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bpdId, policyCode, holdCode);
    }
}
