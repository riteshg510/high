package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblDepartment;

/**
 * @author Ramanjaneyulu Manam on Nov 20, 2024
 */
@Repository
public interface DepartmentRepository extends CrudRepository<TblDepartment, String> {

	/**
	 * @return
	 */
	List<TblDepartment> findAllByOrderByDepartmentNameAsc();

	/**
	 * @param deptIdList
	 * @return
	 */
	List<TblDepartment> getDepartmentsByDepartmentIdInOrderByDepartmentNameAsc(List<String> deptIdList);

}
