package com.hmhs.hvwmid.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Represents a metadata record for a cached document.
 */
@Entity
@Table(name = "T222_COD_TOKEN")
public class TblCodToken {

    @Id
    @Column(name = "REQUEST_ID", nullable = false)
    private Integer requestId;

    @Column(name = "USERID", nullable = false, length = 10)
    private String userId;

    @Column(name = "TIME_CREATE", nullable = false)
    private LocalDateTime timeCreate;

    @Column(name = "DOCUMENT_TYPE", nullable = false, length = 10)
    private String documentType;

    @Column(name = "DOCUMENT_PAGES", nullable = false)
    private Integer documentPages;

    @Column(name = "DOCUMENT_TOKEN", nullable = false, length = 1900)
    private String documentToken;


    @Lob
    @Column(name = "SECURITY_TOKEN", nullable = false)
    private String securityToken;

    @Column(name = "DOC_CNV_STATUS", nullable = false, length = 20)
    private String docCnvStatus;

    @Column(name = "DOCUMENT_SIZE", nullable = false)
    private Integer documentSize;

    @OneToMany(
            mappedBy = "codToken",
            cascade = CascadeType.REMOVE,
            orphanRemoval = true
    )
    private List<TblCodObject> objects = new ArrayList<>();

    // Getters and Setters

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeCreate() {
        return timeCreate;
    }

    public void setTimeCreate(LocalDateTime timeCreate) {
        this.timeCreate = timeCreate;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public Integer getDocumentPages() {
        return documentPages;
    }

    public void setDocumentPages(Integer documentPages) {
        this.documentPages = documentPages;
    }

    public String getDocumentToken() {
        return documentToken;
    }

    public void setDocumentToken(String documentToken) {
        this.documentToken = documentToken;
    }


    public String getSecurityToken() {
        return securityToken;
    }

    public void setSecurityToken(String securityToken) {
        this.securityToken = securityToken;
    }


    public String getDocCnvStatus() {
        return docCnvStatus;
    }

    public void setDocCnvStatus(String docCnvStatus) {
        this.docCnvStatus = docCnvStatus;
    }

    public Integer getDocumentSize() {
        return documentSize;
    }

    public void setDocumentSize(Integer documentSize) {
        this.documentSize = documentSize;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TblCodToken)) return false;
        TblCodToken that = (TblCodToken) o;
        return Objects.equals(requestId, that.requestId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(requestId);
    }
}
