package com.hmhs.hvwmid.entity;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "T117_IMG_COVERSHEETOVERRIDE")
@IdClass(T117ImgCoverSheetOverrideId.class)
public class T117ImgCoverSheetOverride implements Serializable {

    @Id
    @Column(name = "APPLICATION", nullable = false)
    private Integer application;

    @Id
    @Column(name = "NAME", nullable = false, length = 10)
    private String name;

    @Id
    @Column(name = "SEQUENCE", nullable = false)
    private Integer sequence;

    @Column(name = "DESCRIPTION", length = 40)
    private String description;

    @Column(name = "SB1", length = 20)
    private String sb1;

    @Column(name = "EB1", length = 20)
    private String eb1;

    @Column(name = "EB2", length = 20)
    private String eb2;

    @Column(name = "EB3", length = 20)
    private String eb3;

    @Column(name = "TITLE", length = 40)
    private String title;

    @Column(name = "STITLE1", length = 40)
    private String stitle1;

    @Column(name = "STITLE2", length = 40)
    private String stitle2;

    @Column(name = "UNIT", length = 10)
    private String unit;

    @Column(name = "RCODE", length = 10)
    private String rcode;

    @Column(name = "TEMPLATE", length = 10)
    private String template;

    @Column(name = "ACTIVE", nullable = false, length = 1)
    private String active;

    @Column(name = "ENVIRONMENT", nullable = false, length = 15)
    private String environment;

    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSb1() {
        return sb1;
    }

    public void setSb1(String sb1) {
        this.sb1 = sb1;
    }

    public String getEb1() {
        return eb1;
    }

    public void setEb1(String eb1) {
        this.eb1 = eb1;
    }

    public String getEb2() {
        return eb2;
    }

    public void setEb2(String eb2) {
        this.eb2 = eb2;
    }

    public String getEb3() {
        return eb3;
    }

    public void setEb3(String eb3) {
        this.eb3 = eb3;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStitle1() {
        return stitle1;
    }

    public void setStitle1(String stitle1) {
        this.stitle1 = stitle1;
    }

    public String getStitle2() {
        return stitle2;
    }

    public void setStitle2(String stitle2) {
        this.stitle2 = stitle2;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getRcode() {
        return rcode;
    }

    public void setRcode(String rcode) {
        this.rcode = rcode;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
}
