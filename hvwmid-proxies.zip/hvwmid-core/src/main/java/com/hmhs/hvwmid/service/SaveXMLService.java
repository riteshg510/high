package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222ImgExtendedparmRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;

@Component
public class SaveXMLService {

    private static final Logger logger = LogManager.getLogger(SaveXMLService.class);

    private final ImageParmDataService imageParmDataRefresh;
    private final T222ImgExtendedparmRepository extendedparmRepository;
    @Value("${app.cmod.arsxml.cod.directory}")
    private String exportARSXMLDirectory;
    @Value("${app.cmod.arsxml.cod.eparmId}")
    private String eparmId;
    @Value("${app.cmod.arsxml.cod.eparmKey}")
    private String eparmKey;
    private final String mfFoldAGAppExportFN;

    public SaveXMLService(ImageParmDataService imageParmDataRefresh,
            T222ImgExtendedparmRepository extendedparmRepository) {
        this.imageParmDataRefresh = imageParmDataRefresh;
        this.extendedparmRepository = extendedparmRepository;
        // imageParmDataRefresh.refreshParmData();
        mfFoldAGAppExportFN = this.imageParmDataRefresh.getParmDataByKeyByCmodbase(
                "MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME",
                HVWConstants.MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME);

    }

   // @Scheduled(cron = "0 0 3 * * *", zone = "America/New_York")
    public void exportExtendedParmDataToXML() {
        if (exportARSXMLDirectory == null || exportARSXMLDirectory.isEmpty())
            exportARSXMLDirectory = this.imageParmDataRefresh.getParmDataByKeyByCODBase("CMOD_ARSXML_COD_DIRECTORY",
                    HVWConstants.CMOD_ARSXML_COD_DIRECTORY);
        logger.debug("exportARSXMLDirectory: {}", exportARSXMLDirectory);
        logger.info("Starting scheduled export of extended parameter data to XML");

        String filePath = exportARSXMLDirectory + File.separator + mfFoldAGAppExportFN;
        File outputFile = new File(filePath);

        try {
            // Create directory if it doesn't exist
            outputFile.getParentFile().mkdirs();

            // Stream data to file
            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                extendedparmRepository.streamEparmDataByIdAndKey(eparmId, eparmKey, fos);
                logger.info("Successfully exported extended parameter data to: {}", filePath);
            }

        } catch (SQLException e) {
            logger.error("Database error while exporting extended parameter data: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage(), e);
        } catch (IOException e) {
            logger.error("IO error while writing to file {}: {}", filePath, e.getMessage(), e);
            throw new RuntimeException(e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Unexpected error during export: {}", e.getMessage(), e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}
