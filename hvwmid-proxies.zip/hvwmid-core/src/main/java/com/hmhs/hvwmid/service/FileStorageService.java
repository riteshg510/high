package com.hmhs.hvwmid.service;

import org.springframework.web.multipart.MultipartFile;

import com.hmhs.hvwmid.model.FileStorageResult;

/**
 * Service interface for storing and retrieving files in chunked format
 */
public interface FileStorageService {

    /**
     * Stores a file in T222_IMG_OBJECT table as chunks
     * 
     * @param file The file to store
     * @param userId The user ID from JWT token
     * @param documentType The type of document (EXCEL, IMAGE, etc.)
     * @return FileStorageResult containing requestId and metadata
     * @throws Exception if storage fails
     */
    FileStorageResult storeFile(MultipartFile file, String userId, String documentType) throws Exception;

    /**
     * Retrieves file metadata from T222_IMG_TOKEN
     * 
     * @param requestId The request ID of the file
     * @return File metadata or null if not found
     */
    FileStorageResult getFileMetadata(Integer requestId);

    /**
     * Validates if user has access to the file
     * 
     * @param requestId The request ID of the file
     * @param userId The user ID to validate
     * @return true if user has access, false otherwise
     */
    boolean validateAccess(Integer requestId, String userId);

    /**
     * Deletes file segments and token
     * 
     * @param requestId The request ID of the file to delete
     * @throws Exception if deletion fails
     */
    void deleteFile(Integer requestId) throws Exception;
    
    /**
     * Stores file content from byte array in T222_IMG_OBJECT table as chunks
     * 
     * @param content The file content as byte array
     * @param fileName The name of the file
     * @param userId The user ID from JWT token
     * @param documentType The type of document (EXCEL, IMAGE, IMI, etc.)
     * @return FileStorageResult containing requestId and metadata
     * @throws Exception if storage fails
     */
    FileStorageResult storeFileContent(byte[] content, String fileName, String userId, String documentType) throws Exception;
}