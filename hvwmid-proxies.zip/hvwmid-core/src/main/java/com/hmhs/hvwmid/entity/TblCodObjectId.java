package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.util.Objects;

public class TblCodObjectId implements Serializable {

    private Integer requestId;
    private Integer sequenceNo;

    public TblCodObjectId() {}

    public TblCodObjectId(Integer requestId, Integer sequenceNo) {
        this.requestId = requestId;
        this.sequenceNo = sequenceNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TblCodObjectId)) return false;
        TblCodObjectId that = (TblCodObjectId) o;
        return Objects.equals(requestId, that.requestId) &&
                Objects.equals(sequenceNo, that.sequenceNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(requestId, sequenceNo);
    }
}
