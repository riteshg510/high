package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.ReportChild;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.IOException;
import java.util.*;

@Service
public class IndexListingService {

    private static final Logger logger = LogManager.getLogger(IndexListingService.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    private static final Set<String> EXCLUDE_KEYS = Set.of("documentToken", "password", "recordFormat");
    private static final String ACTIONS_COLUMN_ID = "action";
    private static final String ACTIONS_COLUMN_NAME = "Actions";
    @Autowired
    private CmodFolderService cmodFolderService;

    @Value("${api.indexes.url}")
    private String apiUrl;

    @Value("${api.access.url}")
    private String accessUrl;

    @Autowired
    RestClientUtil restClientUtil;

    public Map<String, Object> processReportData(final Map<String, String> otherFields, final String authToken)
            throws IOException {
        try {
            // Extract folder name from request parameters
            String folderName = otherFields.get("odFolderName");
            if (folderName != null && folderName.startsWith("CMOD")) {
                folderName = folderName.substring(4);
            }

            final Map<String, Object> response = fetchIndexData(otherFields, authToken);
            return buildStructuredResponse(response, authToken, folderName);
        } catch (final HVWException e) {
            return createServiceErrorResponse(e);
        } catch (final Exception e) {
            logger.error("Error processing report data: {}", e.getMessage(), e);
            return createGenericErrorResponse(e);
        }
    }

    private Map<String, Object> fetchIndexData(final Map<String, String> searchCriteria, final String authToken) {
        // Create a copy of the search criteria to avoid modifying the original
        final Map<String, String> filteredCriteria = new HashMap<>(searchCriteria);

        final Map<String, Object> requestBody = new HashMap<>();

        // Handle 'srchop' logic
        String srchop = filteredCriteria.remove("srchop");
        if (srchop != null) {
            if ("O".equalsIgnoreCase(srchop)) {
                requestBody.put("searchCriteria", "OR");
            } else if ("A".equalsIgnoreCase(srchop)) {
                requestBody.put("searchCriteria", "AND");
            }
        }

        // Extract odFolderName (removing "CMOD" prefix if present)
        String folderName = filteredCriteria.remove("odFolderName");
        if (folderName == null || folderName.isEmpty()) {
            throw new HVWException(400, "Folder name is required", "CMOD");
        }

        // Remove "CMOD" prefix if present
        if (folderName.startsWith("CMOD")) {
            folderName = folderName.substring(4);
        }
        requestBody.put("odFolder", folderName);

        // Extract start and end dates
        String startDate = filteredCriteria.remove("startdate");
        if (startDate == null || startDate.isEmpty()) {
            throw new HVWException(400, "Start date is required", "CMOD");
        }

        // Format date if needed
        if (startDate.length() == 8) {
            startDate = formatDate(startDate);
        }
        requestBody.put("beginDate", startDate);

        String endDate = filteredCriteria.remove("enddate");
        if (endDate == null || endDate.isEmpty()) {
            throw new HVWException(400, "End date is required", "CMOD");
        }

        // Format date if needed
        if (endDate.length() == 8) {
            endDate = formatDate(endDate);
        }
        requestBody.put("endDate", endDate);

        // Any remaining criteria go into folderSearchCriteria
        requestBody.put("folderSearchCriteria", List.of(filteredCriteria));

        logger.info("Sending request to index service with folder: {}, begin: {}, end: {}",
                requestBody.get("odFolder"), requestBody.get("beginDate"), requestBody.get("endDate"));

        final ResponseEntity<Map> response = restClientUtil.postRequest(apiUrl, authToken, requestBody);

        if (!response.getStatusCode().is2xxSuccessful()) {
            logger.debug("error response");
            logger.debug(response.getStatusCode());
            logger.debug(response.toString());
            handleErrorResponse(response);
        }

        final Map<String, Object> responseBody = response.getBody();

        // Use parseErrorResponse to check for service-specific errors in the response
        if (responseBody != null && responseBody.containsKey("serviceMessage")) {
            try {
                HVWException.checkServiceMessage(responseBody, "CMOD");
            } catch (final HVWException e) {
                throw e; // Re-throw if an exception is generated
            }
        }

        return responseBody;
    }

    /**
     * Formats a date from YYYYMMDD to MM/DD/YY format
     * 
     * @param date Date in YYYYMMDD format
     * @return Date in MM/DD/YY format
     */
    private String formatDate(final String date) {
        if (date == null || date.length() != 8) {
            return date;
        }

        try {
            final String month = date.substring(4, 6);
            final String day = date.substring(6, 8);
            final String year = date.substring(2, 4);

            return month + "/" + day + "/" + year;
        } catch (final Exception e) {
            logger.warn("Failed to format date {}: {}", date, e.getMessage());
            return date;
        }
    }

    private Map<String, Object> buildStructuredResponse(final Map<String, Object> rawResponse, final String authToken,
            final String folderName)
            throws IOException {
        final Map<String, Object> output = new LinkedHashMap<>();
        output.put("definition", createTableDefinition(rawResponse, authToken));
        output.put("data", processTableData(rawResponse, authToken, folderName));
        return output;
    }

    private Map<String, Object> createTableDefinition(final Map<String, Object> apiResponse, String authToken) {
        final Map<String, Object> definition = new LinkedHashMap<>();
        definition.put("allowMultipleSort", false);
        definition.put("allowResizeColumns", false);
        definition.put("pagination", Map.of("pageNumber", 0, "pageSize", 10));
        definition.put("columns", buildColumns(apiResponse, authToken));
        // Add actions array with download action
        List<Map<String, Object>> actions = new ArrayList<>();
        Map<String, Object> downloadAction = new HashMap<>();
        downloadAction.put("actionType", "downloadpdf");
        downloadAction.put("label", "Download Selected");
        downloadAction.put("actionIcon", "download");
        downloadAction.put("apiUrl", "report-archive/tokens/view");
        actions.add(downloadAction);

        definition.put("actions", actions);
        // Add selectionMode: multiple
        definition.put("selectionMode", "multiple");
        return definition;
    }

    private List<Map<String, String>> buildColumns(final Map<String, Object> apiResponse, String authToken) {
        final List<Map<String, String>> columns = new ArrayList<>();
        // Add the actions column first to show it on the left
        columns.add(createActionsColumn());

        // Try to get the folder name from the data (for the service call)
        String folderName = extractFolderName(apiResponse);

        // Get the field order from the field detail service if possible
        List<String> fieldOrder = new ArrayList<>();
        if (folderName != null && !folderName.isEmpty()) {
            try {
                // Call CmodFolderService to get the field details (index fields)
                List<ReportChild> fieldDetails = cmodFolderService.getIndexFields(folderName, authToken, false);
                for (ReportChild field : fieldDetails) {
                    String name = field.getName();
                    if (name != null && !EXCLUDE_KEYS.contains(name)) {
                        fieldOrder.add(name);
                    }
                }
            } catch (Exception e) {
                logger.warn("Could not fetch field order from CmodFolderService: {}", e.getMessage());
            }
        } else if (apiResponse != null && apiResponse.containsKey("folderSearchCriteria")) {
            // Fallback to folderSearchCriteria in the response if available
            List<Map<String, Object>> folderFields = (List<Map<String, Object>>) apiResponse
                    .get("folderSearchCriteria");
            for (Map<String, Object> field : folderFields) {
                String name = (String) field.get("name");
                if (name != null && !EXCLUDE_KEYS.contains(name)) {
                    fieldOrder.add(name);
                }
            }
        }

        // Get the first document's keys
        List<String> docKeys = new ArrayList<>();
        extractDocumentData(apiResponse).stream()
                .findFirst()
                .ifPresent(firstDoc -> docKeys.addAll(firstDoc.keySet()));

        // Special handling: always put POSTING DATE as the first data column (after
        // actions)

        boolean postingDateAdded = false;
        for (Iterator<String> it = fieldOrder.iterator(); it.hasNext();) {
            String field = it.next();
            if ("POSTING DATE".equalsIgnoreCase(field) && docKeys.contains(field)) {
                columns.add(createColumn(field));
                postingDateAdded = true;
                it.remove();
                break;
            }
        }

        if (!postingDateAdded && docKeys.stream().anyMatch(k -> "POSTING DATE".equalsIgnoreCase(k))) {
            // If POSTING DATE is not in fieldOrder but present in docKeys
            columns.add(createColumn("POSTING DATE"));
        }

        // Add the rest of the columns in the order from fieldOrder, only if present in
        // docKeys
        for (String field : fieldOrder) {
            if (docKeys.contains(field) && !"POSTING DATE".equalsIgnoreCase(field)) {
                columns.add(createColumn(field));
            }
        }

        // Add any remaining docKeys not in fieldOrder (preserve their order)

        for (String key : docKeys) {
            if (!fieldOrder.contains(key) && !EXCLUDE_KEYS.contains(key) && !"POSTING DATE".equalsIgnoreCase(key)) {
                columns.add(createColumn(key));
            }
        }
        return columns;
    }

    List<Map<String, String>> buildColumnsold(final Map<String, Object> apiResponse) {
        final List<Map<String, String>> columns = new ArrayList<>();
        // Add the actions column first to show it on the left
        columns.add(createActionsColumn());
        extractDocumentData(apiResponse).stream()
                .findFirst()
                .ifPresent(firstDoc -> firstDoc.keySet().stream()
                        .filter(key -> !EXCLUDE_KEYS.contains(key))
                        .forEach(key -> columns.add(createColumn(key))));
        return columns;
    }

    private List<Map<String, Object>> extractDocumentData(final Map<String, Object> apiResponse) {
        return Optional.ofNullable(apiResponse)
                .map(res -> (Map<String, Object>) res.get("reportArchiveData"))
                .map(data -> (List<Map<String, Object>>) data.get("reportArchiveDocumentData"))
                .orElse(Collections.emptyList());
    }

    private String extractFolderName(final Map<String, Object> apiResponse) {
        return Optional.ofNullable(apiResponse)
                .map(res -> (Map<String, Object>) res.get("reportArchiveData"))
                .map(data -> (String) data.get("odFolder"))
                .orElse(null);
    }

    private Map<String, String> createColumn(final String key) {
        return Map.of(
                "id", key,
                "name", key,
                "type", "string",
                "sortable", "true",
                "filterable", "true",
                "url", "");
    }

    Map<String, String> createActionsColumn() {
        return Map.of(
                "id", ACTIONS_COLUMN_ID,
                "name", ACTIONS_COLUMN_NAME,
                "type", "actions");
    }

    private List<Map<String, Object>> processTableData(final Map<String, Object> apiResponse, final String authToken,
            final String folderName)
            throws IOException {
        final List<Map<String, Object>> data = extractDocumentData(apiResponse);

        // Add odFolder to each row of data
        for (final Map<String, Object> row : data) {
            if (folderName != null) {
                row.put("odFolder", folderName);
            }
        }

        return addActionButtons(data, authToken, folderName);
    }

    /**
     * Adds action buttons (download, view, update, delete) to each row of data
     * based on user permissions
     * 
     * @param data       The list of document data to be displayed in the table
     * @param authToken  Authentication token for fetching access rights
     * @param folderName The folder name for which to check access rights
     * @return Data with action buttons added in the actions column
     * @throws IOException If there is an error processing the JSON
     */
    List<Map<String, Object>> addActionButtons(final List<Map<String, Object>> data, final String authToken,
            final String folderName) throws IOException {
        final String jsonString = objectMapper.writeValueAsString(data);
        final JsonNode jsonArray = objectMapper.readTree(jsonString);

        // Fetch access rights for the specific folder
        final Map<String, Set<String>> accessRights = fetchAccessRights(authToken, folderName);

        // Determine if "DELETED" field is present in the first document (all rows will
        // match)
        boolean hasDeletedField = false;
        if (data != null && !data.isEmpty()) {
            Map<String, Object> firstRow = data.get(0);
            hasDeletedField = firstRow.containsKey("DELETED");
        }

        for (final JsonNode node : jsonArray) {
            final ObjectNode objNode = (ObjectNode) node;
            final ArrayNode actions = objectMapper.createArrayNode();

            // Always add download action
            final ObjectNode downloadAction = objectMapper.createObjectNode();
            downloadAction.put("action", "dynamicAction");
            downloadAction.put("actionIcon", "visibility");
            downloadAction.put("label", "View");
            downloadAction.put("apiUrl", "report-archive/tokens/view");
            downloadAction.put("actionType", "downloadpdf");
            final ObjectNode downloadAction2 = objectMapper.createObjectNode();
            downloadAction2.put("action", "dynamicAction");
            downloadAction2.put("actionIcon", "download");
            downloadAction2.put("label", "Download Original");
            downloadAction2.put("apiUrl", "report-archive/tokens/view");
            downloadAction2.put("actionType", "download");

            actions.add(downloadAction);
            actions.add(downloadAction2);

            // Add update and delete actions if user has access
            final String reportId = objNode.has("REPORT ID") ? objNode.get("REPORT ID").asText() : "";

            if (!reportId.isEmpty() && accessRights.containsKey(reportId)) {
                final Set<String> permissions = accessRights.get(reportId);

                // Add update button if user has update access
                if (permissions.contains("Update")) {
                    final ObjectNode updateAction = objectMapper.createObjectNode();
                    updateAction.put("action", "dynamicAction");
                    updateAction.put("actionIcon", "edit");
                    updateAction.put("label", "Edit");
                    updateAction.put("apiUrl", "report-archive/indexes/update");
                    updateAction.put("actionType", "edit");
                    actions.add(updateAction);
                }

                // Add delete button if user has delete access AND DELETED field is present
                if (permissions.contains("Delete") && hasDeletedField) {
                    final ObjectNode deleteAction = objectMapper.createObjectNode();
                    deleteAction.put("action", "dynamicAction");
                    deleteAction.put("actionIcon", "delete");
                    
                    // Check if the document is deleted and set appropriate label and API URL
                    String deleteLabel = "Delete";
                    String apiUrl = "report-archive/tokens/delete";
                    if (objNode.has("DELETED")) {
                        String deletedValue = objNode.get("DELETED").asText();
                        if ("y".equalsIgnoreCase(deletedValue)) {
                            deleteLabel = "Undelete";
                            apiUrl = "report-archive/tokens/undelete";
                        }
                    }
                    deleteAction.put("label", deleteLabel);
                    deleteAction.put("apiUrl", apiUrl);
                    deleteAction.put("actionType", "delete");
                    actions.add(deleteAction);
                }
            }

            objNode.set(ACTIONS_COLUMN_ID, actions);
        }

        return objectMapper.readValue(
                jsonArray.toString(),
                new TypeReference<List<Map<String, Object>>>() {
                });
    }

    /**
     * Fetches access rights from the access API
     * 
     * @param authToken  Authentication token for API call
     * @param folderName Folder name to check access for
     * @return Map of application IDs to their permitted actions
     */
    Map<String, Set<String>> fetchAccessRights(final String authToken, final String folderName) {
        final Map<String, Set<String>> applicationPermissions = new HashMap<>();

        try {
            if (folderName == null || folderName.isEmpty()) {
                logger.warn("Folder name is empty when checking access rights");
                return applicationPermissions;
            }

            // Create the request body with the folder name
            final Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("odFolder", folderName);

            // Call access API with auth token and request body
            logger.info("Calling access API for folder: {}", folderName);
            final ResponseEntity<Map> response = restClientUtil.postRequest(accessUrl, authToken, requestBody);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                final Map<String, Object> accessData = response.getBody();

                // Process authorized application groups
                if (accessData.containsKey("authorizedApplicationGroups")) {
                    final List<Map<String, Object>> groups = (List<Map<String, Object>>) accessData
                            .get("authorizedApplicationGroups");

                    for (final Map<String, Object> group : groups) {
                        if (group.containsKey("applications") && group.containsKey("accessLevel")) {
                            final List<String> applications = (List<String>) group.get("applications");
                            final String accessLevel = (String) group.get("accessLevel");

                            // Split access levels (e.g., "Add,Delete" becomes ["Add", "Delete"])
                            final Set<String> permissions = new HashSet<>(Arrays.asList(accessLevel.split(",")));

                            // Map each application to its permissions
                            for (final String appId : applications) {
                                applicationPermissions.put(appId, permissions);
                            }
                        }
                    }
                }
            } else {
                logger.warn("Access API call failed or returned empty response. Status: {}",
                        response.getStatusCode());
            }
        } catch (final Exception e) {
            logger.error("Error fetching access rights: {}", e.getMessage(), e);
        }

        return applicationPermissions;
    }

    /**
     * Handles error responses from the index listing service.
     * 
     * @param response The error response
     * @throws HVWException with appropriate error details
     */
    private void handleErrorResponse(final ResponseEntity<Map> response) {
        // Log the error and delegate to the centralized error handler
        logger.error("Error from index listing service: {} - {}", response.getStatusCode(), response.getBody());
        throw HVWException.parseErrorResponse(response, "CMOD");
    }

    private Map<String, Object> createServiceErrorResponse(final HVWException e) {
        return e.createErrorResponse();
    }

    private Map<String, Object> createGenericErrorResponse(final Exception e) {
        return HVWException.createErrorResponse(e);
    }

    private Map<String, Object> createErrorResponse(final ResponseEntity<Map> response) {
        // This method is kept for backward compatibility but delegates to the new error
        // handling
        try {
            handleErrorResponse(response);
            return null; // This line is never reached due to the exception being thrown
        } catch (final HVWException e) {
            return e.createErrorResponse();
        }
    }

    public void setApiUrl(String url) {
        this.apiUrl = url;
    }

    public void setAccessUrl(String url) {
        this.accessUrl = url;
    }
}