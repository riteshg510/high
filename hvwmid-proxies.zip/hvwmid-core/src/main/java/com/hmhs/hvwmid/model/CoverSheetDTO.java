package com.hmhs.hvwmid.model;

import com.hmhs.hvwmid.validations.ValidActiveType;
import jakarta.validation.constraints.Size;

public class CoverSheetDTO {

    
    private Integer application;

    
    @Size(max = 10, message = "Coversheet name cannot exceed 10 characters")
    private String name;

    @Size(max = 40, message = "Coversheet description cannot exceed 40 characters")
    private String description;

    @Size(max = 20, message = "Coversheet description cannot exceed 20 characters")
    private String sb1;
    @Size(max = 20, message = "Coversheet description cannot exceed 20 characters")
    private String eb1;
    @Size(max = 20, message = "Coversheet description cannot exceed 20 characters")
    private String eb2;
    @Size(max = 20, message = "Coversheet description cannot exceed 20 characters")
    private String eb3;

    @Size(max = 40, message = "Coversheet title cannot exceed 40 characters")
    private String title;
    @Size(max = 40, message = "Coversheet stitle1 cannot exceed 40 characters")
    private String stitle1;
    @Size(max = 40, message = "Coversheet stitle2 cannot exceed 40 characters")
    private String stitle2;

    @Size(max = 10, message = "Coversheet unit cannot exceed 10 characters")
    private String unit;
    @Size(max = 10, message = "rcode cannot exceed 10 characters")
    private String rcode;
    @Size(max = 10, message = "template cannot exceed 10 characters")
    private String template;
    @ValidActiveType
    private String active;
    private String environment;

    public CoverSheetDTO() {
    }

    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public String getName() {
        if (name == null) {
            return "";
        }
        return name.trim();
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        if (description == null) {
            return "";
        }
        return description.trim();
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSb1() {
        if (sb1 == null)
            return "";
        return sb1.trim();
    }

    public void setSb1(String sb1) {
        this.sb1 = sb1;
    }

    public String getEb1() {

        if (eb1 == null)
            return "";
        return eb1.trim();
    }

    public void setEb1(String eb1) {
        this.eb1 = eb1;
    }

    public String getEb2() {
        if (eb2 == null)
            return "";

        return eb2.trim();
    }

    public void setEb2(String eb2) {
        this.eb2 = eb2;
    }

    public String getEb3() {
        if (eb3 == null)
            return "";

        return eb3.trim();
    }

    public void setEb3(String eb3) {
        this.eb3 = eb3;
    }

    public String getTitle() {
        if (title == null) {
            return "";
        }
        return title.trim();
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStitle1() {
        if (stitle1 == null) {
            return "";
        }
        return stitle1.trim();
    }

    public void setStitle1(String stitle1) {
        this.stitle1 = stitle1;
    }

    public String getStitle2() {
        if (stitle2 == null)
            return "";
        return stitle2.trim();
    }

    public void setStitle2(String stitle2) {
        this.stitle2 = stitle2;
    }

    public String getUnit() {
        if (unit == null)
            return "";
        return unit.trim();
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getRcode() {
        if (rcode == null)
            return "";

        return rcode.trim();
    }

    public void setRcode(String rcode) {
        this.rcode = rcode;
    }

    public String getTemplate() {
        if (template == null)
            return "";
        return template.trim();
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public String getActive() {
        if (active == null) {
            return "";
        }
        return active.trim();
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getEnvironment() {
        if (environment == null)
            return "";
        return environment.trim();
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }
}
