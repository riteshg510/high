package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T117ImgCoverSheet;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetId;
import com.hmhs.hvwmid.model.CoverSheetDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface T117ImgCoverSheetRepository extends JpaRepository<T117ImgCoverSheet, T117ImgCoverSheetId> {
    @Query("SELECT cs FROM T117ImgCoverSheet cs WHERE cs.application = :applicationId AND cs.name = :name")
    Optional<T117ImgCoverSheet> findByApplicationAndName(@Param("applicationId") int applicationId, @Param("name") String name);


    @Query("SELECT cs FROM T117ImgCoverSheet cs WHERE cs.active = 'Y'")
    List<T117ImgCoverSheet> findAllByActive();


    List<T117ImgCoverSheet> findAllByApplication(int applicationId);

    Optional<CoverSheetDTO> findFirstByApplicationAndName(Integer application, String name);

    List<T117ImgCoverSheet> findAllByTemplate(String template);
}
