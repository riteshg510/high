package com.hmhs.hvwmid.service;


import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.exception.ResourceNotFoundException;
import com.hmhs.hvwmid.model.CoverSheetObjectDTO;
import com.hmhs.hvwmid.repository.T117ImgCoverObjectRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoversheetObjectServiceImpl implements CoversheetObjectService {

    final private T117ImgCoverObjectRepository templateRepository;


    public CoversheetObjectServiceImpl(T117ImgCoverObjectRepository templateRepository) {
        this.templateRepository = templateRepository;
    }

    @Override
    public List<T117ImgCoverObject> getTemplates(){
        return templateRepository.findAllTemplates();
    };

    @Override
    public String getTemplateData(String name) {
        return templateRepository.findByNameIgnoreCase(name)
                .map(template -> template.getObjData())
                .orElseThrow(() -> new ResourceNotFoundException("Template not found: " + name));
    }


    @Override
    public CoverSheetObjectDTO getTemplateByNameAndType(String name, String type) {
        return templateRepository.findByNameAndTypeIgnoreCase(name, type)
                .map(template -> new CoverSheetObjectDTO(template.getObjName().trim(), template.getObjType().trim(), template.getMimeType().trim(), template.getObjData()))
                .orElseThrow(() -> new ResourceNotFoundException("Template not found: " + name + " of type: " + type));
    }

}
