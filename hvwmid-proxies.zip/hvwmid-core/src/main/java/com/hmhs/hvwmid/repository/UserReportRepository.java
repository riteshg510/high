package com.hmhs.hvwmid.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.hmhs.hvwmid.entity.TblUserReport;

import java.util.List;
import java.util.Optional;

public interface UserReportRepository extends CrudRepository<TblUserReport, String> {

	@Query("SELECT COUNT(u) > 0 FROM TblUserReport u WHERE u.userId = :userId AND u.reportId = :reportId")
	boolean existsByUserIdAndReportName(@Param("userId") String userId, @Param("reportId") String reportId);

	@Query("SELECT u.reportId FROM TblUserReport u WHERE u.userId = :userId")
	List<String> findReportsByUserId(@Param("userId") String userId);

	public Optional<TblUserReport> findByUserIdAndReportId(String userId, String reportId);

	// void deleteByUserIdAndReportId(String userId, String reportId);
}
