package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.Hibernate;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class T222ImgExtendedparmId implements Serializable {
    private static final long serialVersionUID = -5070473884743728860L;
    @Size(max = 10)
    @NotNull
    @Column(name = "EPARM_ID", nullable = false, length = 10)
    private String eparmId;

    @Size(max = 50)
    @NotNull
    @Column(name = "EPARM_KEY", nullable = false, length = 50)
    private String eparmKey;

    @NotNull
    @Column(name = "ESEQUENCE_NO", nullable = false)
    private Integer esequenceNo;

    public String getEparmId() {
        return eparmId;
    }

    public void setEparmId(String eparmId) {
        this.eparmId = eparmId;
    }

    public String getEparmKey() {
        return eparmKey;
    }

    public void setEparmKey(String eparmKey) {
        this.eparmKey = eparmKey;
    }

    public Integer getEsequenceNo() {
        return esequenceNo;
    }

    public void setEsequenceNo(Integer esequenceNo) {
        this.esequenceNo = esequenceNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        T222ImgExtendedparmId entity = (T222ImgExtendedparmId) o;
        return Objects.equals(this.eparmKey, entity.eparmKey) &&
                Objects.equals(this.esequenceNo, entity.esequenceNo) &&
                Objects.equals(this.eparmId, entity.eparmId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eparmKey, esequenceNo, eparmId);
    }

}