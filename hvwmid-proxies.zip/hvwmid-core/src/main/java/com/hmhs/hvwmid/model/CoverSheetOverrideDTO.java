package com.hmhs.hvwmid.model;


public class CoverSheetOverrideDTO extends CoverSheetDTO {

    private Integer sequence;

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }


}
