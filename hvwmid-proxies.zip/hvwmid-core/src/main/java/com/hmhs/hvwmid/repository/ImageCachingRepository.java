
package com.hmhs.hvwmid.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class ImageCachingRepository {

    private final DataSource dataSource;

    @Autowired
    public ImageCachingRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Streams OBJECT_SEGMENT data for a given REQUEST_ID from DB2, in SEQUENCE_NO order,
     * directly to the provided OutputStream. Uses JDBC for safe and memory-efficient streaming.
     *
     * @param requestId The ID of the document to retrieve
     * @param outputStream The output stream to write the document to
     * @throws SQLException If a DB access error occurs
     * @throws IOException If an I/O error occurs while writing to the stream
     */
    public void streamSegmentsByRequestId(int requestId, OutputStream outputStream) throws SQLException, IOException {
        final String sql = """
                SELECT OBJECT_SEGMENT
                FROM T222_IMG_OBJECT
                WHERE REQUEST_ID = ?
                ORDER BY SEQUENCE_NO
                FOR FETCH ONLY WITH UR
                """;

        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, requestId);
            ps.setFetchSize(50); // Tune for DB2 performance

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    try (InputStream in = rs.getBinaryStream(1)) {
                        if (in != null) {
                            byte[] buffer = new byte[8192];
                            int bytesRead;
                            while ((bytesRead = in.read(buffer)) != -1) {
                                outputStream.write(buffer, 0, bytesRead);
                            }
                        }
                    }
                }
                outputStream.flush();
            }
        }
    }
}
