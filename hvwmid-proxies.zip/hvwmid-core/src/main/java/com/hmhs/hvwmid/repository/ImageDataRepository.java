package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.model.ImageDataModel;

/*
 * @author Ramanjaneyulu Manam on Oct 9, 2024
 */
@Repository
public interface ImageDataRepository extends JpaRepository<ImageData, Long>, JpaSpecificationExecutor<ImageData> {

	/**
	 * @param applId (lookupValue)
	 * @return List<String>
	 */
	@Query(value = "SELECT DISTINCT application_id FROM tbl_image_data WHERE application_id LIKE ?%", nativeQuery = true)
	List<String> getAllApplicationIdsSatrtsWith(String lookupValue);

	/**
	 * @param folderId (lookupValue)
	 * @return List<String>
	 */
	@Query(value = "SELECT DISTINCT folder_id FROM tbl_image_data WHERE folder_id LIKE ?%", nativeQuery = true)
	List<String> getAllFolderIdsSatrtsWith(String lookupValue);

	@Query(value = "SELECT * FROM tbl_image_data t WHERE t.application_id = :#{#inputData.applid} "
			+ "and t.folder_id = :#{#inputData.foldid} " + "and t.file_tab LIKE :#{#inputData.filetab}% "
			+ "and t.filed >= :#{#inputData.startdate} " + "and :#{#inputData.enddate} >= t.filed ", nativeQuery = true)
	List<ImageData> findImageDataByApplicationId(@Param("inputData") ImageDataModel inputData);

	/**
	 * @param formDescription
	 * @param pagingSort
	 * @return
	 */
	Page<ImageData> findByFormDescriptionContaining(String formDescription, Pageable pagingSort);
 
	/**
	 * @param id
	 * @return
	 */
	ImageData getImageDataById(long id);

}
