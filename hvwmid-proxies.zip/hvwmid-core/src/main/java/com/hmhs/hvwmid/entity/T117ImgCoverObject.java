package com.hmhs.hvwmid.entity;

import com.hmhs.hvwmid.validations.ValidActiveType;
import jakarta.persistence.*;
import jakarta.validation.constraints.Size;

import java.io.Serializable;

@Entity
@Table(name = "T117_IMG_COVEROBJECT")
public class T117ImgCoverObject implements Serializable {

    @Id
    @Column(name = "OBJNAME", nullable = false, length = 10)
    @Size(max = 10, message = "objName cannot exceed 10 characters")
    private String objName;

    @Column(name = "OBJTYPE", nullable = false, length = 10)
    @Size(max = 10, message = "objType cannot exceed 10 characters")
    private String objType;

    @Column(name = "MIMETYPE", length = 40)
    private String mimeType;

    @Lob
    @Column(name = "OBJDATA")
    private String objData;

    @Column(name = "ACTIVE", nullable = false, length = 1)
    @ValidActiveType
    private String active;

    public String getObjName() {
        return objName;
    }

    public void setObjName(String objName) {
        this.objName = objName;
    }

    public String getObjType() {
        return objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getMimeType() {
        if (mimeType == null) {
            return ""; // Default MIME type if not set
        }
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getObjData() {
        return objData;
    }

    public void setObjData(String objData) {
        this.objData = objData;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }
}
