package com.hmhs.hvwmid.service;

import java.io.DataInputStream;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import java.util.UUID;

import com.hmhs.hvwmid.entity.TblImgObjectId;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.hmhs.hvwmid.repository.GenericUDFDao;
import com.hmhs.hvwmid.entity.TblImgObject;
import com.hmhs.hvwmid.repository.TblImgObjectRepository;
import com.hmhs.hvwmid.utils.HVWUtils;

public class GenericUDFService {
    private final GenericUDFDao udfDao;
    private Map<String, String> parmDataMapByCmodbase;
    @Autowired
    private TblImgObjectRepository imgObjectRepository;
    @Autowired
    LoggerService loggerService;
    private String environment = "default";
    private static final Logger logger = LogManager.getLogger(GenericUDFService.class);

    public GenericUDFService(JdbcTemplate jdbcTemplate, String sequenceFunctionName) {
        this.udfDao = new GenericUDFDao(jdbcTemplate, sequenceFunctionName);
    }

    public String generateRequestId() {
        try {
            String sequenceNumber = udfDao.getSequenceNumber();
            return sequenceNumber;
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate request ID: " + e.getMessage(), e);
        }
    }

    public int generateRequestId(String env) {
        try {
            if ("Noservice".equalsIgnoreCase(environment)) {
                return UUID.randomUUID().hashCode() & 0x7fffffff;
            }
            String collectionName = HVWUtils.getCollection(env);
            logger.log(Level.INFO, "Collection name retrieved is: " + collectionName);
            int sequenceNumber = udfDao.getSequenceNumber(collectionName);
            logger.log(Level.INFO, "Sequence number from DB: " + sequenceNumber);
            return sequenceNumber;
        } catch (Exception e) {
            logger.log(Level.FATAL, "Exception in generateRequestId", e);
            throw new RuntimeException("Failed to generate request ID: " + e.getMessage(), e);
        }
    }

    public String getParmDataByKeyByCmodbase(String parmKey, String defaultParmKeyData) {
        if (parmDataMapByCmodbase != null && !parmDataMapByCmodbase.isEmpty()
                && parmDataMapByCmodbase.containsKey(parmKey)) {
            return parmDataMapByCmodbase.get(parmKey);
        }
        return defaultParmKeyData;
    }

    @Transactional
    public TblImgObject commitT222ImgToken(int requestId, int sequenceNumber, DataInputStream is) {
        TblImgObject imgObject = new TblImgObject();
        TblImgObjectId id = new TblImgObjectId();
        id.setRequestId(requestId);
        id.setSequenceNo(sequenceNumber);
        imgObject.setId(id);
        imgObject.setTimeCreate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
        imgObject.setObjectSegment(new byte[] { 0x1A, 0x2B });
        return imgObjectRepository.save(imgObject);
    }
}
