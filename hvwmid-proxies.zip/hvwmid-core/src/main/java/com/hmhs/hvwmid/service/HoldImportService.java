package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.enums.HoldHeaderNameAttr;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.repository.T222ImgRmaHoldRepository;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class HoldImportService {

    private final T222ImgRmaHoldRepository holdRepository;
    private final PolicyService policyService;
    private final HoldService holdService;

    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public HoldImportService(T222ImgRmaHoldRepository holdRepository, PolicyService policyService, HoldService holdService) {
        this.holdRepository = holdRepository;
        this.policyService = policyService;
        this.holdService = holdService;
    }

    public Map<String, List<String>> validateHoldSheet(InputStream inputStream) throws IOException {
        Map<String, List<String>> validationMap = new LinkedHashMap<>();

        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);

            // Validate header
            Row headerRow = sheet.getRow(0);
            HoldHeaderNameAttr[] headers = HoldHeaderNameAttr.values();
            for (int i = 0; i < headers.length; i++) {
                String expectedHeader = headers[i].getHeaderName();
                String actualHeader = headerRow.getCell(i) != null ? headerRow.getCell(i).getStringCellValue() : "";
                if (!expectedHeader.equals(actualHeader)) {
                    throw new IllegalArgumentException("Invalid header format at column " + i + ", expected: " + expectedHeader);
                }
            }

            // Validate rows
            for (int rowNo = 1; rowNo <= sheet.getLastRowNum(); rowNo++) {
                Row row = sheet.getRow(rowNo);
                if (row == null) continue;

                List<String> messages = new ArrayList<>();
                validationMap.put("Row " + rowNo, messages);

                List<String> mandatoryErrors = new ArrayList<>();
                List<String> sizeErrors = new ArrayList<>();

                validateMandatoryAndSize(row, mandatoryErrors, sizeErrors);

                if (mandatoryErrors.isEmpty() && sizeErrors.isEmpty()) {
                    validateHoldDates(row, messages);
                    validateHoldEditFlagAndProgram(row, messages);
                    validateDuplicateHoldCode(row, messages);
                    validateBpdIdAndHoldId(row, messages);
                }

                if (!mandatoryErrors.isEmpty()) {
                    messages.add("FAILED: Missing mandatory fields: " + mandatoryErrors);
                }
                if (!sizeErrors.isEmpty()) {
                    messages.add("FAILED: Field length exceeds limit: " + sizeErrors);
                }
            }
        }

        return validationMap;
    }

    private void validateBpdIdAndHoldId(Row row, List<String> messages) {
        String bpdIdStr = getCellValue(row.getCell(HoldHeaderNameAttr.BPD_ID.ordinal()));
        String holdId = getCellValue(row.getCell(HoldHeaderNameAttr.HOLD_ID.ordinal()));

        if (StringUtils.isBlank(bpdIdStr)) {
            messages.add("FAILED: " + HoldHeaderNameAttr.BPD_ID.getHeaderName() + " is missing");
            return;
        }

        if (StringUtils.isBlank(holdId)) {
            messages.add("FAILED: " + HoldHeaderNameAttr.HOLD_ID.getHeaderName() + " is missing");
            return;
        }

        Integer bpdId;
        try {
            bpdId = Integer.valueOf(bpdIdStr);
        } catch (NumberFormatException e) {
            messages.add("FAILED: " + HoldHeaderNameAttr.BPD_ID.getHeaderName() + " is not a valid number: " + bpdIdStr);
            return;
        }

        if (!policyService.getClientIds().contains(bpdId)) {
            messages.add("FAILED: " + HoldHeaderNameAttr.BPD_ID.getHeaderName() + " does not exist: " + bpdId);
            return;
        }

        boolean exists = holdRepository.existsByBpdIdAndHoldId(bpdId, holdId);
        if (exists) {
            messages.add("FAILED: Combination of " + HoldHeaderNameAttr.BPD_ID.getHeaderName() +
                         " " + bpdId + " and " + HoldHeaderNameAttr.HOLD_ID.getHeaderName() +
                         " '" + holdId + "' already exists");
        }
    }


    private void validateMandatoryAndSize(Row row, List<String> mandatoryErrors, List<String> sizeErrors) {
        HoldHeaderNameAttr[] headers = HoldHeaderNameAttr.values();

        for (int i = 0; i < headers.length; i++) {
            HoldHeaderNameAttr header = headers[i];
            String cellValue = getCellValue(row.getCell(i));

            if (header.isMandatory() && (cellValue == null || cellValue.isEmpty())) {
                mandatoryErrors.add(header.getHeaderName());
            }

            if (header.getFieldSize() > 0 && cellValue != null && cellValue.length() > header.getFieldSize()) {
                sizeErrors.add(header.getHeaderName() + " (" + cellValue.length() + " > " + header.getFieldSize() + ")");
            }
        }
    }

    private void validateHoldDates(Row row, List<String> messages) {
        String dateBeginStr = getCellValue(row.getCell(HoldHeaderNameAttr.HOLD_DATE_BEGIN.ordinal()));
        String dateEndStr = getCellValue(row.getCell(HoldHeaderNameAttr.HOLD_DATE_END.ordinal()));

        try {
            if (StringUtils.isNotBlank(dateBeginStr)) LocalDate.parse(dateBeginStr, dateFormatter);
        } catch (Exception e) {
            messages.add(HoldHeaderNameAttr.HOLD_DATE_BEGIN.getHeaderName() + " invalid date format, expected yyyy-MM-dd");
        }

        try {
            if (StringUtils.isNotBlank(dateEndStr)) LocalDate.parse(dateEndStr, dateFormatter);
        } catch (Exception e) {
            messages.add(HoldHeaderNameAttr.HOLD_DATE_END.getHeaderName() + " invalid date format, expected yyyy-MM-dd");
        }
    }

    private void validateHoldEditFlagAndProgram(Row row, List<String> messages) {
        String editFlag = getCellValue(row.getCell(HoldHeaderNameAttr.HOLD_EDIT_FLAG.ordinal()));
        String pgmName = getCellValue(row.getCell(HoldHeaderNameAttr.HOLD_EDIT_PGMNAME.ordinal()));

        if (!"Y".equals(editFlag) && !"N".equals(editFlag)) {
            messages.add(HoldHeaderNameAttr.HOLD_EDIT_FLAG.getHeaderName() + " should be Y/N");
        }
        if ("Y".equals(editFlag) && !StringUtils.isNotBlank(pgmName)) {
            messages.add(HoldHeaderNameAttr.HOLD_EDIT_PGMNAME.getHeaderName() + " should be populated when Edit Flag is Y");
        }
    }

    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            default -> "";
        };
    }

    @Transactional
    public void importHoldExcel(InputStream inputStream, String loginUser) {
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            HoldHeaderNameAttr[] headers = HoldHeaderNameAttr.values();

            for (int rowNo = 1; rowNo <= sheet.getLastRowNum(); rowNo++) {
                Row row = sheet.getRow(rowNo);
                if (row == null) continue;

                Map<String, String> otherFields = new LinkedHashMap<>();
                for (HoldHeaderNameAttr header : headers) {
                    otherFields.put(header.getBeanAttribute(), getCellValue(row.getCell(header.ordinal())));
                }

                String holdCodeStr = otherFields.get("holdCode");
                if (StringUtils.isBlank(holdCodeStr)) {
                    holdService.createHold(otherFields, loginUser);
                } else {
                    Integer holdCode = Integer.parseInt(holdCodeStr);
                    boolean exists = holdRepository.existsByHoldCode(holdCode);
                    if (exists) {
                        holdService.updateHold(otherFields, loginUser);
                    } else {
                        holdService.createHold(otherFields, loginUser);
                    }
                }
            }
        } catch (IOException e) {
            throw new HVWException("Error reading Excel file", e);
        }
    }


    private void validateDuplicateHoldCode(Row row, List<String> messages) {
        String holdCodeStr = getCellValue(row.getCell(HoldHeaderNameAttr.HOLD_CODE.ordinal()));
        if (StringUtils.isNotBlank(holdCodeStr)) {
            try {
                int holdCode = Integer.parseInt(holdCodeStr);
                boolean exists = holdRepository.findByHoldCode(holdCode).isPresent();
                if (exists) {
                    messages.add("Duplicate HOLD_CODE: " + holdCode);
                }
            } catch (NumberFormatException e) {
                messages.add("HOLD_CODE is not a valid integer: " + holdCodeStr);
            }
        }
    }
}
