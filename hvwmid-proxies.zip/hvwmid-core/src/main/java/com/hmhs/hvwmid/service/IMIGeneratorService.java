package com.hmhs.hvwmid.service;

import static com.hmhs.hvwmid.utils.HVWUtils.hasText;
import static com.hmhs.hvwmid.utils.HVWUtils.concatenateStrings;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.exception.ValidateRequest;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.model.IMIGeneatorData;
import com.hmhs.hvwmid.model.IMIGeneratorOutput;
import com.hmhs.hvwmid.model.IMIGeneratorSelectFileInput;
import com.hmhs.hvwmid.model.IMISearchData;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.InterchangeFile;

@Service
public class IMIGeneratorService {

	private static final Logger logger = LogManager.getLogger(IMIGeneratorService.class);

	@Value("${api.imi.imiGeneratorScheduler}")
	private String imiGeneratorSchedulerURL;

	private final ObjectMapper objectMapper = new ObjectMapper();
	private final DataFormatter objDefaultFormat = new DataFormatter();
	private FormulaEvaluator formulaEvaluator = null;
	private String uniqueTs = HVWUtils.createMfTimeStamp();
	private String filePriority = "99";
	private int noOfIMIDocs = 1;
	private String outputDirectory = "";
	private String naicCode = "";
	private Map<String, String> imiSegmentMap = null;
	private Map<String, String> imiDatePatternMap = null;
	private boolean renameInfoFlag = false;
	private static final String PARMDATA_REGEX_FOR_COMMENTS = "--+[\\\\^\\$\\.\\|\\?\\*\\+\\(\\)\\[\\{\\!\\@\\#\\%\\&\\-\\_\\=\\]\\}\\`\\~\\;\\:\\\"\\'\\,\\<\\>\\/\\s\\w\\d]*";
	private static final String PARMID_IMISEG = "IMISEG";
    private static final String PARMID_IMIGENDT = "IMIGENDT";
    private static final String FAILED = "FAILED";
    private static final String SUCCESS = "SUCCESS";
    private static final String WARNING = "WARNING";
    private static final String INFORMATION = "INFORMATION";
    private static final String NUMERIC = "NUMERIC";
    
	private static final String MESSAGEIMIGENERATOR = "MessageIMIGenerator";
	private static final String MESSAGEIMIGENERATORRESULTS = "MessageIMIGeneratorResults";
	private static final String MISSINGREQUIREDFIELD = "Missing required field ";
	private static final String INPUTSPREADSHEET = "inputSpreadsheet";
	private static final String DOCCOUNTIMI = "docCountIMI";
	private static final String NAICINPUT = "naicInput";
	private static final String OUTPUTDIR = "outputDir";
	private static final String FILEPRIORITYCONSTANT = "filePriority";
	private static final String FILERENAMESTR = "File rename from =>";
	private static final String LOGTOSTR = "<= to =>";
	private static final String LOGSUCCESSFUL = "<= is successful";
	private static final String LOGNOTSUCCESSFUL = "<= is NOT successful";
	private static final String LOGDEFAULTTO = "<= defaulted to =>";
	private static final String LOGDEFAULTTO_1 = " defaulted to ";
	private static final String LOGSEGMENT = "Segment:";
	private static final String LOGSEGVALUE = "<= Segment value =>";
	private static final String LOGSEGNAME = "Segment Name =>";
	private CellStyle failureStyle = null;
	private CellStyle warningStyle = null;
	private CellStyle successStyle = null;
	private CellStyle infoStyle = null;
    
	@Autowired
	private T222APRMRepository aprmRepository;

	// IMI Generator mapping constants
	public enum IMIGenMapConstants {
		U("Unique"), M("Mapped"), C("Constant");

		private final String mapDesc;

		IMIGenMapConstants(String mapDesc) {
			this.mapDesc = mapDesc;
		}

		public String getMapDesc() {
			return mapDesc;
		}
	}

	// IMI Generator input fields map
	public enum IMIGenFieldMap {
		FID("fidTxt", "fidTxtMap", "na"), DPK("dpkTxt", "dpkTxtMap", "dpkTxtConstant"),
		IMG("imgTxtHidden", "imgTxtMap", "na"), BOD("bodTxt", "bodTxtMap", "na");

		private final String valField;
		private final String mapField;
		private final String constantField;

		IMIGenFieldMap(String valField, String mapField, String constantField) {
			this.valField = valField;
			this.mapField = mapField;
			this.constantField = constantField;
		}

		public String getValField() {
			return valField;
		}

		public String getMapField() {
			return mapField;
		}

		public String getConstantField() {
			return constantField;
		}
	}

	/**
	 * Initializes the IMIGenerator on load
	 * 
	 * @param authToken authentication token for user validation
	 * @return map containing NAIC access information and configuration
	 */
	public IMIGeneatorData imiGeneratorOnLoad(String authToken) throws Exception {
		IMIGeneatorData imiGeneatorData = new IMIGeneatorData();
		List<String> ldapGroups = HVWUtils.getUserGroups(authToken);
		if (ldapGroups != null && !ldapGroups.isEmpty()) {
			Map<String, String> naicMap = HVWUtils.buildNAICMap(ldapGroups);
			if (!naicMap.isEmpty()) {
				imiGeneatorData.setNaicMap(naicMap);
				
				Map<String, String> intakeDirMap = getStringParmData("IMIDIRIN");
				imiGeneatorData.setImiDIRIntake(intakeDirMap);
				imiGeneatorData.setSchedulerUILink(imiGeneratorSchedulerURL);
			}else {				
				IMIGeneatorData.BaseMessage baseMessage = new IMIGeneatorData.BaseMessage();
				baseMessage.setReturnCodeDescription(
						"User does not have access to the IMI groups. Request access to the IMI groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->IMI Groups");
				imiGeneatorData.setBaseMessage(baseMessage);
				imiGeneatorData.setNaicMap(naicMap);;
				return imiGeneatorData;
			}

		}
		return imiGeneatorData;
	}

	/**
	 * Validates and processes the selected Excel file
	 * 
	 * @param fileData map containing file information
	 * @return map containing validation results and file headers
	 */
	public Map<String, Object> selectFile(Map<String, String> fileData) {
		Map<String, Object> response = new HashMap<>();
		String inputFileName = fileData.get("inputFileTxt");
		String outputDirName = fileData.get("outputDirTxt");

		// Validate input parameters
		if (inputFileName == null || inputFileName.trim().isEmpty()) {
			response.put("error", "Please enter the input Spreadsheet Name.");
			return response;
		}

		if (outputDirName == null || outputDirName.trim().isEmpty()) {
			response.put("error", "Please enter the output directory Name.");
			return response;
		}

		// Validate file existence and permissions
		File inputFile = new File(inputFileName);
		if (!inputFile.exists()) {
			response.put("error", "Input Spreadsheet doesn't exist " + inputFileName);
			return response;
		}

		// Validate file extension
		String ext = inputFileName.substring(inputFileName.lastIndexOf('.') + 1).toLowerCase();
		if (!"xls".equals(ext) && !"xlsx".equals(ext)) {
			response.put("error", "Input Spreadsheet is not a xls or xlsx file " + inputFileName);
			return response;
		}

		try {
			Map<String, String> rowHeaderMap = readSpreadsheetHeaders(inputFile);
			if (rowHeaderMap.isEmpty()) {
				response.put("error", "Row headers not populated.");
				return response;
			}

			response.put("rowHeaderMap", rowHeaderMap);

			// Get segments from PARM table
			Map<String, String> imiSegParmMap = getStringParmData(PARMID_IMISEG);
			if (imiSegParmMap.isEmpty()) {
				response.put("error", "Unable to load Segments from the PARM table.");
				return response;
			}

			response.put("imiSegMap", imiSegParmMap);
			response.put("inputSpreadsheet", inputFileName);
			response.put("docCountIMI", fileData.get("documentCountTxt"));
			response.put("naicInput", fileData.get("naicCodeTxt"));
			response.put("outputDir", outputDirName);
			response.put("filePriority", fileData.get("filePriorityTxt"));

		} catch (Exception e) {
			logger.error("Error processing spreadsheet: {}", e.getMessage(), e);
			response.put("error", "Error processing spreadsheet: " + e.getMessage());
		}

		return response;
	}

	/**
	 * Creates IMI files from the processed Excel data
	 * 
	 * @param fileData map containing file processing parameters
	 * @return list of IMIGeneratorOutput objects with processing results
	 */
	public List<IMIGeneratorOutput> createIMIFile(Map<String, Object> fileData) {
		List<IMIGeneratorOutput> outputList = new ArrayList<>();

		// Validate required parameters
		String[] requiredParams = { "inputSpreadsheet", "docCountIMI", "naicInput", "outputDir", "filePriority" };
		for (String param : requiredParams) {
			if (!fileData.containsKey(param)) {
				IMIGeneratorOutput output = new IMIGeneratorOutput();
				output.setStatus("ERROR");
				output.setMessages("Missing required parameter: " + param);
				outputList.add(output);
				return outputList;
			}
		}

		String inputFileName = (String) fileData.get("inputSpreadsheet");
		String docCount = (String) fileData.get("docCountIMI");
		naicCode = (String) fileData.get("naicInput");
		outputDirectory = (String) fileData.get("outputDir");
		String filePriorityStr = (String) fileData.get("filePriority");
		uniqueTs = HVWUtils.createMfTimeStamp();

		try {
			// Get segments from PARM table
			imiSegmentMap = getStringParmData(PARMID_IMISEG);
			imiDatePatternMap = getStringParmData(PARMID_IMIGENDT);

			if (imiSegmentMap.isEmpty()) {
				IMIGeneratorOutput output = new IMIGeneratorOutput();
				output.setStatus("ERROR");
				output.setMessages("Unable to load Segments from the PARM table.");
				outputList.add(output);
				return outputList;
			}

			if (imiDatePatternMap.isEmpty()) {
				IMIGeneratorOutput output = new IMIGeneratorOutput();
				output.setStatus("ERROR");
				output.setMessages("Unable to load Date patterns from the PARM table.");
				outputList.add(output);
				return outputList;
			}

			File inputFile = new File(inputFileName);
			if (!inputFile.exists()) {
				IMIGeneratorOutput output = new IMIGeneratorOutput();
				output.setStatus("ERROR");
				output.setMessages("Input file does not exist: " + inputFileName);
				outputList.add(output);
				return outputList;
			}

			try (FileInputStream fis = new FileInputStream(inputFile);
					Workbook workbook = WorkbookFactory.create(fis)) {

				Sheet sheet = workbook.getSheetAt(0);
				if (sheet == null) {
					throw new IOException("Sheet1 is empty in the Spreadsheet");
				}

				// Process each row in the spreadsheet
				int lastRowNum = sheet.getLastRowNum();
				for (int rowNum = 1; rowNum <= lastRowNum; rowNum++) {
					Row row = sheet.getRow(rowNum);
					if (row == null)
						continue;

					IMIGeneratorOutput output = new IMIGeneratorOutput();
					output.setRowNo(String.valueOf(rowNum + 1));

					try {
						// Generate IMI file for the current row
						String imiFileName = generateIMIFile(row, naicCode, filePriorityStr, uniqueTs, outputDirectory);
						output.setStatus("SUCCESS");
						output.setImiFileName(imiFileName);
						output.setMessages("IMI file generated successfully");
					} catch (Exception e) {
						logger.error("Failed to generate IMI file for row {}: {}", rowNum, e.getMessage(), e);
						output.setStatus("ERROR");
						output.setMessages("Failed to generate IMI file: " + e.getMessage());
					}

					outputList.add(output);
				}
			}

		} catch (Exception e) {
			logger.error("Error generating IMI file: {}", e.getMessage(), e);
			IMIGeneratorOutput output = new IMIGeneratorOutput();
			output.setStatus("ERROR");
			output.setMessages("Error generating IMI file: " + e.getMessage());
			outputList.add(output);
		}

		return outputList;
	}

	/**
	 * Generates an IMI file for a specific row
	 * 
	 * @param row             Excel row data
	 * @param naicCode        NAIC code for the file
	 * @param filePriority    priority of the file
	 * @param uniqueTs        unique timestamp
	 * @param outputDirectory output directory path
	 * @return generated IMI filename
	 * @throws Exception if generation fails
	 */
	private String generateIMIFile(Row row, String naicCode, String filePriority, String uniqueTs,
			String outputDirectory) throws Exception {
		// Generate IMI file name
		String imiFileName = String.format("%s.%s.%s.HIGHVIEWGENERATED.%s.imi", filePriority, naicCode, uniqueTs,
				uniqueTs);

		// Create IMI file in output directory
		File tempFile = new File(outputDirectory, imiFileName + ".temp");
		File finalFile = new File(outputDirectory, imiFileName);

		try (InterchangeFile imiFile = new InterchangeFile(tempFile.getAbsolutePath())) {
			// Write mandatory segments
			imiFile.writeSegment("HDR", naicCode);
			imiFile.writeSegment("FID", uniqueTs);

			// Get image file path from row
			Cell imgCell = row.getCell(3); // Assuming IMG column is at index 3
			String imgPath = getCellValue(imgCell);
			if (imgPath == null || imgPath.trim().isEmpty()) {
				throw new IOException("Image path is required");
			}

			// Write image related segments
			imiFile.writeSegment("IMG", imgPath);
			imiFile.writeSegment("DPK", imgPath.toUpperCase());

			// Generate unique document ID for BOD/EOD
			String docId = uniqueTs + "_IMI";
			imiFile.writeSegment("BOD", docId);
			imiFile.writeSegment("EOD", docId);

			// Write trailer
			imiFile.writeSegment("TRL", String.format("%06d", 1));
		}

		// Rename temp file to final file
		if (!tempFile.renameTo(finalFile)) {
			throw new IOException("Failed to rename temporary file to " + imiFileName);
		}

		return imiFileName;
	}

	/**
	 * Extracts cell value from Excel cell
	 * 
	 * @param cell Excel cell
	 * @return string value of the cell
	 */
	private String getCellValue(Cell cell) {
		if (cell == null)
			return null;

//        CellType ct= cell.getCellType();
//        switch (cell.getCellTypeEnum()) {
//            case STRING:
//                return cell.getStringCellValue();
//            case NUMERIC:
//                if (DateUtil.isCellDateFormatted(cell)) {
//                    return cell.getDateCellValue().toString();
//                }
//                return String.valueOf(cell.getNumericCellValue());
//            case FORMULA:
//                if (formulaEvaluator != null) {
//                    CellValue cellValue = formulaEvaluator.evaluate(cell);
//                    return cellValue.getStringValue();
//                }
//                return "";
//            default:
//                return "";
//        }
		return "";
	}

	/**
	 * Reads spreadsheet headers from the first row
	 * 
	 * @param inputFile input Excel file
	 * @return map of column index to header name
	 * @throws IOException if reading fails
	 */
	private Map<String, String> readSpreadsheetHeaders(File inputFile) throws Exception {
		Map<String, String> rowHeaderMap = new LinkedHashMap<>();

		try (FileInputStream fis = new FileInputStream(inputFile); Workbook workbook = WorkbookFactory.create(fis)) {

			Sheet sheet = workbook.getSheetAt(0);
			if (sheet == null) {
				throw new IOException("Sheet1 is empty in the Spreadsheet");
			}

			Row headerRow = sheet.getRow(0);
			if (headerRow == null) {
				throw new IOException("Row1 is empty in the Spreadsheet");
			}

			int lastRowNum = sheet.getLastRowNum();
			if (lastRowNum == 0) {
				throw new IOException("No Rows in the Spreadsheet to create the IMI files");
			}
			if (lastRowNum > 75000) {
				throw new IOException("There cannot be more than 75000 Rows in the Spreadsheet");
			}

			for (Cell cell : headerRow) {
				String value = cell.getStringCellValue();
				if (value != null && !value.trim().isEmpty()) {
					rowHeaderMap.put(String.valueOf(cell.getColumnIndex()), value);
				}
			}
		}

		return rowHeaderMap;
	}

	/**
	 * Retrieves parameter data for IMI generation
	 * 
	 * @param parmId      parameter identifier
	 * @param environment current environment
	 * @return map of parameter data
	 */
	public Map<String, String> getStringParmData(String parmid) throws Exception {
		Map<String, String> parmDataMap = new HashMap<>();
		try {
			List<T222APRM> t222aprmsList = aprmRepository.findByParmId(parmid);
			for (T222APRM entityRow : t222aprmsList) {
				parmDataMap.put(entityRow.getParmKey().trim(),
						entityRow.getParmData().replaceAll(PARMDATA_REGEX_FOR_COMMENTS, "").trim());
			}
		} catch (Exception e) {
			throw new Exception("Exception in getting Parm Data from DB2 : " + e.getMessage());
		}

		return parmDataMap;
	}
	
	/**
	 * This method will get all the IMI groups and put it in the request
	 * 
	 * @param session
	 * @param request
	 */
//	public void imiGeneratorSelectFile(IMIGeneratorSelectFileInput generatorSelectFileInput) {
//		// Validating the request parameters
//		StringBuilder errorMsgBuilder = new StringBuilder();
//		ValidateRequest validateRequest = new ValidateRequest();
//		if (!validateRequest.validateIMIGenSelectFile(request, errorMsgBuilder)) {
//			request.setAttribute(MESSAGEIMIGENERATOR, "Validation error occurred in IMI Generator. " + errorMsgBuilder.toString());
//			logger.error("Validation error occurred in IMI Generator - imiGeneratorSelectFile:" + errorMsgBuilder.toString());
//			return;
//		}
//
//		String inputFileName = request.getParameter("inputFileTxt");
//		String outputDirName = request.getParameter("outputDirTxt");
//		if (inputFileName == null || inputFileName.trim().length() == 0) {
//			request.setAttribute(MESSAGEIMIGENERATOR, "Please enter the input Spreadsheet Name.");
//			return;
//		}
//		if (outputDirName == null || outputDirName.trim().length() == 0) {
//			request.setAttribute(MESSAGEIMIGENERATOR, "Please enter the output directory Name.");
//			return;
//		}
//		// Check if the input spreadsheet exists
//		File inputFile = new File(inputFileName);
//		if (!inputFile.exists()) {
//			request.setAttribute(MESSAGEIMIGENERATOR, concatenateStrings("Input Spreadsheet doesn't exist ", inputFileName, "."));
//			logger.error(concatenateStrings("Input spreadsheet doesn't exist =>", inputFileName, "<="));
//			return;
//		}
//		// Check if the server has access to the input directory
//		String parentDirStr = inputFile.getParent();
//		File parentDir = new File(parentDirStr);
//		if (!parentDir.canRead() || !parentDir.canWrite()) {
//			request.setAttribute(MESSAGEIMIGENERATOR,
//					concatenateStrings("Do not have permission to Read/Write to the input directory ", parentDirStr, "."));
//			logger.error(concatenateStrings("Do not have permission to Read/Write to the input directory =>", parentDirStr, "<="));
//			return;
//		}
//
//		// Check if the server has read/write access to the output directories
//		File outputDir = new File(outputDirName);
//		if (!outputDir.exists()) {
//			request.setAttribute(MESSAGEIMIGENERATOR, concatenateStrings("Output Dir doesn't exist ", outputDirName, "."));
//			logger.error(concatenateStrings("Output Dir doesn't exist =>", outputDirName, "<="));
//			return;
//		} else if (!outputDir.canRead() || !outputDir.canWrite()) {
//			request.setAttribute(MESSAGEIMIGENERATOR,
//					concatenateStrings("Do not have permission to Read/Write to the output directory ", outputDirName, "."));
//			logger.error(concatenateStrings("Do not have permission to Read/Write to the output directory =>", outputDirName, "<="));
//			return;
//		}
//
//		// Verify if the spreadsheet is a xls or xlsx file
//		int extPos = inputFileName.lastIndexOf('.') + 1;
//		String ext = inputFileName.substring(extPos);
//		if (!"xls".equalsIgnoreCase(ext) && !"xlsx".equalsIgnoreCase(ext)) {
//			request.setAttribute(MESSAGEIMIGENERATOR, concatenateStrings("Input Spreadsheet is not a xls or xlsx file ", inputFileName, "."));
//			logger.error(concatenateStrings("Input spreadsheet is not a xls or xlsx file =>", inputFileName, "<="));
//			return;
//		}
//
//		// Reading the data from the spreadsheet
//		Map<String, String> rowHeaderMap = new LinkedHashMap<>();
//		try (InputStream inputStream = new FileInputStream(inputFile); Workbook workBook = WorkbookFactory.create(inputStream)) {
//			Sheet sheet1 = workBook.getSheetAt(0);
//			if (sheet1 != null) {
//				Row row = sheet1.getRow(0);
//				if (row != null) {
//					int lastRowNo = sheet1.getLastRowNum();
//					if (lastRowNo == 0) {
//						request.setAttribute(MESSAGEIMIGENERATOR,
//								concatenateStrings("No Rows in the Spreadsheet ", inputFileName, " to create the IMI files."));
//						logger.error(concatenateStrings("No Rows in the spreadsheet =>", inputFileName, "<= to create the IMI files."));
//						return;
//					} else if (lastRowNo > 75000) {
//						request.setAttribute(MESSAGEIMIGENERATOR, "There cannot be more than 75000 Rows in the Spreadsheet " + inputFileName + ".");
//						logger.error("There cannot be more than 75000 Rows in the spreadsheet =>" + inputFileName + ".");
//						return;
//					}
//					Iterator<Cell> cellItr = row.cellIterator();
//					while (cellItr.hasNext()) {
//						Cell cellValue = cellItr.next();
//						if (cellValue != null) {
//							String value = cellValue.getStringCellValue();
//							if (hasText(value)) {
//								rowHeaderMap.put(String.valueOf(cellValue.getColumnIndex()), value);
//							} else {
//								logger.error(concatenateStrings("Cell =>" + cellValue.getColumnIndex() + "<= has a blank header =>", inputFileName, "<="));
//							}
//						} else {
//							logger.error(concatenateStrings("Cell is empty =>", inputFileName, "<="));
//						}
//					}
//				} else {
//					request.setAttribute(MESSAGEIMIGENERATOR, concatenateStrings("Row1 is empty in the Spreadsheet ", inputFileName, "."));
//					logger.error(concatenateStrings("Row1 is empty in the spreadsheet =>", inputFileName, "<="));
//					return;
//				}
//			} else {
//				request.setAttribute(MESSAGEIMIGENERATOR, concatenateStrings("Sheet1 is empty in the Spreadsheet ", inputFileName, "."));
//				logger.error(concatenateStrings("Sheet1 is empty in the spreadsheet =>", inputFileName, "<="));
//				return;
//			}
//
//		} catch (Exception e) {
//			request.setAttribute(MESSAGEIMIGENERATOR, concatenateStrings("Error occurred while reading the spreadsheet. ", e.getMessage()));
//			logger.error(concatenateStrings("Exception reading the data from the spreadsheet =>", inputFileName, "<="), e);
//			return;
//		}
//		if (rowHeaderMap.size() == 0) {
//			request.setAttribute(MESSAGEIMIGENERATOR, "Row headers not populated.");
//			logger.error(concatenateStrings("Row headers not populated =>", inputFileName, "<="));
//			return;
//		}
//		request.setAttribute("rowHeaderMap", rowHeaderMap);
//
//		// Get all the segments from the PARM table
//		HVWUtils commonUtils = new HVWUtils();
//		Map<String, String> imiSegParmMap = getStringParmData(PARMID_IMISEG);
//		if (imiSegParmMap.size() == 0) {
//			request.setAttribute(MESSAGEIMIGENERATOR, "Unable to load Segments from the PARM table.");
//			logger.error("Unable to load Segments from T222APRM table PARM_ID =>IMISEG<=");
//			return;
//		}
//		request.setAttribute("imiSegMap", imiSegParmMap);
//
//		String naicCode = request.getParameter("naicCodeTxt");
//		// Carrying all the request attributes to the Input Segments frames
//		request.setAttribute(INPUTSPREADSHEET, inputFileName);
//		request.setAttribute(DOCCOUNTIMI, request.getParameter("documentCountTxt"));
//		request.setAttribute(NAICINPUT, naicCode);
//		request.setAttribute(OUTPUTDIR, outputDirName);
//		request.setAttribute(FILEPRIORITYCONSTANT, request.getParameter("filePriorityTxt"));
//		logger.error(concatenateStrings("Input Spreadsheet =>", inputFileName, "<= selected for IMI Generation. NAIC=>", naicCode,
//				"<= Output Directory =>", outputDirName, "<="));
//	}

}
