package com.hmhs.hvwmid.model;

import java.util.Date;
import java.util.Set;

/**
 * DTO representing application access information for CMOD security access.
 * Contains details about user's access to specific CMOD applications.
 * ImageODApplication in old code
 */
public class CMODApplicationAccessInfo {

    private String applicationName;
    private boolean userAccess;
    private String vpieApplication;
    private String vpieRoleDescription;
    private String acf2String;
    private boolean clientEmployeeSecurity;
    private Set<String> applicationVersions;
    private Date modifiedDate;
    // Constructors
    public CMODApplicationAccessInfo() {
    }

    public CMODApplicationAccessInfo(String applicationName, Set<String> applicationVersions, 
                                   boolean userAccess, boolean clientEmployeeSecurity) {
        this.applicationName = applicationName;
        this.applicationVersions = applicationVersions;
        this.userAccess = userAccess;
        this.clientEmployeeSecurity = clientEmployeeSecurity;
    }

    // Getters and Setters
    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public Set<String> getApplicationVersions() {
        return applicationVersions;
    }

    public void setApplicationVersions(Set<String> applicationVersions) {
        this.applicationVersions = applicationVersions;
    }

    public boolean isUserAccess() {
        return userAccess;
    }

    public void setUserAccess(boolean userAccess) {
        this.userAccess = userAccess;
    }

    public boolean isClientEmployeeSecurity() {
        return clientEmployeeSecurity;
    }

    public void setClientEmployeeSecurity(boolean clientEmployeeSecurity) {
        this.clientEmployeeSecurity = clientEmployeeSecurity;
    }

    public String getVpieApplication() {
        return vpieApplication;
    }

    public void setVpieApplication(String vpieApplication) {
        this.vpieApplication = vpieApplication;
    }

    public String getVpieRoleDescription() {
        return vpieRoleDescription;
    }

    public void setVpieRoleDescription(String vpieRoleDescription) {
        this.vpieRoleDescription = vpieRoleDescription;
    }

    public String getAcf2String() {
        return acf2String;
    }

    public void setAcf2String(String acf2String) {
        this.acf2String = acf2String;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}