package com.hmhs.hvwmid.service;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.T222APRMRepository;

@Service
public class LoggerService {

	private static final Logger logger = LogManager.getLogger(LoggerService.class);

	@Autowired
	HvwStatusService hvwStatusService;

	@Value("${app.environment:default}")
	private String environment;

	@Value("${db-logging-level}")
	private String dbLoggingLevel;

	public static final int DEBUG = 2;
	public static final int INFO = 1;
	public static final int ERROR = 0;

	private int environmentLogLevel;

	@Autowired
	private T222APRMRepository t222aprmRepository;

	public String getLogLevelForUser(String userId) {
		// Fetch all log level records for HVWLOG in one query
		List<T222APRM> logRecords = t222aprmRepository.findByParmId("HVWLOG");
		logger.debug("Fetched {} log records for HVWLOG", logRecords.size());

		// Try to find a record for the specific user (case-insensitive)
		for (T222APRM rec : logRecords) {
			if (rec.getParmKey() != null && rec.getParmKey().equalsIgnoreCase(userId)) {
				String value = rec.getParmData();
				logger.debug("Found log level '{}' for user '{}'", value, userId);
				if (isValidLogLevel(value)) {
					return value;
				} else {
					logger.warn("Invalid log level '{}' for user '{}', defaulting to INFO", value, userId);
					return "INFO";
				}
			}
		}
		// Try to find a record for DEFAULT
		for (T222APRM rec : logRecords) {
			if ("DEFAULT".equalsIgnoreCase(rec.getParmKey())) {
				String value = rec.getParmData();
				logger.debug("Found DEFAULT log level '{}'", value);
				if (isValidLogLevel(value)) {
					return value;
				} else {
					logger.warn("Invalid DEFAULT log level '{}', defaulting to INFO", value);
					return "INFO";
				}
			}
		}
		// Fallback to INFO
		logger.debug("No user or DEFAULT log level found, using INFO");
		return "INFO";
	}

	private boolean isValidLogLevel(String value) {
		return "INFO".equalsIgnoreCase(value) || "DEBUG".equalsIgnoreCase(value) || "ERROR".equalsIgnoreCase(value);
	}

	public int getLogLevelInt(String level) {
		int levelIntVal = 1;
		switch (level) {
			case "DEBUG":
				levelIntVal = DEBUG;
				break;

			case "INFO":
				levelIntVal = INFO;
				break;

			case "ERROR":
				levelIntVal = ERROR;
				break;
		}
		return levelIntVal;
	}

	public void log(String logLevel, int requestId, int imgRequestId, int codRequestId, String userId, String function,
			String originalURL, String statusCode, String desc) {
		// Check if we're in Noservice mode - if so, just log to console and don't call
		// hvwStatusService
		if ("Noservice".equalsIgnoreCase(environment)) {
			// Simply log to console in Noservice mode
			switch (logLevel.toUpperCase()) {
				case "DEBUG":
					logger.debug("[NOSERVICE] {} - {} - {}: {}", userId, function, statusCode, desc);
					break;
				case "INFO":
					logger.info("[NOSERVICE] {} - {} - {}: {}", userId, function, statusCode, desc);
					break;
				case "ERROR":
					logger.error("[NOSERVICE] {} - {} - {}: {}", userId, function, statusCode, desc);
					break;
				default:
					logger.info("[NOSERVICE] {} - {} - {}: {}", userId, function, statusCode, desc);
			}
			return;
		}

		// Normal operation for non-Noservice environments
		this.environmentLogLevel = getLogLevelInt(getLogLevelForUser(userId)); // Getting the env log level from db
		int currentLogLevel = getLogLevelInt(logLevel.toUpperCase());
		// Check ThreadContext for COD_REQUEST_ID and use it if present
		String codReqIdFromThread = ThreadContext.get("COD_REQUEST_ID");
		if (codReqIdFromThread != null) {
			try {
				codRequestId = Integer.parseInt(codReqIdFromThread);
			} catch (Exception e) {
				// ignore, fallback to passed codRequestId
			}
		}
		if (environmentLogLevel >= currentLogLevel)
			hvwStatusService.populateT222HvwStatus(requestId, imgRequestId, codRequestId, userId, function, originalURL,
					statusCode, desc);
	}
}
