package com.hmhs.hvwmid.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.T222CodCmodExtAGP;
import com.hmhs.hvwmid.entity.T222CodCmodExtAGPId;

/**
 * Repository for CMOD Security Access data operations.
 * Handles database queries for CMOD security permissions and access control.
 */
@Repository
public interface CMODSecurityRepository extends JpaRepository<T222CodCmodExtAGP, T222CodCmodExtAGPId> {

    Logger log = LoggerFactory.getLogger(CMODSecurityRepository.class);

    /**
     * Retrieves user's CMOD client codes from T222_COD_CMOD_EXT_AGP table.
     * Maps users to CMOD application groups they have access to.
     * 
     * @param userId User ID to lookup
     * @return List of client codes/groups user has access to
     */
    @Query("SELECT DISTINCT c.cmodApplicationGroup FROM T222CodCmodExtAGP c " +
            "WHERE c.cmodUserGroupName = :userId AND c.cmodUserGroupIndicator = 'U'")
    List<String> getUserClientCodes(@Param("userId") String userId);

    /**
     * Gets user's AGQR (Application Group Query Role) mappings as entities.
     * 
     * @param userId User ID to lookup
     * @return List of T222CodCmodExtAGP entities for the user
     */
    @Query("SELECT c FROM T222CodCmodExtAGP c " +
            "WHERE c.cmodUserGroupName = :userId AND c.cmodUserGroupIndicator = 'U'")
    List<T222CodCmodExtAGP> getUserAGQRMappingsRaw(@Param("userId") String userId);

    /**
     * Gets user's AGQR mappings as a map.
     * Converts raw query results to a structured map format.
     * Parses CMOD_USER_QR field to extract application lists using pattern:
     * SUBSTR(queryRestriction, "(", ")") then SUBSTR(applicationsStr, "'", "'")
     * 
     * @param userId User ID to lookup
     * @return Map of application group to query role list
     */
    default Map<String, List<String>> getUserAGQRMappings(String userId) {
        Map<String, List<String>> agqrMap = new HashMap<>();

        try {
            List<T222CodCmodExtAGP> entities = getUserAGQRMappingsRaw(userId.toUpperCase());

            for (T222CodCmodExtAGP entity : entities) {
                String applicationGroup = entity.getCmodApplicationGroup();
                String cmodUserQR = entity.getCmodUserQR();

                if (StringUtils.isNotBlank(applicationGroup) && StringUtils.isNotBlank(cmodUserQR)) {
                    List<String> applications = parseApplicationsFromQR(cmodUserQR);

                    if (!applications.isEmpty()) {
                        agqrMap.put(applicationGroup, applications);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error processing AGQR mappings for user: {}", userId, e);
            return new HashMap<>();
        }

        return agqrMap;
    }

    /**
     * Parses application list from CMOD_USER_QR field.
     * Pattern: Extract content between parentheses, then extract quoted application
     * names.
     * Example: "APPLICATION IN ('APP1-CLNT-V1','APP2-CLNT-V2')" -> ["APP1-CLNT-V1",
     * "APP2-CLNT-V2"]
     * 
     * @param cmodUserQR The query restriction string
     * @return List of application names
     */
    private static List<String> parseApplicationsFromQR(String cmodUserQR) {
        List<String> applications = new ArrayList<>();

        if (StringUtils.isBlank(cmodUserQR)) {
            return applications;
        }

        try {
            // Extract content between parentheses
            int startParen = cmodUserQR.indexOf('(');
            int endParen = cmodUserQR.lastIndexOf(')');

            if (startParen != -1 && endParen != -1 && endParen > startParen) {
                String applicationsStr = cmodUserQR.substring(startParen + 1, endParen);

                // Split by comma and extract quoted strings
                String[] appTokens = applicationsStr.split(",");
                for (String token : appTokens) {
                    String trimmed = token.trim();

                    // Remove quotes if present
                    if (trimmed.startsWith("'") && trimmed.endsWith("'")) {
                        String appName = trimmed.substring(1, trimmed.length() - 1);
                        if (StringUtils.isNotBlank(appName)) {
                            applications.add(appName);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // If parsing fails, return empty list
        }

        return applications;
    }

    /**
     * Query to get security exit view data for client employee security.
     */
    @Query(value = "SELECT CMOD_APPLICATION, BPD_ID, CMOD_INDEX " +
            "FROM V_COD_REPORT_SECURITY_EXIT " +
            "WHERE CMOD_APPLICATION IS NOT NULL AND CMOD_APPLICATION != ''", nativeQuery = true)
    List<Object[]> getSecurityExitData();

}