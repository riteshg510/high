package com.hmhs.hvwmid.validator;

import com.hmhs.hvwmid.model.GenerateIMIRequest;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Validator for GenerateIMIRequest
 */
@Component
public class GenerateIMIRequestValidator {

    // Required segment names for IMI files
    private static final Set<String> REQUIRED_SEGMENTS = Set.of("FID", "DPK", "IMG", "BOD", "EOD");

    /**
     * Validates the GenerateIMIRequest
     * @param request the request to validate
     * @return ValidationResult containing validation status and errors
     */
    public ValidationResult validate(GenerateIMIRequest request) {
        ValidationResult result = new ValidationResult();
        
        if (request == null) {
            result.addError("Request cannot be null");
            return result;
        }

        // Validate Excel ID
        validateExcelId(request, result);
        
        // Validate file ID mappings
        validateFileIdMappings(request, result);
        
        // Validate segment mappings
        validateSegmentMappings(request, result);
        
        // Validate output configuration
        validateOutputConfig(request, result);

        return result;
    }

    private void validateExcelId(GenerateIMIRequest request, ValidationResult result) {
        if (request.getExcelId() == null) {
            result.addError("excelId is required and cannot be null");
        } else if (request.getExcelId() <= 0) {
            result.addError("excelId must be a positive integer");
        }
    }

    private void validateFileIdMappings(GenerateIMIRequest request, ValidationResult result) {
        List<GenerateIMIRequest.FileIdMapping> mappings = request.getFileIdMappings();
        
        if (mappings == null || mappings.isEmpty()) {
            result.addError("fileIdMappings must contain at least one entry");
            return;
        }

        for (int i = 0; i < mappings.size(); i++) {
            GenerateIMIRequest.FileIdMapping mapping = mappings.get(i);
            String prefix = "fileIdMappings[" + i + "]";
            
            if (mapping == null) {
                result.addError(prefix + " cannot be null");
                continue;
            }
            
            if (mapping.getFileId() == null) {
                result.addError(prefix + ".fileId is required and cannot be null");
            } else if (mapping.getFileId() <= 0) {
                result.addError(prefix + ".fileId must be a positive integer");
            }
            
            if (mapping.getExcelFileName() == null || mapping.getExcelFileName().trim().isEmpty()) {
                result.addError(prefix + ".excelFileName is required and cannot be empty");
            }
        }
    }

    private void validateSegmentMappings(GenerateIMIRequest request, ValidationResult result) {
        List<GenerateIMIRequest.SegmentMapping> mappings = request.getMappings();
        
        if (mappings == null) {
            mappings = new ArrayList<>(); // Treat null as empty list for validation
        }

        // Create a map of segment names for easier validation
        Map<String, GenerateIMIRequest.SegmentMapping> segmentMap = new HashMap<>();
        
        // Validate each mapping and build the map
        for (int i = 0; i < mappings.size(); i++) {
            GenerateIMIRequest.SegmentMapping mapping = mappings.get(i);
            String prefix = "mappings[" + i + "]";
            
            if (mapping == null) {
                result.addError(prefix + " cannot be null");
                continue;
            }
            
            // Validate segment name
            if (mapping.getSegmentName() == null || mapping.getSegmentName().trim().isEmpty()) {
                result.addError(prefix + ".segmentName is required and cannot be empty");
                continue;
            }
            
            String segmentName = mapping.getSegmentName().trim().toUpperCase();
            
            // Validate segment type
            if (mapping.getType() == null || mapping.getType().trim().isEmpty()) {
                result.addError(prefix + ".type is required and cannot be empty");
            } else {
                String type = mapping.getType().trim().toUpperCase();
                if (!type.equals("U") && !type.equals("M") && !type.equals("C")) {
                    result.addError(prefix + ".type must be one of: U (Unique), M (Mapped), C (Constant)");
                } else {
                    // Validate value based on type
                    validateSegmentValue(mapping, type, prefix, result);
                }
            }
            
            segmentMap.put(segmentName, mapping);
        }

        // Check for required segments
        for (String requiredSegment : REQUIRED_SEGMENTS) {
            if (!segmentMap.containsKey(requiredSegment)) {
                result.addError("Required segment '" + requiredSegment + "' is missing from mappings");
            }
        }

        // Check for duplicate segment names
        Set<String> seenSegments = new HashSet<>();
        for (GenerateIMIRequest.SegmentMapping mapping : mappings) {
            if (mapping != null && mapping.getSegmentName() != null) {
                String segmentName = mapping.getSegmentName().trim().toUpperCase();
                if (!seenSegments.add(segmentName)) {
                    result.addError("Duplicate segment name '" + segmentName + "' found in mappings");
                }
            }
        }
    }

    private void validateSegmentValue(GenerateIMIRequest.SegmentMapping mapping, String type, String prefix, ValidationResult result) {
        String value = mapping.getValue();
        
        switch (type) {
            case "M": // Mapped - value should be column header name
            case "C": // Constant - value should be constant value
                if (value == null || value.trim().isEmpty()) {
                    result.addError(prefix + ".value is required and cannot be empty when type is '" + type + "'");
                }
                break;
            case "U": // Unique - value should be empty or null (will be auto-generated)
                // No validation needed for unique type
                break;
        }
    }

    private void validateOutputConfig(GenerateIMIRequest request, ValidationResult result) {
        GenerateIMIRequest.OutputConfig config = request.getOutputConfig();
        
        if (config != null) {
            if (config.getDocumentsPerIMI() != null) {
                if (config.getDocumentsPerIMI() < 1 || config.getDocumentsPerIMI() > 2000) {
                    result.addError("outputConfig.documentsPerIMI must be between 1 and 2000");
                }
            }
            
            if (config.getFilePriority() != null) {
                if (config.getFilePriority() < 1 || config.getFilePriority() > 100) {
                    result.addError("outputConfig.filePriority must be between 1 and 100");
                }
            }
        }
    }

    /**
     * Result of validation containing status and error messages
     */
    public static class ValidationResult {
        private final List<String> errors = new ArrayList<>();

        public void addError(String error) {
            errors.add(error);
        }

        public boolean isValid() {
            return errors.isEmpty();
        }

        public List<String> getErrors() {
            return new ArrayList<>(errors);
        }

        public String getErrorMessage() {
            if (errors.isEmpty()) {
                return null;
            }
            return String.join("; ", errors);
        }

        /**
         * Creates a JSON-like error response map
         */
        public Map<String, Object> toErrorResponse() {
            Map<String, Object> errorResponse = new HashMap<>();
            Map<String, Object> error = new HashMap<>();
            
            error.put("code", 400);
            error.put("message", "Validation failed");
            error.put("details", errors);
            
            errorResponse.put("error", error);
            return errorResponse;
        }
    }
}