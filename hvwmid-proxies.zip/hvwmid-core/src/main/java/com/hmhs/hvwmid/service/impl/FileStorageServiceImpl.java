package com.hmhs.hvwmid.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.hmhs.hvwmid.entity.TblImgObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.hmhs.hvwmid.entity.TblImgObject;
import com.hmhs.hvwmid.entity.TblImgToken;
import com.hmhs.hvwmid.model.FileStorageResult;
import com.hmhs.hvwmid.repository.ImgTokenRepository;
import com.hmhs.hvwmid.repository.TblImgObjectRepository;
import com.hmhs.hvwmid.service.FileStorageService;
import com.hmhs.hvwmid.service.GenericUDFService;

@Service
public class FileStorageServiceImpl implements FileStorageService {

    private static final Logger logger = LoggerFactory.getLogger(FileStorageServiceImpl.class);
    private static final int CHUNK_SIZE = 31691; // Maximum size for OBJECT_SEGMENT column
    private static final int BUFFER_SIZE = 8192;

    private final TblImgObjectRepository imgObjectRepository;
    private final ImgTokenRepository imgTokenRepository;
    private final GenericUDFService seqGen;

    public FileStorageServiceImpl(TblImgObjectRepository imgObjectRepository,
                                ImgTokenRepository imgTokenRepository,
                                  org.springframework.jdbc.core.JdbcTemplate jdbcTemplate) {
        this.imgObjectRepository = imgObjectRepository;
        this.imgTokenRepository = imgTokenRepository;
        this.seqGen = new GenericUDFService(jdbcTemplate, "DB2222054A_UDF");;
    }

    @Override
    @Transactional
    public FileStorageResult storeFile(MultipartFile file, String userId, String documentType) throws Exception {
        logger.info("Storing file {} for user {}", file.getOriginalFilename(), userId);

        // Generate unique REQUEST_ID
        Integer requestId = Integer.valueOf(seqGen.generateRequestId());
        
        try {
            // Create token entry first
            TblImgToken token = new TblImgToken();
            token.setRequestId(requestId);
            token.setUserId(userId.toUpperCase());
            token.setTimeCreate(LocalDateTime.now());
            token.setDocumentType(documentType.toUpperCase());
            token.setDocumentPages(0); // Will be updated for Excel files
            token.setDocumentToken(generateDocumentToken());
            token.setSecurityToken("");
            token.setDocumentSize((int) file.getSize());
            token.setDocCnvStatus("UPLOADED");
            
            imgTokenRepository.save(token);
            logger.debug("Created IMG_TOKEN entry for REQUEST_ID: {}", requestId);

            // Store file in chunks
            List<TblImgObject> chunks = new ArrayList<>();
            int sequenceNo = 0;
            
            try (InputStream inputStream = file.getInputStream()) {
                byte[] buffer = new byte[CHUNK_SIZE];
                int bytesRead;
                
                while ((bytesRead = readChunk(inputStream, buffer)) > 0) {
                    TblImgObject chunk = new TblImgObject();

                    TblImgObjectId id = new TblImgObjectId();
                    id.setRequestId(requestId);
                    id.setSequenceNo(sequenceNo++);
                    chunk.setId(id);
                    chunk.setTimeCreate(new Timestamp(System.currentTimeMillis()));
                    
                    // Create exact size array for the chunk
                    byte[] chunkData = new byte[bytesRead];
                    System.arraycopy(buffer, 0, chunkData, 0, bytesRead);
                    chunk.setObjectSegment(chunkData);
                    
                    chunks.add(chunk);
                }
            }
            
            // Save all chunks
            imgObjectRepository.saveAll(chunks);
            logger.info("Stored {} chunks for REQUEST_ID: {}", chunks.size(), requestId);
            
            // Create result
            FileStorageResult result = new FileStorageResult();
            result.setRequestId(requestId);
            result.setFileName(file.getOriginalFilename());
            result.setDocumentType(documentType);
            result.setDocumentSize((int) file.getSize());
            result.setDocumentPages(0);
            result.setUserId(userId);
            result.setTimeCreated(token.getTimeCreate());
            result.setStatus("UPLOADED");
            
            return result;
            
        } catch (Exception e) {
            logger.error("Error storing file for REQUEST_ID: {}", requestId, e);
            throw new Exception("Failed to store file: " + e.getMessage(), e);
        }
    }

    @Override
    public FileStorageResult getFileMetadata(Integer requestId) {

        Optional<TblImgToken> test = imgTokenRepository.findById(requestId);
        if(test.isPresent()) {
            FileStorageResult result = new FileStorageResult();
            result.setRequestId(test.get().getRequestId());
            result.setFileName(""); // Not stored in token, would need separate metadata
            result.setDocumentType(test.get().getDocumentType().trim());
            result.setDocumentSize(test.get().getDocumentSize());
            result.setDocumentPages(test.get().getDocumentPages());
            result.setUserId(test.get().getUserId().trim());
            result.setTimeCreated(test.get().getTimeCreate());
            result.setStatus(test.get().getDocCnvStatus().trim());
            return result;
        } else {
            return null;
        }

    }

    @Override
    public boolean validateAccess(Integer requestId, String userId) {
        return imgTokenRepository.findById(requestId)
            .map(token -> token.getUserId().trim().equalsIgnoreCase(userId))
            .orElse(false);
    }

    @Override
    @Transactional
    public void deleteFile(Integer requestId) throws Exception {
        try {
            // Delete token (cascades to objects due to relationship)
            if (imgTokenRepository.existsById(requestId)) {
                imgTokenRepository.deleteById(requestId);
                logger.info("Deleted file with REQUEST_ID: {}", requestId);
            }
        } catch (Exception e) {
            logger.error("Error deleting file with REQUEST_ID: {}", requestId, e);
            throw new Exception("Failed to delete file: " + e.getMessage(), e);
        }
    }

    /**
     * Reads a chunk from the input stream
     */
    private int readChunk(InputStream inputStream, byte[] buffer) throws IOException {
        int totalRead = 0;
        int bytesRead;
        
        while (totalRead < buffer.length) {
            bytesRead = inputStream.read(buffer, totalRead, buffer.length - totalRead);
            if (bytesRead == -1) {
                break;
            }
            totalRead += bytesRead;
        }
        
        return totalRead;
    }

    /**
     * Generates a unique document token
     */
    private String generateDocumentToken() {
        return UUID.randomUUID().toString().replace("-", "").toUpperCase();
    }
    
    @Override
    @Transactional
    public FileStorageResult storeFileContent(byte[] content, String fileName, String userId, String documentType) throws Exception {
        logger.info("Storing file content {} for user {}", fileName, userId);

        // Generate unique REQUEST_ID
        Integer requestId = Integer.valueOf(seqGen.generateRequestId());
        
        try {
            // Create token entry first
            TblImgToken token = new TblImgToken();
            token.setRequestId(requestId);
            token.setUserId(userId.toUpperCase());
            token.setTimeCreate(LocalDateTime.now());
            token.setDocumentType(documentType.toUpperCase());
            token.setDocumentPages(0); // Will be updated for Excel files
            token.setDocumentToken(generateDocumentToken());
            token.setSecurityToken("");
            token.setDocumentSize(content.length);
            token.setDocCnvStatus("UPLOADED");
            
            imgTokenRepository.save(token);
            logger.debug("Created IMG_TOKEN entry for REQUEST_ID: {}", requestId);

            // Store content in chunks
            List<TblImgObject> chunks = new ArrayList<>();
            int sequenceNo = 0;
            int offset = 0;
            
            while (offset < content.length) {
                int chunkSize = Math.min(CHUNK_SIZE, content.length - offset);
                
                TblImgObject chunk = new TblImgObject();
                TblImgObjectId id = new TblImgObjectId();
                id.setRequestId(requestId);
                id.setSequenceNo(sequenceNo++);
                chunk.setId(id);
                chunk.setTimeCreate(new Timestamp(System.currentTimeMillis()));
                
                // Create chunk data
                byte[] chunkData = new byte[chunkSize];
                System.arraycopy(content, offset, chunkData, 0, chunkSize);
                chunk.setObjectSegment(chunkData);
                
                chunks.add(chunk);
                offset += chunkSize;
            }
            
            // Save all chunks
            imgObjectRepository.saveAll(chunks);
            logger.info("Stored {} chunks for REQUEST_ID: {}", chunks.size(), requestId);
            
            // Create result
            FileStorageResult result = new FileStorageResult();
            result.setRequestId(requestId);
            result.setFileName(fileName);
            result.setDocumentType(documentType);
            result.setDocumentSize(content.length);
            result.setDocumentPages(0);
            result.setUserId(userId);
            result.setTimeCreated(token.getTimeCreate());
            result.setStatus("UPLOADED");
            
            return result;
            
        } catch (Exception e) {
            logger.error("Error storing file content for REQUEST_ID: {}", requestId, e);
            throw new Exception("Failed to store file content: " + e.getMessage(), e);
        }
    }
}