package com.hmhs.hvwmid.model;

import java.io.Serializable;
import java.util.List;

/**
 * Response model for Generate IMI Files endpoint
 */
public class GenerateIMIResponse implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private List<GeneratedFile> generatedFiles;
    private Integer outputExcelId;
    private Summary summary;
    private String message;
    
    /**
     * Information about each generated IMI file
     */
    public static class GeneratedFile implements Serializable {
        private static final long serialVersionUID = 1L;
        
        private Integer imiFileId;      // REQUEST_ID of generated IMI file
        private String imiFileName;     // Generated IMI filename
        private Integer documentCount;  // Number of documents in this IMI
        private String status;          // SUCCESS, FAILED, etc.
        
        public Integer getImiFileId() {
            return imiFileId;
        }
        
        public void setImiFileId(Integer imiFileId) {
            this.imiFileId = imiFileId;
        }
        
        public String getImiFileName() {
            return imiFileName;
        }
        
        public void setImiFileName(String imiFileName) {
            this.imiFileName = imiFileName;
        }
        
        public Integer getDocumentCount() {
            return documentCount;
        }
        
        public void setDocumentCount(Integer documentCount) {
            this.documentCount = documentCount;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
    }
    
    /**
     * Summary of the generation process
     */
    public static class Summary implements Serializable {
        private static final long serialVersionUID = 1L;
        
        private Integer totalRows;
        private Integer successful;
        private Integer failed;
        private Integer warnings;
        
        public Integer getTotalRows() {
            return totalRows;
        }
        
        public void setTotalRows(Integer totalRows) {
            this.totalRows = totalRows;
        }
        
        public Integer getSuccessful() {
            return successful;
        }
        
        public void setSuccessful(Integer successful) {
            this.successful = successful;
        }
        
        public Integer getFailed() {
            return failed;
        }
        
        public void setFailed(Integer failed) {
            this.failed = failed;
        }
        
        public Integer getWarnings() {
            return warnings;
        }
        
        public void setWarnings(Integer warnings) {
            this.warnings = warnings;
        }
    }
    
    // Getters and Setters
    public List<GeneratedFile> getGeneratedFiles() {
        return generatedFiles;
    }
    
    public void setGeneratedFiles(List<GeneratedFile> generatedFiles) {
        this.generatedFiles = generatedFiles;
    }
    
    public Integer getOutputExcelId() {
        return outputExcelId;
    }
    
    public void setOutputExcelId(Integer outputExcelId) {
        this.outputExcelId = outputExcelId;
    }
    
    public Summary getSummary() {
        return summary;
    }
    
    public void setSummary(Summary summary) {
        this.summary = summary;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
}