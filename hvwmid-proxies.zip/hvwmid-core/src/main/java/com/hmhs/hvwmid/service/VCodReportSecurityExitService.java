package com.hmhs.hvwmid.service;

import java.sql.SQLException;
import java.util.Map;

/**
 * Service interface for VCodReportSecurityExit operations
 */
public interface VCodReportSecurityExitService {

    /**
     * Gets CMOD index and BPD ID mapping by CMOD application
     * @return Map with CMOD application as key and nested map containing Index and BpdId
     * @throws SQLException if database operation fails
     */
    Map<String, Map<String, String>> getCmodIndexBpdIdByCmodApplication() throws SQLException;
}