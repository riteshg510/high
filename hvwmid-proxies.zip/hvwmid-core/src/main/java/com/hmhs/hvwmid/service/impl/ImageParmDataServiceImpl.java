package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.service.ImageParmDataService;
import com.hmhs.hvwmid.service.VCodReportSecurityExitService;
import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualHashBidiMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Spring Boot implementation of ImageParmDataService.
 * Manages parameter data from T222APRM table with caching and Spring lifecycle management.
 */
@Service
public class ImageParmDataServiceImpl implements ImageParmDataService {

    private static final Logger logger = LoggerFactory.getLogger(ImageParmDataServiceImpl.class);

    private final T222APRMRepository t222APRMRepository;
    private final VCodReportSecurityExitService vCodReportSecurityExitService;

    // Parameter data maps - using ConcurrentHashMap for thread safety
    private final Map<String, Map<String, String>> parmDataMap = new ConcurrentHashMap<>();
    private final Map<String, String> parmDataMapByHvwbase = new ConcurrentHashMap<>();
    private final Map<String, String> parmDataMapByCODBase = new ConcurrentHashMap<>();
    private final Map<String, String> parmDataMapByCmodbase = new ConcurrentHashMap<>();
    private final Map<String, Map<String, String>> parmDataMapBySecuredClntEmpSec = new ConcurrentHashMap<>();
    private final Map<String, Map<String, String>> parmDataMapByODCMODFieldMap = new ConcurrentHashMap<>();
    private final BidiMap<String, String> parmDataMapByCmodfld = new DualHashBidiMap<>();

    @Autowired
    public ImageParmDataServiceImpl(T222APRMRepository t222APRMRepository, VCodReportSecurityExitService vCodReportSecurityExitService) {
        this.t222APRMRepository = t222APRMRepository;
        this.vCodReportSecurityExitService = vCodReportSecurityExitService;
    }

    @PostConstruct
    public void initializeParmData() {
        logger.info("Initializing parameter data from T222APRM table");
        refreshParmData();
    }

    @Override
    @CacheEvict(value = {"parmData", "parmDataMap", "hvwbaseData", "cmodbaseData", "codbaseData"}, allEntries = true)
    public void refreshParmData() {
        logger.debug("Refreshing parameter data from database");
        
        try {
            // Load basic parameter maps
            loadBasicParmMaps();
            
            // Load CMOD field mappings
            loadCmodFieldMappings();
            
            // Load secured client employee security data
            loadSecuredClientEmpSecData();
            
            // Load additional parameter maps
            loadAdditionalParmMaps();
            
            logger.info("Parameter data refresh completed successfully");
        } catch (Exception e) {
            logger.error("Error refreshing parameter data", e);
            throw new RuntimeException("Failed to refresh parameter data", e);
        }
    }

    private void loadBasicParmMaps() {
        // Load HVWBASE parameters
        parmDataMapByHvwbase.clear();
        parmDataMapByHvwbase.putAll(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE));
        
        // Load CODBASE parameters
        parmDataMapByCODBase.clear();
        parmDataMapByCODBase.putAll(t222APRMRepository.getParmDataAsMap(HVWConstants.CODBASE));
        
        // Load CMBASE parameters
        parmDataMapByCmodbase.clear();
        parmDataMapByCmodbase.putAll(t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE));
        
        logger.debug("Loaded basic parameter maps - HVWBASE: {}, CODBASE: {}, CMBASE: {}", 
                parmDataMapByHvwbase.size(), parmDataMapByCODBase.size(), parmDataMapByCmodbase.size());
    }

    private void loadCmodFieldMappings() {
        // Load CMFLDMAP parameters for bidirectional mapping
        parmDataMapByCmodfld.clear();
        Map<String, String> fieldMappings = t222APRMRepository.getParmDataAsMap(HVWConstants.CMFLDMAP);
        fieldMappings.forEach(parmDataMapByCmodfld::put);
        
        logger.debug("Loaded CMOD field mappings: {}", parmDataMapByCmodfld.size());
    }

    private void loadSecuredClientEmpSecData() {

        try {
            Map<String, Map<String, String>> tempData = vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication();
            parmDataMapBySecuredClntEmpSec.clear();
            parmDataMapBySecuredClntEmpSec.putAll(tempData);
            logger.debug("Loaded secured client employee security data");
        } catch (Exception e) {
            logger.error("Error loading Secured Client Emp Sec Data", e);
        }

    }

    private void loadAdditionalParmMaps() {
        // Load additional parameter maps
        List<String> parmIds = Arrays.asList(
            HVWConstants.CMUSEREX,
            HVWConstants.CMSARA,
            HVWConstants.CMAPPCD,
            HVWConstants.CMIDXRM,
            HVWConstants.HVWLOGIN,
            HVWConstants.RMPOLTYP,
            HVWConstants.HVWMPCFG,
            HVWConstants.CODTSENV,
            HVWConstants.HVWCOMM,
            HVWConstants.HVWOAUTH,
            "CMADDIDA",
            HVWConstants.PARMID_HVW_IMI,
            HVWConstants.PARMID_HVW_IMICOM
        );

        Map<String, Map<String, String>> additionalParmMaps = t222APRMRepository.getParmDataMapsGroupedByParmId(parmIds);
        
        parmDataMap.clear();
        Map<String, Map<String, String>> trimmedParmMaps = new HashMap<>();
        for (Map.Entry<String, Map<String, String>> entry : additionalParmMaps.entrySet()) {
            String trimmedParmId = entry.getKey() != null ? entry.getKey().strip() : null;
            Map<String, String> valueMap = entry.getValue();
            Map<String, String> trimmedValueMap = new HashMap<>();
            if (valueMap != null) {
                for (Map.Entry<String, String> valueEntry : valueMap.entrySet()) {
                    String trimmedKey = valueEntry.getKey() != null ? valueEntry.getKey().strip() : null;
                    trimmedValueMap.put(trimmedKey, valueEntry.getValue());
                }
            }
            trimmedParmMaps.put(trimmedParmId, trimmedValueMap);
        }
        parmDataMap.putAll(trimmedParmMaps);
        
        logger.debug("Loaded additional parameter maps for {} parm IDs", parmIds.size());
    }

    @Override
    @Cacheable(value = "parmData", key = "#parmId + '_' + #key")
    public String getParmData(String parmId, String key) {
        if (parmId == null || key == null) {
            return null;
        }
        
        Map<String, String> parmDataMapById = parmDataMap.get(parmId);
        return parmDataMapById != null ? parmDataMapById.get(key) : null;
    }

    @Override
    @Cacheable(value = "parmDataMap", key = "#parmId")
    public Map<String, String> getParmDataMap(String parmId) {
        if (parmId == null) {
            return null;
        }
        
        if (HVWConstants.HVWBASE.equals(parmId)) {
            return new HashMap<>(parmDataMapByHvwbase);
        } else if (HVWConstants.CMBASE.equals(parmId)) {
            return new HashMap<>(parmDataMapByCmodbase);
        } else if (HVWConstants.CODBASE.equals(parmId)) {
            return new HashMap<>(parmDataMapByCODBase);
        }
        
        Map<String, String> parmMap = parmDataMap.get(parmId);
        return parmMap != null ? new HashMap<>(parmMap) : null;
    }

    @Override
    public String getParmDataByKey(String parmId, String parmKey, String defaultParmKeyData) {
        if (parmId == null || parmKey == null) {
            return defaultParmKeyData;
        }
        
        Map<String, String> parmMap = getParmDataMap(parmId);
        if (parmMap != null && parmMap.containsKey(parmKey)) {
            return parmMap.get(parmKey);
        }
        
        return defaultParmKeyData;
    }

    @Override
    public String getParmDataByKey(String parmId, String parmKey) {
        return getParmDataByKey(parmId, parmKey, "");
    }

    @Override
    @Cacheable(value = "hvwbaseData", key = "#parmKey")
    public String getParmDataByKeyByHvwbase(String parmKey, String defaultParmKeyData) {
        if (parmKey == null) {
            return defaultParmKeyData;
        }
        
        return parmDataMapByHvwbase.getOrDefault(parmKey, defaultParmKeyData);
    }

    @Override
    public String getParmDataByKeyByHvwbase(String parmKey) {
        if (parmKey == null) {
            return null;
        }
        
        return parmDataMapByHvwbase.get(parmKey);
    }

    @Override
    public Map<String, String> getParmDataMapBySecuredClntEmpSec(String cmodApplication) {
        if (cmodApplication == null) {
            return new HashMap<>();
        }
        
        Map<String, String> cmodIndexBpdIdMap = parmDataMapBySecuredClntEmpSec.get(cmodApplication);
        return cmodIndexBpdIdMap != null ? new HashMap<>(cmodIndexBpdIdMap) : new HashMap<>();
    }

    @Override
    public Map<String, Map<String, String>> getSecuredClntEmpSecMap() {
        return new HashMap<>(parmDataMapBySecuredClntEmpSec);
    }

    @Override
    @Cacheable(value = "cmodbaseData", key = "#parmKey")
    public String getParmDataByKeyByCmodbase(String parmKey, String defaultParmKeyData) {
        if (parmKey == null) {
            return defaultParmKeyData;
        }
        
        return parmDataMapByCmodbase.getOrDefault(parmKey, defaultParmKeyData);
    }

    @Override
    @Cacheable(value = "codbaseData", key = "#parmKey")
    public String getParmDataByKeyByCODBase(String parmKey, String defaultParmKeyData) {
        if (parmKey == null) {
            return defaultParmKeyData;
        }
        
        return parmDataMapByCODBase.getOrDefault(parmKey, defaultParmKeyData);
    }

    @Override
    public String getParmDataByKeyByCmodfld(String parmKey, String defaultParmKeyData) {
        if (parmKey == null) {
            return defaultParmKeyData;
        }
        
        return parmDataMapByCmodfld.getOrDefault(parmKey, defaultParmKeyData);
    }

    @Override
    public BidiMap<String, String> getCmodfldMap() {
        return new DualHashBidiMap<>(parmDataMapByCmodfld);
    }

    @Override
    public String getParmKeyByParmDataByCmodfld(String parmValue, String defaultParmKeyData) {
        if (parmValue == null) {
            return defaultParmKeyData;
        }
        
        String key = parmDataMapByCmodfld.getKey(parmValue);
        return key != null ? key : defaultParmKeyData;
    }

    @Override
    public String getParmKeyByParmDataByODCMODField(String parmKey, String odFolderName, String defaultParmKeyData) {
        if (parmKey == null) {
            return defaultParmKeyData;
        }
        
        Map<String, String> fieldsMap = parmDataMapByODCMODFieldMap.get(parmKey);
        if (fieldsMap == null) {
            return defaultParmKeyData;
        }
        
        if (odFolderName != null && !odFolderName.trim().isEmpty()) {
            String normalizedFolderName = odFolderName.replace(' ', '_');
            String value = fieldsMap.get(normalizedFolderName);
            if (value != null) {
                return value;
            }
        }
        
        // Try to get standard field value
        String standardValue = fieldsMap.get("OD_STANDARD_FIELD"); // Using constant placeholder
        return standardValue != null ? standardValue : defaultParmKeyData;
    }
}