package com.hmhs.hvwmid.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CoverSheetObjectDTO {

    
    @NotBlank(message = "Object name is required")
    @Size(max = 10, message = "Template name cannot exceed 10 characters")
    private String objName;

 
    @NotBlank(message = "Object type is required")
    @Size(max = 10, message = "Template type cannot exceed 10 characters")
    private String objType;

    
    private String mimeType;

    private String objData;

    public CoverSheetObjectDTO(String objName, String objType, String mimeType, String objData) {
        this.objName = objName;
        this.objType = objType;
        this.mimeType = mimeType;
        this.objData = objData;
    }

    public String getObjName() {
        return objName;
    }

    public void setObjName(String objName) {
        this.objName = objName;
    }

    public String getObjType() {
        return objType;
    }

    public void setObjType(String objType) {
        this.objType = objType;
    }

    public String getMimeType() {
        if (mimeType == null)
            return ""; // Default MIME type if not set
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getObjData() {
        return objData;
    }

    public void setObjData(String objData) {
        this.objData = objData;
    }
}
