package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Nov 22, 2024
 */
@Entity
@Table(name = "T222_HVW_USER_CABINETS")
public class TblUserCabinets {
	@Id
	@Column(length = 64, columnDefinition = "CHAR(64)")
	private String userCabinetId;
	@Column(length = 32)
	private String cabinetId;
	@Column(length = 32)
	private String userId;

	public String getUserCabinetId() {
		return userCabinetId;
	}

	public void setUserCabinetId(String userCabinetId) {
		this.userCabinetId = userCabinetId;
	}

	public String getCabinetId() {
		return cabinetId;
	}

	public void setCabinetId(String cabinetName) {
		this.cabinetId = cabinetName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId.toUpperCase();
	}

}
