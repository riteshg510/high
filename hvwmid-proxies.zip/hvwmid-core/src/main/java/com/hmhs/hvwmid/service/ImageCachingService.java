package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.entity.TblImgObject;
import com.hmhs.hvwmid.entity.TblImgObjectId;
import com.hmhs.hvwmid.entity.TblImgToken;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.repository.ImageCachingRepository;
import com.hmhs.hvwmid.repository.ImgTokenRepository;
import com.hmhs.hvwmid.repository.TblImgObjectRepository;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Service
@Transactional
public class ImageCachingService {

    private static final Logger logger = LogManager.getLogger(ImageCachingService.class);


    private final ImageCachingRepository imageCachingRepository;
    private final ImgTokenRepository tokenRepo;
    private final TblImgObjectRepository objectRepo;
    private final GenericUDFService seqGen;
    private final TransactionTemplate txTemplate;
    @Value("${db-logging-env}")
    private String dbLoggingEnv;

    @Value("${api.images.download.url}")
    protected String getRequestIdUrl;

    @Autowired
    HvwDataRefresh hvwDataRefresh;
    // your UDF wrapper

    private final RestClientUtil restClientUtil;


    @Autowired
    public ImageCachingService(ImageCachingRepository imageCachingRepository, ImgTokenRepository t,
                               TblImgObjectRepository o, TransactionTemplate txTemplate,
                               org.springframework.jdbc.core.JdbcTemplate jdbcTemplate, RestClientUtil restClientUtil) {
        this.imageCachingRepository = imageCachingRepository;
        this.tokenRepo = t;
        this.objectRepo = o;
        this.seqGen = new GenericUDFService(jdbcTemplate, "DB2222054A_UDF");
        this.txTemplate = txTemplate;
        this.restClientUtil = restClientUtil;
    }

    @Transactional
    public int cacheDocument(InputStream in,
            String userId,
            String documentToken,
            String securityToken) throws IOException {

        String env = hvwDataRefresh.getParmDataByKeyByCmodbase("DEFAULT_ENV", dbLoggingEnv);
        int requestId = seqGen.generateRequestId(env);
        TblImgToken token = new TblImgToken();
        token.setRequestId(requestId);
        token.setUserId(userId);
        token.setDocumentToken(documentToken);
        token.setSecurityToken(securityToken);
        tokenRepo.save(token);

        byte[] buffer = new byte[32 * 1024]; // ~32KB
        int seq = 0, len;
        while ((len = in.read(buffer)) != -1) {
            byte[] chunk = Arrays.copyOf(buffer, len);
            TblImgObject obj = new TblImgObject();
            TblImgObjectId id = new TblImgObjectId();
            id.setRequestId(requestId);
            id.setSequenceNo(seq);
            obj.setId(id);
            obj.setObjectSegment(chunk);
            objectRepo.save(obj);
        }
        return requestId;
    }

    @Transactional
    public TblImgToken getDocumentToken(Integer requestId) {
        return tokenRepo.findByRequestId(requestId)
                .orElseThrow(() -> new SecurityException("Not found"));
    }


    @Transactional
    public TblImgToken getDocumentToken(Integer requestId, String securityToken) {
        return tokenRepo.findByRequestIdAndSecurityTokenSafe(requestId, securityToken)
                .orElseThrow(() -> new SecurityException("Not found"));
    }

    public StreamingResponseBody streamDocument(int requestId) {
        return outputStream -> {
            try {
                imageCachingRepository.streamSegmentsByRequestId(requestId, outputStream);
            } catch (SQLException e) {
                throw new IOException("Database error while streaming document", e);
            }
        };
    }

    @Transactional
    public TblImgToken saveToken(String userId, String securityToken, String documentToken) {

        TblImgToken newtoken = new TblImgToken();
        String env = hvwDataRefresh.getParmDataByKeyByCmodbase("DEFAULT_ENV", dbLoggingEnv);
        int requestId = seqGen.generateRequestId(env);

        newtoken.setRequestId(requestId);
        newtoken.setUserId(userId);
        newtoken.setTimeCreate(java.time.LocalDateTime.now());
        newtoken.setDocumentType("");
        newtoken.setDocumentPages(1);
        newtoken.setDocumentToken(documentToken);
        newtoken.setSecurityToken(securityToken);
        return tokenRepo.save(newtoken);
    }


    /**
     * Returns a TblCodToken for the given user, documentToken, and translateType,
     * using DOC_CNV_STATUS and documentType logic.
     * If not found, returns null.
     */
    public TblImgToken getTokenByStatusAndType(String userId, String documentToken, String translateType,
                                               String securityToken) {
        String[] specialTypes = { "pdf", "afp", "tif", "tiff", "jpg", "jpeg", "bmp", "gif", "png", "txt" };
        java.util.List<TblImgToken> tokens = tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe(userId,
                documentToken, securityToken);
        if ("TOPDF".equalsIgnoreCase(translateType != null ? translateType.trim() : null)) {
            for (TblImgToken token : tokens) {
                String docType = token.getDocumentType();
                String status = token.getDocCnvStatus();
                logger.debug("Checking token with status: {}, docType: {}", status, docType);
                boolean isSpecial = false;
                if (docType != null) {
                    String docTypeLower = docType.trim().toLowerCase();
                    isSpecial = java.util.Arrays.stream(specialTypes).noneMatch(docTypeLower::equals);
                } else {
                    isSpecial = true;
                }
                if (isSpecial) {
                    logger.debug("docType with special document type found: {}", docType);
                    return token;
                }
                String statusTrimmed = status != null ? status.trim() : null;
                if ("Converted".equalsIgnoreCase(statusTrimmed)
                        || "Conversion Failed".equalsIgnoreCase(statusTrimmed)) {
                    return token;
                }
            }
        } else {
            logger.debug("translateType is not TOPDF, checking for Original or Conversion Failed status");
            for (TblImgToken token : tokens) {

                String docType = token.getDocumentType();
                String status = token.getDocCnvStatus();
                logger.debug("Checking token with status: {}, docType: {}", status, docType);
                boolean isSpecial = false;
                if (docType != null) {
                    String docTypeLower = docType.trim().toLowerCase();
                    isSpecial = java.util.Arrays.stream(specialTypes).noneMatch(docTypeLower::equals);
                } else {
                    isSpecial = true;
                }
                if (isSpecial) {
                    logger.debug("docType with special document type found: {}", docType);
                    return token;
                }
                String statusTrimmed = status != null ? status.trim() : null;
                if ("Original".equalsIgnoreCase(statusTrimmed) || "Conversion Failed".equalsIgnoreCase(statusTrimmed)) {
                    return token;
                }
            }
        }
        return null;
    }


    public Map<String, Integer> getDocumentRequestId(final String documentToken,
                                                     final String authToken, final String translateType) {
        if (documentToken == null || documentToken.trim().isEmpty()) {
            throw new HVWException("Document token cannot be null or empty");
        }


        // Prepare base payload
        final Map<String, Object> payload = prepareBasePayload(documentToken);
        if (translateType != null && !translateType.isEmpty()) {
            payload.put("translateType", translateType);
        }
        logger.info("Sending download request to URL: {} with payload: {}", getRequestIdUrl, payload);
        // Make the API call and expect a binary response
        final ResponseEntity<Map> response = restClientUtil.postRequest(getRequestIdUrl, authToken, payload);

        if (response.getStatusCode() == HttpStatus.OK) {
            Map<String, Integer> responseBody = response.getBody();
            if (responseBody != null && responseBody.containsKey("REQUEST_ID")) {
                return responseBody;
            } else {
                logger.error("Request ID not found in the response");
                throw new RuntimeException("Request ID not found in the response");
            }
        } else {
            logger.error("Failed to get request ID, status code: {}", response.getStatusCode());
            throw new RuntimeException("Failed to get request ID, status code: " + response.getStatusCode());
        }
    }


    protected Map<String, Object> prepareBasePayload(final String documentToken) {
        final Map<String, Object> payload = new HashMap<>();
        payload.put("documentToken", documentToken);
        return payload;
    }


    public void setDbLoggingEnv(String dbLoggingEnv) {
        this.dbLoggingEnv = dbLoggingEnv;
    }
}
