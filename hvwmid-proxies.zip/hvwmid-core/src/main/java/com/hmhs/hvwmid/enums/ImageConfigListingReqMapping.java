package com.hmhs.hvwmid.enums;

public enum ImageConfigListingReqMapping {
    ENTTTLPR_APPLIDCD("lprApplIdCdQuery", "lprApplIdCdDisplay", "lprApplIdCd", "Appl Id", "na", "Image Applid - LPR/APR", "APPLIDCD", "LPR"),
    ENTTTLPR_APPLID("lprApplIdQuery", "lprApplIdDisplay", "lprApplId", "Description", "lprApplIdSearchOperator", "Image Applid - LPR/APR", "APPLID", "LPR"),
    ENTTTAPR_SECRESCLASS("aprSecResClassQuery", "aprSecResClassDisplay", "aprSecResClass", "Security Resource Class", "aprSecResClassSearchOperator", "Image Applid - LPR/APR", "SECRESCLASS", "APR"),
    ENTTTAPR_DB2_COLLECTION("aprDb2CollectionQuery", "aprDb2CollectionDisplay", "aprDb2Collection", "DB2 Collection", "aprDb2CollectionSearchOperator", "Image Applid - LPR/APR", "DB2_COLLECTION", "APR"),
    ENTTTAPR_HM_DFLT_IODM("aprDefaultIODMQuery", "aprDefaultIODMDisplay", "aprDefaultIODM", "Default IODM", "aprDefaultIODMSearchOperator", "Image Applid - LPR/APR", "HM_DFLT_IODM", "APR"),
    T222APRM_PARM_DATA("parmDataQuery",	"parmDataDisplay", "parmData", "Map Id", "parmDataSearchOperator", "IMI - APRM", "PARM_DATA", "PRM"),
    BATCHTBL_BBATCH_ID("tblBatchIdQuery", "tblBatchIdDisplay", "tblBatchId", "Batch Id", "tblBatchIdSearchOperator","Batch ID - BATCHTBL", "BBATCH_ID", "TBL"),
    BATCHTBL_BFORM_NUM("tblFormNumQuery", "tblFormNumDisplay", "tblFormNum", "Formnum", "tblFormNumSearchOperator", "Batch ID - BATCHTBL", "BFORM_NUM", "TBL"),
    BATCHTBL_BDESCRIPTION("tblBDescriptionQuery", "tblBDescriptionDisplay", "tblBDescription", "Description", "tblBDescriptionSearchOperator", "Batch ID - BATCHTBL", "BDESCRIPTION", "TBL"),
    BATCHTBL_BFILE_TAB("tblFileTabQuery", "tblFileTabDisplay", "tblFileTab", "Filetab", "tblFileTabSearchOperator", "Batch ID - BATCHTBL", "BFILE_TAB", "TBL"),
    BATCHTBL_BROUTE_FLAG("tblBRouteFlagQuery", "tblBRouteFlagDisplay", "tblBRouteFlag", "Route Flag", "tblBRouteFlagSearchOperator", "Batch ID - BATCHTBL", "BROUTE_FLAG", "TBL"),
    BATCHTBL_BRLOB("tblBRLOBQuery", "tblBRLOBDisplay", "tblBRLOB", "Routing LOB", "tblBRLOBSearchOperator", "Batch ID - BATCHTBL", "BRLOB", "TBL"),
    BATCHTBL_BTRAN_TYPE("tblBTranTypeQuery", "tblBTranTypeDisplay","tblBTranType", "Trantype", "tblBTranTypeSearchOperator", "Batch ID - BATCHTBL", "BTRAN_TYPE", "TBL"),
    BATCHTBL_BUNIT_CODE("tblBUnitCodeQuery", "tblBUnitCodeDisplay", "tblBUnitCode", "Unit Code", "tblBUnitCodeSearchOperator", "Batch ID - BATCHTBL", "BUNIT_CODE", "TBL"),
    BATCHTBL_BROUTE_CODE("tblBRouteCodeQuery", "tblBRouteCodeDisplay", "tblBRouteCode",	"Route Code", "tblBRouteCodeSearchOperator", "Batch ID - BATCHTBL", "BROUTE_CODE", "TBL"),
    BATCHTBL_BPRIORITY("tblBPriorityQuery", "tblBPriorityDisplay", "tblBPriority", "Priority", "na", "Batch ID - BATCHTBL", "BPRIORITY", "TBL"),
    T117A001_KEYVAL("a01BatchIdQuery", "a01BatchIdDisplay", "a01BatchId", "KeyVal", "a01BatchIdSearchOperator","Image - A001", "KEYVAL", "A01"),
    T117A001_FORMNUM("a01FormNumQuery", "a01FormNumDisplay", "a01FormNum", "Formnum", "a01FormNumSearchOperator", "Image - A001", "FORMNUM", "A01"),
    T117A001_RUNIT("a01RunitQuery",	"a01RunitDisplay", "a01Runit", "Unit Code", "na", "Image - A001", "RUNIT", "A01"),
    T117A001_RCODE("a01RcodeQuery", "a01RcodeDisplay", "a01Rcode", "Route Code", "a01RcodeSearchOperator", "Image - A001", "RCODE", "A01"),
    T117A001_ROUTEFLAG("a01RouteFlagQuery", "a01RouteFlagDisplay",	"a01RouteFlag", "Route Flag", "a01RouteFlagSearchOperator", "Image - A001", "ROUTEFLAG", "A01"),
    T117A001_PRIORITY("a01PriorityQuery", "a01PriorityDisplay", "a01Priority", "Priority", "na", "Image - A001", "PRIORITY", "A01"),
    T117A001_FILETAB("a01FileTabQuery", "a01FileTabDisplay", "a01FileTab", "Filetab", "a01FileTabSearchOperator", "Image - A001", "FILETAB", "A01"),
    T117A001_COMMENT("a01CommentQuery", "a01CommentDisplay", "a01Comment", "Comment", "a01CommentSearchOperator", "Image - A001", "COMMENT", "A01"),
    T117A001_SCANEXIT("a01ScanExitQuery", "a01ScanExitDisplay", "a01ScanExit", "Scanner Exit", "a01ScanExitSearchOperator", "Image - A001", "SCANEXIT", "A01"),
    T117A001_DPK("a01DpkQuery", "a01DpkDisplay", "a01Dpk", "DPK", "a01DpkSearchOperator", "Image - A001", "DPK", "A01"),
    T117A001_NAIC_CODE("a01NaicCodeQuery", "a01NaicCodeDisplay", "a01NaicCode", "NAIC", "a01NaicCodeSearchOperator", "Image - A001", "NAIC_CODE", "A01"),
    ENTTTFRM_FORMNUM("frmFormNumQuery", "frmFormNumDisplay", "frmFormNum", "Formnum", "frmFormNumSearchOperator", "Image Routing - FRM", "FORMNUM", "FRM"),
    ENTTTFRM_FORMCD("frmFormCdQuery", "frmFormCdDisplay", "frmFormCd", "FormCd", "na", "Image Routing - FRM", "FORMCD", "FRM"),
    ENTTTFRM_RLOB("frmRLOBQuery", "frmRLOBDisplay", "frmRLOB", "Routing LOB", "frmRLOBSearchOperator", "Image Routing - FRM", "RLOB", "FRM"),
    ENTTTFRM_TRANTYPE("frmTranTypeQuery", "frmTranTypeDisplay", "frmTranType", "Trantype", "frmTranTypeSearchOperator", "Image Routing - FRM", "TRANTYPE", "FRM"),
    ENTTTFRM_OBJDESC("frmObjDescQuery","frmObjDescDisplay", "frmObjDesc", "Formnum Description", "frmObjDescSearchOperator", "Image Routing - FRM", "OBJDESC", "FRM"),
    ENTTTFRM_HM_SPR_GROUP("frmSpreadingGrpQuery", "frmSpreadingGrpDisplay", "frmSpreadingGrp", "Spreading Group", "frmSpreadingGrpSearchOperator", "Image Routing - FRM", "HM_SPR_GROUP","FRM"),
    ENTTTFRM_HM_RETENT_ID("frmRetentionGrpQuery", "frmRetentionGrpDisplay", "frmRetentionGrp", "Retention Group", "frmRetentionGrpSearchOperator", "Image Routing - FRM", "HM_RETENT_ID", "FRM"),
    ENTTTFTB_FILETAB("ftbFileTabQuery", "ftbFileTabDisplay", "ftbFileTab", "Filetab", "ftbFileTabSearchOperator", "Filetab - FTB", "FILETAB", "FTB"),
    ENTTTFTB_TABCD("ftbFileTabCdQuery", "ftbFileTabCdDisplay", "ftbFileTabCd", "FiletabCd", "na", "Filetab - FTB", "TABCD", "FTB"),
    EYPTWRTT_RLOB("rttRLOBQuery", "rttRLOBDisplay", "rttRLOB", "Routing LOB", "rttRLOBSearchOperator", "Image Routing - RTT", "RLOB", "RTT"),
    EYPTWRTT_TRANTYPE("rttTranTypeQuery", "rttTranTypeDisplay", "rttTranType", "Trantype", "rttTranTypeSearchOperator", "Image Routing - RTT", "TRANTYPE", "RTT"),
    EYPTWRTT_USERPRM1("rttUserPrm1Query", "rttUserPrm1Display", "rttUserPrm1", "User Parm 1", "rttUserPrm1SearchOperator", "Image Routing - RTT", "USERPRM1", "RTT"),
    EYPTWRTT_CATWORK("rttCatWorkQuery", "rttCatWorkDisplay", "rttCatWork", "Category of Work", "rttCatWorkSearchOperator", "Image Routing - RTT", "CATWORK", "RTT"),
    EYPTWRTT_RCODE("rttRcodeQuery", "rttRcodeDisplay", "rttRcode", "Route Code", "rttRcodeSearchOperator", "Image Routing - RTT", "RCODE", "RTT"),
    EYPTWUNT_RUNIT("untRunitQuery", "untRunitDisplay", "untRunit", "Unit Code", "na", "Image Routing - UNT", "RUNIT", "UNT"),
    EYPTWUNT_USERPRM1("untUserPrm1Query", "untUserPrm1Display", "untUserPrm1", "User Parm 1", "untUserPrm1SearchOperator", "Image Routing - UNT", "USERPRM1", "UNT"),
    EYPTWUNT_CATWORK("untCatWorkQuery", "untCatWorkDisplay", "untCatWork", "Category of Work", "untCatWorkSearchOperator", "Image Routing - UNT", "CATWORK", "UNT"),
    EYPTWURC_RUNIT("urcRunitQuery", "urcRunitDisplay", "urcRunit", "Unit Code", "na", "Image Routing - URC", "RUNIT", "URC"),
    EYPTWURC_RCODE("urcRcodeQuery", "urcRcodeDisplay", "urcRcode", "Route Code", "urcRcodeSearchOperator", "Image Routing - URC", "RCODE", "URC"),
    EYPTWURC_WQUEDESC("urcQueueDescQuery", "urcQueueDescDisplay", "urcQueueDesc", "Queue Description", "urcQueueDescSearchOperator", "Image Routing - URC", "WQUEDESC", "URC"),
    ;

    private final String queryField;
    private final String displayField;
    private final String outputField;
    private final String columnHeader;
    private final String searchStringField;
    private final String groupName;
    private final String columnName;
    private final String alias;

    ImageConfigListingReqMapping(String queryField, String displayField, String outputField,
                                 String columnHeader, String searchStringField, String groupName,
                                 String columnName, String alias) {
        this.queryField = queryField;
        this.displayField = displayField;
        this.outputField = outputField;
        this.columnHeader = columnHeader;
        this.searchStringField = searchStringField;
        this.groupName = groupName;
        this.columnName = columnName;
        this.alias = alias;
    }

    public String getQueryField()       { return queryField; }
    public String getDisplayField()     { return displayField; }
    public String getOutputField()      { return outputField; }
    public String getColumnHeader()     { return columnHeader; }
    public String getSearchStringField(){ return searchStringField; }
    public String getGroupName()        { return groupName; }
    public String getColumnName()       { return columnName; }
    public String getAlias()            { return alias; }
}
