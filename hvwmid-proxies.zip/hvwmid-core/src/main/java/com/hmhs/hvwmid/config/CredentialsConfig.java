package com.hmhs.hvwmid.config;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.hmhs.hvwmid.exception.HVWException;

@Configuration
public class CredentialsConfig {

	@Value("${credentialFile}")
	private String credz;

	@Value("${oauthClientId}")
	private String oauthClientId;
	@Value("${oauthSecret}")
	private String oauthSecret;
	@Value("${appId}")
	private String appId;
	@Value("${appIdPassword}")
	private String appIdPassword;

	private Logger logger = LogManager.getLogger();

	@Autowired
	private Environment environment;

	public String getOauthClientId() {
		return oauthClientId;
	}

	public String getOauthSecret() {
		return oauthSecret;
	}

	public String getAppId() {
		return appId;
	}

	public String getAppIdPassword() {
		return appIdPassword;
	}

	@PostConstruct
	private void getCredentials() throws HVWException {
		logger.log(Level.INFO, "Loading credentials Started");
		List<String> profiles = Arrays.asList(environment.getActiveProfiles());
		boolean isLocal = profiles.stream().anyMatch("local"::equalsIgnoreCase);
		Properties p = retrieveCredentials(credz);
		if (isLocal) {
			appId = p.getProperty("apphvw-username");
			appIdPassword = p.getProperty("apphvw-password");
			oauthClientId = p.getProperty("edsoauth-username");
			oauthSecret = p.getProperty("edsoauth-password");
		} else {
			appId = (p.getProperty("\"apphvw-username\"")).replace("\"", "");
			appIdPassword = (p.getProperty("\"apphvw-password\"")).replace("\"", "");
			oauthClientId = (p.getProperty("\"edsoauth-username\"")).replace("\"", "");
			oauthSecret = (p.getProperty("\"edsoauth-password\"")).replace("\"", "");
		}
		logger.log(Level.INFO, "Loading credentials Completed");
	}

	/**
	 * Retrieve the logonID(s) and password(s) from the input credentials file.
	 *
	 * @param file
	 * @return
	 * @throws HVWException
	 */
	private Properties retrieveCredentials(final String file) throws HVWException {
		Properties out = new Properties();
		try {
			if (StringUtils.isNotBlank(file)) {
				try (InputStream stream = new FileInputStream(file)) {
					out.load(stream);
				}
			} else {
				logger.log(Level.ERROR, () -> "Missing reference to credential file =>" + file + "<=");
				throw new HVWException("Missing reference to credential file " + file);
			}

			if (out.size() == 0) {
				logger.log(Level.ERROR, () -> "Unable to parse credentials from =>" + file + "<=");
				throw new HVWException("Unable to parse credentials from " + file);
			}
		} catch (Exception e) {
			logger.log(Level.FATAL, () -> "Unable to parse credentials from =>" + file + "<=", e);
			throw new HVWException("Unable to parse credentials from " + file);
		}

		return out;
	}

}
