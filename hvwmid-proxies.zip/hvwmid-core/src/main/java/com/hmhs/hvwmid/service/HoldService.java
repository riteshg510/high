package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.dto.HoldDTO;
import com.hmhs.hvwmid.entity.T222ImgRmaHold;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.projection.HoldProjection;
import com.hmhs.hvwmid.repository.T222ImgRmaHoldRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class HoldService {
    private static final Logger logger = LogManager.getLogger(HoldService.class);

    private static final String BPD_ID = "bpdId";
    private static final String HOLD_CODE = "holdCode";
    private static final String HOLD_ID = "holdId";
    private static final String HOLD_DESCRIPTION = "holdDescription";
    private static final String HOLD_EDIT_FLAG = "holdEditFlag";
    private static final String HOLD_EDIT_PGM_NAME = "holdEditPgmName";
    private static final String HOLD_MOD_USER = "holdModUser";
    private static final String HOLD_DATE_BEGIN = "holdDateBegin";
    private static final String HOLD_DATE_END = "holdDateEnd";
    private static final String MOD_DATE = "modDate";
    private static final String MOD_USER = "modUser";
    private static final String ASC = "asc";
    private static final String DATE_PATTERN_YYYY_MM_DD = "yyyy-MM-dd";

    private final T222ImgRmaHoldRepository t222ImgRmaHoldRepository;
    private final PolicyHoldService policyHoldService;

    public HoldService(T222ImgRmaHoldRepository t222ImgRmaHoldRepository, PolicyHoldService policyHoldService) {
        this.t222ImgRmaHoldRepository = t222ImgRmaHoldRepository;
        this.policyHoldService = policyHoldService;
    }

    @PersistenceContext
    private EntityManager entityManager;

    public Page<HoldDTO> listHolds(Map<String, String> otherFields) {
        Integer bpdId = otherFields.get("bpdId") != null ? Integer.valueOf(otherFields.get("bpdId")) : null;
        int page = otherFields.get("page") != null ? Integer.parseInt(otherFields.get("page")) : 0;
        int pageSize = otherFields.get("pageSize") != null ? Integer.parseInt(otherFields.get("pageSize")) : 20;

        String sortColumn = otherFields.getOrDefault("sortColumn", "HOLD_CODE");
        String sortDirection = otherFields.getOrDefault("sortDirection", "ASC");

        StringBuilder sql = new StringBuilder();
        sql.append("""
        SELECT
            BPD_ID,
            HOLD_CODE,
            HOLD_ID,
            HOLD_DATE_BEGIN,
            HOLD_DATE_END,
            HOLD_EDIT_FLAG,
            HOLD_EDIT_PGMNAME,
            MODUSER,
            MODDATE,
            HOLD_DESCRIPTION
        FROM T222_IMG_RMA_HOLD
        WHERE 1=1
    """);

        Map<String, Object> params = new HashMap<>();

        if (bpdId != null) {
            sql.append(" AND BPD_ID = :bpdId");
            params.put("bpdId", bpdId);
        }
        if (otherFields.get("holdCode") != null) {
            sql.append(" AND CAST(HOLD_CODE AS VARCHAR(50)) LIKE :holdCode");
            params.put("holdCode", otherFields.get("holdCode"));
        }
        if (otherFields.get("holdId") != null) {
            sql.append(" AND HOLD_ID LIKE :holdId");
            params.put("holdId", otherFields.get("holdId"));
        }
        if (otherFields.get("holdDescription") != null) {
            sql.append(" AND HOLD_DESCRIPTION LIKE '%' || :holdDescription || '%'");
            params.put("holdDescription", otherFields.get("holdDescription"));
        }
        if (otherFields.get("holdDateBegin") != null) {
            sql.append(" AND HOLD_DATE_BEGIN >= CAST(:holdDateBegin AS DATE) AND HOLD_DATE_BEGIN < CAST(:holdDateBegin AS DATE) + 1 DAY");
            params.put("holdDateBegin", otherFields.get("holdDateBegin"));
        }
        if (otherFields.get("holdDateEnd") != null) {
            sql.append(" AND HOLD_DATE_END >= CAST(:holdDateEnd AS DATE) AND HOLD_DATE_END < CAST(:holdDateEnd AS DATE) + 1 DAY");
            params.put("holdDateEnd", otherFields.get("holdDateEnd"));
        }
        if (otherFields.get("holdEditFlag") != null) {
            sql.append(" AND HOLD_EDIT_FLAG LIKE :holdEditFlag");
            params.put("holdEditFlag", otherFields.get("holdEditFlag"));
        }
        if (otherFields.get("holdEditPgmName") != null) {
            sql.append(" AND HOLD_EDIT_PGMNAME LIKE :holdEditPgmName");
            params.put("holdEditPgmName", otherFields.get("holdEditPgmName"));
        }
        if (otherFields.get("modUser") != null) {
            sql.append(" AND MODUSER LIKE :modUser");
            params.put("modUser", otherFields.get("modUser"));
        }
        if (otherFields.get("modDate") != null) {
            sql.append(" AND MODDATE >= CAST(:modDate AS TIMESTAMP) AND MODDATE < CAST(:modDate AS TIMESTAMP) + 1 DAY");
            params.put("modDate", otherFields.get("modDate"));
        }

        sql.append(" ORDER BY ").append(sortColumn).append(" ").append(sortDirection);

        Query query = entityManager.createNativeQuery(sql.toString());
        params.forEach(query::setParameter);

        query.setFirstResult(page * pageSize);
        query.setMaxResults(pageSize);

        @SuppressWarnings("unchecked")
        List<Object[]> rows = query.getResultList();

        List<HoldDTO> result = rows.stream().map(HoldDTO::new).toList();

        long total = countTotal(otherFields, bpdId);

        return new PageImpl<>(result, PageRequest.of(page, pageSize), total);
    }

    private long countTotal(Map<String, String> otherFields, Integer bpdId) {
        StringBuilder countSql = new StringBuilder("SELECT COUNT(*) FROM T222_IMG_RMA_HOLD WHERE 1=1 ");
        Map<String, Object> params = new HashMap<>();

        if (bpdId != null) {
            countSql.append(" AND BPD_ID = :bpdId");
            params.put("bpdId", bpdId);
        }
        if (otherFields.get("holdCode") != null) {
            countSql.append(" AND CAST(HOLD_CODE AS VARCHAR(50)) LIKE :holdCode");
            params.put("holdCode", otherFields.get("holdCode"));
        }
        if (otherFields.get("holdId") != null) {
            countSql.append(" AND HOLD_ID LIKE :holdId");
            params.put("holdId", otherFields.get("holdId"));
        }
        if (otherFields.get("holdDescription") != null) {
            countSql.append(" AND HOLD_DESCRIPTION LIKE '%' || :holdDescription || '%'");
            params.put("holdDescription", otherFields.get("holdDescription"));
        }
        if (otherFields.get("holdDateBegin") != null) {
            countSql.append(" AND HOLD_DATE_BEGIN >= CAST(:holdDateBegin AS DATE) AND HOLD_DATE_BEGIN < CAST(:holdDateBegin AS DATE) + 1 DAY");
            params.put("holdDateBegin", otherFields.get("holdDateBegin"));
        }
        if (otherFields.get("holdDateEnd") != null) {
            countSql.append(" AND HOLD_DATE_END >= CAST(:holdDateEnd AS DATE) AND HOLD_DATE_END < CAST(:holdDateEnd AS DATE) + 1 DAY");
            params.put("holdDateEnd", otherFields.get("holdDateEnd"));
        }
        if (otherFields.get("holdEditFlag") != null) {
            countSql.append(" AND HOLD_EDIT_FLAG LIKE :holdEditFlag");
            params.put("holdEditFlag", otherFields.get("holdEditFlag"));
        }
        if (otherFields.get("holdEditPgmName") != null) {
            countSql.append(" AND HOLD_EDIT_PGMNAME LIKE :holdEditPgmName");
            params.put("holdEditPgmName", otherFields.get("holdEditPgmName"));
        }
        if (otherFields.get("modUser") != null) {
            countSql.append(" AND MODUSER LIKE :modUser");
            params.put("modUser", otherFields.get("modUser"));
        }
        if (otherFields.get("modDate") != null) {
            countSql.append(" AND MODDATE >= CAST(:modDate AS TIMESTAMP) AND MODDATE < CAST(:modDate AS TIMESTAMP) + 1 DAY");
            params.put("modDate", otherFields.get("modDate"));
        }

        Query countQuery = entityManager.createNativeQuery(countSql.toString());
        params.forEach(countQuery::setParameter);

        Number total = (Number) countQuery.getSingleResult();
        return total.longValue();
    }



    private static void setHoldCodeIfExists(Map<String, String> otherFields, T222ImgRmaHold hold) {
        String holdCode = otherFields.get(HOLD_CODE);

        if (holdCode != null && !holdCode.isBlank()) {
            try {
                hold.setHoldCode(Integer.parseInt(holdCode));
            } catch (NumberFormatException e) {
                logger.warn("Hold code is not number. Random one will be assigned.");
            }
        }
    }

    private static void setHoldEditPgName(Map<String, String> otherFields, T222ImgRmaHold hold) {
        hold.setHoldEditPgmName(otherFields.get(HOLD_EDIT_PGM_NAME));
        if (StringUtils.isBlank(otherFields.get(HOLD_EDIT_PGM_NAME))){
            hold.setHoldEditPgmName("N/A");
        }
    }

    @Transactional
    public T222ImgRmaHold createHold(Map<String, String> otherFields, String loginUser) {
        logger.info("Creating new Hold.");

        validateMandatoryFields(otherFields, loginUser);

        T222ImgRmaHold hold = new T222ImgRmaHold();

        setHoldCodeIfExists(otherFields, hold);
        hold.setBpdId(parseIntegerField(otherFields, BPD_ID));
        hold.setHoldId(otherFields.get(HOLD_ID));
        hold.setHoldEditFlag(validateEditFlag(otherFields.get(HOLD_EDIT_FLAG)));
        setHoldEditPgName(otherFields, hold);
        hold.setModUser(loginUser);
        hold.setHoldDescription(otherFields.get(HOLD_DESCRIPTION));

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DATE_PATTERN_YYYY_MM_DD);
        hold.setHoldDateBegin(parseOptionalDate(otherFields.get(HOLD_DATE_BEGIN), dateFormatter));
        hold.setHoldDateEnd(parseOptionalDate(otherFields.get(HOLD_DATE_END), dateFormatter));

        hold.setModDate(LocalDateTime.now());

        t222ImgRmaHoldRepository.save(hold);
        logger.info("Hold created.");
        return hold;
    }

    private void validateMandatoryFields(Map<String, String> otherFields, String loginUser) {
        String[] mandatoryFields = {BPD_ID, HOLD_ID, HOLD_EDIT_FLAG};
        for (String field : mandatoryFields) {
            String value = otherFields.get(field);
            if (value == null || value.trim().isEmpty()) {
                throw new HVWException("Missing mandatory field: " + field);
            }
        }
        if (loginUser == null || loginUser.isBlank()) {
            throw new HVWException("Missing mandatory field: loginUser");
        }
    }

    private Integer parseIntegerField(Map<String, String> otherFields, String fieldName) {
        try {
            return Integer.valueOf(otherFields.get(fieldName));
        } catch (NumberFormatException e) {
            throw new HVWException("Invalid numeric value for " + fieldName + ": " + otherFields.get(fieldName));
        }
    }

    private LocalDate parseOptionalDate(String dateStr, DateTimeFormatter formatter) {
        if (dateStr != null && !dateStr.isBlank()) {
            try {
                return LocalDate.parse(dateStr, formatter);
            } catch (Exception e) {
                throw new HVWException("Invalid date format: " + dateStr);
            }
        }
        return null;
    }

    private String validateEditFlag(String flag) {
        if (flag == null || (!flag.equals("Y") && !flag.equals("N"))) {
            throw new HVWException("Invalid value for HOLD_EDIT_FLAG. Must be 'Y' or 'N'");
        }
        return flag;
    }

    public Object getClientIds() {
        return t222ImgRmaHoldRepository.findDistinctBpdIds();
    }

    @Transactional
    public T222ImgRmaHold updateHold(Map<String, String> otherFields, String loginUser) {
        logger.info("Updating Hold.");

        validateMandatoryFields(otherFields, loginUser);

        Integer holdCode = parseIntegerField(otherFields, HOLD_CODE);

        T222ImgRmaHold hold = this.getByHoldCode(holdCode);
        setHoldEditPgName(otherFields, hold);
        hold.setHoldId(otherFields.get(HOLD_ID));
        hold.setHoldEditFlag(validateEditFlag(otherFields.get(HOLD_EDIT_FLAG)));
        hold.setModUser(loginUser);
        hold.setHoldDescription(otherFields.get(HOLD_DESCRIPTION));

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(DATE_PATTERN_YYYY_MM_DD);
        hold.setHoldDateBegin(parseOptionalDate(otherFields.get(HOLD_DATE_BEGIN), dateFormatter));
        hold.setHoldDateEnd(parseOptionalDate(otherFields.get(HOLD_DATE_END), dateFormatter));

        hold.setModDate(LocalDateTime.now());

        t222ImgRmaHoldRepository.save(hold);
        logger.info("Hold updated successfully.");
        return hold;
    }

    public T222ImgRmaHold getByHoldCode(Integer holdCode) {
        return t222ImgRmaHoldRepository.findByHoldCode(holdCode)
                .orElseThrow(() -> new HVWException("Hold not found for HOLD_CODE: " + holdCode));
    }


    @Transactional
    public void delete(Integer holdCode) {
        logger.info("Deleting Hold with HOLD_CODE: {}", holdCode);
        policyHoldService.deleteByHoldCode(holdCode);
        t222ImgRmaHoldRepository.deleteByHoldCode(holdCode);
        logger.info("Hold deleted successfully. HOLD_CODE: {}", holdCode);
    }
}
