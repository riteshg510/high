package com.hmhs.hvwmid.config;

import javax.sql.DataSource;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.hmhs.hvwmid.exception.HVWException;
import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@ConfigurationProperties("data-source-config")
public class DataSourceConfig {

	private Logger logger = LogManager.getLogger();

	private String jndiName;
	private String driverClass;
	private String url;
	private int initialPoolSize;
	private int minPoolSize;
	private int maxPoolSize;
	private int maxIdleTime;
	private int maxStatements;
	private int maxStatementsPerConn;
	private int maxIdleTimeExcessConn;
	private boolean validateConnections;
	private String validateSQL;
	private int poolIncrement;
	private int idleConnectionTestPeriod;

	@Autowired
	public CredentialsConfig credentialsConfig;

	public String getJndiName() {
		return jndiName;
	}

	public void setJndiName(String jndiName) {
		this.jndiName = jndiName;
	}

	public String getDriverClass() {
		return driverClass;
	}

	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getInitialPoolSize() {
		return initialPoolSize;
	}

	public void setInitialPoolSize(int initialPoolSize) {
		this.initialPoolSize = initialPoolSize;
	}

	public int getMinPoolSize() {
		return minPoolSize;
	}

	public void setMinPoolSize(int minPoolSize) {
		this.minPoolSize = minPoolSize;
	}

	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public void setMaxPoolSize(int maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public int getMaxIdleTime() {
		return maxIdleTime;
	}

	public void setMaxIdleTime(int maxIdleTime) {
		this.maxIdleTime = maxIdleTime;
	}

	public int getMaxStatements() {
		return maxStatements;
	}

	public void setMaxStatements(int maxStatements) {
		this.maxStatements = maxStatements;
	}

	public int getMaxStatementsPerConn() {
		return maxStatementsPerConn;
	}

	public void setMaxStatementsPerConn(int maxStatementsPerConn) {
		this.maxStatementsPerConn = maxStatementsPerConn;
	}

	public int getMaxIdleTimeExcessConn() {
		return maxIdleTimeExcessConn;
	}

	public void setMaxIdleTimeExcessConn(int maxIdleTimeExcessConn) {
		this.maxIdleTimeExcessConn = maxIdleTimeExcessConn;
	}

	public boolean isValidateConnections() {
		return validateConnections;
	}

	public void setValidateConnections(boolean validateConnections) {
		this.validateConnections = validateConnections;
	}

	public String getValidateSQL() {
		return validateSQL;
	}

	public void setValidateSQL(String validateSQL) {
		this.validateSQL = validateSQL;
	}

	public int getPoolIncrement() {
		return poolIncrement;
	}

	public void setPoolIncrement(int poolIncrement) {
		this.poolIncrement = poolIncrement;
	}

	public int getIdleConnectionTestPeriod() {
		return idleConnectionTestPeriod;
	}

	public void setIdleConnectionTestPeriod(int idleConnectionTestPeriod) {
		this.idleConnectionTestPeriod = idleConnectionTestPeriod;
	}

	@Bean(destroyMethod = "close")
	public DataSource db2DataSource() throws HVWException {
		try {
			ComboPooledDataSource ds = new ComboPooledDataSource();
			// see https://www.mchange.com/projects/c3p0/
			ds.setDriverClass(driverClass);
			ds.setJdbcUrl(url);
			ds.setUser(credentialsConfig.getAppId());
			ds.setPassword(credentialsConfig.getAppIdPassword());
			ds.setInitialPoolSize(initialPoolSize);
			ds.setMinPoolSize(minPoolSize);
			ds.setMaxPoolSize(maxPoolSize);
			ds.setMaxIdleTime(maxIdleTime); // how long until to expire connections
			// ds.setMaxStatements(maxStatements);
			// ds.setMaxStatementsPerConnection(maxStatementsPerConn);
			ds.setMaxIdleTimeExcessConnections(maxIdleTimeExcessConn);
			/* similar to test connections before use */
			ds.setTestConnectionOnCheckout(validateConnections);
			ds.setPreferredTestQuery(validateSQL);
			ds.setAcquireIncrement(poolIncrement);
			ds.setIdleConnectionTestPeriod(idleConnectionTestPeriod);

			return ds;
		} catch (Exception e) {
			logger.log(Level.FATAL, () -> "ComboPooledDataSource creation failed");
			throw new HVWException(e.getMessage());
		}
	}

	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}

	@Bean
	public PlatformTransactionManager transactionManager(DataSource dataSource) {
		return new DataSourceTransactionManager(dataSource);
	}
}
