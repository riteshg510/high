package com.hmhs.hvwmid.model;

import java.util.List;

/**
 * Response for Excel file upload
 */
public class ExcelUploadResponse {
    
    private Integer excelId;
    private String excelName;
    private List<String> columnHeaders;
    private List<String> distinctFilenames;
    private String message;
    
    public ExcelUploadResponse() {
    }

    public Integer getExcelId() {
        return excelId;
    }

    public void setExcelId(Integer excelId) {
        this.excelId = excelId;
    }

    public String getExcelName() {
        return excelName;
    }

    public void setExcelName(String excelName) {
        this.excelName = excelName;
    }

    public List<String> getColumnHeaders() {
        return columnHeaders;
    }

    public void setColumnHeaders(List<String> columnHeaders) {
        this.columnHeaders = columnHeaders;
    }

    public List<String> getDistinctFilenames() {
        return distinctFilenames;
    }

    public void setDistinctFilenames(List<String> distinctFilenames) {
        this.distinctFilenames = distinctFilenames;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}