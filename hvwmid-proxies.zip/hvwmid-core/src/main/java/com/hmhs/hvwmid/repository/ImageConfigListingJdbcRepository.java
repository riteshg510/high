package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.enums.ImageConfigListingReqMapping;
import com.hmhs.hvwmid.model.ListingSearchRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSetMetaData;
import java.util.*;

@Repository
@RequiredArgsConstructor
public class ImageConfigListingJdbcRepository {

    private final NamedParameterJdbcTemplate jdbc;


    public List<Map<String, Object>> search(ListingSearchRequest req) {

        req.normalize();

        final String main = req.getMainSchema();
        final String batch = req.getBatchtblschema();

        // SELECT columns
        BeanWrapper bw = new BeanWrapperImpl(req);
        List<String> selectCols = new ArrayList<>();
        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            Object disp = bw.getPropertyValue(m.getDisplayField());
            if (disp instanceof Boolean && (Boolean) disp) {
                selectCols.add(m.getAlias() + "." + m.getColumnName() + " AS " + m.name());
            }
        }
        String selectSql = String.join(",", selectCols);

        // FROM + JOINs
        String from = ""
                + " FROM " + main + ".ENTTTLPR LPR "
                + " LEFT JOIN " + main + ".ENTTTAPR APR ON LPR.APPLIDCD = APR.APPLIDCD "
                + " LEFT JOIN " + main + ".ENTTTFRM FRM ON LPR.APPLIDCD = FRM.APPLIDCD "
                + " LEFT JOIN " + main + ".ENTTTFTB FTB ON LPR.APPLIDCD = FTB.APPLIDCD AND FRM.TABCD = FTB.TABCD "
                + " LEFT JOIN " + main + ".EYPTWRTT RTT ON LPR.APPLIDCD = RTT.APPLIDCD AND FRM.TRANTYPE = RTT.TRANTYPE "
                + " LEFT JOIN " + main + ".EYPTWUNT UNT ON LPR.APPLIDCD = UNT.APPLIDCD AND RTT.CATWORK = UNT.CATWORK AND RTT.USERPRM1 = UNT.USERPRM1 "
                + " LEFT JOIN " + main + ".EYPTWURC URC ON LPR.APPLIDCD = URC.APPLIDCD AND RTT.RCODE = URC.RCODE AND UNT.RUNIT = URC.RUNIT "
                + " LEFT JOIN " + main + ".T117A001 A01 ON LPR.APPLIDCD = A01.APPLIDCD AND FRM.FORMNUM = A01.FORMNUM "
                + " LEFT JOIN " + batch + ".BATCHTBL TBL ON A01.KEYVAL = TBL.BBATCH_ID "
                + " LEFT JOIN " + main + ".T222APRM PRM ON A01.DPK = PRM.PARM_KEY AND PRM.PARM_ID = 'IMIDPK' ";

        // WHERE + bind parameters
        StringBuilder where = new StringBuilder(" WHERE LPR.APPLIDCD IN (:applids) ");
        MapSqlParameterSource params = new MapSqlParameterSource();

        List<Integer> applids = (req.getUserApplids() == null || req.getUserApplids().isEmpty())
                ? List.of(-1) : req.getUserApplids();
        params.addValue("applids", applids);

        // Build WHERE from enum
        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            Object qv = bw.getPropertyValue(m.getQueryField());
            if (qv == null) continue;

            if (qv instanceof Long) {
                long v = (Long) qv;
                if (v != -1) {
                    String pname = "p_" + m.name();
                    where.append(" AND ").append(m.getAlias()).append(".").append(m.getColumnName())
                            .append(" = :").append(pname).append(" ");
                    params.addValue(pname, v);
                }
            } else {
                String raw = String.valueOf(qv);
                if (!hasText(raw)) continue;

                String sqlOp = operatorFor(Objects.toString(bw.getPropertyValue(m.getSearchStringField()), null));
                String wildcard = "LIKE".equalsIgnoreCase(sqlOp) ? "%" : "";

                String prepared = (raw == null ? "" : raw.trim()).toUpperCase() + wildcard;
                String pname = "p_" + m.name();

                where.append(" AND UPPER(").append(m.getAlias()).append(".").append(m.getColumnName())
                        .append(") ").append(sqlOp).append(" :").append(pname).append(" ");
                params.addValue(pname, prepared);
            }
        }

        int displayLimit = Math.min(req.getLimit() == null ? 5000 : req.getLimit(), 5000);
        int fetchRows    = displayLimit + 1;

        String sql = "SELECT DISTINCT " + selectSql + from + where + " FETCH FIRST " + fetchRows + " ROWS ONLY WITH UR";

        return jdbc.query(sql, params, (rs, i) -> {
            ResultSetMetaData md = rs.getMetaData();
            Map<String, Object> row = new LinkedHashMap<>();
            for (int c = 1; c <= md.getColumnCount(); c++) {
                row.put(md.getColumnLabel(c), rs.getObject(c));
            }
            return row;
        });
    }


    private static String operatorFor(String op) {
        if (op == null || op.isBlank()) return "=";
        String x = op.trim().toUpperCase(Locale.ROOT);
        if ("LIKE".equals(x))  return "LIKE";
        if ("EXACT".equals(x))  return "=";
        if ("NOT".equals(x))  return "<>";
        // "EXACT" or any unknown -> "="
        return "=";
    }



    private static boolean hasText(String s) {
        return s != null && !s.trim().isEmpty();
    }
}
