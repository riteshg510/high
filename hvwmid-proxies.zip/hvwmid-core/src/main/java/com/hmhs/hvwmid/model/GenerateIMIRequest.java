package com.hmhs.hvwmid.model;

import java.io.Serializable;
import java.util.List;

/**
 * Request model for Generate IMI Files endpoint
 */
public class GenerateIMIRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Integer excelId;
    private List<FileIdMapping> fileIdMappings;
    private List<SegmentMapping> mappings;
    private OutputConfig outputConfig;
    
    /**
     * Maps uploaded file REQUEST_IDs to Excel filenames
     */
    public static class FileIdMapping implements Serializable {
        private static final long serialVersionUID = 1L;
        
        private Integer fileId;  // REQUEST_ID from file upload
        private String excelFileName;  // Filename from Excel
        
        public Integer getFileId() {
            return fileId;
        }
        
        public void setFileId(Integer fileId) {
            this.fileId = fileId;
        }
        
        public String getExcelFileName() {
            return excelFileName;
        }
        
        public void setExcelFileName(String excelFileName) {
            this.excelFileName = excelFileName;
        }
    }
    
    /**
     * Defines segment mapping configuration
     */
    public static class SegmentMapping implements Serializable {
        private static final long serialVersionUID = 1L;
        
        private String segmentName;  // e.g., FID, DPK, etc.
        private String type;         // U (Unique), M (Mapped), C (Constant)
        private String value;        // Header name, constant value, or empty for unique
        
        public String getSegmentName() {
            return segmentName;
        }
        
        public void setSegmentName(String segmentName) {
            this.segmentName = segmentName;
        }
        
        public String getType() {
            return type;
        }
        
        public void setType(String type) {
            this.type = type;
        }
        
        public String getValue() {
            return value;
        }
        
        public void setValue(String value) {
            this.value = value;
        }
    }
    
    /**
     * Output configuration for IMI generation
     */
    public static class OutputConfig implements Serializable {
        private static final long serialVersionUID = 1L;
        
        private Integer documentsPerIMI = 25;  // Default 25
        private Integer filePriority = 99;     // Default 99
        
        public Integer getDocumentsPerIMI() {
            return documentsPerIMI;
        }
        
        public void setDocumentsPerIMI(Integer documentsPerIMI) {
            this.documentsPerIMI = documentsPerIMI;
        }
        
        public Integer getFilePriority() {
            return filePriority;
        }
        
        public void setFilePriority(Integer filePriority) {
            this.filePriority = filePriority;
        }
    }
    
    // Getters and Setters
    public Integer getExcelId() {
        return excelId;
    }
    
    public void setExcelId(Integer excelId) {
        this.excelId = excelId;
    }
    
    public List<FileIdMapping> getFileIdMappings() {
        return fileIdMappings;
    }
    
    public void setFileIdMappings(List<FileIdMapping> fileIdMappings) {
        this.fileIdMappings = fileIdMappings;
    }
    
    public List<SegmentMapping> getMappings() {
        return mappings;
    }
    
    public void setMappings(List<SegmentMapping> mappings) {
        this.mappings = mappings;
    }
    
    public OutputConfig getOutputConfig() {
        return outputConfig;
    }
    
    public void setOutputConfig(OutputConfig outputConfig) {
        this.outputConfig = outputConfig;
    }
}