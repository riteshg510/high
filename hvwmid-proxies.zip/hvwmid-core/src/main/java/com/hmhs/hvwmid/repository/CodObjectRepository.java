package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.TblCodObject;
import com.hmhs.hvwmid.entity.TblCodObjectId;
import jakarta.persistence.QueryHint;
import org.hibernate.jpa.AvailableHints;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.stream.Stream;


public interface CodObjectRepository extends JpaRepository<TblCodObject, TblCodObjectId> {
    List<TblCodObject> findByRequestIdOrderBySequenceNo(Integer requestId);

    @Query("select o from TblCodObject o where o.requestId = :rid order by o.sequenceNo")
    @QueryHints(@QueryHint(name = AvailableHints.HINT_FETCH_SIZE, value = "50"))
    Stream<TblCodObject> streamByRequestId(@Param("rid") Integer requestId);


    @Query(
            value = "SELECT OBJECT_SEGMENT, SEQUENCE_NO FROM T222_COD_OBJECT WHERE REQUEST_ID = :rid ORDER BY SEQUENCE_NO FOR FETCH ONLY WITH UR",
            nativeQuery = true
    )
    @QueryHints(@QueryHint(name = AvailableHints.HINT_FETCH_SIZE, value = "50"))
    Stream<Object[]> streamObjectSegmentsByRequestId(@Param("rid") Integer requestId);


    @Query(value = "SELECT SUM(OCTET_LENGTH(OBJECT_SEGMENT)) FROM T222_COD_OBJECT WHERE REQUEST_ID = :rid", nativeQuery = true)
    Long getDocumentSizeInBytes(@Param("rid") Integer requestId);
}
