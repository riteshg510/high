package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Oct 22, 2024
 */
@Entity
@Table(name = "T222_HVW_TABLES")
public class TblTables {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String tableId;
	private Short multipleSort;
	private Short resizeColumns;
	private String tableName;

	public String getTableId() {
		return tableId.toUpperCase();
	}

	public void setTableId(String tableId) {
		this.tableId = tableId.toUpperCase();
	}

	public Short getMultipleSort() {
		return multipleSort;
	}

	public void setMultipleSort(Short multipleSort) {
		this.multipleSort = multipleSort;
	}

	public Short getResizeColumns() {
		return resizeColumns;
	}

	public void setResizeColumns(Short resizeColumns) {
		this.resizeColumns = resizeColumns;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

}
