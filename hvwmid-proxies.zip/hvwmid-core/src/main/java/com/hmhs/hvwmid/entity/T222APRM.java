package com.hmhs.hvwmid.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "T222APRM")
@IdClass(T222APRMId.class)
public class T222APRM {

    @Id
    @Column(name = "PARM_ID", length = 8)
    private String parmId;

    @Id
    @Column(name = "PARM_KEY", length = 40)
    private String parmKey;

    @Column(name = "MODUSER", length = 8)
    private String modUser;

    @Column(name = "TIMECHGD")
    private Timestamp timeChgd;

    @Column(name = "PARM_DATA", length = 253)
    private String parmData;

    public String getParmId() {
        return parmId;
    }

    public void setParmId(final String parmId) {
        this.parmId = parmId;
    }

    public String getParmKey() {
        return parmKey;
    }

    public void setParmKey(final String parmKey) {
        this.parmKey = parmKey;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(final String modUser) {
        this.modUser = modUser;
    }

    public Timestamp getTimeChgd() {
        return timeChgd;
    }

    public void setTimeChgd(final Timestamp timeChgd) {
        this.timeChgd = timeChgd;
    }

    public String getParmData() {
        return parmData;
    }

    public void setParmData(final String parmData) {
        this.parmData = parmData;
    }
}