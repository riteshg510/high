package com.hmhs.hvwmid.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

@Service
public class CMODDeleteService extends CMODDocumentService {

    private static final Logger logger = LogManager.getLogger(CMODDeleteService.class);

    @Autowired
    private RestClientUtil restClientUtil;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public Map<String, Object> deleteDocument(final String documentToken, final String odFolder,
            final String authToken) {
        validateDocumentToken(documentToken);
        validateFolder(odFolder);

        // Prepare base payload for update
        final Map<String, Object> payload = prepareBasePayload(documentToken, odFolder);
        // Set DELETED property to 'Y' for soft delete
        final Map<String, Object> updateValues = new java.util.HashMap<>();
        updateValues.put("DELETED", "Y");
        payload.put("updateValues", updateValues);

        logger.info("Sending soft delete (update) request to URL: {} with payload: {}", updateUrl, payload);
        // Make the API call to update instead of delete
        org.springframework.http.ResponseEntity<?> response = restClientUtil.postRequest(updateUrl, authToken, payload);
        if (!response.getStatusCode().is2xxSuccessful()) {
            logger.error("Backend update service returned error status: {} with body: {}", response.getStatusCode(), response.getBody());
            throw HVWException.parseErrorResponse((org.springframework.http.ResponseEntity<Map>) response, "CMOD");
        }
        return (Map<String, Object>) response.getBody();
    }

    /**
     * Undeletes a document by setting the DELETED field back to blank
     * 
     * @param documentToken The document token to undelete
     * @param odFolder The folder containing the document
     * @param authToken Authentication token for the API call
     * @return Response from the update operation
     * @throws HVWException if validation fails or the update operation fails
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public Map<String, Object> undeleteDocument(final String documentToken, final String odFolder,
            final String authToken) {
        validateDocumentToken(documentToken);
        validateFolder(odFolder);

        // Prepare base payload for update
        final Map<String, Object> payload = prepareBasePayload(documentToken, odFolder);
        // Set DELETED property to blank for undelete
        final Map<String, Object> updateValues = new java.util.HashMap<>();
        updateValues.put("DELETED", ""); // Set to blank to undelete
        payload.put("updateValues", updateValues);

        logger.info("Sending undelete (update) request to URL: {} with payload: {}", updateUrl, payload);
        // Make the API call to update instead of delete
        org.springframework.http.ResponseEntity<?> response = restClientUtil.postRequest(updateUrl, authToken, payload);
        if (!response.getStatusCode().is2xxSuccessful()) {
            logger.error("Backend update service returned error status: {} with body: {}", response.getStatusCode(), response.getBody());
            throw HVWException.parseErrorResponse((org.springframework.http.ResponseEntity<Map>) response, "CMOD");
        }
        return (Map<String, Object>) response.getBody();
    }
}