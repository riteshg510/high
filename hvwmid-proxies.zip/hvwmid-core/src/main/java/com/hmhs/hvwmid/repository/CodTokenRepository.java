package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.TblCodToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public interface CodTokenRepository extends JpaRepository<TblCodToken, Integer> {

    @Transactional
    @Modifying
    @Query("DELETE FROM TblCodToken t WHERE t.timeCreate < :cutoff")
    void deleteByTimeCreateBefore(@Param("cutoff") LocalDateTime cutoff);

    // DB-level: find by userId and documentToken (excluding securityToken)
    List<TblCodToken> findByUserIdAndDocumentToken(String userId, String documentToken);

    // DB-level: find by requestId (excluding securityToken)
    Optional<TblCodToken> findByRequestId(Integer requestId);

    // Java-level filtering of securityToken
    default List<TblCodToken> findByUserIdAndDocumentTokenAndSecurityTokenSafe(String userId, String documentToken, String securityToken) {
        return findByUserIdAndDocumentToken(userId, documentToken)
            .stream()
            .filter(t -> securityToken.equals(t.getSecurityToken()))
            .collect(Collectors.toList());
    }

    default Optional<TblCodToken> findByRequestIdAndSecurityTokenSafe(Integer requestId, String securityToken) {
        return findByRequestId(requestId)
                .filter(t -> securityToken.equals(t.getSecurityToken()));
    }
}
