package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportLayout {
	private String layoutType;
	private String name;
	private String id;
	private String sid;
	private Boolean collapsible;
	private Boolean defaultCollapsed;
	private List<ReportChild> children;

	// Getters and Setters
	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public Boolean getCollapsible() {
		return collapsible;
	}

	public void setCollapsible(Boolean collapsible) {
		this.collapsible = collapsible;
	}

	public Boolean getDefaultCollapsed() {
		return defaultCollapsed;
	}

	public void setDefaultCollapsed(Boolean defaultCollapsed) {
		this.defaultCollapsed = defaultCollapsed;
	}

	public List<ReportChild> getChildren() {
		return children;
	}

	public void setChildren(List<ReportChild> children) {
		this.children = children;
	}
}
