package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Sept 16, 2024
 */
@Entity
@Table(name = "T222_HVW_FORMS")
public class TblForms {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String formId;
	private String formName;
	private String fileName;
	private String type;

	public String getFormId() {
		return formId.toUpperCase();
	}

	public void setFormId(String formId) {
		this.formId = formId.toUpperCase();
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
