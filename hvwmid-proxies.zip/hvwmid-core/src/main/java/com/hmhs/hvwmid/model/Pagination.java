package com.hmhs.hvwmid.model;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ramanjaneyulu Manam on Oct 18, 2024
 */
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Pagination {

	Integer pageNumber = 0;

	Integer pageSize = 10;

	String sort;

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

}
