package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T222ImgRmaHold;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface T222ImgRmaHoldRepository extends JpaRepository<T222ImgRmaHold, Integer> {
    @Query(value = "SELECT DISTINCT BPD_ID FROM T222_IMG_RMA_HOLD", nativeQuery = true)
    List<Integer> findDistinctBpdIds();

    Optional<T222ImgRmaHold> findByHoldCode(Integer holdCode);

    boolean existsByBpdIdAndHoldId(Integer bpdId, String holdId);

    boolean existsByHoldCode(Integer holdCode);

    void deleteByHoldCode(Integer holdCode);

}


