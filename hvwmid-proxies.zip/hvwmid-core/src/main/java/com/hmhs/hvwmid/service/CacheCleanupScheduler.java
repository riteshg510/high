package com.hmhs.hvwmid.service;


import com.hmhs.hvwmid.repository.CodTokenRepository;
import com.hmhs.hvwmid.repository.ImgTokenRepository;
import com.hmhs.hvwmid.repository.TblHvwStatusRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class CacheCleanupScheduler {

    /**
     * How many days to keep tokens around; you can override in application.yml:
     *   cleanup.token.retention-days=7
     */
    @Value("${cleanup.token.retention-days:7}")
    private long retentionDays;

    /**
     * Repository for CodToken entities.
     */
    private final CodTokenRepository tokenRepo;
    private final ImgTokenRepository imgTokenRepo;
    private final TblHvwStatusRepository hvwStatusRepository;

    private static final Logger logger = LogManager.getLogger(CacheCleanupScheduler.class);



    @Autowired
    public CacheCleanupScheduler(CodTokenRepository tokenRepo, ImgTokenRepository imgTokenRepo, TblHvwStatusRepository hvwStatusRepository) {
        this.tokenRepo = tokenRepo;
        this.imgTokenRepo = imgTokenRepo;
        this.hvwStatusRepository = hvwStatusRepository;
    }

    /**
     * Runs daily at 02:00 AM Eastern US time.
     * Deletes all CodToken entries older than now minus retentionDays.
     */
    @Scheduled(
            cron = "0 0 2 * * *",
            zone = "America/New_York"
    )
    public void cleanupOldTokens() {
        LocalDateTime cutoff = LocalDateTime.now()
                .minusDays(retentionDays);
        tokenRepo.deleteByTimeCreateBefore(cutoff);
        logger.info("Cleaned up tokens before {}", cutoff);
    }


    /**
     * Runs daily at 02:00 AM Eastern US time.
     * Deletes all CodToken entries older than now minus retentionDays.
     */
    @Scheduled(
            cron = "0 0 2 * * *",
            zone = "America/New_York"
    )
    public void cleanupOldTokensImg() {
        LocalDateTime cutoff = LocalDateTime.now()
                .minusDays(retentionDays);
        imgTokenRepo.deleteByTimeCreateBefore(cutoff);
        logger.info("Cleaned up tokens before {}", cutoff);
    }


    @Scheduled(
            cron = "0 0 2 * * *",
            zone = "America/New_York"
    )
    public void cleanupOldHvwStatus() {
        LocalDateTime cutoff = LocalDateTime.now()
                .minusDays(retentionDays);
        hvwStatusRepository.deleteByTimeCreateBefore(cutoff);
        logger.info("Cleaned up tokens before {}", cutoff);
    }

}
