package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T222ImgRmaPolicyHold;
import com.hmhs.hvwmid.entity.T222ImgRmaPolicyHoldId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface T222ImgRmaPolicyHoldRepository extends JpaRepository<T222ImgRmaPolicyHold, T222ImgRmaPolicyHoldId> {
    List<T222ImgRmaPolicyHold> findByPolicyCodeAndBpdId(Integer policyCode, Integer bpdId);

    void deleteByPolicyCodeAndBpdIdAndHoldCodeIn(Integer policyCode, Integer bpdId, Collection<Integer> holdCodes);

    void deleteByHoldCode(Integer holdCode);

    void deleteByPolicyCode(Integer policyCode);

    @Query(
            value = "SELECT HOLD_CODE FROM T222_IMG_RMA_POLICY_HOLD WHERE BPD_ID in (:bpdId)",
            nativeQuery = true
    )
    Set<Integer> findHoldCodesByBpdId(@Param("bpdId") List<Integer> bpdId);

}
