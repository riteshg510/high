package com.hmhs.hvwmid.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hmhs.hvwmid.model.ExcelUploadResponse;
import com.hmhs.hvwmid.model.GenerateIMIRequest;
import com.hmhs.hvwmid.model.GenerateIMIResponse;
import com.hmhs.hvwmid.model.IMIGeneatorData;
import com.hmhs.hvwmid.model.IMIGeneratorOutput;

/**
 * Service interface for IMI file generation operations
 */
public interface IMIFileGeneratorService {

    /**
     * Initializes the IMI File Generator on load
     * 
     * @param authToken authentication token for user validation
     * @return IMIGeneatorData containing configuration information
     * @throws Exception if initialization fails
     */
    IMIGeneatorData imiFileGeneratorOnLoad(String authToken) throws Exception;

    /**
     * Uploads and processes Excel file for IMI generation
     * 
     * @param file Excel file to upload
     * @param documentCount Documents per IMI (1-2000)
     * @param filePriority File priority (1-100)
     * @param userId User ID from JWT token
     * @return ExcelUploadResponse with file metadata and parsed data
     * @throws Exception if upload fails
     */
    ExcelUploadResponse uploadExcelFile(MultipartFile file, Integer documentCount, 
                                      Integer filePriority, String userId) throws Exception;

    /**
     * Validates and processes the selected Excel file
     * 
     * @param fileData map containing file information
     * @return map containing validation results and file headers
     */
    Map<String, Object> selectFile(Map<String, String> fileData);

    /**
     * Retrieves distinct filenames from uploaded Excel by REQUEST_ID
     * 
     * @param excelRequestId REQUEST_ID of the uploaded Excel
     * @param userId User ID for validation
     * @return List of distinct filenames from first column
     * @throws Exception if retrieval fails
     */
    List<String> getDistinctFilenamesFromExcel(Integer excelRequestId, String userId) throws Exception;

    /**
     * Creates IMI files from the processed Excel data
     * 
     * @param fileData map containing file processing parameters
     * @return list of IMIGeneratorOutput objects with processing results
     */
    List<IMIGeneratorOutput> createIMIFile(Map<String, Object> fileData);
    
    /**
     * Generate IMI files based on uploaded Excel and images
     * @param request The generate IMI request containing Excel ID, file mappings, and configuration
     * @param userId The user ID from JWT token
     * @return Response with generated IMI files and summary
     * @throws Exception if generation fails
     */
    GenerateIMIResponse generateIMIFiles(GenerateIMIRequest request, String userId) throws Exception;


    Map<String, String> getStringParmData(String parmid) throws Exception;

}