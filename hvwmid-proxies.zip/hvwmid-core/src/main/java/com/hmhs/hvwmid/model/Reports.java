package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ramanjaneyulu Manam on Dec 3, 2024
 */
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Reports {

	private String id;
	private String actionFolderName;
	private String actionFolderDescription;
	private String cmodAction;
	private String cmodFolderName;
	private String cmodFolderDescription;
	private List<ReportAction> actions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getActionFolderName() {
		return actionFolderName;
	}

	public void setActionFolderName(String actionFolderName) {
		this.actionFolderName = actionFolderName;
	}

	public String getActionFolderDescription() {
		return actionFolderDescription;
	}

	public void setActionFolderDescription(String actionFolderDescription) {
		this.actionFolderDescription = actionFolderDescription;
	}

	public String getCmodAction() {
		return cmodAction;
	}

	public void setCmodAction(String cmodAction) {
		this.cmodAction = cmodAction;
	}

	public String getCmodFolderName() {
		return cmodFolderName;
	}

	public void setCmodFolderName(String cmodFolderName) {
		this.cmodFolderName = cmodFolderName;
	}

	public String getCmodFolderDescription() {
		return cmodFolderDescription;
	}

	public void setCmodFolderDescription(String cmodFolderDescription) {
		this.cmodFolderDescription = cmodFolderDescription;
	}

	public List<ReportAction> getActions() {
		return actions;
	}

	public void setActions(List<ReportAction> actions) {
		this.actions = actions;
	}

}
