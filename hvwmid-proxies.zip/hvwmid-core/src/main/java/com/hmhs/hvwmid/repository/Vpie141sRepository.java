package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.Vpie141s;

/**
 * Repository for VPIE141S table operations.
 * Handles RACF/ACF2 security information queries for CMOD applications.
 */
@Repository
public interface Vpie141sRepository extends JpaRepository<Vpie141s, String> {

    /**
     * Retrieves VPIE141S security information for specific ACF2 resources.
     * Used to get RACF entity details and role descriptions for applications.
     * 
     * @param acf2Resources List of ACF2 resource identifiers
     * @return List of VPIE141S entities matching the resources
     */
    @Query("SELECT v FROM Vpie141s v WHERE v.acf2Resource IN (:acf2Resources)")
    List<Vpie141s> findByAcf2ResourceIn(@Param("acf2Resources") List<String> acf2Resources);

    /**
     * Retrieves VPIE141S information with trimmed fields for legacy compatibility.
     * Matches the original query: SELECT ACF2_STRING, TRIM(APPLICATION) AS APPLICATION, 
     * TRIM(ROLE_DESCRIPTION) AS ROLE_DESCRIPTION, DATE_MODIFIED FROM VPIE141S WHERE ACF2_RESOURCE IN (...)
     * 
     * @param acf2Resources List of ACF2 resource identifiers
     * @return Array of Object[] containing [acf2String, application, roleDescription, dateModified]
     */
    @Query(value = "SELECT ACF2_STRING, TRIM(APPLICATION) AS APPLICATION, " +
                   "TRIM(ROLE_DESCRIPTION) AS ROLE_DESCRIPTION, DATE_MODIFIED " +
                   "FROM VPIE141S WHERE ACF2_RESOURCE IN (:acf2Resources)", nativeQuery = true)
    List<Object[]> getVPIESecurityInfoRaw(@Param("acf2Resources") List<String> acf2Resources);

    /**
     * Retrieves all distinct ACF2 resources in the system.
     * 
     * @return List of distinct ACF2 resource identifiers
     */
    @Query("SELECT DISTINCT v.acf2Resource FROM Vpie141s v ORDER BY v.acf2Resource")
    List<String> findDistinctAcf2Resources();

    /**
     * Finds VPIE141S entries by ACF2 string pattern.
     * Used for application to RACF entity mapping.
     * 
     * @param acf2String ACF2 string to search for
     * @return List of matching VPIE141S entities
     */
    @Query("SELECT v FROM Vpie141s v WHERE v.acf2String = :acf2String")
    List<Vpie141s> findByAcf2String(@Param("acf2String") String acf2String);

    /**
     * Finds VPIE141S entries by application name pattern.
     * 
     * @param application Application name to search for
     * @return List of matching VPIE141S entities
     */
    @Query("SELECT v FROM Vpie141s v WHERE UPPER(v.application) LIKE UPPER(:application)")
    List<Vpie141s> findByApplicationContaining(@Param("application") String application);

    /**
     * Checks if an ACF2 resource exists in the VPIE141S table.
     * Used to identify missing RACF entries.
     * 
     * @param acf2Resource ACF2 resource identifier to check
     * @return true if resource exists, false otherwise
     */
    @Query("SELECT COUNT(v) > 0 FROM Vpie141s v WHERE v.acf2Resource = :acf2Resource")
    boolean existsByAcf2Resource(@Param("acf2Resource") String acf2Resource);
}