package com.hmhs.hvwmid.model;

import java.time.LocalDateTime;

/**
 * Result of file storage operation
 */
public class FileStorageResult {
    
    private Integer requestId;
    private String fileName;
    private String documentType;
    private Integer documentSize;
    private Integer documentPages;
    private String userId;
    private LocalDateTime timeCreated;
    private String status;
    
    public FileStorageResult() {
    }

    public FileStorageResult(Integer requestId, String fileName, String documentType, 
                           Integer documentSize, Integer documentPages, String userId, 
                           LocalDateTime timeCreated, String status) {
        this.requestId = requestId;
        this.fileName = fileName;
        this.documentType = documentType;
        this.documentSize = documentSize;
        this.documentPages = documentPages;
        this.userId = userId;
        this.timeCreated = timeCreated;
        this.status = status;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public Integer getDocumentSize() {
        return documentSize;
    }

    public void setDocumentSize(Integer documentSize) {
        this.documentSize = documentSize;
    }

    public Integer getDocumentPages() {
        return documentPages;
    }

    public void setDocumentPages(Integer documentPages) {
        this.documentPages = documentPages;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeCreated() {
        return timeCreated;
    }

    public void setTimeCreated(LocalDateTime timeCreated) {
        this.timeCreated = timeCreated;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}