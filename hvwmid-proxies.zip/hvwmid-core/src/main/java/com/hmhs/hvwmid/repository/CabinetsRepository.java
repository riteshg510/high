package com.hmhs.hvwmid.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hmhs.hvwmid.entity.TblCabinets;

/**
 * @author Ramanjaneyulu Manam on Nov 20, 2024
 */
@Repository
public interface CabinetsRepository extends CrudRepository<TblCabinets, String> {

	/**
	 * @param departmentId
	 * @return
	 */
	List<TblCabinets> getCabinetsByDepartmentIdOrderByCabinetNameAsc(String departmentId);

	/**
	 * @param cabinetsNamesList
	 * @return
	 */
	List<TblCabinets> getCabinetsByCabinetNameIn(List<String> cabinetsNamesList);

	/**
	 * @param userCabinetIds
	 * @return
	 */
	List<TblCabinets> getCabinetsByCabinetIdIn(List<String> userCabinetIds);

	/**
	 * @param userCabinetIds
	 * @return
	 */
	@Query(value = "SELECT DEPARTMENT_ID FROM T222_HVW_CABINETS WHERE CABINET_ID IN ? ", nativeQuery = true)
	List<String> getDepartmentIdsByUserCabinets(List<String> userCabinetIds);

	/**
	 * @param cabinetId
	 */
	@Modifying
    @Transactional
    @Query(value ="UPDATE T222_HVW_CABINETS SET LAST_USED_DATE = ? WHERE CABINET_ID = ?", nativeQuery = true)
	void updateCabinetsTable(LocalDateTime lastUsedDate, String cabinetId);

}
