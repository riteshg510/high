package com.hmhs.hvwmid.model;

import jakarta.validation.constraints.NotBlank;

import java.util.List;

public class CoverSheetDepartmentDTO {
    private Integer deptId;
    private String description;
    @NotBlank(message = "maintGroup name is required")
    private String maintGroup;
    @NotBlank(message = "printGroup name is required")
    private String printGroup;
    private List<CoverSheetApplicationDTO> departments;
    private Boolean canMaintain = false;

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMaintGroup() {
        return maintGroup;
    }

    public void setMaintGroup(String maintGroup) {
        this.maintGroup = maintGroup;
    }

    public String getPrintGroup() {
        return printGroup;
    }

    public void setPrintGroup(String printGroup) {
        this.printGroup = printGroup;
    }

    public List<CoverSheetApplicationDTO> getDepartments() {
        return departments;
    }

    public void setDepartments(List<CoverSheetApplicationDTO> departments) {
        this.departments = departments;
    }

    public Boolean getCanMaintain() {
        return canMaintain;
    }

    public void setCanMaintain(Boolean canMaintain) {
        this.canMaintain = canMaintain;
    }
}
