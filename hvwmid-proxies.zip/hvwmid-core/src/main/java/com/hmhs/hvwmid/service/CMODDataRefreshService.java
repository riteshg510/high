package com.hmhs.hvwmid.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.model.CMODApplicationAccessInfo;
import com.hmhs.hvwmid.repository.Vpie141sRepository;
import com.hmhs.hvwmid.entity.Vpie141s;

import static com.hmhs.hvwmid.constants.HVWConstants.MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME;
import static org.springframework.util.StringUtils.hasText;

/**
 * Spring Boot service for CMOD data refresh functionality.
 * Manages CMOD folder, application, and client code data by parsing XML exports
 * and populating application RACF details.
 * 
 * This service replaces the legacy singleton pattern with Spring's dependency injection.
 */
@Service
public class CMODDataRefreshService {

    private static final Logger logger = LogManager.getLogger(CMODDataRefreshService.class);

    private static final String CMADDIDA = "CMADDIDA";

    @Value("${app.cmod.arsxml.cod.directory:}")
    private String exportARSXMLDirectory;


    private final ImageParmDataService imageParmDataService;
    private final Vpie141sRepository vpie141sRepository;
    private final T222APRMRepository aprmRepository;

    private long lastRun = 0;

    // Key - CMOD Folder, Value - Map containing Key - AG, List of Applications mapped to this AG in the folder
    private Map<String, Map<String, Set<String>>> cmodFolderMap;
    // Key - Application, Value - CMODApplicationAccessInfo
    private TreeMap<String, CMODApplicationAccessInfo> cmodApplicationMap;
    // Client Codes (e.g. HMRK, NDAK, MINN, WYOM, IBC1..)
    private Set<String> cmodClientCodes = null;

    public CMODDataRefreshService(ImageParmDataService imageParmDataService, Vpie141sRepository vpie141sRepository, T222APRMRepository aprmRepository) {
        this.imageParmDataService = imageParmDataService;
        this.vpie141sRepository = vpie141sRepository;
        this.aprmRepository = aprmRepository;

        cmodFolderMap = new TreeMap<>();
        cmodApplicationMap = new TreeMap<>();
        cmodClientCodes = new HashSet<>();
    }

    /**
     * This method is used to refresh cmod data.
     */
    @PostConstruct
    public void refreshCMODData() {
        lastRun = System.currentTimeMillis();
        Map<String, Map<String, Set<String>>> cmodFolderTempMap = new TreeMap<>();
        TreeMap<String, CMODApplicationAccessInfo> cmodApplicationTempMap = new TreeMap<>();
        
        parseFolderApplicationAGXML(cmodFolderTempMap, cmodApplicationTempMap);
        populateApplicationRACFDetails(cmodApplicationTempMap);
        
        cmodFolderMap = cmodFolderTempMap;
        cmodApplicationMap = cmodApplicationTempMap;
        cmodClientCodes = getCMODClntCds(cmodApplicationTempMap);
        
        logger.info("Refreshed CMOD Data");
    }

    /**
     * This method will populate the Application RACF Details
     * 
     * @param cmodApplicationTempMap
     */
    private void populateApplicationRACFDetails(TreeMap<String, CMODApplicationAccessInfo> cmodApplicationTempMap) {
        try {
            // Get Applications and its RACF entity from parameter data
            Map<String, String> racfClassMap = aprmRepository.getParmDataAsMap(CMADDIDA);
            if (racfClassMap == null || racfClassMap.isEmpty()) {
                logger.warn("No RACF class mapping found for parameter ID: {}", CMADDIDA);
                return;
            }
            
            // Getting RACF Classes from PARM table
            String racfClsStr = buildRACFClsInClause(racfClassMap);
            
            // Use CMOD Security Repository to get RACF entity data
            // Note: This is a simplified version - you may need to adapt based on actual repository methods
            Map<String, CMODApplicationAccessInfo> racfEntityMap = getRACFEntityData(racfClsStr);
            
            for (Map.Entry<String, CMODApplicationAccessInfo> racf : racfEntityMap.entrySet()) {
                CMODApplicationAccessInfo appRacfEntDet = racf.getValue();
                String racfEntity = appRacfEntDet.getAcf2String();
                racfEntity = StringUtils.stripEnd(racfEntity, "*");
                
                SortedMap<String, CMODApplicationAccessInfo> applications = getByPrefix(cmodApplicationTempMap, racfEntity);
                for (Map.Entry<String, CMODApplicationAccessInfo> map : applications.entrySet()) {
                    CMODApplicationAccessInfo odApp = map.getValue();
                    odApp.setAcf2String(racfEntity);
                    odApp.setVpieApplication(appRacfEntDet.getVpieApplication());
                    odApp.setVpieRoleDescription(appRacfEntDet.getVpieRoleDescription());
                }
            }
            logger.debug("populateApplicationRACFDetails executed successfully");
        } catch (Exception e) {
            logger.error("Exception in populating the Application RACF Entity Details", e);
        }
    }

    /**
     * Gets RACF entity data from VPIE141S table using Spring repository.
     * Creates a map of RACF entities sorted in ascending order for prefix logic.
     * 
     * @param racfClsStr Comma-separated list of RACF classes to query
     * @return Map of RACF entity data with ACF2 string as key
     */
    private Map<String, CMODApplicationAccessInfo> getRACFEntityData(String racfClsStr) {
        // Creating a TreeMap because the RACF entities should be sorted in ascending for the prefix logic to work
        Map<String, CMODApplicationAccessInfo> racfEntityMap = new TreeMap<>();
        
        try {
            // Parse the comma-separated RACF classes string into a list
            List<String> racfClasses = Arrays.asList(racfClsStr.split(","))
                .stream()
                .map(String::trim)
                .map(s -> s.replaceAll("'", "")) // Remove quotes if present
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toList());
            
            if (racfClasses.isEmpty()) {
                logger.warn("No RACF classes provided for query");
                return racfEntityMap;
            }
            
            // Query VPIE141S using the repository
            List<Vpie141s> vpieEntities = vpie141sRepository.findByAcf2ResourceIn(racfClasses);
            
            for (Vpie141s vpieEntity : vpieEntities) {
                String racfEntity = vpieEntity.getAcf2String();
                if (hasText(racfEntity)) {
                    racfEntity = racfEntity.trim();
                    Date applicationDate = Date.from(vpieEntity.getDateModified().atZone(ZoneId.systemDefault()).toInstant());
                    
                    // Check if we already have this entity and if the current one is newer
                    if (racfEntityMap.containsKey(racfEntity)) {
                        CMODApplicationAccessInfo existingApp = racfEntityMap.get(racfEntity);
                        if (applicationDate.before(existingApp.getModifiedDate())) {
                            continue; // Skip this older entry
                        }
                    }
                    
                    CMODApplicationAccessInfo odApplication = new CMODApplicationAccessInfo();
                    odApplication.setAcf2String(racfEntity);
                    odApplication.setVpieApplication(vpieEntity.getApplication() != null ? vpieEntity.getApplication().trim() : "");
                    odApplication.setVpieRoleDescription(vpieEntity.getRoleDescription() != null ? vpieEntity.getRoleDescription().trim() : "");
                    odApplication.setModifiedDate(applicationDate);
                    racfEntityMap.put(racfEntity, odApplication);
                }
            }
            
            logger.debug("getRACFEntityData executed successfully, retrieved {} entries", racfEntityMap.size());
        } catch (Exception e) {
            logger.error("Exception in getRACFEntityData", e);
        }
        
        return racfEntityMap;
    }

    /**
     * This method will get all the CMOD client codes
     * 
     * @param cmodApplicationMap
     * @return Set of client codes
     */
    private Set<String> getCMODClntCds(TreeMap<String, CMODApplicationAccessInfo> cmodApplicationMap) {
        Set<String> clntCdSet = new HashSet<>();
        for (Map.Entry<String, CMODApplicationAccessInfo> applicationMap : cmodApplicationMap.entrySet()) {
            String[] tokens = StringUtils.split(applicationMap.getKey(), '-');
            if (tokens.length > 2) {
                String clientCode = tokens[1];
                clntCdSet.add(clientCode);
            }
        }
        return clntCdSet;
    }

    /**
     * This method will get the RACF Entity for the specified application name.
     * 
     * @param applicationName
     * @return CMODApplicationAccessInfo or null if not found
     */
    public CMODApplicationAccessInfo getRACFEntityForApplication(String applicationName) {
        if (!cmodApplicationMap.isEmpty() && cmodApplicationMap.containsKey(applicationName)) {
            return cmodApplicationMap.get(applicationName);
        }
        return null;
    }

    /**
     * This method will get the AG and Application for the specified folder name.
     * 
     * @param folderName
     * @return Map of AG to Applications or null if not found
     */
    public Map<String, Set<String>> getCMODFolderDetails(String folderName) {
        refreshCMODFolderMap();
        if (!cmodFolderMap.isEmpty() && cmodFolderMap.containsKey(folderName)) {
            return cmodFolderMap.get(folderName);
        }
        return null;
    }

    /**
     * This method will refresh CMOD Data if cmodFolderMap is empty
     */
    private void refreshCMODFolderMap() {
        if (cmodFolderMap.isEmpty()) {
            long interval = System.currentTimeMillis() - lastRun;
            // If the CMOD folder map is empty and it is more than 60 minutes since the last run or there is no previous run then call the refresh CMOD Data.
            if (lastRun == 0 || TimeUnit.MILLISECONDS.toMinutes(interval) > 60) {
                logger.info("Folder Details Empty, refreshing CMOD Data");
                refreshCMODData();
            }
        }
    }

    /**
     * This method will return all CMOD Folder details
     * 
     * @return Map of all CMOD folder details
     */
    public Map<String, Map<String, Set<String>>> getAllCMODFolderDetails() {
        refreshCMODFolderMap();
        return cmodFolderMap;
    }

    /**
     * This method will get the CMOD client codes
     * 
     * @return Set of CMOD client codes
     */
    public Set<String> getCMODClientCodes() {
        refreshCMODFolderMap();
        return cmodClientCodes;
    }

    /**
     * This method will construct the racf classes in clause
     * 
     * @param racfClassMap
     * @return String representation of RACF classes for SQL IN clause
     */
    private String buildRACFClsInClause(Map<String, String> racfClassMap) {
        StringBuilder racfClsBuilder = new StringBuilder();
        for (Map.Entry<String, String> racfCls : racfClassMap.entrySet()) {
            String racf = racfCls.getKey().trim();
            if (StringUtils.isNotBlank(racf)) {
                racfClsBuilder.append("'");
                racfClsBuilder.append(racf);
                racfClsBuilder.append("'");
                racfClsBuilder.append(", ");
            }
        }
        return StringUtils.removeEnd(racfClsBuilder.toString(), ", ");
    }

    /**
     * This method will return a sub map for which the keys starting with the specified prefix
     * 
     * @param myMap
     * @param prefix
     * @return SortedMap of applications with matching prefix
     */
    private SortedMap<String, CMODApplicationAccessInfo> getByPrefix(NavigableMap<String, CMODApplicationAccessInfo> myMap, String prefix) {
        return myMap.subMap(prefix, prefix + Character.MAX_VALUE);
    }

    /**
     * This method will parse Folder AG Application XML
     * 
     * @param cmodFolderTempMap
     * @param cmodApplicationTempMap
     */
    private void parseFolderApplicationAGXML(
            Map<String, Map<String, Set<String>>> cmodFolderTempMap,
            TreeMap<String, CMODApplicationAccessInfo> cmodApplicationTempMap) {
        logger.debug("Starting parseFolderApplicationAGXML");
        
        XMLInputFactory factory = XMLInputFactory.newInstance();
        
        // Get filename from parameter data or use default
        String mfFoldAGAppExportFN = imageParmDataService.getParmDataByKeyByCmodbase(
                MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME, MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME);
        
        // Use injected directory or get from parameter data
        String xmlDirectory = StringUtils.isNotBlank(exportARSXMLDirectory) ? 
            exportARSXMLDirectory : 
            imageParmDataService.getParmDataByKeyByCODBase("CMOD_ARSXML_COD_DIRECTORY", HVWConstants.CMOD_ARSXML_COD_DIRECTORY);
            
        if (StringUtils.isBlank(xmlDirectory)) {
            logger.error("CMOD ARSXML directory not configured");
            return;
        }
        
        File folderApplicationExportXML = new File(xmlDirectory + File.separator + mfFoldAGAppExportFN);
        XMLStreamReader reader = null;
        
        if (folderApplicationExportXML.exists()) {
            logger.info("Parsing Folder Permission ARSXML");
            try (InputStream stream = new FileInputStream(folderApplicationExportXML)) {
                reader = factory.createXMLStreamReader(stream, "UTF-8");
                
                while (reader.hasNext()) {
                    reader.next();
                    // Reading each folder
                    if (reader.isStartElement() && "folder".equalsIgnoreCase(reader.getLocalName())) {
                        String folderName = reader.getAttributeValue(null, "name");
                        Map<String, Set<String>> applicationGroupMap = new HashMap<>();
                        cmodFolderTempMap.put(folderName, applicationGroupMap);
                        
                        while (reader.hasNext()) {
                            reader.next();
                            // Reading all application groups mapped to that folder
                            if (reader.isStartElement() && "applicationGroup".equalsIgnoreCase(reader.getLocalName())) {
                                String applicationGroupName = reader.getAttributeValue(null, "name");
                                Set<String> applicationSet = new TreeSet<>();
                                applicationGroupMap.put(applicationGroupName, applicationSet);
                                
                                while (reader.hasNext()) {
                                    reader.next();
                                    // Reading all applications mapped to that folder
                                    if (reader.isStartElement() && "application".equalsIgnoreCase(reader.getLocalName())) {
                                        String applicationName = reader.getAttributeValue(null, "name");
                                        applicationSet.add(applicationName);
                                        cmodApplicationTempMap.put(applicationName, new CMODApplicationAccessInfo());
                                    } else if (reader.isEndElement() && "applicationGroup".equalsIgnoreCase(reader.getLocalName())) {
                                        break;
                                    }
                                }
                            } else if (reader.isEndElement() && "folder".equalsIgnoreCase(reader.getLocalName())) {
                                break;
                            }
                        }
                    }
                }
                
                logger.info("parseFolderApplicationAGXML Successful, Folder Count: {}; Application count:{}", cmodFolderTempMap.size(), cmodApplicationTempMap.size());
                    
            } catch (Exception e) {
                logger.error("Failed to Parse Folder AG Application XML", e);
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (XMLStreamException e) {
                        logger.error("parseFolderApplicationAGXML: Failed to close XMLStreamReader", e);
                    }
                }
            }
        } else {
            logger.warn("Folder Application Export XML not found at: {}", folderApplicationExportXML.getAbsolutePath());
        }
        logger.debug("Finish parseFolderApplicationAGXML");
    }
}