package com.hmhs.hvwmid.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.entity.TblUserCabinets;
import com.hmhs.hvwmid.repository.UserCabinetRepository;

@Service
public class UserCabinetService {

	@Autowired
	private UserCabinetRepository userCabinetRepository;

	/**
	 * Add cabinet for a user.
	 */
	public void addCabinetForUser(String userId, String cabinetId) {
		TblUserCabinets userCabinet = new TblUserCabinets();
		userCabinet.setUserId(userId);
		userCabinet.setCabinetId(cabinetId);
		userCabinet.setUserCabinetId(cabinetId + "_" + userId);
		userCabinetRepository.save(userCabinet);
	}

	/**
	 * Get cabinets for a specific user.
	 */
	public List<String> getUserCabinets(String userId) {
		return userCabinetRepository.findCabinetIdsByUserId(userId);
	}

	public void removeCabinetForUser(String userId, String cabinetId) {
		Optional<TblUserCabinets> userCabinet = userCabinetRepository.findByUserIdAndCabinetId(userId, cabinetId);
		if (userCabinet.isPresent()) {
			userCabinetRepository.delete(userCabinet.get());
		} else {
			throw new IllegalArgumentException("Cabinet not found for user: " + userId + ", cabinetId: " + cabinetId);
		}
	}

}
