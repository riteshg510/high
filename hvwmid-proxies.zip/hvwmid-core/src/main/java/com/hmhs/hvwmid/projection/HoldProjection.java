package com.hmhs.hvwmid.projection;

public interface HoldProjection {
    Integer getBpdId();

    Integer getHoldCode();

    String getHoldId();

    String getHoldDateBegin();

    String getHoldDateEnd();

    String getHoldEditFlag();

    String getHoldEditPgmName();

    String getModUser();

    String getModDate();

    String getHoldDescription();
}
