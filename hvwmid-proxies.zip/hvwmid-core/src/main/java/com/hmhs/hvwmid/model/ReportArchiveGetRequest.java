package com.hmhs.hvwmid.model;

import java.util.Map;

public class ReportArchiveGetRequest {

    private String documentToken;
    private String userId;
    private String proxyUserId;
    private String translateType;
    private String responseDataFolder;
    private String odFolder;
    private String autoShow = "N";
    private String beginDate;
    private String endDate;
    private String searchCriteria = "AND";
    private String searchInputExit;
    private String resultSetOutputExit;
    private Map<String, Object> folderSearchCriteria;

    public String getDocumentToken() {
        return documentToken;
    }

    public void setDocumentToken(String documentToken) {
        this.documentToken = documentToken;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getProxyUserId() {
        return proxyUserId;
    }

    public void setProxyUserId(String proxyUserId) {
        this.proxyUserId = proxyUserId;
    }

    public String getTranslateType() {
        return translateType;
    }

    public void setTranslateType(String translateType) {
        this.translateType = translateType;
    }

    public String getResponseDataFolder() {
        return responseDataFolder;
    }

    public void setResponseDataFolder(String responseDataFolder) {
        this.responseDataFolder = responseDataFolder;
    }

    public String getOdFolder() {
        return odFolder;
    }

    public void setOdFolder(String odFolder) {
        this.odFolder = odFolder;
    }

    public String getAutoShow() {
        return autoShow;
    }

    public void setAutoShow(String autoShow) {
        this.autoShow = autoShow;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getSearchCriteria() {
        return searchCriteria;
    }

    public void setSearchCriteria(String searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    public String getSearchInputExit() {
        return searchInputExit;
    }

    public void setSearchInputExit(String searchInputExit) {
        this.searchInputExit = searchInputExit;
    }

    public String getResultSetOutputExit() {
        return resultSetOutputExit;
    }

    public void setResultSetOutputExit(String resultSetOutputExit) {
        this.resultSetOutputExit = resultSetOutputExit;
    }

    public Map<String, Object> getFolderSearchCriteria() {
        return folderSearchCriteria;
    }

    public void setFolderSearchCriteria(Map<String, Object> folderSearchCriteria) {
        this.folderSearchCriteria = folderSearchCriteria;
    }
}
