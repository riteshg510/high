package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.util.Objects;

public class T117ImgCoverSheetOverrideId implements Serializable {


    private Integer application;
    private String name;
    private Integer sequence;


    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof T117ImgCoverSheetOverrideId)) return false;
        T117ImgCoverSheetOverrideId that = (T117ImgCoverSheetOverrideId) o;
        return Objects.equals(application, that.application) &&
                Objects.equals(name, that.name) &&
                Objects.equals(sequence, that.sequence);
    }

    @Override
    public int hashCode() {
        return Objects.hash(application, name, sequence);
    }
}
