package com.hmhs.hvwmid.entity;

import java.sql.Timestamp;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "T222_IMG_OBJECT")
public class TblImgObject {

//    @Id
//    @Column(name = "REQUEST_ID", nullable = false)
//    private Integer requestId;
//    @Column(name = "SEQUENCE_NO", nullable = false)
//    private Integer sequenceNo;


    @EmbeddedId
    private TblImgObjectId id;

    @Column(name = "TIME_CREATE", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp timeCreate;

    @Column(name = "OBJECT_SEGMENT", columnDefinition = "VARCHAR(31691) FOR BIT DATA", nullable = false)
    private byte[] objectSegment;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="REQUEST_ID", insertable = false, updatable = false)
    private TblImgToken imgToken;

    // Getters and setters

    public TblImgObjectId getId() {
        return id;
    }

    public void setId(TblImgObjectId id) {
        this.id = id;
    }

    public Timestamp getTimeCreate() {
        return timeCreate;
    }

    public void setTimeCreate(Timestamp timeCreate) {
        this.timeCreate = timeCreate;
    }

    public byte[] getObjectSegment() {
        return objectSegment;
    }

    public void setObjectSegment(byte[] objectSegment) {
        this.objectSegment = objectSegment;
    }


    public TblImgToken getImgToken() {
        return imgToken;
    }

    public void setImgToken(TblImgToken imgToken) {
        this.imgToken = imgToken;
    }
}
