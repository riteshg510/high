package com.hmhs.hvwmid.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.hmhs.hvwmid.service.GenericUDFService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.model.ExcelUploadResponse;
import com.hmhs.hvwmid.model.FileStorageResult;
import com.hmhs.hvwmid.model.GenerateIMIRequest;
import com.hmhs.hvwmid.model.GenerateIMIResponse;
import com.hmhs.hvwmid.model.IMIGeneatorData;
import com.hmhs.hvwmid.model.IMIGeneratorOutput;
import com.hmhs.hvwmid.repository.ImageCachingRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.service.FileStorageService;
import com.hmhs.hvwmid.service.IMIFileGeneratorService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.InterchangeFile;

@Service
public class IMIFileGeneratorServiceImpl implements IMIFileGeneratorService {

    private static final Logger logger = LogManager.getLogger(IMIFileGeneratorServiceImpl.class);

    private static final String PARMDATA_REGEX_FOR_COMMENTS = "--+[\\\\^\\$\\.\\|\\?\\*\\+\\(\\)\\[\\{\\!\\@\\#\\%\\&\\-\\_\\=\\]\\}\\`\\~\\;\\:\\\"\\'\\,\\<\\>\\/\\s\\w\\d]*";
    private static final String PARMID_IMISEG = "IMISEG";
    private static final String PARMID_IMIGENDT = "IMIGENDT";

    @Value("${api.imi.imiGeneratorScheduler}")
    private String imiGeneratorSchedulerURL;

    private final T222APRMRepository aprmRepository;
    private final GenericUDFService seqGen;
    private final FileStorageService fileStorageService;
    private final ImageCachingRepository imageCachingRepository;

    private Map<String, String> imiSegmentMap = null;
    private Map<String, String> imiDatePatternMap = null;

    public IMIFileGeneratorServiceImpl(T222APRMRepository aprmRepository, 
                                     org.springframework.jdbc.core.JdbcTemplate jdbcTemplate,
                                     FileStorageService fileStorageService,
                                     ImageCachingRepository imageCachingRepository) {
        this.aprmRepository = aprmRepository;
        this.seqGen = new GenericUDFService(jdbcTemplate, "DB2222054A_UDF");
        this.fileStorageService = fileStorageService;
        this.imageCachingRepository = imageCachingRepository;
    }

    @Override
    public ExcelUploadResponse uploadExcelFile(MultipartFile file, Integer documentCount, 
                                             Integer filePriority, String userId) throws Exception {
        ExcelUploadResponse response = new ExcelUploadResponse();
        
        try {
            // Validate inputs
            if (file == null || file.isEmpty()) {
                throw new IllegalArgumentException("Please select an Excel file to upload");
            }
            
            String fileName = file.getOriginalFilename();
            if (fileName == null || (!fileName.endsWith(".xls") && !fileName.endsWith(".xlsx"))) {
                throw new IllegalArgumentException("File must be an Excel file (.xls or .xlsx)");
            }
            
            if (documentCount == null || documentCount < 1 || documentCount > 2000) {
                throw new IllegalArgumentException("Documents per IMI must be between 1 and 2000");
            }
            
            if (filePriority == null || filePriority < 1 || filePriority > 100) {
                throw new IllegalArgumentException("File priority must be between 1 and 100");
            }

            String DBEXT="XLS";
            if(fileName.endsWith(".xlsx")) DBEXT="XLSX";
            
            // Store file in database
            FileStorageResult storageResult = fileStorageService.storeFile(file, userId, DBEXT);
            
            // Parse Excel to extract headers and filenames
            List<String> columnHeaders = new ArrayList<>();
            Set<String> distinctFilenames = new HashSet<>();
            int rowCount = 0;
            
            // Read file content from memory to parse
            try (ByteArrayInputStream bis = new ByteArrayInputStream(file.getBytes());
                 Workbook workbook = WorkbookFactory.create(bis)) {
                
                Sheet sheet = workbook.getSheetAt(0);
                if (sheet == null) {
                    throw new IOException("Sheet1 is empty in the Spreadsheet");
                }
                
                // Get headers from first row
                Row headerRow = sheet.getRow(0);
                if (headerRow == null) {
                    throw new IOException("Row 1 is empty in the Spreadsheet");
                }
                
                for (Cell cell : headerRow) {
                    String value = getCellValue(cell);
                    if (value != null && !value.trim().isEmpty()) {
                        columnHeaders.add(value.trim());
                    }
                }
                
                // Get distinct filenames from first column (excluding header)
                int lastRowNum = sheet.getLastRowNum();
                if (lastRowNum == 0) {
                    throw new IOException("No data rows in the Spreadsheet to create IMI files");
                }
                if (lastRowNum > 75000) {
                    throw new IOException("There cannot be more than 75000 rows in the Spreadsheet");
                }
                
                for (int i = 1; i <= lastRowNum; i++) {
                    Row row = sheet.getRow(i);
                    if (row != null) {
                        Cell firstCell = row.getCell(0);
                        String filename = getCellValue(firstCell);
                        if (filename != null && !filename.trim().isEmpty()) {
                            distinctFilenames.add(filename.trim());
                            rowCount++;
                        }
                    }
                }
                
                // Update document pages count in token
                fileStorageService.getFileMetadata(storageResult.getRequestId());
            }
            
            // Generate Excel name
            String excelName = String.format("IMI_%s_%s_%d.xlsx", 
                                           userId.toUpperCase(), 
                                           HVWUtils.createMfTimeStamp(), 
                                           storageResult.getRequestId());
            
            // Build response
            response.setExcelId(storageResult.getRequestId());
            response.setExcelName(excelName);
            response.setColumnHeaders(columnHeaders);
            response.setDistinctFilenames(new ArrayList<>(distinctFilenames));
            response.setMessage(String.format("Excel uploaded successfully. Found %d columns and %d distinct filenames", 
                                            columnHeaders.size(), distinctFilenames.size()));
            
            logger.info("Excel file uploaded successfully with REQUEST_ID: {} for user: {}", 
                       storageResult.getRequestId(), userId);
            
            return response;
            
        } catch (Exception e) {
            logger.error("Error uploading Excel file for user {}: {}", userId, e.getMessage(), e);
            throw new Exception("Error uploading Excel file: " + e.getMessage(), e);
        }
    }

    @Override
    public List<String> getDistinctFilenamesFromExcel(Integer excelRequestId, String userId) throws Exception {
        List<String> distinctFilenames = new ArrayList<>();
        
        try {
            // Validate user access to the Excel file
            if (!fileStorageService.validateAccess(excelRequestId, userId)) {
                throw new SecurityException("User does not have access to Excel file with REQUEST_ID: " + excelRequestId);
            }
            
            // Get file metadata to ensure it's an Excel file
            FileStorageResult metadata = fileStorageService.getFileMetadata(excelRequestId);
            if (metadata == null) {
                throw new IllegalArgumentException("Excel file not found with REQUEST_ID: " + excelRequestId);
            }
            
            if (!"XLSX".equalsIgnoreCase(metadata.getDocumentType().trim()) && !"XLS".equalsIgnoreCase(metadata.getDocumentType().trim())) {
                throw new IllegalArgumentException("REQUEST_ID does not reference an Excel file");
            }
            
            // Retrieve file content using streaming
            try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                imageCachingRepository.streamSegmentsByRequestId(excelRequestId, baos);
                byte[] excelContent = baos.toByteArray();
                
                // Parse Excel to extract distinct filenames
                Set<String> uniqueFilenames = new HashSet<>();
                try (ByteArrayInputStream bis = new ByteArrayInputStream(excelContent);
                     Workbook workbook = WorkbookFactory.create(bis)) {
                    
                    Sheet sheet = workbook.getSheetAt(0);
                    if (sheet == null) {
                        throw new IOException("Sheet1 is empty in the Spreadsheet");
                    }
                    
                    // Skip header row and get filenames from first column
                    int lastRowNum = sheet.getLastRowNum();
                    for (int i = 1; i <= lastRowNum; i++) {
                        Row row = sheet.getRow(i);
                        if (row != null) {
                            Cell firstCell = row.getCell(0);
                            String filename = getCellValue(firstCell);
                            if (filename != null && !filename.trim().isEmpty()) {
                                uniqueFilenames.add(filename.trim());
                            }
                        }
                    }
                }
                
                distinctFilenames.addAll(uniqueFilenames);
                logger.info("Retrieved {} distinct filenames from Excel REQUEST_ID: {}", distinctFilenames.size(), excelRequestId);
            }
            
            return distinctFilenames;
            
        } catch (Exception e) {
            logger.error("Error retrieving filenames from Excel REQUEST_ID {}: {}", excelRequestId, e.getMessage(), e);
            throw new Exception("Error retrieving filenames from Excel: " + e.getMessage(), e);
        }
    }

    @Override
    public IMIGeneatorData imiFileGeneratorOnLoad(String authToken) throws Exception {
        IMIGeneatorData imiGeneatorData = new IMIGeneatorData();
        List<String> ldapGroups = HVWUtils.getUserGroups(authToken);
        
        if (ldapGroups != null && !ldapGroups.isEmpty()) {
            Map<String, String> naicMap = HVWUtils.buildNAICMap(ldapGroups);
            if (!naicMap.isEmpty()) {
                imiGeneatorData.setNaicMap(naicMap);
                
                Map<String, String> intakeDirMap = getStringParmData("IMIDIRIN");
                imiGeneatorData.setImiDIRIntake(intakeDirMap);
                imiGeneatorData.setSchedulerUILink(imiGeneratorSchedulerURL);
            } else {
                IMIGeneatorData.BaseMessage baseMessage = new IMIGeneatorData.BaseMessage();
                baseMessage.setReturnCodeDescription(
                        "User does not have access to the IMI groups. Request access to the IMI groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->IMI Groups");
                imiGeneatorData.setBaseMessage(baseMessage);
                imiGeneatorData.setNaicMap(naicMap);
                return imiGeneatorData;
            }
        }
        return imiGeneatorData;
    }

    @Override
    public Map<String, Object> selectFile(Map<String, String> fileData) {
        Map<String, Object> response = new HashMap<>();
        String inputFileName = fileData.get("inputFileTxt");
        String outputDirName = fileData.get("outputDirTxt");

        if (inputFileName == null || inputFileName.trim().isEmpty()) {
            response.put("error", "Please enter the input Spreadsheet Name.");
            return response;
        }

        if (outputDirName == null || outputDirName.trim().isEmpty()) {
            response.put("error", "Please enter the output directory Name.");
            return response;
        }

        File inputFile = new File(inputFileName);
        if (!inputFile.exists()) {
            response.put("error", "Input Spreadsheet doesn't exist " + inputFileName);
            return response;
        }

        String ext = inputFileName.substring(inputFileName.lastIndexOf('.') + 1).toLowerCase();
        if (!"xls".equals(ext) && !"xlsx".equals(ext)) {
            response.put("error", "Input Spreadsheet is not a xls or xlsx file " + inputFileName);
            return response;
        }

        try {
            Map<String, String> rowHeaderMap = readSpreadsheetHeaders(inputFile);
            if (rowHeaderMap.isEmpty()) {
                response.put("error", "Row headers not populated.");
                return response;
            }

            response.put("rowHeaderMap", rowHeaderMap);

            Map<String, String> imiSegParmMap = getStringParmData(PARMID_IMISEG);
            if (imiSegParmMap.isEmpty()) {
                response.put("error", "Unable to load Segments from the PARM table.");
                return response;
            }

            response.put("imiSegMap", imiSegParmMap);
            response.put("inputSpreadsheet", inputFileName);
            response.put("docCountIMI", fileData.get("documentCountTxt"));
            response.put("naicInput", fileData.get("naicCodeTxt"));
            response.put("outputDir", outputDirName);
            response.put("filePriority", fileData.get("filePriorityTxt"));

        } catch (Exception e) {
            logger.error("Error processing spreadsheet: {}", e.getMessage(), e);
            response.put("error", "Error processing spreadsheet: " + e.getMessage());
        }

        return response;
    }

    @Override
    public List<IMIGeneratorOutput> createIMIFile(Map<String, Object> fileData) {
        List<IMIGeneratorOutput> outputList = new ArrayList<>();

        String[] requiredParams = { "inputSpreadsheet", "docCountIMI", "naicInput", "outputDir", "filePriority" };
        for (String param : requiredParams) {
            if (!fileData.containsKey(param)) {
                IMIGeneratorOutput output = new IMIGeneratorOutput();
                output.setStatus("ERROR");
                output.setMessages("Missing required parameter: " + param);
                outputList.add(output);
                return outputList;
            }
        }

        String inputFileName = (String) fileData.get("inputSpreadsheet");
        String naicCode = (String) fileData.get("naicInput");
        String outputDirectory = (String) fileData.get("outputDir");
        String filePriorityStr = (String) fileData.get("filePriority");
        String uniqueTs = HVWUtils.createMfTimeStamp();

        try {
            imiSegmentMap = getStringParmData(PARMID_IMISEG);
            imiDatePatternMap = getStringParmData(PARMID_IMIGENDT);

            if (imiSegmentMap.isEmpty()) {
                IMIGeneratorOutput output = new IMIGeneratorOutput();
                output.setStatus("ERROR");
                output.setMessages("Unable to load Segments from the PARM table.");
                outputList.add(output);
                return outputList;
            }

            if (imiDatePatternMap.isEmpty()) {
                IMIGeneratorOutput output = new IMIGeneratorOutput();
                output.setStatus("ERROR");
                output.setMessages("Unable to load Date patterns from the PARM table.");
                outputList.add(output);
                return outputList;
            }

            File inputFile = new File(inputFileName);
            if (!inputFile.exists()) {
                IMIGeneratorOutput output = new IMIGeneratorOutput();
                output.setStatus("ERROR");
                output.setMessages("Input file does not exist: " + inputFileName);
                outputList.add(output);
                return outputList;
            }

            try (FileInputStream fis = new FileInputStream(inputFile);
                 Workbook workbook = WorkbookFactory.create(fis)) {

                Sheet sheet = workbook.getSheetAt(0);
                if (sheet == null) {
                    throw new IOException("Sheet1 is empty in the Spreadsheet");
                }

                int lastRowNum = sheet.getLastRowNum();
                for (int rowNum = 1; rowNum <= lastRowNum; rowNum++) {
                    Row row = sheet.getRow(rowNum);
                    if (row == null) continue;

                    IMIGeneratorOutput output = new IMIGeneratorOutput();
                    output.setRowNo(String.valueOf(rowNum + 1));

                    try {
                        String imiFileName = generateIMIFile(row, naicCode, filePriorityStr, uniqueTs, outputDirectory);
                        output.setStatus("SUCCESS");
                        output.setImiFileName(imiFileName);
                        output.setMessages("IMI file generated successfully");
                    } catch (Exception e) {
                        logger.error("Failed to generate IMI file for row {}: {}", rowNum, e.getMessage(), e);
                        output.setStatus("ERROR");
                        output.setMessages("Failed to generate IMI file: " + e.getMessage());
                    }

                    outputList.add(output);
                }
            }

        } catch (Exception e) {
            logger.error("Error generating IMI file: {}", e.getMessage(), e);
            IMIGeneratorOutput output = new IMIGeneratorOutput();
            output.setStatus("ERROR");
            output.setMessages("Error generating IMI file: " + e.getMessage());
            outputList.add(output);
        }

        return outputList;
    }

    private String generateIMIFile(Row row, String naicCode, String filePriority, String uniqueTs,
            String outputDirectory) throws Exception {
        String imiFileName = String.format("%s.%s.%s.HIGHVIEWGENERATED.%s.imi", filePriority, naicCode, uniqueTs,
                uniqueTs);

        File tempFile = new File(outputDirectory, imiFileName + ".temp");
        File finalFile = new File(outputDirectory, imiFileName);

        try (InterchangeFile imiFile = new InterchangeFile(tempFile.getAbsolutePath())) {
            imiFile.writeSegment("HDR", naicCode);
            imiFile.writeSegment("FID", uniqueTs);

            Cell imgCell = row.getCell(3);
            String imgPath = getCellValue(imgCell);
            if (imgPath == null || imgPath.trim().isEmpty()) {
                throw new IOException("Image path is required");
            }

            imiFile.writeSegment("IMG", imgPath);
            imiFile.writeSegment("DPK", imgPath.toUpperCase());

            String docId = uniqueTs + "_IMI";
            imiFile.writeSegment("BOD", docId);
            imiFile.writeSegment("EOD", docId);

            imiFile.writeSegment("TRL", String.format("%06d", 1));
        }

        if (!tempFile.renameTo(finalFile)) {
            throw new IOException("Failed to rename temporary file to " + imiFileName);
        }

        return imiFileName;
    }

    private String getCellValue(Cell cell) {
        if (cell == null) return null;
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (org.apache.poi.ss.usermodel.DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                }
                // Remove decimal point for whole numbers
                double numericValue = cell.getNumericCellValue();
                if (numericValue == Math.floor(numericValue)) {
                    return String.valueOf((long) numericValue);
                }
                return String.valueOf(numericValue);
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            case BLANK:
                return "";
            default:
                return "";
        }
    }

    private Map<String, String> readSpreadsheetHeaders(File inputFile) throws Exception {
        Map<String, String> rowHeaderMap = new LinkedHashMap<>();

        try (FileInputStream fis = new FileInputStream(inputFile); 
             Workbook workbook = WorkbookFactory.create(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new IOException("Sheet1 is empty in the Spreadsheet");
            }

            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new IOException("Row1 is empty in the Spreadsheet");
            }

            int lastRowNum = sheet.getLastRowNum();
            if (lastRowNum == 0) {
                throw new IOException("No Rows in the Spreadsheet to create the IMI files");
            }
            if (lastRowNum > 75000) {
                throw new IOException("There cannot be more than 75000 Rows in the Spreadsheet");
            }

            for (Cell cell : headerRow) {
                String value = cell.getStringCellValue();
                if (value != null && !value.trim().isEmpty()) {
                    rowHeaderMap.put(String.valueOf(cell.getColumnIndex()), value);
                }
            }
        }

        return rowHeaderMap;
    }

    public Map<String, String> getStringParmData(String parmid) throws Exception {
        Map<String, String> parmDataMap = new HashMap<>();
        try {
            List<T222APRM> t222aprmsList = aprmRepository.findByParmId(parmid);
            for (T222APRM entityRow : t222aprmsList) {
                parmDataMap.put(entityRow.getParmKey().trim(),
                        entityRow.getParmData().replaceAll(PARMDATA_REGEX_FOR_COMMENTS, "").trim());
            }
        } catch (Exception e) {
            throw new Exception("Exception in getting Parm Data from DB2 : " + e.getMessage());
        }

        return parmDataMap;
    }
    
    @Override
    public GenerateIMIResponse generateIMIFiles(GenerateIMIRequest request, String userId) throws Exception {
        GenerateIMIResponse response = new GenerateIMIResponse();
        List<GenerateIMIResponse.GeneratedFile> generatedFiles = new ArrayList<>();
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        
        try {
            // Validate request
            if (request == null || request.getExcelId() == null) {
                throw new IllegalArgumentException("Excel ID is required");
            }
            
            if (request.getFileIdMappings() == null || request.getFileIdMappings().isEmpty()) {
                throw new IllegalArgumentException("At least one file mapping is required");
            }
            
            // Get output configuration with defaults
            GenerateIMIRequest.OutputConfig outputConfig = request.getOutputConfig();
            if (outputConfig == null) {
                outputConfig = new GenerateIMIRequest.OutputConfig();
            }
            Integer documentsPerIMI = outputConfig.getDocumentsPerIMI() != null ? outputConfig.getDocumentsPerIMI() : 25;
            Integer filePriority = outputConfig.getFilePriority() != null ? outputConfig.getFilePriority() : 99;
            
            // Validate documents per IMI
            if (documentsPerIMI < 1 || documentsPerIMI > 2000) {
                throw new IllegalArgumentException("Documents per IMI must be between 1 and 2000");
            }
            
            // Validate file priority
            if (filePriority < 1 || filePriority > 100) {
                throw new IllegalArgumentException("File priority must be between 1 and 100");
            }
            
            // Validate user access to Excel file
            if (!fileStorageService.validateAccess(request.getExcelId(), userId)) {
                throw new SecurityException("User does not have access to Excel file with REQUEST_ID: " + request.getExcelId());
            }
            
            // Load segment mappings from PARM table
            Map<String, String> imiSegmentMap = getStringParmData(PARMID_IMISEG);
            // Map<String, String> imiDatePatternMap = getStringParmData(PARMID_IMIGENDT);
            
            if (imiSegmentMap.isEmpty()) {
                throw new Exception("Unable to load segments from PARM table");
            }
            
            // Create a map of uploaded file REQUEST_IDs to Excel filenames
            Map<String, Integer> filenameToRequestIdMap = new HashMap<>();
            for (GenerateIMIRequest.FileIdMapping mapping : request.getFileIdMappings()) {
                if (mapping.getFileId() != null && mapping.getExcelFileName() != null) {
                    // Validate user has access to each uploaded file
                    if (!fileStorageService.validateAccess(mapping.getFileId(), userId)) {
                        throw new SecurityException("User does not have access to file with REQUEST_ID: " + mapping.getFileId());
                    }
                    filenameToRequestIdMap.put(mapping.getExcelFileName().trim().toLowerCase(), mapping.getFileId());
                }
            }
            
            // Create segment mapping configuration
            Map<String, GenerateIMIRequest.SegmentMapping> segmentMappings = new HashMap<>();
            if (request.getMappings() != null) {
                for (GenerateIMIRequest.SegmentMapping mapping : request.getMappings()) {
                    if (mapping.getSegmentName() != null) {
                        segmentMappings.put(mapping.getSegmentName().toUpperCase(), mapping);
                    }
                }
            }
            
            // Retrieve and parse Excel content
            logger.info("Retrieving Excel content for REQUEST_ID: {}", request.getExcelId());
            List<Map<String, String>> excelRows = new ArrayList<>();
            List<String> headers = new ArrayList<>();
            
            try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                imageCachingRepository.streamSegmentsByRequestId(request.getExcelId(), baos);
                byte[] excelContent = baos.toByteArray();
                
                try (ByteArrayInputStream bis = new ByteArrayInputStream(excelContent);
                     Workbook workbook = WorkbookFactory.create(bis)) {
                    
                    Sheet sheet = workbook.getSheetAt(0);
                    if (sheet == null) {
                        throw new IOException("Sheet1 is empty in the Spreadsheet");
                    }
                    
                    // Get headers from first row
                    Row headerRow = sheet.getRow(0);
                    if (headerRow == null) {
                        throw new IOException("Row 1 is empty in the Spreadsheet");
                    }
                    
                    for (Cell cell : headerRow) {
                        String value = getCellValue(cell);
                        headers.add(value != null ? value.trim() : "");
                    }
                    
                    // Process data rows
                    int lastRowNum = sheet.getLastRowNum();
                    for (int i = 1; i <= lastRowNum; i++) {
                        Row row = sheet.getRow(i);
                        if (row != null) {
                            Map<String, String> rowData = new HashMap<>();
                            
                            // Add row number for tracking
                            rowData.put("_ROW_NUMBER", String.valueOf(i + 1));
                            
                            // Extract cell values
                            for (int j = 0; j < headers.size(); j++) {
                                Cell cell = row.getCell(j);
                                String cellValue = getCellValue(cell);
                                if (cellValue != null) {
                                    rowData.put(headers.get(j), cellValue.trim());
                                }
                            }
                            
                            // Only add rows that have filename in first column
                            String filename = rowData.get(headers.get(0));
                            if (filename != null && !filename.isEmpty()) {
                                excelRows.add(rowData);
                            }
                        }
                    }
                }
            }
            //
            logger.info("Processing {} rows from Excel", excelRows.size());
            summary.setTotalRows(excelRows.size());
            
            // Generate unique timestamp for this batch
            String batchTimestamp = HVWUtils.createMfTimeStamp();
            
            // Process rows in batches based on documentsPerIMI
            int currentBatch = 0;
            int docsInCurrentIMI = 0;
            int successCount = 0;
            int failCount = 0;
            int warningCount = 0;
            
            // Create output Excel workbook to track results
            Workbook outputWorkbook = WorkbookFactory.create(true); // XLSX format
            Sheet outputSheet = outputWorkbook.createSheet("IMI Generation Results");
            
            // Create header row for output Excel
            Row outputHeaderRow = outputSheet.createRow(0);
            for (int i = 0; i < headers.size(); i++) {
                outputHeaderRow.createCell(i).setCellValue(headers.get(i));
            }
            outputHeaderRow.createCell(headers.size()).setCellValue("STATUS");
            outputHeaderRow.createCell(headers.size() + 1).setCellValue("IMI_FILE");
            outputHeaderRow.createCell(headers.size() + 2).setCellValue("MESSAGE");
            
            int outputRowNum = 1;
            
            // Process documents and group into IMI files
            List<Map<String, String>> currentBatchRows = new ArrayList<>();
            
            for (Map<String, String> rowData : excelRows) {
                currentBatchRows.add(rowData);
                docsInCurrentIMI++;
                
                // Generate IMI when batch is full or at the end
                if (docsInCurrentIMI >= documentsPerIMI || rowData == excelRows.get(excelRows.size() - 1)) {
                    currentBatch++;
                    String imiFileName = String.format("%02d.%s.HIGHVIEWGENERATED.%s.imi", 
                                                     filePriority, batchTimestamp, 
                                                     HVWUtils.createMfTimeStamp());
                    
                    try {
                        // Generate IMI file for this batch
                        Integer imiRequestId = generateSingleIMIFile(currentBatchRows, imiFileName, 
                                                                    filenameToRequestIdMap, segmentMappings, 
                                                                    imiSegmentMap, userId);
                        
                        // Add to generated files list
                        GenerateIMIResponse.GeneratedFile genFile = new GenerateIMIResponse.GeneratedFile();
                        genFile.setImiFileId(imiRequestId);
                        genFile.setImiFileName(imiFileName);
                        genFile.setDocumentCount(currentBatchRows.size());
                        genFile.setStatus("SUCCESS");
                        generatedFiles.add(genFile);
                        
                        // Update output Excel for each row in batch
                        for (Map<String, String> batchRow : currentBatchRows) {
                            Row outputRow = outputSheet.createRow(outputRowNum++);
                            
                            // Copy original data
                            for (int i = 0; i < headers.size(); i++) {
                                String value = batchRow.get(headers.get(i));
                                outputRow.createCell(i).setCellValue(value != null ? value : "");
                            }
                            
                            // Add status columns
                            outputRow.createCell(headers.size()).setCellValue("SUCCESS");
                            outputRow.createCell(headers.size() + 1).setCellValue(imiFileName);
                            outputRow.createCell(headers.size() + 2).setCellValue("Document processed successfully");
                            
                            successCount++;
                        }
                        
                        logger.info("Generated IMI file: {} with {} documents", imiFileName, currentBatchRows.size());
                        
                    } catch (Exception e) {
                        logger.error("Failed to generate IMI file for batch {}: {}", currentBatch, e.getMessage(), e);
                        
                        // Update output Excel with failure status
                        for (Map<String, String> batchRow : currentBatchRows) {
                            Row outputRow = outputSheet.createRow(outputRowNum++);
                            
                            // Copy original data
                            for (int i = 0; i < headers.size(); i++) {
                                String value = batchRow.get(headers.get(i));
                                outputRow.createCell(i).setCellValue(value != null ? value : "");
                            }
                            
                            // Add status columns
                            outputRow.createCell(headers.size()).setCellValue("FAILED");
                            outputRow.createCell(headers.size() + 1).setCellValue("");
                            outputRow.createCell(headers.size() + 2).setCellValue("Error: " + e.getMessage());
                            
                            failCount++;
                        }
                    }
                    
                    // Reset for next batch
                    currentBatchRows.clear();
                    docsInCurrentIMI = 0;
                }
            }
            
            // Save output Excel
            ByteArrayOutputStream outputBaos = new ByteArrayOutputStream();
            outputWorkbook.write(outputBaos);
            outputWorkbook.close();
            
            // Store output Excel in database
            String outputFileName = String.format("IMI_RESULTS_%s_%s.xlsx", userId.toUpperCase(), batchTimestamp);
            FileStorageResult outputExcelResult = fileStorageService.storeFileContent(
                outputBaos.toByteArray(), outputFileName, userId, "XLSX"
            );
            
            // Set response data
            response.setGeneratedFiles(generatedFiles);
            response.setOutputExcelId(outputExcelResult.getRequestId());
            
            summary.setSuccessful(successCount);
            summary.setFailed(failCount);
            summary.setWarnings(warningCount);
            response.setSummary(summary);
            
            response.setMessage(String.format("Successfully generated %d IMI files from %d documents", 
                                            generatedFiles.size(), excelRows.size()));
            
            logger.info("IMI generation completed. Files: {}, Success: {}, Failed: {}", 
                       generatedFiles.size(), successCount, failCount);
            
            return response;
            
        }
        catch (SecurityException e){
            logger.error("Error generating IMI files: {}", e.getMessage(), e);
            throw new SecurityException("Error generating IMI files: " + e.getMessage(), e);
        }
        catch (IllegalArgumentException e){
            logger.error("Error generating IMI files: {}", e.getMessage(), e);
            throw new IllegalArgumentException("Error generating IMI files: " + e.getMessage(), e);
        }
        catch (Exception e) {
            logger.error("Error generating IMI files: {}", e.getMessage(), e);
            throw new Exception("Error generating IMI files: " + e.getMessage(), e);
        }
    }
    
    /**
     * Generate a single IMI file for a batch of documents
     */
    private Integer generateSingleIMIFile(List<Map<String, String>> rows, String imiFileName,
                                        Map<String, Integer> filenameToRequestIdMap,
                                        Map<String, GenerateIMIRequest.SegmentMapping> segmentMappings,
                                        Map<String, String> imiSegmentMap,
                                        String userId) throws Exception {
        
        // Create temporary file
        File tempFile = File.createTempFile("imi_", ".tmp");
        tempFile.deleteOnExit();
        
        try (InterchangeFile imiFile = new InterchangeFile(tempFile.getAbsolutePath(), true)) {
            
            // Generate unique file ID for this IMI
            String fileId = HVWUtils.createMfTimeStamp();
            
            // Write header segment (HDR) - no longer using NAIC code, just a placeholder
            imiFile.writeSegment("HDR", "00000");
            
            // Write file ID segment (FID)
            GenerateIMIRequest.SegmentMapping fidMapping = segmentMappings.get("FID");
            if (fidMapping != null && "U".equalsIgnoreCase(fidMapping.getType())) {
                imiFile.writeSegment("FID", fileId);
            } else if (fidMapping != null && "C".equalsIgnoreCase(fidMapping.getType()) && fidMapping.getValue() != null) {
                imiFile.writeSegment("FID", fidMapping.getValue());
            } else if (fidMapping != null && "M".equalsIgnoreCase(fidMapping.getType()) && fidMapping.getValue() != null) {
                // Use first row's mapped value
                String mappedValue = rows.get(0).get(fidMapping.getValue());
                imiFile.writeSegment("FID", mappedValue != null ? mappedValue : fileId);
            } else {
                imiFile.writeSegment("FID", fileId);
            }
            
            // Process each document in the batch
            int docCount = 0;
            for (Map<String, String> rowData : rows) {
                String filename = rowData.get(segmentMappings.get("IMG").getValue()); // First column is filename
                if (filename == null || filename.isEmpty()) {
                    continue;
                }
                
                // Find the uploaded file REQUEST_ID
                Integer imageRequestId = null;
                for (Map.Entry<String, Integer> entry : filenameToRequestIdMap.entrySet()) {
                    if (filename.toLowerCase().contains(entry.getKey())) {
                        imageRequestId = entry.getValue();
                        break;
                    }
                }
                
                if (imageRequestId == null) {
                    throw new Exception("No uploaded file found for: " + filename);
                }
                
                docCount++;
                
                // Generate document ID
                String docId = fileId + "_" + String.format("%04d", docCount);
                
                // Write BOD (Beginning of Document)
                imiFile.writeSegment("BOD", docId);
                
                // Write DPK segment
                GenerateIMIRequest.SegmentMapping dpkMapping = segmentMappings.get("DPK");
                if (dpkMapping != null && "C".equalsIgnoreCase(dpkMapping.getType()) && dpkMapping.getValue() != null) {
                    imiFile.writeSegment("DPK", dpkMapping.getValue());
                } else if (dpkMapping != null && "M".equalsIgnoreCase(dpkMapping.getType()) && dpkMapping.getValue() != null) {
                    String mappedValue = rowData.get(dpkMapping.getValue());
                    imiFile.writeSegment("DPK", mappedValue != null ? mappedValue : filename.toUpperCase());
                } else {
                    imiFile.writeSegment("DPK", filename.toUpperCase());
                }
                
                // Write custom segments based on mappings
                for (Map.Entry<String, GenerateIMIRequest.SegmentMapping> entry : segmentMappings.entrySet()) {
                    String segmentName = entry.getKey();
                    GenerateIMIRequest.SegmentMapping mapping = entry.getValue();
                    
                    // Skip already processed segments
                    if ("FID".equals(segmentName) || "DPK".equals(segmentName) || 
                        "BOD".equals(segmentName) || "EOD".equals(segmentName) || 
                        "IMG".equals(segmentName) || "HDR".equals(segmentName) || 
                        "TRL".equals(segmentName)) {
                        continue;
                    }
                    
                    // Check if segment is defined in PARM table
                    if (imiSegmentMap.containsKey(segmentName)) {
                        if ("U".equalsIgnoreCase(mapping.getType())) {
                            imiFile.writeSegment(segmentName, HVWUtils.createMfTimeStamp());
                        } else if ("C".equalsIgnoreCase(mapping.getType()) && mapping.getValue() != null) {
                            imiFile.writeSegment(segmentName, mapping.getValue());
                        } else if ("M".equalsIgnoreCase(mapping.getType()) && mapping.getValue() != null) {
                            String mappedValue = rowData.get(mapping.getValue());
                            if (mappedValue != null) {
                                imiFile.writeSegment(segmentName, mappedValue);
                            }
                        }
                    }
                }
                
                // Write IMG segment with binary content
                try (ByteArrayOutputStream imgBaos = new ByteArrayOutputStream()) {
                    imageCachingRepository.streamSegmentsByRequestId(imageRequestId, imgBaos);
                    byte[] imageContent = imgBaos.toByteArray();
                    imiFile.writeBinarySegment("IMG", imageContent);
                }
                
                // Write EOD (End of Document)
                imiFile.writeSegment("EOD", docId);
            }
            
            // Write trailer segment (TRL) with document count
            imiFile.writeSegment("TRL", String.format("%06d", docCount));
        }
        
        // Read the generated IMI file and store in database
        byte[] imiContent = java.nio.file.Files.readAllBytes(tempFile.toPath());
        FileStorageResult imiResult = fileStorageService.storeFileContent(
            imiContent, imiFileName, userId, "IMI"
        );
        
        // Clean up temp file
        tempFile.delete();
        
        return imiResult.getRequestId();
    }
}