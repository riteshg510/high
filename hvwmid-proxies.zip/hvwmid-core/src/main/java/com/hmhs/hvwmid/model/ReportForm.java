package com.hmhs.hvwmid.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportForm {
	private List<ReportAction> actions;
	private List<ReportLayout> layout;
	private String formName;
	private String type;
	private ReportHelp help;

	public List<ReportAction> getActions() {
		return actions;
	}

	public void setActions(final List<ReportAction> actions) {
		this.actions = actions;
	}

	public List<ReportLayout> getLayout() {
		return layout;
	}

	public void setLayout(final List<ReportLayout> layout) {
		this.layout = layout;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(final String formName) {
		this.formName = formName;
	}

	public String getType() {
		return type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	public ReportHelp getHelp() {
		return help;
	}

	public void setHelp(final ReportHelp help) {
		this.help = help;
	}

}
