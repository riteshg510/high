package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.enums.ImageConfigListingReqMapping;
import com.hmhs.hvwmid.model.ListingSearchRequest;
import com.hmhs.hvwmid.repository.ImageConfigListingJdbcRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ImageConfigListingService {

    private static final String KEY_DEFINITION = "definition";
    private static final String KEY_DATA = "data";

    private static final int DEFAULT_PAGE_NUMBER = 0;
    private static final int DEFAULT_PAGE_SIZE = 10;

    private final ImageConfigListingJdbcRepository repo;

    public Map<String, Object> search(final ListingSearchRequest req) throws IOException {
        final List<Map<String, Object>> rows = repo.search(req);
        return buildStructuredResponse(req, rows);
    }

    private Map<String, Object> buildStructuredResponse(
            final ListingSearchRequest req,
            final List<Map<String, Object>> rawRows
    ) {
        final Map<String, Object> output = new LinkedHashMap<>();
        output.put(KEY_DEFINITION, createTableDefinition(req));
        output.put(KEY_DATA, rawRows == null ? List.of() : rawRows);
        return output;
    }

    private Map<String, Object> createTableDefinition(final ListingSearchRequest req) {
        final Map<String, Object> definition = new LinkedHashMap<>();

        definition.put("allowMultipleSort", false);
        definition.put("allowResizeColumns", false);
        definition.put("pagination", Map.of(
                "pageNumber", DEFAULT_PAGE_NUMBER,
                "pageSize", DEFAULT_PAGE_SIZE
        ));

        definition.put("columns", buildSelectedColumns(req));
        definition.put("actions", buildActions());
        definition.put("selectionMode", "multiple");

        return definition;
    }

    private List<Map<String, Object>> buildActions() {
        final Map<String, Object> downloadAction = new LinkedHashMap<>();
        downloadAction.put("actionType", "downloadpdf");
        downloadAction.put("label", "Download Selected");
        downloadAction.put("actionIcon", "download");
        downloadAction.put("apiUrl", "report-archive/tokens/view");

        return List.of(downloadAction);
    }

    private Map<String, Object> createColumn(final String key, final String name) {
        final Map<String, Object> col = new LinkedHashMap<>();
        col.put("id", key);
        col.put("name", name);
        col.put("type", "string");
        col.put("sortable", true);
        col.put("filterable", true);
        col.put("url", "");
        return col;
    }

    private List<Map<String, Object>> buildSelectedColumns(final ListingSearchRequest req) {
        final List<Map<String, Object>> columns = new ArrayList<>();
        final BeanWrapper bw = new BeanWrapperImpl(req);

        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            final Object disp = bw.getPropertyValue(m.getDisplayField());
            if (disp instanceof Boolean && (Boolean) disp) {
                columns.add(createColumn(m.name(), m.getColumnHeader()));
            }
        }
        return columns;
    }
}
