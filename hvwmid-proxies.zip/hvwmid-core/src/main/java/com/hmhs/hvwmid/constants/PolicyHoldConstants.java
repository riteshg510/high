package com.hmhs.hvwmid.constants;

public class PolicyHoldConstants {
    public static final String BPD_ID = "bpdId";
    public static final String POLICY_CODE = "policyCode";
    public static final String POLICY_ID = "policyId";
    public static final String POLICY_DESCRIPTION = "policyDescription";
    public static final String POLICY_ID_TYPE = "policyIdType";
    public static final String POLICY_DAYS = "policyDays";
    public static final String POLICY_EDIT_FLAG = "policyEditFlag";
    public static final String POLICY_EDIT_PGM_NAME = "policyEditPgmName";
    public static final String POLICY_BASE_DATE = "policyBaseDate";
    public static final String MOD_USER = "modUser";
    public static final String MOD_DATE = "modDate";
    public static final String HOLD_CODE = "holdCode";
    public static final String HOLD_ID = "holdId";
    public static final String HOLD_DESCRIPTION = "holdDescription";
    public static final String HOLD_EDIT_FLAG = "holdEditFlag";
    public static final String HOLD_EDIT_PGM_NAME = "holdEditPgmName";
    public static final String HOLD_MOD_USER = "holdModUser";
    public static final String HOLD_DATE_BEGIN = "holdDateBegin";
    public static final String HOLD_DATE_END = "holdDateEnd";
    public static final String HOLDS = "holds";
    public static final String ASC = "asc";
    public static final String RMPOLTYP = "RMPOLTYP";

    private PolicyHoldConstants() {
    }
}
