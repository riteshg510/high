package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.ColumnDefault;

import java.time.Instant;

@Entity
@Table(name = "T222_IMG_EXTENDEDPARM")
public class T222ImgExtendedparm {
    @EmbeddedId
    private T222ImgExtendedparmId id;

    @NotNull
    @ColumnDefault("CURRENT TIMESTAMP")
    @Column(name = "TIME_CREATE", nullable = false)
    private Instant timeCreate;

    @Size(max = 8)
    @NotNull
    @ColumnDefault("USER")
    @Column(name = "MODUSER", nullable = false, length = 8)
    private String moduser;

    @Size(max = 32000)
    @NotNull
    @ColumnDefault("''")
    @Column(name = "EPARM_DATA", nullable = false, length = 32000)
    private String eparmData;

    public T222ImgExtendedparmId getId() {
        return id;
    }

    public void setId(T222ImgExtendedparmId id) {
        this.id = id;
    }

    public Instant getTimeCreate() {
        return timeCreate;
    }

    public void setTimeCreate(Instant timeCreate) {
        this.timeCreate = timeCreate;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getEparmData() {
        return eparmData;
    }

    public void setEparmData(String eparmData) {
        this.eparmData = eparmData;
    }

}