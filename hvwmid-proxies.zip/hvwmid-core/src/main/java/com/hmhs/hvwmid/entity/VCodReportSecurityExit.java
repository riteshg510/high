package com.hmhs.hvwmid.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "V_COD_REPORT_SECURITY_EXIT")
public class VCodReportSecurityExit {
    
    @Column(name = "CDTYPE", length = 50)
    private String cdtype;
    
    @Id
    @Column(name = "SEC_EXIT", length = 100)
    private String secExit;
    
    @Column(name = "ACF2_RESOURCE_NAME", length = 255)
    private String acf2ResourceName;
    
    @Column(name = "SEC_TYPE", length = 50)
    private String secType;
    
    @Column(name = "MOD_USER", length = 50)
    private String modUser;
    
    @Column(name = "MOD_TIME", columnDefinition = "TIMESTAMP")
    private LocalDateTime modTime;
    
    @Column(name = "COMMENTS", length = 500)
    private String comments;
    
    @Column(name = "SEGMENT_KEY", length = 100)
    private String segmentKey;
    
    @Column(name = "CMOD_APPLICATION", length = 100)
    private String cmodApplication;
    
    @Column(name = "CMOD_INDEX", length = 100)
    private String cmodIndex;
    
    @Column(name = "BPD_ID", length = 50)
    private String bpdId;

    public String getCdtype() {
        return cdtype != null ? cdtype.toUpperCase() : null;
    }

    public void setCdtype(String cdtype) {
        this.cdtype = cdtype != null ? cdtype.toUpperCase() : null;
    }

    public String getSecExit() {
        return secExit != null ? secExit.toUpperCase() : null;
    }

    public void setSecExit(String secExit) {
        this.secExit = secExit != null ? secExit.toUpperCase() : null;
    }

    public String getAcf2ResourceName() {
        return acf2ResourceName != null ? acf2ResourceName.toUpperCase() : null;
    }

    public void setAcf2ResourceName(String acf2ResourceName) {
        this.acf2ResourceName = acf2ResourceName != null ? acf2ResourceName.toUpperCase() : null;
    }

    public String getSecType() {
        return secType != null ? secType.toUpperCase() : null;
    }

    public void setSecType(String secType) {
        this.secType = secType != null ? secType.toUpperCase() : null;
    }

    public String getModUser() {
        return modUser != null ? modUser.toUpperCase() : null;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser != null ? modUser.toUpperCase() : null;
    }

    public LocalDateTime getModTime() {
        return modTime;
    }

    public void setModTime(LocalDateTime modTime) {
        this.modTime = modTime;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getSegmentKey() {
        return segmentKey != null ? segmentKey.toUpperCase() : null;
    }

    public void setSegmentKey(String segmentKey) {
        this.segmentKey = segmentKey != null ? segmentKey.toUpperCase() : null;
    }

    public String getCmodApplication() {
        return cmodApplication != null ? cmodApplication.toUpperCase() : null;
    }

    public void setCmodApplication(String cmodApplication) {
        this.cmodApplication = cmodApplication != null ? cmodApplication.toUpperCase() : null;
    }

    public String getCmodIndex() {
        return cmodIndex != null ? cmodIndex.toUpperCase() : null;
    }

    public void setCmodIndex(String cmodIndex) {
        this.cmodIndex = cmodIndex != null ? cmodIndex.toUpperCase() : null;
    }

    public String getBpdId() {
        return bpdId != null ? bpdId.toUpperCase() : null;
    }

    public void setBpdId(String bpdId) {
        this.bpdId = bpdId != null ? bpdId.toUpperCase() : null;
    }
}