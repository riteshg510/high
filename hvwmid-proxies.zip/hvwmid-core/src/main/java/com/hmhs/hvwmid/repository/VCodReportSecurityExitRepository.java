package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.VCodReportSecurityExit;

@Repository
public interface VCodReportSecurityExitRepository extends CrudRepository<VCodReportSecurityExit, String> {
    @Query(value = "SELECT * FROM V_COD_REPORT_SECURITY_EXIT WHERE CMOD_APPLICATION IS NOT NULL AND CMOD_APPLICATION !=''", nativeQuery = true)
    List<VCodReportSecurityExit> getSecurityExitData();
}