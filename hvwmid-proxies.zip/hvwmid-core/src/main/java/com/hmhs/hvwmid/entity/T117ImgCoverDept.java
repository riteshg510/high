package com.hmhs.hvwmid.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Size;


@Entity
@Table(name = "T117_IMG_COVERDEPT")
public class T117ImgCoverDept {

    @Id
    @Column(name = "DEPTID", nullable = false)
    private Integer deptId;

    @Column(name = "DESCRIPTION", length = 40)
    @Size(max = 40, message = "Description cannot exceed 40 characters")
    private String description;

    @Column(name = "MAINTGROUP", length = 50)
    @Size(max = 50, message = "maintGroup cannot exceed 50 characters")
    private String maintGroup;

    @Column(name = "PRINTGROUP", length = 50)
    @Size(max = 50, message = "printGroup cannot exceed 50 characters")
    private String printGroup;


    public T117ImgCoverDept() {
    }
    public T117ImgCoverDept(Integer deptId, String description, String maintGroup, String printGroup) {
        this.deptId = deptId;
        this.description = description;
        this.maintGroup = maintGroup;
        this.printGroup = printGroup;
    }


    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public String getDescription() {
        return description.trim();
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMaintGroup() {
        return maintGroup.trim();
    }

    public void setMaintGroup(String maintGroup) {
        this.maintGroup = maintGroup;
    }

    public String getPrintGroup() {
        return printGroup.trim();
    }

    public void setPrintGroup(String printGroup) {
        this.printGroup = printGroup;
    }
}
