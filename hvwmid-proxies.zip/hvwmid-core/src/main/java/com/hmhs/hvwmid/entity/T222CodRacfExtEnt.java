package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;

/**
 * Entity representing T222_COD_RACF_EXT_ENT table.
 * Maps RACF entities to user IDs for security access control.
 */
@Entity
@Table(name = "T222_COD_RACF_EXT_ENT")
@IdClass(T222CodRacfExtEntId.class)
public class T222CodRacfExtEnt {

    @Id
    @Size(max = 10)
    @NotNull
    @Column(name = "RACF_CLASS", nullable = false, length = 10)
    private String racfClass;

    @Id
    @Size(max = 50)
    @NotNull
    @Column(name = "RACF_ENTITY", nullable = false, length = 50)
    private String racfEntity;

    @Id
    @Size(max = 8)
    @NotNull
    @Column(name = "RACF_USER_ID", nullable = false, length = 8)
    private String racfUserId;

    @Size(max = 40)
    @NotNull
    @Column(name = "RACF_USER_NAME", nullable = false, length = 40)
    private String racfUserName;

    @NotNull
    @Column(name = "TIMEUPDATE", nullable = false)
    private Instant timeupdate;

    public Instant getTimeupdate() {
        return timeupdate;
    }

    public void setTimeupdate(Instant timeupdate) {
        this.timeupdate = timeupdate;
    }

    public String getRacfUserName() {
        return racfUserName;
    }

    public void setRacfUserName(String racfUserName) {
        this.racfUserName = racfUserName;
    }

    public String getRacfClass() {
        return racfClass;
    }

    public void setRacfClass(String racfClass) {
        this.racfClass = racfClass;
    }

    // Constructors
    public T222CodRacfExtEnt() {
    }

    public T222CodRacfExtEnt(String racfClass, String racfEntity, String racfUserId, 
                            String racfUserName, Instant timeupdate) {
        this.racfClass = racfClass;
        this.racfEntity = racfEntity;
        this.racfUserId = racfUserId;
        this.racfUserName = racfUserName;
        this.timeupdate = timeupdate;
    }

    // Getters and Setters
    public String getRacfEntity() {
        return racfEntity;
    }

    public void setRacfEntity(String racfEntity) {
        this.racfEntity = racfEntity;
    }

    public String getRacfUserId() {
        return racfUserId;
    }

    public void setRacfUserId(String racfUserId) {
        this.racfUserId = racfUserId;
    }
}