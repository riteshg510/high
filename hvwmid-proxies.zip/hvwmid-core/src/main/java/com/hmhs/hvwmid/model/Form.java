package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Form {

	private List<Action> actions;
	private List<Section> layout;
	private String formName;
	private String type;

	public List<Action> getActions() {
		return actions;
	}

	public void setActions(List<Action> actions) {
		this.actions = actions;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public List<Section> getLayout() {
		return layout;
	}

	public void setLayout(List<Section> layout) {
		this.layout = layout;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
