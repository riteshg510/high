package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.T222CodRacfExtEnt;
import com.hmhs.hvwmid.entity.T222CodRacfExtEntId;

/**
 * Repository for T222_COD_RACF_EXT_ENT table operations.
 * Handles RACF entity mappings for user client code access control.
 */
@Repository
public interface T222CodRacfExtEntRepository extends JpaRepository<T222CodRacfExtEnt, T222CodRacfExtEntId> {

    /**
     * Retrieves distinct client codes for a user from RACF entities.
     * Extracts client codes using SUBSTR(RACF_ENTITY, 5, 4) to get 4-character client codes
     * starting from position 5 of the RACF entity string.
     * 
     * @param userId User ID to lookup
     * @return List of distinct client codes (e.g., HMRK, NDAK, MINN, WYOM, IBC1)
     */
    @Query(value = "SELECT DISTINCT SUBSTR(RACF_ENTITY, 5, 4) AS CLIENT_CODE " +
                   "FROM T222_COD_RACF_EXT_ENT WHERE RACF_USER_ID = :userId", nativeQuery = true)
    List<String> getUserClientCodes(@Param("userId") String userId);

    /**
     * Retrieves all RACF entities for a specific user.
     * 
     * @param userId User ID to lookup
     * @return List of T222CodRacfExtEnt entities for the user
     */
    @Query("SELECT r FROM T222CodRacfExtEnt r WHERE r.racfUserId = :userId")
    List<T222CodRacfExtEnt> findByRacfUserId(@Param("userId") String userId);

    /**
     * Retrieves RACF entities for a specific user and class.
     * 
     * @param userId User ID to lookup
     * @param racfClass RACF class to filter by
     * @return List of T222CodRacfExtEnt entities matching criteria
     */
    @Query("SELECT r FROM T222CodRacfExtEnt r WHERE r.racfUserId = :userId AND r.racfClass = :racfClass")
    List<T222CodRacfExtEnt> findByRacfUserIdAndRacfClass(@Param("userId") String userId, 
                                                         @Param("racfClass") String racfClass);

    /**
     * Checks if a user has access to a specific RACF entity.
     * 
     * @param userId User ID to check
     * @param racfEntity RACF entity to verify access for
     * @return true if user has access, false otherwise
     */
    @Query("SELECT COUNT(r) > 0 FROM T222CodRacfExtEnt r WHERE r.racfUserId = :userId AND r.racfEntity = :racfEntity")
    boolean hasUserAccessToEntity(@Param("userId") String userId, @Param("racfEntity") String racfEntity);

    /**
     * Retrieves all distinct RACF classes in the system.
     * 
     * @return List of distinct RACF classes
     */
    @Query("SELECT DISTINCT r.racfClass FROM T222CodRacfExtEnt r ORDER BY r.racfClass")
    List<String> findDistinctRacfClasses();

    /**
     * Retrieves all RACF entities for specific client codes.
     * Used to validate user access against specific client codes.
     * 
     * @param clientCodes List of client codes to filter by
     * @return List of RACF entities containing the specified client codes
     */
    @Query(value = "SELECT r.* FROM T222_COD_RACF_EXT_ENT r " +
                   "WHERE SUBSTR(r.RACF_ENTITY, 5, 4) IN (:clientCodes)", nativeQuery = true)
    List<T222CodRacfExtEnt> findByClientCodes(@Param("clientCodes") List<String> clientCodes);
}