package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IMISearchResults {
   
    @JsonProperty("naicCode")
    private String naicCode;
    
    @JsonProperty("transmitTimestamp")
	private String transmitTimeStamp;
	
	@JsonProperty("transmitFileId")
	private long transmitFileId;
	
	@JsonProperty("transmitFileName")
	private String transmitFileName;
	
	@JsonProperty("transmitFileStatusCd")
	private String transmitFileStatusCd;
	
	@JsonProperty("imiFileId")
	private long imiFileId;
	
	@JsonProperty("planFileId")
	private String planFileId;
	
	@JsonProperty("processFileName")
	private String processFileName;
	
	@JsonProperty("processFileStatusCd")
	private String processFileStatusCd;
	
	@JsonProperty("processFileReasonCdDesc")
	private String processFileReasonCdDesc;
	
	@JsonProperty("timeAck")
	private String timeAck;
	
	@JsonProperty("imiDocumentId")
	private Integer imiDocumentId;
	
	@JsonProperty("planDCN")
	private String planDCN;
	
	@JsonProperty("dpk")
	private String dpk;
	
	@JsonProperty("initialProcessDCN")
	private String initialProcessDCN;
	
	@JsonProperty("finalProcessDCN")
	private String finalProcessDCN;
	
	@JsonProperty("documentStatusCd")
	private String documentStatusCd;
	
	@JsonProperty("documentReasonCdDesc")
	private String documentReasonCdDesc;
	
	@JsonProperty("timeUpdate")
	private String timeUpdate;
	
	@JsonProperty("applIdCd")
	private String applIdCd;
	
	@JsonProperty("captureItemId")
	private String captureItemId;
	
	@JsonProperty("resultSetPointer")
	private long resultSetPointer;

    // Getters and Setters
    public String getNaicCode() {
        return naicCode;
    }

    public void setNaicCode(String naicCode) {
        this.naicCode = naicCode;
    }   

    public String getTransmitTimeStamp() {
		return transmitTimeStamp;
	}

	public void setTransmitTimeStamp(String transmitTimeStamp) {
		this.transmitTimeStamp = transmitTimeStamp;
	}

	public long getTransmitFileId() {
        return transmitFileId;
    }

    public void setTransmitFileId(long transmitFileId) {
        this.transmitFileId = transmitFileId;
    }

    public String getTransmitFileName() {
        return transmitFileName;
    }

    public void setTransmitFileName(String transmitFileName) {
        this.transmitFileName = transmitFileName;
    }

    public String getTransmitFileStatusCd() {
        return transmitFileStatusCd;
    }

    public void setTransmitFileStatusCd(String transmitFileStatusCd) {
        this.transmitFileStatusCd = transmitFileStatusCd;
    }

    public long getImiFileId() {
        return imiFileId;
    }

    public void setImiFileId(long imiFileId) {
        this.imiFileId = imiFileId;
    }

    public String getPlanFileId() {
        return planFileId;
    }

    public void setPlanFileId(String planFileId) {
        this.planFileId = planFileId;
    }

    public String getProcessFileName() {
        return processFileName;
    }

    public void setProcessFileName(String processFileName) {
        this.processFileName = processFileName;
    }

    public String getProcessFileStatusCd() {
        return processFileStatusCd;
    }

    public void setProcessFileStatusCd(String processFileStatusCd) {
        this.processFileStatusCd = processFileStatusCd;
    }

    public String getProcessFileReasonCdDesc() {
        return processFileReasonCdDesc;
    }

    public void setProcessFileReasonCdDesc(String processFileReasonCdDesc) {
        this.processFileReasonCdDesc = processFileReasonCdDesc;
    }

    public String getTimeAck() {
        return timeAck;
    }

    public void setTimeAck(String timeAck) {
        this.timeAck = timeAck;
    }

    public Integer getImiDocumentId() {
        return imiDocumentId;
    }

    public void setImiDocumentId(Integer imiDocumentId) {
        this.imiDocumentId = imiDocumentId;
    }

    public String getPlanDCN() {
        return planDCN;
    }

    public void setPlanDCN(String planDCN) {
        this.planDCN = planDCN;
    }

    public String getDpk() {
        return dpk;
    }

    public void setDpk(String dpk) {
        this.dpk = dpk;
    }

    public String getInitialProcessDCN() {
        return initialProcessDCN;
    }

    public void setInitialProcessDCN(String initialProcessDCN) {
        this.initialProcessDCN = initialProcessDCN;
    }

    public String getFinalProcessDCN() {
        return finalProcessDCN;
    }

    public void setFinalProcessDCN(String finalProcessDCN) {
        this.finalProcessDCN = finalProcessDCN;
    }

    public String getDocumentStatusCd() {
        return documentStatusCd;
    }

    public void setDocumentStatusCd(String documentStatusCd) {
        this.documentStatusCd = documentStatusCd;
    }

    public String getDocumentReasonCdDesc() {
        return documentReasonCdDesc;
    }

    public void setDocumentReasonCdDesc(String documentReasonCdDesc) {
        this.documentReasonCdDesc = documentReasonCdDesc;
    }

    public String getTimeUpdate() {
        return timeUpdate;
    }

    public void setTimeUpdate(String timeUpdate) {
        this.timeUpdate = timeUpdate;
    }

    public String getApplIdCd() {
        return applIdCd;
    }

    public void setApplIdCd(String applIdCd) {
        this.applIdCd = applIdCd;
    }

    public String getCaptureItemId() {
        return captureItemId;
    }

    public void setCaptureItemId(String captureItemId) {
        this.captureItemId = captureItemId;
    }

    public long getResultSetPointer() {
        return resultSetPointer;
    }

    public void setResultSetPointer(long resultSetPointer) {
        this.resultSetPointer = resultSetPointer;
    }
} 