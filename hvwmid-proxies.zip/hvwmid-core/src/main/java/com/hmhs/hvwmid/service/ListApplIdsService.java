package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.IntStream;

@Service
public class ListApplIdsService {

    private static final Logger logger = LogManager.getLogger(ListApplIdsService.class);

    @Autowired
    private RestClientUtil restClientUtil;

    public static final String PARMID_HVW_IMG = "HVWIMG";


    @Value("${api.images.listapplids.url}")
    String url = null; // /violation/filter

    private static final String X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS = "x-highmark-businessProcessDifferentiatorIds";
    private static final String BPDID_FIELD = "bpdid";
    @Autowired
    private T222APRMRepository t222APRMRepository;

    public ResponseEntity<Object> filter(Map<String, String> otherFields, String authToken) {
        return executeAction(otherFields, authToken);
    }

    public ResponseEntity<Object> executeAction(Map<String, String> otherFields, String authToken) {
        final ResponseEntity<Map> response = getFromBack(otherFields, authToken);

        List<Map> result = getResults(response.getBody());

        return new ResponseEntity<>(result, response.getStatusCode());
    }

    private ResponseEntity<Map> getFromBack(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>(otherFields);

        Map<String, String> extraHeaders = generateExtraHeaders(otherFields);

        return restClientUtil.postRequest(url+"/list", authToken, requestBody, extraHeaders);
    }

    private static Map<String, String> generateExtraHeaders(Map<String, String> otherFields) {
        Map<String, String> extraHeaders = new HashMap<>();

        if (otherFields.containsKey(BPDID_FIELD) && !StringUtils.isBlank(otherFields.get(BPDID_FIELD))) {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, otherFields.get(BPDID_FIELD));
        } else {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, "1");
        }

        return extraHeaders;
    }

    private List<Map> getResults(Map response){
        List<Map> result = new ArrayList<>();
        if(response.containsKey("results")){
            Map applIds = (Map) response.get("results");
            if(applIds.containsKey("application")){
                List applList = (List) applIds.get("application");
                for(Object applObj: applList){
                    Map appl = (Map) applObj;
                    if(appl.containsKey("applidcd") && appl.containsKey("description")){
                        String key = appl.get("applidcd").toString();
                        String description = appl.get("description").toString();
                        String displayName = description + " (" + key + ")";
                        result.add(new HashMap<>() {{
                            put("key", key);
                            put("displayName", displayName);
                        }});
                    }
                }
            }
        }
        return result;
    }

    public ResponseEntity<Object> listBatchtblIds(Map<String, String> otherFields, String authToken) {

        List<T222APRM> t222APRMS = t222APRMRepository.findByParmId(PARMID_HVW_IMG);

        t222APRMS = t222APRMS.stream().filter(t222APRM -> t222APRM.getParmKey().contains("CONFIGLISTING_BATCHTBL_SCHEMAS")).toList();

        List<String> result = t222APRMS.stream()
                .map(T222APRM::getParmData)
                .filter(Objects::nonNull)
                .flatMap(s -> Arrays.stream(s.split(",")))
                .map(String::trim)
                .toList();

        List<Map<String, String>> mapped = IntStream.range(0, result.size())
                .mapToObj(i -> {
                    Map<String, String> map = new HashMap<>();
                    map.put("displayName", result.get(i));
                    map.put("key", result.get(i));
                    return map;
                })
                .toList();

        return ResponseEntity.ok(mapped);
    }

}