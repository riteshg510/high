package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblTemplates;

/**
 * @author Ramanjaneyulu Manam on Sept 3, 2024
 */
@Repository
public interface TemplateDataRepository extends JpaRepository<TblTemplates, String> {

	/**
	 * @param templateName
	 * @return
	 */
	List<TblTemplates> getTempletByTemplateName(String templateName);

}
