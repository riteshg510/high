package com.hmhs.hvwmid.model;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.validations.ValidActiveType;
import jakarta.validation.constraints.Size;

public class CoverSheetApplicationDTO {

    private Integer application;
    @Size(max = 40, message = "Description cannot exceed 40 characters")
    private String description;
    private Integer sequence;
    private T117ImgCoverDept department;
    @ValidActiveType
    private String active;
    @Size(max = 5, message = "applId cannot exceed 5 characters")
    private String applId;

    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public String getDescription() {
        if (description == null)
            return "";
        return description.trim();
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public T117ImgCoverDept getDeptId() {
        return department;
    }

    public void setDeptId(T117ImgCoverDept deptId) {
        this.department = deptId;
    }

    public String getActive() {
        if (active == null) {
            return "N";
        }
        return active.trim();
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getApplId() {
        if (applId == null) {
            return "";
        }
        return applId.trim();
    }

    public void setApplId(String applId) {
        this.applId = applId;
    }

}
