package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

@Embeddable
public class TblHvwStatusId implements Serializable {
    @Column(name = "REQUEST_ID", nullable = false)
    private int requestId;

    @Column(name = "TIME_CREATE", nullable = false)
    private Timestamp timeCreate;

    public TblHvwStatusId() {}

    public TblHvwStatusId(int requestId, Timestamp timeCreate) {
        this.requestId = requestId;
        this.timeCreate = timeCreate;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public Timestamp getTimeCreate() {
        return timeCreate;
    }

    public void setTimeCreate(Timestamp timeCreate) {
        this.timeCreate = timeCreate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TblHvwStatusId that = (TblHvwStatusId) o;
        return requestId == that.requestId && Objects.equals(timeCreate, that.timeCreate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(requestId, timeCreate);
    }
}
