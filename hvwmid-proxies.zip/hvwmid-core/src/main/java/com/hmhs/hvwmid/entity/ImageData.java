package com.hmhs.hvwmid.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Oct 9, 2024
 */
@Entity
@Table(name = "tbl_image_data")
public class ImageData {

	@Id
	private Long id;
	private String applicationId;
	private String fileTab;
	@Column(name = "filed", columnDefinition = "TIMESTAMP")
	private LocalDateTime filed;
	private String folderId;
	private String formDescription;
	private int pages;
	@Column(name = "received", columnDefinition = "TIMESTAMP")
	private LocalDateTime received;
	private String view;
	private String update;
	private String fileName;

	public ImageData(Long id, String appId) {
		this.id = id;
		this.applicationId = appId;
	}

	public ImageData() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getFileTab() {
		return fileTab;
	}

	public void setFileTab(String fileTab) {
		this.fileTab = fileTab;
	}

	public LocalDateTime getFiled() {
		return filed;
	}

	public void setFiled(LocalDateTime filed) {
		this.filed = filed;
	}

	public String getFolderId() {
		return folderId;
	}

	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}

	public String getFormDescription() {
		return formDescription;
	}

	public void setFormDescription(String formDescription) {
		this.formDescription = formDescription;
	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}

	public LocalDateTime getReceived() {
		return received;
	}

	public void setReceived(LocalDateTime received) {
		this.received = received;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}

	public String getUpdate() {
		return update;
	}

	public void setUpdate(String update) {
		this.update = update;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
