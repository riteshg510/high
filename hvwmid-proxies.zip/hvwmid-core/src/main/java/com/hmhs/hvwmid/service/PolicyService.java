package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.dto.PolicyWithHoldDTO;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.repository.T222ImgRmaPolicyRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.hmhs.hvwmid.constants.PolicyHoldConstants.ASC;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.BPD_ID;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLDS;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_CODE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_DATE_BEGIN;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_DATE_END;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_DESCRIPTION;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_EDIT_FLAG;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_EDIT_PGM_NAME;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_ID;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLD_MOD_USER;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.MOD_DATE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.MOD_USER;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_BASE_DATE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_CODE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_DAYS;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_DESCRIPTION;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_EDIT_FLAG;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_EDIT_PGM_NAME;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_ID;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_ID_TYPE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.RMPOLTYP;

@Service
public class PolicyService {
    private static final Logger logger = LogManager.getLogger(PolicyService.class);

    private final T222ImgRmaPolicyRepository t222ImgRmaPolicyRepository;
    private final PolicyHoldService policyHoldService;
    private final T222APRMRepository t222aprmRepository;
    private final EntityManager entityManager;

    public PolicyService(T222ImgRmaPolicyRepository t222ImgRmaPolicyRepository, PolicyHoldService policyHoldService, T222APRMRepository t222aprmRepository, EntityManager entityManager) {
        this.t222ImgRmaPolicyRepository = t222ImgRmaPolicyRepository;
        this.policyHoldService = policyHoldService;
        this.t222aprmRepository = t222aprmRepository;
        this.entityManager = entityManager;
    }

    public List<Integer> getClientIds() {
        return t222ImgRmaPolicyRepository.findDistinctBpdIds();
    }

    public List<PickListItems> getNoServiceClientIds() {
        List<Integer> bpdIds = t222ImgRmaPolicyRepository.findDistinctBpdIds();
        Map<String, String> clientMap = new HashMap<>();
        
        // Transform integer BPD IDs to string keys and use BPD ID as both key and display name
        for (Integer bpdId : bpdIds) {
            String bpdIdStr = String.valueOf(bpdId);
            clientMap.put(bpdIdStr, bpdIdStr);
        }
        
        return transformMapToPickListItems(clientMap);
    }

    public Page<PolicyWithHoldDTO> listPolicies(Map<String, String> otherFields) {
        Integer bpdId = Integer.valueOf(otherFields.get(BPD_ID));
        int page = otherFields.get("page") != null ? Integer.parseInt(otherFields.get("page")) : 0;
        int pageSize = otherFields.get("pageSize") != null ? Integer.parseInt(otherFields.get("pageSize")) : 20;

        String sortColumn = otherFields.getOrDefault("sortColumn", POLICY_CODE);
        String sortDirection = otherFields.getOrDefault("sortDirection", ASC);
        Sort sort = Sort.by(sortDirection.equalsIgnoreCase(ASC) ? Sort.Order.asc(sortColumn) : Sort.Order.desc(sortColumn));
        Pageable pageable = PageRequest.of(page, pageSize, sort);

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT ")
                .append("p.POLICY_CODE as policyCode, ")
                .append("p.POLICY_ID as policyId, ")
                .append("p.POLICY_DESCRIPTION as policyDescription, ")
                .append("p.POLICY_ID_TYPE as policyIdType, ")
                .append("p.POLICY_DAYS as policyDays, ")
                .append("p.POLICY_EDIT_FLAG as policyEditFlag, ")
                .append("p.POLICY_EDIT_PGMNAME as policyEditPgmName, ")
                .append("VARCHAR_FORMAT(p.POLICY_BASE_DATE, 'YYYY-MM-DD') as policyBaseDate, ")
                .append("p.MODUSER as modUser, ")
                .append("VARCHAR_FORMAT(p.MODDATE, 'YYYY-MM-DD HH24:MI:SS') as modDate, ")
                .append("p.BPD_ID as bpdId, ")
                .append("h.HOLD_CODE as holdCode, ")
                .append("h.HOLD_ID as holdId, ")
                .append("h.HOLD_DESCRIPTION as holdDescription, ")
                .append("h.HOLD_EDIT_FLAG as holdEditFlag, ")
                .append("h.HOLD_EDIT_PGMNAME as holdPgmName, ")
                .append("h.MODUSER as holdModUser, ")
                .append("VARCHAR_FORMAT(h.HOLD_DATE_BEGIN, 'YYYY-MM-DD') as holdDateBegin, ")
                .append("VARCHAR_FORMAT(h.HOLD_DATE_END, 'YYYY-MM-DD') as holdDateEnd ")
                .append("FROM T222_IMG_RMA_POLICY p ")
                .append("LEFT JOIN T222_IMG_RMA_POLICY_HOLD ph ")
                .append("ON p.POLICY_CODE = ph.POLICY_CODE AND p.BPD_ID = ph.BPD_ID ")
                .append("LEFT JOIN T222_IMG_RMA_HOLD h ")
                .append("ON ph.HOLD_CODE = h.HOLD_CODE AND ph.BPD_ID = h.BPD_ID ")
                .append("WHERE p.BPD_ID = :bpdId ");

        Map<String, Object> params = new HashMap<>();
        params.put("bpdId", bpdId);

        if (otherFields.get(POLICY_CODE) != null) {
            sql.append(" AND CAST(p.POLICY_CODE AS VARCHAR(50)) LIKE :policyCode ");
            params.put("policyCode", otherFields.get(POLICY_CODE));
        }
        if (otherFields.get(POLICY_ID) != null) {
            sql.append(" AND p.POLICY_ID LIKE :policyId ");
            params.put("policyId", otherFields.get(POLICY_ID));
        }
        if (otherFields.get(POLICY_DESCRIPTION) != null) {
            sql.append(" AND p.POLICY_DESCRIPTION LIKE '%' || :policyDescription || '%' ");
            params.put("policyDescription", otherFields.get(POLICY_DESCRIPTION));
        }
        if (otherFields.get(POLICY_ID_TYPE) != null) {
            sql.append(" AND p.POLICY_ID_TYPE LIKE :policyIdType ");
            params.put("policyIdType", otherFields.get(POLICY_ID_TYPE));
        }
        if (otherFields.get(POLICY_DAYS) != null) {
            sql.append(" AND CAST(p.POLICY_DAYS AS VARCHAR(50)) LIKE :policyDays ");
            params.put("policyDays", otherFields.get(POLICY_DAYS));
        }
        if (otherFields.get(POLICY_EDIT_FLAG) != null) {
            sql.append(" AND p.POLICY_EDIT_FLAG LIKE :policyEditFlag ");
            params.put("policyEditFlag", otherFields.get(POLICY_EDIT_FLAG));
        }
        if (otherFields.get(POLICY_EDIT_PGM_NAME) != null) {
            sql.append(" AND p.POLICY_EDIT_PGMNAME LIKE :policyEditPgmName ");
            params.put("policyEditPgmName", otherFields.get(POLICY_EDIT_PGM_NAME));
        }
        if (otherFields.get(POLICY_BASE_DATE) != null) {
            sql.append(" AND p.POLICY_BASE_DATE >= :policyBaseDateStart AND p.POLICY_BASE_DATE < :policyBaseDateEnd ");
            LocalDate d = LocalDate.parse(otherFields.get(POLICY_BASE_DATE));
            params.put("policyBaseDateStart", java.sql.Date.valueOf(d));
            params.put("policyBaseDateEnd", java.sql.Date.valueOf(d.plusDays(1)));
        }
        if (otherFields.get(MOD_USER) != null) {
            sql.append(" AND p.MODUSER LIKE :modUser ");
            params.put("modUser", otherFields.get(MOD_USER));
        }
        if (otherFields.get(MOD_DATE) != null) {
            sql.append(" AND p.MODDATE >= :modDateStart AND p.MODDATE < :modDateEnd ");
            LocalDateTime dt = LocalDateTime.parse(otherFields.get(MOD_DATE));
            params.put("modDateStart", java.sql.Timestamp.valueOf(dt));
            params.put("modDateEnd", java.sql.Timestamp.valueOf(dt.plusDays(1)));
        }

        if (otherFields.get(HOLD_CODE) != null) {
            sql.append(" AND CAST(h.HOLD_CODE AS VARCHAR(50)) LIKE :holdCode ");
            params.put("holdCode", otherFields.get(HOLD_CODE));
        }
        if (otherFields.get(HOLD_ID) != null) {
            sql.append(" AND h.HOLD_ID LIKE :holdId ");
            params.put("holdId", otherFields.get(HOLD_ID));
        }
        if (otherFields.get(HOLD_DESCRIPTION) != null) {
            sql.append(" AND h.HOLD_DESCRIPTION LIKE '%' || :holdDescription || '%' ");
            params.put("holdDescription", otherFields.get(HOLD_DESCRIPTION));
        }
        if (otherFields.get(HOLD_EDIT_FLAG) != null) {
            sql.append(" AND h.HOLD_EDIT_FLAG LIKE :holdEditFlag ");
            params.put("holdEditFlag", otherFields.get(HOLD_EDIT_FLAG));
        }
        if (otherFields.get(HOLD_EDIT_PGM_NAME) != null) {
            sql.append(" AND h.HOLD_EDIT_PGMNAME LIKE :holdEditPgmName ");
            params.put("holdEditPgmName", otherFields.get(HOLD_EDIT_PGM_NAME));
        }
        if (otherFields.get(HOLD_MOD_USER) != null) {
            sql.append(" AND h.MODUSER LIKE :holdModUser ");
            params.put("holdModUser", otherFields.get(HOLD_MOD_USER));
        }
        if (otherFields.get(HOLD_DATE_BEGIN) != null) {
            sql.append(" AND h.HOLD_DATE_BEGIN >= :holdDateBeginStart AND h.HOLD_DATE_BEGIN < :holdDateBeginEnd ");
            LocalDate d = LocalDate.parse(otherFields.get(HOLD_DATE_BEGIN));
            params.put("holdDateBeginStart", java.sql.Date.valueOf(d));
            params.put("holdDateBeginEnd", java.sql.Date.valueOf(d.plusDays(1)));
        }
        if (otherFields.get(HOLD_DATE_END) != null) {
            sql.append(" AND h.HOLD_DATE_END >= :holdDateEndStart AND h.HOLD_DATE_END < :holdDateEndEnd ");
            LocalDate d = LocalDate.parse(otherFields.get(HOLD_DATE_END));
            params.put("holdDateEndStart", java.sql.Date.valueOf(d));
            params.put("holdDateEndEnd", java.sql.Date.valueOf(d.plusDays(1)));
        }

        sql.append(" ORDER BY ").append(sortColumn).append(" ").append(sortDirection);
        sql.append(" OFFSET ").append(page * pageSize).append(" ROWS FETCH NEXT ").append(pageSize).append(" ROWS ONLY");

        Query query = entityManager.createNativeQuery(sql.toString());
        params.forEach(query::setParameter);

        @SuppressWarnings("unchecked")
        List<Object[]> rows = query.getResultList();

        List<PolicyWithHoldDTO> result = rows.stream()
                .map(PolicyWithHoldDTO::new)
                .toList();

        long total = countTotal(otherFields, bpdId);

        return new PageImpl<>(result, pageable, total);
    }

    private long countTotal(Map<String, String> otherFields, Integer bpdId) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM T222_IMG_RMA_POLICY p ")
                .append("LEFT JOIN T222_IMG_RMA_POLICY_HOLD ph ")
                .append("ON p.POLICY_CODE = ph.POLICY_CODE AND p.BPD_ID = ph.BPD_ID ")
                .append("LEFT JOIN T222_IMG_RMA_HOLD h ")
                .append("ON ph.HOLD_CODE = h.HOLD_CODE AND ph.BPD_ID = h.BPD_ID ")
                .append("WHERE p.BPD_ID = :bpdId ");

        Map<String, Object> params = new HashMap<>();
        params.put("bpdId", bpdId);

        if (otherFields.get(POLICY_CODE) != null) {
            sql.append(" AND CAST(p.POLICY_CODE AS VARCHAR(50)) LIKE :policyCode ");
            params.put("policyCode", otherFields.get(POLICY_CODE));
        }
        if (otherFields.get(POLICY_ID) != null) {
            sql.append(" AND p.POLICY_ID LIKE :policyId ");
            params.put("policyId", otherFields.get(POLICY_ID));
        }
        if (otherFields.get(POLICY_DESCRIPTION) != null) {
            sql.append(" AND p.POLICY_DESCRIPTION LIKE '%' || :policyDescription || '%' ");
            params.put("policyDescription", otherFields.get(POLICY_DESCRIPTION));
        }
        if (otherFields.get(POLICY_ID_TYPE) != null) {
            sql.append(" AND p.POLICY_ID_TYPE LIKE :policyIdType ");
            params.put("policyIdType", otherFields.get(POLICY_ID_TYPE));
        }
        if (otherFields.get(POLICY_DAYS) != null) {
            sql.append(" AND CAST(p.POLICY_DAYS AS VARCHAR(50)) LIKE :policyDays ");
            params.put("policyDays", otherFields.get(POLICY_DAYS));
        }
        if (otherFields.get(POLICY_EDIT_FLAG) != null) {
            sql.append(" AND p.POLICY_EDIT_FLAG LIKE :policyEditFlag ");
            params.put("policyEditFlag", otherFields.get(POLICY_EDIT_FLAG));
        }
        if (otherFields.get(POLICY_EDIT_PGM_NAME) != null) {
            sql.append(" AND p.POLICY_EDIT_PGMNAME LIKE :policyEditPgmName ");
            params.put("policyEditPgmName", otherFields.get(POLICY_EDIT_PGM_NAME));
        }
        if (otherFields.get(POLICY_BASE_DATE) != null) {
            sql.append(" AND p.POLICY_BASE_DATE >= :policyBaseDateStart AND p.POLICY_BASE_DATE < :policyBaseDateEnd ");
            LocalDate d = LocalDate.parse(otherFields.get(POLICY_BASE_DATE));
            params.put("policyBaseDateStart", java.sql.Date.valueOf(d));
            params.put("policyBaseDateEnd", java.sql.Date.valueOf(d.plusDays(1)));
        }
        if (otherFields.get(MOD_USER) != null) {
            sql.append(" AND p.MODUSER LIKE :modUser ");
            params.put("modUser", otherFields.get(MOD_USER));
        }
        if (otherFields.get(MOD_DATE) != null) {
            sql.append(" AND p.MODDATE >= :modDateStart AND p.MODDATE < :modDateEnd ");
            LocalDateTime dt = LocalDateTime.parse(otherFields.get(MOD_DATE));
            params.put("modDateStart", java.sql.Timestamp.valueOf(dt));
            params.put("modDateEnd", java.sql.Timestamp.valueOf(dt.plusDays(1)));
        }

        if (otherFields.get(HOLD_CODE) != null) {
            sql.append(" AND CAST(h.HOLD_CODE AS VARCHAR(50)) LIKE :holdCode ");
            params.put("holdCode", otherFields.get(HOLD_CODE));
        }
        if (otherFields.get(HOLD_ID) != null) {
            sql.append(" AND h.HOLD_ID LIKE :holdId ");
            params.put("holdId", otherFields.get(HOLD_ID));
        }
        if (otherFields.get(HOLD_DESCRIPTION) != null) {
            sql.append(" AND h.HOLD_DESCRIPTION LIKE '%' || :holdDescription || '%' ");
            params.put("holdDescription", otherFields.get(HOLD_DESCRIPTION));
        }
        if (otherFields.get(HOLD_EDIT_FLAG) != null) {
            sql.append(" AND h.HOLD_EDIT_FLAG LIKE :holdEditFlag ");
            params.put("holdEditFlag", otherFields.get(HOLD_EDIT_FLAG));
        }
        if (otherFields.get(HOLD_EDIT_PGM_NAME) != null) {
            sql.append(" AND h.HOLD_EDIT_PGMNAME LIKE :holdEditPgmName ");
            params.put("holdEditPgmName", otherFields.get(HOLD_EDIT_PGM_NAME));
        }
        if (otherFields.get(HOLD_MOD_USER) != null) {
            sql.append(" AND h.MODUSER LIKE :holdModUser ");
            params.put("holdModUser", otherFields.get(HOLD_MOD_USER));
        }
        if (otherFields.get(HOLD_DATE_BEGIN) != null) {
            sql.append(" AND h.HOLD_DATE_BEGIN >= :holdDateBeginStart AND h.HOLD_DATE_BEGIN < :holdDateBeginEnd ");
            LocalDate d = LocalDate.parse(otherFields.get(HOLD_DATE_BEGIN));
            params.put("holdDateBeginStart", java.sql.Date.valueOf(d));
            params.put("holdDateBeginEnd", java.sql.Date.valueOf(d.plusDays(1)));
        }
        if (otherFields.get(HOLD_DATE_END) != null) {
            sql.append(" AND h.HOLD_DATE_END >= :holdDateEndStart AND h.HOLD_DATE_END < :holdDateEndEnd ");
            LocalDate d = LocalDate.parse(otherFields.get(HOLD_DATE_END));
            params.put("holdDateEndStart", java.sql.Date.valueOf(d));
            params.put("holdDateEndEnd", java.sql.Date.valueOf(d.plusDays(1)));
        }

        Query query = entityManager.createNativeQuery(sql.toString());
        params.forEach(query::setParameter);

        Object singleResult = query.getSingleResult();
        return singleResult != null ? ((Number) singleResult).longValue() : 0L;
    }


    @Transactional
    public T222ImgRmaPolicy createPolicy(Map<String, String> otherFields, String loginUser) {
        logger.info("Creating new policy....");
        T222ImgRmaPolicy policy = new T222ImgRmaPolicy();

        setPolicyFields(otherFields, loginUser, policy);

        policy = t222ImgRmaPolicyRepository.save(policy);

        String holds = otherFields.get(HOLDS);

        if (!StringUtils.isBlank(holds)) {
            policyHoldService.create(loginUser, holds, policy);
        }

        logger.info("Policy created successfully.");
        return policy;
    }

    private void setPolicyFields(Map<String, String> otherFields, String loginUser, T222ImgRmaPolicy policy) {
        validateMandatoryFields(otherFields);

        setPolicyBpdId(otherFields, policy);

        setPolicyCodeIfExists(otherFields, policy);

        policy.setPolicyId(otherFields.get(POLICY_ID));
        policy.setPolicyIdType(otherFields.get(POLICY_ID_TYPE));
        policy.setPolicyDescription(otherFields.get(POLICY_DESCRIPTION));

        String policyDaysStr = otherFields.get(POLICY_DAYS);
        setPolicyDays(policy, policyDaysStr);

        String policyBaseDateStr = otherFields.get(POLICY_BASE_DATE);
        setPolicyBaseDate(policy, policyBaseDateStr);

        String policyEditFlag = otherFields.get(POLICY_EDIT_FLAG);
        setPolicyEditFlagAndName(policy, policyEditFlag, otherFields.get(POLICY_EDIT_PGM_NAME));

        setModUser(loginUser, policy);

        policy.setModDate(LocalDateTime.now());
    }

    private static void setPolicyCodeIfExists(Map<String, String> otherFields, T222ImgRmaPolicy policy) {
        String policyCodeStr = otherFields.get(POLICY_CODE);
        if (StringUtils.isNotBlank(policyCodeStr)) {
            try {
                policy.setPolicyCode(Integer.parseInt(policyCodeStr));
            } catch (NumberFormatException e) {
                throw new HVWException("Invalid numeric value for policyCode: " + policyCodeStr);
            }
        }
    }

    private void validateMandatoryFields(Map<String, String> otherFields) {
        String[] mandatoryFields = {
                BPD_ID,
                POLICY_ID,
                POLICY_DAYS,
                POLICY_ID_TYPE,
                POLICY_EDIT_PGM_NAME,
                POLICY_DESCRIPTION
        };

        for (String field : mandatoryFields) {
            String value = otherFields.get(field);
            if (value == null || value.trim().isEmpty()) {
                throw new HVWException("Missing mandatory field: " + field);
            }
        }
    }

    private void setModUser(String loginUser, T222ImgRmaPolicy policy) {
        if (loginUser == null || loginUser.isEmpty()) {
            throw new HVWException("Missing mandatory field: loginUser");
        }
        policy.setModUser(loginUser);
    }

    private void setPolicyEditFlagAndName(T222ImgRmaPolicy policy, String policyEditFlag, String policyEditPgmName) {
        if (policyEditFlag != null && !policyEditFlag.isEmpty()) {
            if (!policyEditFlag.equals("Y") && !policyEditFlag.equals("N")) {
                throw new HVWException("Invalid value for policyEditFlag. Must be 'Y' or 'N'");
            }
            policy.setPolicyEditFlag(policyEditFlag);

            if ("Y".equals(policyEditFlag)) {
                if (policyEditPgmName == null || policyEditPgmName.isEmpty()) {
                    throw new HVWException("policyEditPgmName must be set when policyEditFlag is Y");
                }
                policy.setPolicyEditPgmName(policyEditPgmName);
            } else {
                policy.setPolicyEditPgmName("N/A");
            }
        }
    }


    private void setPolicyBaseDate(T222ImgRmaPolicy policy, String policyBaseDateStr) {
        if (policyBaseDateStr != null && !policyBaseDateStr.isEmpty()) {
            try {
                policy.setPolicyBaseDate(LocalDate.parse(policyBaseDateStr));
            } catch (DateTimeParseException e) {
                throw new HVWException("Invalid date format for policyBaseDate: " + policyBaseDateStr);
            }
        }
    }

    private void setPolicyDays(T222ImgRmaPolicy policy, String policyDaysStr) {
        try {
            policy.setPolicyDays(Integer.valueOf(policyDaysStr));
        } catch (NumberFormatException e) {
            throw new HVWException("Invalid numeric value for policyDays: " + policyDaysStr);
        }
    }

    private void setPolicyBpdId(Map<String, String> otherFields, T222ImgRmaPolicy policy) {
        try {
            policy.setBpdId(Integer.valueOf(otherFields.get(BPD_ID)));
        } catch (NumberFormatException e) {
            throw new HVWException("Invalid numeric value for bpdId: " + otherFields.get(BPD_ID));
        }
    }

    @Transactional
    public T222ImgRmaPolicy updatePolicy(Map<String, String> otherFields, String loginUser) {
        logger.info("Updating existing policy....");

        String policyCodeStr = otherFields.get(POLICY_CODE);
        if (StringUtils.isBlank(policyCodeStr)) {
            throw new HVWException("Missing mandatory field: policy_code for update");
        }

        int policyCode;
        try {
            policyCode = Integer.parseInt(policyCodeStr);
        } catch (NumberFormatException e) {
            throw new HVWException("Invalid numeric value for policyCode: " + policyCodeStr);
        }

        T222ImgRmaPolicy policy = this.getByPolicyCode(policyCode);

        setPolicyFields(otherFields, loginUser, policy);

        policy = t222ImgRmaPolicyRepository.save(policy);

        String holds = otherFields.get(HOLDS);
        if (!StringUtils.isBlank(holds)) {
            policyHoldService.update(loginUser, holds, policy);
        }

        logger.info("Policy updated successfully.");
        return policy;
    }

    public T222ImgRmaPolicy getByPolicyCode(Integer policyCode) {
        return t222ImgRmaPolicyRepository.findByPolicyCode(policyCode)
                .orElseThrow(() -> new HVWException("Policy with code " + policyCode + " not found"));
    }

    @Transactional
    public void delete(Integer policyCode) {
        logger.info("Deleting policy with POLICY_CODE {}", policyCode);
        policyHoldService.deleteByPolicyCode(policyCode);
        t222ImgRmaPolicyRepository.deleteByPolicyCode(policyCode);
        logger.info("policy with POLICY_CODE {} successfully deleted.", policyCode);
    }

    public List<String> getPolicyTypeKeys() {
        List<String> policyTypeKeys = t222aprmRepository.findByParmId(RMPOLTYP)
                .stream()
                .map(T222APRM::getParmKey)
                .toList();

        if (policyTypeKeys.isEmpty()) {
            policyTypeKeys = List.of("t1", "t2", "t3"); // default keys
        }

        return policyTypeKeys;
    }

    public List<PickListItems> transformMapToPickListItems(Map<String, String> sourceMap) {
		List<PickListItems> pickList = new ArrayList<>();
		long id = 0;
		for (Map.Entry<String, String> entry : sourceMap.entrySet()) {
			PickListItems item = new PickListItems();
			item.setDisplayName(entry.getValue());
			item.setKey(entry.getKey());
			item.setId(id++);
			item.setParentKey("");
			pickList.add(item);
		}
		return pickList;
	}

}
