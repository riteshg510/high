package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblColumns;

/**
 * @author Ramanjaneyulu Manam on Oct 22, 2024
 */
@Repository
public interface TblColumnsRepository extends CrudRepository<TblColumns, String> {

	/**
	 * @param tableId
	 * @return
	 */
	List<TblColumns> getColumnsByTableIdOrderByColumnsOrderAsc(String tableId);

}
