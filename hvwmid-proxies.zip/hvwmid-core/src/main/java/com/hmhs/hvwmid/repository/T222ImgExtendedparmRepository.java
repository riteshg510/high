package com.hmhs.hvwmid.repository;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class T222ImgExtendedparmRepository {

    private final DataSource dataSource;

    @Autowired
    public T222ImgExtendedparmRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * Streams EPARM_DATA for a given EPARM_ID and EPARM_KEY from DB2, in
     * ESEQUENCE_NO order,
     * directly to the provided OutputStream. Uses JDBC for safe and
     * memory-efficient streaming.
     *
     * @param eparmId      The EPARM_ID to filter by
     * @param eparmKey     The EPARM_KEY to filter by
     * @param outputStream The output stream to write the data to
     * @throws SQLException If a DB access error occurs
     * @throws IOException  If an I/O error occurs while writing to the stream
     */
    public void streamEparmDataByIdAndKey(String eparmId, String eparmKey, OutputStream outputStream)
            throws SQLException, IOException {
        final String sql = """
                SELECT EPARM_DATA
                FROM T222_IMG_EXTENDEDPARM
                WHERE EPARM_ID = ? AND EPARM_KEY = ?
                ORDER BY ESEQUENCE_NO ASC
                FOR FETCH ONLY WITH UR
                """;

        boolean found = false;
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, eparmId);
            ps.setString(2, eparmKey);
            ps.setFetchSize(50); // Tune for DB2 performance

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String eparmData = rs.getString(1);
                    if (eparmData != null) {
                        outputStream.write(eparmData.getBytes());
                    }
                }
                outputStream.flush();
            }
        }

        if (!found) {
            throw new IllegalStateException(
                    "No EPARM_DATA found for EPARM_ID=" + eparmId + " and EPARM_KEY=" + eparmKey);
        }
    }
}