package com.hmhs.hvwmid.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.hmhs.hvwmid.constants.ImgGlobals2Constants;
import com.hmhs.hvwmid.constants.ImgGlobals2Constants.SearchReqMapping;
import com.hmhs.hvwmid.model.IMISearchData;
import com.hmhs.hvwmid.model.IMISearchRequest;
import com.hmhs.hvwmid.model.IMIUpdateData;
import com.hmhs.hvwmid.model.IMIUpdateRequest;
import com.hmhs.hvwmid.model.IMIUpdateRetrieveRequest;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.ImgGlobals2Utils;
import com.hmhs.hvwmid.utils.RestClientUtil;
import com.hmhs.hvwmid.utils.HVWUtils.DocumentStatusCd;
import com.hmhs.hvwmid.utils.HVWUtils.ProcessFileStatusCd;
import com.hmhs.hvwmid.utils.HVWUtils.TransmitFileStatusCd;

/**
 * Service for IMI update operations. This service handles IMI data retrieval
 * for updates and status code updates.
 * 
 * @author HighView Development Team
 * @since 1.0
 */
@Service
public class IMIUpdateService {

	private static final Logger logger = LogManager.getLogger(IMIUpdateService.class);
	private static final String DEFAULT_HOSTNAME = "HOSTNAME";
	private static final String TRANSMIT_FILE_STATUS_CD = "transmitFileStatusCd";
	private static final String PROCESS_FILE_STATUS_CD = "processFileStatusCd";
	private static final String DOCUMENT_STATUS_CD = "documentStatusCd";
	private static final String CHOICE_LIST = "choiceList";

	private final RestClientUtil restClientUtil;

	private final ObjectMapper mapper = new ObjectMapper();

	public IMIUpdateService(RestClientUtil restClientUtil) {
		this.restClientUtil = restClientUtil;
	}

	@Value("${api.imi.imiRetrieve}")
	private String imiRetrieveBaseURL;

	@Value("${api.imi.imiUpdateRequest}")
	private String imiUpdateBaseURL;

	@Value("${app.environment:default}")
	private String environment;

	/**
	 * This method will check if the user has access to the Update imi group
	 * 
	 * @param session
	 * @param request
	 * @param response
	 */
	public boolean imionLoadUpdate(String authToken) {
		boolean isHavingAccess = false;
		// Check user group access
		List<String> ldapGroups = HVWUtils.getUserGroups(authToken);
		if (ldapGroups != null && !ldapGroups.isEmpty()) {
			if (ldapGroups.contains("IMI-ACTIVITYTRK-UPDATE-INT")) {
				isHavingAccess = true;
			} else {				
				logger.error("User do not have access to the Update IMI groups. Request access to the IMI groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->IMI Groups->IMI-ACTIVITYTRK-UPDATE-INT");
				
			}
		}
		return isHavingAccess;
	}

	/**
	 * Retrieves IMI data for update operations by searching for a specific record
	 * by ID. This method mimics the functionality of the original imiUpdateRetrieve
	 * method.
	 *
	 * @param userId      The user ID for authentication and logging
	 * @param authToken   The JWT authentication token
	 * @param field       The field type to search by (TF, PF, DT)
	 * @param fileIdQuery The ID value to search for
	 * @return IMISearchData containing the search results or error information
	 */
	public IMISearchData imiUpdateRetrieve(String userId, String authToken, String field, String fileIdQuery) {
		logger.debug("Starting IMI update retrieve for user: {} with field: {} and value: {}", userId, field,
				fileIdQuery);

		try {
			// Validate input parameters
			if (field == null || field.trim().isEmpty()) {
				logger.error("Field parameter is required but not provided");
				return createErrorSearchData("Field parameter is required but not provided");
			}

			if (fileIdQuery == null || fileIdQuery.trim().isEmpty()) {
				logger.error("File ID query parameter is required but not provided");
				return createErrorSearchData("File ID query parameter is required but not provided");
			}

			// Create search request
			IMISearchRequest searchRequest = buildUpdateSearchRequest(field, fileIdQuery);

			// Call the IMI retrieve API
			return callIMIRetrieveAPI(searchRequest, authToken);

		} catch (Exception e) {
			logger.error("Error occurred during IMI update retrieve for user {}: {}", userId, e.getMessage(), e);
			return createErrorSearchData("Error occurred during IMI update retrieve: " + e.getMessage());
		}
	}

	/**
	 * Updates IMI status codes for a specific record. This method mimics the
	 * functionality of the original imiUpdate method.
	 *
	 * @param userId    The user ID for authentication and logging
	 * @param authToken The JWT authentication token
	 * @param tableFlag The table flag indicating which table to update
	 * @param id        The ID of the record to update
	 * @param statusCd  The new status code to set
	 * @return IMIUpdateData containing the update response or error information
	 */
	public IMIUpdateData imiUpdate(String userId, String authToken, Map<String, Object> inputRequest) {

		Object tableFlag = inputRequest.get("updateFieldName");
		Object id = inputRequest.get("updateFieldValue");
		String statusCd = "";

		try {
			// Validate input parameters
			if (tableFlag == null || tableFlag.toString().trim().isEmpty()) {
				logger.error("Table flag parameter is required but not provided");
				return createErrorUpdateData("Table flag parameter is required but not provided");
			}

			if (id == null || tableFlag.toString().trim().isEmpty()) {
				logger.error("ID parameter is required but not provided");
				return createErrorUpdateData("ID parameter is required but not provided");
			}

			if ("TF".equals(tableFlag)) {
				statusCd = (String) inputRequest.get(TRANSMIT_FILE_STATUS_CD);
			} else if ("PF".equals(tableFlag)) {
				statusCd = (String) inputRequest.get(PROCESS_FILE_STATUS_CD);
			} else if ("DT".equals(tableFlag)) {
				statusCd = (String) inputRequest.get(DOCUMENT_STATUS_CD);
			}

			if (statusCd == null || statusCd.trim().isEmpty()) {
				logger.error("Status code parameter is required but not provided");
				return createErrorUpdateData("Status code parameter is required but not provided");
			}

			logger.debug("Starting IMI update for user: {} with tableFlag: {}, id: {}, statusCd: {}", userId, tableFlag,
					id, statusCd);

			// Create update request
			IMIUpdateRequest updateRequest = new IMIUpdateRequest(tableFlag.toString(), Long.valueOf(id.toString()),
					statusCd);

			// Call the IMI update API
			IMIUpdateData updateData = callIMIUpdateAPI(updateRequest, authToken);

			if (updateData != null && updateData.getResponseMessage() != null) {
				logger.info("IMI update completed successfully for user: {} with message: {}", userId,
						updateData.getResponseMessage());
			} else {
				logger.warn("IMI update returned error for user: {}", userId);
			}

			return updateData;

		} catch (Exception e) {
			logger.error("Error occurred during IMI update for user {}: {}", userId, e.getMessage(), e);
			return createErrorUpdateData("Error occurred during IMI update: " + e.getMessage());
		}
	}

	/**
	 * Builds an IMI search request for update operations based on field type and
	 * value.
	 *
	 * @param field       The field type (TF, PF, DT)
	 * @param fileIdQuery The ID value to search for
	 * @return IMISearchRequest configured for the specific field type
	 */
	private IMISearchRequest buildUpdateSearchRequest(String field, String fileIdQuery) {
		IMISearchRequest searchRequest = new IMISearchRequest();

		try {
			Long idValue = Long.valueOf(fileIdQuery.trim());

			// Set the appropriate query field based on field type
			if ("TF".equals(field)) {
				searchRequest.setTransmitFileIdQuery(idValue);
			} else if ("PF".equals(field)) {
				searchRequest.setImiFileIdQuery(idValue);
			} else if ("DT".equals(field)) {
				searchRequest.setImiDocumentIdQuery(idValue);
			} else {
				throw new IllegalArgumentException("Invalid field type: " + field);
			}

			// Set all display fields for the corresponding input field to true
			SearchReqMapping[] reqMapping = SearchReqMapping.values();
			for (SearchReqMapping mapping : reqMapping) {
				String alias = mapping.getAlias();
				if (alias != null && alias.equals(field)) {
					String displayField = mapping.getDisplayField();
					ImgGlobals2Utils.setPropertyVals(searchRequest, displayField, "true");
				}
			}

			searchRequest.setSearchById(true);

		} catch (NumberFormatException e) {
			logger.error("Invalid ID format: {}", fileIdQuery);
			throw new IllegalArgumentException("Invalid ID format: " + fileIdQuery);
		}

		return searchRequest;
	}

	/**
	 * Calls the IMI retrieve API with the provided search request.
	 *
	 * @param searchRequest The IMI search request
	 * @param authToken     The authentication token
	 * @return IMISearchData response from the IMI API
	 */
	private IMISearchData callIMIRetrieveAPI(IMISearchRequest searchRequest, String authToken) {
		IMISearchData searchData = null;
		String webservice = imiRetrieveBaseURL.replaceFirst(DEFAULT_HOSTNAME, HVWUtils.getHostname());
		logger.debug("Requesting IMI retrieve webservice: {}", webservice);

		try {
			// Use RestClientUtil for consistent HTTP handling
			ResponseEntity<IMISearchData> response = restClientUtil.postIMIRequest(webservice, authToken, searchRequest,
					IMISearchData.class);

			searchData = response.getBody();
			logger.debug("Request to IMI retrieve webservice successful: {}", webservice);

			// Validate ServiceMessage return code
			if (searchData != null && searchData.getServiceMessage() != null) {
				IMISearchData.ServiceMessage serviceMessage = searchData.getServiceMessage();
				if (serviceMessage.getReturnCode() != null && serviceMessage.getReturnCode() != 0) {
					logger.error("IMI retrieve service returned error code: {} - {}", serviceMessage.getReturnCode(),
							serviceMessage.getReturnCodeDescription());
				}
			}

		} catch (Exception e) {
			logger.error("Exception occurred calling IMI retrieve webservice: {}", webservice, e);

			// Create error response
			searchData = createErrorSearchData(
					"Exception occurred while calling IMI retrieve webservice: " + e.getMessage());
		}

		return searchData;
	}

	/**
	 * Calls the IMI update API with the provided update request.
	 *
	 * @param updateRequest The IMI update request
	 * @param authToken     The authentication token
	 * @return IMIUpdateData response from the IMI API
	 */
	private IMIUpdateData callIMIUpdateAPI(IMIUpdateRequest updateRequest, String authToken) {
		IMIUpdateData updateData = null;
		String webservice = imiUpdateBaseURL.replaceFirst(DEFAULT_HOSTNAME, HVWUtils.getHostname());
		logger.debug("Requesting IMI update webservice: {}", webservice);

		try {
			// Use RestClientUtil for consistent HTTP handling
			ResponseEntity<IMIUpdateData> response = restClientUtil.postIMIRequest(webservice, authToken, updateRequest,
					IMIUpdateData.class);

			updateData = response.getBody();
			logger.debug("Request to IMI update webservice successful: {}", webservice);

		} catch (Exception e) {
			logger.error("Exception occurred calling IMI update webservice: {}", webservice, e);

			// Create error response
			updateData = createErrorUpdateData(
					"Exception occurred while calling IMI update webservice: " + e.getMessage());
		}

		return updateData;
	}

	/**
	 * Creates an error search data response.
	 *
	 * @param errorMessage The error message
	 * @return IMISearchData with error information
	 */
	private IMISearchData createErrorSearchData(String errorMessage) {
		IMISearchData errorData = new IMISearchData();
		IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
		baseMessage.setReturnCode("500");
		baseMessage.setReturnCodeDescription(errorMessage);
		errorData.setBaseMessage(baseMessage);
		errorData.setSearchResultsList(new ArrayList<>());
		return errorData;
	}

	/**
	 * Creates an error update data response.
	 *
	 * @param errorMessage The error message
	 * @return IMIUpdateData with error information
	 */
	private IMIUpdateData createErrorUpdateData(String errorMessage) {
		IMIUpdateData errorData = new IMIUpdateData();
		IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
		baseMessage.setReturnCode("500");
		baseMessage.setReturnCodeDescription(errorMessage);
		errorData.setBaseMessage(baseMessage);
		return errorData;
	}

	public Map<String, Object> convertToTableFormat(List<?> backendResponseList,
			IMIUpdateRetrieveRequest retrieveRequest) throws JsonProcessingException {
		ObjectNode finalResponse = mapper.createObjectNode();

		// --- Definition block ---
		ObjectNode definition = mapper.createObjectNode();
		definition.put("allowMultipleSort", false);
		definition.put("allowResizeColumns", false);

		// pagination
		ObjectNode pagination = mapper.createObjectNode();
		pagination.put("pageSize", 20);
		pagination.put("pageNumber", 0);
		definition.set("pagination", pagination);

		Set<String> activeKeys = buildActiveKeysFromRetrieveRequest(retrieveRequest);


		definition.set("columns", generateColumns(activeKeys, retrieveRequest));
		finalResponse.set("definition", definition);

		finalResponse.set("data", constructData(activeKeys, backendResponseList, retrieveRequest));

		return mapper.convertValue(finalResponse, new TypeReference<Map<String, Object>>() {
		});
	}
	
	/**
	 * Builds activeKeys from the retrieveRequest field type instead of from search results
	 * This ensures consistent column display even when search results have null values
	 * 
	 * @param retrieveRequest The IMIUpdateRetrieveRequest containing field type information
	 * @return Set of active field names that should be displayed
	 */
	private Set<String> buildActiveKeysFromRetrieveRequest(IMIUpdateRetrieveRequest retrieveRequest) {
		Set<String> activeKeys = new LinkedHashSet<>();
		
		// Always include naicCode and transmitTimeStamp as they are core fields
		activeKeys.add("naicCode");
		activeKeys.add("transmitTimestamp");
		
		// Get the field type from retrieveRequest
		String fieldType = retrieveRequest.getField();
		if (fieldType == null || fieldType.trim().isEmpty()) {
			return activeKeys;
		}
		
		// Use SearchReqMapping to get fields based on field type (TF, PF, DT)
		SearchReqMapping[] reqMapping = SearchReqMapping.values();
		for (SearchReqMapping mapping : reqMapping) {
			String alias = mapping.getAlias();
			String outputField = mapping.getOutputField();
			
			// Add fields that match the field type
			if (alias != null && alias.equals(fieldType)) {
				activeKeys.add(outputField);
			}
		}
		
		return activeKeys;
	}

	public ArrayNode generateColumns(Set<String> activeKeys, IMIUpdateRetrieveRequest retrieveRequest) {
		// Columns
		ArrayNode columns = mapper.createArrayNode();

		// Static "Actions" column
		ObjectNode actionColumn = mapper.createObjectNode();
		actionColumn.put("id", "action");
		actionColumn.put("type", "actions");
		actionColumn.put("name", "Actions");
		columns.add(actionColumn);

		for (String fieldName : activeKeys) {
			ObjectNode col = mapper.createObjectNode();
			if (fieldName != null && fieldName.contains("time")) {
				col.put("type", "datetime");
				col.put("dateFormat", "yyyy-MM-DD HH:mm:ss.SSSSSS");
			} else {
				col.put("type", "string");
			}

			col.put("url", "");
			col.put("sortable", true);
			if ("naicCode".equalsIgnoreCase(fieldName))
				col.put("name", "NAIC");
			else if ("transmitTimeStamp".equalsIgnoreCase(fieldName))
				col.put("name", "Transmit Timestamp");
			else
				col.put("name", ImgGlobals2Constants.getHeaderByFieldName(fieldName));
			col.put("filterable", true);
			col.put("id", fieldName);

			if ("TF".equals(retrieveRequest.getField()) && TRANSMIT_FILE_STATUS_CD.equalsIgnoreCase(fieldName)) {
				col.set(CHOICE_LIST,
						mapper.convertValue(convertEnumToChoiceList(TransmitFileStatusCd.class), JsonNode.class));
			} else if ("PF".equals(retrieveRequest.getField()) && PROCESS_FILE_STATUS_CD.equalsIgnoreCase(fieldName)) {
				col.set(CHOICE_LIST,
						mapper.convertValue(convertEnumToChoiceList(ProcessFileStatusCd.class), JsonNode.class));
			} else if ("DT".equals(retrieveRequest.getField()) && DOCUMENT_STATUS_CD.equalsIgnoreCase(fieldName)) {
				col.set(CHOICE_LIST,
						mapper.convertValue(convertEnumToChoiceList(DocumentStatusCd.class), JsonNode.class));
			} else {
				col.put("readonly", true);
			}

			columns.add(col);
		}

		return columns;
	}

	public ArrayNode constructData(Set<String> activeKeys, List<?> backendResponseList,
			IMIUpdateRetrieveRequest retrieveRequest) {
		// --- Data block ---
		ArrayNode data = mapper.createArrayNode();

		for (Object pojo : backendResponseList) {
			Map<String, Object> rowMap = mapper.convertValue(pojo, new TypeReference<Map<String, Object>>() {
			});

			ObjectNode rowNode = mapper.createObjectNode();
			for (String key : activeKeys) {
				Object tempValue = rowMap.get(key);
				rowNode.put("updateFieldName", retrieveRequest.getField());
				rowNode.put("updateFieldValue", retrieveRequest.getFieldQuery());
				if (tempValue != null && "TF".equals(retrieveRequest.getField())
						&& TRANSMIT_FILE_STATUS_CD.equalsIgnoreCase(key)) {
					tempValue = HVWUtils.convertTransmitFileStatusCd(tempValue.toString());
				} else if (tempValue != null && "PF".equals(retrieveRequest.getField())
						&& PROCESS_FILE_STATUS_CD.equalsIgnoreCase(key)) {
					tempValue = HVWUtils.convertProcessFileStatusCd(tempValue.toString());
				} else if (tempValue != null && "DT".equals(retrieveRequest.getField())
						&& DOCUMENT_STATUS_CD.equalsIgnoreCase(key)) {
					tempValue = HVWUtils.convertDocumentStatusCd(tempValue.toString());
				}

				rowNode.set(key, mapper.valueToTree(tempValue));
			}

			ArrayNode rowActions = mapper.createArrayNode();
			ObjectNode rowAction = mapper.createObjectNode();
			rowAction.put("action", "dynamicAction");
			rowAction.put("actionIcon", "");
			rowAction.put("label", "Update");
			rowAction.put("apiUrl", "imi/imi-updateRequest");
			rowAction.put("actionType", "edit");
			rowActions.add(rowAction);
			rowNode.set("action", rowActions);
			data.add(rowNode);
		}

		return data;
	}

	/**
	 * Converts an enum to a choice list format. Each enum value becomes a choice
	 * item with displayName, id, key, and parentKey.
	 *
	 * @param enumClass The enum class to convert
	 * @param <T>       The enum type
	 * @return List of choice items in the specified format
	 */
	public static <T extends Enum<T>> List<PickListItems> convertEnumToChoiceList(Class<T> enumClass) {

		List<PickListItems> choiceList = new ArrayList<>();

		T[] enumConstants = enumClass.getEnumConstants();
		for (int i = 0; i < enumConstants.length; i++) {
			T enumValue = enumConstants[i];
			PickListItems choiceItem = new PickListItems();

			// Set the key as the enum name
			choiceItem.setKey(enumValue.name());

			// Set the display name as "Key - Description" format
			// If the enum has a description method, use it; otherwise use the name
			String displayName = HVWUtils.getDescription(enumClass, enumValue.name());
			choiceItem.setDisplayName(displayName);

			// Set the ID as the ordinal (position in enum)
			choiceItem.setId((long) i);

			// Set parent key as empty string (can be customized if needed)
			choiceItem.setParentKey("");

			choiceList.add(choiceItem);
		}

		return choiceList;
	}

}
