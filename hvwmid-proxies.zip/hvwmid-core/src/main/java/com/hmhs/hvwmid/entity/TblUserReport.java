package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "T222_HVW_USER_REPORTS")
public class TblUserReport {
 
	@Id
	@Column(length = 64, columnDefinition = "CHAR(64)")
	private String userReportId;
	private String reportId;
	private String userId;

	public String getUserReportId() {
		return userReportId.trim();
	}

	public void setUserReportId(String userReportId) {
		this.userReportId = userReportId.trim();
	}

	// Getters and Setters
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportName) {
		this.reportId = reportName;
	}
}
