package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface T117ImgCoverDeptRepository extends JpaRepository<T117ImgCoverDept, Integer> {

    @Query("SELECT COALESCE(MAX(d.deptId), 0) FROM T117ImgCoverDept d WHERE d.deptId <> 9999")
    int findMaxDeptIdExcluding9999();

    @Query("select distinct(d.maintGroup) from T117ImgCoverDept d")
    List<String> findDistinctMaintGroups();

}
