package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class IMIUISearchRequest {
	
	@JsonProperty("naiccode")
	private String naicCode;
	
	@JsonProperty("begindate")
    private String begindate;
	
	@JsonProperty("starttimehour")
    private String startTimeHour;
	
	@JsonProperty("starttimemin")
    private String startTimeMin;
	
	@JsonProperty("enddate")
    private String enddate;
	
	@JsonProperty("endtimehour")
    private String endTimeHour;
	
	@JsonProperty("endtimemin")
    private String endTimeMin;
	
	@JsonProperty("submittop")
    private String submitTop;
	
	@JsonProperty("allfieldsselunseltop")
    private boolean allFieldsSelUnSelTop;
	
	@JsonProperty("transmitfileidquery")
    private String transmitFileIdQuery;
	
	@JsonProperty("transmitfileidSearchOperator")
    private String transmitFileIdSearchOperator;
	
	@JsonProperty("transmitfileidDisplay")
    private boolean transmitFileIdDisplay;
	
	@JsonProperty("transmitfilenamequery")
    private String transmitFileNameQuery;
	
	@JsonProperty("transmitfilenameSearchOperator")
    private String transmitFileNameSearchOperator;
	
	@JsonProperty("transmitfilenameDisplay")
    private boolean transmitFileNameDisplay;
	
	@JsonProperty("transmitfilestatuscdquery")
    private String transmitFileStatusCdQuery;
	
	@JsonProperty("transmitfilestatuscdSearchOperator")
    private String transmitFileStatusCdSearchOperator;
	
	@JsonProperty("transmitfilestatuscdDisplay")
    private boolean transmitFileStatusCdDisplay;
	
	@JsonProperty("imifileidquery")
    private String imiFileIdQuery;
	
	@JsonProperty("imifileidSearchOperator")
    private String imiFileIdSearchOperator;
	
	@JsonProperty("imifileidDisplay")
    private boolean imiFileIdDisplay;
	
	@JsonProperty("planfileidquery")
    private String planFileIdQuery;
	
	@JsonProperty("planfileidSearchOperator")
    private String planFileIdSearchOperator;
	
	@JsonProperty("planfileidDisplay")
    private boolean planFileIdDisplay;
	
	@JsonProperty("processfilenamequery")
    private String processFileNameQuery;
	
	@JsonProperty("processfilenameSearchOperator")
    private String processFileNameSearchOperator;
	
	@JsonProperty("processfilenameDisplay")
    private boolean processFileNameDisplay;
	
	@JsonProperty("processfilestatuscdquery")
    private String processFileStatusCdQuery;
	
	@JsonProperty("processfilestatuscdSearchOperator")
    private String processFileStatusCdSearchOperator;
	
	@JsonProperty("processfilestatuscdDisplay")
    private boolean processFileStatusCdDisplay;
	
	@JsonProperty("imidocumentidquery")
    private String imiDocumentIdQuery;
	
	@JsonProperty("imidocumentidSearchOperator")
    private String imiDocumentIdSearchOperator;
	
	@JsonProperty("imidocumentidDisplay")
    private boolean imiDocumentIdDisplay;
	
	@JsonProperty("plandcnquery")
    private String planDCNQuery;
	
	@JsonProperty("plandcnSearchOperator")
    private String planDCNSearchOperator;
	
	@JsonProperty("plandcnDisplay")
    private boolean planDCNDisplay;
	
	@JsonProperty("dpkquery")
    private String dpkQuery;
	
	@JsonProperty("dpkSearchOperator")
    private String dpkSearchOperator;
	
	@JsonProperty("dpkDisplay")
    private boolean dpkDisplay;
	
	@JsonProperty("initialprocessdcnquery")
    private String initialProcessDCNQuery;
	
	@JsonProperty("initialprocessdcnSearchOperator")
    private String initialProcessDCNSearchOperator;
	
	@JsonProperty("initialprocessdcnDisplay")
    private boolean initialProcessDCNDisplay;
	
	@JsonProperty("finalprocessdcnquery")
    private String finalProcessDCNQuery;
	
	@JsonProperty("finalprocessdcnSearchOperator")
    private String finalProcessDCNSearchOperator;
	
	@JsonProperty("finalprocessdcnDisplay")
    private boolean finalProcessDCNDisplay;
	
	@JsonProperty("documentstatuscdquery")
    private String documentStatusCdQuery;
	
	@JsonProperty("documentstatuscdSearchOperator")
    private String documentStatusCdSearchOperator;
	
	@JsonProperty("documentstatuscdDisplay")
    private boolean documentStatusCdDisplay;
	
	@JsonProperty("applidcdquery")
    private String applIdCdQuery;
	
	@JsonProperty("applidcdSearchOperator")
    private String applIdCdSearchOperator;
	
	@JsonProperty("applidcdDisplay")
    private boolean applIdCdDisplay;
	
	@JsonProperty("captureitemidquery")
    private String captureItemIdQuery;
	
	@JsonProperty("captureitemidSearchOperator")
    private String captureItemIdSearchOperator;
	
	@JsonProperty("captureitemidDisplay")
    private boolean captureItemIdDisplay;
	
	@JsonProperty("allfieldsselunselbottom")
    private boolean allFieldsSelUnSelBottom;
	
	@JsonProperty("processfilereasoncdquery")
    private String processFileReasonCdQuery;
	
	@JsonProperty("processfilereasonSearchOperator")
    private String processFileReasonSearchOperator;
	
	@JsonProperty("timeackquery")
    private String timeAckQuery;
		
	@JsonProperty("documentreasonSearchOperator")
    private String documentReasonSearchOperator;	
	
	// Legacy fields for backward compatibility
	@JsonProperty("memberid")
    private String memberId;
	
	@JsonProperty("memberidDisplay")
    private boolean memberIdDisplay;
	
	@JsonProperty("memberidSearchOperator")
    private String memberIdSearchOperator;
	
	@JsonProperty("memberidtype")
    private String memberIdType;
	
	@JsonProperty("memberidtypeDisplay")
    private boolean memberIdTypeDisplay;
	
	@JsonProperty("memberidtypeSearchOperator")
    private String memberIdTypeSearchOperator;
	
	@JsonProperty("documenttype")
    private String documentType;
	
	@JsonProperty("documenttypeDisplay")
    private boolean documentTypeDisplay;
	
	@JsonProperty("documenttypeSearchOperator")
    private String documentTypeSearchOperator;
	
	@JsonProperty("documentid")
    private String documentId;
	
	@JsonProperty("documentidDisplay")
    private boolean documentIdDisplay;
	
	@JsonProperty("documentidSearchOperator")
    private String documentIdSearchOperator;
	
	@JsonProperty("processfilereasoncddesc")
    private String processFileReasonCdDesc;
	
	@JsonProperty("processfilereasoncdDisplay")
    private boolean processFileReasonCdDisplay;
	
	@JsonProperty("processfilereasoncdSearchOperator")
    private String processFileReasonCdSearchOperator;
	
	@JsonProperty("timeack")
    private String timeAck;
	
	@JsonProperty("timeackDisplay")
    private boolean timeAckDisplay;
	
	@JsonProperty("timeackSearchOperator")
    private String timeAckSearchOperator;
	
	@JsonProperty("timeUpdateQuery")
	private String timeUpdateQuery;
	
	@JsonProperty("timeUpdateSearchOperator")
	private String timeUpdateSearchOperator;
	
	@JsonProperty("timeUpdateDisplay")
	private boolean timeUpdateDisplay;
	
	@JsonProperty("documentReasonCdQuery")
	private String documentReasonCdQuery;
	
	@JsonProperty("documentReasonCdSearchOperator")
	private String documentReasonCdSearchOperator;
	
	@JsonProperty("documentReasonCdDisplay")
	private boolean documentReasonCdDisplay;
	
	
    // Getters and Setters

    public String getTimeUpdateSearchOperator() {
		return timeUpdateSearchOperator;
	}

	public void setTimeUpdateSearchOperator(String timeUpdateSearchOperator) {
		this.timeUpdateSearchOperator = timeUpdateSearchOperator;
	}

	public boolean isTimeUpdateDisplay() {
		return timeUpdateDisplay;
	}

	public void setTimeUpdateDisplay(boolean timeUpdateDisplay) {
		this.timeUpdateDisplay = timeUpdateDisplay;
	}

	public String getDocumentReasonCdSearchOperator() {
		return documentReasonCdSearchOperator;
	}

	public void setDocumentReasonCdSearchOperator(String documentReasonCdSearchOperator) {
		this.documentReasonCdSearchOperator = documentReasonCdSearchOperator;
	}

	public boolean isDocumentReasonCdDisplay() {
		return documentReasonCdDisplay;
	}

	public void setDocumentReasonCdDisplay(boolean documentReasonCdDisplay) {
		this.documentReasonCdDisplay = documentReasonCdDisplay;
	}

	public String getTimeAck() {
		return timeAck;
	}

	public void setTimeAck(String timeAck) {
		this.timeAck = timeAck;
	}

	public boolean isTimeAckDisplay() {
		return timeAckDisplay;
	}

	public void setTimeAckDisplay(boolean timeAckDisplay) {
		this.timeAckDisplay = timeAckDisplay;
	}

	public String getTimeAckSearchOperator() {
		return timeAckSearchOperator;
	}

	public void setTimeAckSearchOperator(String timeAckSearchOperator) {
		this.timeAckSearchOperator = timeAckSearchOperator;
	}

	public String getProcessFileReasonCdDesc() {
		return processFileReasonCdDesc;
	}

	public void setProcessFileReasonCdDesc(String processFileReasonCdDesc) {
		this.processFileReasonCdDesc = processFileReasonCdDesc;
	}

	public boolean isProcessFileReasonCdDisplay() {
		return processFileReasonCdDisplay;
	}

	public void setProcessFileReasonCdDisplay(boolean processFileReasonCdDisplay) {
		this.processFileReasonCdDisplay = processFileReasonCdDisplay;
	}

	public String getProcessFileReasonCdSearchOperator() {
		return processFileReasonCdSearchOperator;
	}

	public void setProcessFileReasonCdSearchOperator(String processFileReasonCdSearchOperator) {
		this.processFileReasonCdSearchOperator = processFileReasonCdSearchOperator;
	}

	public String getNaicCode() {
        return naicCode;
    }

    public void setNaicCode(String naicCode) {
        this.naicCode = naicCode;
    }

    public String getBegindate() {
        return begindate;
    }

    public void setBegindate(String begindate) {
        this.begindate = begindate;
    }

    public String getStartTimeHour() {
        return startTimeHour;
    }

    public void setStartTimeHour(String startTimeHour) {
        this.startTimeHour = startTimeHour;
    }

    public String getStartTimeMin() {
        return startTimeMin;
    }

    public void setStartTimeMin(String startTimeMin) {
        this.startTimeMin = startTimeMin;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getEndTimeHour() {
        return endTimeHour;
    }

    public void setEndTimeHour(String endTimeHour) {
        this.endTimeHour = endTimeHour;
    }

    public String getEndTimeMin() {
        return endTimeMin;
    }

    public void setEndTimeMin(String endTimeMin) {
        this.endTimeMin = endTimeMin;
    }

    public String getSubmitTop() {
        return submitTop;
    }

    public void setSubmitTop(String submitTop) {
        this.submitTop = submitTop;
    }

    public boolean isAllFieldsSelUnSelTop() {
        return allFieldsSelUnSelTop;
    }

    public void setAllFieldsSelUnSelTop(boolean allFieldsSelUnSelTop) {
        this.allFieldsSelUnSelTop = allFieldsSelUnSelTop;
    }

   

	public String getTransmitFileIdQuery() {
		return transmitFileIdQuery;
	}

	public void setTransmitFileIdQuery(String transmitFileIdQuery) {
		this.transmitFileIdQuery = transmitFileIdQuery;
	}

	public String getTransmitFileIdSearchOperator() {
		return transmitFileIdSearchOperator;
	}

	public void setTransmitFileIdSearchOperator(String transmitFileIdSearchOperator) {
		this.transmitFileIdSearchOperator = transmitFileIdSearchOperator;
	}

	public boolean isTransmitFileIdDisplay() {
		return transmitFileIdDisplay;
	}

	public void setTransmitFileIdDisplay(boolean transmitFileIdDisplay) {
		this.transmitFileIdDisplay = transmitFileIdDisplay;
	}

	public String getTransmitFileNameQuery() {
        return transmitFileNameQuery;
    }

    public void setTransmitFileNameQuery(String transmitFileNameQuery) {
        this.transmitFileNameQuery = transmitFileNameQuery;
    }

    public String getTransmitFileNameSearchOperator() {
        return transmitFileNameSearchOperator;
    }

    public void setTransmitFileNameSearchOperator(String transmitFileNameSearchOperator) {
        this.transmitFileNameSearchOperator = transmitFileNameSearchOperator;
    }

    public boolean isTransmitFileNameDisplay() {
        return transmitFileNameDisplay;
    }

    public void setTransmitFileNameDisplay(boolean transmitFileNameDisplay) {
        this.transmitFileNameDisplay = transmitFileNameDisplay;
    }

    public String getTransmitFileStatusCdQuery() {
        return transmitFileStatusCdQuery;
    }

    public void setTransmitFileStatusCdQuery(String transmitFileStatusCdQuery) {
        this.transmitFileStatusCdQuery = transmitFileStatusCdQuery;
    }

    public String getTransmitFileStatusCdSearchOperator() {
        return transmitFileStatusCdSearchOperator;
    }

    public void setTransmitFileStatusCdSearchOperator(String transmitFileStatusCdSearchOperator) {
        this.transmitFileStatusCdSearchOperator = transmitFileStatusCdSearchOperator;
    }

    public boolean isTransmitFileStatusCdDisplay() {
        return transmitFileStatusCdDisplay;
    }

    public void setTransmitFileStatusCdDisplay(boolean transmitFileStatusCdDisplay) {
        this.transmitFileStatusCdDisplay = transmitFileStatusCdDisplay;
    }

    public String getImiFileIdQuery() {
        return imiFileIdQuery;
    }

    public void setImiFileIdQuery(String imiFileIdQuery) {
        this.imiFileIdQuery = imiFileIdQuery;
    }

    public String getImiFileIdSearchOperator() {
        return imiFileIdSearchOperator;
    }

    public void setImiFileIdSearchOperator(String imiFileIdSearchOperator) {
        this.imiFileIdSearchOperator = imiFileIdSearchOperator;
    }

    public boolean isImiFileIdDisplay() {
        return imiFileIdDisplay;
    }

    public void setImiFileIdDisplay(boolean imiFileIdDisplay) {
        this.imiFileIdDisplay = imiFileIdDisplay;
    }

    public String getPlanFileIdQuery() {
        return planFileIdQuery;
    }

    public void setPlanFileIdQuery(String planFileIdQuery) {
        this.planFileIdQuery = planFileIdQuery;
    }

    public String getPlanFileIdSearchOperator() {
        return planFileIdSearchOperator;
    }

    public void setPlanFileIdSearchOperator(String planFileIdSearchOperator) {
        this.planFileIdSearchOperator = planFileIdSearchOperator;
    }

    public boolean isPlanFileIdDisplay() {
        return planFileIdDisplay;
    }

    public void setPlanFileIdDisplay(boolean planFileIdDisplay) {
        this.planFileIdDisplay = planFileIdDisplay;
    }

    public String getProcessFileNameQuery() {
        return processFileNameQuery;
    }

    public void setProcessFileNameQuery(String processFileNameQuery) {
        this.processFileNameQuery = processFileNameQuery;
    }

    public String getProcessFileNameSearchOperator() {
        return processFileNameSearchOperator;
    }

    public void setProcessFileNameSearchOperator(String processFileNameSearchOperator) {
        this.processFileNameSearchOperator = processFileNameSearchOperator;
    }

    public boolean isProcessFileNameDisplay() {
        return processFileNameDisplay;
    }

    public void setProcessFileNameDisplay(boolean processFileNameDisplay) {
        this.processFileNameDisplay = processFileNameDisplay;
    }

    public String getProcessFileStatusCdQuery() {
        return processFileStatusCdQuery;
    }

    public void setProcessFileStatusCdQuery(String processFileStatusCdQuery) {
        this.processFileStatusCdQuery = processFileStatusCdQuery;
    }

    public String getProcessFileStatusCdSearchOperator() {
        return processFileStatusCdSearchOperator;
    }

    public void setProcessFileStatusCdSearchOperator(String processFileStatusCdSearchOperator) {
        this.processFileStatusCdSearchOperator = processFileStatusCdSearchOperator;
    }

    public boolean isProcessFileStatusCdDisplay() {
        return processFileStatusCdDisplay;
    }

    public void setProcessFileStatusCdDisplay(boolean processFileStatusCdDisplay) {
        this.processFileStatusCdDisplay = processFileStatusCdDisplay;
    }

    public String getImiDocumentIdQuery() {
        return imiDocumentIdQuery;
    }

    public void setImiDocumentIdQuery(String imiDocumentIdQuery) {
        this.imiDocumentIdQuery = imiDocumentIdQuery;
    }

    public String getImiDocumentIdSearchOperator() {
        return imiDocumentIdSearchOperator;
    }

    public void setImiDocumentIdSearchOperator(String imiDocumentIdSearchOperator) {
        this.imiDocumentIdSearchOperator = imiDocumentIdSearchOperator;
    }

    public boolean isImiDocumentIdDisplay() {
        return imiDocumentIdDisplay;
    }

    public void setImiDocumentIdDisplay(boolean imiDocumentIdDisplay) {
        this.imiDocumentIdDisplay = imiDocumentIdDisplay;
    }

    public String getPlanDCNQuery() {
        return planDCNQuery;
    }

    public void setPlanDCNQuery(String planDCNQuery) {
        this.planDCNQuery = planDCNQuery;
    }

    public String getPlanDCNSearchOperator() {
        return planDCNSearchOperator;
    }

    public void setPlanDCNSearchOperator(String planDCNSearchOperator) {
        this.planDCNSearchOperator = planDCNSearchOperator;
    }

    public boolean isPlanDCNDisplay() {
        return planDCNDisplay;
    }

    public void setPlanDCNDisplay(boolean planDCNDisplay) {
        this.planDCNDisplay = planDCNDisplay;
    }

    public String getDpkQuery() {
        return dpkQuery;
    }

    public void setDpkQuery(String dpkQuery) {
        this.dpkQuery = dpkQuery;
    }

    public String getDpkSearchOperator() {
        return dpkSearchOperator;
    }

    public void setDpkSearchOperator(String dpkSearchOperator) {
        this.dpkSearchOperator = dpkSearchOperator;
    }

    public boolean isDpkDisplay() {
        return dpkDisplay;
    }

    public void setDpkDisplay(boolean dpkDisplay) {
        this.dpkDisplay = dpkDisplay;
    }

    public String getInitialProcessDCNQuery() {
        return initialProcessDCNQuery;
    }

    public void setInitialProcessDCNQuery(String initialProcessDCNQuery) {
        this.initialProcessDCNQuery = initialProcessDCNQuery;
    }

    public String getInitialProcessDCNSearchOperator() {
        return initialProcessDCNSearchOperator;
    }

    public void setInitialProcessDCNSearchOperator(String initialProcessDCNSearchOperator) {
        this.initialProcessDCNSearchOperator = initialProcessDCNSearchOperator;
    }

    public boolean isInitialProcessDCNDisplay() {
        return initialProcessDCNDisplay;
    }

    public void setInitialProcessDCNDisplay(boolean initialProcessDCNDisplay) {
        this.initialProcessDCNDisplay = initialProcessDCNDisplay;
    }

    public String getFinalProcessDCNQuery() {
        return finalProcessDCNQuery;
    }

    public void setFinalProcessDCNQuery(String finalProcessDCNQuery) {
        this.finalProcessDCNQuery = finalProcessDCNQuery;
    }

    public String getFinalProcessDCNSearchOperator() {
        return finalProcessDCNSearchOperator;
    }

    public void setFinalProcessDCNSearchOperator(String finalProcessDCNSearchOperator) {
        this.finalProcessDCNSearchOperator = finalProcessDCNSearchOperator;
    }

    public boolean isFinalProcessDCNDisplay() {
        return finalProcessDCNDisplay;
    }

    public void setFinalProcessDCNDisplay(boolean finalProcessDCNDisplay) {
        this.finalProcessDCNDisplay = finalProcessDCNDisplay;
    }

    public String getDocumentStatusCdQuery() {
        return documentStatusCdQuery;
    }

    public void setDocumentStatusCdQuery(String documentStatusCdQuery) {
        this.documentStatusCdQuery = documentStatusCdQuery;
    }

    public String getDocumentStatusCdSearchOperator() {
        return documentStatusCdSearchOperator;
    }

    public void setDocumentStatusCdSearchOperator(String documentStatusCdSearchOperator) {
        this.documentStatusCdSearchOperator = documentStatusCdSearchOperator;
    }

    public boolean isDocumentStatusCdDisplay() {
        return documentStatusCdDisplay;
    }

    public void setDocumentStatusCdDisplay(boolean documentStatusCdDisplay) {
        this.documentStatusCdDisplay = documentStatusCdDisplay;
    }

    public String getApplIdCdQuery() {
        return applIdCdQuery;
    }

    public void setApplIdCdQuery(String applIdCdQuery) {
        this.applIdCdQuery = applIdCdQuery;
    }

    public String getApplIdCdSearchOperator() {
        return applIdCdSearchOperator;
    }

    public void setApplIdCdSearchOperator(String applIdCdSearchOperator) {
        this.applIdCdSearchOperator = applIdCdSearchOperator;
    }

    public boolean isApplIdCdDisplay() {
        return applIdCdDisplay;
    }

    public void setApplIdCdDisplay(boolean applIdCdDisplay) {
        this.applIdCdDisplay = applIdCdDisplay;
    }

    public String getCaptureItemIdQuery() {
        return captureItemIdQuery;
    }

    public void setCaptureItemIdQuery(String captureItemIdQuery) {
        this.captureItemIdQuery = captureItemIdQuery;
    }

    public String getCaptureItemIdSearchOperator() {
        return captureItemIdSearchOperator;
    }

    public void setCaptureItemIdSearchOperator(String captureItemIdSearchOperator) {
        this.captureItemIdSearchOperator = captureItemIdSearchOperator;
    }

    public boolean isCaptureItemIdDisplay() {
        return captureItemIdDisplay;
    }

    public void setCaptureItemIdDisplay(boolean captureItemIdDisplay) {
        this.captureItemIdDisplay = captureItemIdDisplay;
    }

    public boolean isAllFieldsSelUnSelBottom() {
        return allFieldsSelUnSelBottom;
    }

    public void setAllFieldsSelUnSelBottom(boolean allFieldsSelUnSelBottom) {
        this.allFieldsSelUnSelBottom = allFieldsSelUnSelBottom;
    }

    public String getProcessFileReasonCdQuery() {
        return processFileReasonCdQuery;
    }

    public void setProcessFileReasonCdQuery(String processFileReasonCdQuery) {
        this.processFileReasonCdQuery = processFileReasonCdQuery;
    }

    public String getProcessFileReasonSearchOperator() {
        return processFileReasonSearchOperator;
    }

    public void setProcessFileReasonSearchOperator(String processFileReasonSearchOperator) {
        this.processFileReasonSearchOperator = processFileReasonSearchOperator;
    }

    public String getTimeAckQuery() {
        return timeAckQuery;
    }

    public void setTimeAckQuery(String timeAckQuery) {
        this.timeAckQuery = timeAckQuery;
    }

    public String getDocumentReasonCdQuery() {
        return documentReasonCdQuery;
    }

    public void setDocumentReasonCdQuery(String documentReasonCdQuery) {
        this.documentReasonCdQuery = documentReasonCdQuery;
    }

    public String getDocumentReasonSearchOperator() {
        return documentReasonSearchOperator;
    }

    public void setDocumentReasonSearchOperator(String documentReasonSearchOperator) {
        this.documentReasonSearchOperator = documentReasonSearchOperator;
    }

    public String getTimeUpdateQuery() {
        return timeUpdateQuery;
    }

    public void setTimeUpdateQuery(String timeUpdateQuery) {
        this.timeUpdateQuery = timeUpdateQuery;
    }

    // Legacy field getters and setters
    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public boolean isMemberIdDisplay() {
        return memberIdDisplay;
    }

    public void setMemberIdDisplay(boolean memberIdDisplay) {
        this.memberIdDisplay = memberIdDisplay;
    }

    public String getMemberIdSearchOperator() {
        return memberIdSearchOperator;
    }

    public void setMemberIdSearchOperator(String memberIdSearchOperator) {
        this.memberIdSearchOperator = memberIdSearchOperator;
    }

    public String getMemberIdType() {
        return memberIdType;
    }

    public void setMemberIdType(String memberIdType) {
        this.memberIdType = memberIdType;
    }

    public boolean isMemberIdTypeDisplay() {
        return memberIdTypeDisplay;
    }

    public void setMemberIdTypeDisplay(boolean memberIdTypeDisplay) {
        this.memberIdTypeDisplay = memberIdTypeDisplay;
    }

    public String getMemberIdTypeSearchOperator() {
        return memberIdTypeSearchOperator;
    }

    public void setMemberIdTypeSearchOperator(String memberIdTypeSearchOperator) {
        this.memberIdTypeSearchOperator = memberIdTypeSearchOperator;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public boolean isDocumentTypeDisplay() {
        return documentTypeDisplay;
    }

    public void setDocumentTypeDisplay(boolean documentTypeDisplay) {
        this.documentTypeDisplay = documentTypeDisplay;
    }

    public String getDocumentTypeSearchOperator() {
        return documentTypeSearchOperator;
    }

    public void setDocumentTypeSearchOperator(String documentTypeSearchOperator) {
        this.documentTypeSearchOperator = documentTypeSearchOperator;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public boolean isDocumentIdDisplay() {
        return documentIdDisplay;
    }

    public void setDocumentIdDisplay(boolean documentIdDisplay) {
        this.documentIdDisplay = documentIdDisplay;
    }

    public String getDocumentIdSearchOperator() {
        return documentIdSearchOperator;
    }

    public void setDocumentIdSearchOperator(String documentIdSearchOperator) {
        this.documentIdSearchOperator = documentIdSearchOperator;
    }
}
