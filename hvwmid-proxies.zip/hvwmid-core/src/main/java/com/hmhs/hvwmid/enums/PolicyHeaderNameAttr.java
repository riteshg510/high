package com.hmhs.hvwmid.enums;

public enum PolicyHeaderNameAttr {
    POLICY_CODE("Policy Code", "policyCode", false, 0),
    POLICY_ID("Policy Id", "policyId", true, 30),
    POLICY_DESC("Policy Description", "policyDescription", true, 250),
    POLICY_ID_TYPE("Policy Id Type", "policyIdType", true, 5),
    BPD_ID("BPD Id", "bpdId", true, 0),
    POLICY_DAYS("Policy Days", "policyDays", true, 9),
    POLICY_EDIT_FLAG("Policy Edit Flag", "policyEditFlag", true, 1),
    POLICY_EDIT_PGM_NAME("Policy Edit Program Name", "policyEditPgmName", false, 8),
    POLICY_BASE_DATE("Policy Base Date", "policyBaseDate", false, 10),
    HOLDS("Holds", "holds", false, 0),
    MODUSER("Modified User", "modUser", false, 0),
    MODTIMESTAMP("Modified Timestamp", "modDate", false, 0);

    private final String headerName;
    private final String beanAttribute;
    private final boolean mandatory;
    private final int fieldSize;

    PolicyHeaderNameAttr(String headerName, String beanAttribute, boolean mandatory, int fieldSize) {
        this.headerName = headerName;
        this.beanAttribute = beanAttribute;
        this.mandatory = mandatory;
        this.fieldSize = fieldSize;
    }

    public String getHeaderName() { return headerName; }
    public String getBeanAttribute() { return beanAttribute; }
    public boolean isMandatory() { return mandatory; }
    public int getFieldSize() { return fieldSize; }
}

