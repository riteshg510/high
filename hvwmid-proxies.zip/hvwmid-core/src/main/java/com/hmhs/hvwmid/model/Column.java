package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Column {

	private String layoutType = "column";
	private List<BaseLayout> children;

	public List<BaseLayout> getChildren() {
		return children;
	}

	public void setChildren(List<BaseLayout> children) {
		this.children = children;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}
}
