package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetId;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetOverrideId;
import com.hmhs.hvwmid.model.*;

import java.util.List;

public interface CoversheetService {

    List<CoverSheetDTO> getAllCoverSheets(boolean activeOnly);

    CoverSheetDTO saveCoverSheet(CoverSheetDTO dto);

    CoverSheetDTO updateCoverSheet(CoverSheetDTO dto);

    void deleteCoverSheet(T117ImgCoverSheetId id);

    CoversheetFileResult getCoverSheet(int applicationId, int sequence, String applicationName, boolean b);



    List<CoverSheetOverrideDTO> getAllOverrides();

    CoverSheetOverrideDTO updateOverride(CoverSheetOverrideDTO dto);

    void deleteOverride(T117ImgCoverSheetOverrideId id);




    List<CoverSheetDepartmentDTO> getAllApplications(boolean showInactive, List<String> groups);

    CoverSheetApplicationDTO saveApplication(CoverSheetApplicationDTO dto);

    void deleteApplication(Integer id);



    T117ImgCoverObject saveNewCoverSheetTemplate(T117ImgCoverObject template);

    int updateCoverSheetTemplate(T117ImgCoverObject template);

    int getOverrideApplSequence(int applicationId, String applicationName);


    List<CoverSheetDTO> getCoversheetByApplicationId(Integer applicationId);

    List<CoverSheetOverrideDTO> getAllOverridesByApplicationId(Integer applicationId);

    CoverSheetOverrideDTO getCoversheetOverrideByApplicationIdAndName(Integer applicationId, String coversheetName, Integer sequence);

    CoverSheetOverrideDTO createNewOveride(CoverSheetOverrideDTO override);

    int getCoverApplSequence();

    List<CoverSheetApplicationDTO> getAllApplicationsByDepartment(Integer departmentId, List<String> groups);

    CoverSheetDTO getCoversheetByApplicationIdAndName(Integer applicationId, String coversheetName);

    List<CoverSheetOverrideDTO> getAllCoversheetsAndOverridesByTemplateName(String templateName);

    List<CoverSheetOverrideDTO> getCoversheetOverrideListByApplicationIdAndName(Integer applicationId, String coversheetName);

    CoverSheetApplicationDTO getApplicationsById(Integer id, List<String> groups);
}
