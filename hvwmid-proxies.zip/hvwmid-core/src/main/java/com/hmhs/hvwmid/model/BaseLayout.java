package com.hmhs.hvwmid.model;

import org.springframework.boot.jackson.JsonComponent;

@JsonComponent
public class BaseLayout {

}
