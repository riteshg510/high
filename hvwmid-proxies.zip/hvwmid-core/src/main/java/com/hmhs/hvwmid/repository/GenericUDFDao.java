package com.hmhs.hvwmid.repository;

import org.springframework.jdbc.core.JdbcTemplate;

public class GenericUDFDao {
    private final JdbcTemplate jdbcTemplate;
    private final String sequenceFunctionName;

    public GenericUDFDao(JdbcTemplate jdbcTemplate, String sequenceFunctionName) {
        this.jdbcTemplate = jdbcTemplate;
        this.sequenceFunctionName = sequenceFunctionName;
    }

    public String getSequenceNumber() {
        String sql = "SELECT " + sequenceFunctionName + "() FROM SYSIBM.SYSDUMMY1";
        return jdbcTemplate.queryForObject(sql, String.class);
    }

    public int getSequenceNumber(String collectionName) {
        String sql = "SELECT " + collectionName + "." + sequenceFunctionName + "() FROM SYSIBM.SYSDUMMY1";
        return jdbcTemplate.queryForObject(sql, Integer.class);
    }
}
