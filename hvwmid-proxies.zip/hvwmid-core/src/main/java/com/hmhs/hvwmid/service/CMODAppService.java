package com.hmhs.hvwmid.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hmhs.hvwmid.entity.Odscrt;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.OdscrtRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service for retrieving CMOD application data for the file upload process.
 */
@Service
public class CMODAppService {

    private static final Logger logger = LogManager.getLogger(CMODAppService.class);

    @Autowired
    private OdscrtRepository odscrtRepository;

    @Autowired
    private T222APRMRepository aprmRepository;

    /**
     * Get application choices for dropdown display.
     * 
     * @return List of application choices with key and displayName
     */
    public List<Map<String, String>> getApplicationChoices() {
        logger.info("Retrieving application choices for CMOD upload dropdown");
        final List<Map<String, String>> choiceList = new ArrayList<>();

        try {
            // Fetch all ODSCRT records that have a foreign RID
            final List<Odscrt> odscrtRecords = odscrtRepository.findAll().stream()
                    .filter(record -> record.getForeignRid() != null && !record.getForeignRid().isEmpty())
                    .collect(Collectors.toList());

            // Use a Set to avoid duplicate entries
            final Set<String> processedApps = new HashSet<>();

            for (final Odscrt record : odscrtRecords) {
                // Create a unique key for the app group + app name combination
                final String appKey = record.getAgName() + " - " + record.getAppName();
                // Trim the foreign RID to remove any whitespace padding
                final String storeKey = record.getForeignRid() != null ? record.getForeignRid().trim() : "";

                // Skip if we've already processed this app
                if (processedApps.contains(appKey)) {
                    continue;
                }

                // Create a choice item with the foreign RID as the key and app info as the
                // display name
                final Map<String, String> choice = new HashMap<>();
                choice.put("key", storeKey);
                choice.put("displayName", appKey);

                choiceList.add(choice);
                processedApps.add(appKey);
            }

            logger.info("Retrieved {} application choices", choiceList.size());
        } catch (final Exception e) {
            logger.error("Error retrieving application choices: {}", e.getMessage(), e);
            // Return an empty list in case of error
        }

        return choiceList;
    }

    /**
     * Get application choices from the APRM table.
     * 
     * @return List of application choices with key and displayName
     */
    public List<Map<String, String>> getAPRMApplicationChoices() {
        logger.info("Retrieving APRM application choices for CMOD upload dropdown");
        final List<Map<String, String>> choiceList = new ArrayList<>();

        try {
            // Fetch all APRM records (or filter as needed)
            final List<T222APRM> aprmRecords = aprmRepository.findAll();

            // Use a Set to avoid duplicate entries
            final Set<String> processedKeys = new HashSet<>();

            for (final T222APRM record : aprmRecords) {
                // Trim the PARM_KEY to remove any whitespace padding
                final String parmKey = record.getParmKey() != null ? record.getParmKey().trim() : "";
                final String parmData = record.getParmData();

                // Skip if we've already processed this key or if key is empty
                if (processedKeys.contains(parmKey) || parmKey == null || parmKey.isEmpty()) {
                    continue;
                }

                // Create a choice item with parmKey as the key and parmData as additional info
                final Map<String, String> choice = new HashMap<>();
                choice.put("key", parmKey);

                // Use parmData as display name if available, otherwise use parmKey
                final String displayName = (parmData != null && !parmData.isEmpty())
                        ? parmKey + " - " + parmData
                        : parmKey;

                choice.put("displayName", displayName);

                choiceList.add(choice);
                processedKeys.add(parmKey);
            }

            logger.info("Retrieved {} APRM application choices", choiceList.size());
        } catch (final Exception e) {
            logger.error("Error retrieving APRM application choices: {}", e.getMessage(), e);
            // Return an empty list in case of error
        }

        return choiceList;
    }

    /**
     * Get combined application choices from both ODSCRT and APRM tables.
     * 
     * @return List of application choices with key and displayName
     */
    public List<Map<String, String>> getCombinedApplicationChoices() {
        final List<Map<String, String>> combinedList = new ArrayList<>();

        // Get choices from ODSCRT
        combinedList.addAll(getApplicationChoices());

        // Get choices from APRM
        combinedList.addAll(getAPRMApplicationChoices());

        return combinedList;
    }

    /**
     * Get application choices for a specific folder - using the same logic as
     * upload buttons
     * 
     * @param folderName The folder name to filter applications for
     * @return List of application choices with key and displayName that are
     *         relevant to the folder
     */
    public List<Map<String, String>> getApplicationChoicesForFolder(final String folderName) {
        logger.info("Retrieving application choices for folder: {}", folderName);

        if (folderName == null || folderName.isEmpty()) {
            logger.warn("Folder name is null or empty, returning empty list");
            return new ArrayList<>();
        }

        try {
            // Normalize the folder name (remove CMOD and UPLOAD prefixes if present)
            final String normalizedFolderName = normalizeFolderName(folderName);
            logger.debug("Normalized folder name: {} -> {}", folderName, normalizedFolderName);

            final List<T222APRM> parmRecords = new ArrayList<>();

            // First try exact match with normalized name
            logger.debug("Attempting exact match with normalized folder name: '{}'", normalizedFolderName);
            List<T222APRM> exactMatches = aprmRepository.findByParmIdAndParmData(normalizedFolderName);
            if (!exactMatches.isEmpty()) {
                logger.debug("Found {} exact matches with normalized folder name", exactMatches.size());
                parmRecords.addAll(exactMatches);
            }

            if (parmRecords.isEmpty()) {
                logger.debug("No PARM records found for folder (normalized or original), returning empty list");
                // Log diagnostic information about PARM entries
                final List<T222APRM> allParmRecords = aprmRepository.findAll();
                logger.debug("Total PARM entries in database: {}", allParmRecords.size());
                logger.debug("Sample PARM entries:");
                for (int i = 0; i < Math.min(5, allParmRecords.size()); i++) {
                    final T222APRM record = allParmRecords.get(i);
                    logger.debug("  PARM_ID: {}, PARM_KEY: {}, PARM_DATA: '{}'",
                            record.getParmId(), record.getParmKey(), record.getParmData());
                }

                return new ArrayList<>();
            }

            // 2. Get application groups and applications for each PARM Key
            final List<String> foreignRids = parmRecords.stream()
                    .map(T222APRM::getParmKey)
                    .collect(Collectors.toList());

            logger.debug("Foreign RIDs for folder {}: {}", folderName, foreignRids);

            final List<Odscrt> odscrtRecords = new ArrayList<>();
            for (final String foreignRid : foreignRids) {
                final List<Odscrt> records = odscrtRepository.findByForeignRid(foreignRid);
                logger.debug("Found {} ODSCRT records for foreign RID: {}", records.size(), foreignRid);
                odscrtRecords.addAll(records);
            }

            if (odscrtRecords.isEmpty()) {
                logger.debug("No ODSCRT records found for PARM Keys: {}, returning empty list", foreignRids);
                return new ArrayList<>();
            }

            // Log out all the app groups found
            logger.debug("ODSCRT records found for folder {}:", folderName);
            for (final Odscrt record : odscrtRecords) {
                logger.debug("  AG_NAME: {}, APP_NAME: {}, FOREIGN_RID: {}",
                        record.getAgName(), record.getAppName(), record.getForeignRid());
            }

            // Convert to choice format
            final List<Map<String, String>> folderChoices = new ArrayList<>();
            final Set<String> processedApps = new HashSet<>();

            for (final Odscrt record : odscrtRecords) {
                final String appKey = record.getAgName() + " - " + record.getAppName();
                // Trim the foreign RID to remove any whitespace padding
                final String storeKey = record.getForeignRid() != null ? record.getForeignRid().trim() : "";

                if (!processedApps.contains(appKey)) {
                    final Map<String, String> choice = new HashMap<>();
                    choice.put("key", storeKey);
                    choice.put("displayName", appKey);

                    folderChoices.add(choice);
                    processedApps.add(appKey);
                }
            }

            logger.info("Found {} folder-specific applications for {}", folderChoices.size(), folderName);

            // If no folder-specific apps found, return empty list
            if (folderChoices.isEmpty()) {
                logger.warn("No folder-specific applications found for {}, returning empty list", folderName);
                return new ArrayList<>();
            }

            return folderChoices;

        } catch (final Exception e) {
            logger.error("Error filtering applications for folder {}: {}", folderName, e.getMessage(), e);
            // Return empty list if there's an error
            return new ArrayList<>();
        }
    }

    /**
     * Normalizes a folder name by removing any CMOD and UPLOAD prefixes
     *
     * @param folderName The folder name to normalize
     * @return The normalized folder name
     */
    private String normalizeFolderName(final String folderName) {
        if (folderName == null) {
            return null;
        }

        String normalized = folderName;

        // Remove CMOD prefix if present
        if (normalized.startsWith("CMOD")) {
            normalized = normalized.substring(4);
        }

        // Remove UPLOAD prefix if present
        if (normalized.startsWith("UPLOAD")) {
            normalized = normalized.substring(6);
        }

        return normalized;
    }
}