package com.hmhs.hvwmid.service;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;

@Service
public class ReportService {

	private static final Logger logger = LogManager.getLogger(ReportService.class);
	@Value("${api.folders.url}")
	private final String allReportsURL = null;
	private final ObjectMapper objectMapper = new ObjectMapper(); // ObjectMapper instance

	@Autowired
	RestClientUtil restClientUtil;
	
	@Value("${controller.path.rpt}")
	private String basePath; 

	@Autowired
	private CmodFolderService cmodFolderService;

	private final String cmodact = HVWConstants.CMODACT;

	public String getAllReportsDataWithDynamicActions(final String selector, final String authToken) {
		try {
			// 1. Call external service to get raw report data
			final ResponseEntity<Map> response = restClientUtil.postRequest(allReportsURL, authToken, null);

			if (!response.getStatusCode().is2xxSuccessful()) {
				logger.error("Error from external service: {} - {}", response.getStatusCode(), response.getBody());
				throw HVWException.parseErrorResponse(response, "CMOD");
			}

			// 2. Extract and transform the response
			final Map<String, Object> responseBody = response.getBody();
			if (responseBody == null) {
				throw new HVWException(503, "Empty response received from report service", "CMOD");
			}

			final List<Map<String, Object>> transformedReports = transformServiceResponse(responseBody, selector);

			// 3. Convert to JSON and return
			return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(transformedReports);

		} catch (final Exception e) {
			logger.error("Error processing reports data: {}", e.getMessage(), e);
			return buildErrorResponse(e);
		}
	}

	List<Map<String, Object>> transformServiceResponse(final Map<String, Object> rawResponse,
													   final String selector) {
		final List<Map<String, Object>> result = new ArrayList<>();

		// Extract the report list from nested structure
		final List<Map<String, Object>> reports = (List<Map<String, Object>>) rawResponse
				.get("reportArchiveFolderListing");

		for (final Map<String, Object> report : reports) {
			final Map<String, Object> transformed = new HashMap<>();
			String folderName = (String) report.get("odFolderName");
			String encodedFolderName = URLEncoder.encode(folderName, StandardCharsets.UTF_8);
			// Base fields
			//transformed.put("actions", "Search");
			transformed.put("id", "CMOD" + encodedFolderName);
			transformed.put("actionFolderNameId", folderName);
			transformed.put("folderDescriptionId", report.get("odFolderDesc"));
			// Dynamic actions
			transformed.put(cmodact, createActionArray(folderName, selector));
			result.add(transformed);
		}
		return result;
	}

	List<Map<String, String>> createActionArray(final String folderName, final String selector) {
		final List<Map<String, String>> actions = new ArrayList<>();
		final Map<String, String> action = new HashMap<>();
		final Map<String, String> navigateAction = new HashMap<>();

		final String actionType = selector.equalsIgnoreCase("MYREPORTS") ? "remove" : "add";
		String safeFolderName = folderName.replace("/", "__SLASH__");
		final String encodedFolderName = URLEncoder.encode(safeFolderName, StandardCharsets.UTF_8);
		final String apiUrl = (actionType.equals("add") ? basePath+"/favorites/add/" : basePath+"/favorites/remove/") + encodedFolderName;
		final String actionLabel = (actionType.equals("add") ? "Add" :  "Remove");

		action.put("action", "dynamicAction");
		action.put("actionIcon", actionType);
		action.put("apiUrl", apiUrl);
		action.put("label", actionLabel);
		action.put("actionType", actionType.equals("add") ? "submit" : "delete");
		navigateAction.put("action", "navigate");
		navigateAction.put("label", "Search");
		// Replace '/' with unique string '__SLASH__' in navigateUrl

		String safeUrl = HVWConstants.SINGLEREPORT + safeFolderName;

		navigateAction.put("navigateUrl", safeUrl);
		actions.add(navigateAction);
		actions.add(action);
		return actions;
	}

	private String buildErrorResponse(final Exception e) {
		final Map<String, Object> errorResponse = HVWException.createErrorResponse(e);

		try {
			return objectMapper.writeValueAsString(errorResponse);
		} catch (final JsonProcessingException ex) {
			return "{\"status\":\"error\",\"message\":\"Failed to serialize error response\"}";
		}
	}

	

	

	public String getCmodFolderData(final String folderId, final String sHelp, final String authToken)
			throws IOException {
		// Delegate to the new CmodFolderService and propagate any exceptions
		logger.debug("Fetching CMOD folder data for folderId: {}", folderId);
		try {
			return cmodFolderService.getCmodFolderData(folderId, sHelp, authToken);
		} catch (final HVWException e) {
			// Propagate HVWException directly
			throw e;
		} catch (final Exception e) {
			// Wrap other exceptions
			logger.error("Error getting CMOD folder data for {}: {}", folderId, e.getMessage(), e);
			throw new HVWException(503, "Error retrieving CMOD folder data: " + e.getMessage(), "CMOD");
		}
	}
}
