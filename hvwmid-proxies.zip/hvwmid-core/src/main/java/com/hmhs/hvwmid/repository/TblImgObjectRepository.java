package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.TblImgObjectId;
import jakarta.persistence.QueryHint;
import org.hibernate.jpa.AvailableHints;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblImgObject;

import java.util.List;
import java.util.stream.Stream;

@Repository
public interface TblImgObjectRepository extends JpaRepository<TblImgObject, TblImgObjectId> {

    //List<TblImgObject> findByRequestIdOrderBySequenceNo(Integer requestId);

    @Query("select o from TblImgObject o where o.id.requestId = :rid order by o.id.sequenceNo")
    @QueryHints(@QueryHint(name = AvailableHints.HINT_FETCH_SIZE, value = "50"))
    Stream<TblImgObject> streamByRequestId(@Param("rid") Integer requestId);
}
