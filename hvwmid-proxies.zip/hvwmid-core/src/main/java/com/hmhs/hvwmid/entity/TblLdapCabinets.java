package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Nov 22, 2024
 */
@Entity
@Table(name = "T222_HVW_LDAP_CABINETS")
public class TblLdapCabinets {
	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String ldapId;
	@Column(length = 32)
	private String cabinetId;
	private String cabinetName;
	private String ldapGroupName;

	public String getLdapId() {
		return ldapId;
	}

	public void setLdapId(String ldapId) {
		this.ldapId = ldapId;
	}

	public String getCabinetId() {
		return cabinetId;
	}

	public void setCabinetId(String cabinetId) {
		this.cabinetId = cabinetId;
	}

	public String getCabinetName() {
		return cabinetName;
	}

	public void setCabinetName(String cabinetName) {
		this.cabinetName = cabinetName;
	}

	public String getLdapGroupName() {
		return ldapGroupName;
	}

	public void setLdapGroupName(String ldapGroupName) {
		this.ldapGroupName = ldapGroupName;
	}

}
