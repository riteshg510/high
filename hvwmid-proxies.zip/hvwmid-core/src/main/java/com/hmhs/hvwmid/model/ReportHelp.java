package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)

public class ReportHelp {
	
	public ReportHelp()
	{
		
	}
	
	public ReportHelp(String htmlText) {
		
		setHtmlText(htmlText);
	}

	private String htmlText;

	// Getters and Setters
	public String getHtmlText() {
		return htmlText;
	}

	public void setHtmlText(String htmlText) {
		this.htmlText = htmlText;
	}

}
