package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblPickListItems;

/**
 * @author Ramanjaneyulu Manam on Sep 20, 2024
 */
@Repository
public interface ChoiceItemsRepository extends JpaRepository<TblPickListItems, Long> {

	/**
	 * @param pid
	 * @return
	 */
	List<TblPickListItems> getChoiceItemsByPickListIdOrderByIdAsc(String pid);

	/**
	 * @param pid
	 * @param dkey
	 * @return
	 */
	List<TblPickListItems> getChoiceItemsByPickListIdAndDependentKeyOrderByIdAsc(String pid, String dkey);

}
