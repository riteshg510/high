package com.hmhs.hvwmid.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.entity.TblUserReport;
import com.hmhs.hvwmid.repository.UserReportRepository;

@Service
public class UserReportService {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private UserReportRepository userReportRepository;

	@Transactional
	public TblUserReport saveUserReport(String userId, String reportId) {
		TblUserReport tblUserReport = new TblUserReport();
		tblUserReport.setUserId(userId);
		tblUserReport.setReportId(reportId);
		tblUserReport.setUserReportId(reportId + "_" + userId);
		return userReportRepository.save(tblUserReport);
	}

	public String filterJsonByDb(String userId, String jsonInput) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode jsonArray = mapper.readTree(jsonInput);
			List<String> userReports = userReportRepository.findReportsByUserId(userId);
			List<JsonNode> filteredList = new ArrayList<>();

			for (JsonNode node : jsonArray) {
				String id = node.get("actionFolderNameId").asText();
				if (userReports.contains(id)) {
					filteredList.add(node);
				}
			}

			// Convert the filtered list back to JSON string
			return mapper.writeValueAsString(filteredList);

		} catch (Exception e) {
			logger.error(e.getMessage());
			return "[]"; // Return empty JSON array in case of error
		}
	}

	/*
	 
	  public void removeFromMyReport(String userId, String reportId) {	  
	  	userReportRepository.deleteByUserIdAndReportId(userId, reportId); 
	  }
	 
	 */

	public boolean removeFromMyReport(String userId, String reportId) {
		Optional<TblUserReport> tblUserReport = userReportRepository.findByUserIdAndReportId(userId, reportId);
		if (tblUserReport.isPresent()) {
			userReportRepository.delete(tblUserReport.get());
			return true;
		}
		return false;
	}

}
