package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.util.Objects;

public class T117ImgCoverSheetId implements Serializable {

    private Integer application;
    private String name;

    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof T117ImgCoverSheetId)) return false;
        T117ImgCoverSheetId that = (T117ImgCoverSheetId) o;
        return Objects.equals(application, that.application) &&
                Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(application, name);
    }
}
