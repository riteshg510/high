package com.hmhs.hvwmid.service;

import java.util.List;
import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.model.ImageDataModel;

/**
 * @author Ramanjaneyulu Manam on Oct 10, 2024
 */
public interface CustomPostService {

	/**
	 * @param inputData
	 * @return
	 */
	List<ImageData> getViewImageData(ImageDataModel inputData);

	/**
	 * @param fieldName
	 * @param lookupValue
	 * @return
	 */
	List<String> getLookupValues(String fieldName, String lookupValue);

}
