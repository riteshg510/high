package com.hmhs.hvwmid.dto;

public class PolicyWithHoldDTO {
    private String policyCode;
    private String policyId;
    private String policyDescription;
    private String policyIdType;
    private Integer policyDays;
    private String policyEditFlag;
    private String policyEditPgmName;
    private String policyBaseDate;
    private String modUser;
    private String modDate;
    private Integer bpdId;
    private String holdCode;
    private String holdId;
    private String holdDescription;
    private String holdEditFlag;
    private String holdEditPgmName;
    private String holdModUser;
    private String holdDateBegin;
    private String holdDateEnd;

    // Constructor iz Object[]
    public PolicyWithHoldDTO(Object[] row) {
        this.policyCode = row[0] != null ? row[0].toString() : null;
        this.policyId = row[1] != null ? row[1].toString() : null;
        this.policyDescription = row[2] != null ? row[2].toString() : null;
        this.policyIdType = row[3] != null ? row[3].toString() : null;
        this.policyDays = row[4] != null ? ((Number) row[4]).intValue() : null;
        this.policyEditFlag = row[5] != null ? row[5].toString() : null;
        this.policyEditPgmName = row[6] != null ? row[6].toString() : null;
        this.policyBaseDate = row[7] != null ? row[7].toString() : null;
        this.modUser = row[8] != null ? row[8].toString() : null;
        this.modDate = row[9] != null ? row[9].toString() : null;
        this.bpdId = row[10] != null ? ((Number) row[10]).intValue() : null;
        this.holdCode = row[11] != null ? row[11].toString() : null;
        this.holdId = row[12] != null ? row[12].toString() : null;
        this.holdDescription = row[13] != null ? row[13].toString() : null;
        this.holdEditFlag = row[14] != null ? row[14].toString() : null;
        this.holdEditPgmName = row[15] != null ? row[15].toString() : null;
        this.holdModUser = row[16] != null ? row[16].toString() : null;
        this.holdDateBegin = row[17] != null ? row[17].toString() : null;
        this.holdDateEnd = row[18] != null ? row[18].toString() : null;
    }


    public String getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(String policyCode) {
        this.policyCode = policyCode;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public String getPolicyDescription() {
        return policyDescription;
    }

    public void setPolicyDescription(String policyDescription) {
        this.policyDescription = policyDescription;
    }

    public String getPolicyIdType() {
        return policyIdType;
    }

    public void setPolicyIdType(String policyIdType) {
        this.policyIdType = policyIdType;
    }

    public Integer getPolicyDays() {
        return policyDays;
    }

    public void setPolicyDays(Integer policyDays) {
        this.policyDays = policyDays;
    }

    public String getPolicyEditFlag() {
        return policyEditFlag;
    }

    public void setPolicyEditFlag(String policyEditFlag) {
        this.policyEditFlag = policyEditFlag;
    }

    public String getPolicyEditPgmName() {
        return policyEditPgmName;
    }

    public void setPolicyEditPgmName(String policyEditPgmName) {
        this.policyEditPgmName = policyEditPgmName;
    }

    public String getPolicyBaseDate() {
        return policyBaseDate;
    }

    public void setPolicyBaseDate(String policyBaseDate) {
        this.policyBaseDate = policyBaseDate;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public String getModDate() {
        return modDate;
    }

    public void setModDate(String modDate) {
        this.modDate = modDate;
    }

    public Integer getBpdId() {
        return bpdId;
    }

    public void setBpdId(Integer bpdId) {
        this.bpdId = bpdId;
    }

    public String getHoldCode() {
        return holdCode;
    }

    public void setHoldCode(String holdCode) {
        this.holdCode = holdCode;
    }

    public String getHoldId() {
        return holdId;
    }

    public void setHoldId(String holdId) {
        this.holdId = holdId;
    }

    public String getHoldDescription() {
        return holdDescription;
    }

    public void setHoldDescription(String holdDescription) {
        this.holdDescription = holdDescription;
    }

    public String getHoldEditFlag() {
        return holdEditFlag;
    }

    public void setHoldEditFlag(String holdEditFlag) {
        this.holdEditFlag = holdEditFlag;
    }

    public String getHoldEditPgmName() {
        return holdEditPgmName;
    }

    public void setHoldEditPgmName(String holdEditPgmName) {
        this.holdEditPgmName = holdEditPgmName;
    }

    public String getHoldModUser() {
        return holdModUser;
    }

    public void setHoldModUser(String holdModUser) {
        this.holdModUser = holdModUser;
    }

    public String getHoldDateBegin() {
        return holdDateBegin;
    }

    public void setHoldDateBegin(String holdDateBegin) {
        this.holdDateBegin = holdDateBegin;
    }

    public String getHoldDateEnd() {
        return holdDateEnd;
    }

    public void setHoldDateEnd(String holdDateEnd) {
        this.holdDateEnd = holdDateEnd;
    }
}

