package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

@Table(name = "T222_IMG_RMA_POLICY")
@Entity
public class T222ImgRmaPolicy {
    @Column(name = "BPD_ID", nullable = false)
    private Integer bpdId;

    @Id
    @Column(name = "POLICY_CODE", nullable = false)
    private Integer policyCode;

    @Column(name = "POLICY_ID", length = 30, nullable = false)
    private String policyId;

    @Column(name = "POLICY_DAYS", nullable = false)
    private Integer policyDays;

    @Column(name = "POLICY_EDIT_FLAG", length = 1)
    private String policyEditFlag;

    @Column(name = "POLICY_EDIT_PGMNAME", length = 8, nullable = false)
    private String policyEditPgmName;

    @Column(name = "POLICY_ID_TYPE", length = 5, nullable = false)
    private String policyIdType;

    @Column(name = "POLICY_BASE_DATE")
    private LocalDate policyBaseDate;

    @Column(name = "MODUSER", length = 8, nullable = false)
    private String modUser;

    @Column(name = "MODDATE", nullable = false)
    private LocalDateTime modDate;

    @Column(name = "POLICY_DESCRIPTION", length = 250, nullable = false)
    private String policyDescription;

    @PrePersist
    public void generateIdIfMissing() {
        if (policyCode == null) {
            policyCode = ThreadLocalRandom.current().nextInt(1, 1_000_000);
        }
    }

    public Integer getBpdId() {
        return bpdId;
    }

    public void setBpdId(Integer bpdId) {
        this.bpdId = bpdId;
    }

    public Integer getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(Integer policyCode) {
        this.policyCode = policyCode;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public Integer getPolicyDays() {
        return policyDays;
    }

    public void setPolicyDays(Integer policyDays) {
        this.policyDays = policyDays;
    }

    public String getPolicyEditFlag() {
        return policyEditFlag;
    }

    public void setPolicyEditFlag(String policyEditFlag) {
        this.policyEditFlag = policyEditFlag;
    }

    public String getPolicyEditPgmName() {
        return policyEditPgmName;
    }

    public void setPolicyEditPgmName(String policyEditPgmName) {
        this.policyEditPgmName = policyEditPgmName;
    }

    public String getPolicyIdType() {
        return policyIdType;
    }

    public void setPolicyIdType(String policyIdType) {
        this.policyIdType = policyIdType;
    }

    public LocalDate getPolicyBaseDate() {
        return policyBaseDate;
    }

    public void setPolicyBaseDate(LocalDate policyBaseDate) {
        this.policyBaseDate = policyBaseDate;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public LocalDateTime getModDate() {
        return modDate;
    }

    public void setModDate(LocalDateTime modDate) {
        this.modDate = modDate;
    }

    public String getPolicyDescription() {
        return policyDescription;
    }

    public void setPolicyDescription(String policyDescription) {
        this.policyDescription = policyDescription;
    }

    @Override
    public String toString() {
        return "T222ImgRmaPolicy{" +
               "bpdId=" + bpdId +
               ", policyCode=" + policyCode +
               ", policyId='" + policyId + '\'' +
               ", policyDays=" + policyDays +
               ", policyEditFlag='" + policyEditFlag + '\'' +
               ", policyEditPgmName='" + policyEditPgmName + '\'' +
               ", policyIdType='" + policyIdType + '\'' +
               ", policyBaseDate=" + policyBaseDate +
               ", modUser='" + modUser + '\'' +
               ", modDate=" + modDate +
               ", policyDescription='" + policyDescription + '\'' +
               '}';
    }
}
