package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DeleteTempIDService {

    private static final Logger logger = LogManager.getLogger(DeleteTempIDService.class);

    @Autowired
    private RestClientUtil restClientUtil;

    @Value("${api.images.deletetempid.url}")
    String url = null; // /deletetempid/delete

    private static final String X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS = "x-highmark-businessProcessDifferentiatorIds";
    private static final String BPDID_FIELD = "bpdid";

    public ResponseEntity<Object> delete(Map<String, String> otherFields, String authToken) {
        return executeAction(otherFields, authToken);
    }

    public ResponseEntity<Object> executeAction(Map<String, String> otherFields, String authToken) {
        final ResponseEntity<Map> response = getFromBack(otherFields, authToken);

        List<Map> result = getResults(response.getBody());

        return new ResponseEntity<>(result, response.getStatusCode());
    }

    private ResponseEntity<Map> getFromBack(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>(otherFields);

        Map<String, String> extraHeaders = generateExtraHeaders(otherFields);

        return restClientUtil.postRequest(url+"/delete", authToken, requestBody, extraHeaders);
    }

    private static Map<String, String> generateExtraHeaders(Map<String, String> otherFields) {
        Map<String, String> extraHeaders = new HashMap<>();

        if (otherFields.containsKey(BPDID_FIELD) && !StringUtils.isBlank(otherFields.get(BPDID_FIELD))) {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, otherFields.get(BPDID_FIELD));
        } else {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, "1");
        }

        return extraHeaders;
    }

    private List<Map> getResults(Map response){
        List<Map> result = new ArrayList<>();
        if(response.containsKey("results")){
            Map results = (Map) response.get("results");
            Map<String, Object> values = new HashMap<>();
            values.put("Foldid", results.get("foldid"));
            values.put("Foldtkn", results.get("foldtkn"));
            values.put("Objtime", results.get("objtime"));
            values.put("ReturnCode", results.get("returnCode"));
            values.put("ReasonCode", results.get("reasonCode"));
            values.put("Message", results.get("message"));
            result.add(values);
        }
        return result;
    }
}