package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T117ImgCoverSheetOverride;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetOverrideId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface T117ImgCoverSheetOverrideRepository
                extends JpaRepository<T117ImgCoverSheetOverride, T117ImgCoverSheetOverrideId> {

        @Query("SELECT o FROM T117ImgCoverSheetOverride o " +
                        "WHERE o.application = :applicationId " +
                        "AND o.name = :name " +
                        "AND o.sequence = :sequence")
        Optional<T117ImgCoverSheetOverride> findByAppNameSequence(@Param("applicationId") int applicationId,
                        @Param("name") String name,
                        @Param("sequence") int sequence);

        @Query("SELECT COALESCE(MAX(t.sequence), 0) FROM T117ImgCoverSheetOverride t " +
                        "WHERE t.application = :applicationId AND UPPER(t.name) = UPPER(:name)")
        int findMaxSequenceByApplicationAndName(@Param("applicationId") int applicationId,
                        @Param("name") String name);

        List<T117ImgCoverSheetOverride> findAllByApplicationAndName(Integer application, String name);

        List<T117ImgCoverSheetOverride> findAllByApplication(int applicationId);

        List<T117ImgCoverSheetOverride> findAllByTemplate(String template);
}
