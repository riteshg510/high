package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Nov 20, 2024
 */
@Entity
@Table(name = "T222_HVW_DEPARTMENT")
public class TblDepartment {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String departmentId;
	private String departmentName;

	public String getDepartmentId() {
		return departmentId.toUpperCase();
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId.toUpperCase();
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

}
