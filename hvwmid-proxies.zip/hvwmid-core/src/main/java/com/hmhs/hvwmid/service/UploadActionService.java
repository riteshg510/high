package com.hmhs.hvwmid.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.Odscrt;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.OdscrtRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.utils.RestClientUtil;

@Service
public class UploadActionService {

    private static final Logger logger = LogManager.getLogger(UploadActionService.class);

    @Value("${api.access.url}")
    private String accessApiUrl;

    @Autowired
    private T222APRMRepository t222aprmRepository;

    @Autowired
    private OdscrtRepository odscrtRepository;

    @Autowired
    private RestClientUtil restClientUtil;

    /**
     * Checks if upload action should be shown for a given folder
     * 
     * @param folderName The folder name to check
     * @param authToken  The authentication token
     * @return true if upload action should be shown, false otherwise
     */
    public boolean shouldShowUploadAction(final String folderName, final String authToken) {
        try {
            if (folderName == null || folderName.isEmpty()) {
                logger.debug("Folder name is null or empty");
                return false;
            }

            // Normalize the folder name (remove CMOD and UPLOAD prefixes if present)
            final String normalizedFolderName = normalizeFolderName(folderName);
            logger.debug("Normalized folder name: {} -> {}", folderName, normalizedFolderName);

            final List<T222APRM> parmRecords = new ArrayList<>();

            // First try exact match with normalized name
            logger.debug("Attempting exact match with normalized folder name: '{}'", normalizedFolderName);
            final List<T222APRM> exactMatches = t222aprmRepository.findByParmIdAndParmData(normalizedFolderName);
            if (!exactMatches.isEmpty()) {
                logger.debug("Found {} exact matches with normalized folder name", exactMatches.size());
                parmRecords.addAll(exactMatches);
            } 
            
            logger.debug("Final PARM records count for folder {}: {}", folderName, parmRecords.size());

            if (parmRecords.isEmpty()) {
                logger.debug("No PARM records found for folder: {} (normalized: {})", folderName, normalizedFolderName);

                // Log diagnostic information
                final List<T222APRM> allParmRecords = t222aprmRepository.findByParmId(HVWConstants.PARMIDFORAPPLIST);
                logger.debug("Total PARM entries in database for PARM_ID={}: {}", HVWConstants.PARMIDFORAPPLIST, allParmRecords.size());
                logger.debug("Sample PARM entries:");
                for (int i = 0; i < Math.min(5, allParmRecords.size()); i++) {
                    final T222APRM record = allParmRecords.get(i);
                    logger.debug("  PARM_ID: {}, PARM_KEY: {}, PARM_DATA: '{}'",
                            record.getParmId(), record.getParmKey(), record.getParmData());
                }

                return false;
            }

            // 2. Get application groups and applications for each PARM Key
            final List<String> foreignRids = parmRecords.stream()
                    .map(T222APRM::getParmKey)
                    .collect(Collectors.toList());

            logger.debug("Foreign RIDs for folder {}: {}", folderName, foreignRids);

            final List<Odscrt> odscrtRecords = new ArrayList<>();
            for (final String foreignRid : foreignRids) {
                final List<Odscrt> records = odscrtRepository.findByForeignRid(foreignRid);
                logger.debug("Found {} ODSCRT records for foreign RID: {}", records.size(), foreignRid);
                odscrtRecords.addAll(records);
            }

            if (odscrtRecords.isEmpty()) {
                logger.debug("No ODSCRT records found for PARM Keys: {}", foreignRids);
                return false;
            }

            // Log out all the app groups found
            logger.debug("ODSCRT records found:");
            for (final Odscrt record : odscrtRecords) {
                logger.debug("  AG_NAME: {}, APP_NAME: {}, FOREIGN_RID: {}",
                        record.getAgName(), record.getAppName(), record.getForeignRid());
            }

            // 3. Check user access for each application group
            final Map<String, Object> accessResponse = checkUserAccess(folderName, authToken);
            if (accessResponse == null) {
                logger.error("Failed to get user access details");
                return false;
            }

            // 4. Check if user has Add access for any of the application groups
            return hasAddAccess(odscrtRecords, accessResponse);

        } catch (final Exception e) {
            logger.error("Error checking upload action visibility for folder {}: {}", folderName, e.getMessage(), e);
            return false;
        }
    }

    /**
     * Checks user access using the access API
     * 
     * @param folderName The folder name to check access for
     * @param authToken  The authentication token
     * @return The access response or null if failed
     */
    private Map<String, Object> checkUserAccess(final String folderName, final String authToken) {
        try {
            if (folderName == null || folderName.isEmpty()) {
                logger.warn("Folder name is empty when checking access rights");
                return null;
            }

            // Create the request body with the folder name
            final Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("odFolder", folderName);

            // Call access API with auth token and request body
            logger.debug("Calling access API for folder: {}", folderName);
            final ResponseEntity<Map> response = restClientUtil.postRequest(accessApiUrl, authToken, requestBody);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody();
            }
            logger.error("Failed to get user access details: {}", response.getStatusCode());
            return null;
        } catch (final Exception e) {
            logger.error("Error checking user access for folder {}: {}", folderName, e.getMessage(), e);
            return null;
        }
    }

    /**
     * Checks if user has Add access for any of the application groups
     * 
     * @param odscrtRecords  The ODSCRT records
     * @param accessResponse The access API response
     * @return true if user has Add access, false otherwise
     */
    private boolean hasAddAccess(final List<Odscrt> odscrtRecords, final Map<String, Object> accessResponse) {
        try {
            // Check if accessResponse has the required structure
            if (accessResponse == null) {
                logger.debug("Access response is null");
                return false;
            }

            // The authorizedApplicationGroups is directly at the root level, not inside
            // serviceMessage
            if (!accessResponse.containsKey("authorizedApplicationGroups")) {
                logger.debug("Access response is missing authorizedApplicationGroups");
                return false;
            }

            final List<Map<String, Object>> authorizedGroups = (List<Map<String, Object>>) accessResponse
                    .get("authorizedApplicationGroups");

            if (authorizedGroups == null || authorizedGroups.isEmpty()) {
                logger.debug("No authorized application groups found");
                return false;
            }

            // Log all available authorized groups for debugging
            logger.debug("Available authorized groups:");
            for (final Map<String, Object> group : authorizedGroups) {
                if (group.containsKey("groupName")) {
                    logger.debug("  Group: {}, AccessLevel: {}",
                            group.get("groupName"),
                            group.containsKey("accessLevel") ? group.get("accessLevel") : "N/A");
                }
            }

            for (final Odscrt odscrt : odscrtRecords) {
                final String agName = odscrt.getAgName();
                logger.debug("Checking ODSCRT group: {}", agName);

                for (final Map<String, Object> group : authorizedGroups) {
                    if (!group.containsKey("groupName") || !group.containsKey("accessLevel")) {
                        continue;
                    }

                    final String groupName = (String) group.get("groupName");
                    logger.debug("  Comparing with authorized group: {}", groupName);

                    // Try exact match first
                    boolean matched = agName.equals(groupName);

                    // If no exact match, try case-insensitive match with trimming
                    if (!matched && groupName != null) {
                        matched = agName.trim().equalsIgnoreCase(groupName.trim());
                        if (matched) {
                            logger.debug("  Match found using case-insensitive comparison");
                        }
                    }

                    if (matched) {
                        final String accessLevel = (String) group.get("accessLevel");
                        logger.debug("  Group match found! Access level: {}", accessLevel);

                        if (accessLevel != null && accessLevel.contains("Add")) {
                            logger.debug("Found Add access for group: {}", agName);
                            return true;
                        }
                    }
                }
            }

            logger.debug("No matching group with Add access found");
            return false;
        } catch (final Exception e) {
            logger.error("Error checking Add access: {}", e.getMessage(), e);
            return false;
        }
    }

    /**
     * Gets all application groups and applications for a given folder name
     * For testing and troubleshooting purposes
     * 
     * @param folderName The folder name to check
     * @return List of ODSCRT records, or an empty list if none found
     */
    public List<Odscrt> getApplicationsForFolder(final String folderName) {
        try {
            if (folderName == null || folderName.isEmpty()) {
                logger.debug("Folder name is null or empty");
                return new ArrayList<>();
            }

            // Normalize the folder name (remove CMOD and UPLOAD prefixes if present)
            final String normalizedFolderName = normalizeFolderName(folderName);
            logger.debug("Normalized folder name: {} -> {}", folderName, normalizedFolderName);

            final List<T222APRM> parmRecords = new ArrayList<>();

            // Try with normalized name first
            final List<T222APRM> normalizedMatches = t222aprmRepository.findByParmIdAndParmData(normalizedFolderName);
            if (!normalizedMatches.isEmpty()) {
                logger.debug("Found {} matches with normalized folder name", normalizedMatches.size());
                parmRecords.addAll(normalizedMatches);
            }

            if (parmRecords.isEmpty()) {
                logger.debug("No PARM records found for folder: {} (normalized: {})", folderName, normalizedFolderName);
                return new ArrayList<>();
            }

            // 2. Get application groups and applications for each PARM Key
            final List<String> foreignRids = parmRecords.stream()
                    .map(T222APRM::getParmKey)
                    .collect(Collectors.toList());

            final List<Odscrt> odscrtRecords = new ArrayList<>();
            for (final String foreignRid : foreignRids) {
                odscrtRecords.addAll(odscrtRepository.findByForeignRid(foreignRid));
            }

            return odscrtRecords;
        } catch (final Exception e) {
            logger.error("Error getting applications for folder {}: {}", folderName, e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    /**
     * Normalizes a folder name by removing any CMOD and UPLOAD prefixes
     *
     * @param folderName The folder name to normalize
     * @return The normalized folder name
     */
    private String normalizeFolderName(final String folderName) {
        if (folderName == null) {
            return null;
        }

        String normalized = folderName;

        // Remove CMOD prefix if present
        if (normalized.startsWith("CMOD")) {
            normalized = normalized.substring(4);
        }

        // Remove UPLOAD prefix if present
        if (normalized.startsWith("UPLOAD")) {
            normalized = normalized.substring(6);
        }

        return normalized;
    }
}