package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ramanjaneyulu Manam on Nov 19, 2024
 */
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Cabinets {

	private Cabinet data;
	private List<Cabinet> children;

	public Cabinet getData() {
		return data;
	}

	public void setData(Cabinet data) {
		this.data = data;
	}

	public List<Cabinet> getChildren() {
		return children;
	}

	public void setChildren(List<Cabinet> children) {
		this.children = children;
	}

}
