package com.hmhs.hvwmid.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.core.io.ByteArrayResource;

import java.util.Map;

@Service
public class CMODDownloadService extends CMODDocumentService {

    private static final Logger logger = LogManager.getLogger(CMODDownloadService.class);

    @Autowired
    private RestClientUtil restClientUtil;

    public ResponseEntity<ByteArrayResource> downloadDocument(final String documentToken, final String odFolder,
            final String authToken) {
        validateDocumentToken(documentToken);
        validateFolder(odFolder);

        // Prepare base payload
        final Map<String, Object> payload = prepareBasePayload(documentToken, odFolder);

        logger.info("Sending download request to URL: {} with payload: {}", downloadUrl, payload);
        // Make the API call and expect a binary response
        final ResponseEntity<ByteArrayResource> response = restClientUtil.postRequestForBinary(downloadUrl, authToken,
                payload);

        // Log the response status
        logger.info("Download response status: {}", response.getStatusCode());

        // Just return the response with its original status code
        return response;
    }

    public Map<String, Integer> getDocumentRequestId(final String documentToken, final String odFolder,
            final String authToken, final String translateType) {
        validateDocumentToken(documentToken);
        validateFolder(odFolder);

        // Prepare base payload
        final Map<String, Object> payload = prepareBasePayload(documentToken, odFolder);
        if (translateType != null && !translateType.isEmpty()) {
            payload.put("translateType", translateType);
        }
        logger.info("Sending download request to URL: {} with payload: {}", getRequestIdUrl, payload);
        // Make the API call and expect a binary response
        final ResponseEntity<Map> response = restClientUtil.postRequest(getRequestIdUrl, authToken, payload);

        if (response.getStatusCode() == HttpStatus.OK) {
            Map<String, Integer> responseBody = response.getBody();
            if (responseBody != null && responseBody.containsKey("REQUEST_ID")) {
                return responseBody;
            } else {
                logger.error("Request ID not found in the response");
                throw new RuntimeException("Request ID not found in the response");
            }
        } else {
            logger.error("Failed to get request ID, status code: {}", response.getStatusCode());
            throw new RuntimeException("Failed to get request ID, status code: " + response.getStatusCode());
        }
    }
}