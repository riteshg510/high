package com.hmhs.hvwmid.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IMISearchData {
	
	@JsonProperty("searchResultsList")
    private List<IMISearchResults> searchResultsList;
	
	@JsonProperty("baseMessage")
    private BaseMessage baseMessage;
	
	@JsonProperty("serviceMessage")
    private ServiceMessage serviceMessage;
	
	@JsonProperty("naicMap")
    private Map<String, String> naicMap;	
	
    
    public List<IMISearchResults> getSearchResultsList() {
        return searchResultsList;
    }

    public void setSearchResultsList(List<IMISearchResults> searchResultsList) {
        this.searchResultsList = searchResultsList;
    }

    public BaseMessage getBaseMessage() {
        return baseMessage;
    }

    public void setBaseMessage(BaseMessage baseMessage) {
        this.baseMessage = baseMessage;
    }
    
    public ServiceMessage getServiceMessage() {
        return serviceMessage;
    }

    public void setServiceMessage(ServiceMessage serviceMessage) {
        this.serviceMessage = serviceMessage;
    }
    
    public Map<String, String> getNaicMap() {
        return naicMap;
    }

    public void setNaicMap(Map<String, String> naicMap) {
        this.naicMap = naicMap;
    }
    
    public static class BaseMessage {
    	
    	@JsonProperty("returnCode")
        private String returnCode;
    	
    	@JsonProperty("returnCodeDescription")
        private String returnCodeDescription;

        public String getReturnCode() {
            return returnCode;
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public String getReturnCodeDescription() {
            return returnCodeDescription;
        }

        public void setReturnCodeDescription(String returnCodeDescription) {
            this.returnCodeDescription = returnCodeDescription;
        }
    }
    
    public static class ServiceMessage {
    	
    	@JsonProperty("returnCode")
        private Integer returnCode;
    	
    	@JsonProperty("returnCodeDescription")
        private String returnCodeDescription;

        public Integer getReturnCode() {
            return returnCode;
        }

        public void setReturnCode(Integer returnCode) {
            this.returnCode = returnCode;
        }

        public String getReturnCodeDescription() {
            return returnCodeDescription;
        }

        public void setReturnCodeDescription(String returnCodeDescription) {
            this.returnCodeDescription = returnCodeDescription;
        }
    }
} 