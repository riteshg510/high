package com.hmhs.hvwmid.service;

import java.sql.Timestamp;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.entity.TblHvwStatus;
import com.hmhs.hvwmid.entity.TblHvwStatusId;
import com.hmhs.hvwmid.repository.TblHvwStatusRepository;

@Service
public class HvwStatusService {

	private static final Logger logger = LogManager.getLogger(HvwStatusService.class);

	@Autowired
	TblHvwStatusRepository hvwStatusRepository;

	@Value("${app.environment:default}")
	private String environment;

	public TblHvwStatus populateT222HvwStatus(int requestId, int imgRequestId, int codRequestId, String userId,
			String function, String originalURL, String statusCode, String desc) {
		// Skip database operations in Noservice mode
		if ("Noservice".equalsIgnoreCase(environment)) {
			logger.debug("[NOSERVICE] Skipping database status recording for: {} - {} - {}: {}", userId, function,
					statusCode, desc);
			return null;
		}
		
		TblHvwStatus hvwStatus = new TblHvwStatus();
		TblHvwStatusId id = new TblHvwStatusId(requestId, new Timestamp(Calendar.getInstance().getTimeInMillis()));
		hvwStatus.setId(id);
		hvwStatus.setImgRequestId(imgRequestId);
		hvwStatus.setCodRequestId(codRequestId);
		hvwStatus.setUserId(userId);
		hvwStatus.setFunction(StringUtils.substring(function, 0, 25));
		hvwStatus.setOriginalUrl(originalURL);
		hvwStatus.setStatusCode(statusCode);
		hvwStatus.setStatusDescription(StringUtils.substring(desc, 0, 254));

		return hvwStatusRepository.save(hvwStatus);
	}

}
