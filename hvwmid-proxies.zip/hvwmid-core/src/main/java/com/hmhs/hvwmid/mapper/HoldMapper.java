package com.hmhs.hvwmid.mapper;

import com.hmhs.hvwmid.dto.HoldResponse;
import com.hmhs.hvwmid.entity.T222ImgRmaHold;

import java.time.format.DateTimeFormatter;

public class HoldMapper {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static HoldResponse toResponse(T222ImgRmaHold entity) {
        if (entity == null) return null;

        HoldResponse response = new HoldResponse();
        response.setBpdId(entity.getBpdId());
        response.setHoldCode(entity.getHoldCode());
        response.setHoldId(entity.getHoldId());
        response.setHoldDateBegin(entity.getHoldDateBegin() != null ? entity.getHoldDateBegin().format(DATE_FORMATTER) : null);
        response.setHoldDateEnd(entity.getHoldDateEnd() != null ? entity.getHoldDateEnd().format(DATE_FORMATTER) : null);
        response.setHoldEditFlag(entity.getHoldEditFlag());
        response.setHoldEditPgmName(entity.getHoldEditPgmName());
        response.setModUser(entity.getModUser());
        response.setModDate(entity.getModDate() != null ? entity.getModDate().format(DATETIME_FORMATTER) : null);
        response.setHoldDescription(entity.getHoldDescription());
        return response;
    }
}
