package com.hmhs.hvwmid.service;

import org.apache.commons.collections4.BidiMap;

import java.util.Map;

/**
 * Service interface for managing parameter data from T222APRM table.
 * Provides access to configuration parameters grouped by PARM_ID.
 */

public interface ImageParmDataService {

    /**
     * Refreshes all parameter data from the database.
     */
    void refreshParmData();

    /**
     * Returns the value to which the specified key is mapped for the given parm ID.
     * 
     * @param parmId the parameter ID
     * @param key    the parameter key
     * @return the parameter value, or null if not found
     */
    String getParmData(String parmId, String key);

    /**
     * Returns the parameter map for the specified parm ID.
     * 
     * @param parmId the parameter ID
     * @return the parameter map, or null if not found
     */
    Map<String, String> getParmDataMap(String parmId);

    /**
     * Returns parameter data for the specified key, or default value if not found.
     * 
     * @param parmId             the parameter ID
     * @param parmKey            the parameter key
     * @param defaultParmKeyData the default value to return if key not found
     * @return the parameter value or default value
     */
    String getParmDataByKey(String parmId, String parmKey, String defaultParmKeyData);

    /**
     * Returns parameter data for the specified key, or empty string if not found.
     * 
     * @param parmId  the parameter ID
     * @param parmKey the parameter key
     * @return the parameter value or empty string
     */
    String getParmDataByKey(String parmId, String parmKey);

    /**
     * Returns parameter data for the specified key from HVWBASE parm ID.
     * 
     * @param parmKey            the parameter key
     * @param defaultParmKeyData the default value to return if key not found
     * @return the parameter value or default value
     */
    String getParmDataByKeyByHvwbase(String parmKey, String defaultParmKeyData);

    /**
     * Returns parameter data for the specified key from HVWBASE parm ID.
     * 
     * @param parmKey the parameter key
     * @return the parameter value or null if not found
     */
    String getParmDataByKeyByHvwbase(String parmKey);

    /**
     * Returns parameter data map for the specified CMOD application.
     * 
     * @param cmodApplication the CMOD application name
     * @return the parameter map for the application
     */
    Map<String, String> getParmDataMapBySecuredClntEmpSec(String cmodApplication);

    /**
     * Returns the complete secured client employee security map.
     * 
     * @return the secured client employee security map
     */
    Map<String, Map<String, String>> getSecuredClntEmpSecMap();

    /**
     * Returns parameter data for the specified key from CMBASE parm ID.
     * 
     * @param parmKey            the parameter key
     * @param defaultParmKeyData the default value to return if key not found
     * @return the parameter value or default value
     */
    String getParmDataByKeyByCmodbase(String parmKey, String defaultParmKeyData);

    /**
     * Returns parameter data for the specified key from CODBASE parm ID.
     * 
     * @param parmKey            the parameter key
     * @param defaultParmKeyData the default value to return if key not found
     * @return the parameter value or default value
     */
    String getParmDataByKeyByCODBase(String parmKey, String defaultParmKeyData);

    /**
     * Returns parameter data for the specified key from CMFLDMAP parm ID.
     * 
     * @param parmKey            the parameter key
     * @param defaultParmKeyData the default value to return if key not found
     * @return the parameter value or default value
     */
    String getParmDataByKeyByCmodfld(String parmKey, String defaultParmKeyData);

    /**
     * Returns the bidirectional CMOD field mapping.
     * 
     * @return the bidirectional CMOD field map
     */
    BidiMap<String, String> getCmodfldMap();

    /**
     * Returns the parameter key for the specified parameter value from CMFLDMAP.
     * 
     * @param parmValue          the parameter value
     * @param defaultParmKeyData the default value to return if not found
     * @return the parameter key or default value
     */
    String getParmKeyByParmDataByCmodfld(String parmValue, String defaultParmKeyData);

    /**
     * Returns parameter data for the specified field and OD folder from ODCMFDMP.
     * 
     * @param parmKey            the parameter key (field name)
     * @param odFolderName       the OD folder name
     * @param defaultParmKeyData the default value to return if not found
     * @return the parameter value or default value
     */
    String getParmKeyByParmDataByODCMODField(String parmKey, String odFolderName, String defaultParmKeyData);
}