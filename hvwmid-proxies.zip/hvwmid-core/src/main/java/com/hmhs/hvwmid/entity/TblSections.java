package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Sept 6, 2024
 */
@Entity
@Table(name = "T222_HVW_SECTIONS")
public class TblSections {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String sectionId;
	@Column(length = 32)
	private String formId;
	private Short isRoot;
	private int parentColumnNumber;
	@Column(length = 32)
	private String parentSectionId;
	@Column(length = 64)
	private String sectionName;

	public String getSectionId() {
		return sectionId.toUpperCase();
	}

	public void setSectionId(String sectionId) {
		this.sectionId = sectionId.toUpperCase();
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public Short getIsRoot() {
		return isRoot;
	}

	public void setIsRoot(Short isRoot) {
		this.isRoot = isRoot;
	}

	public int getParentColumnNumber() {
		return parentColumnNumber;
	}

	public void setParentColumnNumber(int parentColumnNumber) {
		this.parentColumnNumber = parentColumnNumber;
	}

	public String getParentSectionId() {
		return parentSectionId;
	}

	public void setParentSectionId(String parentSectionId) {
		this.parentSectionId = parentSectionId.toUpperCase();
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

}
