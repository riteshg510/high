package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblForms;

/**
 * @author Ramanjaneyulu Manam on Sept 16, 2024
 */
@Repository
public interface FormsRepository extends CrudRepository<TblForms, Integer> {
  
	/**
	 * @param formId
	 * @return
	 */
	TblForms getFormByFormId(String formId);

	/**
	 * @param filename
	 * @return
	 */
	List<TblForms> getFormIdByFileName(String filename);
}
