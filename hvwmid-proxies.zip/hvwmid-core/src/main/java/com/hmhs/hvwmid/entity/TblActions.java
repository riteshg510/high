package com.hmhs.hvwmid.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Sept 16, 2024
 */
@Entity
@Table(name = "T222_HVW_ACTIONS")
public class TblActions {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String actionId;
	@Column(length = 32)
	private String action;
	@Column(length = 32)
	private String actionIcon;
	private int actionOrder;
	@Column(length = 32)
	private String actionType;
	private String apiUrl;
	@Column(name = "createTimestamp", columnDefinition = "TIMESTAMP")
	private LocalDateTime createTimestamp;
	@Column(length = 32)
	private String formId;
	private String label;
	private String navigateUrl;
	@Column(length = 32)
	private String tableId;
	@Column(length = 32)
	private String variant;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public int getActionOrder() {
		return actionOrder;
	}

	public void setActionOrder(int actionOrder) {
		this.actionOrder = actionOrder;
	}

	public String getActionIcon() {
		if (actionIcon != null)
			return actionIcon.toLowerCase();
		else
			return actionIcon;
	}

	public void setActionIcon(String actionIcon) {
		if (actionIcon != null)
			this.actionIcon = actionIcon.toLowerCase();
		else
			this.actionIcon = actionIcon;
	}

	public String getActionId() {
		return actionId.toUpperCase();
	}

	public void setActionId(String actionId) {
		this.actionId = actionId.toUpperCase();
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public LocalDateTime getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDateTime createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getFormId() {
		return formId.toUpperCase();
	}

	public void setFormId(String formId) {
		this.formId = formId.toUpperCase();
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getNavigateUrl() {
		return navigateUrl;
	}

	public void setNavigateUrl(String navigateUrl) {
		this.navigateUrl = navigateUrl;
	}

	public String getTableId() {
		return tableId;
	}

	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

}
