package com.hmhs.hvwmid.model;

/**
 * Model class for IMIGenerator output data
 * Contains information about the processing status and results for each row
 * Based on the original IMIGeneratorOutput from hvwweb_ear_was_intra project
 */
public class IMIGeneratorOutput {
    private String status = "";
    private String plandDCN = "";
    private String messages = "";
    private String imageLocation = "";
    private String rowNo = "";
    private String imiFileName = "";
    private String dpk = "";

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPlandDCN() {
        return plandDCN;
    }

    public void setPlandDCN(String plandDCN) {
        this.plandDCN = plandDCN;
    }

    public String getMessages() {
        return messages;
    }

    public void setMessages(String messages) {
        this.messages = messages;
    }

    public String getImageLocation() {
        return imageLocation;
    }

    public void setImageLocation(String imageLocation) {
        this.imageLocation = imageLocation;
    }

    public String getRowNo() {
        return rowNo;
    }

    public void setRowNo(String rowNo) {
        this.rowNo = rowNo;
    }

    public String getImiFileName() {
        return imiFileName;
    }

    public void setImiFileName(String imiFileName) {
        this.imiFileName = imiFileName;
    }

    public String getDpk() {
        return dpk;
    }

    public void setDpk(String dpk) {
        this.dpk = dpk;
    }
}
