package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/**
 * Entity representing VPIE141S table.
 * Contains RACF/ACF2 security information for CMOD applications.
 * Used for mapping applications to their RACF entities and role descriptions.
 */
@Entity
@Table(name = "VPIE141S")
public class Vpie141s {

    @Column(name = "APPLICATION", length = 30)
    private String application;
    @Column(name = "ROLE_DESCRIPTION", length = 255)
    private String roleDescription;
    @Id
    @Column(name = "ACF2_RESOURCE", length = 8, nullable = false)
    private String acf2Resource;

    @Column(name = "ACF2_STRING", length = 255)
    private String acf2String;

    @Column(name = "CUSTODIAN", length = 10)
    private String custodian;

    @Column(name = "DATE_MODIFIED")
    private LocalDateTime dateModified;

    @Column(name="GENERAL_TEXT", length = 255)
    private String generalText;

    // Constructors
    public Vpie141s() {
    }

    public Vpie141s(String acf2Resource, String acf2String, String application, 
                   String roleDescription, LocalDateTime dateModified) {
        this.acf2Resource = acf2Resource;
        this.acf2String = acf2String;
        this.application = application;
        this.roleDescription = roleDescription;
        this.dateModified = dateModified;
    }

    // Getters and Setters
    public String getAcf2Resource() {
        return acf2Resource;
    }

    public void setAcf2Resource(String acf2Resource) {
        this.acf2Resource = acf2Resource;
    }

    public String getAcf2String() {
        return acf2String;
    }

    public void setAcf2String(String acf2String) {
        this.acf2String = acf2String;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

    public String getRoleDescription() {
        return roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }

    public LocalDateTime getDateModified() {
        return dateModified;
    }

    public void setDateModified(LocalDateTime dateModified) {
        this.dateModified = dateModified;
    }

    public String getCustodian() {
        return custodian;
    }

    public void setCustodian(String custodian) {
        this.custodian = custodian;
    }

    public String getGeneralText() {
        return generalText;
    }

    public void setGeneralText(String generalText) {
        this.generalText = generalText;
    }
}