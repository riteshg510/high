package com.hmhs.hvwmid.service;

import static com.hmhs.hvwmid.constants.HVWConstants.CMBASE;
import static com.hmhs.hvwmid.constants.HVWConstants.CMOD_PRODUCT_DTS_TRIAGE;
import static com.hmhs.hvwmid.constants.HVWConstants.CMSARA;
import static org.springframework.util.StringUtils.hasText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.CMODApplicationAccessInfo;
import com.hmhs.hvwmid.model.CMODSARAPathInfo;
import com.hmhs.hvwmid.model.CMODSecurityAccessResponse;
import com.hmhs.hvwmid.repository.CMODSecurityRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.repository.T222CodRacfExtEntRepository;

/**
 * Service for CMOD Security Access functionality.
 * Implements business logic for retrieving user's CMOD security permissions and
 * access details.
 */
@Service
public class CMODSecurityService {

    private static final Logger logger = LogManager.getLogger(CMODSecurityService.class);

    // Parameter keys for CMOD security configuration
    private static final String PARAM_CMOD_ACCESS_UI = "CMOD_ACCESS_UI";

    private final T222APRMRepository t222APRMRepository;
    private final CMODSecurityRepository cmodSecurityRepository;
    private final T222CodRacfExtEntRepository racfExtEntRepository;
    private final ImageParmDataService imageParmDataService;

    private final CMODDataRefreshService cmodDataRefreshService;

    public CMODSecurityService(T222APRMRepository t222APRMRepository, CMODSecurityRepository cmodSecurityRepository,
            T222CodRacfExtEntRepository racfExtEntRepository, ImageParmDataService imageParmDataService,
            CMODDataRefreshService cmodDataRefreshService) {
        this.t222APRMRepository = t222APRMRepository;
        this.cmodSecurityRepository = cmodSecurityRepository;
        this.racfExtEntRepository = racfExtEntRepository;
        this.imageParmDataService = imageParmDataService;
        this.cmodDataRefreshService = cmodDataRefreshService;
    }

    /**
     * Retrieves CMOD security access information for the specified user.
     * 
     * @param userId         User ID for security access lookup
     * @param cmodFolderName
     * @return CMODSecurityAccessResponse containing user's folder permissions and
     *         access details
     * @throws HVWException if security access retrieval fails
     */
    public CMODSecurityAccessResponse getCMODSecurityAccess(String userId, String cmodFolderName) {
        logger.info("Retrieving CMOD security access for user: {}", userId);

        try {
            // Validate CMOD Access UI is enabled - IMP
            if (!isCMODAccessUIEnabled()) {
                logger.warn("CMOD Access UI is disabled for user: {}", userId);
                return new CMODSecurityAccessResponse("CMOD Access UI is currently disabled.");
            }

            // Get user's CMOD client codes/groups - IMP
            List<String> userClientCodes = getUserClientCodes(userId.toUpperCase());
            if (userClientCodes.isEmpty()) {
                logger.warn("User {} has no CMOD application access", userId);
                return new CMODSecurityAccessResponse("You do not have access to any CMOD applications.");
            }

            Set<String> userFolders = getUserAccessibleFolders(userClientCodes, cmodFolderName);

            // Get user's AGQR (Application Group Query Role) mappings
            Map<String, List<String>> userAGQRMap = getUserAGQRMappings(userId);

            Map<String, Set<String>> missingRACFMap = new HashMap<>();
            Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = buildFolderAccessMap(userFolders,
                    userAGQRMap, userClientCodes, missingRACFMap);

            // Build SARA path information
            CMODSARAPathInfo saraPathInfo = buildSARAPathInfo();

            // Get triage information
            String triageInfo = getTriageInfo();

            // Build user groups string
            String userGroups = String.join(", ", userClientCodes);

            logger.info("CMOD security access retrieved successfully for user: {}", userId);

            return new CMODSecurityAccessResponse(folderAccessMap, missingRACFMap, saraPathInfo, userGroups,
                    triageInfo);

        } catch (Exception e) {
            logger.error("Error retrieving CMOD security access for user: {}", userId, e);
            throw new HVWException(500, "Failed to retrieve CMOD security access: " + e.getMessage(),
                    "CMODSecurityService");
        }
    }

    /**
     * Checks if CMOD Access UI is enabled via configuration parameter.
     */
    private boolean isCMODAccessUIEnabled() {
        try {
            String access = imageParmDataService.getParmDataByKeyByCmodbase(PARAM_CMOD_ACCESS_UI, "Y");
            return access.equalsIgnoreCase("Y");
        } catch (Exception e) {
            logger.warn("Error checking CMOD Access UI configuration", e);
            return false;
        }
    }

    /**
     * Retrieves user's CMOD client codes/groups from database.
     */
    private List<String> getUserClientCodes(String userId) {
        try {
            // Get client codes from RACF entity table using the new repository
            List<String> racfClientCodes = racfExtEntRepository.getUserClientCodes(userId)
                    .stream()
                    .map(String::trim)
                    .filter(code -> !code.isEmpty())
                    .collect(Collectors.toList());

            Set<String> validClientCodes = cmodDataRefreshService.getCMODClientCodes();
            // Cross-reference with CMOD client codes from XML data (validClientCodes)
            // return only ones racfClientCodes found in validClientCodes
            return racfClientCodes.stream().filter(validClientCodes::contains).collect(Collectors.toList());

        } catch (Exception e) {
            logger.error("Error retrieving user client codes for user: {}", userId, e);
            return new ArrayList<>();
        }
    }

    /**
     * Gets folders accessible to user based on client codes.
     * listFoldersBasedOnClntCd in old implementation
     */
    private Set<String> getUserAccessibleFolders(List<String> grpCodeList, String folderName) {
        Set<String> userFoldetSet = new TreeSet<>();

        if (hasText(folderName)) {
            Map<String, Set<String>> appGrpMap = cmodDataRefreshService.getCMODFolderDetails(folderName);
            populateUserFolderSet(appGrpMap, grpCodeList, userFoldetSet, folderName);
        } else {
            Map<String, Map<String, Set<String>>> cmodFolders = cmodDataRefreshService.getAllCMODFolderDetails();
            for (Map.Entry<String, Map<String, Set<String>>> folderDet : cmodFolders.entrySet()) {
                Map<String, Set<String>> appGrpMap = folderDet.getValue();
                populateUserFolderSet(appGrpMap, grpCodeList, userFoldetSet, folderDet.getKey());
            }
        }
        return userFoldetSet;
    }

    /**
     * This method will populate the Folders which the user has access in the Set
     *
     * @param appGrpMap
     * @param grpCodeList
     * @param userFoldetSet
     * @param folderName
     */
    private void populateUserFolderSet(Map<String, Set<String>> appGrpMap, List<String> grpCodeList,
            Set<String> userFoldetSet, String folderName) {
        if (appGrpMap != null) {
            for (Map.Entry<String, Set<String>> applicationMap : appGrpMap.entrySet()) {
                Set<String> applications = applicationMap.getValue();
                for (String application : applications) {
                    String[] tokens = StringUtils.split(application, '-');
                    if (tokens.length > 2) {
                        String clientCode = tokens[1];
                        if (grpCodeList.contains(clientCode)) {
                            userFoldetSet.add(folderName);
                        }
                    }
                }
            }
        }
    }

    /**
     * Gets user's AGQR mappings from database.
     */
    private Map<String, List<String>> getUserAGQRMappings(String userId) {
        try {
            Map<String, List<String>> userAGQRMappings = cmodSecurityRepository.getUserAGQRMappings(userId);
            logger.debug("CMOD security access retrieved {} entries for user: {}", userAGQRMappings.size(), userId);
            return userAGQRMappings;
        } catch (Exception e) {
            logger.error("Error retrieving user AGQR mappings for user: {}", userId, e);
            return new HashMap<>();
        }
    }

    /**
     * Builds folder access map with application access information.
     * (populateCMODSARADetails)
     */
    private Map<String, Map<String, CMODApplicationAccessInfo>> buildFolderAccessMap(
            Set<String> userFolders,
            Map<String, List<String>> userAGQRMap,
            List<String> grpCodeList,
            Map<String, Set<String>> missingRACFMap) {

        Map<String, Map<String, String>> securedClientEmpSec = imageParmDataService.getSecuredClntEmpSecMap();
        Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = new HashMap<>();

        for (String folder : userFolders) {
            Map<String, CMODApplicationAccessInfo> odApplicationsMap = new TreeMap<>();
            Set<String> missingRACFSet = new TreeSet<>();
            try {
                // Get applications for this folder
                Map<String, Set<String>> appGrpMap = cmodDataRefreshService.getCMODFolderDetails(folder);
                if (appGrpMap != null) {
                    for (Map.Entry<String, Set<String>> applicationMap : appGrpMap.entrySet()) {
                        String applicationGroup = applicationMap.getKey();
                        Set<String> applications = applicationMap.getValue();
                        for (String application : applications) {
                            String[] tokens = StringUtils.split(application, '-');
                            if (tokens.length > 2) {
                                String clientCode = tokens[1];
                                if (grpCodeList.contains(clientCode)) {
                                    // Remove the version from the application name
                                    int lastIndex = application.lastIndexOf('-');
                                    String cmodApplicationName = null;
                                    if (lastIndex > -1) {
                                        cmodApplicationName = application.substring(0, application.lastIndexOf('-'));
                                    } else {
                                        logger.warn(
                                                "populateCMODSARADetails: CMOD application {} doesn't follow the naming convention",
                                                application);
                                        continue;
                                    }

                                    CMODApplicationAccessInfo odApp = cmodDataRefreshService
                                            .getRACFEntityForApplication(application);
                                    String acf2 = odApp.getAcf2String();
                                    if (!hasText(acf2)) {
                                        missingRACFSet.add(application);
                                        continue;
                                    }

                                    // Check if the entry need to be added to the same group or different group
                                    boolean isGroupedTogether = false;
                                    if (odApplicationsMap.containsKey(acf2)) {
                                        CMODApplicationAccessInfo odApplication = odApplicationsMap.get(acf2);
                                        boolean clientEmpSec = odApplication.isClientEmployeeSecurity();
                                        boolean curClientEmpSec = false;
                                        // Get client employee security for the current application that is in the loop
                                        if (securedClientEmpSec.containsKey(cmodApplicationName)) {
                                            curClientEmpSec = true;
                                        }
                                        if (clientEmpSec == curClientEmpSec) {
                                            isGroupedTogether = true;
                                        }
                                    }

                                    if (isGroupedTogether) {
                                        CMODApplicationAccessInfo odApplication = odApplicationsMap.get(acf2);
                                        Set<String> applicationVerSet = odApplication.getApplicationVersions();
                                        applicationVerSet.add(application);
                                    } else {
                                        CMODApplicationAccessInfo odApplication = new CMODApplicationAccessInfo();
                                        odApplication.setApplicationName(cmodApplicationName);
                                        odApplication.setUserAccess(false);
                                        odApplication.setAcf2String(acf2);
                                        odApplication.setVpieApplication(odApp.getVpieApplication());
                                        odApplication.setVpieRoleDescription(odApp.getVpieRoleDescription());
                                        odApplication.setClientEmployeeSecurity(false);
                                        // Check if the user has access to the application
                                        if (userAGQRMap.containsKey(applicationGroup)) {
                                            List<String> userAppList = userAGQRMap.get(applicationGroup);
                                            if (userAppList.contains(application)) {
                                                odApplication.setUserAccess(true);
                                            }
                                        }
                                        // Check if the application has client employee security
                                        if (securedClientEmpSec.containsKey(cmodApplicationName)) {
                                            odApplication.setClientEmployeeSecurity(true);
                                        }
                                        Set<String> applicationVerSet = new TreeSet<>();
                                        applicationVerSet.add(application);
                                        odApplication.setApplicationVersions(applicationVerSet);
                                        odApplicationsMap.put(acf2, odApplication);
                                    }

                                }
                            }
                        }
                    }
                }
                folderAccessMap.put(folder, odApplicationsMap);

            } catch (Exception e) {
                logger.error("Error building access map for folder: {}", folder, e);
                // Continue with other folders
            }

            if (!missingRACFSet.isEmpty()) {
                missingRACFMap.put(folder, missingRACFSet);
            }
        }

        return folderAccessMap;
    }

    /**
     * Builds SARA path information from configuration parameters.
     */
    private CMODSARAPathInfo buildSARAPathInfo() {
        try {
            // Get root SARA path
            String rootPath = imageParmDataService.getParmDataByKeyByCmodbase(CMBASE, "");

            Map<String, String> saraPathMap = imageParmDataService.getParmDataMap(CMSARA);

            // Separate Highview and Reno paths
            Map<String, String> highviewPaths = new HashMap<>();
            Map<String, String> renoPaths = new HashMap<>();

            if (saraPathMap != null) {
                for (Map.Entry<String, String> entry : saraPathMap.entrySet()) {
                    if (entry.getKey().toLowerCase().contains("reno")) {
                        renoPaths.put(entry.getKey(), entry.getValue());
                    } else {
                        highviewPaths.put(entry.getKey(), entry.getValue());
                    }
                }
            }

            return new CMODSARAPathInfo(rootPath, highviewPaths, renoPaths);

        } catch (Exception e) {
            logger.error("Error building SARA path information", e);
            return new CMODSARAPathInfo();
        }
    }

    /**
     * Gets triage information from configuration parameters.
     */
    private String getTriageInfo() {
        try {
            return imageParmDataService.getParmDataByKeyByCmodbase(CMOD_PRODUCT_DTS_TRIAGE, "");
        } catch (Exception e) {
            logger.error("Error retrieving triage information", e);
            return "";
        }
    }

    /**
     * Helper method to get parameter value from T222APRM table.
     * 
     * private String getParameterValue(String paramKey) {
     * try {
     * List<T222APRM> paramRecords =
     * t222APRMRepository.findByParmIdAndParmData(paramKey);
     * if (!paramRecords.isEmpty()) {
     * return paramRecords.get(0).getParmData();
     * }
     * } catch (Exception e) {
     * logger.error("Error retrieving parameter value for key: {}", paramKey, e);
     * }
     * return "";
     * }
     */
}