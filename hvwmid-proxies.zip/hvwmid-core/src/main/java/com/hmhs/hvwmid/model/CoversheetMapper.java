package com.hmhs.hvwmid.model;

import com.hmhs.hvwmid.entity.T117ImgCoverAppl;
import com.hmhs.hvwmid.entity.T117ImgCoverSheet;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetOverride;

public class CoversheetMapper {

    public static CoverSheetDTO toDTO(T117ImgCoverSheet e) {
        CoverSheetDTO dto = new CoverSheetDTO();
        dto.setApplication(e.getApplication());
        dto.setName(e.getName());
        dto.setDescription(e.getDescription());
        dto.setSb1(e.getSb1());
        dto.setEb1(e.getEb1());
        dto.setEb2(e.getEb2());
        dto.setEb3(e.getEb3());
        dto.setTitle(e.getTitle());
        dto.setStitle1(e.getStitle1());
        dto.setStitle2(e.getStitle2());
        dto.setUnit(e.getUnit());
        dto.setRcode(e.getRcode());
        dto.setTemplate(e.getTemplate());
        dto.setActive(e.getActive());
        dto.setEnvironment(e.getEnvironment());
        return dto;
    }

    public static T117ImgCoverSheet toEntity(CoverSheetDTO d) {
        T117ImgCoverSheet e = new T117ImgCoverSheet();
        e.setApplication(d.getApplication());
        e.setName(d.getName());
        e.setDescription(d.getDescription());
        e.setSb1(d.getSb1());
        e.setEb1(d.getEb1());
        e.setEb2(d.getEb2());
        e.setEb3(d.getEb3());
        e.setTitle(d.getTitle());
        e.setStitle1(d.getStitle1());
        e.setStitle2(d.getStitle2());
        e.setUnit(d.getUnit());
        e.setRcode(d.getRcode());
        e.setTemplate(d.getTemplate());
        e.setActive(d.getActive());
        e.setEnvironment(d.getEnvironment());
        return e;
    }

    public static CoverSheetOverrideDTO toDTO(T117ImgCoverSheetOverride e) {
        CoverSheetOverrideDTO d = new CoverSheetOverrideDTO();
        d.setApplication(e.getApplication());
        d.setName(e.getName());
        d.setSequence(e.getSequence());
        d.setDescription(e.getDescription());
        d.setSb1(e.getSb1());
        d.setEb1(e.getEb1());
        d.setEb2(e.getEb2());
        d.setEb3(e.getEb3());
        d.setTitle(e.getTitle());
        d.setStitle1(e.getStitle1());
        d.setStitle2(e.getStitle2());
        d.setUnit(e.getUnit());
        d.setRcode(e.getRcode());
        d.setTemplate(e.getTemplate());
        d.setActive(e.getActive());
        d.setEnvironment(e.getEnvironment());
        return d;
    }

    public static T117ImgCoverSheetOverride toEntity(CoverSheetOverrideDTO d) {
        T117ImgCoverSheetOverride e = new T117ImgCoverSheetOverride();
        e.setApplication(d.getApplication());
        e.setName(d.getName());
        e.setSequence(d.getSequence());
        e.setDescription(d.getDescription());
        e.setSb1(d.getSb1());
        e.setEb1(d.getEb1());
        e.setEb2(d.getEb2());
        e.setEb3(d.getEb3());
        e.setTitle(d.getTitle());
        e.setStitle1(d.getStitle1());
        e.setStitle2(d.getStitle2());
        e.setUnit(d.getUnit());
        e.setRcode(d.getRcode());
        e.setTemplate(d.getTemplate());
        e.setActive(d.getActive());
        e.setEnvironment(d.getEnvironment());
        return e;
    }

    public static CoverSheetApplicationDTO toDTO(T117ImgCoverAppl e) {
        CoverSheetApplicationDTO d = new CoverSheetApplicationDTO();
        d.setApplication(e.getApplication());
        d.setDescription(e.getDescription());
        d.setSequence(e.getSequence());
        d.setDeptId(e.getDepartment());
        d.setActive(e.getActive());
        d.setApplId(e.getApplId());
        return d;
    }

    public static T117ImgCoverAppl toEntity(CoverSheetApplicationDTO d) {
        T117ImgCoverAppl e = new T117ImgCoverAppl();
        e.setApplication(d.getApplication());
        e.setDescription(d.getDescription());
        e.setSequence(d.getSequence());
        e.setDepartment(d.getDeptId());
        e.setActive(d.getActive());
        e.setApplId(d.getApplId());
        return e;
    }

}
