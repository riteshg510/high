package com.hmhs.hvwmid.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IMISearchRequest {

	@JsonProperty("naicCode")
	private String naicCode;
	
	@JsonProperty("transmitTimestampFrom")
	private String transmitTimestampFrom;
	
	@JsonProperty("transmitTimestampTo")
	private String transmitTimestampTo;
	
	@JsonProperty("transmitFileIdQuery")
	private long transmitFileIdQuery;
	
	@JsonProperty("transmitFileIdDisplay")
	private boolean transmitFileIdDisplay;
	
	@JsonProperty("transmitFileNameQuery")
	private String transmitFileNameQuery;
	
	@JsonProperty("transmitFileNameSearchOperator")
	private String transmitFileNameSearchOperator;
	
	@JsonProperty("transmitFileNameDisplay")
	private boolean transmitFileNameDisplay;
	
	@JsonProperty("transmitFileStatusCdQuery")
	private String transmitFileStatusCdQuery;
	
	@JsonProperty("transmitFileStatusCdSearchOperator")
	private String transmitFileStatusCdSearchOperator;
	
	@JsonProperty("transmitFileStatusCdDisplay")
	private boolean transmitFileStatusCdDisplay;
	
	@JsonProperty("imiFileIdQuery")
	private long imiFileIdQuery;
	
	@JsonProperty("imiFileIdDisplay")
	private boolean imiFileIdDisplay;
	
	@JsonProperty("planFileIdQuery")
	private String planFileIdQuery;
	
	@JsonProperty("planFileIdSearchOperator")
	private String planFileIdSearchOperator;
	
	@JsonProperty("planFileIdDisplay")
	private boolean planFileIdDisplay;
	
	@JsonProperty("processFileNameQuery")
	private String processFileNameQuery;
	
	@JsonProperty("processFileNameSearchOperator")
	private String processFileNameSearchOperator;
	
	@JsonProperty("processFileNameDisplay")
	private boolean processFileNameDisplay;
	
	@JsonProperty("processFileStatusCdQuery")
	private String processFileStatusCdQuery;
	
	@JsonProperty("processFileStatusCdSearchOperator")
	private String processFileStatusCdSearchOperator;
	
	@JsonProperty("processFileStatusCdDisplay")
	private boolean processFileStatusCdDisplay;
	
	@JsonProperty("processFileReasonCdQuery")
	private String processFileReasonCdQuery;
	
	@JsonProperty("processFileReasonCdSearchOperator")
	private String processFileReasonCdSearchOperator;
	
	@JsonProperty("processFileReasonCdDisplay")
	private boolean processFileReasonCdDisplay;
	
	@JsonProperty("timeAckQuery")
	private String timeAckQuery;
	
	@JsonProperty("timeAckSearchOperator")
	private String timeAckSearchOperator;
	
	@JsonProperty("timeAckDisplay")
	private boolean timeAckDisplay;
	
	@JsonProperty("imiDocumentIdQuery")
	private long imiDocumentIdQuery;
	
	@JsonProperty("imiDocumentIdDisplay")
	private boolean imiDocumentIdDisplay;
	
	@JsonProperty("planDCNQuery")
	private String planDCNQuery;
	
	@JsonProperty("planDCNSearchOperator")
	private String planDCNSearchOperator;
	
	@JsonProperty("planDCNDisplay")
	private boolean planDCNDisplay;
	
	@JsonProperty("dpkQuery")
	private String dpkQuery;
	
	@JsonProperty("dpkSearchOperator")
	private String dpkSearchOperator;
	
	@JsonProperty("dpkDisplay")
	private boolean dpkDisplay;
	
	@JsonProperty("initialProcessDCNQuery")
	private String initialProcessDCNQuery;
	
	@JsonProperty("initialProcessDCNSearchOperator")
	private String initialProcessDCNSearchOperator;
	
	@JsonProperty("initialProcessDCNDisplay")
	private boolean initialProcessDCNDisplay;
	
	@JsonProperty("finalProcessDCNQuery")
	private String finalProcessDCNQuery;
	
	@JsonProperty("finalProcessDCNSearchOperator")
	private String finalProcessDCNSearchOperator;
	
	@JsonProperty("finalProcessDCNDisplay")
	private boolean finalProcessDCNDisplay;
	
	@JsonProperty("documentStatusCdQuery")
	private String documentStatusCdQuery;
	
	@JsonProperty("documentStatusCdSearchOperator")
	private String documentStatusCdSearchOperator;
	
	@JsonProperty("documentStatusCdDisplay")
	private boolean documentStatusCdDisplay;
	
	@JsonProperty("documentReasonCdQuery")
	private String documentReasonCdQuery;
	
	@JsonProperty("documentReasonCdSearchOperator")
	private String documentReasonCdSearchOperator;
	
	@JsonProperty("documentReasonCdDisplay")
	private boolean documentReasonCdDisplay;
	
	@JsonProperty("timeUpdateQuery")
	private String timeUpdateQuery;
	
	@JsonProperty("timeUpdateSearchOperator")
	private String timeUpdateSearchOperator;
	
	@JsonProperty("timeUpdateDisplay")
	private boolean timeUpdateDisplay;
	
	@JsonProperty("applIdCdQuery")
	private List<Integer> applIdCdQuery;
	
	@JsonProperty("applIdCdDisplay")
	private boolean applIdCdDisplay;
	
	@JsonProperty("captureItemIdQuery")
	private String captureItemIdQuery;
	
	@JsonProperty("captureItemIdDisplay")
	private boolean captureItemIdDisplay;
	
	@JsonProperty("resultSetPointer")
	private long resultSetPointer = 0;
	
	@JsonProperty("paginationOn")
	private boolean paginationOn = true;
	
	@JsonProperty("paginationRowCount")
	private long paginationRowCount = 250;
	
	@JsonProperty("searchById")
	private boolean searchById;

	public String getTransmitTimestampFrom() {
		return transmitTimestampFrom;
	}

	public void setTransmitTimestampFrom(String transmitTimestampFrom) {
		this.transmitTimestampFrom = transmitTimestampFrom;
	}

	public String getTransmitTimestampTo() {
		return transmitTimestampTo;
	}

	public void setTransmitTimestampTo(String transmitTimestampTo) {
		this.transmitTimestampTo = transmitTimestampTo;
	}

	public String getNaicCode() {
		return naicCode;
	}

	public void setNaicCode(String naicCode) {
		this.naicCode = naicCode;
	}

	public long getTransmitFileIdQuery() {
		return transmitFileIdQuery;
	}

	public void setTransmitFileIdQuery(long transmitFileIdQuery) {
		this.transmitFileIdQuery = transmitFileIdQuery;
	}

	public boolean isTransmitFileIdDisplay() {
		return transmitFileIdDisplay;
	}

	public void setTransmitFileIdDisplay(boolean transmitFileIdDisplay) {
		this.transmitFileIdDisplay = transmitFileIdDisplay;
	}

	public String getTransmitFileNameQuery() {
		return transmitFileNameQuery;
	}

	public void setTransmitFileNameQuery(String transmitFileNameQuery) {
		this.transmitFileNameQuery = transmitFileNameQuery;
	}

	public boolean isTransmitFileNameDisplay() {
		return transmitFileNameDisplay;
	}

	public void setTransmitFileNameDisplay(boolean transmitFileNameDisplay) {
		this.transmitFileNameDisplay = transmitFileNameDisplay;
	}

	public String getTransmitFileStatusCdQuery() {
		return transmitFileStatusCdQuery;
	}

	public void setTransmitFileStatusCdQuery(String transmitFileStatusCdQuery) {
		this.transmitFileStatusCdQuery = transmitFileStatusCdQuery;
	}

	public boolean isTransmitFileStatusCdDisplay() {
		return transmitFileStatusCdDisplay;
	}

	public void setTransmitFileStatusCdDisplay(boolean transmitFileStatusCdDisplay) {
		this.transmitFileStatusCdDisplay = transmitFileStatusCdDisplay;
	}

	public long getImiFileIdQuery() {
		return imiFileIdQuery;
	}

	public void setImiFileIdQuery(long imiFileIdQuery) {
		this.imiFileIdQuery = imiFileIdQuery;
	}

	public boolean isImiFileIdDisplay() {
		return imiFileIdDisplay;
	}

	public void setImiFileIdDisplay(boolean imiFileIdDisplay) {
		this.imiFileIdDisplay = imiFileIdDisplay;
	}

	public String getPlanFileIdQuery() {
		return planFileIdQuery;
	}

	public void setPlanFileIdQuery(String planFileIdQuery) {
		this.planFileIdQuery = planFileIdQuery;
	}

	public boolean isPlanFileIdDisplay() {
		return planFileIdDisplay;
	}

	public void setPlanFileIdDisplay(boolean planFileIdDisplay) {
		this.planFileIdDisplay = planFileIdDisplay;
	}

	public String getProcessFileNameQuery() {
		return processFileNameQuery;
	}

	public void setProcessFileNameQuery(String processFileNameQuery) {
		this.processFileNameQuery = processFileNameQuery;
	}

	public boolean isProcessFileNameDisplay() {
		return processFileNameDisplay;
	}

	public void setProcessFileNameDisplay(boolean processFileNameDisplay) {
		this.processFileNameDisplay = processFileNameDisplay;
	}

	public String getProcessFileStatusCdQuery() {
		return processFileStatusCdQuery;
	}

	public void setProcessFileStatusCdQuery(String processFileStatusCdQuery) {
		this.processFileStatusCdQuery = processFileStatusCdQuery;
	}

	public boolean isProcessFileStatusCdDisplay() {
		return processFileStatusCdDisplay;
	}

	public void setProcessFileStatusCdDisplay(boolean processFileStatusCdDisplay) {
		this.processFileStatusCdDisplay = processFileStatusCdDisplay;
	}

	

	public String getProcessFileReasonCdQuery() {
		return processFileReasonCdQuery;
	}

	public void setProcessFileReasonCdQuery(String processFileReasonCdQuery) {
		this.processFileReasonCdQuery = processFileReasonCdQuery;
	}

	public String getProcessFileReasonCdSearchOperator() {
		return processFileReasonCdSearchOperator;
	}

	public void setProcessFileReasonCdSearchOperator(String processFileReasonCdSearchOperator) {
		this.processFileReasonCdSearchOperator = processFileReasonCdSearchOperator;
	}

	public boolean isProcessFileReasonCdDisplay() {
		return processFileReasonCdDisplay;
	}

	public void setProcessFileReasonCdDisplay(boolean processFileReasonCdDisplay) {
		this.processFileReasonCdDisplay = processFileReasonCdDisplay;
	}

	public String getTimeAckQuery() {
		return timeAckQuery;
	}

	public void setTimeAckQuery(String timeAckQuery) {
		this.timeAckQuery = timeAckQuery;
	}

	public String getTimeAckSearchOperator() {
		return timeAckSearchOperator;
	}

	public void setTimeAckSearchOperator(String timeAckSearchOperator) {
		this.timeAckSearchOperator = timeAckSearchOperator;
	}

	public boolean isTimeAckDisplay() {
		return timeAckDisplay;
	}

	public void setTimeAckDisplay(boolean timeAckDisplay) {
		this.timeAckDisplay = timeAckDisplay;
	}

	public long getImiDocumentIdQuery() {
		return imiDocumentIdQuery;
	}

	public void setImiDocumentIdQuery(long imiDocumentIdQuery) {
		this.imiDocumentIdQuery = imiDocumentIdQuery;
	}

	public boolean isImiDocumentIdDisplay() {
		return imiDocumentIdDisplay;
	}

	public void setImiDocumentIdDisplay(boolean imiDocumentIdDisplay) {
		this.imiDocumentIdDisplay = imiDocumentIdDisplay;
	}

	public String getPlanDCNQuery() {
		return planDCNQuery;
	}

	public void setPlanDCNQuery(String planDCNQuery) {
		this.planDCNQuery = planDCNQuery;
	}

	public boolean isPlanDCNDisplay() {
		return planDCNDisplay;
	}

	public void setPlanDCNDisplay(boolean planDCNDisplay) {
		this.planDCNDisplay = planDCNDisplay;
	}

	public String getDpkQuery() {
		return dpkQuery;
	}

	public void setDpkQuery(String dpkQuery) {
		this.dpkQuery = dpkQuery;
	}

	public boolean isDpkDisplay() {
		return dpkDisplay;
	}

	public void setDpkDisplay(boolean dpkDisplay) {
		this.dpkDisplay = dpkDisplay;
	}

	public String getInitialProcessDCNQuery() {
		return initialProcessDCNQuery;
	}

	public void setInitialProcessDCNQuery(String initialProcessDCNQuery) {
		this.initialProcessDCNQuery = initialProcessDCNQuery;
	}

	public boolean isInitialProcessDCNDisplay() {
		return initialProcessDCNDisplay;
	}

	public void setInitialProcessDCNDisplay(boolean initialProcessDCNDisplay) {
		this.initialProcessDCNDisplay = initialProcessDCNDisplay;
	}

	public String getFinalProcessDCNQuery() {
		return finalProcessDCNQuery;
	}

	public void setFinalProcessDCNQuery(String finalProcessDCNQuery) {
		this.finalProcessDCNQuery = finalProcessDCNQuery;
	}

	public boolean isFinalProcessDCNDisplay() {
		return finalProcessDCNDisplay;
	}

	public void setFinalProcessDCNDisplay(boolean finalProcessDCNDisplay) {
		this.finalProcessDCNDisplay = finalProcessDCNDisplay;
	}

	public String getDocumentStatusCdQuery() {
		return documentStatusCdQuery;
	}

	public void setDocumentStatusCdQuery(String documentStatusCdQuery) {
		this.documentStatusCdQuery = documentStatusCdQuery;
	}

	public boolean isDocumentStatusCdDisplay() {
		return documentStatusCdDisplay;
	}

	public void setDocumentStatusCdDisplay(boolean documentStatusCdDisplay) {
		this.documentStatusCdDisplay = documentStatusCdDisplay;
	}

	public String getDocumentReasonCdQuery() {
		return documentReasonCdQuery;
	}

	public void setDocumentReasonCdQuery(String documentReasonCdQuery) {
		this.documentReasonCdQuery = documentReasonCdQuery;
	}

	public String getDocumentReasonCdSearchOperator() {
		return documentReasonCdSearchOperator;
	}

	public void setDocumentReasonCdSearchOperator(String documentReasonCdSearchOperator) {
		this.documentReasonCdSearchOperator = documentReasonCdSearchOperator;
	}

	public boolean isDocumentReasonCdDisplay() {
		return documentReasonCdDisplay;
	}

	public void setDocumentReasonCdDisplay(boolean documentReasonCdDisplay) {
		this.documentReasonCdDisplay = documentReasonCdDisplay;
	}

	public List<Integer> getApplIdCdQuery() {
		return applIdCdQuery;
	}

	public void setApplIdCdQuery(List<Integer> applIdCdQuery) {
		this.applIdCdQuery = applIdCdQuery;
	}

	public boolean isApplIdCdDisplay() {
		return applIdCdDisplay;
	}

	public void setApplIdCdDisplay(boolean applIdCdDisplay) {
		this.applIdCdDisplay = applIdCdDisplay;
	}

	public String getCaptureItemIdQuery() {
		return captureItemIdQuery;
	}

	public void setCaptureItemIdQuery(String captureItemIdQuery) {
		this.captureItemIdQuery = captureItemIdQuery;
	}

	public boolean isCaptureItemIdDisplay() {
		return captureItemIdDisplay;
	}

	public void setCaptureItemIdDisplay(boolean captureItemIdDisplay) {
		this.captureItemIdDisplay = captureItemIdDisplay;
	}

	public long getResultSetPointer() {
		return resultSetPointer;
	}

	public void setResultSetPointer(long resultSetPointer) {
		this.resultSetPointer = resultSetPointer;
	}

	public boolean isPaginationOn() {
		return paginationOn;
	}

	public void setPaginationOn(boolean paginationOn) {
		this.paginationOn = paginationOn;
	}

	public String getTransmitFileNameSearchOperator() {
		return transmitFileNameSearchOperator;
	}

	public void setTransmitFileNameSearchOperator(String transmitFileNameSearchOperator) {
		this.transmitFileNameSearchOperator = transmitFileNameSearchOperator;
	}

	public String getTransmitFileStatusCdSearchOperator() {
		return transmitFileStatusCdSearchOperator;
	}

	public void setTransmitFileStatusCdSearchOperator(String transmitFileStatusCdSearchOperator) {
		this.transmitFileStatusCdSearchOperator = transmitFileStatusCdSearchOperator;
	}

	public String getPlanFileIdSearchOperator() {
		return planFileIdSearchOperator;
	}

	public void setPlanFileIdSearchOperator(String planFileIdSearchOperator) {
		this.planFileIdSearchOperator = planFileIdSearchOperator;
	}

	public String getProcessFileNameSearchOperator() {
		return processFileNameSearchOperator;
	}

	public void setProcessFileNameSearchOperator(String processFileNameSearchOperator) {
		this.processFileNameSearchOperator = processFileNameSearchOperator;
	}

	public String getProcessFileStatusCdSearchOperator() {
		return processFileStatusCdSearchOperator;
	}

	public void setProcessFileStatusCdSearchOperator(String processFileStatusCdSearchOperator) {
		this.processFileStatusCdSearchOperator = processFileStatusCdSearchOperator;
	}

	public String getPlanDCNSearchOperator() {
		return planDCNSearchOperator;
	}

	public void setPlanDCNSearchOperator(String planDCNSearchOperator) {
		this.planDCNSearchOperator = planDCNSearchOperator;
	}

	public String getDpkSearchOperator() {
		return dpkSearchOperator;
	}

	public void setDpkSearchOperator(String dpkSearchOperator) {
		this.dpkSearchOperator = dpkSearchOperator;
	}

	public String getInitialProcessDCNSearchOperator() {
		return initialProcessDCNSearchOperator;
	}

	public void setInitialProcessDCNSearchOperator(String initialProcessDCNSearchOperator) {
		this.initialProcessDCNSearchOperator = initialProcessDCNSearchOperator;
	}

	public String getFinalProcessDCNSearchOperator() {
		return finalProcessDCNSearchOperator;
	}

	public void setFinalProcessDCNSearchOperator(String finalProcessDCNSearchOperator) {
		this.finalProcessDCNSearchOperator = finalProcessDCNSearchOperator;
	}

	public String getDocumentStatusCdSearchOperator() {
		return documentStatusCdSearchOperator;
	}

	public void setDocumentStatusCdSearchOperator(String documentStatusCdSearchOperator) {
		this.documentStatusCdSearchOperator = documentStatusCdSearchOperator;
	}

	public long getPaginationRowCount() {
		return paginationRowCount;
	}

	public void setPaginationRowCount(long paginationRowCount) {
		this.paginationRowCount = paginationRowCount;
	}

	public boolean isSearchById() {
		return searchById;
	}

	public void setSearchById(boolean searchById) {
		this.searchById = searchById;
	}

	public String getTimeUpdateQuery() {
		return timeUpdateQuery;
	}

	public void setTimeUpdateQuery(String timeUpdateQuery) {
		this.timeUpdateQuery = timeUpdateQuery;
	}

	public String getTimeUpdateSearchOperator() {
		return timeUpdateSearchOperator;
	}

	public void setTimeUpdateSearchOperator(String timeUpdateSearchOperator) {
		this.timeUpdateSearchOperator = timeUpdateSearchOperator;
	}

	public boolean isTimeUpdateDisplay() {
		return timeUpdateDisplay;
	}

	public void setTimeUpdateDisplay(boolean timeUpdateDisplay) {
		this.timeUpdateDisplay = timeUpdateDisplay;
	}

	@Override
	public String toString() {
		return "IMISearchRequest [naicCode=" + naicCode + ", transmitTimestampFrom=" + transmitTimestampFrom
				+ ", transmitTimestampTo=" + transmitTimestampTo + ", transmitFileIdQuery=" + transmitFileIdQuery
				+ ", transmitFileIdDisplay=" + transmitFileIdDisplay + ", transmitFileNameQuery="
				+ transmitFileNameQuery + ", transmitFileNameSearchOperator=" + transmitFileNameSearchOperator
				+ ", transmitFileNameDisplay=" + transmitFileNameDisplay + ", transmitFileStatusCdQuery="
				+ transmitFileStatusCdQuery + ", transmitFileStatusCdSearchOperator="
				+ transmitFileStatusCdSearchOperator + ", transmitFileStatusCdDisplay=" + transmitFileStatusCdDisplay
				+ ", imiFileIdQuery=" + imiFileIdQuery + ", imiFileIdDisplay=" + imiFileIdDisplay + ", planFileIdQuery="
				+ planFileIdQuery + ", planFileIdSearchOperator=" + planFileIdSearchOperator + ", planFileIdDisplay="
				+ planFileIdDisplay + ", processFileNameQuery=" + processFileNameQuery
				+ ", processFileNameSearchOperator=" + processFileNameSearchOperator + ", processFileNameDisplay="
				+ processFileNameDisplay + ", processFileStatusCdQuery=" + processFileStatusCdQuery
				+ ", processFileStatusCdSearchOperator=" + processFileStatusCdSearchOperator
				+ ", processFileStatusCdDisplay=" + processFileStatusCdDisplay + ", processFileReasonCdQuery="
				+ processFileReasonCdQuery + ", processFileReasonCdSearchOperator=" + processFileReasonCdSearchOperator
				+ ", processFileReasonCdDisplay=" + processFileReasonCdDisplay + ", timeAckQuery=" + timeAckQuery
				+ ", timeAckSearchOperator=" + timeAckSearchOperator + ", timeAckDisplay=" + timeAckDisplay
				+ ", imiDocumentIdQuery=" + imiDocumentIdQuery + ", imiDocumentIdDisplay=" + imiDocumentIdDisplay
				+ ", planDCNQuery=" + planDCNQuery + ", planDCNSearchOperator=" + planDCNSearchOperator
				+ ", planDCNDisplay=" + planDCNDisplay + ", dpkQuery=" + dpkQuery + ", dpkSearchOperator="
				+ dpkSearchOperator + ", dpkDisplay=" + dpkDisplay + ", initialProcessDCNQuery="
				+ initialProcessDCNQuery + ", initialProcessDCNSearchOperator=" + initialProcessDCNSearchOperator
				+ ", initialProcessDCNDisplay=" + initialProcessDCNDisplay + ", finalProcessDCNQuery="
				+ finalProcessDCNQuery + ", finalProcessDCNSearchOperator=" + finalProcessDCNSearchOperator
				+ ", finalProcessDCNDisplay=" + finalProcessDCNDisplay + ", documentStatusCdQuery="
				+ documentStatusCdQuery + ", documentStatusCdSearchOperator=" + documentStatusCdSearchOperator
				+ ", documentStatusCdDisplay=" + documentStatusCdDisplay + ", documentReasonCdQuery="
				+ documentReasonCdQuery + ", documentReasonCdSearchOperator=" + documentReasonCdSearchOperator
				+ ", documentReasonCdDisplay=" + documentReasonCdDisplay + ", timeUpdateQuery=" + timeUpdateQuery
				+ ", timeUpdateSearchOperator=" + timeUpdateSearchOperator + ", timeUpdateDisplay=" + timeUpdateDisplay
				+ ", applIdCdQuery=" + applIdCdQuery + ", applIdCdDisplay=" + applIdCdDisplay + ", captureItemIdQuery="
				+ captureItemIdQuery + ", captureItemIdDisplay=" + captureItemIdDisplay + ", resultSetPointer="
				+ resultSetPointer + ", paginationOn=" + paginationOn + ", paginationRowCount=" + paginationRowCount
				+ ", searchById=" + searchById + "]";
	}
	
	

}
