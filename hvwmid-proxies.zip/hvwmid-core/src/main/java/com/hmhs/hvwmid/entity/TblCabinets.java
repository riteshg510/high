package com.hmhs.hvwmid.entity;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

/**
 * @author Ramanjaneyulu Manam on Nov 19, 2024
 */
@Entity
@Table(name = "T222_HVW_CABINETS")
public class TblCabinets {
	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String cabinetId;
	private String cabinetName;
	@Column(name = "createTimestamp", columnDefinition = "TIMESTAMP")
	private LocalDateTime createTimestamp;
	@Column(length = 32)
	private String departmentId;
	@Column(columnDefinition = "TIMESTAMP")
	private LocalDateTime lastUsedDate;
	@Transient
	private List<TblActions> actions;

	public String getCabinetId() {
		return cabinetId.toUpperCase();
	}

	public void setCabinetId(String cabinetId) {
		this.cabinetId = cabinetId.toUpperCase();
	}

	public String getCabinetName() {
		return cabinetName;
	}

	public void setCabinetName(String cabinetName) {
		this.cabinetName = cabinetName;
	}

	public String getDepartmentId() {
		return departmentId.toUpperCase();
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId.toUpperCase();
	}

	public LocalDateTime getLastUsedDate() {
		return lastUsedDate;
	}

	public void setLastUsedDate(LocalDateTime lastUsedDate) {
		this.lastUsedDate = lastUsedDate;
	}

	public LocalDateTime getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDateTime createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public List<TblActions> getActions() {
		return actions;
	}

	public void setActions(List<TblActions> actions) {
		this.actions = actions;
	}

}
