package com.hmhs.hvwmid.entity;

import java.io.Serializable;

public class T222ADSGId implements Serializable {
    private Integer imiDocumentId;
    private Integer segmentSeqNo;

    // Default constructor
    public T222ADSGId() {
    }

    // Constructor with parameters
    public T222ADSGId(Integer imiDocumentId, Integer segmentSeqNo) {
        this.imiDocumentId = imiDocumentId;
        this.segmentSeqNo = segmentSeqNo;
    }

    public Integer getImiDocumentId() {
        return imiDocumentId;
    }

    public void setImiDocumentId(final Integer imiDocumentId) {
        this.imiDocumentId = imiDocumentId;
    }

    public Integer getSegmentSeqNo() {
        return segmentSeqNo;
    }

    public void setSegmentSeqNo(final Integer segmentSeqNo) {
        this.segmentSeqNo = segmentSeqNo;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        final T222ADSGId that = (T222ADSGId) o;
        return imiDocumentId.equals(that.imiDocumentId) && segmentSeqNo.equals(that.segmentSeqNo);
    }

    @Override
    public int hashCode() {
        return 31 * imiDocumentId.hashCode() + segmentSeqNo.hashCode();
    }
} 