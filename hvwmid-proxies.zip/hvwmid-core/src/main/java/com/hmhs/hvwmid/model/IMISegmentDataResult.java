package com.hmhs.hvwmid.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhs.hvwmid.entity.T222ADSG;

public class IMISegmentDataResult {

	@JsonProperty("t222adsgList")
	private List<T222ADSG> t222adsgList;

	@JsonProperty("serviceMessage")
	private ServiceMessage serviceMessage;

	public List<T222ADSG> getT222adsgList() {
		return t222adsgList;
	}

	public void setT222adsgList(List<T222ADSG> t222adsgList) {
		this.t222adsgList = t222adsgList;
	}

	public ServiceMessage getServiceMessage() {
		return serviceMessage;
	}

	public void setServiceMessage(ServiceMessage serviceMessage) {
		this.serviceMessage = serviceMessage;
	}

	public static class ServiceMessage {

		@JsonProperty("returnCode")
		private Integer returnCode;

		@JsonProperty("returnCodeDescription")
		private String returnCodeDescription;

		public Integer getReturnCode() {
			return returnCode;
		}

		public void setReturnCode(Integer returnCode) {
			this.returnCode = returnCode;
		}

		public String getReturnCodeDescription() {
			return returnCodeDescription;
		}

		public void setReturnCodeDescription(String returnCodeDescription) {
			this.returnCodeDescription = returnCodeDescription;
		}
	}
}
