package com.hmhs.hvwmid.projection;


public interface PolicyWithHoldProjection {
    // Policy columns
    Integer getPolicyCode();

    String getPolicyId();

    String getPolicyDescription();

    String getPolicyIdType();

    Integer getPolicyDays();

    String getPolicyEditFlag();

    String getPolicyEditPgmName();

    String getPolicyBaseDate();  // varchar format

    String getModUser();

    String getModDate();         // varchar format

    Integer getBpdId();

    // Hold columns
    Integer getHoldCode();

    String getHoldId();

    String getHoldDescription();

    String getHoldEditFlag();

    String getHoldEditPgmName();

    String getHoldModUser();

    String getHoldDateBegin();

    String getHoldDateEnd();
}
