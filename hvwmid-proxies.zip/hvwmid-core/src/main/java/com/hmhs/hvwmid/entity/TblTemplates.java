package com.hmhs.hvwmid.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Sept 3, 2024
 */
@Entity
@Table(name = "T222_HVW_TEMPLATES")
public class TblTemplates {

	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String templateId;
	@Lob
	private byte[] content;
	@Column(length = 32)
	private String envId;
	@Column(name = "lastModifiedDate", columnDefinition = "TIMESTAMP")
	private LocalDateTime lastModifiedDate;
	@Column(length = 32)
	private String lastModifiedUser;
	@Column(length = 64)
	private String templateName;
	@Column(length = 1024)
	private String templateDesc;
	private int templateType;

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	public String getEnvId() {
		return envId;
	}

	public void setEnvId(String envId) {
		this.envId = envId;
	}

	public LocalDateTime getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedUser() {
		return lastModifiedUser;
	}

	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateDesc() {
		return templateDesc;
	}

	public void setTemplateDesc(String templateDesc) {
		this.templateDesc = templateDesc;
	}

	public int getTemplateType() {
		return templateType;
	}

	public void setTemplateType(int templateType) {
		this.templateType = templateType;
	}

}
