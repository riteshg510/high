package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.util.Objects;

/**
 * Composite primary key for T222CodRacfExtEnt entity.
 */
public class T222CodRacfExtEntId implements Serializable {

    private String racfEntity;
    private String racfUserId;
    private String racfClass;

    // Constructors
    public T222CodRacfExtEntId() {
    }

    public T222CodRacfExtEntId(String racfEntity, String racfUserId, String racfClass) {
        this.racfEntity = racfEntity;
        this.racfUserId = racfUserId;
        this.racfClass = racfClass;
    }

    // Getters and Setters
    public String getRacfEntity() {
        return racfEntity;
    }

    public void setRacfEntity(String racfEntity) {
        this.racfEntity = racfEntity;
    }

    public String getRacfUserId() {
        return racfUserId;
    }

    public void setRacfUserId(String racfUserId) {
        this.racfUserId = racfUserId;
    }

    // equals and hashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        T222CodRacfExtEntId that = (T222CodRacfExtEntId) o;
        return Objects.equals(racfEntity, that.racfEntity) &&
               Objects.equals(racfUserId, that.racfUserId) && Objects.equals(racfClass, that.racfClass);
    }

    @Override
    public int hashCode() {
        return Objects.hash(racfEntity, racfUserId, racfClass);
    }


    public String getRacfClass() {
        return racfClass;
    }

    public void setRacfClass(String racfClass) {
        this.racfClass = racfClass;
    }
}