package com.hmhs.hvwmid.dto;

public class HoldResponse {
    private Integer bpdId;
    private Integer holdCode;
    private String holdId;
    private String holdDateBegin;
    private String holdDateEnd;
    private String holdEditFlag;
    private String holdEditPgmName;
    private String modUser;
    private String modDate;
    private String holdDescription;

    public Integer getBpdId() {
        return bpdId;
    }

    public void setBpdId(Integer bpdId) {
        this.bpdId = bpdId;
    }

    public Integer getHoldCode() {
        return holdCode;
    }

    public void setHoldCode(Integer holdCode) {
        this.holdCode = holdCode;
    }

    public String getHoldId() {
        return holdId;
    }

    public void setHoldId(String holdId) {
        this.holdId = holdId;
    }

    public String getHoldDateBegin() {
        return holdDateBegin;
    }

    public void setHoldDateBegin(String holdDateBegin) {
        this.holdDateBegin = holdDateBegin;
    }

    public String getHoldDateEnd() {
        return holdDateEnd;
    }

    public void setHoldDateEnd(String holdDateEnd) {
        this.holdDateEnd = holdDateEnd;
    }

    public String getHoldEditFlag() {
        return holdEditFlag;
    }

    public void setHoldEditFlag(String holdEditFlag) {
        this.holdEditFlag = holdEditFlag;
    }

    public String getHoldEditPgmName() {
        return holdEditPgmName;
    }

    public void setHoldEditPgmName(String holdEditPgmName) {
        this.holdEditPgmName = holdEditPgmName;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public String getModDate() {
        return modDate;
    }

    public void setModDate(String modDate) {
        this.modDate = modDate;
    }

    public String getHoldDescription() {
        return holdDescription;
    }

    public void setHoldDescription(String holdDescription) {
        this.holdDescription = holdDescription;
    }

}
