package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblLdapCabinets;

/**
 * @author Ramanjaneyulu Manam on Nov 22, 2024
 */
@Repository
public interface LdapCabinetsRepository extends CrudRepository<TblLdapCabinets, String> {

	/**
	 * @param groupName
	 * @return
	 */

	List<TblLdapCabinets> getCabinetsByLdapGroupName(String groupName);

	/**
	 * @return
	 */
	@Query(value = "SELECT ldap_group_name from T222_HVW_ldap_cabinets group by ldap_group_name order by ldap_group_name", nativeQuery = true)
	List<String> getLdapCabinets();
	
}
