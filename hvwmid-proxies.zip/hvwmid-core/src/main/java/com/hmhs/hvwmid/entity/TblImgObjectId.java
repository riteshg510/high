package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;

@Embeddable
public class TblImgObjectId implements Serializable {

    @Column(name = "REQUEST_ID")
    private Integer requestId;
    
    @Column(name = "SEQUENCE_NO")
    private Integer sequenceNo;



    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public Integer getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Integer sequenceNo) {
        this.sequenceNo = sequenceNo;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        TblImgObjectId that = (TblImgObjectId) o;
        
        if (!requestId.equals(that.requestId)) return false;
        return sequenceNo.equals(that.sequenceNo);
    }
    
    @Override
    public int hashCode() {
        int result = requestId.hashCode();
        result = 31 * result + sequenceNo.hashCode();
        return result;
    }
}

