package com.hmhs.hvwmid.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Model class representing an IMI update request.
 * Contains the necessary parameters for updating IMI status codes.
 * 
 * @author HighView Development Team
 * @since 1.0
 */
public class IMIUpdateRequest {

    @JsonProperty("tableFlag")
    private String tableFlag;

    @JsonProperty("id")
    private Long id;

    @JsonProperty("statusCd")
    private String statusCd;

    // Default constructor
    public IMIUpdateRequest() {
    }

    // Constructor with required fields
    public IMIUpdateRequest(String tableFlag, Long id, String statusCd) {
        this.tableFlag = tableFlag;
        this.id = id;
        this.statusCd = statusCd;
    }

    // Getters and Setters
    public String getTableFlag() {
        return tableFlag;
    }

    public void setTableFlag(String tableFlag) {
        this.tableFlag = tableFlag;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    @Override
    public String toString() {
        return "IMIUpdateRequest{" +
                "tableFlag='" + tableFlag + '\'' +
                ", id=" + id +
                ", statusCd='" + statusCd + '\'' +
                '}';
    }
}
