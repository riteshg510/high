package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Sept 20, 2024
 */
@Entity
@Table(name = "T222_HVW_PICK_LIST_ITEMS")
public class TblPickListItems {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pick_list_id")
	@SequenceGenerator(name = "pick_list_id", sequenceName = "pick_list_id", allocationSize = 1)
	private Long id = 0L;
	private String dependentKey;
	private String displayName;
	private String key;
	@Column(length = 32)
	private String pickListId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDependentKey() {
		return dependentKey;
	}

	public void setDependentKey(String dependentKey) {
		this.dependentKey = dependentKey;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getPickListId() {
		return pickListId;
	}

	public void setPickListId(String pickListId) {
		this.pickListId = pickListId;
	}

}
