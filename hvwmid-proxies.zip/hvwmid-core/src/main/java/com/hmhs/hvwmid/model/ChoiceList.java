package com.hmhs.hvwmid.model;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChoiceList {
	String key;
	String displayName;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
}
