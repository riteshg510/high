package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.model.ReportArchiveGetRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.hmhs.hvwmid.utils.RestClientUtil;
import com.hmhs.hvwmid.exceptions.HVWException;

import java.util.Map;
import java.util.HashMap;

@Service
public class CMODDocumentService {
    protected static final Logger logger = LogManager.getLogger(CMODDocumentService.class);

    @Value("${api.upload.url}")
    protected String uploadUrl;

    @Value("${api.update.url}")
    protected String updateUrl;

    @Value("${api.delete.url}")
    protected String deleteUrl;

    @Value("${api.download.url}")
    protected String downloadUrl;

    @Value("${api.download.getRequestIdUrl}")
    protected String getRequestIdUrl;

    @Autowired
    protected RestClientUtil restClientUtil;

    protected Map<String, Object> prepareBasePayload(final String documentToken, final String odFolder) {
        final Map<String, Object> payload = new HashMap<>();
        payload.put("documentToken", documentToken);
        payload.put("odFolder", odFolder);
        return payload;
    }

    protected ReportArchiveGetRequest prepareReportArchiveGetRequest(final String documentToken, final String odFolder) {
        ReportArchiveGetRequest request = new ReportArchiveGetRequest();
        request.setDocumentToken(documentToken);
        request.setOdFolder(odFolder);
        return request;
    }

    protected void validateDocumentToken(final String documentToken) {
        if (documentToken == null || documentToken.trim().isEmpty()) {
            throw new HVWException("Document token cannot be null or empty");
        }
    }

    protected void validateFolder(final String odFolder) {
        if (odFolder == null || odFolder.trim().isEmpty()) {
            throw new HVWException("Folder cannot be null or empty");
        }
    }
}