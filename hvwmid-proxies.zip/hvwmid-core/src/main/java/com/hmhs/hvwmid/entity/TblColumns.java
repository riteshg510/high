package com.hmhs.hvwmid.entity;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.stream.Collectors;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Oct 22, 2024
 */
@Entity
@Table(name = "T222_HVW_COLUMNS")
public class TblColumns {
	@Id
	@Column(length = 32, columnDefinition = "CHAR(32)")
	private String columnId;
	@Column(name = "column_order")
	private int columnsOrder;
	private int columnWidth;
	@Column(name = "createTimestamp", columnDefinition = "TIMESTAMP")
	private LocalDateTime createTimestamp;
	private String dateFormat;
	private Short filterable;
	private String label;
	private String name;
	@Column(length = 1024)
	private String pickListOptions;
	private Short sortable;
	@Column(length = 32)
	private String tableId;
	private String type;
	private String url;

	public String getColumnId() {
		return columnId.toUpperCase();
	}

	public void setColumnId(String columnId) {
		this.columnId = columnId.toUpperCase();
	}

	public int getColumnsOrder() {
		return columnsOrder;
	}

	public void setColumnsOrder(int columnsOrder) {
		this.columnsOrder = columnsOrder;
	}

	public int getColumnWidth() {
		return columnWidth;
	}

	public void setColumnWidth(int columnWidth) {
		this.columnWidth = columnWidth;
	}

	public LocalDateTime getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDateTime createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public Short getFilterable() {
		return filterable;
	}

	public void setFilterable(Short filterable) {
		this.filterable = filterable;
	}

	public String getLabel() {
		return capitalize(label);
	}

	public void setLabel(String label) {
		this.label = capitalize(label);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPickListOptions() {
		return pickListOptions;
	}

	public void setPickListOptions(String pickListOptions) {
		this.pickListOptions = pickListOptions;
	}

	public Short getSortable() {
		return sortable;
	}

	public void setSortable(Short sortable) {
		this.sortable = sortable;
	}

	public String getTableId() {
		return tableId.toUpperCase();
	}

	public void setTableId(String tableId) {
		this.tableId = tableId.toUpperCase();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	// String capitalize is used for Label
	static String capitalize(String input) {
		if (input == null || input.isEmpty()) {
			return "";
		}
		return Arrays.stream(input.split("\\s+")).map(word -> word.substring(0, 1).toUpperCase() + word.substring(1))
				.collect(Collectors.joining(" "));
	}

}
