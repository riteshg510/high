package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.repository.T117ImgCoverDeptRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CoversheetDepartmentServiceImpl implements CoversheetDepartmentService {
    final private T117ImgCoverDeptRepository departmentRepository;
    public CoversheetDepartmentServiceImpl(T117ImgCoverDeptRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    @Override
    public List<T117ImgCoverDept> getAllDepartments() {
        return departmentRepository.findAll()
                .stream()
                .collect(Collectors.toList());
    }

    @Override
    public T117ImgCoverDept saveDepartment(T117ImgCoverDept department) {
        if(department.getDeptId() == null)
        {
            // If the department ID is null, it means we are creating a new department and we need to find the next available ID
            Integer nextId = departmentRepository.findMaxDeptIdExcluding9999();
            nextId = nextId + 1; // Increment the maxID found
            department.setDeptId(nextId);
        }
        return departmentRepository.save(department);
    }

    @Override
    public void deleteDepartment(Integer id) {
        departmentRepository.deleteById(id);
    }

    @Override
    public List<String> getAllMaintananceGroups() {
        return departmentRepository.findDistinctMaintGroups();
    }

    @Override
    public T117ImgCoverDept getDepartmentById(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("Department ID cannot be null");
        }
        T117ImgCoverDept department = departmentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Department not found with ID: " + id));

        return department;
    }
}
