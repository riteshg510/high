package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface T222ImgRmaPolicyRepository extends JpaRepository<T222ImgRmaPolicy, Integer> {
    @Query(value = "SELECT DISTINCT BPD_ID FROM T222_IMG_RMA_POLICY", nativeQuery = true)
    List<Integer> findDistinctBpdIds();

    List<T222ImgRmaPolicy> findByBpdIdIn(Collection<Integer> bpdIds);

    Optional<T222ImgRmaPolicy> findByPolicyCode(Integer policyCode);

    void deleteByPolicyCode(Integer policyCode);

    @Query(value = "SELECT DISTINCT POLICY_CODE FROM T222_IMG_RMA_POLICY", nativeQuery = true)
    Set<Integer> selectAllPolicyCodes();
}
