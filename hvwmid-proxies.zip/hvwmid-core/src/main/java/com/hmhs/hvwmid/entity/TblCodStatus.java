package com.hmhs.hvwmid.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Represents a status record for API/document interaction.
 */
@Entity
@Table(name = "T222_COD_STATUS")
@IdClass(TblCodStatusId.class)
public class TblCodStatus {

    @Id
    @Column(name = "TIME_CREATE", nullable = false)
    private LocalDateTime timeCreate;

    @Id
    @Column(name = "REQUEST_ID", nullable = false)
    private Integer requestId;

    @Column(name = "USERID", nullable = false, length = 10)
    private String userId;

    @Column(name = "API_METHOD", nullable = false, length = 255)
    private String apiMethod;

    @Column(name = "HTTP_STATUS_CODE", nullable = false, length = 25)
    private String httpStatusCode;

    @Column(name = "RETURN_CODE", nullable = false, length = 25)
    private String returnCode;

    @Column(name = "STATUS_DESCRIPTION", nullable = false, length = 255)
    private String statusDescription;

    // Getters and Setters

    public LocalDateTime getTimeCreate() {
        return timeCreate;
    }

    public void setTimeCreate(LocalDateTime timeCreate) {
        this.timeCreate = timeCreate;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getApiMethod() {
        return apiMethod;
    }

    public void setApiMethod(String apiMethod) {
        this.apiMethod = apiMethod;
    }

    public String getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(String httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TblCodStatus)) return false;
        TblCodStatus that = (TblCodStatus) o;
        return Objects.equals(timeCreate, that.timeCreate) &&
                Objects.equals(requestId, that.requestId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(timeCreate, requestId);
    }
}
