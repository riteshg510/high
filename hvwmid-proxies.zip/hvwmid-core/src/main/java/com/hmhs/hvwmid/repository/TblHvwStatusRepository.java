package com.hmhs.hvwmid.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblHvwStatus;
import com.hmhs.hvwmid.entity.TblHvwStatusId;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Repository
public interface TblHvwStatusRepository extends JpaRepository<TblHvwStatus, TblHvwStatusId> {

    @Transactional
    @Modifying
    @Query("DELETE FROM TblHvwStatus t WHERE t.id.timeCreate < :cutoff")
    void deleteByTimeCreateBefore(@Param("cutoff") LocalDateTime cutoff);

}


