package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T117ImgCoverAppl;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface T117ImgCoverApplRepository extends JpaRepository<T117ImgCoverAppl, Integer> {

    @Query("SELECT COALESCE(MAX(t.application), 0) FROM T117ImgCoverAppl t")
    int findMaxApplication();

    List<T117ImgCoverAppl> findAllByActive(String active);

    // Find all applications which department printgroup is in the provided list
    @Query("SELECT t FROM T117ImgCoverAppl t WHERE t.department.maintGroup IN :groups")
    List<T117ImgCoverAppl> findAllByMaintGroupIn(@Param("groups") List<String> groups);

    @Query("SELECT t FROM T117ImgCoverAppl t WHERE t.department.printGroup IN :groups and t.active = 'Y'")
    List<T117ImgCoverAppl> findAllActiveByPrintGroupIn(@Param("groups") List<String> groups);

    @Query("SELECT t FROM T117ImgCoverAppl t WHERE t.department.printGroup IN :groups")
    List<T117ImgCoverAppl> findAllByPrintGroupIn(@Param("groups") List<String> groups);

    @Query("SELECT t FROM T117ImgCoverAppl t WHERE t.department.printGroup IN :groups and t.department.deptId = :departmentId")
    List<T117ImgCoverAppl> findAllByDepartmentIdAndPrintGroupIn(@Param("departmentId") Integer departmentId, @Param("groups") List<String> groups);

    @Query("SELECT t FROM T117ImgCoverAppl t WHERE t.department.maintGroup IN :groups AND t.application = :id")
    Optional<T117ImgCoverAppl> findApplicationByIdAndPrintGroupIn(@Param("id") Integer id, @Param("groups") List<String> groups);
}
