package com.hmhs.hvwmid.entity;

import java.io.Serializable;

public class OdscrtId implements Serializable {
    private String agName;
    private String appName;

    public String getAgName() {
        return agName;
    }

    public void setAgName(final String agName) {
        this.agName = agName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(final String appName) {
        this.appName = appName;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        final OdscrtId odscrtId = (OdscrtId) o;
        return agName.equals(odscrtId.agName) && appName.equals(odscrtId.appName);
    }

    @Override
    public int hashCode() {
        return 31 * agName.hashCode() + appName.hashCode();
    }
}