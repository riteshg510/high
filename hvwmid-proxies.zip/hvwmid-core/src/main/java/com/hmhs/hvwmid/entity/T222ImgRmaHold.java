package com.hmhs.hvwmid.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "T222_IMG_RMA_HOLD")
public class T222ImgRmaHold {
    @Column(name = "BPD_ID", nullable = false)
    private Integer bpdId;

    @Id
    @Column(name = "HOLD_CODE", nullable = false)
    private Integer holdCode;

    @Column(name = "HOLD_ID", length = 30, nullable = false)
    private String holdId;

    @Column(name = "HOLD_DATE_BEGIN")
    private LocalDate holdDateBegin;

    @Column(name = "HOLD_DATE_END")
    private LocalDate holdDateEnd;

    @Column(name = "HOLD_EDIT_FLAG", length = 1, nullable = false)
    private String holdEditFlag;

    @Column(name = "HOLD_EDIT_PGMNAME", length = 8, nullable = false)
    private String holdEditPgmName;

    @Column(name = "MODUSER", length = 8, nullable = false)
    private String modUser;

    @Column(name = "MODDATE", nullable = false)
    private LocalDateTime modDate;

    @Column(name = "HOLD_DESCRIPTION", length = 250)
    private String holdDescription;

    @PrePersist
    public void generateIdIfMissing() {
        if (this.holdCode == null) {
            this.holdCode = ThreadLocalRandom.current().nextInt(1, 1_000_000);
        }
    }

    public Integer getBpdId() {
        return bpdId;
    }

    public void setBpdId(Integer bpdId) {
        this.bpdId = bpdId;
    }

    public Integer getHoldCode() {
        return holdCode;
    }

    public void setHoldCode(Integer holdCode) {
        this.holdCode = holdCode;
    }

    public String getHoldId() {
        return holdId;
    }

    public void setHoldId(String holdId) {
        this.holdId = holdId;
    }

    public LocalDate getHoldDateBegin() {
        return holdDateBegin;
    }

    public void setHoldDateBegin(LocalDate holdDateBegin) {
        this.holdDateBegin = holdDateBegin;
    }

    public LocalDate getHoldDateEnd() {
        return holdDateEnd;
    }

    public void setHoldDateEnd(LocalDate holdDateEnd) {
        this.holdDateEnd = holdDateEnd;
    }

    public String getHoldEditFlag() {
        return holdEditFlag;
    }

    public void setHoldEditFlag(String holdEditFlag) {
        this.holdEditFlag = holdEditFlag;
    }

    public String getHoldEditPgmName() {
        return holdEditPgmName;
    }

    public void setHoldEditPgmName(String holdEditPgmName) {
        this.holdEditPgmName = holdEditPgmName;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public LocalDateTime getModDate() {
        return modDate;
    }

    public void setModDate(LocalDateTime modDate) {
        this.modDate = modDate;
    }

    public String getHoldDescription() {
        return holdDescription;
    }

    public void setHoldDescription(String holdDescription) {
        this.holdDescription = holdDescription;
    }
}
