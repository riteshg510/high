package com.hmhs.hvwmid.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.entity.TblActions;
import com.hmhs.hvwmid.entity.TblCabinets;
import com.hmhs.hvwmid.entity.TblColumns;
import com.hmhs.hvwmid.entity.TblDepartment;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblHelpPages;
import com.hmhs.hvwmid.entity.TblLdapCabinets;
import com.hmhs.hvwmid.entity.TblPickListItems;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblSections;
import com.hmhs.hvwmid.entity.TblTables;
import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.repository.ActionsRepository;
import com.hmhs.hvwmid.repository.CabinetsRepository;
import com.hmhs.hvwmid.repository.ChoiceItemsRepository;
import com.hmhs.hvwmid.repository.DepartmentRepository;
import com.hmhs.hvwmid.repository.FormsRepository;
import com.hmhs.hvwmid.repository.ImageDataRepository;
import com.hmhs.hvwmid.repository.LdapCabinetsRepository;
import com.hmhs.hvwmid.repository.SectionDetailsRepository;
import com.hmhs.hvwmid.repository.SectionsRepository;
import com.hmhs.hvwmid.repository.TblColumnsRepository;
import com.hmhs.hvwmid.repository.TblHelpPagesRepository;
import com.hmhs.hvwmid.repository.TblTablesRepository;
import com.hmhs.hvwmid.repository.TemplateDataRepository;

/**
 * @author Ramanjaneyulu Manam on Sep 18, 2024
 */
@Service
public class AppDataServiceImpl implements AppDataService {

	@Autowired
	private ActionsRepository actionsRepo;

	@Autowired
	private ChoiceItemsRepository pickRepo;

	@Autowired
	private CabinetsRepository cabinetsRepo;

	@Autowired
	private DepartmentRepository departmentRepo;

	@Autowired
	private FormsRepository formsRepo;

	@Autowired
	private LdapCabinetsRepository ldapCabinetsRepo;

	@Autowired
	private SectionDetailsRepository sectionDetailsRepo;

	@Autowired
	private SectionsRepository secRepo;

	@Autowired
	private TblColumnsRepository tblColumnRepo;

	@Autowired
	private TblTablesRepository tblTableRepo;

	@Autowired
	private TemplateDataRepository templetDataRepo;

	@Autowired
	private ImageDataRepository imageDataRepo;

	@Autowired
	private TblHelpPagesRepository tblHelpPagesRepo;

	@Override
	public List<TblActions> getActionsByFormId(String fid) {
		return actionsRepo.getActionsByFormIdOrderByActionOrderAsc(fid);
	}

	@Override
	public List<TblCabinets> getCabinetsByCabinetIds(List<String> userCabinetIds) {
		return cabinetsRepo.getCabinetsByCabinetIdIn(userCabinetIds);
	}

	@Override
	public List<TblCabinets> getCabinetsByCabinetsNames(List<String> cabinetsNamesList) {
		return cabinetsRepo.getCabinetsByCabinetNameIn(cabinetsNamesList);
	}

	@Override
	public List<TblCabinets> getCabinetsByDepartmentId(String departmentId) {
		return cabinetsRepo.getCabinetsByDepartmentIdOrderByCabinetNameAsc(departmentId);
	}

	@Override
	public List<String> getDepartmentIdsByUserCabinetIds(List<String> userCabinetIds) {
		return cabinetsRepo.getDepartmentIdsByUserCabinets(userCabinetIds);
	}

	@Override
	public List<TblDepartment> findAllDepartment() {
		return departmentRepo.findAllByOrderByDepartmentNameAsc();
	}

	@Override
	public List<TblDepartment> getDepartmentsByDeptIds(List<String> deptIdList) {
		return departmentRepo.getDepartmentsByDepartmentIdInOrderByDepartmentNameAsc(deptIdList);
	}

	@Override
	public List<TblLdapCabinets> getCabinetsNamesByGroupName(String groupName) {
		return ldapCabinetsRepo.getCabinetsByLdapGroupName(groupName);
	}

	@Override
	public TblForms getForm(String fid) {
		return formsRepo.getFormByFormId(fid);
	}

	@Override
	public List<TblForms> getFormIdByFileName(String filename) {
		return formsRepo.getFormIdByFileName(filename);
	}

	@Override
	public List<TblPickListItems> getPickList(String plid) {
		return pickRepo.getChoiceItemsByPickListIdOrderByIdAsc(plid);
	}

	@Override
	public List<TblPickListItems> getPickList(String plid, String dkey) {
		return pickRepo.getChoiceItemsByPickListIdAndDependentKeyOrderByIdAsc(plid, dkey);
	}

	@Override
	public List<TblSectionDetails> getSectionDetailsBySectionId(String sid) {
		return sectionDetailsRepo.getSectionDetailsBySectionIdOrderByColumnNumberAscFieldOrderAsc(sid);
	}

	@Override
	public List<TblSectionDetails> getSectionDetailsBySectionIdOrderByFieldOrderAsc(String sid) {
		return sectionDetailsRepo.getSectionDetailsBySectionIdOrderByFieldOrderAsc(sid);
	}

	@Override
	public List<String> getChildList(String sectionId, String fieldName) {
		return sectionDetailsRepo.getDependentFieldNames(sectionId, fieldName);
	}

	@Override
	public List<TblSections> getSections(String fid) {
		return secRepo.getSectionsByFormId(fid);
	}

	@Override
	public List<TblSections> getSectionsByParentSectionId(String psid, String fid) {
		return secRepo.getSectionDataByParentSectionIdAndFormIdOrderByParentColumnNumberAsc(psid, fid);
	}

	@Override
	public List<TblColumns> getColumns(String tableId) {
		return tblColumnRepo.getColumnsByTableIdOrderByColumnsOrderAsc(tableId);
	}

	@Override
	public TblTables getTableByTableId(String tableId) {
		return tblTableRepo.getTableByTableId(tableId);
	}

	@Override
	public List<TblTemplates> getTempletByName(String templateName) {
		return templetDataRepo.getTempletByTemplateName(templateName);
	}

	@Override
	public ImageData getImageDataFilename(String id) {
		return imageDataRepo.getImageDataById(Long.parseLong(id));
	}

	@Override
	public Page<ImageData> findAll(Pageable pagingSort) {
		return imageDataRepo.findAll(pagingSort);
	}

	@Override
	public Page<ImageData> findByFormDescriptionContaining(String formDescription, Pageable pagingSort) {
		return imageDataRepo.findByFormDescriptionContaining(formDescription, pagingSort);
	}

	@Override
	public TblHelpPages getHelpPages(String odFolderName) {
		return tblHelpPagesRepo.getHelpPageByOdFolderName(odFolderName);
	}

	@Override
	public String updateCabinetsTable(String cabinetId) {
		cabinetsRepo.updateCabinetsTable(LocalDateTime.now(), cabinetId);
		return "{\"status\":\"success\",\"message\":\"Cabinet last used date was updated.\"}";
	}

	@Override
	public TblTables getTableByTableName(String tableName) {
		return tblTableRepo.getTableByTableName(tableName);
	}

	@Override
	public List<String> getLDAPGroups() {
		return ldapCabinetsRepo.getLdapCabinets();
	}
}
