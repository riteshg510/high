package com.hmhs.hvwmid.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.HashMap;

@Service
public class CMODUpdateService extends CMODDocumentService {

    private static final Logger logger = LogManager.getLogger(CMODUpdateService.class);

    @Autowired
    private RestClientUtil restClientUtil;

    @SuppressWarnings({"unchecked", "rawtypes"})
    public Map<String, Object> updateDocument(final Map<String, Object> request, final String authToken) {
        final String documentToken = (String) request.get("documentToken");
        final String odFolder = (String) request.get("odFolder");

        validateDocumentToken(documentToken);
        validateFolder(odFolder);

        // Prepare base payload
        final Map<String, Object> payload = prepareBasePayload(documentToken, odFolder);

        // Create updateValues map excluding id, action, documentToken, odFolder, and
        // reportId
        final Map<String, Object> updateValues = new HashMap<>();
        request.forEach((key, value) -> {
            if (!key.equals("id") && !key.equals("action") && !key.equals("documentToken") &&
                    !key.equals("odFolder") && !key.equals("recordFormat")) {
                updateValues.put(key, value);
            }
        });

        payload.put("updateValues", updateValues);

        logger.info("Sending update request to URL: {} with payload: {}", updateUrl, payload);
        // Make the API call
        org.springframework.http.ResponseEntity<?> response = restClientUtil.postRequest(updateUrl, authToken, payload);
        if (!response.getStatusCode().is2xxSuccessful()) {
            logger.error("Backend update service returned error status: {} with body: {}", response.getStatusCode(), response.getBody());
            throw HVWException.parseErrorResponse((org.springframework.http.ResponseEntity<Map>) response, "CMOD");
        }
        return (Map<String, Object>) response.getBody();
    }
}