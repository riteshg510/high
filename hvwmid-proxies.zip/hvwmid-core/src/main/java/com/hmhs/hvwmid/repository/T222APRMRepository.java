package com.hmhs.hvwmid.repository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.entity.T222APRMId;

@Repository
public interface T222APRMRepository extends JpaRepository<T222APRM, T222APRMId> {

    // Fetch records by parmID and filter by parmData (ignore case)
    default List<T222APRM> findByParmIdAndParmData(String parmData) {
        // Fetch records from the database each time
        List<T222APRM> records = findByParmId(HVWConstants.PARMIDFORAPPLIST);

        // Filter the records by parmData, ignoring case
        return records.stream()
                .filter(record -> record.getParmData().equalsIgnoreCase(parmData))
                .collect(Collectors.toList());
    }

    // Method to fetch records by parmID
    List<T222APRM> findByParmId(String parmId);

    // Method to convert list of parameter records to a map for easy lookup
    default Map<String, String> getParmDataAsMap(String parmId) {
        return findByParmId(parmId).stream()
                .collect(Collectors.toMap(
                    T222APRM::getParmKey,
                    T222APRM::getParmData,
                    (existing, replacement) -> replacement
                ));
    }

    // Method to get all parameter records for multiple parm IDs
    @Query("SELECT p FROM T222APRM p WHERE p.parmId IN :parmIds")
    List<T222APRM> findByParmIdIn(@Param("parmIds") List<String> parmIds);

    // Method to get parameter records grouped by parm ID
    default Map<String, List<T222APRM>> getParmDataGroupedByParmId(List<String> parmIds) {
        return findByParmIdIn(parmIds).stream()
                .collect(Collectors.groupingBy(T222APRM::getParmId));
    }

    // Method to get parameter data maps grouped by parm ID
    default Map<String, Map<String, String>> getParmDataMapsGroupedByParmId(List<String> parmIds) {
        return getParmDataGroupedByParmId(parmIds).entrySet().stream()
                .collect(Collectors.toMap(
                    Map.Entry::getKey,
                    entry -> entry.getValue().stream()
                            .collect(Collectors.toMap(
                                T222APRM::getParmKey,
                                T222APRM::getParmData,
                                (existing, replacement) -> replacement
                            ))
                ));
    }
}
