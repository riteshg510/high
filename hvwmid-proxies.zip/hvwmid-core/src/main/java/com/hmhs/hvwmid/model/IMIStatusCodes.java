package com.hmhs.hvwmid.model;

public class IMIStatusCodes {
    
    // Transmit File Status Codes
    public enum TransmitFileStatusCd {
        A("Accepted"), R("Rejected"), C("Completed");

        private String statusDesc;

        private TransmitFileStatusCd(String statusDesc) {
            this.statusDesc = statusDesc;
        }

        public String getStatusDesc() {
            return statusDesc;
        }
    }

    // Process File Status Codes
    public enum ProcessFileStatusCd {
        V("Validation (Ready for)"), 
        K("Acknowledge (Ready for)"), 
        T("Transformation (Ready for)"), 
        F("Finalization (Ready for)"), 
        E("Error"), 
        C("Completed");

        private String statusDesc;

        private ProcessFileStatusCd(String statusDesc) {
            this.statusDesc = statusDesc;
        }

        public String getStatusDesc() {
            return statusDesc;
        }
    }

    // Document Status Codes
    public enum DocumentStatusCd {
        A("Accepted"), 
        X("Batch Capture (Ready for)"), 
        I("Image Store (Ready for)"), 
        L("Non-claim OCR (Ready for)"), 
        P("CMOD (Ready for)"), 
        O("Claim OCR (Ready for)"), 
        S("Stored"), 
        M("CMOD Stored"), 
        F("Finalization (Ready for)"), 
        E("Error"), 
        R("Rejected");

        private String statusDesc;

        private DocumentStatusCd(String statusDesc) {
            this.statusDesc = statusDesc;
        }

        public String getStatusDesc() {
            return statusDesc;
        }
    }
} 