package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.TblImgToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


public interface ImgTokenRepository extends JpaRepository<TblImgToken, Integer> {
    List<TblImgToken> findByUserIdAndDocumentToken(String userId, String documentToken);
    Optional<TblImgToken> findByRequestId(Integer requestId);

    /**
     * Delete all tokens (and their chunks) created before the given cutoff.
     */
    @Transactional
    @Modifying
    @Query("DELETE FROM TblImgToken t WHERE t.timeCreate < :cutoff")
    void deleteByTimeCreateBefore(@Param("cutoff") LocalDateTime cutoff);


    default List<TblImgToken> findByUserIdAndDocumentTokenAndSecurityTokenSafe(String userId, String documentToken, String securityToken) {
        return findByUserIdAndDocumentToken(userId, documentToken)
                .stream()
                .filter(t -> securityToken.equals(t.getSecurityToken()))
                .collect(Collectors.toList());
    }



    default Optional<TblImgToken> findByRequestIdAndSecurityTokenSafe(Integer requestId, String securityToken) {
        return findByRequestId(requestId)
                .filter(t -> securityToken.equals(t.getSecurityToken()));
    }
}
