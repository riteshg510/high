package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "T222_IMG_RMA_POLICY_HOLD")
@IdClass(T222ImgRmaPolicyHoldId.class)
public class T222ImgRmaPolicyHold {
    @Id
    @Column(name = "BPD_ID", nullable = false)
    private Integer bpdId;

    @Id
    @Column(name = "POLICY_CODE", nullable = false)
    private Integer policyCode;

    @Id
    @Column(name = "HOLD_CODE", nullable = false)
    private Integer holdCode;

    @Column(name = "MODUSER", length = 8, nullable = false)
    private String modUser;

    @Column(name = "MODDATE", nullable = false)
    private LocalDateTime modDate;

    public Integer getBpdId() {
        return bpdId;
    }

    public void setBpdId(Integer bpdId) {
        this.bpdId = bpdId;
    }

    public Integer getPolicyCode() {
        return policyCode;
    }

    public void setPolicyCode(Integer policyCode) {
        this.policyCode = policyCode;
    }

    public Integer getHoldCode() {
        return holdCode;
    }

    public void setHoldCode(Integer holdCode) {
        this.holdCode = holdCode;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public LocalDateTime getModDate() {
        return modDate;
    }

    public void setModDate(LocalDateTime modDate) {
        this.modDate = modDate;
    }
}
