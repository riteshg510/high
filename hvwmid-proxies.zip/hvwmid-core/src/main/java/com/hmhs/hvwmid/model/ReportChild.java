package com.hmhs.hvwmid.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportChild {
	private String layoutType;
	private String defaultValue;
	private String id;
	private String inputType;
	private String type;
	private String name;
	private Integer maxLength;
	private Boolean required;
	private Boolean display;
	private Boolean collapsible;
	private Boolean defaultCollapsed;
	private Boolean readonly;
	private List<Map<String, String>> choiceList;
	private String dateFormat;
	private String dateFormatDisplay;
	private String queryParamId;
	private Boolean allowFutureDate;

	public Boolean getAllowFutureDate() {
		return allowFutureDate;
	}

	public void setAllowFutureDate(Boolean allowFutureDate) {
		this.allowFutureDate = allowFutureDate;
	}

	public String getDateFormatDisplay() {
		return dateFormatDisplay;
	}

	public void setDateFormatDisplay(String dateFormatDisplay) {
		this.dateFormatDisplay = dateFormatDisplay;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public Boolean getReadonly() {
		return readonly;
	}

	public void setReadonly(final Boolean readonly) {
		this.readonly = readonly;
	}

	private List<ReportChild> children;

	// Getters and Setters
	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(final String layoutType) {
		this.layoutType = layoutType;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(final String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getId() {
		return id;
	}

	public void setId(final String id) {
		this.id = id;
	}

	public String getInputType() {
		return inputType;
	}

	public void setInputType(final String inputType) {
		this.inputType = inputType;
	}

	public String getType() {
		return type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Integer getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(final Integer maxLength) {
		this.maxLength = maxLength;
	}

	public Boolean getRequired() {
		return required;
	}

	public void setRequired(final Boolean required) {
		this.required = required;
	}

	public Boolean getDisplay() {
		return display;
	}

	public void setDisplay(final Boolean display) {
		this.display = display;
	}

	public Boolean getCollapsible() {
		return collapsible;
	}

	public void setCollapsible(final Boolean collapsible) {
		this.collapsible = collapsible;
	}

	public Boolean getDefaultCollapsed() {
		return defaultCollapsed;
	}

	public void setDefaultCollapsed(final Boolean defaultCollapsed) {
		this.defaultCollapsed = defaultCollapsed;
	}

	public List<ReportChild> getChildren() {
		return children;
	}

	public void setChildren(final List<ReportChild> children) {
		this.children = children;
	}

	public List<Map<String, String>> getChoiceList() {
		return choiceList;
	}

	public void setChoiceList(final List<Map<String, String>> choiceList) {
		this.choiceList = choiceList;
	}

	public String getQueryParamId() {
		return queryParamId;
	}

	public void setQueryParamId(String queryParamId) {
		this.queryParamId = queryParamId;
	}
}
