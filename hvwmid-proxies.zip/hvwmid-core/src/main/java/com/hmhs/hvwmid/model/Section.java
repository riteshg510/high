package com.hmhs.hvwmid.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Section extends BaseLayout {

	private String layoutType = "section";
	private boolean collapsible = false;
	private boolean defaultCollapsed = false;
	private String id;
	private String sid;
	private String name;
	private List<Columns> children = new ArrayList<>();

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public void setChildren(Columns children) {
		this.children.add(children);
	}
	
	public void setChildren(List<Columns> columns) {
		this.children = columns;
	}

	public List<Columns> getChildren() {
		return children;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public void setCollapsible(boolean collapsible) {
		this.collapsible = collapsible;
	}

	public boolean isCollapsible() {
		return collapsible;
	}

	public void setDefaultCollapsed(boolean defaultCollapsed) {
		this.defaultCollapsed = defaultCollapsed;
	}

	public boolean isDefaultCollapsed() {
		return defaultCollapsed;
	}
}
