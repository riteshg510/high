package com.hmhs.hvwmid.model;

import java.util.List;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ramanjaneyulu Manam on Oct 21, 2024
 */
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class Field {

	String id;
	String label;
	String name;
	String type;
	Short sortable;
	Short filterable;
	int columnWidth;
	String url;
	String dateFormat;
	String trueLabel;
	String falseLabel;
	List<ChoiceList> choiceList;
	int columnsOrder;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Short getSortable() {
		return sortable;
	}

	public void setSortable(Short sortable) {
		this.sortable = sortable;
	}

	public Short getFilterable() {
		return filterable;
	}

	public void setFilterable(Short filterable) {
		this.filterable = filterable;
	}

	public int getColumnWidth() {
		return columnWidth;
	}

	public void setColumnWidth(int columnWidth) {
		this.columnWidth = columnWidth;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getTrueLabel() {
		return trueLabel;
	}

	public void setTrueLabel(String trueLabel) {
		this.trueLabel = trueLabel;
	}

	public String getFalseLabel() {
		return falseLabel;
	}

	public void setFalseLabel(String falseLabel) {
		this.falseLabel = falseLabel;
	}

	public List<ChoiceList> getChoiceList() {
		return choiceList;
	}

	public void setChoiceList(List<ChoiceList> choiceList) {
		this.choiceList = choiceList;
	}

	public int getColumnsOrder() {
		return columnsOrder;
	}

	public void setColumnsOrder(int columnsOrder) {
		this.columnsOrder = columnsOrder;
	}

}
