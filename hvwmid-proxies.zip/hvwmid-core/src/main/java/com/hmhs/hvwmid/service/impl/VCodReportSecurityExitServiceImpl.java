package com.hmhs.hvwmid.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.hmhs.hvwmid.entity.VCodReportSecurityExit;
import com.hmhs.hvwmid.repository.VCodReportSecurityExitRepository;
import com.hmhs.hvwmid.service.VCodReportSecurityExitService;

@Service
public class VCodReportSecurityExitServiceImpl implements VCodReportSecurityExitService {

    private static final Logger logger = LoggerFactory.getLogger(VCodReportSecurityExitServiceImpl.class);

    private final VCodReportSecurityExitRepository repository;

    @Autowired
    public VCodReportSecurityExitServiceImpl(VCodReportSecurityExitRepository repository) {
        this.repository = repository;
    }

    @Override
    public Map<String, Map<String, String>> getCmodIndexBpdIdByCmodApplication() throws SQLException {
        Map<String, Map<String, String>> parmDataMap = new HashMap<>();
        
        try {
            List<VCodReportSecurityExit> securityExitData = repository.getSecurityExitData();
            
            for (VCodReportSecurityExit securityExit : securityExitData) {
                String cmodApplication = securityExit.getCmodApplication();
                if (cmodApplication != null) {
                    cmodApplication = cmodApplication.trim();
                    if (cmodApplication.length() > 0) {
                        String cmodIndex = securityExit.getCmodIndex();
                        String bpdId = securityExit.getBpdId();
                        
                        if (!StringUtils.isEmpty(cmodIndex) && !StringUtils.isEmpty(bpdId)) {
                            Map<String, String> parmValuesMap = new HashMap<>();
                            parmValuesMap.put("Index", cmodIndex);
                            parmValuesMap.put("BpdId", bpdId);
                            parmDataMap.put(cmodApplication, parmValuesMap);
                        }
                    }
                }
            }
            
            logger.debug("Retrieved {} CMOD application mappings", parmDataMap.size());
            
        } catch (Exception e) {
            logger.error("Exception in getting Parm Data from DB2: {}", e.getMessage(), e);
            throw new SQLException("Exception in getting Parm Data from DB2 : " + e.getMessage());
        }
        
        return parmDataMap;
    }
}