package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class WorkstationService {

    private static final Logger logger = LogManager.getLogger(WorkstationService.class);

    private final RestClientUtil restClientUtil;

    @Value("${api.workstation.url}")
    private String workstationUrl;

    public WorkstationService(RestClientUtil restClientUtil) {
        this.restClientUtil = restClientUtil;
    }

    /**
     * Retrieves workstation listing from external service
     *
     * @param otherFields Request parameters from controller
     * @param authToken   JWT authentication token
     * @return ResponseEntity with workstation data
     * @throws HVWException if error occurs during API call
     */
    public ResponseEntity<Object> getWorkstationList(Map<String, String> otherFields, String authToken)
            throws HVWException {

        Map<String, Object> requestBody = buildRequestBody(otherFields, authToken);

        logger.info("Calling workstation API with request body: {}", requestBody);

        ResponseEntity<Map> response = restClientUtil.postRequest(workstationUrl, authToken, requestBody);

        Map<String, Object> responseBody = getResults(response.getBody());

        if(responseBody == null){
            return ResponseEntity.notFound().build();
        }
        return new ResponseEntity<>(responseBody, HttpStatus.OK);
    }

    public Map<String, Object> getWorkstationInformation(String ipaddress, String authToken)
            throws HVWException {
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("ipAddressMask", ipaddress);
        requestBody.put("function", "L");

        logger.info("Calling workstation API with request body: {}", requestBody);

        ResponseEntity<Map> response = restClientUtil.postRequest(workstationUrl, authToken, requestBody);

        return response.getBody();
    }

    /**
     * Builds request body from otherFields parameters
     */
    private Map<String, Object> buildRequestBody(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>();

        // Fixed values
        requestBody.put("requestLength", "37");
        requestBody.put("function", otherFields.getOrDefault("function", "L"));

        // Get user from JWT token
        String initiatingUserId = HVWUtils.getUserIdFromJWT(authToken);
        requestBody.put("initiatingUserId", initiatingUserId);

        // Masks - use "%" if null or empty
        String workstationIDMask = normalizeField(otherFields.get("workstationIDMask"));
        String ipAddressMask = normalizeField(otherFields.get("ipAddressMask"));

        requestBody.put("workstationIDMask", workstationIDMask != null ? workstationIDMask : "%");
        requestBody.put("ipAddressMask", ipAddressMask != null ? ipAddressMask : "%");

        return requestBody;
    }

    /**
     * Normalizes field value - trims and converts empty/null to null
     */
    private String normalizeField(String value) {
        return (value == null || value.trim().isEmpty()) ? null : value.trim();
    }

    private Map getResults(Map response){
        System.out.println(response.containsKey("workstationListing"));
        if(response.containsKey("workstationListing")){
            Map workstationListing = (Map) response.get("workstationListing");
            if(workstationListing.containsKey("results")){
                Map results = (Map) workstationListing.get("results");
                System.out.println(results.containsKey("rows"));
                if(!results.containsKey("rows")
                        || results.get("rows") == null
                        || ((List)results.get("rows")).isEmpty()){
                    return null;
                }
            }
        }
        return response;
    }
}