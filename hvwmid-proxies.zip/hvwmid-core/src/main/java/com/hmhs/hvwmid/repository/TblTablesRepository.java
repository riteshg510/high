package com.hmhs.hvwmid.repository;

import org.springframework.data.repository.CrudRepository;

import com.hmhs.hvwmid.entity.TblTables;

/**
 * @author Ramanjaneyulu Manam on Oct 22, 2024
 */
public interface TblTablesRepository extends CrudRepository<TblTables, String> {

	/**
	 * @param tableId
	 * @return
	 */
	TblTables getTableByTableId(String tableId);

	/**
	 * @param tableName
	 * @return
	 */
	TblTables getTableByTableName(String tableName);

}
