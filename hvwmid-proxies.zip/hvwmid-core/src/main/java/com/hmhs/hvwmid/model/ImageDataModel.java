package com.hmhs.hvwmid.model;

import java.util.Date;

import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Ramanjaneyulu Manam on Oct 10, 2024
 */
@JsonComponent
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ImageDataModel {

	String applid;
	Date enddate;
	String filetab;
	String foldid;
	Boolean showdeleted;
	Date startdate;

	public String getApplid() {
		return applid;
	}

	public void setApplid(String applid) {
		this.applid = applid;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public String getFiletab() {
		return filetab;
	}

	public void setFiletab(String filetab) {
		this.filetab = filetab;
	}

	public String getFoldid() {
		return foldid;
	}

	public void setFoldid(String foldid) {
		this.foldid = foldid;
	}

	public Boolean getShowdeleted() {
		return showdeleted;
	}

	public void setShowdeleted(Boolean showdeleted) {
		this.showdeleted = showdeleted;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

}
