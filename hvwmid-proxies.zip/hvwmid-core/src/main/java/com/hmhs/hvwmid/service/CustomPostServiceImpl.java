package com.hmhs.hvwmid.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.model.ImageDataModel;
import com.hmhs.hvwmid.repository.ImageDataRepository;

/**
 * @author Ramanjaneyulu Manam on Oct 9, 2024
 */
@Service
public class CustomPostServiceImpl implements CustomPostService {

	@Autowired
	private ImageDataRepository imageDataRepo;

	@Override
	public List<ImageData> getViewImageData(ImageDataModel inputData) {
		return imageDataRepo.findImageDataByApplicationId(inputData);
	}

	@Override
	public List<String> getLookupValues(String fieldName, String lookupValue) {
		List<String> lookupItems = new ArrayList<>();
		if (fieldName.toLowerCase().startsWith("appl"))
			lookupItems = imageDataRepo.getAllApplicationIdsSatrtsWith(lookupValue);
		if (fieldName.toLowerCase().startsWith("fold"))
			lookupItems = imageDataRepo.getAllFolderIdsSatrtsWith(lookupValue);
		return lookupItems;
	}

}
