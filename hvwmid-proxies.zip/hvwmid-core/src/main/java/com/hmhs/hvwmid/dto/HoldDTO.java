package com.hmhs.hvwmid.dto;

import lombok.Data;

@Data
public class HoldDTO {
    private Integer bpdId;
    private Integer holdCode;
    private String holdId;
    private String holdDateBegin;
    private String holdDateEnd;
    private String holdEditFlag;
    private String holdEditPgmName;
    private String modUser;
    private String modDate;
    private String holdDescription;

    public HoldDTO(Object[] row) {
        this.bpdId = row[0] != null ? ((Number) row[0]).intValue() : null;
        this.holdCode = row[1] != null ? ((Number) row[1]).intValue() : null;
        this.holdId = row[2] != null ? row[2].toString() : null;
        this.holdDateBegin = row[3] != null ? row[3].toString() : null;
        this.holdDateEnd = row[4] != null ? row[4].toString() : null;
        this.holdEditFlag = row[5] != null ? row[5].toString() : null;
        this.holdEditPgmName = row[6] != null ? row[6].toString() : null;
        this.modUser = row[7] != null ? row[7].toString() : null;
        this.modDate = row[8] != null ? row[8].toString() : null;
        this.holdDescription = row[9] != null ? row[9].toString() : null;
    }
}
