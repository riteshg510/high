package com.hmhs.hvwmid.entity;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "T117_IMG_COVERAPPL")
public class T117ImgCoverAppl implements Serializable {

    @Id
    @Column(name = "APPLICATION", nullable = false)
    private Integer application;

    @Column(name = "DESCRIPTION", nullable = false, length = 40)
    private String description;

    @Column(name = "SEQUENCE", nullable = false)
    private Integer sequence;

//    @Column(name = "DEPTID", nullable = false)
//    private Integer deptId;

    // Reference to T117ImgCoverDept entity deptId is external key
    @ManyToOne
    @JoinColumn(name = "DEPTID", referencedColumnName = "DEPTID", nullable = false)
    private T117ImgCoverDept department;



    @Column(name = "ACTIVE", nullable = false, length = 1)
    private String active;

    @Column(name = "APPLID", nullable = false, length = 5)
    private String applId;

    public Integer getApplication() {
        return application;
    }

    public void setApplication(Integer application) {
        this.application = application;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

//    public Integer getDeptId() {
//        return deptId;
//    }
//
//    public void setDeptId(Integer deptId) {
//        this.deptId = deptId;
//    }

    public T117ImgCoverDept getDepartment() {
        return department;
    }
    public void setDepartment(T117ImgCoverDept department) {
        this.department = department;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getApplId() {
        return applId;
    }

    public void setApplId(String applId) {
        this.applId = applId;
    }
}
