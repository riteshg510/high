package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblSectionDetails;

/**
 * @author Ramanjaneyulu Manam on Sept 6, 2024
 */
@Repository
public interface SectionDetailsRepository extends CrudRepository<TblSectionDetails, String> {

	/**
	 * @param sid
	 * @return
	 */
	List<TblSectionDetails> getSectionDetailsBySectionIdOrderByColumnNumberAscFieldOrderAsc(String sid);
	
	/**
	 * @param sid
	 * @return
	 */
	List<TblSectionDetails> getSectionDetailsBySectionIdOrderByFieldOrderAsc(String sid);

	/**
	 * @param sectionId
	 * @param fieldName
	 * @return
	 */
	@Query(value = "SELECT FIELD_NAME FROM T222_HVW_SECTION_DETAILS WHERE SECTION_ID = ? AND IS_DEPENDENT_ON LIKE %?%", nativeQuery = true)
	List<String> getDependentFieldNames(String sectionId, String fieldName);
}
