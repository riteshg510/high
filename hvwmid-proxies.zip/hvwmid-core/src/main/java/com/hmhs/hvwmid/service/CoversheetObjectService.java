package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.model.CoverSheetObjectDTO;

import java.util.List;

public interface CoversheetObjectService {

    List<T117ImgCoverObject> getTemplates();

    String getTemplateData(String name);

    CoverSheetObjectDTO getTemplateByNameAndType(String name, String type);
}
