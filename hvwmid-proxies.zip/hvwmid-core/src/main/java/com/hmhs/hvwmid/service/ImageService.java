package com.hmhs.hvwmid.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.hmhs.hvwmid.model.Action;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ImageService {

    private static final Logger logger = LogManager.getLogger(ImageService.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    @Value("${api.images.url}")
    String allImagesUrl = null;
    @Autowired
    private RestClientUtil restClientUtil;

    @Value("${api.access.url}")
    private String accessUrl;

    @Value("${api.images.download.url}")
    String downloadUrl;

 

    @Value("${api.images.delete-restore.url}")
    String deleteRestoreUrl = null;
    @Value("${api.images.copy.url}")
    String copyToFolderUrl = null;

    @Value("${api.images.move.url}")
    String moveToFolderUrl = null;

    private static final String ACTIONS_COLUMN_ID = "action";
    private static final String NEXT_ACTION_REQUEST_FIELD = "nextactionname";
    private static final String COPY_2_FOLDA_ACTION = "copy2folda";
    private static final String COPY_2_FOLDB_ACTION = "copy2foldb";
    private static final String MOVE_2_FOLDA_ACTION = "move2folda";
    private static final String MOVE_2_FOLDB_ACTION = "move2foldb";
    private static final String COPY_TO_CLAIM_ACTION = "copytoclaim";
    private static final String RESET_TEMPID_ACTION = "resettempid";
    private static final String DF_ECRP_SENT_ACTION = "dfecrpsent";
    private static final String HG_INITIAL_CLAIM_ENTRY_ACTION = "hginitial";
    private static final String OSCAR_ADJUSTMENT_ACTION = "oscaradjustment";
    private static final String HG_ADJUSTMENT_ACTION = "hgaadjustment";
    private static final String UPDATE_MS_CARE_ACTION = "updatemscare";
    private static final String COPY_TO_ADDITIONAL_CLAIMS_ACTION = "copytoadditionalclaims";
    private static final String COPY_TO_IBC_ACTION = "copytoibc";

    private static final String DELETE_ACTION = "delete";
    private static final String NEXT_ACTION_FIELD = "nextaction";
    private static final String DOCUMENT_TOKEN_FIELD = "documentToken";
    private static final String INITIATING_USER_ID_FIELD = "initiatingUserID";
    private static final String ACTION_ICON = "actionIcon";
    private static final String ACTION_API_URL = "apiUrl";
    private static final String ACTION_TYPE = "actionType";
    private static final String X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS = "x-highmark-businessProcessDifferentiatorIds";
    private static final String BPDID_FIELD = "bpdid";
    private static final String USER_STAT_FIELD = "userStat";

    static List<Map<String, Object>> filterResults(Map<String, String> otherFields,
            List<Map<String, Object>> documentData) {
        String fileTabFilter = normalizeFilterField(otherFields.get("filetab"));
        String startDate = normalizeFilterField(otherFields.get("startdate"));
        String endDate = normalizeFilterField(otherFields.get("enddate"));
        String showDeleted = normalizeFilterField(otherFields.get("showdeleted"));

        boolean includeDeleted = "yes".equalsIgnoreCase(showDeleted);

        List<Map<String, Object>> filteredDocuments = new ArrayList<>();

        for (Map<String, Object> doc : documentData) {
            String docFileTab = (String) doc.get("fileTab");
            String receivedDate = (String) doc.get("receivedDate");
            String objectUserStatus = (String) doc.get("objectUserStatus");
            logger.debug("object User Status {}", objectUserStatus);
            doc.put("formDescription",
                    doc.getOrDefault("fileTab", "") + " - " + doc.getOrDefault("objectDescription", ""));

            boolean matchesFileTab = (fileTabFilter == null || fileTabFilter.isEmpty())
                    || (docFileTab != null && fileTabFilter.equalsIgnoreCase(docFileTab));
            boolean matchesDateRange = true;
            boolean matchesDeleted = true;

            if (startDate != null && endDate != null && receivedDate != null) {
                String receivedDateNormalized = receivedDate.replace("-", ""); // yyyyMMdd
                matchesDateRange = receivedDateNormalized.compareTo(startDate) >= 0
                        && receivedDateNormalized.compareTo(endDate) <= 0;
            }

            if (!includeDeleted) {
                  logger.debug("includeDeleted {}", includeDeleted);
                matchesDeleted = "0".equals(objectUserStatus);
            }
            else{
                 logger.debug("includeDeleted {}", includeDeleted);
            }

            if (matchesFileTab && matchesDateRange && matchesDeleted) {
                filteredDocuments.add(doc);
            }
        }
        return filteredDocuments;
    }


    private static String normalizeFilterField(String value) {
        return (value == null || value.trim().isEmpty()) ? null : value.trim();
    }

    static List<Map<String, Object>> validateAndGetData(ResponseEntity<Map> response) {

        if (response == null) {
            throw new HVWException(503, "Empty response received from report service", "CMOD");
        }
        if (!response.getStatusCode().is2xxSuccessful()) {
            logger.error("Error from external service: {} - {}", response.getStatusCode(), response.getBody());
            throw HVWException.parseErrorResponse(response, "CMOD");
        }

        Map<String, Object> responseBody = response.getBody();
        if (responseBody == null) {
            throw new HVWException(503, "Empty response received from report service", "CMOD");
        }

        Map<String, Object> imageListData = (Map<String, Object>) responseBody.get("imageListData");
        if (imageListData == null) {
            throw new HVWException(503, "No imageListData in response", "CMOD");
        }

        List<Map<String, Object>> documentData = (List<Map<String, Object>>) imageListData.get("documentData");
        if (documentData == null) {
            documentData = new ArrayList<>();
        }

        return documentData;
    }

    private static String getNextaction(Map<String, String> otherFields) {
        return otherFields.get(NEXT_ACTION_FIELD);
    }

    private List<Map<String, Object>> addActionsBasedOnCallSource(Map<String, String> otherFields,
            List<Map<String, Object>> filteredDocuments) throws IOException {
        if (!otherFields.containsKey(NEXT_ACTION_REQUEST_FIELD))
            return filteredDocuments;

        String nextAction = getNextaction(otherFields);

        return switch (nextAction) {
            case COPY_2_FOLDA_ACTION ->
                addActionButton(filteredDocuments, COPY_2_FOLDA_ACTION, "file_copy", "image/copy", "copy","Copy");
            case COPY_2_FOLDB_ACTION ->
                addActionButton(filteredDocuments, COPY_2_FOLDB_ACTION, "move_down", "image/copy", "move","Copy");
			case MOVE_2_FOLDA_ACTION ->
				addActionButton(filteredDocuments, MOVE_2_FOLDA_ACTION, "move_down", "image/copy", "move","Move");

            case MOVE_2_FOLDB_ACTION ->
                addActionButton(filteredDocuments, MOVE_2_FOLDB_ACTION, "move_down", "image/copy", "move","Move");
            case DELETE_ACTION ->
                addActionButton(filteredDocuments, DELETE_ACTION, "remove", "image/delete-restore", "delete","Delete");

            // todo: appropriate actions should be added
            case COPY_TO_CLAIM_ACTION ->
                addActionButton(filteredDocuments, COPY_TO_CLAIM_ACTION, "note_add", "image/claim", "copyToClaim","Copy");
            case RESET_TEMPID_ACTION ->
                addActionButton(filteredDocuments, RESET_TEMPID_ACTION, "restart_alt", "image/reset", "reset","Reset TempID");
            case DF_ECRP_SENT_ACTION ->
                addActionButton(filteredDocuments, DF_ECRP_SENT_ACTION, "send", "image/ecrp", "dfEcrpSent", "DF ECRP Sent");
            case HG_INITIAL_CLAIM_ENTRY_ACTION ->
                addActionButton(filteredDocuments, HG_INITIAL_CLAIM_ENTRY_ACTION, "assignment", "image/highmark",
                        "hgClaimEntry","HG Initial Claim Entry");
            case OSCAR_ADJUSTMENT_ACTION ->
                addActionButton(filteredDocuments, OSCAR_ADJUSTMENT_ACTION, "tune", "image/adjust", "oscarAdjust","OSCAR Adjustment");
            case HG_ADJUSTMENT_ACTION ->
                addActionButton(filteredDocuments, HG_ADJUSTMENT_ACTION, "tune", "image/adjust", "hgaAdjust","HG Adjustment");
            case UPDATE_MS_CARE_ACTION ->
                addActionButton(filteredDocuments, UPDATE_MS_CARE_ACTION, "update", "image/update", "update","Update");
            case COPY_TO_ADDITIONAL_CLAIMS_ACTION ->
                addActionButton(filteredDocuments, COPY_TO_ADDITIONAL_CLAIMS_ACTION, "file_copy", "image/copy",
                        "copyToAdditionalClaims","Copy");
            case COPY_TO_IBC_ACTION ->
                addActionButton(filteredDocuments, COPY_TO_IBC_ACTION, "file_copy", "image/copy", "copyToIBC","Copy");

            default -> filteredDocuments;
        };
    }

    public ResponseEntity<Object> getImagesListObja(Map<String, String> otherFields, String authToken)
            throws IOException {
        final ResponseEntity<Map> response = getBaseImageResponse(otherFields, authToken);
        List<Map<String, Object>> documentData = validateAndGetData(response);
        logger.info("Total documents retrieved: {}", documentData.size());
        // Calculate counts before filtering
        int total = documentData.size();
        int secured = 0;
        int deleted = 0;
        for (Map<String, Object> doc : documentData) {
            if ("yes".equalsIgnoreCase(String.valueOf(doc.get("secure")))) {
                secured++;
            }
            if (!"0".equals(String.valueOf(doc.get("objectUserStatus")))) {
                deleted++;
            }
        }
        logger.info("Secured documents: {}, Deleted documents: {}", secured, deleted);
        // Filter out secured documents for data
        List<Map<String, Object>> nonSecuredDocs = new ArrayList<>();
        for (Map<String, Object> doc : documentData) {
            if (!"yes".equalsIgnoreCase(String.valueOf(doc.get("secure")))) {
                nonSecuredDocs.add(doc);
            }
        }

        // Apply existing filters (filetab, date, deleted, etc.)
        List<Map<String, Object>> filteredDocuments = filterResults(otherFields, nonSecuredDocs);
        filteredDocuments = addDownloadActionButton(filteredDocuments);
        filteredDocuments = addActionsBasedOnCallSource(otherFields, filteredDocuments);

        int filtered = total - filteredDocuments.size() - secured - deleted;
        if (filtered < 0) filtered = 0; // avoid negative

        Map<String, Object> counts = new HashMap<>();
        counts.put("total", total);
        counts.put("filtered", filtered);
        counts.put("deleted", deleted);
        counts.put("secured", secured);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("data", filteredDocuments);
        responseBody.put("counts", counts);

        return new ResponseEntity<>(responseBody, HttpStatus.OK);
    }


    private List<Map<String, Object>> addActionButton(
            final List<Map<String, Object>> data,
            String action,
            String actionIcon,
            String apiUrl,
            String actionType,
            String label) throws IOException {
        final String jsonString = objectMapper.writeValueAsString(data);
        final JsonNode jsonArray = objectMapper.readTree(jsonString);

        for (final JsonNode node : jsonArray) {
            final ObjectNode objNode = (ObjectNode) node;
            final ArrayNode actions;

            if (objNode.has(ACTIONS_COLUMN_ID) && objNode.get(ACTIONS_COLUMN_ID).isArray()) {
                actions = (ArrayNode) objNode.get(ACTIONS_COLUMN_ID);
            } else {
                actions = objectMapper.createArrayNode();
            }

            final ObjectNode actionNode = objectMapper.createObjectNode();
            actionNode.put(ACTIONS_COLUMN_ID, action);
            actionNode.put(ACTION_ICON, actionIcon);
            actionNode.put(ACTION_API_URL, apiUrl);
            actionNode.put(ACTION_TYPE, actionType);
            actionNode.put("label", label);

            actions.add(actionNode);
            objNode.set(ACTIONS_COLUMN_ID, actions);
        }

        return objectMapper.readValue(
                jsonArray.toString(),
                new TypeReference<List<Map<String, Object>>>() {
                });
    }

    private List<Map<String, Object>> addDownloadActionButton(final List<Map<String, Object>> data) throws IOException {
        final String jsonString = objectMapper.writeValueAsString(data);
        final JsonNode jsonArray = objectMapper.readTree(jsonString);

        for (final JsonNode node : jsonArray) {
            final ObjectNode objNode = (ObjectNode) node;
            final ArrayNode actions;

            if (objNode.has(ACTIONS_COLUMN_ID) && objNode.get(ACTIONS_COLUMN_ID).isArray()) {
                actions = (ArrayNode) objNode.get(ACTIONS_COLUMN_ID);
            } else {
                actions = objectMapper.createArrayNode();
            }

            // Download PDF action using Action model
            Action downloadPdfAction = new Action();
            downloadPdfAction.setActionName("dynamicAction");
            downloadPdfAction.setActionIcon("visibility");
            downloadPdfAction.setApiUrl("image/tokens/view");
            downloadPdfAction.setActionType("downloadpdf");
            downloadPdfAction.setLabel("View");
            actions.add(objectMapper.valueToTree(downloadPdfAction));

            // Download Original action using Action model
            Action downloadOriginalAction = new Action();
            downloadOriginalAction.setActionName("dynamicAction");
            downloadOriginalAction.setActionIcon("download");
            downloadOriginalAction.setApiUrl("image/tokens/view");
            downloadOriginalAction.setActionType("download");
            downloadOriginalAction.setLabel("Download Original");
            actions.add(objectMapper.valueToTree(downloadOriginalAction));

            // Delete/UnDelete action using Action model
            Action deleteAction = new Action();
            deleteAction.setActionName("dynamicAction");
            deleteAction.setActionIcon("delete");
            deleteAction.setApiUrl("image/delete-restore");
            deleteAction.setActionType("delete");
            deleteAction.setLabel((objNode.has("objectUserStatus") && objNode.get("objectUserStatus").asInt() == 0) ? "Delete" : "UnDelete");
            actions.add(objectMapper.valueToTree(deleteAction));


            objNode.set(ACTIONS_COLUMN_ID, actions);
        }

        return objectMapper.readValue(
                jsonArray.toString(),
                new TypeReference<List<Map<String, Object>>>() {
                });
    }

    private static Map<String, String> generateExtraHeaders(Map<String, String> otherFields) {
        Map<String, String> extraHeaders = new HashMap<>();

        if (otherFields.containsKey(BPDID_FIELD) && !StringUtils.isBlank(otherFields.get(BPDID_FIELD))) {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, otherFields.get(BPDID_FIELD));
        } else {
            extraHeaders.put(X_HIGHMARK_BUSINESS_PROCESS_DIFFERENTIATOR_IDS, "0");
        }

        return extraHeaders;
    }

    private ResponseEntity<Map> getBaseImageExtendedResponse(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>();

        // Only add keyN if value is not null or empty
        for (int i = 1; i <= 20; i++) {
            String keyName = "key" + i;
            String fieldName = "field" + i;
            String value = normalizeFilterField(otherFields.get(fieldName));
            if (value != null) {
                requestBody.put(keyName, value);
            }
        }

        String applIdcd = normalizeFilterField(otherFields.get("applidcd"));
        if (applIdcd != null) {
            requestBody.put("applIdcd", applIdcd);
        }
        requestBody.put("searchSecondaryIndexMetaData", "true");
        Map<String, String> extraHeaders = generateExtraHeaders(otherFields);
        return restClientUtil.postRequest(allImagesUrl, authToken, requestBody, extraHeaders);
    }

    private ResponseEntity<Map> getBaseImageResponse(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>();
        String foldId = normalizeFilterField(otherFields.get("foldid"));
        if (foldId == null) {
            foldId = normalizeFilterField(otherFields.get("field1"));
        }
        requestBody.put("key1", foldId);
        requestBody.put("applIdcd", normalizeFilterField(otherFields.get("applidcd")));

        Map<String, String> extraHeaders = generateExtraHeaders(otherFields);

        return restClientUtil.postRequest(allImagesUrl, authToken, requestBody, extraHeaders);
    }

    public ResponseEntity<Object> getImagesListObj2(Map<String, String> otherFields, String authToken)
            throws IOException {
        final ResponseEntity<Map> response = getBaseImageExtendedResponse(otherFields, authToken);
        List<Map<String, Object>> documentData = validateAndGetData(response);

        // Calculate counts before filtering
        int total = documentData.size();
        int secured = 0;
        int deleted = 0;
        for (Map<String, Object> doc : documentData) {
            if ("yes".equalsIgnoreCase(String.valueOf(doc.get("secure")))) {
                secured++;
            }
            if (!"0".equals(String.valueOf(doc.get("objectUserStatus")))) {
                deleted++;
            }
        }

        // Filter out secured documents for data
        List<Map<String, Object>> nonSecuredDocs = new ArrayList<>();
        for (Map<String, Object> doc : documentData) {
            if (!"yes".equalsIgnoreCase(String.valueOf(doc.get("secure")))) {
                nonSecuredDocs.add(doc);
            }
        }

        // Apply existing filters (filetab, date, deleted, etc.)
        List<Map<String, Object>> filteredDocuments = filterResults(otherFields, nonSecuredDocs);
        filteredDocuments = addDownloadActionButton(filteredDocuments);
        filteredDocuments = addActionsBasedOnCallSource(otherFields, filteredDocuments);

        int filtered = total - filteredDocuments.size() - secured - deleted;
        if (filtered < 0) filtered = 0; // avoid negative

        Map<String, Object> counts = new HashMap<>();
        counts.put("total", total);
        counts.put("filtered", filtered);
        counts.put("deleted", deleted);
        counts.put("secured", secured);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("data", filteredDocuments);
        responseBody.put("counts", counts);

        return new ResponseEntity<>(responseBody, HttpStatus.OK);
    }

    public ResponseEntity<ByteArrayResource> download(Map<String, String> otherFields, String authToken) {
        String documentToken = otherFields.get(DOCUMENT_TOKEN_FIELD);

        validateDocumentToken(documentToken);

        // Prepare base payload
        final Map<String, Object> payload = prepareBasePayload(documentToken);

        logger.info("Sending download request to URL: {} with payload: {}", downloadUrl, payload);
        // Make the API call and expect a binary response
        final ResponseEntity<ByteArrayResource> response = restClientUtil.postRequestForBinary(downloadUrl, authToken,
                payload);

        // Log the response status
        logger.info("Download response status: {}", response.getStatusCode());

        // Just return the response with its original status code
        return response;
    }

    private Map<String, Object> prepareBasePayload(String documentToken) {
        final Map<String, Object> payload = new HashMap<>();
        payload.put(DOCUMENT_TOKEN_FIELD, documentToken);
        return payload;
    }

    private void validateDocumentToken(final String documentToken) {
        if (documentToken == null || documentToken.trim().isEmpty()) {
            throw new HVWException("Document token cannot be null or empty");
        }
    }

    // Todo: change this according to imagemq api response
    public ResponseEntity<Object> copy2folder(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put(DOCUMENT_TOKEN_FIELD, otherFields.get(DOCUMENT_TOKEN_FIELD));
        requestBody.put(INITIATING_USER_ID_FIELD, otherFields.get("objectUserStatus"));

        String rawTargetFolders = otherFields.get("destinationFolder");
        List<String> targetFoldIds = Arrays.stream(rawTargetFolders.split(";"))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();

        Map<String, Object> target = new HashMap<>();
        target.put("targetFoldIds", targetFoldIds);

        requestBody.put("target", target);
        ResponseEntity<Map> response;

        String action = otherFields.get(ACTIONS_COLUMN_ID);
        if ("copy".equalsIgnoreCase(action)) {
            response = restClientUtil.postRequest(copyToFolderUrl, authToken, requestBody);
        } else if ("move".equalsIgnoreCase(action)) {
            response = restClientUtil.postRequest(moveToFolderUrl, authToken, requestBody);
        } else {
            return new ResponseEntity<>(Map.of("error", "Unsupported action: " + action), HttpStatus.BAD_REQUEST);
        }

        if (response.getStatusCode().is2xxSuccessful()) {
            return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response.getBody(), response.getStatusCode());
        }
    }

    public ResponseEntity<Object> deleteRestore(Map<String, String> otherFields, String authToken) {
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put(DOCUMENT_TOKEN_FIELD, otherFields.get(DOCUMENT_TOKEN_FIELD));
       // requestBody.put(INITIATING_USER_ID_FIELD, otherFields.get("objectUserStatus"));
        String objectUserStatus = otherFields.get("objectUserStatus");
        String userStatValue = "0".equals(objectUserStatus) ? "1" : "0";
        requestBody.put(USER_STAT_FIELD, userStatValue);

        ResponseEntity<Map> response = restClientUtil.postRequest(deleteRestoreUrl, authToken, requestBody);

        if (response.getStatusCode().is2xxSuccessful()) {
            return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(response.getBody(), response.getStatusCode());
        }
    }
}