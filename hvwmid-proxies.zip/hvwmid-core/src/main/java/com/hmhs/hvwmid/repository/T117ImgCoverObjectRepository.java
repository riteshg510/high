package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface T117ImgCoverObjectRepository extends JpaRepository<T117ImgCoverObject, String> {

    @Query("SELECT o FROM T117ImgCoverObject o WHERE UPPER(o.objName) = UPPER(:name)")
    Optional<T117ImgCoverObject> findByNameIgnoreCase(@Param("name") String name);

    @Query("SELECT DISTINCT o.objName FROM T117ImgCoverObject o")
    List<String> findDistinctObjNames();

    @Query("SELECT o FROM T117ImgCoverObject o")
    List<T117ImgCoverObject> findAllTemplates();

    Optional<T117ImgCoverObject> getFirstByObjName(String objName);

    @Modifying
    @Query("UPDATE T117ImgCoverObject t SET " +
            "t.objType = UPPER(:objType), " +
            "t.mimeType = :mimeType, " +
            "t.objData = :objData, " +
            "t.active = 'Y' " +
            "WHERE UPPER(t.objName) = UPPER(:objName)")
    int updateTemplate(
            @Param("objName") String objName,
            @Param("objType") String objType,
            @Param("mimeType") String mimeType,
            @Param("objData") String objData
    );

    @Query("SELECT o FROM T117ImgCoverObject o WHERE UPPER(o.objName) = UPPER(:name) AND UPPER(o.objType) = UPPER(:type)")
    Optional<T117ImgCoverObject> findByNameAndTypeIgnoreCase(@Param("name") String name, @Param("type") String type);
}
