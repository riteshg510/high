package com.hmhs.hvwmid.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

public class TblCodStatusId implements Serializable {

    private LocalDateTime timeCreate;
    private Integer requestId;

    public TblCodStatusId() {}

    public TblCodStatusId(LocalDateTime timeCreate, Integer requestId) {
        this.timeCreate = timeCreate;
        this.requestId = requestId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TblCodStatusId)) return false;
        TblCodStatusId that = (TblCodStatusId) o;
        return Objects.equals(timeCreate, that.timeCreate) &&
                Objects.equals(requestId, that.requestId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(timeCreate, requestId);
    }
}
