package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblCodObject;
import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.repository.CodCachingRepository;
import com.hmhs.hvwmid.repository.CodObjectRepository;
import com.hmhs.hvwmid.repository.CodTokenRepository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Arrays;

@Service
@Transactional
public class CodCachingService {

    private final CodCachingRepository codCachingRepository;
    private final CodTokenRepository tokenRepo;
    private final CodObjectRepository objectRepo;
    private final GenericUDFService seqGen;
    private final TransactionTemplate txTemplate;
    @Value("${db-logging-env}")
    private String dbLoggingEnv;

    @Autowired
    HvwDataRefresh hvwDataRefresh;
    private static final Logger logger = LogManager.getLogger(CodCachingService.class);

    @Autowired
    public CodCachingService(CodCachingRepository codCachingRepository, CodObjectRepository objectRepo,
            CodTokenRepository tokenRepo,
            PlatformTransactionManager txManager,
            JdbcTemplate jdbcTemplate) {
        this.codCachingRepository = codCachingRepository;
        this.tokenRepo = tokenRepo;
        this.objectRepo = objectRepo;
        this.txTemplate = new TransactionTemplate(txManager);
        // this.txTemplate.setReadOnly(true);
        // Pass the correct sequence function name for CodCachingService
        this.seqGen = new GenericUDFService(jdbcTemplate, "DB2222055A_UDF");
    }

    @Transactional
    public int cacheDocument(InputStream in,
            String userId,
            String documentToken,
            String securityToken) throws IOException {
        String env = hvwDataRefresh.getParmDataByKeyByCmodbase("DEFAULT_ENV", dbLoggingEnv);

        int requestId = seqGen.generateRequestId(env);
        TblCodToken token = new TblCodToken();
        token.setRequestId(requestId);
        token.setUserId(userId);
        token.setDocumentToken(documentToken);
        token.setSecurityToken(securityToken);
        tokenRepo.save(token);

        byte[] buffer = new byte[32 * 1024]; // ~32KB
        int seq = 0, len;
        while ((len = in.read(buffer)) != -1) {
            byte[] chunk = Arrays.copyOf(buffer, len);
            TblCodObject obj = new TblCodObject();
            obj.setRequestId(requestId);
            obj.setSequenceNo(seq++);
            obj.setObjectSegment(chunk);
            objectRepo.save(obj);
        }
        return requestId;
    }

    @Transactional
    public TblCodToken getDocumentToken(String userId, String documentToken, String securityToken) {
        return tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe(userId, documentToken, securityToken)
                .stream()
                .filter(token -> token.getDocumentType() != null && (token.getDocumentType().equalsIgnoreCase("PDF")
                        || token.getDocumentType().toUpperCase().contains("PDF")))
                .findFirst()
                .orElseThrow(() -> new SecurityException("Not found or not a PDF document"));
    }

    @Transactional
    public TblCodToken getDocumentToken(Integer requestId, String securityToken) {
        return tokenRepo.findByRequestIdAndSecurityTokenSafe(requestId, securityToken)
                .orElseThrow(() -> new SecurityException("Not found"));
    }

    public StreamingResponseBody streamDocument(int requestId) {
        return outputStream -> {
            try {
                codCachingRepository.streamSegmentsByRequestId(requestId, outputStream);
            } catch (SQLException e) {
                throw new IOException("Database error while streaming document", e);
            }
        };
    }

    public TblCodToken saveToken(String userId, String securityToken, String documentToken) {
        String env = hvwDataRefresh.getParmDataByKeyByCmodbase("DEFAULT_ENV", dbLoggingEnv);

        int requestId = seqGen.generateRequestId(env);
        TblCodToken newtoken = new TblCodToken();
        newtoken.setRequestId(requestId);
        newtoken.setUserId(userId);
        newtoken.setTimeCreate(java.time.LocalDateTime.now());
        newtoken.setDocumentType("");
        newtoken.setDocumentPages(1);
        newtoken.setDocumentToken(documentToken);
        newtoken.setSecurityToken(securityToken);
        newtoken.setDocCnvStatus("");
        newtoken.setDocumentSize(0); // Assuming size is 0 for new token
        return tokenRepo.save(newtoken);
    }

    /**
     * Returns a TblCodToken for the given user, documentToken, and translateType,
     * using DOC_CNV_STATUS and documentType logic.
     * If not found, returns null.
     */
    public TblCodToken getTokenByStatusAndType(String userId, String documentToken, String translateType,
            String securityToken) {
        String[] specialTypes = { "pdf", "afp", "tif", "tiff", "jpg", "jpeg", "bmp", "gif", "png", "txt" };
        java.util.List<TblCodToken> tokens = tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe(userId,
                documentToken, securityToken);
        if ("TOPDF".equalsIgnoreCase(translateType != null ? translateType.trim() : null)) {
            for (TblCodToken token : tokens) {
                String docType = token.getDocumentType();
                String status = token.getDocCnvStatus();
                logger.debug("Checking token with status: {}, docType: {}", status, docType);
                boolean isSpecial = false;
                if (docType != null) {
                    String docTypeLower = docType.trim().toLowerCase();
                    isSpecial = java.util.Arrays.stream(specialTypes).noneMatch(docTypeLower::equals);
                } else {
                    isSpecial = true;
                }
                if (isSpecial) {
                    logger.debug("docType with special document type found: {}", docType);
                    return token;
                }
                String statusTrimmed = status != null ? status.trim() : null;
                if ("Converted".equalsIgnoreCase(statusTrimmed)
                        || "Conversion Failed".equalsIgnoreCase(statusTrimmed)) {
                    return token;
                }
            }
        } else {
            logger.debug("translateType is not TOPDF, checking for Original or Conversion Failed status");
            for (TblCodToken token : tokens) {

                String docType = token.getDocumentType();
                String status = token.getDocCnvStatus();
                logger.debug("Checking token with status: {}, docType: {}", status, docType);
                boolean isSpecial = false;
                if (docType != null) {
                    String docTypeLower = docType.trim().toLowerCase();
                    isSpecial = java.util.Arrays.stream(specialTypes).noneMatch(docTypeLower::equals);
                } else {
                    isSpecial = true;
                }
                if (isSpecial) {
                    logger.debug("docType with special document type found: {}", docType);
                    return token;
                }
                String statusTrimmed = status != null ? status.trim() : null;
                if ("Original".equalsIgnoreCase(statusTrimmed) || "Conversion Failed".equalsIgnoreCase(statusTrimmed)) {
                    return token;
                }
            }
        }
        return null;
    }

    public void setDbLoggingEnv(String dbLoggingEnv) {
        this.dbLoggingEnv = dbLoggingEnv;
    }

}
