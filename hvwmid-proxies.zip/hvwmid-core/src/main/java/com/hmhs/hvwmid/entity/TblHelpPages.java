package com.hmhs.hvwmid.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * @author Ramanjaneyulu Manam on Dec 2, 2024
 */
@Entity
@Table(name = "T222_HVW_HELP_PAGES")
public class TblHelpPages {

	@Id
	@Column(length = 255, columnDefinition = "CHAR(255)")
	private String odFolderName;
	@Column(length = 32)
	private String formId;

	public String getOdFolderName() {
		return odFolderName;
	}

	public void setOdFolderName(String odFolderName) {
		this.odFolderName = odFolderName;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

}
