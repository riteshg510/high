package com.hmhs.hvwmid.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.Odscrt;
import com.hmhs.hvwmid.entity.OdscrtId;

@Repository
public interface OdscrtRepository extends JpaRepository<Odscrt, OdscrtId> {

    List<Odscrt> findByForeignRid(String foreignRid);
}