package com.hmhs.hvwmid.enums;

public enum HoldHeaderNameAttr {
    HOLD_CODE("Hold Code", "holdCode", false, 0),
    HOLD_ID("Hold Id", "holdId", true, 30),
    HOLD_DESCRIPTION("Hold Description", "holdDescription", false, 250),
    BPD_ID("BPD Id", "bpdId", true, 0),
    HOLD_DATE_BEGIN("Hold Date Begin", "holdDateBegin", false, 10),
    HOLD_DATE_END("Hold Date End", "holdDateEnd", false, 10),
    HOLD_EDIT_FLAG("Hold Edit Flag", "holdEditFlag", true, 1),
    HOLD_EDIT_PGMNAME("Hold Edit Program Name", "holdEditPgmName", false, 8),
    MODUSER("Modified User", "modUser", false, 8),
    MODTIMESTAMP("Modified Timestamp", "modDate", false, 0);

    private final String headerName;
    private final String beanAttribute;
    private final boolean mandatory;
    private final int fieldSize;

    HoldHeaderNameAttr(String headerName, String beanAttribute, boolean mandatory, int fieldSize) {
        this.headerName = headerName;
        this.beanAttribute = beanAttribute;
        this.mandatory = mandatory;
        this.fieldSize = fieldSize;
    }

    public String getHeaderName() { return headerName; }
    public String getBeanAttribute() { return beanAttribute; }
    public boolean isMandatory() { return mandatory; }
    public int getFieldSize() { return fieldSize; }
}
