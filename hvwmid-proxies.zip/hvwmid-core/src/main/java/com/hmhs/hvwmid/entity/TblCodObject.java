package com.hmhs.hvwmid.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * Represents a chunk of a cached document.
 */
@Entity
@Table(name = "T222_COD_OBJECT")
@IdClass(TblCodObjectId.class)
public class TblCodObject {

    @Id
    @Column(name = "REQUEST_ID", nullable = false)
    private Integer requestId;

    @Id
    @Column(name = "SEQUENCE_NO", nullable = false)
    private Integer sequenceNo;

    @Column(name = "TIME_CREATE", nullable = false, columnDefinition = "TIMESTAMP(6) DEFAULT CURRENT TIMESTAMP")
    private LocalDateTime timeCreate;

    @Column(name = "OBJECT_SEGMENT", columnDefinition = "VARCHAR(31691) FOR BIT DATA", nullable = false)
    private byte[] objectSegment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="REQUEST_ID", insertable = false, updatable = false)
    private TblCodToken codToken;



    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public Integer getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(Integer sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    public LocalDateTime getTimeCreate() {
        return timeCreate;
    }

    public void setTimeCreate(LocalDateTime timeCreate) {
        this.timeCreate = timeCreate;
    }

    public byte[] getObjectSegment() {
        return objectSegment;
    }

    public void setObjectSegment(byte[] objectSegment) {
        this.objectSegment = objectSegment;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TblCodObject)) return false;
        TblCodObject that = (TblCodObject) o;
        return Objects.equals(requestId, that.requestId) &&
                Objects.equals(sequenceNo, that.sequenceNo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(requestId, sequenceNo);
    }

    public TblCodToken getCodToken() {
        return codToken;
    }

    public void setCodToken(TblCodToken codToken) {
        this.codToken = codToken;
    }
}
