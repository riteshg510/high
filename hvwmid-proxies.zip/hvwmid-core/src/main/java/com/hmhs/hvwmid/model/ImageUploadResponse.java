package com.hmhs.hvwmid.model;

/**
 * Response for image file upload
 */
public class ImageUploadResponse {
    
    private Integer requestId;
    private String filename;
    private String status;
    private String message;
    
    public ImageUploadResponse() {
    }

    public ImageUploadResponse(Integer requestId, String filename, String status, String message) {
        this.requestId = requestId;
        this.filename = filename;
        this.status = status;
        this.message = message;
    }

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}