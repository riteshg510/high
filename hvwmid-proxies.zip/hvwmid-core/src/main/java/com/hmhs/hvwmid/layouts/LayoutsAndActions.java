package com.hmhs.hvwmid.layouts;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblActions;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblPickListItems;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblSections;
import com.hmhs.hvwmid.model.Action;
import com.hmhs.hvwmid.model.BaseLayout;
import com.hmhs.hvwmid.model.ChoiceList;
import com.hmhs.hvwmid.model.Column;
import com.hmhs.hvwmid.model.Columns;
import com.hmhs.hvwmid.model.Form;
import com.hmhs.hvwmid.model.Property;
import com.hmhs.hvwmid.model.Section;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService;

import jakarta.persistence.Embeddable;
import jakarta.servlet.http.HttpServletRequest;

/**
 * @author Ramanjaneyulu Manam on Sept 17, 2024
 */
@Component
@Embeddable
public class LayoutsAndActions {

	@Autowired
	LoggerService loggerService;

	@Autowired
	private HttpServletRequest request;

	@Value("${controller.path.comn}")
	private String basePath;

	@Value("${controller.path.imi}")
	private String imiPath;

	@Value("${controller.path.common}")
	private String appBasePath;

	@Value("${controller.path.search}")
	private String searchPath;

	private static final Logger logger = LogManager.getLogger(LayoutsAndActions.class);
	private String string = HVWConstants.STRING;
	private String date1 = HVWConstants.YMD;
	private String flag = HVWConstants.FLAG;
	private AppDataService service;

	public AppDataService getService() {
		return service;
	}

	public void setService(AppDataService service) {
		this.service = service;
	}

	/**
	 * Get Actions and Layout from service by FormId
	 * 
	 * @param FormId
	 * @return
	 */
	public Form getLayoutAndActions(String fid) {
		Form form = new Form();
		form.setActions(getActionsByFormId(fid.startsWith("IMI") ? fid.substring(4) : fid));
		form.setLayout(getLayoutsByFormId(fid));
		return form;
	}

	/**
	 * Get Actions from service by FormId
	 * 
	 * @param FormId
	 * @return
	 */
	List<Action> getActionsByFormId(String fid) {
		List<Action> actionsList = new ArrayList<>();
		Action option = null;
		List<TblActions> listTblActions = null;
		try {
			listTblActions = service.getActionsByFormId(fid);
			for (TblActions adata : listTblActions) {
				option = new Action();
				option.setActionName(adata.getAction());
				option.setActionIcon(adata.getActionIcon());
				option.setActionType(adata.getActionType());
				option.setApiUrl(adata.getApiUrl().startsWith("list") ? searchPath + "/" + adata.getApiUrl()
						: adata.getApiUrl());
				option.setLabel(adata.getLabel());
				option.setNavigateUrl(getUpdatedUrl(adata.getNavigateUrl()));
				option.setVariant(adata.getVariant());
				option.setTableId(adata.getTableId());
				actionsList.add(option);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			loggerService.log("ERROR", 0, 0, 0, "", "getActionsByFormId()", request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
		}
		return actionsList;
	}

	String getUpdatedUrl(String navigateUrl) {
		String updatedUrl = navigateUrl;
		if (navigateUrl.contains("html") || navigateUrl.contains("name")) {
			if (navigateUrl.contains("ImgSessionMgr")) {
				Map<String, String> queryParams = getQueryMap(navigateUrl);
				StringBuilder redirectUrl = new StringBuilder("");
				StringBuilder idUrl = new StringBuilder("");
				if (!queryParams.isEmpty()) {
					queryParams.forEach((key, value) -> {
						if (key.equalsIgnoreCase(HVWConstants.TEMPLATE)) {
							List<TblForms> form = service.getFormIdByFileName(value.replaceFirst("[.][^.]+$", ""));
							if (!form.isEmpty()) {
								if (value.toLowerCase().contains("work"))
									idUrl.append(HVWConstants.WORKFLOW + form.get(0).getFormId() + "?");
								else if (value.toLowerCase().contains("scan"))
									idUrl.append(HVWConstants.CABINETSCAN + form.get(0).getFormId() + "?");
								else
									idUrl.append(HVWConstants.SINGLECABINET + form.get(0).getFormId() + "?");
							} else
								idUrl.append("pages/ImgSessionMgr?" + key).append("=").append(value).append("&");
						} else if (key.equalsIgnoreCase(HVWConstants.CMODFOLDERNAME)) {
							idUrl.append(HVWConstants.SINGLEREPORT + value).append("?");
						} else
							redirectUrl.append(key.replace("ImgSessionMgr?", "")).append("=").append(value).append("&");
					});
					// Remove the last "&"
					if (redirectUrl.length() > 0)
						redirectUrl.setLength(redirectUrl.length() - 1);
					updatedUrl = idUrl + redirectUrl.toString();
					if (updatedUrl.endsWith("?"))
						updatedUrl = updatedUrl.substring(0, updatedUrl.length() - 1);
				}
			} else {
				List<TblForms> form = service.getFormIdByFileName(navigateUrl.replaceFirst("[.][^.]+$", ""));
				if (!form.isEmpty()) {
					if (navigateUrl.toLowerCase().contains("work"))
						updatedUrl = HVWConstants.WORKFLOW + form.get(0).getFormId();
					else if (navigateUrl.toLowerCase().contains("scan"))
						updatedUrl = HVWConstants.CABINETSCAN + form.get(0).getFormId();
					else
						updatedUrl = HVWConstants.SINGLECABINET + form.get(0).getFormId();
				}
			}
		}
		return updatedUrl;
	}

	/**
	 * Extracts query parameters from a URL-like string.
	 * 
	 * @param urlString The string containing query parameters.
	 * @return A map of query parameter names to their values.
	 */
	public static Map<String, String> getQueryMap(String urlString) {
		Map<String, String> queryParams = new HashMap<>();
		try {
			int queryStart = urlString.indexOf("?");
			if (queryStart == -1 || queryStart >= urlString.length() - 1) {
				return queryParams; // No query string found
			}
			// Extract query part and ignore URL fragments (#)
			String query = urlString.substring(queryStart + 1).split("#")[0];
			query = URLDecoder.decode(query, StandardCharsets.UTF_8);
			// Process key-value pairs
			for (String param : query.split("&")) {
				String[] keyValue = param.split("=", 2); // Split into max 2 parts
				String key = keyValue[0].trim();
				String value = keyValue.length > 1 ? keyValue[1].trim() : "";
				queryParams.put(key, value);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return queryParams;
	}

	/**
	 * Get Layouts from service by FormId
	 * 
	 * @param FormId
	 * @return
	 */
	List<Section> getLayoutsByFormId(String fid) {
		List<Section> layout = new ArrayList<>();
		Section section = new Section();
		Boolean isIMIForm = false;
		if (fid.startsWith("IMI")) {
			fid = fid.substring(4);
			isIMIForm = true;
		}
		try {
			// Get Layout
			List<TblSections> listLayouts = service.getSections(fid);
			for (TblSections sdata : listLayouts) {
				Short isRoot = sdata.getIsRoot();
				if (isRoot == 1) {
					section.setLayoutType("section");
					section.setCollapsible(false);
					section.setDefaultCollapsed(false);
					section.setId(sdata.getSectionId());
					section.setSid(sdata.getSectionId());
					List<TblSections> listSections = service.getSectionsByParentSectionId(sdata.getSectionId(),
							sdata.getFormId());
					if (listSections.isEmpty()) {
						List<TblSectionDetails> fieldProps = service.getSectionDetailsBySectionId(sdata.getSectionId());
						if (isIMIForm) {
							section.setChildren(createChildPropertyColumnsByRow(
									service.getSectionDetailsBySectionIdOrderByFieldOrderAsc(sdata.getSectionId())));
						} else {
							section.setChildren(createChildPropertyColumnsByColumn(fieldProps));
						}
					} else {
						layout = createChildSections(listSections, isIMIForm);
					}
				}
			}

		} catch (Exception e) {
			logger.error(e.getMessage());
			loggerService.log("ERROR", 0, 0, 0, "", "getLayoutsByFormId()", request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
		}
		if (layout.isEmpty())
			layout.add(section);
		return layout;
	}

	List<Section> createChildSections(List<TblSections> listSections, Boolean isIMIForm) {
		List<Section> sections = new ArrayList<>();
		Section section = null;
		for (TblSections sdata : listSections) {
			section = createChildSection(sdata, isIMIForm);
			sections.add(section);
		}
		return sections;
	}

	Columns createChildSectionColumns(List<TblSections> listSections, Boolean isIMIForm) {
		Columns columns = new Columns();
		List<Column> children = new ArrayList<>();
		Column column = null;
		int col = -1;
		Section section = null;
		List<BaseLayout> sections = new ArrayList<>();
		for (TblSections sdata : listSections) {
			if (sdata.getParentColumnNumber() > col) {
				col = sdata.getParentColumnNumber();
				if (column != null) {
					column.setChildren(sections);
					children.add(column);
					sections = new ArrayList<>();
				}
				column = new Column();
			}
			section = createChildSection(sdata, isIMIForm);
			sections.add(section);
		}
		if (column != null)
			column.setChildren(sections);
		children.add(column);
		columns.setChildren(children);
		return columns;
	}

	Section createChildSection(TblSections sdata, Boolean isIMIForm) {
		Section section = new Section();
		section.setCollapsible(false);
		section.setDefaultCollapsed(false);
		section.setId(sdata.getFormId());
		section.setSid(sdata.getSectionId());
		section.setName(sdata.getSectionName());
		List<TblSections> listSections = service.getSectionsByParentSectionId(sdata.getSectionId(), sdata.getFormId());
		if (listSections.isEmpty()) {
			List<TblSectionDetails> fieldProps = service.getSectionDetailsBySectionId(sdata.getSectionId());
			if (isIMIForm)
				section.setChildren(createChildPropertyColumnsByRow(
						service.getSectionDetailsBySectionIdOrderByFieldOrderAsc(sdata.getSectionId())));
			else
				section.setChildren(createChildPropertyColumnsByColumn(fieldProps));
		} else {
			section.setChildren(createChildSectionColumns(listSections, isIMIForm));
		}
		return section;
	}

	private Columns createChildPropertyColumnsByColumn(List<TblSectionDetails> fieldProps) {
		Columns columns = new Columns();
		List<Column> children = new ArrayList<>();
		Column column = null;
		BigDecimal col = new BigDecimal("-1.0");
		Property property = null;
		List<BaseLayout> properties = new ArrayList<>();
		for (TblSectionDetails propData : fieldProps) {
			if (propData.getColumnNumber().compareTo(col) > 0) {
				col = propData.getColumnNumber();
				if (column != null) {
					column.setChildren(properties);
					children.add(column);
					properties = new ArrayList<>();
				}
				column = new Column();
			}
			property = createProperty(propData);
			properties.add(property);
		}
		if (column != null)
			column.setChildren(properties);
		children.add(column);
		columns.setChildren(children);
		return columns;
	}

	private List<Columns> createChildPropertyColumnsByRow(List<TblSectionDetails> fieldProps) {
		List<Columns> columnsList = new ArrayList<>();
		Columns columns = null;
		List<Column> children = null;
		Column column = null;
		BigDecimal col = new BigDecimal("1.00");
		Property property = null;
		List<BaseLayout> properties = null;
		for (TblSectionDetails propData : fieldProps) {
			if (propData.getColumnNumber().compareTo(col) == 0) {
				if (columns != null) {
					columns.setChildren(children);
					columnsList.add(columns);
				}

				columns = new Columns();
				column = new Column();
				children = new ArrayList<>();
				property = createProperty(propData);
				properties = new ArrayList<>();
				properties.add(property);
				column.setChildren(properties);
				children.add(column);
			} else if (propData.getColumnNumber().compareTo(col) > 0) {
				column = new Column();
				property = createProperty(propData);
				properties = new ArrayList<>();
				properties.add(property);
				column.setChildren(properties);
				children.add(column);
			}
		}
		if (columns != null) {
			columns.setChildren(children);
			columnsList.add(columns);
		}
		return columnsList;
	}

	public Property createProperty(TblSectionDetails propData) {
		Property property = new Property();
		property.setDescription(propData.getNotes());
		property.setDisplay("$$ return " + ((propData.getVisible() == 1) ? true : false));
		property.setName(propData.getLabel());
		if (propData.getFieldName() != null && propData.getFieldName().length() > 1)
			property.setId(propData.getFieldName().replace(" ", ""));
		else
			property.setId(propData.getFieldId());
		property.setLayoutType("property");
		property.setReadonly((propData.getReadOnly() == 1) ? true : false);
		property.setRequired("$$ return " + ((propData.getRequired() == 1) ? true : false));
		String defaultData = propData.getDefaultValue();
		if (defaultData != null && !defaultData.isEmpty()) {
			String jsValue = null;
			String defaultVal = null;
			if (defaultData.contains("##")) {
				String[] parts = defaultData.split("##");
				for (String part : parts) {
					part = part.trim();
					if (part.contains("$set$")) {
						jsValue = part;
					} else {
						defaultVal = part;
					}
				}
			} else if (defaultData.contains("$set$")) {
				jsValue = defaultData.trim();
				defaultVal = "";
			} else {
				defaultVal = defaultData.trim();
			}
			if (jsValue != null) {
				property.setJs(jsValue);
			}
			if (defaultVal != null) {
				property.setDefaultValue(defaultVal);
				propData.setDefaultValue(defaultVal);
			}
		}

		int fieldType = propData.getFieldType();
		switch (fieldType) {
			case 0: { // "Button"
				property.setType(flag);
				property.setInputType("button");
				break;
			}
			case 1: { // "Checkbox"
				property.setChoiceList(getChoiceList(propData.getPickListOptions()));
				property.setChoiceListMultiSelect(true);
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase("")) {
					String[] defaultValues = propData.getDefaultValue().split(",");
					List<String> al = new ArrayList<>();
					for (int i = 0; i < defaultValues.length; i++) {
						al.add(i, defaultValues[i].replace(" ", ""));
					}
					property.setDefaultValue(al);
				}
				property.setInputType("inputgroup");
				property.setMultiline(false);
				property.setType(string);
				if (propData.getLabel() != null && propData.getLabel().length() < 3) {
					property.setName(null);
				}
				if (propData.getPickListOptions() == null || propData.getPickListOptions().equalsIgnoreCase("")) {
					property.setInputType("checkbox");
					property.setType(flag);
				}
				break;
			}
			case 2: { // "Date"
				property.setAllowFutureDate((propData.getMultiSelect() == 1) ? true : false);
				if (propData.getMaximum() > 0)
					property.setMaxLength(propData.getMaximum());
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase("")) {
					if (propData.getDefaultValue().toLowerCase().contains("today")
							|| propData.getDefaultValue().toLowerCase().contains("current")) {
						property.setDefaultValue(new SimpleDateFormat("yyyyMMdd").format(new Date()));
					} else {
						property.setDefaultValue(propData.getDefaultValue());
					}
				}
				property.setInputType("date");
				property.setType("date");
				if (propData.getValidationRules().contains("MMDDYYYY")
						|| propData.getValidationRules().contains("MMDDCCYY")) {
					property.setDateFormat("MMDDYYYY");
					property.setPattern("(?:0[1-9]|1[012])(?:0[1-9]|[12][0-9]|3[01])((?:19|20)[0-9][0-9])");
					property.setPatternMessage(propData.getValidationMessage());
				} else if (propData.getValidationRules().contains(date1)
						|| propData.getValidationRules().contains("CCYYMMDD")) {
					property.setDateFormat(date1);
					property.setPattern("((?:19|20)[0-9][0-9])(?:0[1-9]|1[012])(?:0[1-9]|[12][0-9]|3[01])");
					property.setPatternMessage(propData.getValidationMessage());
				} else if (propData.getValidationRules().equalsIgnoreCase("")) {
					property.setDateFormat(date1);
				} else {
					if (propData.getValidationRules().contains("MMDD") || propData.getValidationRules().contains("DDMM")
							|| propData.getValidationRules().contains("MM/DD")
							|| propData.getValidationRules().contains("DD/MM")
							|| propData.getValidationRules().contains("MM-DD")
							|| propData.getValidationRules().contains("DD-MM"))
						property.setDateFormat(propData.getValidationRules());
					property.setPattern(propData.getValidationRules());
					property.setPatternMessage(propData.getValidationMessage());
				}
				break;
			}
			case 3: { // "DateTime"
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase(""))
					property.setDefaultValue(propData.getDefaultValue());

				property.setInputType("datetime");
				property.setType("datetime");
				break;
			}
			case 4: { // "Hidden"
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase(""))
					property.setDefaultValue(propData.getDefaultValue());
				property.setDisplay("$$ return " + false);
				property.setInputType("hidden");
				property.setMultiline(false);
				property.setType(string);
				break;
			}
			case 5: { // "Integer"
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase(""))
					property.setDefaultValue(Integer.parseInt(propData.getDefaultValue()));
				property.setExample("10");
				if (propData.getMaximum() > 0)
					property.setMaxValue(propData.getMaximum());
				property.setMinValue(propData.getMinimum());
				property.setType("integer");
				break;
			}
			case 6: { // "Lookup"
				property.setChoiceListMultiSelect((propData.getMultiSelect() == 1) ? true : false);
				property.setInputType("lookup");
				property.setMultiline(false);
				property.setType(string);
				if (propData.getMaximum() > 0)
					property.setMaxLength(propData.getMaximum());
				property.setMinLength(propData.getMinimum());
				property.setPattern(propData.getValidationRules());
				property.setPatternMessage(propData.getValidationMessage());
				if (propData.getPickListId().equalsIgnoreCase("lookup") && propData.getPickListOptions() != null
						&& propData.getPickListOptions().contains("?")) {
					property.setLookupApi(propData.getPickListOptions());
				} else if (propData.getPickListId() != null && !propData.getPickListId().equalsIgnoreCase("")) {
					if (propData.getPickListOrder() == 0) {
						property.setChoiceList(getChoiceListByID(propData.getPickListId()));
					} else {
						List<String> dependentParent = new ArrayList<>();
						StringBuilder sApi = new StringBuilder();
						sApi.append(basePath + "/lookup/" + propData.getFieldName());
						List<String> dependentChild = service.getChildList(propData.getSectionId(),
								propData.getFieldName());
						if (propData.getIsDependentOn() != null && !propData.getIsDependentOn().equalsIgnoreCase("")) {
							String[] dependentOn = propData.getIsDependentOn().replace(" ", "").split(",");
							for (int i = 0; i < dependentOn.length; i++) {
								dependentParent.add(i, dependentOn[i]);
								sApi.append("/{" + dependentOn[i] + "}");
							}
						}
						property.setLookupApi(sApi.append("/{" + property.getId() + "}").toString());
						if (!dependentParent.isEmpty())
							property.setParentFields(dependentParent);
						if (!dependentChild.isEmpty())
							property.setChildFields(dependentChild);
					}

				} else {
					// property.setChoiceList(getChoiceList(propData.getPickListOptions()));
					property.setLookupApi(
							basePath + "/lookup/" + propData.getFieldName() + "/{" + property.getId() + "}");
				}
				break;
			}
			case 7: { // "Number"
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase(""))
					property.setDefaultValue(Double.parseDouble(propData.getDefaultValue()));
				property.setExample("10.5");
				if (propData.getMaximum() > 0)
					property.setMaxValue(propData.getMaximum());
				property.setMinValue(propData.getMinimum());
				property.setType("number");
				break;
			}
			case 8: { // "Radio"
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase("")) {
					String[] defaultValue = propData.getDefaultValue().split(",");
					List<String> al = new ArrayList<>();
					for (int i = 0; i < defaultValue.length; i++) {
						al.add(0, defaultValue[i].replace(" ", ""));
					}
					property.setDefaultValue(al);
				}
				property.setChoiceList(getChoiceList(propData.getPickListOptions()));
				property.setChoiceListMultiSelect(false);
				property.setInputType("inputgroup");
				property.setMultiline(false);
				property.setType(string);
				break;
			}
			case 9: { // "Select"
				property.setChoiceListMultiSelect((propData.getMultiSelect() == 1) ? true : false);
				property.setInputType("select");
				property.setMultiline(false);
				property.setType(string);
				if (propData.getPickListId() != null && !propData.getPickListId().equalsIgnoreCase("")) {
					if (propData.getPickListOrder() == 0) {
						property.setChoiceList(getChoiceListByID(propData.getPickListId()));
					} else {
						List<String> dependentParent = new ArrayList<>();
						StringBuilder sApi = new StringBuilder();
						sApi.append(basePath + "/get-picklist/" + propData.getPickListId());
						List<String> dependentChild = service.getChildList(propData.getSectionId(),
								propData.getFieldName());
						if (propData.getIsDependentOn() != null && !propData.getIsDependentOn().equalsIgnoreCase("")) {
							String[] dependentOn = propData.getIsDependentOn().replace(" ", "").split(",");
							for (int i = 0; i < dependentOn.length; i++) {
								dependentParent.add(i, dependentOn[i]);
								sApi.append("/{" + dependentOn[i] + "}");
							}
						}
						property.setChoicelistApi(sApi.toString());
						if (!dependentParent.isEmpty())
							property.setParentFields(dependentParent);
						if (!dependentChild.isEmpty())
							property.setChildFields(dependentChild);
					}

				} else if (propData.getPickListOptions().startsWith("customChoiceList")) {
					property.setChoicelistApi(propData.getPickListOptions().substring(17));
				} else
					property.setChoiceList(getChoiceList(propData.getPickListOptions()));
				break;
			}
			case 10: { // "StaticHTML"
				String fieldName = Optional.ofNullable(propData.getFieldName()).orElse("").trim();
				property.setId(fieldName.length() > 1 ? fieldName.replace(" ", "") : propData.getFieldId());

				String defaultValue = Optional.ofNullable(propData.getDefaultValue()).orElse("").toString();

				if (defaultValue.contains("template") && defaultValue.contains("href")) {
					property.setHtmlText(updateAnchorTags(defaultValue));
				} else {
					property.setHtmlText(defaultValue);
				}

				property.setDefaultValue("");
				property.setType("statichtml");
				property.setLayoutType("text");
				break;
			}
			case 11: { // "Switch"
				property.setInputType("switch");
				property.setType(flag);
				property.setTrueLabel("yes");
				property.setFalseLabel("no");
				break;
			}
			case 12: { // "Text"
				if (propData.getDefaultValue() != null) {
					property.setDefaultValue(propData.getDefaultValue());
				}
				property.setInputType("text");
				if (propData.getMaximum() > 0)
					property.setMaxLength(propData.getMaximum());
				property.setMinLength(propData.getMinimum());
				property.setMultiline(false);
				property.setPattern(propData.getValidationRules());
				property.setPatternMessage(propData.getValidationMessage());
				property.setType(string);
				break;
			}
			case 13: { // "Textarea"
				if (propData.getDefaultValue() != null)
					property.setDefaultValue(propData.getDefaultValue());
				property.setInputType("textarea");
				if (propData.getMaximum() > 0)
					property.setMaxLength(propData.getMaximum());
				property.setMinLength(propData.getMinimum());
				property.setMultiline(true);
				property.setPattern(propData.getValidationRules());
				property.setPatternMessage(propData.getValidationMessage());
				property.setType(string);
				break;
			}
			case 14: { // "Boolean"
				if (propData.getDefaultValue() != null && !propData.getDefaultValue().equalsIgnoreCase("")) {
					String[] defaultValue = propData.getDefaultValue().split(",");
					List<String> al = new ArrayList<>();
					for (int i = 0; i < defaultValue.length; i++) {
						al.add(0, defaultValue[i].replace(" ", ""));
					}
					property.setDefaultValue(al);
				}
				property.setChoiceListMultiSelect(false);
				property.setInputType("radiogroup");
				property.setMultiline(false);
				property.setTrueLabel("Yes");
				property.setFalseLabel("No");
				property.setType(flag);
				break;
			}
			case 15: { // "StaticData"
				if (propData.getFieldName() != null && propData.getFieldName().length() > 1)
					property.setId(propData.getFieldName().replace(" ", ""));
				else
					property.setId(propData.getFieldId());
				if (propData.getDefaultValue() != null)
					property.setHtmlText(
							updateAnchorTags(new String(propData.getHtmlContent(), StandardCharsets.UTF_8)));
				// .replaceAll("ImgSessionMgr", basePath + "/ImgSessionMgr"));
				else
					property.setHtmlText("");
				property.setType("statichtml");
				property.setLayoutType("text");
				break;
			}
			case 16: { // "file"
				property.setMultiple((propData.getMultiSelect() == 1) ? true : false);
				property.setType("file");
				break;
			}
			default:
				property.setType("None");
		}

		if (propData.getName() != null && !propData.getName().equals("")) {
			property.setName(propData.getName());
		}
		if (propData.getDisplayExp() != null && !propData.getDisplayExp().equals("")) {
			property.setDisplay(propData.getDisplayExp());
		}
		if (propData.getRequiredExp() != null && !propData.getRequiredExp().equals("")) {
			property.setRequired(propData.getRequiredExp());
		}

		return property;
	}

	/**
	 * @param pickListId
	 * @return
	 */
	List<ChoiceList> getChoiceListByID(String pickListId) {
		List<ChoiceList> choiceList = new ArrayList<>();
		ChoiceList option;
		try {
			// list the Section Id's
			List<TblPickListItems> tblChoiceItems = service.getPickList(pickListId);
			for (TblPickListItems sdata : tblChoiceItems) {
				option = new ChoiceList();
				option.setKey(sdata.getKey());
				option.setDisplayName(sdata.getDisplayName());
				choiceList.add(option);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			loggerService.log("ERROR", 0, 0, 0, "", "getChoiceListByID()", request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
		}
		return choiceList;
	}

	/**
	 * @param pickListOptions
	 * @return
	 */
	public List<ChoiceList> getChoiceList(String sPickListOptions) {
		List<ChoiceList> choiceList = new ArrayList<>();
		if (sPickListOptions != null) {
			sPickListOptions = sPickListOptions.replace("\n", "");
			sPickListOptions = sPickListOptions.replace(",,", ",");
			sPickListOptions = sPickListOptions.trim();

			ChoiceList option = null;
			String[] strArray = sPickListOptions.split(",");
			for (int i = 0; i < strArray.length; i++) {
				option = new ChoiceList();
				if (strArray[i].contains("(")) {
					option.setKey(StringUtils.substringBetween(strArray[i], "(", ")").replace(" ", ""));
					option.setDisplayName(strArray[i].substring(0, strArray[i].indexOf("(")).trim());
				} else {
					option.setKey(strArray[i].replace(" ", ""));
					option.setDisplayName(strArray[i].trim());
				}
				choiceList.add(option);
			}
		}
		return choiceList;
	}

	public String updateAnchorTags(String defaultValue) {
		// Pattern anchorPattern =
		// Pattern.compile("<a[^>]*href\\s*=\\s*['\"](.*?)['\"][^>]*>.*?</a>",
		// Pattern.CASE_INSENSITIVE);
		Pattern hrefPattern = Pattern.compile("href\\s*=\\s*['\"](.*?)['\"]",
				Pattern.CASE_INSENSITIVE);
		Matcher matcher = hrefPattern.matcher(defaultValue);
		StringBuffer result = new StringBuffer();

		while (matcher.find()) {
			String originalHref = matcher.group(1);
			String updatedHref = getUpdatedUrl(originalHref);
			String updatedAnchor = matcher.group().replace(originalHref, updatedHref);
			matcher.appendReplacement(result, Matcher.quoteReplacement(updatedAnchor));
		}

		matcher.appendTail(result);
		return result.toString();
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public void setSearchPath(String searchPath) {
		this.searchPath = searchPath;
	}
}