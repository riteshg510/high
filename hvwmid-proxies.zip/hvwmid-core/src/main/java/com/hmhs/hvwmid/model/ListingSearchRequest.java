package com.hmhs.hvwmid.model;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

@Data
public class ListingSearchRequest {

    // Context
    private String mainSchema;
    private String batchtblschema;
    private List<Integer> userApplids;
    private Integer limit;

    // ---------------- ENTTTLPR (LPR) ----------------
    private Long    lprApplIdCdQuery;
    private Boolean lprApplIdCdDisplay;              // "na"

    private String  lprApplIdQuery;
    private Boolean lprApplIdDisplay;
    private String  lprApplIdSearchOperator;

    // ---------------- ENTTTAPR (APR) ----------------
    private String  aprSecResClassQuery;
    private Boolean aprSecResClassDisplay;
    private String  aprSecResClassSearchOperator;

    private String  aprDb2CollectionQuery;
    private Boolean aprDb2CollectionDisplay;
    private String  aprDb2CollectionSearchOperator;

    private String  aprDefaultIODMQuery;
    private Boolean aprDefaultIODMDisplay;
    private String  aprDefaultIODMSearchOperator;

    // ---------------- T222APRM (PRM) ----------------
    private String  parmDataQuery;
    private Boolean parmDataDisplay;
    private String  parmDataSearchOperator;

    // ---------------- BATCHTBL (TBL) ----------------
    private Long    tblBatchIdQuery;
    private Boolean tblBatchIdDisplay;
    private String  tblBatchIdSearchOperator;

    private String  tblFormNumQuery;
    private Boolean tblFormNumDisplay;
    private String  tblFormNumSearchOperator;

    private String  tblBDescriptionQuery;
    private Boolean tblBDescriptionDisplay;
    private String  tblBDescriptionSearchOperator;

    private String  tblFileTabQuery;
    private Boolean tblFileTabDisplay;
    private String  tblFileTabSearchOperator;

    private String  tblBRouteFlagQuery;
    private Boolean tblBRouteFlagDisplay;
    private String  tblBRouteFlagSearchOperator;

    private String  tblBRLOBQuery;
    private Boolean tblBRLOBDisplay;
    private String  tblBRLOBSearchOperator;

    private String  tblBTranTypeQuery;
    private Boolean tblBTranTypeDisplay;
    private String  tblBTranTypeSearchOperator;

    private String  tblBUnitCodeQuery;
    private Boolean tblBUnitCodeDisplay;
    private String  tblBUnitCodeSearchOperator;

    private String  tblBRouteCodeQuery;
    private Boolean tblBRouteCodeDisplay;
    private String  tblBRouteCodeSearchOperator;

    private Long    tblBPriorityQuery;
    private Boolean tblBPriorityDisplay;             // "na"

    // ---------------- T117A001 (A01) ----------------
    private Long    a01BatchIdQuery;
    private Boolean a01BatchIdDisplay;
    private String  a01BatchIdSearchOperator;

    private String  a01FormNumQuery;
    private Boolean a01FormNumDisplay;
    private String  a01FormNumSearchOperator;

    private String  a01RunitQuery;
    private Boolean a01RunitDisplay;                 // "na"

    private String  a01RcodeQuery;
    private Boolean a01RcodeDisplay;
    private String  a01RcodeSearchOperator;

    private String  a01RouteFlagQuery;
    private Boolean a01RouteFlagDisplay;
    private String  a01RouteFlagSearchOperator;

    private Long    a01PriorityQuery;
    private Boolean a01PriorityDisplay;              // "na"

    private String  a01FileTabQuery;
    private Boolean a01FileTabDisplay;
    private String  a01FileTabSearchOperator;

    private String  a01CommentQuery;
    private Boolean a01CommentDisplay;
    private String  a01CommentSearchOperator;

    private String  a01ScanExitQuery;
    private Boolean a01ScanExitDisplay;
    private String  a01ScanExitSearchOperator;

    private String  a01DpkQuery;
    private Boolean a01DpkDisplay;
    private String  a01DpkSearchOperator;

    private String  a01NaicCodeQuery;
    private Boolean a01NaicCodeDisplay;
    private String  a01NaicCodeSearchOperator;

    // ---------------- ENTTTFRM (FRM) ----------------
    private String  frmFormNumQuery;
    private Boolean frmFormNumDisplay;
    private String  frmFormNumSearchOperator;

    private String  frmFormCdQuery;
    private Boolean frmFormCdDisplay;                // "na"

    private String  frmRLOBQuery;
    private Boolean frmRLOBDisplay;
    private String  frmRLOBSearchOperator;

    private String  frmTranTypeQuery;
    private Boolean frmTranTypeDisplay;
    private String  frmTranTypeSearchOperator;

    private String  frmObjDescQuery;
    private Boolean frmObjDescDisplay;
    private String  frmObjDescSearchOperator;

    private String  frmSpreadingGrpQuery;
    private Boolean frmSpreadingGrpDisplay;
    private String  frmSpreadingGrpSearchOperator;

    private String  frmRetentionGrpQuery;
    private Boolean frmRetentionGrpDisplay;
    private String  frmRetentionGrpSearchOperator;

    // ---------------- ENTTTFTB (FTB) ----------------
    private String  ftbFileTabQuery;
    private Boolean ftbFileTabDisplay;
    private String  ftbFileTabSearchOperator;

    private String  ftbFileTabCdQuery;
    private Boolean ftbFileTabCdDisplay;             // "na"

    // ---------------- EYPTWRTT (RTT) ----------------
    private String  rttRLOBQuery;
    private Boolean rttRLOBDisplay;
    private String  rttRLOBSearchOperator;

    private String  rttTranTypeQuery;
    private Boolean rttTranTypeDisplay;
    private String  rttTranTypeSearchOperator;

    private String  rttUserPrm1Query;
    private Boolean rttUserPrm1Display;
    private String  rttUserPrm1SearchOperator;

    private String  rttCatWorkQuery;
    private Boolean rttCatWorkDisplay;
    private String  rttCatWorkSearchOperator;

    private String  rttRcodeQuery;
    private Boolean rttRcodeDisplay;
    private String  rttRcodeSearchOperator;

    // ---------------- EYPTWUNT (UNT) ----------------
    private String  untRunitQuery;
    private Boolean untRunitDisplay;                 // "na"

    private String  untUserPrm1Query;
    private Boolean untUserPrm1Display;
    private String  untUserPrm1SearchOperator;

    private String  untCatWorkQuery;
    private Boolean untCatWorkDisplay;
    private String  untCatWorkSearchOperator;

    // ---------------- EYPTWURC (URC) ----------------
    private String  urcRunitQuery;
    private Boolean urcRunitDisplay;                 // "na"

    private String  urcRcodeQuery;
    private Boolean urcRcodeDisplay;
    private String  urcRcodeSearchOperator;

    private String  urcQueueDescQuery;
    private Boolean urcQueueDescDisplay;
    private String  urcQueueDescSearchOperator;


    public void normalize() {

        this.a01FormNumQuery   = rtrimToNull(this.a01FormNumQuery);
        this.frmFormNumQuery   = rtrimToNull(this.frmFormNumQuery);
        this.tblFormNumQuery   = rtrimToNull(this.tblFormNumQuery);
        this.urcQueueDescQuery = rtrimToNull(this.urcQueueDescQuery);



        this.lprApplIdQuery = ttn(this.lprApplIdQuery);
        this.aprSecResClassQuery = ttn(this.aprSecResClassQuery);
        this.aprDb2CollectionQuery = ttn(this.aprDb2CollectionQuery);
        this.aprDefaultIODMQuery = ttn(this.aprDefaultIODMQuery);
        this.parmDataQuery = ttn(this.parmDataQuery);
        this.tblBDescriptionQuery = ttn(this.tblBDescriptionQuery);
        this.tblFileTabQuery = ttn(this.tblFileTabQuery);
        this.tblBRouteFlagQuery = ttn(this.tblBRouteFlagQuery);
        this.tblBRLOBQuery = ttn(this.tblBRLOBQuery);
        this.tblBTranTypeQuery = ttn(this.tblBTranTypeQuery);
        this.tblBUnitCodeQuery = ttn(this.tblBUnitCodeQuery);
        this.tblBRouteCodeQuery = ttn(this.tblBRouteCodeQuery);
        this.a01RunitQuery = ttn(this.a01RunitQuery);
        this.a01RcodeQuery = ttn(this.a01RcodeQuery);
        this.a01RouteFlagQuery = ttn(this.a01RouteFlagQuery);
        this.a01FileTabQuery = ttn(this.a01FileTabQuery);
        this.a01CommentQuery = ttn(this.a01CommentQuery);
        this.a01ScanExitQuery = ttn(this.a01ScanExitQuery);
        this.a01DpkQuery = ttn(this.a01DpkQuery);
        this.a01NaicCodeQuery = ttn(this.a01NaicCodeQuery);
        this.frmFormCdQuery = ttn(this.frmFormCdQuery);
        this.frmRLOBQuery = ttn(this.frmRLOBQuery);
        this.frmTranTypeQuery = ttn(this.frmTranTypeQuery);
        this.frmObjDescQuery = ttn(this.frmObjDescQuery);
        this.frmSpreadingGrpQuery = ttn(this.frmSpreadingGrpQuery);
        this.frmRetentionGrpQuery = ttn(this.frmRetentionGrpQuery);
        this.ftbFileTabQuery = ttn(this.ftbFileTabQuery);
        this.ftbFileTabCdQuery = ttn(this.ftbFileTabCdQuery);
        this.rttRLOBQuery = ttn(this.rttRLOBQuery);
        this.rttTranTypeQuery = ttn(this.rttTranTypeQuery);
        this.rttUserPrm1Query = ttn(this.rttUserPrm1Query);
        this.rttCatWorkQuery = ttn(this.rttCatWorkQuery);
        this.rttRcodeQuery = ttn(this.rttRcodeQuery);
        this.untRunitQuery = ttn(this.untRunitQuery);
        this.untUserPrm1Query = ttn(this.untUserPrm1Query);
        this.untCatWorkQuery = ttn(this.untCatWorkQuery);
        this.urcRunitQuery = ttn(this.urcRunitQuery);
        this.urcRcodeQuery = ttn(this.urcRcodeQuery);
    }

    private static String ttn(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }
    private static String rtrimToNull(String s) {
        if (s == null) return null;
        String rt = StringUtils.stripEnd(s, null);
        return (rt == null || rt.trim().isEmpty()) ? null : rt;
    }
}
