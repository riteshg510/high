package com.hmhs.hvwmid.service;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.constants.ImgGlobals2;
import com.hmhs.hvwmid.constants.ImgGlobals2Constants;
import com.hmhs.hvwmid.constants.ImgGlobals2Constants.SearchReqMapping;
import com.hmhs.hvwmid.entity.T222ADSG;
import com.hmhs.hvwmid.model.IMISearchData;
import com.hmhs.hvwmid.model.IMISearchRequest;
import com.hmhs.hvwmid.model.IMISearchResults;
import com.hmhs.hvwmid.model.IMISegmentDataResult;
import com.hmhs.hvwmid.model.IMIUISearchRequest;
import com.hmhs.hvwmid.repository.T222ADSGRepository;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.ImgGlobals2Utils;
import com.hmhs.hvwmid.utils.RestClientUtil;

@Service
public class IMIActivityTrackingService {

	private static final Logger logger = LogManager.getLogger(IMIActivityTrackingService.class);
	private static final String ALLOW_MULTIPLE_SORT = "allowMultipleSort";
	private static final String ALLOW_RESIZE_COLUMNS = "allowResizeColumns";
	private static final String PAGINATION = "pagination";
	private static final String COLUMNS = "columns";
	private static final String ACTIONS = "actions";
	private static final String DEFINITION = "definition";
	private static final String ERROR = "error";

	// Constants for UI table properties
	private static final String PAGE_NUMBER = "pageNumber";
	private static final String PAGE_SIZE = "pageSize";
	private static final String ACTION = "action";
	private static final String STATUS = "status";
	private static final String NAVIGATE_URL = "navigateUrl";
	private static final String API_URL = "apiUrl";
	private static final String NAVIGATE = "navigate";
	private static final String LABEL = "label";
	private static final String URL_TARGET = "urlTarget";
	private static final String BLANK = "blank";
	private static final String ACTION_ICON = "actionIcon";
	private static final String ACTION_TYPE = "actionType";
	private static final String MAX_ACTIONS_TO_DISPLAY = "maxNumOfActionsToDisplay";

	// Default values
	private static final int DEFAULT_PAGINATION_ROW_COUNT = 250;
	private static final int DEFAULT_PAGE_SIZE = 20;
	private static final int DEFAULT_PAGE_NUMBER = 0;
	private static final int NO_OF_ACTIONS_TO_DISPLAY = 1;

	// Date format constants
	private static final String TRANSMIT_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.S";
	private static final String PARAMETER_DATE_FORMAT = "yyyy-MM-dd";

	private final ObjectMapper objectMapper = new ObjectMapper();
	private int paginationRowCount = 0;

	@Autowired
	private RestClientUtil restClientUtil;

	@Autowired
	private T222ADSGRepository t222ADSGRepository;

	@Autowired
	private ImageParmDataService imageParmDataService;

	@Value("${api.imi.imiRetrieve}")
	private String imiRetrieveBaseURL;

	@Value("${app.environment:default}")
	private String environment;

	@Value("${form.viewImage.id}")
	private String viewImageFormId;

	@Value("${form.viewImage.navigatePathIMG}")
	private String viewImageNavigatePath;

	@Value("${form.viewImage.param1}")
	private String viewImageFormParam1;

	@Value("${form.viewImage.param2}")
	private String viewImageFormParam2;

	@Value("${form.viewImage.param3}")
	private String viewImageFormParam3;

	@Value("${form.viewImage.param4}")
	private String viewImageFormParam4;

	@Value("${form.CMOD.navigatePathCMOD}")
	private String cmodNavigatePath;

	@Value("${form.CMOD.param1}")
	private String cmodParam1;

	@Value("${form.CMOD.param2}")
	private String cmodParam2;

	@Value("${imi-phi-access-ldap-group}")
	private String phiAccessLdapGroup;

	@Value("${api.imi.retrieveSegmentData}")
	private String imiRetrieveSegmentData;

	public IMISearchData imiOnLoad(String authToken) {

		IMISearchData searchData = new IMISearchData();
		// Check user group access
		List<String> ldapGroups = HVWUtils.getUserGroups(authToken);
		if (ldapGroups != null && !ldapGroups.isEmpty()) {
			Map<String, String> naicMap = HVWUtils.buildNAICMap(ldapGroups);
			searchData.setNaicMap(naicMap);
			if (naicMap.isEmpty()) {
				IMISearchData errorData = new IMISearchData();
				IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
				baseMessage.setReturnCodeDescription(
						"User does not have access to the IMI groups. Request access to the IMI groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->IMI Groups");
				errorData.setBaseMessage(baseMessage);
				errorData.setSearchResultsList(new ArrayList<>());
				return errorData;
			}
		}
		return searchData;

	}

	/**
	 * This method will retrieve the Activity Tracking UI results by calling the
	 * imiRetrieve webservice
	 * 
	 * @param session
	 * @param request
	 * @param response
	 */
	public Object imiRetrieve(String userId, IMIUISearchRequest imiuiSearchRequest, String authToken, String imiAction,
			String resultPointer, String imiRetrieveRowCount) {
		try {
			IMISearchRequest searchRequest = new IMISearchRequest();

			if (imiAction != null && !imiAction.trim().isEmpty()) {
				logger.info("IMIAction to be executed is =>{}<=", imiAction);
				if ("imiNextResults".equals(imiAction) || "imiPreviousResults".equals(imiAction)) {
					// Get the saved search criteria from the session
					if (resultPointer != null) {
						long resultSetPointer = Long.parseLong(resultPointer);
						logger.info("Resultset pointer for this request is =>{}<=", resultSetPointer);
						searchRequest.setResultSetPointer(resultSetPointer);
						searchRequest.setPaginationRowCount(Long.parseLong(imiRetrieveRowCount) + 1);
					}
				} else {
					Map<String, String> hvwParmMap = imageParmDataService.getParmDataMap(ImgGlobals2.PARMID_HVW_IMI);
					paginationRowCount = DEFAULT_PAGINATION_ROW_COUNT;
					// Get the result per page from T222APRM table
					if (hvwParmMap != null
							&& hvwParmMap.containsKey(HVWConstants.PARMKEY_ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT)) {
						paginationRowCount = Integer.parseInt(
								hvwParmMap.get(HVWConstants.PARMKEY_ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT));
						logger.debug("Results per page count in the T222APRM table is: {}", paginationRowCount);
					}
					// 1 is added to the pagination row count to decide whether to
					// display Next button on the screen
					searchRequest.setPaginationRowCount(paginationRowCount + 1);
				}
				searchRequest.setApplIdCdQuery(new ArrayList<Integer>());
				searchRequest.setNaicCode(imiuiSearchRequest.getNaicCode());
				if (!parseSearchDatesSafely(imiuiSearchRequest, searchRequest)) {
					return "";
				}
				processSearchCriteria(imiuiSearchRequest, searchRequest);

			} else {
			logger.fatal("imiAction parm is missing. We should never be here.");
				throw new IllegalArgumentException("imiAction parm missing in the request");
			}

			// Make the IMI API call
			IMISearchData searchData = callIMIApi(searchRequest, authToken);

			if (searchData != null && searchData.getBaseMessage() != null
					&& !"200".equalsIgnoreCase(searchData.getBaseMessage().getReturnCode())) {
				return searchData;
			}
			return convertToTableFormat(searchData, authToken, searchRequest);

		} catch (Exception e) {
			logger.error("Error Occurred while retrieving Activity Tracking Search Results.", e);
			// Return error response in structured format
			Map<String, Object> errorResponse = new LinkedHashMap<>();

			// Create minimal table definition for error case
			Map<String, Object> definition = new LinkedHashMap<>();
			definition.put(ALLOW_MULTIPLE_SORT, false);
			definition.put(ALLOW_RESIZE_COLUMNS, false);
			definition.put(PAGINATION, Map.of(PAGE_NUMBER, DEFAULT_PAGE_NUMBER, PAGE_SIZE, 10));
			definition.put("selectionMode", "multiple");
			definition.put(COLUMNS, new ArrayList<>());
			definition.put(ACTIONS, new ArrayList<>());

			errorResponse.put(DEFINITION, definition);
			errorResponse.put("data", new ArrayList<>());
			errorResponse.put(ERROR,
					"Error occurred while retrieving Activity Tracking Search Results: " + e.getMessage());

			return errorResponse;
		}
	}

	private boolean parseSearchDatesSafely(IMIUISearchRequest imiuiSearchRequest, IMISearchRequest imiSearchRequest) {
		try {
			parseSearchDates(imiuiSearchRequest, imiSearchRequest);
			return true;
		} catch (ParseException parseException) {
			logger.error("Error Occurred while parsing the Start Date or End Date.", parseException);
			return false;
		}
	}

	private void parseSearchDates(IMIUISearchRequest imiuiSearchRequest, IMISearchRequest imiSearchRequest)
			throws ParseException {
		String startDate = formatDateIfValid(imiuiSearchRequest.getBegindate());
		String startTimeHour = imiuiSearchRequest.getStartTimeHour();
		String startTimeMin = imiuiSearchRequest.getStartTimeMin();
		Date stDate = new SimpleDateFormat("MM/dd/yy HH:mm")
				.parse(startDate + " " + startTimeHour + ":" + startTimeMin);
		imiSearchRequest.setTransmitTimestampFrom(new SimpleDateFormat(TRANSMIT_TIMESTAMP_FORMAT).format(stDate));

		String endDate = formatDateIfValid(imiuiSearchRequest.getEnddate());
		String endTimeHour = imiuiSearchRequest.getEndTimeHour();
		String endTimeMin = imiuiSearchRequest.getEndTimeMin();
		Date edDate = new SimpleDateFormat("MM/dd/yy HH:mm").parse(endDate + " " + endTimeHour + ":" + endTimeMin);
		imiSearchRequest.setTransmitTimestampTo(new SimpleDateFormat(TRANSMIT_TIMESTAMP_FORMAT).format(edDate));
	}

	public static String formatDateIfValid(String inputDate) {

		if (inputDate == null || inputDate.length() != 8) {
			return inputDate; // Not 8 chars, skip
		}

		String[] candidatePatterns = { "MMddyyyy", "yyyyMMdd" };
		SimpleDateFormat outputFormat = new java.text.SimpleDateFormat("MM/dd/yy");
		for (String pattern : candidatePatterns) {
			try {
				SimpleDateFormat inputFormat = new java.text.SimpleDateFormat(pattern);
				inputFormat.setLenient(false);
				Date parsedDate = inputFormat.parse(inputDate);
				return outputFormat.format(parsedDate);
			} catch (java.text.ParseException ignored) {
				// try next pattern
			}
		}
		// If none of the patterns matched, return unchanged
		return inputDate;
	}

	private void processSearchCriteria(IMIUISearchRequest imiuiSearchRequest, IMISearchRequest imiSearchRequest) {
		boolean isProcessFileFields = false;

		SearchReqMapping[] reqMapping = SearchReqMapping.values();
		for (SearchReqMapping mapping : reqMapping) {
			String queryField = mapping.getQueryField();
			String displayField = mapping.getDisplayField();

			String paramValue = (String) ImgGlobals2Utils.getPropertyVal(imiuiSearchRequest, queryField);
			if (paramValue != null && HVWUtils.hasText(paramValue)) {
				ImgGlobals2Utils.setPropertyVals(imiSearchRequest, queryField, paramValue.trim());

				// Set the search operator if available
				String searchOpField = mapping.getSearchStringField();
				if (!"na".equals(searchOpField)) {
					String paramValueSearchOperator = (String) ImgGlobals2Utils.getPropertyVal(imiuiSearchRequest,
							searchOpField);
					String searchOpValue = "EXACT";
					if (paramValueSearchOperator != null && HVWUtils.hasText(paramValueSearchOperator)) {
						searchOpValue = paramValueSearchOperator;
					}
					ImgGlobals2Utils.setPropertyVals(imiSearchRequest, searchOpField, searchOpValue);
				}
			}

			Object displayFieldVal = ImgGlobals2Utils.getPropertyVal(imiuiSearchRequest, displayField);
			if (displayFieldVal != null && displayFieldVal.toString().equalsIgnoreCase("true")) {
				String alias = mapping.getAlias();
				if ("PF".equals(alias)) {
					isProcessFileFields = true;
				}
				ImgGlobals2Utils.setPropertyVals(imiSearchRequest, displayField, "true");
			}
		}

		// If any of the Process File Fields display is true then we will
		// set the Acknowledgement Time display to true
		if (isProcessFileFields) {
			imiSearchRequest.setTimeAckDisplay(true);
		}

		// If status code display is true then we will set the
		// reason code display to true
		if (imiSearchRequest.isDocumentStatusCdDisplay()) {
			imiSearchRequest.setDocumentReasonCdDisplay(true);
			imiSearchRequest.setTimeUpdateDisplay(true);
		}
		if (imiSearchRequest.isProcessFileStatusCdDisplay()) {
			imiSearchRequest.setProcessFileReasonCdDisplay(true);
		}
	}

	private IMISearchData callIMIApi(IMISearchRequest searchRequest, String authToken) {
		IMISearchData searchData = null;
		String webservice = imiRetrieveBaseURL.replaceFirst("HOSTNAME", HVWUtils.getHostname());
		logger.debug("Requesting webservice: {}", webservice);

		try {
			// Use RestClientUtil for consistent HTTP handling
			ResponseEntity<IMISearchData> response = restClientUtil.postIMIRequest(webservice, authToken, searchRequest,
					IMISearchData.class);

			searchData = response.getBody();
			logger.debug("Request to webservice successful: {}", webservice);

			// Validate ServiceMessage return code
			if (searchData != null && searchData.getServiceMessage() != null) {
				IMISearchData.ServiceMessage serviceMessage = searchData.getServiceMessage();
				if (serviceMessage.getReturnCode() != null && serviceMessage.getReturnCode() != 0) {
					logger.error("IMI service returned error code: {} - {}", serviceMessage.getReturnCode(),
							serviceMessage.getReturnCodeDescription());

					// Return the error response with service message
					return searchData;
				}
			}

		} catch (Exception e) {
			logger.error("Exception occurred calling IMI webservice: {}", webservice, e);

			// Create error response
			IMISearchData errorData = new IMISearchData();
			IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();

			if (e.getMessage() != null
					&& (e.getMessage().contains("Timeout") || e.getMessage().contains("Connection refused"))) {
				baseMessage.setReturnCode(String.valueOf(HVWConstants.WSCONNECTTIMEOUT));
				baseMessage.setReturnCodeDescription(
						"Timeout occurred while retrieving Activity Tracking Search Results. Please check the service is up and running or narrow your search.");
			} else {
				baseMessage.setReturnCode(String.valueOf(HVWConstants.WSCONNECTTIMEOUT));
				baseMessage.setReturnCodeDescription(
						"Error occurred while retrieving Activity Tracking Search Results: " + e.getMessage());
			}

			errorData.setBaseMessage(baseMessage);
			errorData.setSearchResultsList(new ArrayList<>());
			return errorData;
		}

		return searchData;
	}

	public Map<String, Object> convertToTableFormat(IMISearchData searchData, String authToken,
			IMISearchRequest searchRequest) throws JsonProcessingException {
		ObjectNode finalResponse = objectMapper.createObjectNode();
		// --- Definition block ---
		ObjectNode definition = objectMapper.createObjectNode();
		definition.put(ALLOW_MULTIPLE_SORT, false);
		definition.put(ALLOW_RESIZE_COLUMNS, false);
		// pagination
		ObjectNode pagination = objectMapper.createObjectNode();
		pagination.put(PAGE_SIZE, DEFAULT_PAGE_SIZE);
		pagination.put(PAGE_NUMBER, DEFAULT_PAGE_NUMBER);
		definition.set(PAGINATION, pagination);
		definition.put(MAX_ACTIONS_TO_DISPLAY, NO_OF_ACTIONS_TO_DISPLAY);

		Set<String> activeKeys = buildActiveKeysFromSearchRequest(searchRequest);
		definition.set(COLUMNS, generateColumns(activeKeys));
		finalResponse.set(DEFINITION, definition);

		finalResponse.set("data", constructData(activeKeys, searchData, authToken));

		return objectMapper.convertValue(finalResponse, new TypeReference<Map<String, Object>>() {
		});
	}

	/**
	 * Builds activeKeys from the search request display fields This ensures
	 * consistent column display even when search results have null values
	 * 
	 * @param searchRequest The IMISearchRequest containing display field settings
	 * @return Set of active field names that should be displayed
	 */
	private Set<String> buildActiveKeysFromSearchRequest(IMISearchRequest searchRequest) {
		Set<String> activeKeys = new LinkedHashSet<>();

		// Always include naicCode and transmitTimeStamp as they are core fields
		activeKeys.add("naicCode");
		activeKeys.add("transmitTimestamp");

		// Use SearchReqMapping to get all possible display fields
		SearchReqMapping[] reqMapping = SearchReqMapping.values();
		for (SearchReqMapping mapping : reqMapping) {
			String displayField = mapping.getDisplayField();
			String outputField = mapping.getOutputField();

			// Check if the display field is true in the search request
			Object displayFieldVal = ImgGlobals2Utils.getPropertyVal(searchRequest, displayField);
			if (displayFieldVal != null && displayFieldVal.toString().equalsIgnoreCase("true")) {
				activeKeys.add(outputField);
			}
		}

		return activeKeys;
	}

	public ArrayNode generateColumns(Set<String> activeKeys) {
		// Columns
		ArrayNode columns = objectMapper.createArrayNode();

		// Static "Actions" column
		ObjectNode actionColumn = objectMapper.createObjectNode();
		actionColumn.put("id", ACTION);
		actionColumn.put("type", ACTIONS);
		actionColumn.put("name", "Actions");
		columns.add(actionColumn);

		for (String fieldName : activeKeys) {
			ObjectNode col = objectMapper.createObjectNode();
			if (fieldName != null && fieldName.toLowerCase().contains("time")) {
				col.put("type", "datetime");
				col.put("dateFormat", "yyyy-MM-DD HH:mm:ss.SSSSSS");
			} else {
				col.put("type", "string");
			}

			col.put("url", "");
			col.put("sortable", true);
			if ("naicCode".equalsIgnoreCase(fieldName))
				col.put("name", "NAIC");
			else if ("transmitTimeStamp".equalsIgnoreCase(fieldName))
				col.put("name", "Transmit Timestamp");
			else
				col.put("name", ImgGlobals2Constants.getHeaderByFieldName(fieldName));
			col.put("filterable", true);
			col.put("id", fieldName);

			columns.add(col);
		}

		return columns;
	}

	public ArrayNode constructData(Set<String> activeKeys, IMISearchData searchData, String authoken) {
		// --- Data block ---
		ArrayNode data = objectMapper.createArrayNode();
		List<IMISearchResults> backendResponseList = searchData.getSearchResultsList();
		if (backendResponseList != null && !backendResponseList.isEmpty()) {
			int noOfRows = 0;
			if (backendResponseList.size() > paginationRowCount)
				noOfRows = backendResponseList.size() - 1;
			else
				noOfRows = backendResponseList.size();

			boolean isUserHavingShowPHIAccess = HVWUtils.hasPhiAccess(authoken, phiAccessLdapGroup);

			// Retrieve CMOD date threshold once before iterating through the list
			Date cmodDateThreshold = getCMODDateThreshold();
			logger.debug("Retrieved CMOD date threshold: {} from APRM table for processing IMI records to display CMOD Search Link", cmodDateThreshold);

			for (int i = 0; i < noOfRows; i++) {
				IMISearchResults pojo = backendResponseList.get(i);
				Map<String, Object> rowMap = objectMapper.convertValue(pojo, new TypeReference<Map<String, Object>>() {
				});

				ObjectNode rowNode = objectMapper.createObjectNode();
				for (String key : activeKeys) {
					Object tempValue = rowMap.get(key);
					if (tempValue == null) {
						rowNode.set(key, objectMapper.valueToTree(""));
					} else {
						if ("transmitFileStatusCd".equalsIgnoreCase(key)) {
							rowNode.set(key, objectMapper.valueToTree(
									tempValue + " - " + HVWUtils.convertTransmitFileStatusCd(tempValue.toString())));
						} else if ("processFileStatusCd".equalsIgnoreCase(key)) {
							rowNode.set(key, objectMapper.valueToTree(
									tempValue + " - " + HVWUtils.convertProcessFileStatusCd(tempValue.toString())));
						} else if ("documentStatusCd".equalsIgnoreCase(key)) {
							rowNode.set(key, objectMapper.valueToTree(
									tempValue + " - " + HVWUtils.convertDocumentStatusCd(tempValue.toString())));
						} else
							rowNode.set(key, objectMapper.valueToTree(tempValue));
					}
				}
				rowNode.set(ACTION, constructActions(pojo, isUserHavingShowPHIAccess, cmodDateThreshold));
				data.add(rowNode);
			}
		}

		return data;
	}

	/**
	 * Retrieves the CMOD date threshold from the parameter table
	 * 
	 * @return Date threshold or null if not configured
	 */
	private Date getCMODDateThreshold() {
		try {
			Map<String, String> parmMap = imageParmDataService.getParmDataMap(HVWConstants.PARMID_HVW_IMICOM);
			String thresholdDateStr = parmMap.get(HVWConstants.PARMKEY_IMICOM_CMOD_DATE_THRESHOLD);

			if (!HVWUtils.hasText(thresholdDateStr)) {
				logger.debug("CMOD date threshold not configured in parameter table");
				return null;
			}

			// Parse the date string (format: yyyy-MM-dd)
			return parseDateFromParameter(thresholdDateStr.trim());

		} catch (Exception e) {
			logger.error("Error retrieving CMOD date threshold from parameter table", e);
			return null;
		}
	}

	/**
	 * Parses a date string from parameter table (format: yyyy-MM-dd)
	 * 
	 * @param dateStr The date string to parse
	 * @return Parsed Date or null if parsing fails
	 */
	private Date parseDateFromParameter(String dateStr) {
		if (!HVWUtils.hasText(dateStr)) {
			return null;
		}

		try {
			SimpleDateFormat sdf = new SimpleDateFormat(PARAMETER_DATE_FORMAT);
			sdf.setLenient(false);
			return sdf.parse(dateStr);
		} catch (ParseException e) {
			logger.warn("Could not parse date string: {} with format {}", dateStr, PARAMETER_DATE_FORMAT);
			return null;
		}
	}

	public ArrayNode constructActions(IMISearchResults searchData, boolean hasSecureAccess, Date cmodDateThreshold) {
		ArrayNode rowActions = objectMapper.createArrayNode();

		if (hasSecureAccess)
			rowActions.add(createSecureActionsForDocument(searchData));

		// Add actions based on document status
		String documentStatus = searchData.getDocumentStatusCd();
		if (HVWUtils.hasText(documentStatus) && Set.of("M", "S", "Y").contains(documentStatus)) {
			// Add standard actions based on document status
			rowActions.add(createActionsForDocumentStatus(documentStatus, searchData, cmodDateThreshold));
		}

		return rowActions;

	}

	/**
	 * Creates action arrays based on document status
	 * 
	 * @param documentStatus The document status code
	 * @param searchResult   The search result object containing document
	 *                       information
	 * @return List of action maps for the document
	 */
	private ObjectNode createActionsForDocumentStatus(String documentStatus, IMISearchResults searchResult,
			Date cmodDateThreshold) {
		ObjectNode action = null;
		switch (documentStatus) {
		case "M": // CMOD Stored
			action = createCMODAction(searchResult, cmodDateThreshold);
			// Note: createCMODAction may return null if date threshold not met
			break;
		case "S", "Y": // Original Completed or Stored
			action = createImageAction(searchResult);
			break;
		default:
			// No actions for other status codes
			break;
		}

		return action;

	}

	/**
	 * Creates a CMOD action for documents with status "M"
	 * 
	 * @param searchResult The search result object
	 * @return Map containing CMOD action properties
	 */
	private ObjectNode createCMODAction(IMISearchResults searchResult, Date cmodDateThreshold) {

		// If cmodDateThreshold is null, skip date comparison and create action
		if (cmodDateThreshold != null
				&& !isTransmitTimestampAfterCMODThreshold(searchResult.getTransmitTimeStamp(), cmodDateThreshold)) {
			return objectMapper.createObjectNode();
		}

		ObjectNode action = objectMapper.createObjectNode();
		action.put(API_URL, "imi/imiCMODSearch");
		action.put(ACTION_TYPE, "submit");
		action.put(LABEL, "CMOD Search");
		action.put(ACTION_ICON, "search");

		return action;
	}

	/**
	 * Constructs CMOD search URL for a given document ID and parameters
	 * 
	 * @param imiDocumentId The IMI document ID
	 * @param parameters    Additional parameters for URL construction
	 * @return Constructed CMOD search URL
	 */
	public String constructCMODSearchUrl(Integer imiDocumentId, Map<String, String> parameters) {
		StringBuilder navigateUrl = new StringBuilder(cmodNavigatePath);

		if (HVWUtils.hasText(String.valueOf(imiDocumentId))) {
			Map<String, String> paramMap = getSegmentDataByDocumentIdAndSegmentNames(imiDocumentId,
					List.of("CFL", "CFF"));
			if (paramMap != null) {
				navigateUrl.append(paramMap.get("CFL")).append("?").append(paramMap.get("CFF") + "=")
						.append(imiDocumentId).append("&").append(cmodParam1 + "=").append(cmodParam2);
			} else {
				// If segment data is not available, use default navigation path
				logger.warn("Segment data not found for document ID: {}, using default CMOD navigation", imiDocumentId);
				navigateUrl.append("");
			}
		}

		return navigateUrl.toString();
	}

	/**
	 * Checks if the transmit time stamp is after the CMOD date threshold
	 * 
	 * @param transmitTimestamp The transmit time stamp to check
	 * @param cmodDateThreshold The CMOD date threshold to compare against
	 * @return true if transmit time stamp is after the threshold, false otherwise
	 */
	private boolean isTransmitTimestampAfterCMODThreshold(String transmitTimestamp, Date cmodDateThreshold) {
		if (!HVWUtils.hasText(transmitTimestamp)) {
			logger.debug("Transmit timestamp is null or empty, not allowing CMOD action");
			return false;
		}
		try {
			Date transmitDate = parseTransmitTimestamp(transmitTimestamp);
			if (transmitDate == null) {
				logger.debug("Could not parse transmit timestamp: {}, not allowing CMOD action", transmitTimestamp);
				return false;
			}
			return transmitDate.after(cmodDateThreshold);
		} catch (Exception e) {
			logger.error("Error comparing transmit timestamp with CMOD threshold", e);
			return false;
		}
	}

	/**
	 * Parses the transmit time stamp string to Date
	 * 
	 * @param transmitTimestamp The transmit time stamp string
	 * @return Parsed Date or null if parsing fails
	 */
	private Date parseTransmitTimestamp(String transmitTimestamp) {
		if (!HVWUtils.hasText(transmitTimestamp)) {
			return null;
		}

		try {
			// Try the expected format first: yyyy-MM-dd HH:mm:ss.S
			SimpleDateFormat sdf = new SimpleDateFormat(TRANSMIT_TIMESTAMP_FORMAT);
			sdf.setLenient(false);
			return sdf.parse(transmitTimestamp);
		} catch (ParseException e) {
			// Try alternative formats
			String[] formats = { "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss",
					"yyyy-MM-dd'T'HH:mm:ss.SSS", "MM/dd/yyyy HH:mm:ss" };

			for (String format : formats) {
				try {
					SimpleDateFormat sdf = new SimpleDateFormat(format);
					sdf.setLenient(false);
					return sdf.parse(transmitTimestamp);
				} catch (ParseException ex) {
					// Continue to next format
				}
			}

			logger.warn("Could not parse transmit timestamp: {}", transmitTimestamp);
			return null;
		}
	}

	/**
	 * Retrieves segment data for a specific document ID and segment names.
	 * 
	 * @param imiDocumentId the document ID to search for
	 * @param segmentNames  list of segment names to filter by
	 * @return Map of segment data or null if no segments found
	 */
	public Map<String, String> getSegmentDataByDocumentIdAndSegmentNames(Integer imiDocumentId,
			List<String> segmentNames) {
		List<T222ADSG> segments = t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(imiDocumentId, segmentNames);

		// Return null if no segments found
		if (segments == null || segments.isEmpty()) {
			return null;
		}

		return segments.stream().collect(
				Collectors.toMap(T222ADSG::getSegmentName, T222ADSG::getSegmentData, (existing, replacement) -> existing // Keep
				));
	}

	/**
	 * Creates an Image action for documents with status "S" or "Y"
	 * 
	 * @param searchResult The search result object
	 * @return Map containing Image action properties
	 */
	private ObjectNode createImageAction(IMISearchResults searchResult) {
		ObjectNode action = objectMapper.createObjectNode();

		// Build navigate URL with document parameters
		StringBuilder navigateUrl = new StringBuilder(viewImageNavigatePath + viewImageFormId);
		if (HVWUtils.hasText(String.valueOf(searchResult.getInitialProcessDCN()))) {
			navigateUrl.append("?").append(viewImageFormParam1 + "=").append(searchResult.getInitialProcessDCN());
		}
		if (HVWUtils.hasText(String.valueOf(searchResult.getApplIdCd()))) {
			navigateUrl.append("&").append(viewImageFormParam2 + "=").append(searchResult.getApplIdCd());
		}

		navigateUrl.append("&").append(viewImageFormParam3 + "=").append(viewImageFormParam4);
		action.put(NAVIGATE_URL, navigateUrl.toString());
		action.put(ACTION, NAVIGATE);
		action.put(LABEL, "Image Search");
		action.put(URL_TARGET, BLANK);
		action.put(ACTION_ICON, "search");

		return action;
	}

	/**
	 * Creates additional secure actions for documents if user has secure LDAP group
	 * access
	 * 
	 * @param searchResult The search result object
	 * @return List of secure action maps for the document
	 */
	private ObjectNode createSecureActionsForDocument(IMISearchResults searchResult) {

		ObjectNode secureDownloadAction = objectMapper.createObjectNode();

		secureDownloadAction.put(NAVIGATE_URL, "pages/imi-segments/" + searchResult.getImiDocumentId());
		secureDownloadAction.put(ACTION, NAVIGATE);
		secureDownloadAction.put(LABEL, "Show PHI Data");
		secureDownloadAction.put(URL_TARGET, BLANK);
		secureDownloadAction.put(ACTION_ICON, "shield");

		return secureDownloadAction;
	}

	/**
	 * Retrieves PHI (Protected Health Information) data for a specific IMI document
	 * 
	 * @param userId        The user ID
	 * @param authToken     The authentication token
	 * @param imiDocumentId The IMI document ID to retrieve PHI data for
	 * @return Map containing the PHI data response
	 */
	public Map<String, Object> retrieveSegmentData(String userId, String authToken, int imiDocumentId) {

		Map<String, Object> phiDataResponse = new LinkedHashMap<>();
		try {
			// Call external web service to get PHI data
			Map<String, Object> phiData = callSegmentDataWebService(imiDocumentId, authToken);
			if (phiData != null && !phiData.containsKey(ERROR)) {
				phiDataResponse.put(STATUS, "success");
				phiDataResponse.put("imiDocumentId", imiDocumentId);
				phiDataResponse.put("phiData", phiData);
				phiDataResponse.put("retrievedAt", new Date());
			} else {
				phiDataResponse.put(STATUS, ERROR);
				phiDataResponse.put(ERROR, "Failed to retrieve segment data");
			}

		} catch (Exception e) {
			logger.error("Error occurred while retrieving PHI data for document {}: {}", imiDocumentId, e.getMessage(),
					e);
			phiDataResponse.put(STATUS, ERROR);
			phiDataResponse.put(ERROR, "Error occurred while retrieving PHI data: " + e.getMessage());
		}

		return phiDataResponse;
	}

	/**
	 * Calls external web service to retrieve PHI data for a specific IMI document
	 * 
	 * @param userId        The user ID
	 * @param imiDocumentId The IMI document ID
	 * @param authToken     The authentication token
	 * @return Map containing the PHI data or error information
	 */

	private Map<String, Object> callSegmentDataWebService(int imiDocumentId, String authToken) {
		Map<String, Object> phiData = new LinkedHashMap<>();
		try {
			// Build the web service URL for PHI data retrieval
			String segmentDataWebServiceUrl = imiRetrieveSegmentData.replaceFirst("HOSTNAME", HVWUtils.getHostname())
					.replaceFirst("IMI_DOCUMENTID", String.valueOf(imiDocumentId));
			logger.debug("Requesting segment data from web service: {} for IMI Document ID: {}",
					segmentDataWebServiceUrl, imiDocumentId);

			// Use RestClientUtil for consistent HTTP handling
			ResponseEntity<IMISegmentDataResult> response = restClientUtil.getRequest(segmentDataWebServiceUrl,
					authToken, IMISegmentDataResult.class);

			IMISegmentDataResult responseBody = response.getBody();
			if (responseBody == null) {
				logger.error("Error from PHI data service: {} - body is null", response.getStatusCode());
				phiData.put(ERROR, "Failed to retrieve PHI data from external service");
				return phiData;
			}

			IMISegmentDataResult.ServiceMessage serviceMessage = responseBody.getServiceMessage();
			if (serviceMessage != null && serviceMessage.getReturnCode() != 0) {
				logger.error("Error from PHI data service: {} - returnCode: {} - {}", response.getStatusCode(),
						serviceMessage.getReturnCode(), serviceMessage.getReturnCodeDescription());
				phiData.put(ERROR, "Failed to retrieve PHI data from external service");
				return phiData;
			}

			phiData = transformSegmentsToTableFormat(responseBody.getT222adsgList());
			logger.debug("Successfully retrieved PHI data for document: {}", imiDocumentId);

		} catch (Exception e) {
			logger.error("Exception occurred calling PHI data web service for document {}: {}", imiDocumentId,
					e.getMessage(), e);
			phiData.put(ERROR, "Exception occurred while calling PHI data web service: " + e.getMessage());
		}

		return phiData;
	}

	public Map<String, Object> transformSegmentsToTableFormat(List<T222ADSG> segments) {
		Map<String, Object> response = new LinkedHashMap<>();

		// Create definition section
		Map<String, Object> definition = new LinkedHashMap<>();
		definition.put(ALLOW_MULTIPLE_SORT, false);
		definition.put(ALLOW_RESIZE_COLUMNS, false);

		Map<String, Object> pagination = new LinkedHashMap<>();
		pagination.put(PAGE_SIZE, DEFAULT_PAGE_SIZE);
		pagination.put(PAGE_NUMBER, DEFAULT_PAGE_NUMBER);
		definition.put(PAGINATION, pagination);

		// Columns in declaration order
		List<Map<String, Object>> columns = new ArrayList<>();
		for (Field field : T222ADSG.class.getDeclaredFields()) {
			String fieldName = field.getName();

			if ("imiDocumentId".equalsIgnoreCase(fieldName) || "segmentseqno".equalsIgnoreCase(fieldName)) {
				continue;
			}

			Map<String, Object> column = new LinkedHashMap<>();
			column.put("name", humanizeHeader(fieldName));
			column.put("sortable", true);
			column.put("url", "");
			column.put("type", mapType(field.getType()));
			column.put("id", fieldName.toUpperCase());
			column.put("filterable", true);

			columns.add(column);
		}
		definition.put(COLUMNS, columns);
		response.put(DEFINITION, definition);

		// Data section
		List<Map<String, Object>> data = new ArrayList<>();
		if (segments != null) {
			try {
				for (T222ADSG segment : segments) {
					Map<String, Object> row = new LinkedHashMap<>();
					for (Field field : T222ADSG.class.getDeclaredFields()) {
						String fieldName = field.getName();

						PropertyDescriptor pd = new PropertyDescriptor(fieldName, T222ADSG.class);
						Method getter = pd.getReadMethod();
						if (getter != null) {
							Object value = getter.invoke(segment);
							String key = fieldName.toUpperCase().replace("_", " ");
							row.put(key, value);
						}
					}
					data.add(row);
				}
			} catch (Exception e) {
				throw new IllegalStateException("Failed to extract data from segments", e);
			}
		}
		response.put("data", data);

		return response;
	}

	// Converts a raw field name (e.g., segmentname, segment_status_code, segmentReasonCode)
	// into a human-friendly header with spaces and reasonable capitalization.
	private String humanizeHeader(String rawFieldName) {
		if (rawFieldName == null || rawFieldName.isEmpty()) {
			return "";
		}

		String lower = rawFieldName.toLowerCase();
		switch (lower) {
		case "segmentname":
			return "Segment Name";
		case "segmentstatuscode":
			return "Segment Status Code";
		case "segmentreasoncode":
			return "Segment Reason Code";
		case "segmentdata":
			return "Segment Data";
		case "segmentseqno":
			return "Segment Seq No";
		case "imidocumentid":
			return "IMI Document ID";
		default:
			return "";
		}
	}

	// Helper to map Java types → UI types
	private String mapType(Class<?> type) {
		if (Number.class.isAssignableFrom(type)
				|| (type.isPrimitive() && type != boolean.class && type != char.class)) {
			return "number";
		} else if (type == Boolean.class || type == boolean.class) {
			return "boolean";
		} else if (Date.class.isAssignableFrom(type) || java.time.temporal.Temporal.class.isAssignableFrom(type)) {
			return "date";
		} else if (CharSequence.class.isAssignableFrom(type) || type == char.class) {
			return "string";
		} else {
			return "object"; // fallback
		}
	}
}
