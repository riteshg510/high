package com.hmhs.hvwmid.entity;

import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "ODSCRT")
@IdClass(OdscrtId.class)
public class Odscrt {

	@Id
    @Column(name = "ODSCRT_AG_NAME", length = 60)
    private String agName;

    @Id
    @Column(name = "ODSCRT_APP_NAME", length = 60)
    private String appName;

    @Column(name = "ODSCRT_JOB", columnDefinition = "CHAR(8)")
    private String job;

    @Column(name = "ODSCRT_STEP", columnDefinition = "CHAR(8)")
    private String step;

    @Column(name = "ODSCRT_PROCSTEP", columnDefinition = "CHAR(8)")
    private String procStep;

    @Column(name = "ODSCRT_DD", length = 8)
    private String dd;

    @Column(name = "ODSCRT_FOREIGN_RID", columnDefinition = "CHAR(25)")
    private String foreignRid;

    @Column(name = "ODSCRT_SNODE_NAME", columnDefinition = "CHAR(60)")
    private String sNodeName;

    @Column(name = "ODSCRT_TITLE", length = 120)
    private String title;

    @Column(name = "ODSCRT_INDEX_1", length = 254)
    private String index1;

    @Column(name = "ODSCRT_INDEX_2", length = 254)
    private String index2;

    @Column(name = "ODSCRT_INDEX_3", length = 254)
    private String index3;

    @Column(name = "ODSCRT_UPD_TS")
    private Timestamp updTs;

    @Column(name = "ODSCRT_UPD_USERID", columnDefinition = "CHAR(8)")
    private String updUserId;

	public String getAgName() {
		return agName;
	}

	public void setAgName(String agName) {
		this.agName = agName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getStep() {
		return step;
	}

	public void setStep(String step) {
		this.step = step;
	}

	public String getProcStep() {
		return procStep;
	}

	public void setProcStep(String procStep) {
		this.procStep = procStep;
	}

	public String getDd() {
		return dd;
	}

	public void setDd(String dd) {
		this.dd = dd;
	}

	public String getForeignRid() {
		return foreignRid;
	}

	public void setForeignRid(String foreignRid) {
		this.foreignRid = foreignRid;
	}

	public String getsNodeName() {
		return sNodeName;
	}

	public void setsNodeName(String sNodeName) {
		this.sNodeName = sNodeName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIndex1() {
		return index1;
	}

	public void setIndex1(String index1) {
		this.index1 = index1;
	}

	public String getIndex2() {
		return index2;
	}

	public void setIndex2(String index2) {
		this.index2 = index2;
	}

	public String getIndex3() {
		return index3;
	}

	public void setIndex3(String index3) {
		this.index3 = index3;
	}

	public Timestamp getUpdTs() {
		return updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUserId() {
		return updUserId;
	}

	public void setUpdUserId(String updUserId) {
		this.updUserId = updUserId;
	}
	    
}