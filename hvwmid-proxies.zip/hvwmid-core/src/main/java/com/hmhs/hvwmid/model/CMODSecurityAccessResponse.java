package com.hmhs.hvwmid.model;

import java.util.Map;
import java.util.Set;

/**
 * Response DTO for CMOD Security Access API endpoint.
 * Contains all security access information for a user's CMOD permissions.
 */
public class CMODSecurityAccessResponse {

    private Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap; // - `CMODSecurityAccessList` -
                                                                                 // `Map<String, Map<String,
                                                                                 // ImageODApplication>>` - Main
                                                                                 // security access mapping
    private Map<String, Set<String>> missingRacfEntries; // - `CMODMissingRACFMap` - `Map<String, Set<String>>` -
                                                         // Missing RACF entries
    private CMODSARAPathInfo saraPathInfo; // - `CMODSARARoot` - `String` - Root SARA path, //- `CMODSARAHighview` -
                                           // `Map<String, String>` - Highview-specific SARA mappings
    // - `CMODSARARenoPath` - `Map<String, String>` - Reno-specific SARA paths
    private String userGroups; // - `CMODUserGroups` - `String` - User group information
    private String triageInfo; // CMODTriage` - `String` - Triage contact information
    private String errorMessage; // - `MessageCMODSecurityAccess` - `String` - Error/status messages
    private boolean hasError;
    private boolean cmodFolderNavigation = false;

    // Constructors
    public CMODSecurityAccessResponse() {
    }

    public CMODSecurityAccessResponse(Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap,
            Map<String, Set<String>> missingRacfEntries,
            CMODSARAPathInfo saraPathInfo,
            String userGroups,
            String triageInfo) {
        this.folderAccessMap = folderAccessMap;
        this.missingRacfEntries = missingRacfEntries;
        this.saraPathInfo = saraPathInfo;
        this.userGroups = userGroups;
        this.triageInfo = triageInfo;
        this.hasError = false;
    }

    // Error constructor
    public CMODSecurityAccessResponse(String errorMessage) {
        this.errorMessage = errorMessage;
        this.hasError = true;
    }

    // Getters and Setters
    public Map<String, Map<String, CMODApplicationAccessInfo>> getFolderAccessMap() {
        return folderAccessMap;
    }

    public void setFolderAccessMap(Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap) {
        this.folderAccessMap = folderAccessMap;
    }

    public Map<String, Set<String>> getMissingRacfEntries() {
        return missingRacfEntries;
    }

    public void setMissingRacfEntries(Map<String, Set<String>> missingRacfEntries) {
        this.missingRacfEntries = missingRacfEntries;
    }

    public CMODSARAPathInfo getSaraPathInfo() {
        return saraPathInfo;
    }

    public void setSaraPathInfo(CMODSARAPathInfo saraPathInfo) {
        this.saraPathInfo = saraPathInfo;
    }

    public String getUserGroups() {
        return userGroups;
    }

    public void setUserGroups(String userGroups) {
        this.userGroups = userGroups;
    }

    public String getTriageInfo() {
        return triageInfo;
    }

    public void setTriageInfo(String triageInfo) {
        this.triageInfo = triageInfo;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public boolean isHasError() {
        return hasError;
    }

    public void setHasError(boolean hasError) {
        this.hasError = hasError;
    }

    public boolean isCmodFolderNavigation() {
        return cmodFolderNavigation;
    }

    public void setCmodFolderNavigation(boolean cmodFolderNavigation) {
        this.cmodFolderNavigation = cmodFolderNavigation;
    }
}