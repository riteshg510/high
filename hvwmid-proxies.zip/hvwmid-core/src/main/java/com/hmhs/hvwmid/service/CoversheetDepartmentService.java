package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;

import java.util.List;

public interface CoversheetDepartmentService {

    List<T117ImgCoverDept> getAllDepartments();

    T117ImgCoverDept saveDepartment(T117ImgCoverDept department);

    void deleteDepartment(Integer id);

    List<String> getAllMaintananceGroups();

    T117ImgCoverDept getDepartmentById(Integer id);
}
