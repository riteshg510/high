package com.hmhs.hvwmid.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * Generic exception for HVW application errors.
 * Provides centralized error handling functionality across all services.
 */
public class HVWException extends RuntimeException {

    private static final Logger logger = LogManager.getLogger(HVWException.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final long serialVersionUID = 1L;

    private final int returnCode;
    private final String returnCodeDescription;
    private final String service;

    /**
     * Constructs a new exception with the specified return code and description.
     *
     * @param returnCode            The error return code
     * @param returnCodeDescription The description of the error
     */
    public HVWException(final int returnCode, final String returnCodeDescription) {
        super(returnCodeDescription);
        this.returnCode = returnCode;
        this.returnCodeDescription = returnCodeDescription;
        this.service = "unknown";
    }

    /**
     * Constructs a new exception with the specified return code, description, and
     * service name.
     *
     * @param returnCode            The error return code
     * @param returnCodeDescription The description of the error
     * @param service               The service that generated the error
     */
    public HVWException(final int returnCode, final String returnCodeDescription, final String service) {
        super(returnCodeDescription);
        this.returnCode = returnCode;
        this.returnCodeDescription = returnCodeDescription;
        this.service = service;
    }

    /**
     * Constructs a new exception with the specified message.
     *
     * @param message The error message
     */
    public HVWException(final String message) {
        super(message);
        this.returnCode = 503;
        this.returnCodeDescription = message;
        this.service = "unknown";
    }

    /**
     * Constructs a new exception with the specified message and service.
     *
     * @param message The error message
     * @param service The service that generated the error
     */
    public HVWException(final String message, final String service) {
        super(message);
        this.returnCode = 503;
        this.returnCodeDescription = message;
        this.service = service;
    }

    /**
     * Constructs a new exception with the specified cause.
     *
     * @param cause The cause of the exception
     */
    public HVWException(final Throwable cause) {
        super(cause.getMessage(), cause);
        this.returnCode = 503;
        this.returnCodeDescription = cause.getMessage();
        this.service = "unknown";
    }

    /**
     * Constructs a new exception with the specified message and cause.
     *
     * @param message The error message
     * @param cause   The cause of the exception
     */
    public HVWException(final String message, final Throwable cause) {
        super(message, cause);
        this.returnCode = 503;
        this.returnCodeDescription = message;
        this.service = "unknown";
    }

    /**
     * Constructs a new exception with the specified message, cause, and service.
     *
     * @param message The error message
     * @param cause   The cause of the exception
     * @param service The service that generated the error
     */
    public HVWException(final String message, final Throwable cause, final String service) {
        super(message, cause);
        this.returnCode = 503;
        this.returnCodeDescription = message;
        this.service = service;
    }

    /**
     * Gets the return code of the error.
     *
     * @return The return code
     */
    public int getReturnCode() {
        return returnCode;
    }

    /**
     * Gets the description of the error.
     *
     * @return The error description
     */
    public String getReturnCodeDescription() {
        return returnCodeDescription;
    }

    /**
     * Gets the service that generated the error.
     *
     * @return The service name
     */
    public String getService() {
        return service;
    }

    /**
     * Creates a standardized error response map from this exception.
     * 
     * @return Map containing error details formatted for client response
     */
    public Map<String, Object> createErrorResponse() {
        return createErrorResponseMap(this.returnCode, this.returnCodeDescription, this.service);
    }

    /**
     * Creates a ResponseEntity with the appropriate HTTP status and error details
     * from this exception.
     * 
     * @return ResponseEntity containing error details and appropriate HTTP status
     */
    public ResponseEntity<Object> createErrorResponseEntity() {
        return createErrorResponseEntity(this.returnCode, this.returnCodeDescription, this.service);
    }

    /**
     * Creates a standardized error response map from a generic exception.
     * 
     * @param e The exception to convert to response format
     * @return Map containing error details formatted for client response
     */
    public static Map<String, Object> createErrorResponse(final Exception e) {
        final Map<String, Object> errorResponse = new HashMap<>();

        // Core error info
        errorResponse.put("status", "error");

        if (e instanceof HVWException) {
            final HVWException hvwEx = (HVWException) e;

            // Extract service message details
            final Map<String, Object> serviceMessage = new HashMap<>();
            serviceMessage.put("returnCode", hvwEx.getReturnCode());

            // Clean up any nested error messages
            final String cleanDescription = extractNestedErrorMessage(hvwEx.getMessage());
            serviceMessage.put("returnCodeDescription", cleanDescription);

            if (hvwEx.getService() != null && !"unknown".equals(hvwEx.getService())) {
                serviceMessage.put("service", hvwEx.getService());
            }

            errorResponse.put("serviceMessage", serviceMessage);
            errorResponse.put("message", cleanDescription);
        } else {
            // For generic exceptions
            final Map<String, Object> serviceMessage = new HashMap<>();
            serviceMessage.put("returnCode", 503);

            String message = e.getMessage();
            if (message == null) {
                message = e.getClass().getSimpleName();
            } else {
                // Clean up any nested error messages
                message = extractNestedErrorMessage(message);
            }

            serviceMessage.put("returnCodeDescription", message);

            errorResponse.put("serviceMessage", serviceMessage);
            errorResponse.put("message", message);
        }

        return errorResponse;
    }

    /**
     * Creates a standardized error response map with the specified return code and
     * description.
     * 
     * @param returnCode  The error code to include in the response
     * @param description The error description to include in the response
     * @return Map containing error details formatted for client response
     */
    public static Map<String, Object> createErrorResponseMap(final int returnCode, final String description) {
        return createErrorResponseMap(returnCode, description, "unknown");
    }

    /**
     * Creates a standardized error response map with the specified return code,
     * description, and service.
     * 
     * @param returnCode  The error code to include in the response
     * @param description The error description to include in the response
     * @param service     The service that generated the error
     * @return Map containing error details formatted for client response
     */
    public static Map<String, Object> createErrorResponseMap(final int returnCode, final String description,
            final String service) {
        final Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", returnCode);
        serviceMessage.put("returnCodeDescription", description);
        if (!"unknown".equals(service)) {
            serviceMessage.put("service", service);
        }

        final Map<String, Object> response = new HashMap<>();
        response.put("serviceMessage", serviceMessage);
        response.put("status", "error");
        response.put("message", description);

        return response;
    }

    /**
     * Creates a ResponseEntity with the appropriate HTTP status and error details.
     * 
     * @param returnCode  The error code to include in the response
     * @param description The error description to include in the response
     * @return ResponseEntity containing error details and appropriate HTTP status
     */
    public static ResponseEntity<Object> createErrorResponseEntity(final int returnCode, final String description) {
        return createErrorResponseEntity(returnCode, description, "unknown");
    }

    /**
     * Creates a ResponseEntity with the appropriate HTTP status and error details.
     * 
     * @param returnCode  The error code to include in the response
     * @param description The error description to include in the response
     * @param service     The service that generated the error
     * @return ResponseEntity containing error details and appropriate HTTP status
     */
    public static ResponseEntity<Object> createErrorResponseEntity(final int returnCode, final String description,
            final String service) {
        final Map<String, Object> errorResponse = createErrorResponseMap(returnCode, description, service);

        HttpStatus httpStatus;
        switch (returnCode) {
            case 400:
                httpStatus = HttpStatus.BAD_REQUEST;
                break;
            case 401:
                httpStatus = HttpStatus.UNAUTHORIZED;
                break;
            case 403:
                httpStatus = HttpStatus.FORBIDDEN;
                break;
            case 404:
                httpStatus = HttpStatus.NOT_FOUND;
                break;
            default:
                httpStatus = HttpStatus.SERVICE_UNAVAILABLE;
        }

        return ResponseEntity.status(httpStatus).body(errorResponse);
    }

    /**
     * Creates a ResponseEntity with the appropriate HTTP status and error details
     * from an exception.
     * 
     * @param e The exception to convert to response format
     * @return ResponseEntity containing error details and appropriate HTTP status
     */
    public static ResponseEntity<Object> createErrorResponseEntity(final Exception e) {
        if (e instanceof HVWException) {
            return ((HVWException) e).createErrorResponseEntity();
        } else {
            return createErrorResponseEntity(503, e.getMessage(), "unknown");
        }
    }

    /**
     * Parse an error response and extract the real error details.
     * Handles Map-type responses and standardizes the error format.
     * 
     * @param response The response entity from the service call (Map type)
     * @param service  The service name to associate with the exception
     * @return A HVWException with the correct error code and message
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static HVWException parseErrorResponse(final ResponseEntity<Map> response, final String service) {
        final int statusCode = response.getStatusCodeValue();

        // If we have a response body, try to extract structured error
        if (response.getBody() != null) {
            final Map<String, Object> responseBody = response.getBody();

            // Check for standard serviceMessage format first
            if (responseBody.containsKey("serviceMessage")) {
                final Map<String, Object> serviceMsg = (Map<String, Object>) responseBody.get("serviceMessage");

                if (serviceMsg.containsKey("returnCode") && serviceMsg.containsKey("returnCodeDescription")) {
                    final int returnCode = ((Number) serviceMsg.get("returnCode")).intValue();
                    final String description = (String) serviceMsg.get("returnCodeDescription");

                    // Special case for OAuth token errors
                    if (returnCode == 30 && description.toLowerCase().contains("oauth token")) {
                        return new HVWException(401, "Authentication token expired. Please log in again.", service);
                    }

                    return new HVWException(returnCode, description, service);
                }
            }

            // Check for nested errors in string representations
            try {
                // If response body contains a string representation of a serviceMessage
                final String responseStr = responseBody.toString();
                if (responseStr.contains("serviceMessage") && responseStr.contains("returnCode")) {
                    final String extractedMsg = extractNestedErrorMessage(responseStr);
                    if (extractedMsg != null && !extractedMsg.equals(responseStr)) {
                        return new HVWException(statusCode, extractedMsg, service);
                    }
                }

                // Try to search for nested serviceMessage keys (in case of deep nesting)
                for (final Object value : responseBody.values()) {
                    if (value instanceof String) {
                        final String strValue = (String) value;
                        if (strValue.contains("serviceMessage") && strValue.contains("returnCode")) {
                            final String extractedMsg = extractNestedErrorMessage(strValue);
                            if (extractedMsg != null && !extractedMsg.equals(strValue)) {
                                return new HVWException(statusCode, extractedMsg, service);
                            }
                        }
                    } else if (value instanceof Map) {
                        // Recursive check in nested maps
                        final Map<String, Object> nestedMap = (Map<String, Object>) value;
                        if (nestedMap.containsKey("serviceMessage")) {
                            final Map<String, Object> serviceMsg = (Map<String, Object>) nestedMap
                                    .get("serviceMessage");
                            if (serviceMsg.containsKey("returnCode")
                                    && serviceMsg.containsKey("returnCodeDescription")) {
                                final int returnCode = ((Number) serviceMsg.get("returnCode")).intValue();
                                final String description = (String) serviceMsg.get("returnCodeDescription");
                                return new HVWException(returnCode, description, service);
                            }
                        }
                    }
                }
            } catch (final Exception e) {
                logger.debug("Error parsing nested error details: {}", e.getMessage());
            }
        }

        // If we couldn't extract a structured error, use HTTP status with generic
        // message
        return createStatusBasedError(statusCode,
                "Service request failed with status: " + statusCode,
                service);
    }

    /**
     * Parse an error response and extract the real error details.
     * For backward compatibility with existing code.
     * 
     * @param response The response entity from the service call
     * @return A HVWException with the correct error code and message
     */
    @SuppressWarnings("rawtypes")
    public static HVWException parseErrorResponse(final ResponseEntity<Map> response) {
        return parseErrorResponse(response, "unknown");
    }

    /**
     * Parse a generic error response and extract the real error details.
     * For use with any ResponseEntity type.
     * 
     * @param response The ResponseEntity containing the error
     * @param service  The service name
     * @return An HVWException with error details
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static HVWException parseGenericErrorResponse(final ResponseEntity<?> response, final String service) {
        // If it's a Map response, use the specialized method
        if (response.getBody() instanceof Map) {
            final ResponseEntity<Map> mapResponse = (ResponseEntity<Map>) response;
            return parseErrorResponse(mapResponse, service);
        }

        final int statusCode = response.getStatusCodeValue();

        // Try to convert response body to string for processing
        if (response.getBody() != null) {
            try {
                final String jsonStr = objectMapper.writeValueAsString(response.getBody());

                // If it contains serviceMessage structure, try to extract it
                if (jsonStr.contains("serviceMessage")) {
                    final String extractedMsg = extractNestedErrorMessage(jsonStr);
                    if (extractedMsg != null && !extractedMsg.equals(jsonStr)) {
                        return new HVWException(statusCode, extractedMsg, service);
                    }

                    // Try to parse as JSON and extract serviceMessage directly
                    try {
                        final JsonNode jsonNode = objectMapper.readTree(jsonStr);
                        if (jsonNode.has("serviceMessage")) {
                            final JsonNode serviceMsg = jsonNode.get("serviceMessage");
                            if (serviceMsg.has("returnCode") && serviceMsg.has("returnCodeDescription")) {
                                final int returnCode = serviceMsg.get("returnCode").asInt();
                                final String description = serviceMsg.get("returnCodeDescription").asText();
                                return new HVWException(returnCode, description, service);
                            }
                        }
                    } catch (final Exception e) {
                        logger.debug("Error parsing JSON in response body: {}", e.getMessage());
                    }
                }

                // Use the response body content as error message
                return new HVWException(statusCode, jsonStr, service);
            } catch (final Exception e) {
                logger.debug("Error converting response body to string: {}", e.getMessage());
            }
        }

        // Default case - use HTTP status code
        return createStatusBasedError(statusCode,
                "Service request failed with status: " + statusCode,
                service);
    }

    /**
     * Create an error based on HTTP status code with appropriate message.
     */
    static HVWException createStatusBasedError(final int statusCode, final String errorMessage,
                                               final String service) {
        // Map HTTP status codes to more specific error messages
        String userFriendlyMessage;
        switch (statusCode) {
            case 400:
                userFriendlyMessage = "Invalid request to service: " + service;
                break;
            case 401:
                userFriendlyMessage = "Authentication required for service: " + service;
                break;
            case 403:
                userFriendlyMessage = "Not authorized to access service: " + service;
                break;
            case 404:
                userFriendlyMessage = "Resource not found in service: " + service;
                break;
            case 500:
            case 502:
            case 503:
            case 504:
                userFriendlyMessage = "Service temporarily unavailable: " + service;
                break;
            default:
                userFriendlyMessage = errorMessage;
        }

        return new HVWException(statusCode, userFriendlyMessage, service);
    }

    /**
     * Attempt to extract nested service messages from a response body.
     * 
     * @param responseBody The response body to parse
     * @param defaultCode  The default status code to use if no code is found
     * @param service      The service name to associate with the exception
     * @return A HVWException with the extracted details
     */
    static HVWException extractNestedServiceMessage(
            final Map<String, Object> responseBody, final int defaultCode, final String service) {

        if (responseBody == null) {
            return new HVWException(defaultCode, "Empty response body", service);
        }

        try {
            // Check for body field that might contain JSON string
            if (responseBody.containsKey("body") && responseBody.get("body") instanceof String) {
                final String bodyStr = (String) responseBody.get("body");
                return parseJsonString(bodyStr, defaultCode, service);
            }

            // Check if the string representation contains service message
            final String responseBodyStr = responseBody.toString();
            if (responseBodyStr.contains("serviceMessage")) {
                return parseJsonString(responseBodyStr, defaultCode, service);
            }

            // Try to serialize and then parse the whole body as a fallback
            final String serialized = objectMapper.writeValueAsString(responseBody);
            return parseJsonString(serialized, defaultCode, service);

        } catch (final Exception e) {
            logger.debug("Could not extract nested error: {}", e.getMessage());
            return new HVWException(defaultCode,
                    responseBody.containsKey("message")
                            ? responseBody.get("message").toString()
                            : "Service request failed with status: " + defaultCode,
                    service);
        }
    }

    /**
     * Parse a JSON string to extract service message details.
     * Handles deeply nested and escaped JSON strings.
     * 
     * @param jsonString  The JSON string to parse
     * @param defaultCode The default status code to use if no code is found
     * @param service     The service name to associate with the exception
     * @return A HVWException with the extracted details
     */
    static HVWException parseJsonString(String jsonString, final int defaultCode, final String service) {
        try {
            // Special case for HTTP error messages containing JSON
            if (jsonString.contains("Bad Request:") ||
                    jsonString.contains("Unauthorized:") ||
                    jsonString.contains("Forbidden:") ||
                    jsonString.contains("Not Found:") ||
                    jsonString.contains("Service Unavailable:")) {

                // Extract the JSON part from the HTTP error message
                final int jsonStart = jsonString.indexOf('{');
                if (jsonStart > 0) {
                    jsonString = jsonString.substring(jsonStart);
                }
            }

            // Handle multiple levels of string escaping
            // Continue unescaping until no more changes are made
            String prevString;
            do {
                prevString = jsonString;

                // Replace escaped quotes
                if (jsonString.contains("\\\"")) {
                    jsonString = jsonString.replace("\\\"", "\"");
                }

                // Remove surrounding quotes if present
                if (jsonString.startsWith("\"") && jsonString.endsWith("\"")) {
                    jsonString = jsonString.substring(1, jsonString.length() - 1);
                }

                // Special case for JSON escaped as string inside another JSON
                if (jsonString.contains("\\{") || jsonString.contains("\\}")) {
                    jsonString = jsonString.replace("\\{", "{").replace("\\}", "}");
                }

            } while (!prevString.equals(jsonString));

            try {
                // Try to parse as JSON
                final JsonNode jsonNode = objectMapper.readTree(jsonString);

                // Extract service message if present
                if (jsonNode.has("serviceMessage")) {
                    final JsonNode serviceMsg = jsonNode.get("serviceMessage");
                    final int code = serviceMsg.has("returnCode")
                            ? serviceMsg.get("returnCode").asInt()
                            : defaultCode;

                    String desc = serviceMsg.has("returnCodeDescription")
                            ? serviceMsg.get("returnCodeDescription").asText()
                            : "Service request failed";

                    // Don't include the JSON in the error message
                    if (desc.contains("{") && desc.contains("}")) {
                        // Try to extract inner message
                        try {
                            final JsonNode innerNode = objectMapper.readTree(desc);
                            if (innerNode.has("serviceMessage")) {
                                final JsonNode innerServiceMsg = innerNode.get("serviceMessage");
                                if (innerServiceMsg.has("returnCodeDescription")) {
                                    desc = innerServiceMsg.get("returnCodeDescription").asText();
                                }
                            }
                        } catch (final Exception e) {
                            // If we can't parse the inner message, just use what we have
                            logger.debug("Couldn't parse inner message: {}", e.getMessage());
                        }
                    }

                    return new HVWException(code, desc, service);
                }

                // Check for direct message field
                if (jsonNode.has("message")) {
                    String desc = jsonNode.get("message").asText();

                    // Clean up the message if it contains JSON
                    if (desc.contains("{") && desc.contains("}")) {
                        try {
                            final JsonNode innerNode = objectMapper.readTree(desc);
                            if (innerNode.has("serviceMessage")) {
                                final JsonNode innerServiceMsg = innerNode.get("serviceMessage");
                                if (innerServiceMsg.has("returnCodeDescription")) {
                                    desc = innerServiceMsg.get("returnCodeDescription").asText();
                                }
                            }
                        } catch (final Exception e) {
                            // If we can't parse the inner message, just use what we have
                            logger.debug("Couldn't parse inner message: {}", e.getMessage());
                        }
                    }

                    return new HVWException(defaultCode, desc, service);
                }

                return new HVWException(defaultCode, "Service request failed with status: " + defaultCode, service);

            } catch (final Exception e) {
                // If we can't parse as JSON, try to extract error information using regex
                logger.debug("Couldn't parse as JSON, trying regex: {}", e.getMessage());

                // Try to extract return code and description using regex
                final java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
                        "\"returnCode\"\\s*:\\s*(\\d+).*?\"returnCodeDescription\"\\s*:\\s*\"([^\"]+)\"");
                final java.util.regex.Matcher matcher = pattern.matcher(jsonString);

                if (matcher.find()) {
                    final int extractedCode = Integer.parseInt(matcher.group(1));
                    final String extractedDesc = matcher.group(2);
                    return new HVWException(extractedCode, extractedDesc, service);
                }
            }

            // If all parsing attempts fail, just return a cleaner version of the string
            // Remove all escaped quotes and JSON syntax for a cleaner message
            String cleanedMessage = jsonString
                    .replaceAll("\\\\\"", "")
                    .replaceAll("\\{", "")
                    .replaceAll("\\}", "")
                    .replaceAll("\"serviceMessage\":", "")
                    .replaceAll("\"returnCode\":", "")
                    .replaceAll("\"returnCodeDescription\":", "")
                    .replaceAll("\":\\s*", ": ")
                    .replaceAll(",\\s*\"", ", ");

            if (cleanedMessage.length() > 100) {
                cleanedMessage = cleanedMessage.substring(0, 100) + "...";
            }

            return new HVWException(defaultCode, cleanedMessage, service);

        } catch (final Exception e) {
            logger.debug("Failed to parse JSON string: {}", e.getMessage());

            // Last resort - return a simple error
            return new HVWException(defaultCode,
                    "Error response from service: Use the service logs for more details.",
                    service);
        }
    }

    /**
     * Extracts error details from a string that might contain embedded JSON.
     * Focuses on extracting 'returnCodeDescription' from 'serviceMessage'.
     * 
     * @param errorMessage The error message that might contain nested JSON
     * @return A clean, user-friendly error message
     */
    public static String extractNestedErrorMessage(final String errorMessage) {
        if (errorMessage == null || !errorMessage.contains("{")) {
            return errorMessage;
        }

        try {
            // Handle common error patterns with JSON inside strings
            String processedMsg = errorMessage;

            // Remove Http error prefixes if present
            if (processedMsg.contains("Bad Request:") ||
                    processedMsg.contains("Unauthorized:") ||
                    processedMsg.contains("Forbidden:") ||
                    processedMsg.contains("Not Found:")) {
                final int jsonStart = processedMsg.indexOf('{');
                if (jsonStart > 0) {
                    processedMsg = processedMsg.substring(jsonStart);
                }
            }

            // Handle escaped quotes and JSON
            processedMsg = processedMsg.replace("\\\"", "\"")
                    .replace("\\{", "{")
                    .replace("\\}", "}");

            // Extract the JSON part
            final int jsonStart = processedMsg.indexOf('{');
            final int jsonEnd = processedMsg.lastIndexOf('}') + 1;

            if (jsonStart >= 0 && jsonEnd > jsonStart) {
                final String jsonPart = processedMsg.substring(jsonStart, jsonEnd);

                // Parse the JSON to extract serviceMessage.returnCodeDescription
                final JsonNode jsonNode = objectMapper.readTree(jsonPart);

                if (jsonNode.has("serviceMessage")) {
                    final JsonNode serviceMsg = jsonNode.get("serviceMessage");
                    if (serviceMsg.has("returnCodeDescription")) {
                        return serviceMsg.get("returnCodeDescription").asText();
                    }
                }

                // If no serviceMessage found, check for direct message
                if (jsonNode.has("message")) {
                    return jsonNode.get("message").asText();
                }
            }

            return errorMessage;
        } catch (final Exception e) {
            logger.debug("Failed to extract structured error message: {}", e.getMessage());
            return errorMessage;
        }
    }

    /**
     * Checks a response body for serviceMessage structure and throws an exception
     * if an error is found.
     * This is a convenience method to standardize handling of serviceMessage across
     * services.
     * 
     * @param responseBody The response body to check
     * @param service      The service name
     * @throws HVWException if the serviceMessage indicates an error
     */
    @SuppressWarnings("unchecked")
    public static void checkServiceMessage(final Map<String, Object> responseBody, final String service) {
        if (responseBody == null) {
            return;
        }

        if (responseBody.containsKey("serviceMessage")) {
            final Map<String, Object> serviceMessage = (Map<String, Object>) responseBody.get("serviceMessage");
            if (serviceMessage.containsKey("returnCode")) {
                final int returnCode = ((Number) serviceMessage.get("returnCode")).intValue();
                // Only throw exception if returnCode is non-zero (indicating an error)
                if (returnCode != 0) {
                    final String description = serviceMessage.containsKey("returnCodeDescription")
                            ? (String) serviceMessage.get("returnCodeDescription")
                            : "Unknown error";

                    // Special case for OAuth token errors
                    if (returnCode == 30 && description.toLowerCase().contains("oauth token")) {
                        throw new HVWException(401, "Authentication token expired. Please log in again.", service);
                    }

                    throw new HVWException(returnCode, description, service);
                }
            }
        }
    }
}