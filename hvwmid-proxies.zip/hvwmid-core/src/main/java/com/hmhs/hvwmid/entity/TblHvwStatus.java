package com.hmhs.hvwmid.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "T222_HVW_STATUS")
public class TblHvwStatus {

    @EmbeddedId
    private TblHvwStatusId id;

    @Column(name = "IMG_REQUEST_ID", nullable = false, columnDefinition = "INTEGER DEFAULT 0")
    private int imgRequestId;

    @Column(name = "COD_REQUEST_ID", nullable = false, columnDefinition = "INTEGER DEFAULT 0")
    private int codRequestId;

    @Column(name = "USERID", nullable = false, length = 10, columnDefinition = "CHAR(10) DEFAULT ' '")
    private String userId;

    @Column(name = "FUNCTION", nullable = false, length = 25, columnDefinition = "CHAR(25) DEFAULT ' '")
    private String function;

    @Column(name = "ORIGINAL_URL", nullable = false, length = 255, columnDefinition = "VARCHAR(255) DEFAULT ''")
    private String originalUrl;

    @Column(name = "STATUS_CODE", nullable = false, length = 25, columnDefinition = "CHAR(25) DEFAULT ' '")
    private String statusCode;

    @Column(name = "STATUS_DESCRIPTION", nullable = false, length = 255, columnDefinition = "VARCHAR(255) DEFAULT ''")
    private String statusDescription;

    // Getters and Setters
    public TblHvwStatusId getId() {
        return id;
    }

    public void setId(TblHvwStatusId id) {
        this.id = id;
    }

    public int getRequestId() {
        return id != null ? id.getRequestId() : 0;
    }

    public void setRequestId(int requestId) {
        if (id == null) id = new TblHvwStatusId();
        id.setRequestId(requestId);
    }

    public Timestamp getTimeCreate() {
        return id != null ? id.getTimeCreate() : null;
    }

    public void setTimeCreate(Timestamp timeCreate) {
        if (id == null) id = new TblHvwStatusId();
        id.setTimeCreate(timeCreate);
    }

    public int getImgRequestId() {
		return imgRequestId;
	}

	public void setImgRequestId(int imgRequestId) {
		this.imgRequestId = imgRequestId;
	}

	public int getCodRequestId() {
		return codRequestId;
	}

	public void setCodRequestId(int codRequestId) {
		this.codRequestId = codRequestId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getOriginalUrl() {
		return originalUrl;
	}

	public void setOriginalUrl(String originalUrl) {
		this.originalUrl = originalUrl;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
 
}
