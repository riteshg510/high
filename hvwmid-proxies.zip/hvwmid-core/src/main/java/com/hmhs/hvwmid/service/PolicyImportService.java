package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;
import com.hmhs.hvwmid.enums.PolicyHeaderNameAttr;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.repository.T222ImgRmaPolicyRepository;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.hmhs.hvwmid.constants.PolicyHoldConstants.BPD_ID;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.HOLDS;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_BASE_DATE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_CODE;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_DAYS;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_DESCRIPTION;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_EDIT_FLAG;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_EDIT_PGM_NAME;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_ID;
import static com.hmhs.hvwmid.constants.PolicyHoldConstants.POLICY_ID_TYPE;

@Service
public class PolicyImportService {
    private final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    private final T222ImgRmaPolicyRepository t222ImgRmaPolicyRepository;
    private final PolicyService policyService;
    private final PolicyHoldService policyHoldService;

    public PolicyImportService(T222ImgRmaPolicyRepository t222ImgRmaPolicyRepository, PolicyService policyService, PolicyHoldService policyHoldService) {
        this.t222ImgRmaPolicyRepository = t222ImgRmaPolicyRepository;
        this.policyService = policyService;
        this.policyHoldService = policyHoldService;
    }

    public Map<String, List<String>> validatePolicySheet(InputStream inputStream) throws IOException {
        Map<String, List<String>> validationMap = new LinkedHashMap<>();
        dateFormat.setLenient(false);

        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);

            // Validate header
            Row headerRow = sheet.getRow(0);
            for (int i = 0; i < PolicyHeaderNameAttr.values().length - 2; i++) {
                String expectedHeader = PolicyHeaderNameAttr.values()[i].getHeaderName();
                if (!expectedHeader.equals(headerRow.getCell(i).getStringCellValue())) {
                    throw new IllegalArgumentException("Invalid header format, expected: " + expectedHeader);
                }
            }

            List<String> policyTypeKeys = policyService.getPolicyTypeKeys();


            List<Integer> clientIds = policyService.getClientIds();
            Set<Integer> holdIdSet = policyHoldService.getHoldIdsByBpdIdIn(clientIds);

            Map<Integer, Set<String>> bpdPolicyMap = t222ImgRmaPolicyRepository.findByBpdIdIn(clientIds)
                    .stream()
                    .collect(Collectors.groupingBy(
                            T222ImgRmaPolicy::getBpdId,
                            Collectors.mapping(T222ImgRmaPolicy::getPolicyId, Collectors.toSet())
                    ));

            Set<Integer> policyCdSet = t222ImgRmaPolicyRepository.selectAllPolicyCodes();

            // Validate rows
            for (int rowNo = 1; rowNo <= sheet.getLastRowNum(); rowNo++) {
                Row row = sheet.getRow(rowNo);

                List<String> messages = new ArrayList<>();
                validationMap.put("Row " + rowNo, messages);

                List<String> mandatoryErrors = new ArrayList<>();
                List<String> sizeErrors = new ArrayList<>();

                validateMandatoryCellsAndSize(row, mandatoryErrors, sizeErrors);

                if (mandatoryErrors.isEmpty() && sizeErrors.isEmpty()) {
                    validatePolicyColumns(row, policyTypeKeys, messages);
                    validateHoldIdColumn(row, holdIdSet, messages);
                    validatePolicyCode(row, policyCdSet, messages);
                    validatePolicyIdByBpd(row, bpdPolicyMap, messages);
                }

                if (!mandatoryErrors.isEmpty()) {
                    populateValidationMessageList(messages, "FAILED", "Missing mandatory fields: " + mandatoryErrors);
                }
                if (!sizeErrors.isEmpty()) {
                    populateValidationMessageList(messages, "FAILED", "Field length exceeds limit: " + sizeErrors);
                }
            }
        }

        return validationMap;
    }


    /**
     * Populate validation message list
     */
    public void populateValidationMessageList(List<String> messages, String status, String message) {
        messages.add(status + ": " + message);
    }

    public void validateMandatoryCellsAndSize(Row row, List<String> mandatoryErrors, List<String> sizeErrors) {
        PolicyHeaderNameAttr[] headers = PolicyHeaderNameAttr.values();

        for (int i = 0; i < headers.length; i++) {
            PolicyHeaderNameAttr header = headers[i];
            Cell cell = row.getCell(i);
            String cellValue = null;

            if (cell != null) {
                cellValue = switch (cell.getCellType()) {
                    case STRING -> cell.getStringCellValue().trim();
                    case NUMERIC -> String.valueOf((long) cell.getNumericCellValue());
                    case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
                    case FORMULA -> cell.getCellFormula();
                    case BLANK, _NONE, ERROR -> null;
                };
            }

            // Check mandatory
            if (header.isMandatory() && (cellValue == null || cellValue.isEmpty())) {
                mandatoryErrors.add(header.getHeaderName());
            }

            // Check field size if applicable
            if (header.getFieldSize() > 0 && cellValue != null && cellValue.length() > header.getFieldSize()) {
                sizeErrors.add(header.getHeaderName() + " (" + cellValue.length() + " > " + header.getFieldSize() + ")");
            }
        }
    }

    private void validatePolicyIdByBpd(Row row, Map<Integer, Set<String>> bpdPolicyMap, List<String> messages) {
        Integer bpdId = Integer.parseInt(getCellValue(row.getCell(PolicyHeaderNameAttr.BPD_ID.ordinal())));
        String policyId = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_ID.ordinal()));

        bpdPolicyMap.computeIfAbsent(bpdId, k -> new HashSet<>());

        Set<String> policySet = bpdPolicyMap.get(bpdId);
        if (policySet.contains(policyId)) {
            messages.add("Duplicate POLICY_ID " + policyId + " for BPD_ID " + bpdId);
        } else {
            policySet.add(policyId);
        }
    }


    private void validatePolicyColumns(Row row, List<String> policyTypeKeys, List<String> messages) {
        // Policy Id Type
        String policyIdType = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_ID_TYPE.ordinal()));
        if (!policyTypeKeys.contains(policyIdType)) {
            messages.add("Policy Id Type should be one of " + policyTypeKeys);
        }

        // BPD Id
        String bpdIdValue = getCellValue(row.getCell(PolicyHeaderNameAttr.BPD_ID.ordinal()));
        List<Integer> clientIds = policyService.getClientIds();
        try {
            Integer bpdIdInt = Integer.valueOf(bpdIdValue);
            if (!clientIds.contains(bpdIdInt)) {
                messages.add(PolicyHeaderNameAttr.BPD_ID.getHeaderName() + " is not a valid BPD Id: " + bpdIdValue);
            }
        } catch (NumberFormatException e) {
            messages.add(PolicyHeaderNameAttr.BPD_ID.getHeaderName() + " is not a valid integer: " + bpdIdValue);
        }


        // Policy Days
        String policyDays = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_DAYS.ordinal()));
        if (!StringUtils.isNumeric(policyDays)) {
            messages.add(PolicyHeaderNameAttr.POLICY_DAYS.getHeaderName() + " should be numeric");
        }

        // Policy Edit Flag / Program Name
        String policyEditFlag = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_EDIT_FLAG.ordinal()));
        if ("Y".equals(policyEditFlag)) {
            String pgmName = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_EDIT_PGM_NAME.ordinal()));
            if (!hasText(pgmName)) {
                messages.add(PolicyHeaderNameAttr.POLICY_EDIT_PGM_NAME.getHeaderName() + " should be populated when Edit Flag is Y");
            }
        } else if (!"N".equals(policyEditFlag)) {
            messages.add(PolicyHeaderNameAttr.POLICY_EDIT_FLAG.getHeaderName() + " should be Y/N");
        }

        // Policy Base Date
        String policyBaseDate = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_BASE_DATE.ordinal()));
        if (hasText(policyBaseDate)) {
            try {
                dateFormat.parse(policyBaseDate);
            } catch (ParseException pe) {
                messages.add(PolicyHeaderNameAttr.POLICY_BASE_DATE.getHeaderName() + " should be in yyyy-MM-dd format");
            }
        }
    }

    private void validateHoldIdColumn(Row row, Set<Integer> holdIdSet, List<String> messages) {
        String holds = getCellValue(row.getCell(PolicyHeaderNameAttr.HOLDS.ordinal()));
        if (!hasText(holds)) {
            return;
        }

        String[] holdsArray = StringUtils.split(holds, "\n");
        for (String holdStr : holdsArray) {
            holdStr = holdStr.trim();
            if (holdStr.isEmpty()) continue;

            try {
                Integer hold = Integer.valueOf(holdStr);
                if (!holdIdSet.contains(hold)) {
                    messages.add(PolicyHeaderNameAttr.HOLDS.getHeaderName() + " are not valid for the BPD Id");
                    break;
                }
            } catch (NumberFormatException e) {
                messages.add(PolicyHeaderNameAttr.HOLDS.getHeaderName() + " contains invalid number: " + holdStr);
            }
        }
    }


    private void validatePolicyCode(Row row, Set<Integer> existingPolicyCodes, List<String> messages) {
        String policyCodeStr = getCellValue(row.getCell(PolicyHeaderNameAttr.POLICY_CODE.ordinal()));

        int policyCode;
        try {
            policyCode = Integer.parseInt(policyCodeStr);
        } catch (NumberFormatException e) {
            messages.add("Policy Code is not a valid integer: " + policyCodeStr);
            return;
        }

        if (existingPolicyCodes.contains(policyCode)) {
            messages.add("Policy Code already exists (violates UNIQUE constraint): " + policyCode);
        }
    }


    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            default -> "";
        };
    }

    private boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    @Transactional
    public void importPolicyExcel(InputStream inputStream, String loginUser) {
        Map<String, String> headerMapping = getHeaderMap();

        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);

            for (int rowNo = 1; rowNo <= sheet.getLastRowNum(); rowNo++) {
                Row row = sheet.getRow(rowNo);
                if (row == null) continue;

                Map<String, String> policyFields = new LinkedHashMap<>();

                mapHeaderToRequestFields(row, headerMapping, policyFields);

                String policyCodeStr = policyFields.get(POLICY_CODE);
                if (StringUtils.isBlank(policyCodeStr)) {
                    throw new HVWException("Missing policy code at row " + (rowNo + 1));
                }

                int policyCode = Integer.parseInt(policyCodeStr);
                boolean exists = t222ImgRmaPolicyRepository.findByPolicyCode(policyCode).isPresent();

                String holdsRaw = policyFields.get(HOLDS);
                if (holdsRaw != null) {
                    holdsRaw = holdsRaw.replace("\n", ",");
                    policyFields.put(HOLDS, holdsRaw);
                }

                if (exists) {
                    policyService.updatePolicy(policyFields, loginUser);
                } else {
                    policyService.createPolicy(policyFields, loginUser);
                }
            }
        } catch (IOException e) {
            throw new HVWException("Error reading Excel file", e);
        }
    }

    private void mapHeaderToRequestFields(Row row, Map<String, String> headerMapping, Map<String, String> policyFields) {
        for (PolicyHeaderNameAttr header : PolicyHeaderNameAttr.values()) {
            String cellValue = getCellValue(row.getCell(header.ordinal()));

            // map Excel header to internal field name
            String internalField = headerMapping.get(header.getHeaderName());
            if (internalField != null) {
                policyFields.put(internalField, cellValue);
            }
        }
    }

    private static Map<String, String> getHeaderMap() {
        return Map.of(
                PolicyHeaderNameAttr.POLICY_CODE.getHeaderName(), POLICY_CODE,
                PolicyHeaderNameAttr.POLICY_ID.getHeaderName(), POLICY_ID,
                PolicyHeaderNameAttr.POLICY_DESC.getHeaderName(), POLICY_DESCRIPTION,
                PolicyHeaderNameAttr.POLICY_ID_TYPE.getHeaderName(), POLICY_ID_TYPE,
                PolicyHeaderNameAttr.BPD_ID.getHeaderName(), BPD_ID,
                PolicyHeaderNameAttr.POLICY_DAYS.getHeaderName(), POLICY_DAYS,
                PolicyHeaderNameAttr.POLICY_EDIT_FLAG.getHeaderName(), POLICY_EDIT_FLAG,
                PolicyHeaderNameAttr.POLICY_EDIT_PGM_NAME.getHeaderName(), POLICY_EDIT_PGM_NAME,
                PolicyHeaderNameAttr.POLICY_BASE_DATE.getHeaderName(), POLICY_BASE_DATE,
                PolicyHeaderNameAttr.HOLDS.getHeaderName(), HOLDS
        );
    }

}
