package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.exception.ResourceNotFoundException;
import com.hmhs.hvwmid.model.*;
import com.hmhs.hvwmid.entity.*;
import com.hmhs.hvwmid.repository.*;
import com.hmhs.hvwmid.model.CoversheetMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CoversheetServiceImpl implements CoversheetService {


    final private T117ImgCoverSheetRepository coverSheetRepo;

    final private T117ImgCoverSheetOverrideRepository coverSheetOverrideRepo;

    final private T117ImgCoverApplRepository applicationRepository;

    final private T117ImgCoverObjectRepository templateRepository;



    public CoversheetServiceImpl(T117ImgCoverSheetRepository coverSheetRepo, T117ImgCoverSheetOverrideRepository coverSheetOverrideRepo, T117ImgCoverApplRepository applicationRepository, T117ImgCoverObjectRepository templateRepository) {
        this.coverSheetRepo = coverSheetRepo;
        this.coverSheetOverrideRepo = coverSheetOverrideRepo;
        this.applicationRepository = applicationRepository;
        this.templateRepository = templateRepository;
    }

    @Override
    public List<CoverSheetDTO> getAllCoverSheets(boolean activeOnly) {

        if (activeOnly) {
            return coverSheetRepo.findAllByActive()
                    .stream()
                    .map(CoversheetMapper::toDTO)
                    .collect(Collectors.toList());
        }

        return coverSheetRepo.findAll()
                .stream()
                .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CoverSheetDTO getCoversheetByApplicationIdAndName(Integer applicationId, String coversheetName) {
        if (applicationId == null || coversheetName == null || coversheetName.isEmpty()) {
            throw new IllegalArgumentException("Application ID and Coversheet Name must not be null or empty");
        }

        T117ImgCoverSheet entity = coverSheetRepo.findByApplicationAndName(applicationId, coversheetName)
                .orElseThrow(() -> new ResourceNotFoundException("CoverSheet not found"));

        return CoversheetMapper.toDTO(entity);
    }


    @Override
    public List<CoverSheetOverrideDTO> getAllCoversheetsAndOverridesByTemplateName(String templateName) {

        List<CoverSheetOverrideDTO> overridesByTemplate = coverSheetOverrideRepo.findAllByTemplate(templateName)
                .stream()
                .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());
        List<T117ImgCoverSheet> covers = coverSheetRepo.findAllByTemplate(templateName);
        if (covers != null && !covers.isEmpty()) {
            List<CoverSheetOverrideDTO> coverSheetDTOs = covers.stream()
                    .map(c ->{
                        CoverSheetOverrideDTO dto = new CoverSheetOverrideDTO();
                        dto.setApplication(c.getApplication());
                        dto.setName(c.getName());
                        dto.setTemplate(c.getTemplate());
                        dto.setSequence(null); // Sequence is not applicable for cover sheets
                        dto.setActive(c.getActive());
                        dto.setDescription(c.getDescription());
                        dto.setEnvironment(c.getEnvironment());
                        dto.setSb1(c.getSb1());
                        dto.setEb1(c.getEb1());
                        dto.setEb2(c.getEb2());
                        dto.setEb3(c.getEb3());
                        dto.setTitle(c.getTitle());
                        dto.setStitle1(c.getStitle1());
                        dto.setStitle2(c.getStitle2());
                        dto.setUnit(c.getUnit());
                        dto.setRcode(c.getRcode());
                        return dto;
                    })
                    .collect(Collectors.toList());
            overridesByTemplate.addAll(coverSheetDTOs);
            return overridesByTemplate;
        }



        return List.of();
    }



    @Override
    public CoverSheetDTO saveCoverSheet(CoverSheetDTO dto) {
        T117ImgCoverSheet entity = CoversheetMapper.toEntity(dto);
        return CoversheetMapper.toDTO(coverSheetRepo.save(entity));
    }

    @Override
    public CoverSheetDTO updateCoverSheet(CoverSheetDTO dto) {
        T117ImgCoverSheet entity = coverSheetRepo.findByApplicationAndName(dto.getApplication(), dto.getName())
                .orElseThrow(() -> new ResourceNotFoundException("CoverSheet not found"));
        entity.setDescription(dto.getDescription());
        entity.setSb1(dto.getSb1());
        entity.setEb1(dto.getEb1());
        entity.setEb2(dto.getEb2());
        entity.setEb3(dto.getEb3());
        entity.setTitle(dto.getTitle());
        entity.setStitle1(dto.getStitle1());
        entity.setStitle2(dto.getStitle2());
        entity.setUnit(dto.getUnit());
        entity.setRcode(dto.getRcode());
        entity.setTemplate(dto.getTemplate());
        entity.setActive(dto.getActive());
        entity.setEnvironment(dto.getEnvironment());
        return CoversheetMapper.toDTO(coverSheetRepo.save(entity));
    }

    @Override
    public void deleteCoverSheet(T117ImgCoverSheetId id) {
        if (id == null || id.getApplication() == null || id.getName() == null) {
            throw new IllegalArgumentException("CoverSheet ID must not be null");
        }
        coverSheetRepo.findById(id)
                .map(entity -> {
                    entity.setActive("N");
                    return entity;
                }).ifPresent(coverSheetRepo::save);
    }

    @Override
    public List<CoverSheetOverrideDTO> getAllOverrides() {
        return coverSheetOverrideRepo.findAll()
                .stream()
                .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());
    }


    @Override
    public List<CoverSheetOverrideDTO> getCoversheetOverrideListByApplicationIdAndName(Integer applicationId, String coversheetName) {
        return coverSheetOverrideRepo.findAllByApplicationAndName(applicationId, coversheetName)
                .stream()
                .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());
    }


    @Override
    public CoverSheetOverrideDTO getCoversheetOverrideByApplicationIdAndName(Integer applicationId, String coversheetName, Integer sequence) {
        if (applicationId == null || coversheetName == null || coversheetName.isEmpty() || sequence == null) {
            throw new IllegalArgumentException("Application ID and Coversheet Name must not be null or empty");
        }

        T117ImgCoverSheetOverride entity = coverSheetOverrideRepo.findByAppNameSequence(applicationId, coversheetName, sequence)
                .orElseThrow(() -> new ResourceNotFoundException("CoverSheet not found"));

        return CoversheetMapper.toDTO(entity);
    }


    @Override
    public CoverSheetOverrideDTO createNewOveride(CoverSheetOverrideDTO override) {
        T117ImgCoverSheetOverride entity = CoversheetMapper.toEntity(override);
        int max = coverSheetOverrideRepo.findMaxSequenceByApplicationAndName(entity.getApplication(), entity.getName())+1;
        entity.setSequence(max);
        return CoversheetMapper.toDTO(coverSheetOverrideRepo.save(entity));
    }

    @Override
    public CoverSheetOverrideDTO updateOverride(CoverSheetOverrideDTO dto) {
        T117ImgCoverSheetOverride entity = coverSheetOverrideRepo.findByAppNameSequence(dto.getApplication(), dto.getName(), dto.getSequence())
                .orElseThrow(() -> new ResourceNotFoundException("CoverSheet not found"));
        entity.setDescription(dto.getDescription());
        entity.setSb1(dto.getSb1());
        entity.setEb1(dto.getEb1());
        entity.setEb2(dto.getEb2());
        entity.setEb3(dto.getEb3());
        entity.setTitle(dto.getTitle());
        entity.setStitle1(dto.getStitle1());
        entity.setStitle2(dto.getStitle2());
        entity.setUnit(dto.getUnit());
        entity.setRcode(dto.getRcode());
        entity.setTemplate(dto.getTemplate());
        entity.setActive(dto.getActive());
        entity.setEnvironment(dto.getEnvironment());
        return CoversheetMapper.toDTO(coverSheetOverrideRepo.save(entity));
    }

    @Override
    public void deleteOverride(T117ImgCoverSheetOverrideId id) {
        T117ImgCoverSheetOverride entity = coverSheetOverrideRepo.getOne(id);
        entity.setActive("N");
        coverSheetOverrideRepo.save(entity);
    }


    @Override
    public List<CoverSheetApplicationDTO> getAllApplicationsByDepartment(Integer departmentId, List<String> groups) {
       return applicationRepository.findAllByDepartmentIdAndPrintGroupIn(departmentId,groups)
                .stream()
               .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());

    }

    @Override
    public CoverSheetApplicationDTO getApplicationsById(Integer id, List<String> groups) {
        if (id == null) {
            throw new IllegalArgumentException("Application ID must not be null");
        }
        T117ImgCoverAppl entity = applicationRepository.findApplicationByIdAndPrintGroupIn(id,groups)
                .orElseThrow(() -> new ResourceNotFoundException("CoverSheet not found"));

        return CoversheetMapper.toDTO(entity);
    }




    @Override
    public List<CoverSheetDepartmentDTO> getAllApplications(boolean showInactive, List<String> groups) {
        // Fetch all applications (active or all depending on flag)
        List<T117ImgCoverAppl> allApplications = (showInactive
                ? applicationRepository.findAllByPrintGroupIn(groups)
                : applicationRepository.findAllActiveByPrintGroupIn(groups))
                .stream()
                .collect(Collectors.toList());

        // Group by department ID
        Map<Integer, List<T117ImgCoverAppl>> groupedByDept = allApplications.stream()
                .collect(Collectors.groupingBy(dto -> dto.getDepartment().getDeptId()));

        // Map to CoverSheetDepartmentDTO
        List<CoverSheetDepartmentDTO> departmentDTOs = new ArrayList<>();
        for (Map.Entry<Integer, List<T117ImgCoverAppl>> entry : groupedByDept.entrySet()) {
            T117ImgCoverAppl sample = entry.getValue().get(0); // Safe since group is non-empty

            CoverSheetDepartmentDTO deptDto = new CoverSheetDepartmentDTO();
            deptDto.setDeptId(sample.getDepartment().getDeptId());
            deptDto.setDescription(sample.getDepartment().getDescription());
            deptDto.setMaintGroup(sample.getDepartment().getMaintGroup());
            deptDto.setPrintGroup(sample.getDepartment().getPrintGroup());
            deptDto.setCanMaintain(groups.contains(sample.getDepartment().getMaintGroup()));
            deptDto.setDepartments(entry.getValue().stream()
                    .map(app -> {
                        CoverSheetApplicationDTO child = new CoverSheetApplicationDTO();
                        child.setApplication(app.getApplication());
                        child.setDescription(app.getDescription());
                        child.setSequence(app.getSequence());
                        child.setDeptId(app.getDepartment());
                        child.setActive(app.getActive());
                        child.setApplId(app.getApplId());
                        return child;
                    }).collect(Collectors.toList()));

            departmentDTOs.add(deptDto);
        }

        return departmentDTOs;
    }


//    @Override
//    public List<CoverSheetApplicationDTO> getAllApplications(boolean showInactive, List<String> groups) {
//
//        if (showInactive) {
//            return applicationRepository.findAll()
//                    .stream()
//                    .map(app->{
//                        if (groups.contains(app.getDepartment().getMaintGroup())) {
//                            CoverSheetApplicationDTO csa = CoversheetMapper.toDTO(app);
//                            csa.s
//                            etMaintenance(true);
//                            return csa;
//                        } else {
//                            // If not maintained by the user's group, skip it
//                            return CoversheetMapper.toDTO(app);
//                        }
//                    })
//                    .collect(Collectors.toList());
//        }
//
//        return applicationRepository.findAllByActive("Y")
//                .stream()
//                .map(app->{
//                    if (groups.contains(app.getDepartment().getMaintGroup())) {
//                        CoverSheetApplicationDTO csa = CoversheetMapper.toDTO(app);
//                        csa.setMaintenance(true);
//                        return csa;
//                    } else {
//                        // If not maintained by the user's group, skip it
//                        return CoversheetMapper.toDTO(app);
//                    }
//                })
//                .collect(Collectors.toList());
//    }

    @Override
    public CoverSheetApplicationDTO saveApplication(CoverSheetApplicationDTO dto) {
        T117ImgCoverAppl entity = CoversheetMapper.toEntity(dto);
        return CoversheetMapper.toDTO(applicationRepository.save(entity));
    }

    @Override
    public void deleteApplication(Integer id) {
        T117ImgCoverAppl entity = applicationRepository.getOne(id);
        entity.setActive("N");
        applicationRepository.save(entity);
    }


    @Override
    public CoversheetFileResult getCoverSheet(int applicationId, int sequence, String applicationName, boolean override) {
        String templateName;

        if (override) {
            T117ImgCoverSheetOverride entity = coverSheetOverrideRepo.findByAppNameSequence(applicationId, applicationName, sequence)
                    .orElseThrow(() -> new ResourceNotFoundException("Override not found"));
            templateName = entity.getTemplate();
        } else {
            T117ImgCoverSheet entity = coverSheetRepo.findByApplicationAndName(applicationId, applicationName)
                    .orElseThrow(() -> new ResourceNotFoundException("CoverSheet not found"));
            templateName = entity.getTemplate();
        }

        T117ImgCoverObject template = templateRepository.findByNameIgnoreCase(templateName)
                .orElseThrow(() -> new ResourceNotFoundException("Template '" + templateName + "' not found."));


        return new CoversheetFileResult(template.getObjData().getBytes(StandardCharsets.UTF_8),
                template.getMimeType(),
                template.getObjName() + ".pdf");

    }



    @Override
    public T117ImgCoverObject saveNewCoverSheetTemplate(T117ImgCoverObject template) {
        if (template.getObjName() == null || template.getObjName().isEmpty()) {
            throw new IllegalArgumentException("Template name cannot be empty");
        }
        if (template.getObjType() == null || template.getObjType().isEmpty()) {
            throw new IllegalArgumentException("Template type cannot be empty");
        }
        template.setObjName(template.getObjName().toUpperCase());
        template.setObjType(template.getObjType().toUpperCase());
        template.setActive("Y");
        return templateRepository.save(template);
    }


    @Override
    @Transactional
    public int updateCoverSheetTemplate(final T117ImgCoverObject template) {

        if (template.getObjName() == null || template.getObjName().isEmpty()) {
            throw new IllegalArgumentException("Template name cannot be empty");
        }
        if (template.getObjType() == null || template.getObjType().isEmpty()) {
            throw new IllegalArgumentException("Template type cannot be empty");
        }

        return templateRepository.updateTemplate(template.getObjName(), template.getObjType(), template.getMimeType(), template.getObjData());
    }


    /**
     * Get sequence number to add new override for Application
     * @param applicationId
     * @param applicationName
     * @return
     */
    @Override
    public int getOverrideApplSequence(int applicationId, String applicationName) {
        int maxSeq = coverSheetOverrideRepo.findMaxSequenceByApplicationAndName(applicationId, applicationName);
        return maxSeq + 1;
    }

    @Override
    public List<CoverSheetDTO> getCoversheetByApplicationId(Integer applicationId) {
        return coverSheetRepo.findAllByApplication(applicationId)
                .stream()
                .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<CoverSheetOverrideDTO> getAllOverridesByApplicationId(Integer applicationId) {
        return coverSheetOverrideRepo.findAllByApplication(applicationId)
                .stream()
                .map(CoversheetMapper::toDTO)
                .collect(Collectors.toList());
    }




    /**
     * Get next sequence number for new Cover Application
     * @return
     */
    @Override
    public int getCoverApplSequence() {
        int maxValue = applicationRepository.findMaxApplication();
        return maxValue + 1;
    }



}
