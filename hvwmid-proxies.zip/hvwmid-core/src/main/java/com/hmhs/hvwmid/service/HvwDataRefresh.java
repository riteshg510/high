package com.hmhs.hvwmid.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hmhs.hvwmid.repository.T222APRMRepository;

@Service
public class HvwDataRefresh {
	
	@Autowired
	T222APRMRepository t222aprmRepository;
	
	private Map<String, String> parmDataMapByCmodbase;
	public HvwDataRefresh() {
		
		parmDataMapByCmodbase = new HashMap<>();
	}
	
	/**
	 * This method is used to refresh parm table entries.
	 * 
	 * @param sv
	 * @throws SQLException
	 *//*
	public void refreshParmData(short sv) throws Exception {
		parmDataMapByCmodbase = getStringParmData(HVWConstants.CMBASE);
	}
	*/
	
	/**
	 * This method returns parmData for parmKey for parmId 'CMBASE'
	 * 
	 * @param parmKey
	 * @param defaultParmKeyData
	 * @return parmData
	 */
	public String getParmDataByKeyByCmodbase(String parmKey, String defaultParmKeyData) {
		if (!parmDataMapByCmodbase.isEmpty() && parmDataMapByCmodbase.containsKey(parmKey)) {
			return parmDataMapByCmodbase.get(parmKey);
		}
		return defaultParmKeyData;
	}
	
	/**
	 * Get the parm data from the T222APRM Table for PARM ID IMGBASE
	 * 
	 * @param PARAM ID
	 * @return returns the PARAM_KEY and PARAM_DATA
	 *//*
	public Map<String, String> getStringParmData(String parmid) throws Exception {
		Map<String, String> parmDataMap = new HashMap<>();
		try {
			List<T222APRM> t222aprmsList = t222aprmRepository.findParmKeyDataByParmIdIgnoreCase(parmid);
			for (T222APRM entityRow : t222aprmsList) {
				parmDataMap.put(entityRow.getParmKey().trim(),
						entityRow.getParmData().replaceAll(PARMDATA_REGEX_FOR_COMMENTS, "").trim());
			}
		} catch (Exception e) {
			throw new Exception("Exception in getting Parm Data from DB2 : " + e.getMessage());
		}

		return parmDataMap;
	} */
}
