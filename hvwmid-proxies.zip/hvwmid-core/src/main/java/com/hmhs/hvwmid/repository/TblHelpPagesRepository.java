package com.hmhs.hvwmid.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hmhs.hvwmid.entity.TblHelpPages;

/**
 * @author Ramanjaneyulu Manam on Mar 28, 2025
 */
@Repository
public interface TblHelpPagesRepository extends CrudRepository<TblHelpPages, String> {

	TblHelpPages getHelpPageByOdFolderName(String comfolderName);

}
