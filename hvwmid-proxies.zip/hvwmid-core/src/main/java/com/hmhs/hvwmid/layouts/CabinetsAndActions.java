package com.hmhs.hvwmid.layouts;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblActions;
import com.hmhs.hvwmid.entity.TblCabinets;
import com.hmhs.hvwmid.entity.TblDepartment;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblLdapCabinets;
import com.hmhs.hvwmid.model.Action;
import com.hmhs.hvwmid.model.Cabinet;
import com.hmhs.hvwmid.model.Cabinets;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.UserCabinetService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.RestClientUtil;

import jakarta.persistence.Embeddable;

/**
 * @author Ramanjaneyulu Manam on Nov 20, 2024
 */
@Component
@Embeddable
public class CabinetsAndActions {

	@Value("${controller.path.cab}")
	private String basePath;

	@Value("${api.images.workflow.url}")
	String url = null;

	@Value("${app.environment:default}")
	private String environment;

	private static final Logger logger = LogManager.getLogger(CabinetsAndActions.class);

	private final String template = HVWConstants.TEMPLATE;
	private final String singleCabinet = HVWConstants.SINGLECABINET;
	private final String workflow = HVWConstants.WORKFLOW;
	private final String cmodFolderName = HVWConstants.CMODFOLDERNAME;
	public List<TblCabinets> userLDAPCabinets = new ArrayList<>();
	@Autowired
	private AppDataService service;

	public AppDataService getService() {
		return service;
	}

	@Autowired
	private RestClientUtil restClientUtil;

	public void setService(AppDataService service) {
		this.service = service;
	}

	/** Retrieves cabinets and actions for the authenticated user */
	public List<Cabinets> getUserCabinetsAndActions(UserCabinetService userCabinetService, String authToken) {
		String loginUser = HVWConstants.UID;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
		} catch (Exception e) {
			logger.warn("Failed to get user ID from JWT", e);
		}
		getLdapGroupUserCabinets(authToken);
		List<String> userCabinetIds = userCabinetService.getUserCabinets(loginUser.toUpperCase());
		return getUserCabinetsAndActions(userCabinetIds);
	}

	public List<Cabinets> getUserCabinetsAndActions(List<String> userCabinetIds) {
		List<Cabinets> response = new ArrayList<>();
		List<TblCabinets> userCabinets = new ArrayList<>(service.getCabinetsByCabinetIds(userCabinetIds));
		Set<String> userLDAPAllCabinetIds = userLDAPCabinets.stream()
				.map(TblCabinets::getCabinetId)
				.collect(Collectors.toSet());
		userCabinets.removeIf(cabinet -> !userLDAPAllCabinetIds.contains(cabinet.getCabinetId()));
		List<String> userFavCabinetIds = userCabinets.stream().map(TblCabinets::getCabinetId)
				.collect(Collectors.toList());

		List<String> departmentIds = service.getDepartmentIdsByUserCabinetIds(userFavCabinetIds);
		List<TblDepartment> ldep = service.getDepartmentsByDeptIds(departmentIds);

		if (ldep != null) {
			for (TblDepartment tblDep : ldep) {
				Cabinets cabts = new Cabinets();
				Cabinet dep = new Cabinet();
				dep.setId(tblDep.getDepartmentId());
				dep.setCabinetName(tblDep.getDepartmentName());

				List<Cabinet> cabinetsList = createCabinetList(tblDep, userCabinets);
				if (!cabinetsList.isEmpty()) {
					cabts.setData(dep);
					cabts.setChildren(cabinetsList);
					response.add(cabts);
				}
			}
		}
		return response;
	}

	private List<Cabinet> createCabinetList(TblDepartment tblDep, List<TblCabinets> ucab) {
		List<Cabinet> cabinetsList = new ArrayList<>();
		if (ucab != null) {
			for (TblCabinets tblCab : ucab) {
				if (tblCab.getDepartmentId().equalsIgnoreCase(tblDep.getDepartmentId())) {
					Cabinet cab = new Cabinet();
					cab.setId(tblCab.getCabinetId());
					cab.setDocumentClass(tblCab.getCabinetName());

					List<Action> actionsList = createActionsForCabinet(tblCab);
					actionsList.add(0, createRemoveAction(tblCab));

					cab.setActions(actionsList);
					cabinetsList.add(cab);
				}
			}
		}
		return cabinetsList;
	}

	public void getLdapGroupUserCabinets(String authToken) {
		Set<String> memberSet = HVWUtils.getUserGroups(authToken).stream()
				.map(String::trim)
				.collect(Collectors.toSet());

		if (userLDAPCabinets == null) {
			userLDAPCabinets = new ArrayList<>();
		} else {
			userLDAPCabinets.clear();
		}
		service.getLDAPGroups().stream()
				.filter(memberSet::contains)
				.flatMap(groupName -> service.getCabinetsNamesByGroupName(groupName).stream())
				.map(TblLdapCabinets::getCabinetId)
				.distinct()
				.collect(Collectors.collectingAndThen(Collectors.toList(), cabinetIds -> {

					List<TblCabinets> cabinets = service.getCabinetsByCabinetIds(cabinetIds);
					userLDAPCabinets.addAll(cabinets);
					return null;
				}));
	}

	/** Retrieves cabinets and actions for a specific user groups */
	public List<Cabinets> getCabinetsAndActionsByGroup(String authToken) {
		List<TblDepartment> departments = new ArrayList<>();
		getLdapGroupUserCabinets(authToken);
		Set<String> userDepartmentIds = userLDAPCabinets.stream()
				.map(TblCabinets::getDepartmentId)
				.collect(Collectors.toSet());
		Set<String> set = new HashSet<>(userDepartmentIds);
		List<String> deptIds = new ArrayList<>(set);
		departments = service.getDepartmentsByDeptIds(deptIds);
		return getCabinetsAndActions(departments);
	}

	/** Retrieves cabinets and their actions based on a list of departments */
	public List<Cabinets> getCabinetsAndActions(List<TblDepartment> departments) {
		List<Cabinets> response = new ArrayList<>();
		if (departments != null) {
			for (TblDepartment tblDep : departments) {
				Cabinets cabinetWrapper = createCabinetWrapper(tblDep);
				if (!cabinetWrapper.getChildren().isEmpty()) {
					response.add(cabinetWrapper);
				}
			}
		}
		return response;
	}

	/** Creates a wrapper around cabinets */
	private Cabinets createCabinetWrapper(TblDepartment tblDep) {
		Cabinets cabinetWrapper = new Cabinets();
		Cabinet departmentCabinet = new Cabinet();
		departmentCabinet.setId(tblDep.getDepartmentId());
		departmentCabinet.setCabinetName(tblDep.getDepartmentName());
		List<TblCabinets> cabinets = service.getCabinetsByDepartmentId(tblDep.getDepartmentId());
		Set<String> userCabinetIds = userLDAPCabinets.stream()
				.map(TblCabinets::getCabinetId)
				.collect(Collectors.toSet());
		cabinets.removeIf(cabinet -> !userCabinetIds.contains(cabinet.getCabinetId()));
		List<Cabinet> cabinetList = cabinets.stream().map(this::createCabinetWithActions).collect(Collectors.toList());

		cabinetWrapper.setData(departmentCabinet);
		cabinetWrapper.setChildren(cabinetList);
		return cabinetWrapper;
	}

	/** Creates a cabinet and its associated actions */
	private Cabinet createCabinetWithActions(TblCabinets tblCab) {
		Cabinet cabinet = new Cabinet();
		cabinet.setId(tblCab.getCabinetId());
		cabinet.setDocumentClass(tblCab.getCabinetName());

		List<Action> actions = createActionsForCabinet(tblCab);
		actions.add(0, createAddAction(tblCab)); // Adding 'add' action at the start

		cabinet.setActions(actions);
		return cabinet;
	}

	/** Creates a list of actions for a given cabinet */
	private List<Action> createActionsForCabinet(TblCabinets tblCab) {
		List<Action> actions = new ArrayList<>();
		List<TblActions> tblActions = service.getActionsByFormId(tblCab.getCabinetId());

		if (tblActions != null) {
			for (TblActions tblAction : tblActions) {
				actions.add(createAction(tblAction, tblCab));
			}
		}
		return actions;
	}

	/** Processes the navigation URL and creates an Action object */
	private Action createAction(TblActions tblAction, TblCabinets tblCab) {
		Action action = new Action();
		action.setLabel(tblAction.getLabel());
		action.setNavigateUrl(appendCabinetId(processNavigateUrl(tblAction, tblCab), tblCab.getCabinetId()));
		return action;
	}

	/** Optimizes navigation URL processing */
	private String processNavigateUrl(TblActions tblAction, TblCabinets tblCab) {
		String navigateUrl = tblAction.getNavigateUrl();
		if (navigateUrl.startsWith("ImgSessionMgr")) {
			return handleImageSessionUrl(tblAction, navigateUrl);
		} else {
			return refineNavigateUrl(tblAction);
		}
	}

	/** Handles Image Session URLs */
	private String handleImageSessionUrl(TblActions tblAction, String navigateUrl) {
		Map<String, String> queryParams = getQueryMap(navigateUrl);
		boolean redirect = queryParams.containsKey(template);

		StringBuilder redirectUrl = new StringBuilder();
		StringBuilder idUrl = new StringBuilder();
		if (!queryParams.isEmpty() && redirect) {
			appendQueryParameters(tblAction, queryParams, idUrl, redirectUrl);
			redirectUrl.setLength(redirectUrl.length() - 1);
			return idUrl + redirectUrl.toString();
		} else if (!queryParams.isEmpty() && queryParams.containsKey(cmodFolderName)) {
			appendQueryParameters(tblAction, queryParams, idUrl, redirectUrl);
			return idUrl.toString();
		} else {
			return basePath + "/" + navigateUrl;
		}
	}

	/** Refines standard navigation URLs */
	private String refineNavigateUrl(TblActions tblAction) {
		String navigateUrl = tblAction.getNavigateUrl().replace(".html", "").replace(".htm", "");

		List<TblForms> forms = service.getFormIdByFileName(navigateUrl);
		if (forms != null && !forms.isEmpty()) {
			navigateUrl = singleCabinet + forms.get(0).getFormId();
		} else {
			if (tblAction.getLabel().toLowerCase().contains("work")) {
				navigateUrl = HVWConstants.WORKFLOW + navigateUrl;
			} else if (tblAction.getLabel().toLowerCase().contains("scan")) {
				navigateUrl = HVWConstants.CABINETSCAN + navigateUrl;
			} else {
				navigateUrl = HVWConstants.SINGLECABINET + navigateUrl;
			}
		}
		return navigateUrl;
	}

	/** Append CabinetId navigation URLs */
	private String appendCabinetId(String baseUrl, String cabinetId) {
		String separator = baseUrl.contains("?") ? "&" : "?";
		return baseUrl + separator + "cabinetid=" + cabinetId;
	}

	/** Creates an "Add" action */
	private Action createAddAction(TblCabinets tblCab) {
		Action addAction = new Action();
		addAction.setActionName("add");
		addAction.setActionIcon("add");
		addAction.setApiUrl(basePath + "/favorites/add/" + tblCab.getCabinetId());
		addAction.setActionType("submit");
		return addAction;
	}

	/** Creates an "Remove" action */
	private Action createRemoveAction(TblCabinets tblCab) {
		Action removeAction = new Action();
		removeAction.setActionName("remove");
		removeAction.setActionIcon("remove");
		removeAction.setApiUrl(basePath + "/favorites/remove/" + tblCab.getCabinetId());
		removeAction.setActionType("submit");
		return removeAction;
	}

	public static Map<String, String> getQueryMap(String query) {
		Map<String, String> map = new HashMap<>();
		if (query.contains("&")) {
			String[] params = query.split("&");
			for (String param : params) {
				String name = param.split("=")[0];
				String value = "";
				if (param.split("=").length > 1)
					value = param.split("=")[1];
				map.put(name, value);
			}
		}
		return map;
	}

	void appendQueryParameters(TblActions tblAction, Map<String, String> queryParams, StringBuilder idUrl,
			StringBuilder redirectUrl) {
		queryParams.forEach((key, value) -> {
			if (key.equalsIgnoreCase(template)) {
				List<TblForms> form = service.getFormIdByFileName(value.replaceFirst("[.][^.]+$", ""));
				if (!form.isEmpty()) {
					if (value.toLowerCase().contains("work"))
						idUrl.append(workflow + form.get(0).getFormId() + "?");
					else if (value.toLowerCase().contains("scan"))
						idUrl.append(HVWConstants.CABINETSCAN + form.get(0).getFormId() + "?");
					else
						idUrl.append(singleCabinet + form.get(0).getFormId() + "?");
				} else
					idUrl.append("pages/ImgSessionMgr?" + key).append("=").append(value).append("&");
			} else if (key.equalsIgnoreCase(cmodFolderName)) {
				idUrl.append(HVWConstants.SINGLEREPORT + value);
			} else
				redirectUrl.append(key.replace("ImgSessionMgr?", "")).append("=").append(value).append("&");
		});
	}

	public String updateCabinetsTableDate(String cabinetId) {
		return service.updateCabinetsTable(cabinetId);
	}

	public ResponseEntity<Object> dropWorkflow(Map<String, String> otherFields, String authToken) {
		Map<String, String> resBody = new HashMap<>();
		if (otherFields != null && !otherFields.isEmpty() && otherFields.containsKey("foldid")
				&& otherFields.containsKey("applidcd") && otherFields.containsKey("documentToken")) {
			if ("Noservice".equalsIgnoreCase(environment)) {
				for (Map.Entry<String, String> entry : otherFields.entrySet()) {
					String value = entry.getValue();
					if (value != null && !value.trim().isEmpty()) {
						if (!entry.getKey().equals("applidcd") && !entry.getKey().equals("foldid")
								&& !entry.getKey().equals("documentToken"))
							resBody.put(entry.getKey(), " is changed to " + value);
					} else {
						resBody.put(entry.getKey(), "is not changed");
					}
					resBody.put("Drop", "successful.");
				}
				return new ResponseEntity<>(resBody, HttpStatus.OK);
			}
			otherFields.put("function", "drop");
			otherFields.put("unit", "");
			otherFields.put("rcode", "");
			final ResponseEntity<Map> response = getFromBack(otherFields, authToken);
			Map<String, Object> result = getResults(response.getBody());
			if (result != null && result.get("ReturnCode") instanceof Integer
					&& (Integer) result.get("ReturnCode") == 0) {
				for (Map.Entry<String, String> entry : otherFields.entrySet()) {
					String value = entry.getValue();
					if (value != null && !value.trim().isEmpty()) {
						if (!entry.getKey().equals("applidcd") && !entry.getKey().equals("foldid")
								&& !entry.getKey().equals("documentToken"))
							resBody.put(entry.getKey(), " is changed to " + value);
					} else {
						resBody.put(entry.getKey(), "is not changed");
					}
					resBody.put("Drop", "successful.");
				}
			} else {
				resBody.put("Drop", " failed..!");
				resBody.put("ReturnCode", result.get("ReturnCode").toString());
				resBody.put("ReasonCode", result.get("ReasonCode").toString());
				resBody.put("Message", result.get("Message").toString());
			}
			return new ResponseEntity<>(resBody, response.getStatusCode());
		}
		resBody.put("Message",
				"One of the required field (applidcd, authToken, documentToken, foldid) value not available.");
		return new ResponseEntity<>(resBody, HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Object> reRouteWorkflow(Map<String, String> otherFields, String authToken) {
		Map<String, Object> resBody = new HashMap<>();
		if (otherFields != null && !otherFields.isEmpty() && otherFields.containsKey("foldid")
				&& otherFields.containsKey("applidcd") && otherFields.containsKey("documentToken")
				&& otherFields.containsKey("unit") && otherFields.containsKey("rcode")) {
			otherFields.put("unit", otherFields.get("unit"));
			otherFields.put("function", "reroute");
			final ResponseEntity<Map> response = getFromBack(otherFields, authToken);
			Map<String, Object> result = getResults(response.getBody());
			return new ResponseEntity<>(result, response.getStatusCode());
		}
		resBody.put("Message",
				"One of the required field (applidcd, authToken, documentToken, foldid, rcode, unit) value not available.");
		return new ResponseEntity<>(resBody, HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Object> getNewWork(Map<String, String> otherFields, String authToken) {
		Map<String, Object> resBody = new HashMap<>();
		if ("Noservice".equalsIgnoreCase(environment)) {
			Map<String, Object> response = new HashMap<>();
			for (Map.Entry<String, String> entry : otherFields.entrySet()) {
				response.put(entry.getKey(), entry.getValue());
			}
			LocalDateTime start = LocalDateTime.of(2025, 10, 10, 0, 0, 0, 1000000);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
			LocalDateTime end = start.plus(24323, ChronoUnit.MICROS);
			String foldtkn = start.format(formatter);
			String objtime = end.format(formatter);
			response.put("foldid", "20251010001");
			response.put("foldtkn", foldtkn);
			response.put("objtime", objtime);
			response.put("documentToken", "03" + String.format("%05d", Integer.parseInt(otherFields.get("applidcd")))
					+ foldtkn + objtime + "TIMG");
			response.put("assignto", "liduser");
			response.put("authToken", authToken);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		if (otherFields != null && !otherFields.isEmpty() && otherFields.containsKey("applidcd")) {
			otherFields.put("unit", otherFields.get("unit") == null ? "" : otherFields.get("unit"));
			otherFields.put("rcode", otherFields.get("rcode") == null ? "" : otherFields.get("rcode"));
			otherFields.put("function", "getWork");
			final ResponseEntity<Map> response = getFromBack(otherFields, authToken);
			Map<String, Object> result = getResults(response.getBody());
			return new ResponseEntity<>(result, response.getStatusCode());
		}
		resBody.put("Message",
				"One of the required field (applidcd, authToken) value not available.");
		return new ResponseEntity<>(resBody, HttpStatus.BAD_REQUEST);
	}

	private ResponseEntity<Map> getFromBack(Map<String, String> otherFields, String authToken) {
		return restClientUtil.postRequest(url, authToken, new HashMap<>(), otherFields);
	}

	private Map<String, Object> getResults(Map response) {
		Map<String, Object> results = new HashMap<>();
		if (response.containsKey("WorkflowResult")) {
			Map workdata = (Map) response.get("WorkflowResult");
			if (workdata.containsKey("Results")) {
				results = (Map) workdata.get("Results");
			}
		}
		return results;
	}

	public ResponseEntity<Object> addNewWork(Map<String, String> otherFields, String authToken) {
		Map<String, Object> resBody = new HashMap<>();
		if ("Noservice".equalsIgnoreCase(environment)) {
			Map<String, Object> response = new HashMap<>();
			for (Map.Entry<String, String> entry : otherFields.entrySet()) {
				response.put(entry.getKey(), entry.getValue());
			}
			LocalDateTime start = LocalDateTime.of(2025, 10, 10, 0, 0, 0, 1000000);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");
			LocalDateTime end = start.plus(24323, ChronoUnit.MICROS);
			String foldtkn = start.format(formatter);
			String objtime = end.format(formatter);
			response.put("foldid", "20251010001");
			response.put("foldtkn", foldtkn);
			response.put("objtime", objtime);
			response.put("documentToken", "03" + String.format("%05d", Integer.parseInt(otherFields.get("applidcd")))
					+ foldtkn + objtime + "TIMG");
			response.put("assignto", "liduser");
			response.put("authToken", authToken);
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		if (otherFields != null && !otherFields.isEmpty() && otherFields.containsKey("applidcd")) {
			otherFields.put("unit", otherFields.get("unit") == null ? "" : otherFields.get("unit"));
			otherFields.put("rcode", otherFields.get("rcode") == null ? "" : otherFields.get("rcode"));
			otherFields.put("function", "addWork");
			final ResponseEntity<Map> response = getFromBack(otherFields, authToken);
			Map<String, Object> result = getResults(response.getBody());
			return new ResponseEntity<>(result, response.getStatusCode());
		}
		resBody.put("Message",
				"One of the required field (applidcd, authToken) value not available.");
		return new ResponseEntity<>(resBody, HttpStatus.BAD_REQUEST);
	}
}
