package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CoversheetFileResultTest {

    @Test
    void constructor_shouldCreateObjectWithAllFields() {
        // Given
        byte[] data = "Test file content".getBytes();
        String mimeType = "application/pdf";
        String filename = "test.pdf";

        // When
        CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

        // Then
        assertArrayEquals(data, result.getData());
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
    }

    @Test
    void constructor_shouldHandleNullData() {
        // Given
        byte[] data = null;
        String mimeType = "text/plain";
        String filename = "test.txt";

        // When
        CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

        // Then
        assertNull(result.getData());
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
    }

    @Test
    void constructor_shouldHandleNullMimeType() {
        // Given
        byte[] data = "content".getBytes();
        String mimeType = null;
        String filename = "test.txt";

        // When
        CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

        // Then
        assertArrayEquals(data, result.getData());
        assertNull(result.getMimeType());
        assertEquals(filename, result.getFilename());
    }

    @Test
    void constructor_shouldHandleNullFilename() {
        // Given
        byte[] data = "content".getBytes();
        String mimeType = "text/plain";
        String filename = null;

        // When
        CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

        // Then
        assertArrayEquals(data, result.getData());
        assertEquals(mimeType, result.getMimeType());
        assertNull(result.getFilename());
    }

    @Test
    void constructor_shouldHandleAllNullValues() {
        // When
        CoversheetFileResult result = new CoversheetFileResult(null, null, null);

        // Then
        assertNull(result.getData());
        assertNull(result.getMimeType());
        assertNull(result.getFilename());
    }

    @Test
    void getData_shouldReturnSameArrayReference() {
        // Given
        byte[] originalData = "Test content".getBytes();
        CoversheetFileResult result = new CoversheetFileResult(originalData, "text/plain", "test.txt");

        // When
        byte[] retrievedData = result.getData();

        // Then
        assertSame(originalData, retrievedData);
        
        // Modifying the original array should affect the returned data
        originalData[0] = 'X';
        assertEquals('X', result.getData()[0]);
    }

    @Test
    void constructor_shouldHandleEmptyByteArray() {
        // Given
        byte[] emptyData = new byte[0];
        String mimeType = "application/octet-stream";
        String filename = "empty.bin";

        // When
        CoversheetFileResult result = new CoversheetFileResult(emptyData, mimeType, filename);

        // Then
        assertEquals(0, result.getData().length);
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
    }

    @Test
    void constructor_shouldHandleLargeBinaryData() {
        // Given
        byte[] largeData = new byte[10000];
        for (int i = 0; i < largeData.length; i++) {
            largeData[i] = (byte) (i % 256);
        }
        String mimeType = "application/octet-stream";
        String filename = "large.bin";

        // When
        CoversheetFileResult result = new CoversheetFileResult(largeData, mimeType, filename);

        // Then
        assertEquals(10000, result.getData().length);
        assertEquals((byte) 0, result.getData()[0]);
        assertEquals((byte) 255, result.getData()[255]);
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
    }

    @Test
    void constructor_shouldHandleVariousMimeTypes() {
        // Test different MIME types
        String[] mimeTypes = {
            "application/pdf",
            "text/html",
            "image/jpeg",
            "application/json",
            "text/plain; charset=UTF-8",
            "multipart/form-data",
            "application/octet-stream"
        };

        byte[] data = "content".getBytes();
        String filename = "test.file";

        for (String mimeType : mimeTypes) {
            // When
            CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

            // Then
            assertEquals(mimeType, result.getMimeType());
        }
    }

    @Test
    void constructor_shouldHandleVariousFilenames() {
        // Test different filename patterns
        String[] filenames = {
            "simple.txt",
            "file with spaces.pdf",
            "file-with-dashes.html",
            "file_with_underscores.json",
            "FILE.WITH.DOTS.xml",
            "fileWithoutExtension",
            "very-long-filename-that-might-cause-issues-in-some-systems.docx",
            "unicode-filename-tëst.pdf",
            ""
        };

        byte[] data = "content".getBytes();
        String mimeType = "text/plain";

        for (String filename : filenames) {
            // When
            CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

            // Then
            assertEquals(filename, result.getFilename());
        }
    }

    @Test
    void constructor_shouldHandleSpecialCharactersInFields() {
        // Given
        byte[] data = "Special chars: !@#$%^&*()".getBytes();
        String mimeType = "text/plain; charset=UTF-8";
        String filename = "special!@#$%^&*().txt";

        // When
        CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

        // Then
        assertArrayEquals(data, result.getData());
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
    }

    @Test
    void fields_shouldBeFinalAndImmutable() {
        // Given
        byte[] data = "original content".getBytes();
        String mimeType = "text/plain";
        String filename = "test.txt";

        // When
        CoversheetFileResult result = new CoversheetFileResult(data, mimeType, filename);

        // Then - Since fields are final, we can't modify them after construction
        // This test verifies the immutable nature by ensuring getters return consistent values
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
        assertArrayEquals(data, result.getData());

        // Verify multiple calls return the same values
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
        assertArrayEquals(data, result.getData());
    }

    @Test
    void constructor_shouldHandleUtf8EncodedData() {
        // Given
        String utf8Content = "Unicode content: 测试 Tëst Üñîçødë";
        byte[] utf8Data = utf8Content.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String mimeType = "text/plain; charset=UTF-8";
        String filename = "unicode-test.txt";

        // When
        CoversheetFileResult result = new CoversheetFileResult(utf8Data, mimeType, filename);

        // Then
        assertArrayEquals(utf8Data, result.getData());
        assertEquals(mimeType, result.getMimeType());
        assertEquals(filename, result.getFilename());
        
        // Verify we can reconstruct the original string
        String reconstructed = new String(result.getData(), java.nio.charset.StandardCharsets.UTF_8);
        assertEquals(utf8Content, reconstructed);
    }
}