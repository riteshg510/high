package com.hmhs.hvwmid.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import javax.sql.DataSource;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CodCachingRepositoryTest {

    private DataSource dataSource;
    private Connection connection;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    private CodCachingRepository repository;

    @BeforeEach
    void setUp() throws Exception {
        dataSource = mock(DataSource.class);
        connection = mock(Connection.class);
        preparedStatement = mock(PreparedStatement.class);
        resultSet = mock(ResultSet.class);

        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
        when(preparedStatement.executeQuery()).thenReturn(resultSet);

        repository = new CodCachingRepository(dataSource);
    }

    @Test
    void streamSegmentsByRequestId_shouldStreamDataCorrectly() throws Exception {
        byte[] mockData = "Test data segment".getBytes();
        InputStream mockInputStream = new ByteArrayInputStream(mockData);

        when(resultSet.next()).thenReturn(true, false); // only one row
        when(resultSet.getBinaryStream(1)).thenReturn(mockInputStream);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();


        repository.streamSegmentsByRequestId(123, outputStream);


        assertArrayEquals(mockData, outputStream.toByteArray());
        verify(preparedStatement).setInt(1, 123);
    }

    @Test
    void streamSegmentsByRequestId_shouldHandleNullStreamGracefully() throws Exception {
        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getBinaryStream(1)).thenReturn(null); // null stream

        ByteArrayOutputStream outputStream = spy(new ByteArrayOutputStream());

        repository.streamSegmentsByRequestId(456, outputStream);


        verify(outputStream).flush();
        assertEquals(0, outputStream.size());
    }

    @Test
    void streamSegmentsByRequestId_shouldPropagateSQLException() throws Exception {
        when(dataSource.getConnection()).thenThrow(new SQLException("DB error"));

        assertThrows(SQLException.class, () ->
                repository.streamSegmentsByRequestId(999, new ByteArrayOutputStream()));
    }

    @Test
    void streamSegmentsByRequestId_shouldPropagateIOException() throws Exception {
        InputStream faultyStream = mock(InputStream.class);
        when(faultyStream.read(any())).thenThrow(new IOException("Read failed"));

        when(resultSet.next()).thenReturn(true, false);
        when(resultSet.getBinaryStream(1)).thenReturn(faultyStream);

        assertThrows(IOException.class, () ->
                repository.streamSegmentsByRequestId(789, new ByteArrayOutputStream()));
    }
}
