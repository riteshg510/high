package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for TblImgObject entity
 */
class TblImgObjectTest {

    private TblImgObject imgObject;
    private TblImgObjectId id;
    private TblImgToken imgToken;

    @BeforeEach
    void setUp() {
        imgObject = new TblImgObject();
        
        // Create a composite key
        id = new TblImgObjectId();
        id.setRequestId(12345);
        id.setSequenceNo(1);
        
        // Create a mock TblImgToken
        imgToken = new TblImgToken();
    }

    @Test
    void testGetSetId() {
        // Act
        imgObject.setId(id);

        // Assert
        assertEquals(id, imgObject.getId());
        assertEquals(Integer.valueOf(12345), imgObject.getId().getRequestId());
        assertEquals(Integer.valueOf(1), imgObject.getId().getSequenceNo());
    }

    @Test
    void testSetAndGetTimeCreate() {
        // Arrange
        Timestamp timestamp = Timestamp.valueOf(LocalDateTime.now());

        // Act
        imgObject.setTimeCreate(timestamp);

        // Assert
        assertEquals(timestamp, imgObject.getTimeCreate());
    }

    @Test
    void testSetAndGetObjectSegment() {
        // Arrange
        byte[] testData = "Test binary data for object segment".getBytes();

        // Act
        imgObject.setObjectSegment(testData);

        // Assert
        assertArrayEquals(testData, imgObject.getObjectSegment());
    }

    @Test
    void testGetSetObjectSegmentWithLargeData() {
        // Arrange - Create data close to the 31KB limit
        byte[] largeData = new byte[31000];
        for (int i = 0; i < largeData.length; i++) {
            largeData[i] = (byte) (i % 256);
        }

        // Act
        imgObject.setObjectSegment(largeData);

        // Assert
        assertArrayEquals(largeData, imgObject.getObjectSegment());
        assertEquals(31000, imgObject.getObjectSegment().length);
    }

    @Test
    void testGetSetObjectSegmentWithNullData() {
        // Act
        imgObject.setObjectSegment(null);

        // Assert
        assertNull(imgObject.getObjectSegment());
    }

    @Test
    void testGetSetObjectSegmentWithEmptyData() {
        // Arrange
        byte[] emptyData = new byte[0];

        // Act
        imgObject.setObjectSegment(emptyData);

        // Assert
        assertArrayEquals(emptyData, imgObject.getObjectSegment());
        assertEquals(0, imgObject.getObjectSegment().length);
    }

    @Test
    void testGetSetImgToken() {
        // Act
        imgObject.setImgToken(imgToken);

        // Assert
        assertEquals(imgToken, imgObject.getImgToken());
    }

    @Test
    void testGetSetImgTokenWithNull() {
        // Act
        imgObject.setImgToken(null);

        // Assert
        assertNull(imgObject.getImgToken());
    }

    @Test
    void testCompleteObjectSetup() {
        // Arrange
        Timestamp timestamp = Timestamp.valueOf(LocalDateTime.of(2024, 1, 15, 10, 30, 0));
        byte[] testData = "Complete test data".getBytes();

        // Act
        imgObject.setId(id);
        imgObject.setTimeCreate(timestamp);
        imgObject.setObjectSegment(testData);
        imgObject.setImgToken(imgToken);

        // Assert
        assertEquals(id, imgObject.getId());
        assertEquals(timestamp, imgObject.getTimeCreate());
        assertArrayEquals(testData, imgObject.getObjectSegment());
        assertEquals(imgToken, imgObject.getImgToken());
    }

    @Test
    void testDefaultConstructor() {
        // Act
        TblImgObject newObject = new TblImgObject();

        // Assert
        assertNull(newObject.getId());
        assertNull(newObject.getTimeCreate());
        assertNull(newObject.getObjectSegment());
        assertNull(newObject.getImgToken());
    }

    @Test
    void testObjectSegmentBinaryData() {
        // Arrange - Test with various binary data including special bytes
        byte[] binaryData = new byte[256];
        for (int i = 0; i < 256; i++) {
            binaryData[i] = (byte) i;
        }

        // Act
        imgObject.setObjectSegment(binaryData);

        // Assert
        assertArrayEquals(binaryData, imgObject.getObjectSegment());
        // Verify all byte values are preserved
        for (int i = 0; i < 256; i++) {
            assertEquals((byte) i, imgObject.getObjectSegment()[i]);
        }
    }

    @Test
    void testTimeCreateWithCurrentTimestamp() {
        // Arrange
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());

        // Act
        imgObject.setTimeCreate(currentTime);

        // Assert
        assertEquals(currentTime, imgObject.getTimeCreate());
        assertNotNull(imgObject.getTimeCreate());
    }

    @Test
    void testIdAssociation() {
        // Arrange
        TblImgObjectId customId = new TblImgObjectId();
        customId.setRequestId(99999);
        customId.setSequenceNo(5);

        // Act
        imgObject.setId(customId);

        // Assert
        assertEquals(customId, imgObject.getId());
        assertEquals(Integer.valueOf(99999), imgObject.getId().getRequestId());
        assertEquals(Integer.valueOf(5), imgObject.getId().getSequenceNo());
    }

    @Test
    void testObjectSegmentReference() {
        // Arrange
        byte[] originalData = {1, 2, 3, 4, 5};
        byte[] copyData = originalData.clone();
        
        imgObject.setObjectSegment(originalData);
        
        // Act - Modify original array
        originalData[0] = 99;

        // Assert - The object stores the same reference, so changes are reflected
        // This test verifies the actual behavior - the object segment is a reference
        assertEquals(99, imgObject.getObjectSegment()[0]); // Will be 99 due to reference
        assertArrayEquals(originalData, imgObject.getObjectSegment());
        assertNotEquals(copyData[0], imgObject.getObjectSegment()[0]);
    }

    @Test
    void testRelationshipWithImgToken() {
        // This test verifies the JPA relationship setup
        // In a real scenario, this would be tested with JPA context
        
        // Act
        imgObject.setImgToken(imgToken);

        // Assert
        assertNotNull(imgObject.getImgToken());
        assertEquals(imgToken, imgObject.getImgToken());
    }
}
