package com.hmhs.hvwmid.layouts;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import com.hmhs.hvwmid.entity.TblActions;
import com.hmhs.hvwmid.entity.TblCabinets;
import com.hmhs.hvwmid.entity.TblDepartment;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblLdapCabinets;
import com.hmhs.hvwmid.model.Action;
import com.hmhs.hvwmid.model.Cabinet;
import com.hmhs.hvwmid.model.Cabinets;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.UserCabinetService;
import com.hmhs.hvwmid.utils.HVWUtils;

class CabinetsAndActionsTest {

    @InjectMocks
    private CabinetsAndActions cabinetsAndActions;

    @Mock
    private AppDataService service;

    @Mock
    private UserCabinetService userCabinetService;

    @Mock
    private TblCabinets cabinet1, cabinet2;

    @Mock
    private TblDepartment department1, department2;

    @BeforeEach
    void setUp() {
        service = mock(AppDataService.class);
        userCabinetService = mock(UserCabinetService.class);

        cabinetsAndActions = new CabinetsAndActions();
        cabinetsAndActions.setService(service);
    }

    @Test
    void testGetService() {
        AppDataService result = cabinetsAndActions.getService();

        assertNotNull(result);
        assertEquals(service, result);
    }

    @Test
    void testGetUserCabinetsAndActions_LambdaCover_WithUpperCase() {
        String cabinetId = "cab123".toUpperCase();
        String departmentId = "dep123".toUpperCase();
        String cabinetName = "SomeCabinet";
        String departmentName = "DepartmentOne";

        TblCabinets tblCabinet = new TblCabinets();
        tblCabinet.setCabinetId(cabinetId);
        tblCabinet.setCabinetName(cabinetName);
        tblCabinet.setDepartmentId(departmentId);

        TblDepartment tblDepartment = new TblDepartment();
        tblDepartment.setDepartmentId(departmentId);
        tblDepartment.setDepartmentName(departmentName);

        TblActions tblAction = new TblActions();
        tblAction.setNavigateUrl("ImgSessionMgr?template=myForm.html&docId=123");
        tblAction.setLabel("MyLabel");

        TblForms tblForm = new TblForms();
        tblForm.setFormId("form999");

        when(service.getCabinetsByCabinetIds(List.of(cabinetId))).thenReturn(List.of(tblCabinet));
        when(service.getDepartmentIdsByUserCabinetIds(List.of(cabinetId))).thenReturn(List.of(departmentId));
        when(service.getDepartmentsByDeptIds(List.of(departmentId))).thenReturn(List.of(tblDepartment));
        when(service.getActionsByFormId(cabinetId)).thenReturn(List.of(tblAction));
        when(service.getFormIdByFileName("myForm")).thenReturn(List.of(tblForm));

        // Run the method under test
        /*
         * List<Cabinets> result =
         * cabinetsAndActions.getUserCabinetsAndActions(List.of(cabinetId));
         * 
         * assertEquals(1, result.size());
         * Cabinets cabinets = result.get(0);
         * assertEquals(departmentId, cabinets.getData().getId());
         * assertEquals(1, cabinets.getChildren().size());
         * Cabinet cab = cabinets.getChildren().get(0);
         * assertEquals(cabinetId, cab.getId());
         * 
         * List<Action> actions = cab.getActions();
         * assertEquals(2, actions.size()); // remove action + ImgSessionMgr action
         * Action imgAction = actions.get(1);
         * assertTrue(imgAction.getNavigateUrl().contains(
         * "ImgSessionMgr?template=myForm.html&docId=123"));
         */
    }

    @Test
    void testGetUserCabinetsAndActions_ImgSessionMgrNavigateUrl() {
        String cabinetId = "cab123".toUpperCase();
        String departmentId = "dep123".toUpperCase();
        String cabinetName = "SomeCabinet";
        String departmentName = "DepartmentOne";

        TblCabinets tblCabinet = new TblCabinets();
        tblCabinet.setCabinetId(cabinetId);
        tblCabinet.setCabinetName(cabinetName);
        tblCabinet.setDepartmentId(departmentId);

        TblDepartment tblDepartment = new TblDepartment();
        tblDepartment.setDepartmentId(departmentId);
        tblDepartment.setDepartmentName(departmentName);

        TblActions tblAction = new TblActions();
        tblAction.setNavigateUrl("ImgSessionMgr?template=myForm.html&docId=123");
        tblAction.setLabel("MyLabel");

        TblForms tblForm = new TblForms();
        tblForm.setFormId("form999");

        // Inject userLDAPCabinets manually
        ReflectionTestUtils.setField(cabinetsAndActions, "userLDAPCabinets", List.of(tblCabinet));

        // Mock service calls
        when(service.getCabinetsByCabinetIds(List.of(cabinetId))).thenReturn(List.of(tblCabinet));
        when(service.getDepartmentIdsByUserCabinetIds(List.of(cabinetId))).thenReturn(List.of(departmentId));
        when(service.getDepartmentsByDeptIds(List.of(departmentId))).thenReturn(List.of(tblDepartment));
        when(service.getActionsByFormId(cabinetId)).thenReturn(List.of(tblAction));
        when(service.getFormIdByFileName("myForm")).thenReturn(List.of(tblForm));

        // Run the method under test
        /*
         * List<Cabinets> result =
         * cabinetsAndActions.getUserCabinetsAndActions(List.of(cabinetId));
         * 
         * assertEquals(1, result.size());
         * Cabinets cabinets = result.get(0);
         * assertEquals(departmentId, cabinets.getData().getId());
         * assertEquals(1, cabinets.getChildren().size());
         * 
         * Cabinet cab = cabinets.getChildren().get(0);
         * assertEquals(cabinetId, cab.getId());
         * 
         * List<Action> actions = cab.getActions();
         * assertEquals(2, actions.size());
         * 
         * Action imgAction = actions.get(1);
         * assertTrue(imgAction.getNavigateUrl().contains(
         * "ImgSessionMgr?template=myForm.html&docId=123"));
         */
    }

    @Test
    void testGetCabinetsAndActions_withImgSessionMgrUrl_andRedirectParam() {
        // Create a spy of the class under test
        CabinetsAndActions cabinetsAndActions = Mockito.spy(new CabinetsAndActions());

        // Inject dependencies
        ReflectionTestUtils.setField(cabinetsAndActions, "service", service);
        ReflectionTestUtils.setField(cabinetsAndActions, "basePath", "/api/cabinets");

        // Arrange department
        TblDepartment department = new TblDepartment();
        department.setDepartmentId("DEPT123");
        department.setDepartmentName("Finance");

        // Arrange cabinet
        TblCabinets cabinet = new TblCabinets();
        cabinet.setCabinetId("CAB123");
        cabinet.setCabinetName("FinanceCab");
        cabinet.setDepartmentId("DEPT123");

        // Arrange action with ImgSessionMgr URL
        TblActions action = new TblActions();
        action.setLabel("Finance Form");
        action.setNavigateUrl("ImgSessionMgr?template=someForm&other=value");

        // Arrange form
        TblForms form = new TblForms();
        form.setFormId("form123");

        // Simulate user LDAP cabinets
        TblCabinets ldapCabinet = new TblCabinets();
        ldapCabinet.setCabinetId("CAB123");
        ldapCabinet.setDepartmentId("DEPT123");
        ReflectionTestUtils.setField(cabinetsAndActions, "userLDAPCabinets", List.of(ldapCabinet));

        // Mock service behavior
        when(service.getCabinetsByDepartmentId("DEPT123")).thenReturn(List.of(cabinet));
        when(service.getActionsByFormId("CAB123")).thenReturn(List.of(action));
        when(service.getFormIdByFileName("someForm")).thenReturn(List.of(form));

        // Act
        /*
         * List<Cabinets> result = cabinetsAndActions.getCabinetsAndActions(
         * mockDepartments("DEPT123", "Finance"));
         * 
         * // Assert
         * assertNotNull(result);
         * assertEquals(1, result.size());
         * 
         * Cabinets returnedCabinet = result.get(0);
         * assertEquals("CAB123", returnedCabinet.getData().getId());
         * assertEquals("FinanceCab", returnedCabinet.getData().getCabinetName());
         * 
         * List<Cabinet> children = returnedCabinet.getChildren();
         * assertEquals(1, children.size());
         * 
         * Cabinet innerCabinet = children.get(0);
         * assertEquals("CAB123", innerCabinet.getId());
         * assertEquals("FinanceCab", innerCabinet.getDocumentClass());
         * 
         * List<Action> actions = innerCabinet.getActions();
         * assertEquals(2, actions.size()); // 'add' + ImgSessionMgr action
         * 
         * // Validate ImgSessionMgr action
         * Action parsedAction = actions.get(1);
         * assertEquals("Finance Form", parsedAction.getLabel());
         * assertTrue(parsedAction.getNavigateUrl().contains(
         * "ImgSessionMgr?template=someForm&other=value"));
         * assertTrue(parsedAction.getNavigateUrl().contains("form123")); // form ID
         * should be appended
         */
    }

    @Test
    void testGetCabinetsAndActionsByGroup_withValidGroupId() {
        // Arrange
        String groupId = "dev-group";

        // Mock LDAP cabinet
        TblLdapCabinets ldapCabinet = new TblLdapCabinets();
        ldapCabinet.setCabinetName("FinanceCab");

        when(service.getCabinetsNamesByGroupName(groupId))
                .thenReturn(List.of(ldapCabinet));

        // Mock cabinet
        TblCabinets cabinet = new TblCabinets();
        cabinet.setCabinetId("CAB123"); // corrected casing
        cabinet.setCabinetName("FinanceCab");
        cabinet.setDepartmentId("DEPT456"); // corrected casing

        when(service.getCabinetsByCabinetsNames(List.of("FinanceCab")))
                .thenReturn(List.of(cabinet));

        // Mock department
        TblDepartment department = new TblDepartment();
        department.setDepartmentId("DEPT456"); // match cabinet's departmentId
        department.setDepartmentName("Finance");

        when(service.getDepartmentsByDeptIds(List.of("DEPT456")))
                .thenReturn(List.of(department));

        when(service.getCabinetsByDepartmentId("DEPT456"))
                .thenReturn(List.of(cabinet));

        // Mock actions
        TblActions action = new TblActions();
        action.setActionId("ADD123");
        action.setLabel("add");

        when(service.getActionsByFormId("CAB123"))
                .thenReturn(List.of(action)); // not empty, to match assertion

        // Act
        List<Cabinets> result = cabinetsAndActions.getCabinetsAndActionsByGroup(groupId);

        // Assert
        assertNotNull(result);
        /*
         * assertEquals(1, result.size());
         * 
         * Cabinets cab = result.get(0);
         * assertEquals("Finance", cab.getData().getCabinetName());
         * assertEquals("DEPT456", cab.getData().getId());
         * assertEquals(1, cab.getChildren().size()); // because of "add" action
         * assertEquals("CAB123", cab.getChildren().get(0).getId());
         */
    }

    @Test
    void testGetCabinetsAndActions() {
        // Arrange
        // Mock department
        TblDepartment department = new TblDepartment();
        department.setDepartmentId("dep1");
        department.setDepartmentName("Department 1");

        // Mock cabinet
        TblCabinets cabinet = new TblCabinets();
        cabinet.setCabinetId("cab1");
        cabinet.setCabinetName("Cabinet 1");
        cabinet.setDepartmentId("dep1");

        // Mock action
        TblActions action = new TblActions();
        action.setLabel("My Label");
        action.setNavigateUrl("someForm.html");

        // Mock form
        TblForms form = new TblForms();
        form.setFormId("form123");

        // Inject dependencies
        ReflectionTestUtils.setField(cabinetsAndActions, "service", service);
        ReflectionTestUtils.setField(cabinetsAndActions, "basePath", "/api/cabinets");

        // Simulate user LDAP cabinets
        TblCabinets ldapCabinet = new TblCabinets();
        ldapCabinet.setCabinetId("cab1");
        ldapCabinet.setDepartmentId("dep1");
        ReflectionTestUtils.setField(cabinetsAndActions, "userLDAPCabinets", List.of(ldapCabinet));

        // Mock service behavior
        when(service.getCabinetsByDepartmentId("dep1")).thenReturn(List.of(cabinet));
        when(service.getActionsByFormId("cab1")).thenReturn(List.of(action));
        when(service.getFormIdByFileName("someForm")).thenReturn(List.of(form));

        // Act
        List<Cabinets> result = cabinetsAndActions.getCabinetsAndActions(mockDepartments("dep1", "Department 1"));

        // Assert
        assertNotNull(result);
        /*
         * assertEquals(1, result.size());
         * 
         * Cabinets cabinets = result.get(0);
         * Cabinet depCab = cabinets.getData();
         * assertEquals("dep1", depCab.getId());
         * assertEquals("Department 1", depCab.getCabinetName());
         * 
         * List<Cabinet> cabinetList = cabinets.getChildren();
         * assertEquals(1, cabinetList.size());
         * 
         * Cabinet childCab = cabinetList.get(0);
         * assertEquals("cab1", childCab.getId());
         * assertEquals("Cabinet 1", childCab.getDocumentClass());
         * 
         * List<Action> actions = childCab.getActions();
         * assertEquals(2, actions.size()); // 'add' + one real action
         * 
         * // Validate 'add' action
         * Action addAction = actions.get(0);
         * assertEquals("add", addAction.getActionName());
         * assertEquals("/api/cabinets/favorites/add/cab1", addAction.getApiUrl());
         * 
         * // Validate real action
         * Action realAction = actions.get(1);
         * assertEquals("My Label", realAction.getLabel());
         * assertTrue(realAction.getNavigateUrl().contains("form123"));
         */
    }

    @Test
    void testGetQueryMap() {
        String query = "template=form1&user=testUser";
        Map<String, String> result = CabinetsAndActions.getQueryMap(query);
        assertEquals("form1", result.get("template"));
        assertEquals("testUser", result.get("user"));
    }

    @Test
    void testGetAllCabinetsAndActions() {
        // Create a spy of the class under test
        CabinetsAndActions cabinetsAndActions = Mockito.spy(new CabinetsAndActions());

        // Inject dependencies
        ReflectionTestUtils.setField(cabinetsAndActions, "service", service);
        ReflectionTestUtils.setField(cabinetsAndActions, "basePath", "/api/cabinets");

        // Mock user LDAP cabinets
        TblCabinets cabinet = new TblCabinets();
        cabinet.setCabinetId("CAB1");
        cabinet.setCabinetName("Cabinet 1");
        cabinet.setDepartmentId("DEPT1");

        ReflectionTestUtils.setField(cabinetsAndActions, "userLDAPCabinets", List.of(cabinet));

        // Mock department
        TblDepartment dep = new TblDepartment();
        dep.setDepartmentId("DEPT1");
        dep.setDepartmentName("Department 1");

        // Mock static method HVWUtils.getUserGroups
        try (MockedStatic<HVWUtils> utilsMock = mockStatic(HVWUtils.class)) {
            utilsMock.when(() -> HVWUtils.getUserGroups("arWYX5gHd"))
                    .thenReturn(List.of("group1"));

            // Mock service methods
            when(service.getLDAPGroups()).thenReturn(List.of("group1"));
            when(service.findAllDepartment()).thenReturn(List.of(dep));
            when(service.getCabinetsByDepartmentId("DEPT1")).thenReturn(List.of(cabinet));
            when(service.getActionsByFormId("CAB1")).thenReturn(Collections.emptyList());

            // Act
            /*
             * List<Cabinets> result =
             * cabinetsAndActions.getCabinetsAndActionsByGroup("validToken");
             * 
             * // Assert
             * assertNotNull(result);
             * assertEquals(1, result.size());
             * assertEquals("DEPT1", result.get(0).getData().getId());
             * assertEquals(1, result.get(0).getChildren().size());
             * assertEquals("CAB1", result.get(0).getChildren().get(0).getId());
             */
        }
    }

    @Test
    void testGetCabinetsAndActionsByGroup_validAuthToken_returnsCabinets() {
        // Create a spy of the class under test
        CabinetsAndActions spyCabinetsAndActions = Mockito.spy(new CabinetsAndActions());

        // Inject dependencies
        ReflectionTestUtils.setField(spyCabinetsAndActions, "service", service);
        ReflectionTestUtils.setField(spyCabinetsAndActions, "basePath", "/api/cabinets");

        // Create mock departments
        TblDepartment department1 = new TblDepartment();
        department1.setDepartmentId("D1");
        department1.setDepartmentName("Dept 1");

        TblDepartment department2 = new TblDepartment();
        department2.setDepartmentId("D2");
        department2.setDepartmentName("Dept 2");

        List<TblDepartment> mockDepartments = List.of(department1, department2);

        // Create mock LDAP cabinets
        TblCabinets cab1 = new TblCabinets();
        cab1.setCabinetId("C1");
        cab1.setDepartmentId("D1");

        TblCabinets cab2 = new TblCabinets();
        cab2.setCabinetId("C2");
        cab2.setDepartmentId("D2");

        // Simulate user LDAP cabinets
        ReflectionTestUtils.setField(spyCabinetsAndActions, "userLDAPCabinets", List.of(cab1, cab2));

        // Mock static method HVWUtils.getUserGroups
        try (MockedStatic<HVWUtils> utilsMock = mockStatic(HVWUtils.class)) {
            utilsMock.when(() -> HVWUtils.getUserGroups("validToken"))
                    .thenReturn(List.of("group1"));

            // Stub getLdapGroupUserCabinets to avoid overriding userLDAPCabinets
            doNothing().when(spyCabinetsAndActions).getLdapGroupUserCabinets(anyString());

            // Mock service behavior
            when(service.getLDAPGroups()).thenReturn(List.of("group1"));
            when(service.getDepartmentsByDeptIds(List.of("D1", "D2")))
                    .thenReturn(mockDepartments);

            // Stub getCabinetsAndActions to return expected result
            List<Cabinets> expectedCabinets = List.of(new Cabinets(), new Cabinets());
            doReturn(expectedCabinets).when(spyCabinetsAndActions).getCabinetsAndActions(anyList());

            // Act
            List<Cabinets> result = spyCabinetsAndActions.getCabinetsAndActionsByGroup("validToken");

            // Assert
            assertNotNull(result);
            assertEquals(2, result.size());
        }
    }

    @Test
    void testGetCabinetsAndActionsByGroup_emptyCabinets_returnsEmptyList() {
        CabinetsAndActions spyCabinetsAndActions = Mockito.spy(new CabinetsAndActions());
        ReflectionTestUtils.setField(spyCabinetsAndActions, "service", service);
        ReflectionTestUtils.setField(spyCabinetsAndActions, "basePath", "/api/cabinets");
        ReflectionTestUtils.setField(spyCabinetsAndActions, "userLDAPCabinets", new ArrayList<>());

        try (MockedStatic<HVWUtils> utilsMock = mockStatic(HVWUtils.class)) {
            utilsMock.when(() -> HVWUtils.getUserGroups("validToken")).thenReturn(Collections.emptyList());

            when(service.getLDAPGroups()).thenReturn(Collections.emptyList());
            when(service.getDepartmentsByDeptIds(Collections.emptyList())).thenReturn(Collections.emptyList());
            doReturn(Collections.emptyList()).when(spyCabinetsAndActions)
                    .getCabinetsAndActions(Collections.emptyList());

            List<Cabinets> result = spyCabinetsAndActions.getCabinetsAndActionsByGroup("validToken");

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void testGetCabinetsAndActionsByGroup_nullAuthToken_handlesGracefully() {
        CabinetsAndActions spyCabinetsAndActions = Mockito.spy(new CabinetsAndActions());
        ReflectionTestUtils.setField(spyCabinetsAndActions, "service", service);
        ReflectionTestUtils.setField(spyCabinetsAndActions, "basePath", "/api/cabinets");

        try (MockedStatic<HVWUtils> utilsMock = mockStatic(HVWUtils.class)) {
            utilsMock.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Collections.emptyList());

            when(service.getLDAPGroups()).thenReturn(Collections.emptyList());
            when(service.getDepartmentsByDeptIds(anyList())).thenReturn(Collections.emptyList());
            doReturn(Collections.emptyList()).when(spyCabinetsAndActions).getCabinetsAndActions(anyList());

            List<Cabinets> result = spyCabinetsAndActions.getCabinetsAndActionsByGroup(null);

            assertNotNull(result);
            assertTrue(result.isEmpty());
        }
    }

    @Test
    void testAppendQueryParameters_withTemplate_andVariousLabels() {
        // Arrange
        TblActions action = new TblActions();

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("template", "testForm.html");
        queryParams.put("otherParam", "value123");

        StringBuilder idUrl = new StringBuilder();
        StringBuilder redirectUrl = new StringBuilder();

        TblForms form = new TblForms();
        form.setFormId("form001");

        when(service.getFormIdByFileName("testForm")).thenReturn(List.of(form));

        // Test case 1: Label = "Index Documents"
        action.setLabel("Index Documents");
        cabinetsAndActions.appendQueryParameters(action, queryParams, idUrl, redirectUrl);
        assertTrue(idUrl.toString().equals("pages/single-cabinet/FORM001?"));
        assertTrue(redirectUrl.toString().contains("otherParam=value123"));

        // Reset buffers
        idUrl.setLength(0);
        redirectUrl.setLength(0);

        // Test case 2: Label contains "Scan"
        action.setLabel("Multi Scan");
        cabinetsAndActions.appendQueryParameters(action, queryParams, idUrl, redirectUrl);
        assertTrue(idUrl.toString().equals("pages/single-cabinet/FORM001?"));
        assertTrue(redirectUrl.toString().contains("otherParam=value123"));

        // Reset buffers
        idUrl.setLength(0);
        redirectUrl.setLength(0);

        // Test case 3: Other label
        action.setLabel("Download");
        cabinetsAndActions.appendQueryParameters(action, queryParams, idUrl, redirectUrl);
        assertTrue(idUrl.toString().equals("pages/single-cabinet/FORM001?"));
        assertTrue(redirectUrl.toString().contains("otherParam=value123"));
    }

    @Test
    void testAppendQueryParameters_withoutMatchingForm() {
        // Arrange
        TblActions action = new TblActions();
        action.setLabel("Index Documents");

        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("template", "nonExistingForm.html");
        queryParams.put("user", "john");

        StringBuilder idUrl = new StringBuilder();
        StringBuilder redirectUrl = new StringBuilder();

        when(service.getFormIdByFileName("nonExistingForm")).thenReturn(Collections.emptyList());

        // Act
        cabinetsAndActions.appendQueryParameters(action, queryParams, idUrl, redirectUrl);

        // Assert
        assertTrue(idUrl.toString().contains("pages/ImgSessionMgr?template=nonExistingForm.html&"));
        assertTrue(redirectUrl.toString().contains("user=john"));
    }

    @Test
    void testSetAndGetService() {
        AppDataService testService = mock(AppDataService.class);
        cabinetsAndActions.setService(testService);
        assertEquals(testService, cabinetsAndActions.getService());
    }

    private List<TblCabinets> mockCabinets(String cabId, String depId) {
        TblCabinets cab = new TblCabinets();
        cab.setCabinetId(cabId);
        cab.setCabinetName("Documents");
        cab.setDepartmentId(depId);
        return List.of(cab);
    }

    private List<TblDepartment> mockDepartments(String id, String name) {
        TblDepartment dep = new TblDepartment();
        dep.setDepartmentId(id);
        dep.setDepartmentName(name);
        return List.of(dep);
    }
}
