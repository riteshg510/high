package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.entity.TblCodToken;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CodTokenRepositoryTest {

    private CodTokenRepository repository;

    @BeforeEach
    void setup() {
        repository = mock(CodTokenRepository.class, CALLS_REAL_METHODS);
    }

    @Test
    void findByUserIdAndDocumentTokenAndSecurityTokenSafe_shouldReturnMatch() {
        TblCodToken token1 = new TblCodToken();
        token1.setUserId("user123");
        token1.setDocumentToken("doc456");
        token1.setSecurityToken("secret789");
        TblCodToken token2 = new TblCodToken();
        token2.setUserId("user123");
        token2.setDocumentToken("doc456");
        token2.setSecurityToken("other");

        when(repository.findByUserIdAndDocumentToken("user123", "doc456"))
                .thenReturn(List.of(token1, token2));

        List<TblCodToken> result = repository
                .findByUserIdAndDocumentToken("user123", "doc456");
        List<TblCodToken> filtered = result.stream().filter(t -> "secret789".equals(t.getSecurityToken())).toList();

        assertFalse(filtered.isEmpty());
        assertEquals("secret789", filtered.get(0).getSecurityToken());
    }

    @Test
    void findByUserIdAndDocumentTokenAndSecurityTokenSafe_shouldReturnEmptyIfNoMatch() {
        TblCodToken token = new TblCodToken();
        token.setUserId("user123");
        token.setDocumentToken("doc456");
        token.setSecurityToken("wrongToken");

        when(repository.findByUserIdAndDocumentToken("user123", "doc456"))
                .thenReturn(List.of(token));

        List<TblCodToken> result = repository
                .findByUserIdAndDocumentToken("user123", "doc456");
        List<TblCodToken> filtered = result.stream().filter(t -> "secret789".equals(t.getSecurityToken())).toList();

        assertTrue(filtered.isEmpty());
    }

    @Test
    void findByRequestIdAndSecurityTokenSafe_shouldReturnMatch() {
        TblCodToken token = new TblCodToken();
        token.setRequestId(1001);
        token.setSecurityToken("abc123");

        when(repository.findByRequestId(1001)).thenReturn(Optional.of(token));


        Optional<TblCodToken> result = repository
                .findByRequestIdAndSecurityTokenSafe(1001, "abc123");


        assertTrue(result.isPresent());
        assertEquals("abc123", result.get().getSecurityToken());
    }

    @Test
    void findByRequestIdAndSecurityTokenSafe_shouldReturnEmptyIfTokenMismatch() {
        TblCodToken token = new TblCodToken();
        token.setRequestId(1001);
        token.setSecurityToken("wrong");

        when(repository.findByRequestId(1001)).thenReturn(Optional.of(token));

        Optional<TblCodToken> result = repository
                .findByRequestIdAndSecurityTokenSafe(1001, "correct");


        assertTrue(result.isEmpty());
    }

    @Test
    void findByRequestIdAndSecurityTokenSafe_shouldReturnEmptyIfNoToken() {
        when(repository.findByRequestId(999)).thenReturn(Optional.empty());

        Optional<TblCodToken> result = repository.findByRequestIdAndSecurityTokenSafe(999, "whatever");

        assertTrue(result.isEmpty());
    }
}
