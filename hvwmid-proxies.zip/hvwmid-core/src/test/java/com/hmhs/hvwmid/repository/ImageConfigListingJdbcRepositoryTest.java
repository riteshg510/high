package com.hmhs.hvwmid.repository;

import com.hmhs.hvwmid.model.ListingSearchRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ImageConfigListingJdbcRepositoryTest {

    @Mock
    private NamedParameterJdbcTemplate jdbc;

    private ImageConfigListingJdbcRepository repo;

    @Captor
    private ArgumentCaptor<String> sqlCaptor;

    @Captor
    private ArgumentCaptor<MapSqlParameterSource> paramCaptor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        repo = new ImageConfigListingJdbcRepository(jdbc);
    }

    @Test
    void search_buildsSelectAndWhere_withLikeOperator_andSelectedColumns() {
        ListingSearchRequest req = new ListingSearchRequest();
        req.setMainSchema("DB2INST1");
        req.setBatchtblschema("DB2INST1");


        req.setFrmFormNumDisplay(true);
        req.setFrmFormNumSearchOperator("LIKE");
        req.setFrmFormNumQuery("  f123 ");


        req.setUserApplids(List.of(10, 20));
        req.setLimit(25);

        when(jdbc.query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
                .thenReturn(List.of(Map.of("ENTTTFRM_FORMNUM", "F123")));

        List<Map<String, Object>> out = repo.search(req);

        verify(jdbc).query(sqlCaptor.capture(), paramCaptor.capture(), any(RowMapper.class));
        String sql = sqlCaptor.getValue();
        MapSqlParameterSource params = paramCaptor.getValue();


        assertTrue(sql.contains("FRM.FORMNUM AS ENTTTFRM_FORMNUM"));


        assertTrue(sql.contains("UPPER(FRM.FORMNUM) LIKE :p_ENTTTFRM_FORMNUM"));
        assertEquals("F123%", params.getValue("p_ENTTTFRM_FORMNUM"));


        @SuppressWarnings("unchecked")
        Collection<Integer> applids = (Collection<Integer>) params.getValue("applids");
        assertNotNull(applids);
        assertEquals(List.of(10, 20), List.copyOf(applids));


        assertTrue(sql.contains("FETCH FIRST 26 ROWS ONLY"));
        assertTrue(sql.toUpperCase().contains("WITH UR"));

        assertFalse(out.isEmpty());
    }



    @Test
    void search_usesExactOperatorForLongFields_WhenValuePresent() {
        ListingSearchRequest req = new ListingSearchRequest();
        req.setMainSchema("DB2INST1");
        req.setBatchtblschema("DB2INST1");

        req.setLprApplIdCdDisplay(true);
        req.setLprApplIdCdQuery(123L);

        req.setUserApplids(List.of(99));
        req.setLimit(2);

        when(jdbc.query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
                .thenReturn(List.of());

        repo.search(req);

        verify(jdbc).query(sqlCaptor.capture(), paramCaptor.capture(), any(RowMapper.class));
        String sql = sqlCaptor.getValue();
        MapSqlParameterSource params = paramCaptor.getValue();

        assertTrue(sql.contains("LPR.APPLIDCD = :p_ENTTTLPR_APPLIDCD"));
        assertEquals(123L, params.getValue("p_ENTTTLPR_APPLIDCD"));
    }

    @Test
    void search_fallsBackToMinusOneApplids_WhenEmptyOrNull() {
        ListingSearchRequest req = new ListingSearchRequest();
        req.setMainSchema("DB2INST1");
        req.setBatchtblschema("DB2INST1");

        req.setFrmFormNumDisplay(true);
        req.setFrmFormNumQuery("X");
        req.setFrmFormNumSearchOperator("EXACT");

        req.setUserApplids(null);
        req.setLimit(1);

        when(jdbc.query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
                .thenReturn(List.of());

        repo.search(req);

        verify(jdbc).query(sqlCaptor.capture(), paramCaptor.capture(), any(RowMapper.class));
        MapSqlParameterSource params = paramCaptor.getValue();

        @SuppressWarnings("unchecked")
        List<Integer> applids = (List<Integer>) params.getValue("applids");
        assertEquals(List.of(-1), applids);
    }

    @Test
    void search_capsLimitAt5000_andAddsOneToFetchRows() {
        ListingSearchRequest req = new ListingSearchRequest();
        req.setMainSchema("DB2INST1");
        req.setBatchtblschema("DB2INST1");

        req.setFrmFormNumDisplay(true);
        req.setFrmFormNumQuery("X");
        req.setFrmFormNumSearchOperator("LIKE");

        req.setUserApplids(List.of(1));
        req.setLimit(10000);

        when(jdbc.query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
                .thenReturn(List.of());

        repo.search(req);

        verify(jdbc).query(sqlCaptor.capture(), any(MapSqlParameterSource.class), any(RowMapper.class));
        String sql = sqlCaptor.getValue();

        assertTrue(sql.contains("FETCH FIRST 5001 ROWS ONLY"));
        assertTrue(sql.toUpperCase().contains("WITH UR"));
    }

}
