package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMISearchResults POJO
 * Tests all getters, setters, and JSON property mappings
 * 
 * @author HighView Development Team
 * @since 1.0
 */
class IMISearchResultsTest {

    private IMISearchResults imiSearchResults;

    @BeforeEach
    void setUp() {
        imiSearchResults = new IMISearchResults();
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        IMISearchResults results = new IMISearchResults();
        assertNotNull(results);
        
        // Test default values
        assertNull(results.getNaicCode());
        assertNull(results.getTransmitTimeStamp());
        assertEquals(0L, results.getTransmitFileId());
        assertNull(results.getTransmitFileName());
        assertNull(results.getTransmitFileStatusCd());
        assertEquals(0L, results.getImiFileId());
        assertNull(results.getPlanFileId());
        assertNull(results.getProcessFileName());
        assertNull(results.getProcessFileStatusCd());
        assertNull(results.getProcessFileReasonCdDesc());
        assertNull(results.getTimeAck());
        assertNull(results.getImiDocumentId());
        assertNull(results.getPlanDCN());
        assertNull(results.getDpk());
        assertNull(results.getInitialProcessDCN());
        assertNull(results.getFinalProcessDCN());
        assertNull(results.getDocumentStatusCd());
        assertNull(results.getDocumentReasonCdDesc());
        assertNull(results.getTimeUpdate());
        assertNull(results.getApplIdCd());
        assertNull(results.getCaptureItemId());
        assertEquals(0L, results.getResultSetPointer());
    }

    // ========== BASIC FIELD TESTS ==========

    @Test
    void testNaicCodeGetterAndSetter() {
        imiSearchResults.setNaicCode("12345");
        assertEquals("12345", imiSearchResults.getNaicCode());
    }

    @Test
    void testNaicCodeWithNull() {
        imiSearchResults.setNaicCode(null);
        assertNull(imiSearchResults.getNaicCode());
    }

    @Test
    void testNaicCodeWithEmptyString() {
        imiSearchResults.setNaicCode("");
        assertEquals("", imiSearchResults.getNaicCode());
    }

    @Test
    void testTransmitTimeStampGetterAndSetter() {
        imiSearchResults.setTransmitTimeStamp("2023-01-01 10:00:00");
        assertEquals("2023-01-01 10:00:00", imiSearchResults.getTransmitTimeStamp());
    }

    @Test
    void testTransmitTimeStampWithNull() {
        imiSearchResults.setTransmitTimeStamp(null);
        assertNull(imiSearchResults.getTransmitTimeStamp());
    }

    @Test
    void testTransmitTimeStampWithEmptyString() {
        imiSearchResults.setTransmitTimeStamp("");
        assertEquals("", imiSearchResults.getTransmitTimeStamp());
    }

    // ========== TRANSMIT FILE TESTS ==========

    @Test
    void testTransmitFileIdGetterAndSetter() {
        imiSearchResults.setTransmitFileId(12345L);
        assertEquals(12345L, imiSearchResults.getTransmitFileId());
    }

    @Test
    void testTransmitFileIdWithZero() {
        imiSearchResults.setTransmitFileId(0L);
        assertEquals(0L, imiSearchResults.getTransmitFileId());
    }

    @Test
    void testTransmitFileIdWithNegativeValue() {
        imiSearchResults.setTransmitFileId(-1L);
        assertEquals(-1L, imiSearchResults.getTransmitFileId());
    }

    @Test
    void testTransmitFileIdWithMaxValue() {
        imiSearchResults.setTransmitFileId(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, imiSearchResults.getTransmitFileId());
    }

    @Test
    void testTransmitFileNameGetterAndSetter() {
        imiSearchResults.setTransmitFileName("test_file.txt");
        assertEquals("test_file.txt", imiSearchResults.getTransmitFileName());
    }

    @Test
    void testTransmitFileNameWithNull() {
        imiSearchResults.setTransmitFileName(null);
        assertNull(imiSearchResults.getTransmitFileName());
    }

    @Test
    void testTransmitFileNameWithEmptyString() {
        imiSearchResults.setTransmitFileName("");
        assertEquals("", imiSearchResults.getTransmitFileName());
    }

    @Test
    void testTransmitFileStatusCdGetterAndSetter() {
        imiSearchResults.setTransmitFileStatusCd("A");
        assertEquals("A", imiSearchResults.getTransmitFileStatusCd());
    }

    @Test
    void testTransmitFileStatusCdWithNull() {
        imiSearchResults.setTransmitFileStatusCd(null);
        assertNull(imiSearchResults.getTransmitFileStatusCd());
    }

    @Test
    void testTransmitFileStatusCdWithEmptyString() {
        imiSearchResults.setTransmitFileStatusCd("");
        assertEquals("", imiSearchResults.getTransmitFileStatusCd());
    }

    // ========== IMI FILE TESTS ==========

    @Test
    void testImiFileIdGetterAndSetter() {
        imiSearchResults.setImiFileId(67890L);
        assertEquals(67890L, imiSearchResults.getImiFileId());
    }

    @Test
    void testImiFileIdWithZero() {
        imiSearchResults.setImiFileId(0L);
        assertEquals(0L, imiSearchResults.getImiFileId());
    }

    @Test
    void testImiFileIdWithNegativeValue() {
        imiSearchResults.setImiFileId(-1L);
        assertEquals(-1L, imiSearchResults.getImiFileId());
    }

    @Test
    void testImiFileIdWithMaxValue() {
        imiSearchResults.setImiFileId(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, imiSearchResults.getImiFileId());
    }

    // ========== PLAN FILE TESTS ==========

    @Test
    void testPlanFileIdGetterAndSetter() {
        imiSearchResults.setPlanFileId("PLAN123");
        assertEquals("PLAN123", imiSearchResults.getPlanFileId());
    }

    @Test
    void testPlanFileIdWithNull() {
        imiSearchResults.setPlanFileId(null);
        assertNull(imiSearchResults.getPlanFileId());
    }

    @Test
    void testPlanFileIdWithEmptyString() {
        imiSearchResults.setPlanFileId("");
        assertEquals("", imiSearchResults.getPlanFileId());
    }

    // ========== PROCESS FILE TESTS ==========

    @Test
    void testProcessFileNameGetterAndSetter() {
        imiSearchResults.setProcessFileName("process_file.pdf");
        assertEquals("process_file.pdf", imiSearchResults.getProcessFileName());
    }

    @Test
    void testProcessFileNameWithNull() {
        imiSearchResults.setProcessFileName(null);
        assertNull(imiSearchResults.getProcessFileName());
    }

    @Test
    void testProcessFileNameWithEmptyString() {
        imiSearchResults.setProcessFileName("");
        assertEquals("", imiSearchResults.getProcessFileName());
    }

    @Test
    void testProcessFileStatusCdGetterAndSetter() {
        imiSearchResults.setProcessFileStatusCd("C");
        assertEquals("C", imiSearchResults.getProcessFileStatusCd());
    }

    @Test
    void testProcessFileStatusCdWithNull() {
        imiSearchResults.setProcessFileStatusCd(null);
        assertNull(imiSearchResults.getProcessFileStatusCd());
    }

    @Test
    void testProcessFileStatusCdWithEmptyString() {
        imiSearchResults.setProcessFileStatusCd("");
        assertEquals("", imiSearchResults.getProcessFileStatusCd());
    }

    @Test
    void testProcessFileReasonCdDescGetterAndSetter() {
        imiSearchResults.setProcessFileReasonCdDesc("REASON001");
        assertEquals("REASON001", imiSearchResults.getProcessFileReasonCdDesc());
    }

    @Test
    void testProcessFileReasonCdDescWithNull() {
        imiSearchResults.setProcessFileReasonCdDesc(null);
        assertNull(imiSearchResults.getProcessFileReasonCdDesc());
    }

    @Test
    void testProcessFileReasonCdDescWithEmptyString() {
        imiSearchResults.setProcessFileReasonCdDesc("");
        assertEquals("", imiSearchResults.getProcessFileReasonCdDesc());
    }

    // ========== TIME ACK TESTS ==========

    @Test
    void testTimeAckGetterAndSetter() {
        imiSearchResults.setTimeAck("2023-01-01 10:30:00");
        assertEquals("2023-01-01 10:30:00", imiSearchResults.getTimeAck());
    }

    @Test
    void testTimeAckWithNull() {
        imiSearchResults.setTimeAck(null);
        assertNull(imiSearchResults.getTimeAck());
    }

    @Test
    void testTimeAckWithEmptyString() {
        imiSearchResults.setTimeAck("");
        assertEquals("", imiSearchResults.getTimeAck());
    }

    // ========== IMI DOCUMENT TESTS ==========

    @Test
    void testImiDocumentIdGetterAndSetter() {
        imiSearchResults.setImiDocumentId(98765);
        assertEquals(98765, imiSearchResults.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithNull() {
        imiSearchResults.setImiDocumentId(null);
        assertNull(imiSearchResults.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithZero() {
        imiSearchResults.setImiDocumentId(0);
        assertEquals(0, imiSearchResults.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithNegativeValue() {
        imiSearchResults.setImiDocumentId(-1);
        assertEquals(-1, imiSearchResults.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithMaxValue() {
        imiSearchResults.setImiDocumentId(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, imiSearchResults.getImiDocumentId());
    }

    // ========== PLAN DCN TESTS ==========

    @Test
    void testPlanDCNGetterAndSetter() {
        imiSearchResults.setPlanDCN("DCN123456");
        assertEquals("DCN123456", imiSearchResults.getPlanDCN());
    }

    @Test
    void testPlanDCNWithNull() {
        imiSearchResults.setPlanDCN(null);
        assertNull(imiSearchResults.getPlanDCN());
    }

    @Test
    void testPlanDCNWithEmptyString() {
        imiSearchResults.setPlanDCN("");
        assertEquals("", imiSearchResults.getPlanDCN());
    }

    // ========== DPK TESTS ==========

    @Test
    void testDpkGetterAndSetter() {
        imiSearchResults.setDpk("DPK789");
        assertEquals("DPK789", imiSearchResults.getDpk());
    }

    @Test
    void testDpkWithNull() {
        imiSearchResults.setDpk(null);
        assertNull(imiSearchResults.getDpk());
    }

    @Test
    void testDpkWithEmptyString() {
        imiSearchResults.setDpk("");
        assertEquals("", imiSearchResults.getDpk());
    }

    // ========== INITIAL PROCESS DCN TESTS ==========

    @Test
    void testInitialProcessDCNGetterAndSetter() {
        imiSearchResults.setInitialProcessDCN("INIT_DCN123");
        assertEquals("INIT_DCN123", imiSearchResults.getInitialProcessDCN());
    }

    @Test
    void testInitialProcessDCNWithNull() {
        imiSearchResults.setInitialProcessDCN(null);
        assertNull(imiSearchResults.getInitialProcessDCN());
    }

    @Test
    void testInitialProcessDCNWithEmptyString() {
        imiSearchResults.setInitialProcessDCN("");
        assertEquals("", imiSearchResults.getInitialProcessDCN());
    }

    // ========== FINAL PROCESS DCN TESTS ==========

    @Test
    void testFinalProcessDCNGetterAndSetter() {
        imiSearchResults.setFinalProcessDCN("FINAL_DCN456");
        assertEquals("FINAL_DCN456", imiSearchResults.getFinalProcessDCN());
    }

    @Test
    void testFinalProcessDCNWithNull() {
        imiSearchResults.setFinalProcessDCN(null);
        assertNull(imiSearchResults.getFinalProcessDCN());
    }

    @Test
    void testFinalProcessDCNWithEmptyString() {
        imiSearchResults.setFinalProcessDCN("");
        assertEquals("", imiSearchResults.getFinalProcessDCN());
    }

    // ========== DOCUMENT STATUS TESTS ==========

    @Test
    void testDocumentStatusCdGetterAndSetter() {
        imiSearchResults.setDocumentStatusCd("S");
        assertEquals("S", imiSearchResults.getDocumentStatusCd());
    }

    @Test
    void testDocumentStatusCdWithNull() {
        imiSearchResults.setDocumentStatusCd(null);
        assertNull(imiSearchResults.getDocumentStatusCd());
    }

    @Test
    void testDocumentStatusCdWithEmptyString() {
        imiSearchResults.setDocumentStatusCd("");
        assertEquals("", imiSearchResults.getDocumentStatusCd());
    }

    // ========== DOCUMENT REASON TESTS ==========

    @Test
    void testDocumentReasonCdDescGetterAndSetter() {
        imiSearchResults.setDocumentReasonCdDesc("REASON002");
        assertEquals("REASON002", imiSearchResults.getDocumentReasonCdDesc());
    }

    @Test
    void testDocumentReasonCdDescWithNull() {
        imiSearchResults.setDocumentReasonCdDesc(null);
        assertNull(imiSearchResults.getDocumentReasonCdDesc());
    }

    @Test
    void testDocumentReasonCdDescWithEmptyString() {
        imiSearchResults.setDocumentReasonCdDesc("");
        assertEquals("", imiSearchResults.getDocumentReasonCdDesc());
    }

    // ========== TIME UPDATE TESTS ==========

    @Test
    void testTimeUpdateGetterAndSetter() {
        imiSearchResults.setTimeUpdate("2023-01-01 15:45:00");
        assertEquals("2023-01-01 15:45:00", imiSearchResults.getTimeUpdate());
    }

    @Test
    void testTimeUpdateWithNull() {
        imiSearchResults.setTimeUpdate(null);
        assertNull(imiSearchResults.getTimeUpdate());
    }

    @Test
    void testTimeUpdateWithEmptyString() {
        imiSearchResults.setTimeUpdate("");
        assertEquals("", imiSearchResults.getTimeUpdate());
    }

    // ========== APPLICATION ID TESTS ==========

    @Test
    void testApplIdCdGetterAndSetter() {
        imiSearchResults.setApplIdCd("12345");
        assertEquals("12345", imiSearchResults.getApplIdCd());
    }

    @Test
    void testApplIdCdWithNull() {
        imiSearchResults.setApplIdCd(null);
        assertNull(imiSearchResults.getApplIdCd());
    }

    @Test
    void testApplIdCdWithEmptyString() {
        imiSearchResults.setApplIdCd("");
        assertEquals("", imiSearchResults.getApplIdCd());
    }

    // ========== CAPTURE ITEM TESTS ==========

    @Test
    void testCaptureItemIdGetterAndSetter() {
        imiSearchResults.setCaptureItemId("CAPTURE123");
        assertEquals("CAPTURE123", imiSearchResults.getCaptureItemId());
    }

    @Test
    void testCaptureItemIdWithNull() {
        imiSearchResults.setCaptureItemId(null);
        assertNull(imiSearchResults.getCaptureItemId());
    }

    @Test
    void testCaptureItemIdWithEmptyString() {
        imiSearchResults.setCaptureItemId("");
        assertEquals("", imiSearchResults.getCaptureItemId());
    }

    // ========== RESULT SET POINTER TESTS ==========

    @Test
    void testResultSetPointerGetterAndSetter() {
        imiSearchResults.setResultSetPointer(100L);
        assertEquals(100L, imiSearchResults.getResultSetPointer());
    }

    @Test
    void testResultSetPointerWithZero() {
        imiSearchResults.setResultSetPointer(0L);
        assertEquals(0L, imiSearchResults.getResultSetPointer());
    }

    @Test
    void testResultSetPointerWithNegativeValue() {
        imiSearchResults.setResultSetPointer(-1L);
        assertEquals(-1L, imiSearchResults.getResultSetPointer());
    }

    @Test
    void testResultSetPointerWithMaxValue() {
        imiSearchResults.setResultSetPointer(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, imiSearchResults.getResultSetPointer());
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteSearchResultsSetup() {
        // Set all fields with sample data
        imiSearchResults.setNaicCode("12345");
        imiSearchResults.setTransmitTimeStamp("2023-01-01 10:00:00");
        imiSearchResults.setTransmitFileId(12345L);
        imiSearchResults.setTransmitFileName("test_file.txt");
        imiSearchResults.setTransmitFileStatusCd("A");
        imiSearchResults.setImiFileId(67890L);
        imiSearchResults.setPlanFileId("PLAN123");
        imiSearchResults.setProcessFileName("process_file.pdf");
        imiSearchResults.setProcessFileStatusCd("C");
        imiSearchResults.setProcessFileReasonCdDesc("REASON001");
        imiSearchResults.setTimeAck("2023-01-01 10:30:00");
        imiSearchResults.setImiDocumentId(98765);
        imiSearchResults.setPlanDCN("DCN123456");
        imiSearchResults.setDpk("DPK789");
        imiSearchResults.setInitialProcessDCN("INIT_DCN123");
        imiSearchResults.setFinalProcessDCN("FINAL_DCN456");
        imiSearchResults.setDocumentStatusCd("S");
        imiSearchResults.setDocumentReasonCdDesc("REASON002");
        imiSearchResults.setTimeUpdate("2023-01-01 15:45:00");
        imiSearchResults.setApplIdCd("12345");
        imiSearchResults.setCaptureItemId("CAPTURE123");
        imiSearchResults.setResultSetPointer(100L);

        // Verify all fields are set correctly
        assertEquals("12345", imiSearchResults.getNaicCode());
        assertEquals("2023-01-01 10:00:00", imiSearchResults.getTransmitTimeStamp());
        assertEquals(12345L, imiSearchResults.getTransmitFileId());
        assertEquals("test_file.txt", imiSearchResults.getTransmitFileName());
        assertEquals("A", imiSearchResults.getTransmitFileStatusCd());
        assertEquals(67890L, imiSearchResults.getImiFileId());
        assertEquals("PLAN123", imiSearchResults.getPlanFileId());
        assertEquals("process_file.pdf", imiSearchResults.getProcessFileName());
        assertEquals("C", imiSearchResults.getProcessFileStatusCd());
        assertEquals("REASON001", imiSearchResults.getProcessFileReasonCdDesc());
        assertEquals("2023-01-01 10:30:00", imiSearchResults.getTimeAck());
        assertEquals(98765, imiSearchResults.getImiDocumentId());
        assertEquals("DCN123456", imiSearchResults.getPlanDCN());
        assertEquals("DPK789", imiSearchResults.getDpk());
        assertEquals("INIT_DCN123", imiSearchResults.getInitialProcessDCN());
        assertEquals("FINAL_DCN456", imiSearchResults.getFinalProcessDCN());
        assertEquals("S", imiSearchResults.getDocumentStatusCd());
        assertEquals("REASON002", imiSearchResults.getDocumentReasonCdDesc());
        assertEquals("2023-01-01 15:45:00", imiSearchResults.getTimeUpdate());
        assertEquals("12345", imiSearchResults.getApplIdCd());
        assertEquals("CAPTURE123", imiSearchResults.getCaptureItemId());
        assertEquals(100L, imiSearchResults.getResultSetPointer());
    }

    @Test
    void testSearchResultsWithAllNullValues() {
        // All fields should be null by default
        assertNull(imiSearchResults.getNaicCode());
        assertNull(imiSearchResults.getTransmitTimeStamp());
        assertNull(imiSearchResults.getTransmitFileName());
        assertNull(imiSearchResults.getTransmitFileStatusCd());
        assertNull(imiSearchResults.getPlanFileId());
        assertNull(imiSearchResults.getProcessFileName());
        assertNull(imiSearchResults.getProcessFileStatusCd());
        assertNull(imiSearchResults.getProcessFileReasonCdDesc());
        assertNull(imiSearchResults.getTimeAck());
        assertNull(imiSearchResults.getImiDocumentId());
        assertNull(imiSearchResults.getPlanDCN());
        assertNull(imiSearchResults.getDpk());
        assertNull(imiSearchResults.getInitialProcessDCN());
        assertNull(imiSearchResults.getFinalProcessDCN());
        assertNull(imiSearchResults.getDocumentStatusCd());
        assertNull(imiSearchResults.getDocumentReasonCdDesc());
        assertNull(imiSearchResults.getTimeUpdate());
        assertNull(imiSearchResults.getApplIdCd());
        assertNull(imiSearchResults.getCaptureItemId());
    }

    // ========== EDGE CASE TESTS ==========

    @Test
    void testWithSpecialCharacters() {
        imiSearchResults.setNaicCode("12345!@#$%");
        imiSearchResults.setTransmitFileName("file with spaces & special chars.txt");
        imiSearchResults.setPlanFileId("PLAN-123_456");
        imiSearchResults.setProcessFileName("process_file with spaces.pdf");
        imiSearchResults.setDpk("DPK-789_ABC");
        
        assertEquals("12345!@#$%", imiSearchResults.getNaicCode());
        assertEquals("file with spaces & special chars.txt", imiSearchResults.getTransmitFileName());
        assertEquals("PLAN-123_456", imiSearchResults.getPlanFileId());
        assertEquals("process_file with spaces.pdf", imiSearchResults.getProcessFileName());
        assertEquals("DPK-789_ABC", imiSearchResults.getDpk());
    }

    @Test
    void testWithEmptyStrings() {
        imiSearchResults.setNaicCode("");
        imiSearchResults.setTransmitFileName("");
        imiSearchResults.setPlanFileId("");
        imiSearchResults.setProcessFileName("");
        imiSearchResults.setDpk("");
        
        assertEquals("", imiSearchResults.getNaicCode());
        assertEquals("", imiSearchResults.getTransmitFileName());
        assertEquals("", imiSearchResults.getPlanFileId());
        assertEquals("", imiSearchResults.getProcessFileName());
        assertEquals("", imiSearchResults.getDpk());
    }

    @Test
    void testWithVeryLongStrings() {
        String longString = "A".repeat(1000);
        imiSearchResults.setNaicCode(longString);
        imiSearchResults.setTransmitFileName(longString);
        imiSearchResults.setPlanFileId(longString);
        imiSearchResults.setProcessFileName(longString);
        imiSearchResults.setDpk(longString);
        
        assertEquals(longString, imiSearchResults.getNaicCode());
        assertEquals(longString, imiSearchResults.getTransmitFileName());
        assertEquals(longString, imiSearchResults.getPlanFileId());
        assertEquals(longString, imiSearchResults.getProcessFileName());
        assertEquals(longString, imiSearchResults.getDpk());
    }

    @Test
    void testWithUnicodeCharacters() {
        imiSearchResults.setNaicCode("12345测试");
        imiSearchResults.setTransmitFileName("file_测试.txt");
        imiSearchResults.setPlanFileId("PLAN_测试_123");
        imiSearchResults.setProcessFileName("process_测试.pdf");
        imiSearchResults.setDpk("DPK_测试_789");
        
        assertEquals("12345测试", imiSearchResults.getNaicCode());
        assertEquals("file_测试.txt", imiSearchResults.getTransmitFileName());
        assertEquals("PLAN_测试_123", imiSearchResults.getPlanFileId());
        assertEquals("process_测试.pdf", imiSearchResults.getProcessFileName());
        assertEquals("DPK_测试_789", imiSearchResults.getDpk());
    }

    @Test
    void testWithNumericStringValues() {
        imiSearchResults.setNaicCode("12345");
        imiSearchResults.setTransmitFileName("12345.txt");
        imiSearchResults.setPlanFileId("12345");
        imiSearchResults.setProcessFileName("12345.pdf");
        imiSearchResults.setDpk("12345");
        imiSearchResults.setApplIdCd("12345");
        imiSearchResults.setCaptureItemId("12345");
        
        assertEquals("12345", imiSearchResults.getNaicCode());
        assertEquals("12345.txt", imiSearchResults.getTransmitFileName());
        assertEquals("12345", imiSearchResults.getPlanFileId());
        assertEquals("12345.pdf", imiSearchResults.getProcessFileName());
        assertEquals("12345", imiSearchResults.getDpk());
        assertEquals("12345", imiSearchResults.getApplIdCd());
        assertEquals("12345", imiSearchResults.getCaptureItemId());
    }

    @Test
    void testWithDateTimeFormats() {
        imiSearchResults.setTransmitTimeStamp("2023-01-01 10:00:00");
        imiSearchResults.setTimeAck("2023-01-01 10:30:00");
        imiSearchResults.setTimeUpdate("2023-01-01 15:45:00");
        
        assertEquals("2023-01-01 10:00:00", imiSearchResults.getTransmitTimeStamp());
        assertEquals("2023-01-01 10:30:00", imiSearchResults.getTimeAck());
        assertEquals("2023-01-01 15:45:00", imiSearchResults.getTimeUpdate());
    }

    @Test
    void testWithStatusCodes() {
        imiSearchResults.setTransmitFileStatusCd("A");
        imiSearchResults.setProcessFileStatusCd("C");
        imiSearchResults.setDocumentStatusCd("S");
        
        assertEquals("A", imiSearchResults.getTransmitFileStatusCd());
        assertEquals("C", imiSearchResults.getProcessFileStatusCd());
        assertEquals("S", imiSearchResults.getDocumentStatusCd());
    }

    @Test
    void testWithReasonCodes() {
        imiSearchResults.setProcessFileReasonCdDesc("REASON001");
        imiSearchResults.setDocumentReasonCdDesc("REASON002");
        
        assertEquals("REASON001", imiSearchResults.getProcessFileReasonCdDesc());
        assertEquals("REASON002", imiSearchResults.getDocumentReasonCdDesc());
    }

    @Test
    void testWithDCNValues() {
        imiSearchResults.setPlanDCN("DCN123456");
        imiSearchResults.setInitialProcessDCN("INIT_DCN123");
        imiSearchResults.setFinalProcessDCN("FINAL_DCN456");
        
        assertEquals("DCN123456", imiSearchResults.getPlanDCN());
        assertEquals("INIT_DCN123", imiSearchResults.getInitialProcessDCN());
        assertEquals("FINAL_DCN456", imiSearchResults.getFinalProcessDCN());
    }
}
