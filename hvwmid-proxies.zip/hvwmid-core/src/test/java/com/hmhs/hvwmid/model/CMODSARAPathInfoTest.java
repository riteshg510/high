package com.hmhs.hvwmid.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for CMODSARAPathInfo DTO.
 * Tests DTO serialization, validation, and constructor behavior.
 */
class CMODSARAPathInfoTest {

    @Test
    void testDefaultConstructor() {
        // Act
        CMODSARAPathInfo info = new CMODSARAPathInfo();

        // Assert
        assertNotNull(info);
        assertNull(info.getRootPath());
        assertNull(info.getHighviewPaths());
        assertNull(info.getRenoPaths());
    }

    @Test
    void testParameterizedConstructor() {
        // Arrange
        String rootPath = "/test/root/path";
        Map<String, String> highviewPaths = createTestHighviewPaths();
        Map<String, String> renoPaths = createTestRenoPaths();

        // Act
        CMODSARAPathInfo info = new CMODSARAPathInfo(rootPath, highviewPaths, renoPaths);

        // Assert
        assertNotNull(info);
        assertEquals(rootPath, info.getRootPath());
        assertEquals(highviewPaths, info.getHighviewPaths());
        assertEquals(renoPaths, info.getRenoPaths());
        assertEquals(2, info.getHighviewPaths().size());
        assertEquals(2, info.getRenoPaths().size());
    }

    @Test
    void testParameterizedConstructorWithNulls() {
        // Act
        CMODSARAPathInfo info = new CMODSARAPathInfo(null, null, null);

        // Assert
        assertNotNull(info);
        assertNull(info.getRootPath());
        assertNull(info.getHighviewPaths());
        assertNull(info.getRenoPaths());
    }

    @Test
    void testSettersAndGetters() {
        // Arrange
        CMODSARAPathInfo info = new CMODSARAPathInfo();
        String rootPath = "/dynamic/root/path";
        Map<String, String> highviewPaths = createTestHighviewPaths();
        Map<String, String> renoPaths = createTestRenoPaths();

        // Act
        info.setRootPath(rootPath);
        info.setHighviewPaths(highviewPaths);
        info.setRenoPaths(renoPaths);

        // Assert
        assertEquals(rootPath, info.getRootPath());
        assertEquals(highviewPaths, info.getHighviewPaths());
        assertEquals(renoPaths, info.getRenoPaths());
    }

    @Test
    void testRootPathHandling() {
        // Arrange
        CMODSARAPathInfo info = new CMODSARAPathInfo();

        // Test null root path
        info.setRootPath(null);
        assertNull(info.getRootPath());

        // Test empty root path
        info.setRootPath("");
        assertEquals("", info.getRootPath());

        // Test absolute path
        info.setRootPath("/absolute/path");
        assertEquals("/absolute/path", info.getRootPath());

        // Test relative path
        info.setRootPath("relative/path");
        assertEquals("relative/path", info.getRootPath());

        // Test Windows-style path
        info.setRootPath("C:\\Windows\\Path");
        assertEquals("C:\\Windows\\Path", info.getRootPath());
    }

    @Test
    void testHighviewPathsHandling() {
        // Arrange
        CMODSARAPathInfo info = new CMODSARAPathInfo();

        // Test null paths
        info.setHighviewPaths(null);
        assertNull(info.getHighviewPaths());

        // Test empty map
        Map<String, String> emptyMap = new HashMap<>();
        info.setHighviewPaths(emptyMap);
        assertEquals(emptyMap, info.getHighviewPaths());
        assertTrue(info.getHighviewPaths().isEmpty());

        // Test populated map
        Map<String, String> highviewPaths = createTestHighviewPaths();
        info.setHighviewPaths(highviewPaths);
        assertEquals(highviewPaths, info.getHighviewPaths());
        assertEquals("/highview/path1", info.getHighviewPaths().get("HIGHVIEW_PATH1"));
        assertEquals("/highview/path2", info.getHighviewPaths().get("HIGHVIEW_PATH2"));
    }

    @Test
    void testRenoPathsHandling() {
        // Arrange
        CMODSARAPathInfo info = new CMODSARAPathInfo();

        // Test null paths
        info.setRenoPaths(null);
        assertNull(info.getRenoPaths());

        // Test empty map
        Map<String, String> emptyMap = new HashMap<>();
        info.setRenoPaths(emptyMap);
        assertEquals(emptyMap, info.getRenoPaths());
        assertTrue(info.getRenoPaths().isEmpty());

        // Test populated map
        Map<String, String> renoPaths = createTestRenoPaths();
        info.setRenoPaths(renoPaths);
        assertEquals(renoPaths, info.getRenoPaths());
        assertEquals("/reno/path1", info.getRenoPaths().get("RENO_PATH1"));
        assertEquals("/reno/path2", info.getRenoPaths().get("RENO_PATH2"));
    }

    @Test
    void testPathMapModification() {
        // Arrange
        CMODSARAPathInfo info = new CMODSARAPathInfo();
        Map<String, String> highviewPaths = new HashMap<>(createTestHighviewPaths());
        Map<String, String> renoPaths = new HashMap<>(createTestRenoPaths());
        
        info.setHighviewPaths(highviewPaths);
        info.setRenoPaths(renoPaths);

        // Act - Modify the maps
        highviewPaths.put("NEW_HIGHVIEW_PATH", "/new/highview/path");
        renoPaths.put("NEW_RENO_PATH", "/new/reno/path");

        // Assert - Modifications should be reflected
        assertEquals(3, info.getHighviewPaths().size());
        assertEquals(3, info.getRenoPaths().size());
        assertEquals("/new/highview/path", info.getHighviewPaths().get("NEW_HIGHVIEW_PATH"));
        assertEquals("/new/reno/path", info.getRenoPaths().get("NEW_RENO_PATH"));
    }

    @Test
    void testMixedPathTypes() {
        // Arrange
        CMODSARAPathInfo info = new CMODSARAPathInfo();
        Map<String, String> mixedPaths = new HashMap<>();
        mixedPaths.put("UNIX_PATH", "/unix/style/path");
        mixedPaths.put("WINDOWS_PATH", "C:\\Windows\\Style\\Path");
        mixedPaths.put("RELATIVE_PATH", "relative/path");
        mixedPaths.put("EMPTY_PATH", "");
        mixedPaths.put("NULL_PATH", null);

        // Act
        info.setHighviewPaths(mixedPaths);

        // Assert
        assertEquals(5, info.getHighviewPaths().size());
        assertEquals("/unix/style/path", info.getHighviewPaths().get("UNIX_PATH"));
        assertEquals("C:\\Windows\\Style\\Path", info.getHighviewPaths().get("WINDOWS_PATH"));
        assertEquals("relative/path", info.getHighviewPaths().get("RELATIVE_PATH"));
        assertEquals("", info.getHighviewPaths().get("EMPTY_PATH"));
        assertNull(info.getHighviewPaths().get("NULL_PATH"));
    }

    @Test
    void testCompletePathConfiguration() {
        // Arrange
        String rootPath = "/cmod/root";
        Map<String, String> highviewPaths = createTestHighviewPaths();
        Map<String, String> renoPaths = createTestRenoPaths();

        // Act
        CMODSARAPathInfo info = new CMODSARAPathInfo(rootPath, highviewPaths, renoPaths);

        // Assert - Test complete configuration
        assertNotNull(info);
        assertEquals(rootPath, info.getRootPath());
        
        // Verify all Highview paths
        assertEquals(2, info.getHighviewPaths().size());
        assertTrue(info.getHighviewPaths().containsKey("HIGHVIEW_PATH1"));
        assertTrue(info.getHighviewPaths().containsKey("HIGHVIEW_PATH2"));
        
        // Verify all Reno paths
        assertEquals(2, info.getRenoPaths().size());
        assertTrue(info.getRenoPaths().containsKey("RENO_PATH1"));
        assertTrue(info.getRenoPaths().containsKey("RENO_PATH2"));
    }

    /**
     * Helper method to create test Highview paths.
     */
    private Map<String, String> createTestHighviewPaths() {
        Map<String, String> paths = new HashMap<>();
        paths.put("HIGHVIEW_PATH1", "/highview/path1");
        paths.put("HIGHVIEW_PATH2", "/highview/path2");
        return paths;
    }

    /**
     * Helper method to create test Reno paths.
     */
    private Map<String, String> createTestRenoPaths() {
        Map<String, String> paths = new HashMap<>();
        paths.put("RENO_PATH1", "/reno/path1");
        paths.put("RENO_PATH2", "/reno/path2");
        return paths;
    }
}