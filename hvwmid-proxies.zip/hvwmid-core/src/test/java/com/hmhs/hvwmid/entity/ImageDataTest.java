package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class ImageDataTest {

    private ImageData imageData;

    @BeforeEach
    void setUp() {
        imageData = new ImageData();
    }

    // Test for ID
    @Test
    void testSetGetId() {
        Long id = 1L;
        imageData.setId(id);
        assertEquals(id, imageData.getId());
    }

    // Test for ApplicationId
    @Test
    void testSetGetApplicationId() {
        String appId = "app123";
        imageData.setApplicationId(appId);
        assertEquals(appId, imageData.getApplicationId());
    }

    // Test for FileTab
    @Test
    void testSetGetFileTab() {
        String fileTab = "fileTab123";
        imageData.setFileTab(fileTab);
        assertEquals(fileTab, imageData.getFileTab());
    }

    // Test for Filed (LocalDateTime)
    @Test
    void testSetGetFiled() {
        LocalDateTime filedTime = LocalDateTime.of(2024, 10, 9, 12, 0, 0, 0);
        imageData.setFiled(filedTime);
        assertEquals(filedTime, imageData.getFiled());
    }

    // Test for FolderId
    @Test
    void testSetGetFolderId() {
        String folderId = "folder123";
        imageData.setFolderId(folderId);
        assertEquals(folderId, imageData.getFolderId());
    }

    // Test for FormDescription
    @Test
    void testSetGetFormDescription() {
        String description = "Form Description";
        imageData.setFormDescription(description);
        assertEquals(description, imageData.getFormDescription());
    }

    // Test for Pages
    @Test
    void testSetGetPages() {
        int pages = 5;
        imageData.setPages(pages);
        assertEquals(pages, imageData.getPages());
    }

    // Test for Received (LocalDateTime)
    @Test
    void testSetGetReceived() {
        LocalDateTime receivedTime = LocalDateTime.of(2024, 10, 9, 14, 0, 0, 0);
        imageData.setReceived(receivedTime);
        assertEquals(receivedTime, imageData.getReceived());
    }

    // Test for View
    @Test
    void testSetGetView() {
        String view = "some view";
        imageData.setView(view);
        assertEquals(view, imageData.getView());
    }

    // Test for Update
    @Test
    void testSetGetUpdate() {
        String update = "some update";
        imageData.setUpdate(update);
        assertEquals(update, imageData.getUpdate());
    }

    // Test for FileName
    @Test
    void testSetGetFileName() {
        String fileName = "imagefile.jpg";
        imageData.setFileName(fileName);
        assertEquals(fileName, imageData.getFileName());
    }

    // Test for Constructor with id and appId
    @Test
    void testConstructorWithIdAndAppId() {
        Long id = 123L;
        String appId = "app123";
        ImageData imageDataWithConstructor = new ImageData(id, appId);

        assertEquals(id, imageDataWithConstructor.getId());
        assertEquals(appId, imageDataWithConstructor.getApplicationId());
    }

    // Test for Empty Constructor
    @Test
    void testEmptyConstructor() {
        ImageData imageDataWithDefaultConstructor = new ImageData();
        assertNull(imageDataWithDefaultConstructor.getId());
        assertNull(imageDataWithDefaultConstructor.getApplicationId());
        assertNull(imageDataWithDefaultConstructor.getFileTab());
        assertNull(imageDataWithDefaultConstructor.getFiled());
        assertNull(imageDataWithDefaultConstructor.getFolderId());
        assertNull(imageDataWithDefaultConstructor.getFormDescription());
        assertEquals(0, imageDataWithDefaultConstructor.getPages());
        assertNull(imageDataWithDefaultConstructor.getReceived());
        assertNull(imageDataWithDefaultConstructor.getView());
        assertNull(imageDataWithDefaultConstructor.getUpdate());
        assertNull(imageDataWithDefaultConstructor.getFileName());
    }
}
