package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import org.apache.logging.log4j.ThreadContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class LoggerServiceTest {

    @InjectMocks
    private LoggerService loggerService;

    @Mock
    private HvwStatusService hvwStatusService;

    @Mock
    private T222APRMRepository t222aprmRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(loggerService, "environment", "TestEnv");
        ReflectionTestUtils.setField(loggerService, "dbLoggingLevel", "INFO");
    }

    @Test
    void testGetLogLevelInt_DEBUG() {
        int result = loggerService.getLogLevelInt("DEBUG");
        assertEquals(LoggerService.DEBUG, result);
    }

    @Test
    void testGetLogLevelInt_INFO() {
        int result = loggerService.getLogLevelInt("INFO");
        assertEquals(LoggerService.INFO, result);
    }

    @Test
    void testGetLogLevelInt_ERROR() {
        int result = loggerService.getLogLevelInt("ERROR");
        assertEquals(LoggerService.ERROR, result);
    }

    @Test
    void testGetLogLevelInt_Invalid_ReturnsDefault() {
        int result = loggerService.getLogLevelInt("INVALID");
        assertEquals(LoggerService.INFO, result); // Default je INFO (1)
    }

    @Test
    void testGetLogLevelForUser_UserLevelFound_Valid() {
        T222APRM userLevel = new T222APRM();
        userLevel.setParmKey("user123");
        userLevel.setParmData("DEBUG");

        when(t222aprmRepository.findByParmId("HVWLOG"))
                .thenReturn(Collections.singletonList(userLevel));

        String level = loggerService.getLogLevelForUser("user123");
        assertEquals("DEBUG", level);
    }

    @Test
    void testGetLogLevelForUser_UserLevelFound_Invalid() {
        T222APRM userLevel = new T222APRM();
        userLevel.setParmKey("user123");
        userLevel.setParmData("INVALID_LEVEL");

        when(t222aprmRepository.findByParmId("HVWLOG"))
                .thenReturn(Collections.singletonList(userLevel));

        String level = loggerService.getLogLevelForUser("user123");
        assertEquals("INFO", level);  // Default to INFO if invalid
    }

    @Test
    void testGetLogLevelForUser_DefaultLevelFound_Valid() {
        T222APRM defaultLevel = new T222APRM();
        defaultLevel.setParmKey("DEFAULT");
        defaultLevel.setParmData("ERROR");

        when(t222aprmRepository.findByParmId("HVWLOG"))
                .thenReturn(Collections.singletonList(defaultLevel));

        String level = loggerService.getLogLevelForUser("unknownUser");
        assertEquals("ERROR", level);
    }

    // Test getLogLevelForUser: user and DEFAULT not found
    @Test
    void testGetLogLevelForUser_NoUserNoDefault() {
        when(t222aprmRepository.findByParmId("HVWLOG")).thenReturn(Collections.emptyList());

        String level = loggerService.getLogLevelForUser("unknownUser");
        assertEquals("INFO", level);  // fallback to INFO
    }

    // Test log() method when environment = Noservice (should just log and not call hvwStatusService)
    @Test
    void testLog_NoserviceEnvironment_LogsToConsoleOnly() {
        ReflectionTestUtils.setField(loggerService, "environment", "Noservice");

        // We can spy on loggerService to verify hvwStatusService.populateT222HvwStatus is NOT called
        loggerService.log("INFO", 1, 2, 3, "user1", "func", "url", "200", "desc");

        verifyNoInteractions(hvwStatusService);
    }

    // Test log() method normal flow - hvwStatusService gets called if envLogLevel >= currentLogLevel
    @Test
    void testLog_NormalOperation_CallsHvwStatusService() {
        // Mock getLogLevelForUser to return INFO (level 1)
        LoggerService spyLogger = spy(loggerService);
        doReturn("INFO").when(spyLogger).getLogLevelForUser("user1");
        // Override getLogLevelInt to return proper ints
        doReturn(LoggerService.INFO).when(spyLogger).getLogLevelInt("INFO");

        // Put a codRequestId in ThreadContext to override passed codRequestId
        ThreadContext.put("COD_REQUEST_ID", "999");

        spyLogger.log("INFO", 100, 200, 300, "user1", "function", "url", "404", "desc");

        // hvwStatusService.populateT222HvwStatus treba da se pozove sa codRequestId iz ThreadContext (999)
        verify(hvwStatusService).populateT222HvwStatus(100, 200, 999, "user1", "function", "url", "404", "desc");

        ThreadContext.clearAll();
    }

    // Test log() method normal flow - hvwStatusService not called if log level too low
    @Test
    void testLog_LogLevelTooLow_DoesNotCallHvwStatusService() {
        LoggerService spyLogger = spy(loggerService);
        doReturn("ERROR").when(spyLogger).getLogLevelForUser("user1"); // env level ERROR = 0
        doReturn(LoggerService.ERROR).when(spyLogger).getLogLevelInt("ERROR");

        spyLogger.log("INFO", 100, 200, 300, "user1", "function", "url", "404", "desc");

        verifyNoInteractions(hvwStatusService);
    }

}
