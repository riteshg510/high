package com.hmhs.hvwmid.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.model.CMODApplicationAccessInfo;
import com.hmhs.hvwmid.model.CMODSARAPathInfo;
import com.hmhs.hvwmid.model.CMODSecurityAccessResponse;
import com.hmhs.hvwmid.repository.CMODSecurityRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.repository.T222CodRacfExtEntRepository;

/**
 * Unit tests for CMODSecurityService.
 * Tests the main business logic for CMOD security access functionality.
 */
@ExtendWith(MockitoExtension.class)
class CMODSecurityServiceTest {

    @Mock
    private T222APRMRepository t222APRMRepository;
    
    @Mock
    private CMODSecurityRepository cmodSecurityRepository;
    
    @Mock
    private T222CodRacfExtEntRepository racfExtEntRepository;
    
    @Mock
    private ImageParmDataService imageParmDataService;
    
    @Mock
    private CMODDataRefreshService cmodDataRefreshService;

    @InjectMocks
    private CMODSecurityService cmodSecurityService;

    private static final String TEST_USER_ID = "TESTUSER";
    private static final String TEST_FOLDER_NAME = "TEST_FOLDER";

    @BeforeEach
    void setUp() {
        // Common setup for all tests
    }

    @Test
    void testGetCMODSecurityAccess_Success() {
        // Arrange
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        
        List<String> clientCodes = Arrays.asList("HMRK", "NDAK");
        when(racfExtEntRepository.getUserClientCodes(TEST_USER_ID.toUpperCase()))
            .thenReturn(clientCodes);
        
        Set<String> validClientCodes = Set.of("HMRK", "NDAK", "MINN");
        when(cmodDataRefreshService.getCMODClientCodes())
            .thenReturn(validClientCodes);
        
        Set<String> userFolders = Set.of("FOLDER1", "FOLDER2");
        Map<String, Set<String>> folderApps = new HashMap<>();
        folderApps.put("APP_GROUP1", Set.of("APP1-HMRK-V1", "APP2-HMRK-V2"));
        
        when(cmodDataRefreshService.getCMODFolderDetails(anyString()))
            .thenReturn(folderApps);
        when(cmodDataRefreshService.getAllCMODFolderDetails())
            .thenReturn(Map.of("FOLDER1", folderApps, "FOLDER2", folderApps));
        
        Map<String, List<String>> agqrMap = new HashMap<>();
        agqrMap.put("APP_GROUP1", Arrays.asList("APP1-HMRK-V1", "APP2-HMRK-V2"));
        when(cmodSecurityRepository.getUserAGQRMappings(TEST_USER_ID))
            .thenReturn(agqrMap);
        
        CMODApplicationAccessInfo appInfo = new CMODApplicationAccessInfo();
        appInfo.setAcf2String("TEST_ACF2");
        appInfo.setVpieApplication("TEST_APP");
        appInfo.setVpieRoleDescription("TEST_ROLE");
        when(cmodDataRefreshService.getRACFEntityForApplication(anyString()))
            .thenReturn(appInfo);
        
        when(imageParmDataService.getSecuredClntEmpSecMap())
            .thenReturn(new HashMap<>());
        
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMBASE", ""))
            .thenReturn("/test/path");
        when(imageParmDataService.getParmDataMap("CMSARA"))
            .thenReturn(Map.of("HIGHVIEW_PATH", "/highview", "RENO_PATH", "/reno"));
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_PRODUCT_DTS_TRIAGE", ""))
            .thenReturn("Test Triage Info");

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");

        // Assert
        assertNotNull(response);
        assertFalse(response.isHasError());
        assertNotNull(response.getFolderAccessMap());
        assertNotNull(response.getSaraPathInfo());
        assertEquals("HMRK, NDAK", response.getUserGroups());
        assertEquals("Test Triage Info", response.getTriageInfo());
        
        // Verify interactions
        verify(racfExtEntRepository).getUserClientCodes(TEST_USER_ID.toUpperCase());
        verify(cmodSecurityRepository).getUserAGQRMappings(TEST_USER_ID);
        verify(cmodDataRefreshService).getCMODClientCodes();
    }

    @Test
    void testGetCMODSecurityAccess_CMODAccessUIDisabled() {
        // Arrange
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("N");

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");

        // Assert
        assertNotNull(response);
        assertTrue(response.isHasError());
        assertEquals("CMOD Access UI is currently disabled.", response.getErrorMessage());
        
        // Verify no further processing occurred
        verify(racfExtEntRepository, never()).getUserClientCodes(anyString());
    }

    @Test
    void testGetCMODSecurityAccess_NoClientCodes() {
        // Arrange
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        when(racfExtEntRepository.getUserClientCodes(TEST_USER_ID.toUpperCase()))
            .thenReturn(Arrays.asList());
        when(cmodDataRefreshService.getCMODClientCodes())
            .thenReturn(Set.of("HMRK", "NDAK"));

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");

        // Assert
        assertNotNull(response);
        assertTrue(response.isHasError());
        assertEquals("You do not have access to any CMOD applications.", response.getErrorMessage());
    }

    @Test
    void testGetCMODSecurityAccess_WithSpecificFolder() {
        // Arrange
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        
        List<String> clientCodes = Arrays.asList("HMRK");
        when(racfExtEntRepository.getUserClientCodes(TEST_USER_ID.toUpperCase()))
            .thenReturn(clientCodes);
        when(cmodDataRefreshService.getCMODClientCodes())
            .thenReturn(Set.of("HMRK"));
        
        Map<String, Set<String>> folderApps = new HashMap<>();
        folderApps.put("APP_GROUP1", Set.of("APP1-HMRK-V1"));
        when(cmodDataRefreshService.getCMODFolderDetails(TEST_FOLDER_NAME))
            .thenReturn(folderApps);
        
        when(cmodSecurityRepository.getUserAGQRMappings(TEST_USER_ID))
            .thenReturn(new HashMap<>());
        
        CMODApplicationAccessInfo appInfo = new CMODApplicationAccessInfo();
        appInfo.setAcf2String("TEST_ACF2");
        when(cmodDataRefreshService.getRACFEntityForApplication(anyString()))
            .thenReturn(appInfo);
        
        when(imageParmDataService.getSecuredClntEmpSecMap())
            .thenReturn(new HashMap<>());
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMBASE", ""))
            .thenReturn("");
        when(imageParmDataService.getParmDataMap("CMSARA"))
            .thenReturn(new HashMap<>());
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_PRODUCT_DTS_TRIAGE", ""))
            .thenReturn("");

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, TEST_FOLDER_NAME);

        // Assert
        assertNotNull(response);
        assertFalse(response.isHasError());
        
        // Verify specific folder was requested (called twice - once in getUserAccessibleFolders, once in buildFolderAccessMap)
        verify(cmodDataRefreshService, times(2)).getCMODFolderDetails(TEST_FOLDER_NAME);
        verify(cmodDataRefreshService, never()).getAllCMODFolderDetails();
    }

    @Test
    void testGetCMODSecurityAccess_ExceptionHandling() {
        // Arrange  
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        when(racfExtEntRepository.getUserClientCodes(anyString()))
            .thenThrow(new RuntimeException("Database error"));

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");

        // Assert - Service handles the exception gracefully and returns error response
        assertNotNull(response);
        assertTrue(response.isHasError());
        assertEquals("You do not have access to any CMOD applications.", response.getErrorMessage());
    }

    @Test
    void testIsCMODAccessUIEnabled_Enabled() {
        // This tests the private method through the public method
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        when(racfExtEntRepository.getUserClientCodes(anyString()))
            .thenReturn(Arrays.asList());
        when(cmodDataRefreshService.getCMODClientCodes())
            .thenReturn(Set.of());

        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");
        
        // If we get past the UI check, it means it was enabled
        assertNotNull(response);
        assertTrue(response.isHasError());
        assertEquals("You do not have access to any CMOD applications.", response.getErrorMessage());
    }

    @Test
    void testGetUserClientCodes_FilteringLogic() {
        // Arrange
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        
        // User has access to more codes than are valid in CMOD
        List<String> racfClientCodes = Arrays.asList("HMRK", "INVALID", "NDAK", "ANOTHER_INVALID");
        when(racfExtEntRepository.getUserClientCodes(TEST_USER_ID.toUpperCase()))
            .thenReturn(racfClientCodes);
        
        // Only some codes are valid in CMOD
        Set<String> validClientCodes = Set.of("HMRK", "NDAK", "MINN");
        when(cmodDataRefreshService.getCMODClientCodes())
            .thenReturn(validClientCodes);
        
        when(cmodDataRefreshService.getAllCMODFolderDetails())
            .thenReturn(new HashMap<>());
        when(cmodSecurityRepository.getUserAGQRMappings(TEST_USER_ID))
            .thenReturn(new HashMap<>());
        when(imageParmDataService.getSecuredClntEmpSecMap())
            .thenReturn(new HashMap<>());
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMBASE", ""))
            .thenReturn("");
        when(imageParmDataService.getParmDataMap("CMSARA"))
            .thenReturn(new HashMap<>());
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_PRODUCT_DTS_TRIAGE", ""))
            .thenReturn("");

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");

        // Assert
        assertNotNull(response);
        // Should only contain the filtered valid codes
        assertEquals("HMRK, NDAK", response.getUserGroups());
    }

    @Test
    void testBuildSARAPathInfo_PathSeparation() {
        // Arrange
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_ACCESS_UI", "Y"))
            .thenReturn("Y");
        when(racfExtEntRepository.getUserClientCodes(anyString()))
            .thenReturn(Arrays.asList("HMRK"));
        when(cmodDataRefreshService.getCMODClientCodes())
            .thenReturn(Set.of("HMRK"));
        when(cmodDataRefreshService.getAllCMODFolderDetails())
            .thenReturn(new HashMap<>());
        when(cmodSecurityRepository.getUserAGQRMappings(anyString()))
            .thenReturn(new HashMap<>());
        when(imageParmDataService.getSecuredClntEmpSecMap())
            .thenReturn(new HashMap<>());
        
        // Setup SARA paths with different prefixes
        Map<String, String> saraMap = new HashMap<>();
        saraMap.put("HIGHVIEW_PATH1", "/highview/path1");
        saraMap.put("RENO_PATH1", "/reno/path1");
        saraMap.put("HIGHVIEW_PATH2", "/highview/path2");
        saraMap.put("OTHER_PATH", "/other/path");
        
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMBASE", ""))
            .thenReturn("/root/path");
        when(imageParmDataService.getParmDataMap("CMSARA"))
            .thenReturn(saraMap);
        when(imageParmDataService.getParmDataByKeyByCmodbase("CMOD_PRODUCT_DTS_TRIAGE", ""))
            .thenReturn("");

        // Act
        CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, "");

        // Assert
        assertNotNull(response);
        CMODSARAPathInfo saraInfo = response.getSaraPathInfo();
        assertNotNull(saraInfo);
        assertEquals("/root/path", saraInfo.getRootPath());
        
        // Check that paths were properly separated
        assertTrue(saraInfo.getHighviewPaths().containsKey("HIGHVIEW_PATH1"));
        assertTrue(saraInfo.getHighviewPaths().containsKey("HIGHVIEW_PATH2"));
        assertTrue(saraInfo.getHighviewPaths().containsKey("OTHER_PATH")); // Non-reno goes to highview
        assertTrue(saraInfo.getRenoPaths().containsKey("RENO_PATH1"));
        assertEquals(3, saraInfo.getHighviewPaths().size());
        assertEquals(1, saraInfo.getRenoPaths().size());
    }
}