package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class PaginationTest {

    private Pagination pagination;

    @BeforeEach
    void setUp() {
        // Before each test, create a new Pagination object
        pagination = new Pagination();
    }

    @Test
    void testDefaultValues() {
        // Verify default values of Pagination object
        assertEquals(0, pagination.getPageNumber(), "Default pageNumber should be 0");
        assertEquals(10, pagination.getPageSize(), "Default pageSize should be 10");
        assertNull(pagination.getSort(), "Default sort should be null");
    }

    @Test
    void testSetAndGetPageNumber() {
        // Set a custom page number and verify it's correctly set
        pagination.setPageNumber(5);
        assertEquals(5, pagination.getPageNumber(), "Page number should be 5");
    }

    @Test
    void testSetAndGetPageSize() {
        // Set a custom page size and verify it's correctly set
        pagination.setPageSize(20);
        assertEquals(20, pagination.getPageSize(), "Page size should be 20");
    }

    @Test
    void testSetAndGetSort() {
        // Set a custom sort and verify it's correctly set
        pagination.setSort("asc");
        assertEquals("asc", pagination.getSort(), "Sort should be 'asc'");
    }

    @Test
    void testNullPageNumber() {
        // Set the pageNumber to null and verify default value (assuming pageNumber is Integer, not int)
        pagination.setPageNumber(null);
        assertNull(pagination.getPageNumber(), "Page number should be null");
    }

    @Test
    void testNullPageSize() {
        // Set the pageSize to null and verify default value (assuming pageSize is Integer, not int)
        pagination.setPageSize(null);
        assertNull(pagination.getPageSize(), "Page size should be null");
    }

    @Test
    void testNullSort() {
        // Set the sort to null and verify that it remains null
        pagination.setSort(null);
        assertNull(pagination.getSort(), "Sort should remain null");
    }

    @Test
    void testSetPageNumberWithinValidRange() {
        // Set a page number within a valid range and verify
        pagination.setPageNumber(3);
        assertEquals(3, pagination.getPageNumber(), "Page number should be set to 3");
    }

    @Test
    void testSetPageSizeWithinValidRange() {
        // Set a page size within a valid range and verify
        pagination.setPageSize(50);
        assertEquals(50, pagination.getPageSize(), "Page size should be set to 50");
    }

    // Optionally, you can add tests for invalid page number or size if needed
    @Test
    void testSetNegativePageNumber() {
        // Test for a negative page number
        pagination.setPageNumber(-1);
        assertEquals(-1, pagination.getPageNumber(), "Page number should allow negative values if needed");
    }

    @Test
    void testSetNegativePageSize() {
        // Test for a negative page size
        pagination.setPageSize(-10);
        assertEquals(-10, pagination.getPageSize(), "Page size should allow negative values if needed");
    }
}
