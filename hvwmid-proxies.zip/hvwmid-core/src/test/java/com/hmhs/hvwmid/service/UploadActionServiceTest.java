package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.Odscrt;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.OdscrtRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UploadActionServiceTest {

    private final String authToken = "mocked-token";
    @InjectMocks
    private UploadActionService uploadActionService;
    @Mock
    private T222APRMRepository t222aprmRepository;
    @Mock
    private OdscrtRepository odscrtRepository;
    @Mock
    private RestClientUtil restClientUtil;
    @Value("${api.access.url}")
    private String accessApiUrl = "http://mocked-access-api";

    @BeforeEach
    void setup() throws Exception {
        // reflection hack for setting @Value field
        Field field = UploadActionService.class.getDeclaredField("accessApiUrl");
        field.setAccessible(true);
        field.set(uploadActionService, accessApiUrl);
    }

    @Test
    void shouldReturnFalseWhenFolderNameIsNull() {
        boolean result = uploadActionService.shouldShowUploadAction(null, authToken);
        assertFalse(result);
    }

    @Test
    void shouldReturnFalseWhenNoParmRecordsFound() {
        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(Collections.emptyList());

        boolean result = uploadActionService.shouldShowUploadAction("folder", authToken);
        assertFalse(result);
    }

    @Test
    void shouldReturnFalseWhenNoOdscrtRecords() {
        T222APRM mockParm = new T222APRM();
        mockParm.setParmKey("123");
        mockParm.setParmData("folder");

        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(List.of(mockParm));
        when(odscrtRepository.findByForeignRid("123")).thenReturn(Collections.emptyList());

        boolean result = uploadActionService.shouldShowUploadAction("folder", authToken);
        assertFalse(result);
    }

    @Test
    void shouldReturnFalseWhenAccessApiFails() {
        T222APRM mockParm = new T222APRM();
        mockParm.setParmKey("123");
        mockParm.setParmData("folder");

        Odscrt mockOdscrt = new Odscrt();
        mockOdscrt.setAgName("GroupA");
        mockOdscrt.setAppName("AppA");
        mockOdscrt.setForeignRid("123");

        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(List.of(mockParm));
        when(odscrtRepository.findByForeignRid("123")).thenReturn(List.of(mockOdscrt));
        when(restClientUtil.postRequest(any(), any(), any())).thenThrow(new RuntimeException("API failed"));

        boolean result = uploadActionService.shouldShowUploadAction("folder", authToken);
        assertFalse(result);
    }

    @Test
    void shouldReturnTrueWhenAddAccessFound() {
        T222APRM mockParm = new T222APRM();
        mockParm.setParmKey("123");
        mockParm.setParmData("folder");

        Odscrt mockOdscrt = new Odscrt();
        mockOdscrt.setAgName("GroupA");
        mockOdscrt.setAppName("AppA");
        mockOdscrt.setForeignRid("123");

        Map<String, Object> group = new HashMap<>();
        group.put("groupName", "GroupA");
        group.put("accessLevel", "Read,Add,Delete");

        Map<String, Object> response = new HashMap<>();
        response.put("authorizedApplicationGroups", List.of(group));

        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(List.of(mockParm));
        when(odscrtRepository.findByForeignRid("123")).thenReturn(List.of(mockOdscrt));

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(response, HttpStatus.OK);
        when(restClientUtil.postRequest(any(), any(), any())).thenReturn(mockResponse);

        boolean result = uploadActionService.shouldShowUploadAction("folder", authToken);
        assertTrue(result);
    }

    @Test
    void getApplicationsForFolder_returnsMatchingRecords() {
        T222APRM mockParm = new T222APRM();
        mockParm.setParmKey("RID001");
        mockParm.setParmData("folder");

        Odscrt mockOdscrt = new Odscrt();
        mockOdscrt.setAgName("GroupX");
        mockOdscrt.setAppName("AppY");
        mockOdscrt.setForeignRid("RID001");

        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(List.of(mockParm));
        when(odscrtRepository.findByForeignRid("RID001")).thenReturn(List.of(mockOdscrt));

        List<Odscrt> result = uploadActionService.getApplicationsForFolder("folder");
        assertEquals(1, result.size());
        assertEquals("GroupX", result.get(0).getAgName());
    }

    @Test
    void shouldReturnFalseWhenNoAddAccessFound() {
        T222APRM mockParm = new T222APRM();
        mockParm.setParmKey("123");
        mockParm.setParmData("folder");

        Odscrt mockOdscrt = new Odscrt();
        mockOdscrt.setAgName("GroupA");
        mockOdscrt.setAppName("AppA");
        mockOdscrt.setForeignRid("123");

        Map<String, Object> group = new HashMap<>();
        group.put("groupName", "GroupA");
        group.put("accessLevel", "Read,Delete");

        Map<String, Object> response = new HashMap<>();
        response.put("authorizedApplicationGroups", List.of(group));

        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(List.of(mockParm));
        when(odscrtRepository.findByForeignRid("123")).thenReturn(List.of(mockOdscrt));

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(response, HttpStatus.OK);
        when(restClientUtil.postRequest(any(), any(), any())).thenReturn(mockResponse);

        boolean result = uploadActionService.shouldShowUploadAction("folder", authToken);
        assertFalse(result);
    }

    @Test
    void shouldReturnTrueWhenOneGroupHasAddAccessAmongMany() {
        T222APRM mockParm = new T222APRM();
        mockParm.setParmKey("123");
        mockParm.setParmData("folder");

        Odscrt mockOdscrt = new Odscrt();
        mockOdscrt.setAgName("GroupB");
        mockOdscrt.setAppName("AppB");
        mockOdscrt.setForeignRid("123");

        Map<String, Object> group1 = new HashMap<>();
        group1.put("groupName", "GroupX");
        group1.put("accessLevel", "Read");

        Map<String, Object> group2 = new HashMap<>();
        group2.put("groupName", "GroupB");
        group2.put("accessLevel", "Add");

        Map<String, Object> response = new HashMap<>();
        response.put("authorizedApplicationGroups", List.of(group1, group2));

        when(t222aprmRepository.findByParmIdAndParmData("folder")).thenReturn(List.of(mockParm));
        when(odscrtRepository.findByForeignRid("123")).thenReturn(List.of(mockOdscrt));

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(response, HttpStatus.OK);
        when(restClientUtil.postRequest(any(), any(), any())).thenReturn(mockResponse);

        boolean result = uploadActionService.shouldShowUploadAction("folder", authToken);
        assertTrue(result);
    }

    @Test
    void normalizeFolderNameShouldRemoveCMODAndUPLOADPrefixes() throws Exception {
        String folderName = "CMODUPLOADFolder123";

        // Access private method via reflection
        Method method = UploadActionService.class.getDeclaredMethod("normalizeFolderName", String.class);
        method.setAccessible(true);

        String normalized = (String) method.invoke(uploadActionService, folderName);

        assertEquals("Folder123", normalized);
    }

    @Test
    void getApplicationsForFolderReturnsEmptyWhenFolderNameIsNull() {
        List<Odscrt> result = uploadActionService.getApplicationsForFolder(null);
        assertTrue(result.isEmpty());
    }

}
