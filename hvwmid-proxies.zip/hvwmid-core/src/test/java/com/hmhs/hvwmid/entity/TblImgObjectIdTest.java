package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for TblImgObjectId composite key entity
 */
class TblImgObjectIdTest {

    private TblImgObjectId id1;
    private TblImgObjectId id2;

    @BeforeEach
    void setUp() {
        id1 = new TblImgObjectId();
        id2 = new TblImgObjectId();
    }

    @Test
    void testGetSetRequestId() {
        // Arrange
        Integer requestId = 12345;

        // Act
        id1.setRequestId(requestId);

        // Assert
        assertEquals(requestId, id1.getRequestId());
    }

    @Test
    void testGetSetSequenceNo() {
        // Arrange
        Integer sequenceNo = 1;

        // Act
        id1.setSequenceNo(sequenceNo);

        // Assert
        assertEquals(sequenceNo, id1.getSequenceNo());
    }

    @Test
    void testEqualsWithSameValues() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);
        
        id2.setRequestId(100);
        id2.setSequenceNo(1);

        // Act & Assert
        assertEquals(id1, id2);
        assertEquals(id2, id1);
    }

    @Test
    void testEqualsWithSameObject() {
        // Act & Assert
        assertEquals(id1, id1);
    }

    @Test
    void testEqualsWithDifferentRequestId() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);
        
        id2.setRequestId(200);
        id2.setSequenceNo(1);

        // Act & Assert
        assertNotEquals(id1, id2);
    }

    @Test
    void testEqualsWithDifferentSequenceNo() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);
        
        id2.setRequestId(100);
        id2.setSequenceNo(2);

        // Act & Assert
        assertNotEquals(id1, id2);
    }

    @Test
    void testEqualsWithNullObject() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);

        // Act & Assert
        assertNotEquals(id1, null);
    }

    @Test
    void testEqualsWithDifferentClass() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);
        String otherObject = "different class";

        // Act & Assert
        assertNotEquals(id1, otherObject);
    }

    @Test
    void testHashCodeConsistency() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);

        // Act
        int hash1 = id1.hashCode();
        int hash2 = id1.hashCode();

        // Assert
        assertEquals(hash1, hash2);
    }

    @Test
    void testHashCodeEqualObjects() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);
        
        id2.setRequestId(100);
        id2.setSequenceNo(1);

        // Act & Assert
        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testHashCodeDifferentObjects() {
        // Arrange
        id1.setRequestId(100);
        id1.setSequenceNo(1);
        
        id2.setRequestId(200);
        id2.setSequenceNo(2);

        // Act & Assert
        assertNotEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testHashCodeWithNullValues() {
        // This test verifies what happens with null values
        // Note: The current implementation will throw NPE with null values
        // which is expected behavior for composite keys
        
        assertThrows(NullPointerException.class, () -> {
            id1.setRequestId(null);
            id1.setSequenceNo(1);
            id1.hashCode();
        });
    }

    @Test
    void testEqualsWithNullRequestId() {
        // Test behavior with null values
        assertThrows(NullPointerException.class, () -> {
            id1.setRequestId(null);
            id1.setSequenceNo(1);
            
            id2.setRequestId(100);
            id2.setSequenceNo(1);
            
            id1.equals(id2);
        });
    }

    @Test
    void testSerializableImplementation() {
        // Arrange
        id1.setRequestId(123);
        id1.setSequenceNo(456);

        // Assert that the class implements Serializable
        assertTrue(id1 instanceof java.io.Serializable);
    }

    @Test
    void testValidCompositeKey() {
        // Arrange
        Integer requestId = 12345;
        Integer sequenceNo = 1;

        // Act
        id1.setRequestId(requestId);
        id1.setSequenceNo(sequenceNo);

        // Assert
        assertEquals(requestId, id1.getRequestId());
        assertEquals(sequenceNo, id1.getSequenceNo());
        assertNotNull(id1.hashCode());
    }

    @Test
    void testDefaultConstructor() {
        // Act
        TblImgObjectId newId = new TblImgObjectId();

        // Assert
        assertNull(newId.getRequestId());
        assertNull(newId.getSequenceNo());
    }
}