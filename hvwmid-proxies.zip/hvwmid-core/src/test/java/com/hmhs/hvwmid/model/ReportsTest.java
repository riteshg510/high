package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ReportsTest {

    private Reports reports;

    // Setup method to initialize Reports object before each test
    @BeforeEach
    void setUp() {
        reports = new Reports();
    }

    @Test
    void testGetAndSetId() {
        // Test set and get for 'id' field
        String testId = "report123";
        reports.setId(testId);
        assertEquals(testId, reports.getId(), "The id should match the set value");
    }

    @Test
    void testGetAndSetActionFolderName() {
        // Test set and get for 'actionFolderName' field
        String testActionFolderName = "Action Folder 1";
        reports.setActionFolderName(testActionFolderName);
        assertEquals(testActionFolderName, reports.getActionFolderName(), "The actionFolderName should match the set value");
    }

    @Test
    void testGetAndSetActionFolderDescription() {
        // Test set and get for 'actionFolderDescription' field
        String testActionFolderDescription = "Description of the action folder";
        reports.setActionFolderDescription(testActionFolderDescription);
        assertEquals(testActionFolderDescription, reports.getActionFolderDescription(), "The actionFolderDescription should match the set value");
    }

    @Test
    void testGetAndSetCmodAction() {
        // Test set and get for 'cmodAction' field
        String testCmodAction = "CMOD action 1";
        reports.setCmodAction(testCmodAction);
        assertEquals(testCmodAction, reports.getCmodAction(), "The cmodAction should match the set value");
    }

    @Test
    void testGetAndSetCmodFolderName() {
        // Test set and get for 'cmodFolderName' field
        String testCmodFolderName = "CMOD Folder 1";
        reports.setCmodFolderName(testCmodFolderName);
        assertEquals(testCmodFolderName, reports.getCmodFolderName(), "The cmodFolderName should match the set value");
    }

    @Test
    void testGetAndSetCmodFolderDescription() {
        // Test set and get for 'cmodFolderDescription' field
        String testCmodFolderDescription = "Description of the CMOD folder";
        reports.setCmodFolderDescription(testCmodFolderDescription);
        assertEquals(testCmodFolderDescription, reports.getCmodFolderDescription(), "The cmodFolderDescription should match the set value");
    }

    @Test
    void testDefaultValues() {
        // Verify default values for the class fields
        assertNull(reports.getId(), "The default id should be null");
        assertNull(reports.getActionFolderName(), "The default actionFolderName should be null");
        assertNull(reports.getActionFolderDescription(), "The default actionFolderDescription should be null");
        assertNull(reports.getCmodAction(), "The default cmodAction should be null");
        assertNull(reports.getCmodFolderName(), "The default cmodFolderName should be null");
        assertNull(reports.getCmodFolderDescription(), "The default cmodFolderDescription should be null");
        assertNull(reports.getActions(), "The default actions list should be null");
    }
}
