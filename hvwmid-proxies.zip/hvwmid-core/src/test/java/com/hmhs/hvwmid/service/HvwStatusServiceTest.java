package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblHvwStatus;
import com.hmhs.hvwmid.entity.TblHvwStatusId;
import com.hmhs.hvwmid.repository.TblHvwStatusRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class HvwStatusServiceTest {

    @InjectMocks
    private HvwStatusService hvwStatusService;

    @Mock
    private TblHvwStatusRepository hvwStatusRepository;

    private TblHvwStatus hvwStatus;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Setup sample data for the tests
        hvwStatus = new TblHvwStatus();
        hvwStatus.setId(new TblHvwStatusId(1, new Timestamp(Calendar.getInstance().getTimeInMillis())));
        hvwStatus.setImgRequestId(2);
        hvwStatus.setCodRequestId(3);
        hvwStatus.setUserId("user123");
        hvwStatus.setFunction("testFunction");
        hvwStatus.setOriginalUrl("http://example.com");
        hvwStatus.setStatusCode("200");
        hvwStatus.setStatusDescription("Successful Request");
    }

    @Test
    void testPopulateT222HvwStatus_Success() {
        // Arrange: Setup mock behavior
        when(hvwStatusRepository.save(any(TblHvwStatus.class))).thenReturn(hvwStatus);

        // Act: Call the method we want to test
        TblHvwStatus result = hvwStatusService.populateT222HvwStatus(
                1, 2, 3, "user123", "testFunction", "http://example.com", "200", "Successful Request"
        );

        // Assert: Verify the result
        assertNotNull(result);
        assertEquals(1, result.getRequestId());
        assertEquals("user123", result.getUserId());
        assertEquals("200", result.getStatusCode());
        assertEquals("Successful Request", result.getStatusDescription());
        verify(hvwStatusRepository, times(1)).save(any(TblHvwStatus.class));  // Ensure the repository save method was called
    }

}
