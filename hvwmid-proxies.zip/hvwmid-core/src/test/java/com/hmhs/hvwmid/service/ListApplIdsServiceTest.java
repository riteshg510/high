package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
class ListApplIdsServiceTest {
    @InjectMocks
    private ListApplIdsService listApplIdsService;

    @Mock
    private RestClientUtil restClientUtil;

    private static final String BPDID_FIELD = "bpdid";

    @Test
    void testFilterReturnsExpectedResult() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> imageApplidListing = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> applicationList = new ArrayList<>();

    Map<String, Object> appl1 = new HashMap<>();
    appl1.put("applidcd", "A1");
    appl1.put("description", "S1");
    applicationList.add(appl1);

        results.put("application", applicationList);
        imageApplidListing.put("results", results);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(imageApplidListing, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listApplIdsService.filter(otherFields, "token");

        List<Map> expected = new ArrayList<>();
    Map<String, String> expectedEntry = new HashMap<>();
    expectedEntry.put("key", "A1");
    expectedEntry.put("displayName", "S1 (A1)");
    expected.add(expectedEntry);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
    }

    @Test
    void testFilterWithEmptyResponse() {
        Map<String, String> otherFields = new HashMap<>();
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listApplIdsService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }

    @Test
    void testFilterDoesNotHaveAllProperties() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> responseMap = new HashMap<>();
        Map<String, Object> imageApplidListing = new HashMap<>();
        Map<String, Object> segmentData = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> applicationList = new ArrayList<>();

        Map<String, Object> appl1 = new HashMap<>();
    appl1.put("aescription", "S1"); // typo to keep test negative
        applicationList.add(appl1);

        results.put("application", applicationList);
        segmentData.put("results", results);
        imageApplidListing.put("segmentData", segmentData);
        responseMap.put("imageApplidListing", imageApplidListing);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseMap, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        //no Applidcd
        ResponseEntity<Object> result = listApplIdsService.filter(otherFields, "token");

        List<Map> expected = new ArrayList<>();

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

    //No Description
    applicationList.clear();
    appl1.clear();
    appl1.put("applidcd", "A1");
    applicationList.add(appl1);
    result = listApplIdsService.filter(otherFields, "token");
    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertEquals(expected, result.getBody());

        //No Application
        results.clear();
        result = listApplIdsService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No Results
        segmentData.clear();
        result = listApplIdsService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No SegmentData
        imageApplidListing.clear();
        result = listApplIdsService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No ImageApplidListing
        responseMap.clear();
        result = listApplIdsService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

    }

    @Test
    void testFilterGenerateDifferentExtraHeaders() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put(BPDID_FIELD, "   "); // blank value
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listApplIdsService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());

        otherFields.put(BPDID_FIELD, "abc"); // not blank value
        result = listApplIdsService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }
}