package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CMODDownloadServiceTest {

    private static final Logger logger = LogManager.getLogger(CMODDownloadService.class);
    private static final String DOCUMENT_TOKEN = "dummyDocumentToken";
    private static final String OD_FOLDER = "dummyFolder";
    private static final String AUTH_TOKEN = "dummyAuthToken";
    private static final String DOWNLOAD_URL = "http://fake-download-url";
    @InjectMocks
    private CMODDownloadService service;
    @Mock
    private RestClientUtil restClientUtil;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        // Set the mock for the restClientUtil field
        Field restClientUtilField = CMODDownloadService.class.getDeclaredField("restClientUtil");
        restClientUtilField.setAccessible(true);
        restClientUtilField.set(service, restClientUtil);

        // Set the downloadUrl field in CMODDocumentService (since it's inherited)
        Field downloadUrlField = CMODDocumentService.class.getDeclaredField("downloadUrl");
        downloadUrlField.setAccessible(true);
        downloadUrlField.set(service, DOWNLOAD_URL);
    }

    @Test
    void testDownloadDocument_Success() {
        // Prepare mock response
        ByteArrayResource byteArrayResource = new ByteArrayResource("Mocked document content".getBytes());
        ResponseEntity<ByteArrayResource> mockResponse = ResponseEntity.ok(byteArrayResource);

        // Mock RestClientUtil behavior
        when(restClientUtil.postRequestForBinary(eq(DOWNLOAD_URL), eq(AUTH_TOKEN), any(Map.class)))
                .thenReturn(mockResponse);

        // Act
        ResponseEntity<ByteArrayResource> response = service.downloadDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);

        // Assert
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Mocked document content", new String(response.getBody().getByteArray()));

        // Verify that the mock method was called
        verify(restClientUtil, times(1))
                .postRequestForBinary(eq(DOWNLOAD_URL), eq(AUTH_TOKEN), any(Map.class));
    }

    @Test
    void testDownloadDocument_Failure_BadRequest() {
        // Prepare mock response for a bad request (4xx response)
        ResponseEntity<ByteArrayResource> mockResponse = ResponseEntity.badRequest().build();

        // Mock RestClientUtil behavior
        when(restClientUtil.postRequestForBinary(eq(DOWNLOAD_URL), eq(AUTH_TOKEN), any(Map.class)))
                .thenReturn(mockResponse);

        // Act
        ResponseEntity<ByteArrayResource> response = service.downloadDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);

        // Assert
        assertNotNull(response);
        assertEquals(400, response.getStatusCodeValue()); // Bad Request

        // Verify that the mock method was called
        verify(restClientUtil, times(1))
                .postRequestForBinary(eq(DOWNLOAD_URL), eq(AUTH_TOKEN), any(Map.class));
    }

    @Test
    void testGetDocumentRequestId_Success() {
        // Mock response map with REQUEST_ID
        Map<String, Integer> responseBody = Map.of("REQUEST_ID", 123);
        ResponseEntity<Map> mockResponse = ResponseEntity.ok(responseBody);

        when(restClientUtil.postRequest(eq(service.getRequestIdUrl), eq(AUTH_TOKEN), any(Map.class)))
                .thenReturn(mockResponse);

        Map<String, Integer> result = service.getDocumentRequestId(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN, "someTranslateType");

        assertNotNull(result);
        assertEquals(123, result.get("REQUEST_ID"));

        verify(restClientUtil, times(1))
                .postRequest(eq(service.getRequestIdUrl), eq(AUTH_TOKEN), any(Map.class));
    }

    @Test
    void testGetDocumentRequestId_Failure_NonOkStatus() {
        ResponseEntity<Map> mockResponse = ResponseEntity.status(500).build();

        when(restClientUtil.postRequest(eq(service.getRequestIdUrl), eq(AUTH_TOKEN), any(Map.class)))
                .thenReturn(mockResponse);

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                service.getDocumentRequestId(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN, null)
        );

        assertTrue(ex.getMessage().contains("Failed to get request ID"));
    }

    @Test
    void testGetDocumentRequestId_Failure_MissingRequestIdInBody() {
        Map<String, Integer> responseBody = Map.of("OTHER_KEY", 999);
        ResponseEntity<Map> mockResponse = ResponseEntity.ok(responseBody);

        when(restClientUtil.postRequest(eq(service.getRequestIdUrl), eq(AUTH_TOKEN), any(Map.class)))
                .thenReturn(mockResponse);

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                service.getDocumentRequestId(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN, "")
        );

        assertEquals("Request ID not found in the response", ex.getMessage());
    }

    @Test
    void testGetDocumentRequestId_TranslateTypeNullOrEmpty() {
        Map<String, Integer> responseBody = Map.of("REQUEST_ID", 456);
        ResponseEntity<Map> mockResponse = ResponseEntity.ok(responseBody);

        when(restClientUtil.postRequest(eq(service.getRequestIdUrl), eq(AUTH_TOKEN), any(Map.class)))
                .thenReturn(mockResponse);

        Map<String, Integer> resultNull = service.getDocumentRequestId(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN, null);
        assertNotNull(resultNull);
        assertEquals(456, resultNull.get("REQUEST_ID"));

        Map<String, Integer> resultEmpty = service.getDocumentRequestId(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN, "");
        assertNotNull(resultEmpty);
        assertEquals(456, resultEmpty.get("REQUEST_ID"));

        verify(restClientUtil, times(2))
                .postRequest(eq(service.getRequestIdUrl), eq(AUTH_TOKEN), any(Map.class));
    }


}
