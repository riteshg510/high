package com.hmhs.hvwmid.exceptions;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static com.hmhs.hvwmid.exceptions.HVWException.checkServiceMessage;
import static com.hmhs.hvwmid.exceptions.HVWException.extractNestedServiceMessage;
import static com.hmhs.hvwmid.exceptions.HVWException.parseJsonString;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class HVWExceptionTest {

    private static final int DEFAULT_CODE = 400;
    private static final String SERVICE = "test-service";
    private final ObjectMapper objectMapper = new ObjectMapper(); // Mock this if needed

    @Test
    void testConstructorWithReturnCodeAndDescription() {
        int returnCode = 404;
        String description = "Not Found";
        HVWException exception = new HVWException(returnCode, description);

        assertEquals(returnCode, exception.getReturnCode(), "Return code should be correctly set.");
        assertEquals(description, exception.getReturnCodeDescription(), "Description should be correctly set.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(description, exception.getMessage(), "Message should be the same as the description.");
    }

    @Test
    void testConstructorWithReturnCodeDescriptionAndService() {
        int returnCode = 400;
        String description = "Bad Request";
        String service = "MyService";
        HVWException exception = new HVWException(returnCode, description, service);

        assertEquals(returnCode, exception.getReturnCode(), "Return code should be correctly set.");
        assertEquals(description, exception.getReturnCodeDescription(), "Description should be correctly set.");
        assertEquals(service, exception.getService(), "Service should be correctly set.");
        assertEquals(description, exception.getMessage(), "Message should be the same as the description.");
    }

    @Test
    void testConstructorWithMessage() {
        String message = "Something went wrong";
        HVWException exception = new HVWException(message);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(message, exception.getReturnCodeDescription(), "Description should be the same as the message.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(message, exception.getMessage(), "Message should be the same as the message.");
    }

    @Test
    void testConstructorWithMessageAndService() {
        String message = "Service error";
        String service = "SomeService";
        HVWException exception = new HVWException(message, service);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(message, exception.getReturnCodeDescription(), "Description should be the same as the message.");
        assertEquals(service, exception.getService(), "Service should be correctly set.");
        assertEquals(message, exception.getMessage(), "Message should be the same as the message.");
    }

    @Test
    void testConstructorWithCause() {
        Throwable cause = new RuntimeException("Runtime exception occurred");
        HVWException exception = new HVWException(cause);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(cause.getMessage(), exception.getReturnCodeDescription(), "Description should be the same as the cause's message.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(cause.getMessage(), exception.getMessage(), "Message should be the same as the cause's message.");
        assertEquals(cause, exception.getCause(), "Cause should be the same as the provided cause.");
    }

    @Test
    void testConstructorWithReturnCodeAndDescription2() {
        int returnCode = 404;
        String description = "Not Found";
        HVWException exception = new HVWException(returnCode, description);

        assertEquals(returnCode, exception.getReturnCode(), "Return code should be correctly set.");
        assertEquals(description, exception.getReturnCodeDescription(), "Description should be correctly set.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(description, exception.getMessage(), "Message should be the same as the description.");
    }

    @Test
    void testConstructorWithReturnCodeDescriptionAndService2() {
        int returnCode = 400;
        String description = "Bad Request";
        String service = "MyService";
        HVWException exception = new HVWException(returnCode, description, service);

        assertEquals(returnCode, exception.getReturnCode(), "Return code should be correctly set.");
        assertEquals(description, exception.getReturnCodeDescription(), "Description should be correctly set.");
        assertEquals(service, exception.getService(), "Service should be correctly set.");
        assertEquals(description, exception.getMessage(), "Message should be the same as the description.");
    }

    @Test
    void testConstructorWithMessage1() {
        String message = "Something went wrong";
        HVWException exception = new HVWException(message);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(message, exception.getReturnCodeDescription(), "Description should be the same as the message.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(message, exception.getMessage(), "Message should be the same as the message.");
    }

    @Test
    void testConstructorWithMessageAndService1() {
        String message = "Service error";
        String service = "SomeService";
        HVWException exception = new HVWException(message, service);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(message, exception.getReturnCodeDescription(), "Description should be the same as the message.");
        assertEquals(service, exception.getService(), "Service should be correctly set.");
        assertEquals(message, exception.getMessage(), "Message should be the same as the message.");
    }

    @Test
    void testConstructorWithCause2() {
        Throwable cause = new RuntimeException("Runtime exception occurred");
        HVWException exception = new HVWException(cause);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(cause.getMessage(), exception.getReturnCodeDescription(), "Description should be the same as the cause's message.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(cause.getMessage(), exception.getMessage(), "Message should be the same as the cause's message.");
        assertEquals(cause, exception.getCause(), "Cause should be the same as the provided cause.");
    }

    @Test
    void testConstructorWithMessageAndCause() {
        String message = "Error occurred";
        Throwable cause = new RuntimeException("Cause of error");
        HVWException exception = new HVWException(message, cause);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(message, exception.getReturnCodeDescription(), "Description should be the same as the message.");
        assertEquals("unknown", exception.getService(), "Service should default to 'unknown'.");
        assertEquals(message, exception.getMessage(), "Message should be the same as the message.");
        assertEquals(cause, exception.getCause(), "Cause should be the same as the provided cause.");
    }

    @Test
    void testConstructorWithMessageCauseAndService() {
        String message = "Service error occurred";
        Throwable cause = new RuntimeException("Cause of service error");
        String service = "MyService";
        HVWException exception = new HVWException(message, cause, service);

        assertEquals(503, exception.getReturnCode(), "Default return code should be 503.");
        assertEquals(message, exception.getReturnCodeDescription(), "Description should be the same as the message.");
        assertEquals(service, exception.getService(), "Service should be correctly set.");
        assertEquals(message, exception.getMessage(), "Message should be the same as the message.");
        assertEquals(cause, exception.getCause(), "Cause should be the same as the provided cause.");
    }

    @Test
    void testGetReturnCode() {
        int returnCode = 403;
        String description = "Forbidden";
        HVWException exception = new HVWException(returnCode, description);

        assertEquals(returnCode, exception.getReturnCode(), "Return code should be correctly returned.");
    }

    @Test
    void testGetReturnCodeDescription() {
        String description = "Service unavailable";
        HVWException exception = new HVWException(503, description);

        assertEquals(description, exception.getReturnCodeDescription(), "Return code description should be correctly returned.");
    }

    @Test
    void testGetService() {
        String service = "UserService";
        HVWException exception = new HVWException(503, "SERVICE_UNAVAILABLE", service);

        assertEquals(service, exception.getService(), "Service should be correctly returned.");
    }

    @Test
    void testCreateErrorResponse() {
        int returnCode = 404;
        String description = "Not Found";
        String service = "MyService";

        HVWException exception = new HVWException(returnCode, description, service);
        Map<String, Object> errorResponse = exception.createErrorResponse();

        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(service, serviceMessage.get("service"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseEntity() {
        int returnCode = 503;
        String description = "SERVICE_UNAVAILABLE";
        String service = "MyService";

        HVWException exception = new HVWException(returnCode, description, service);
        ResponseEntity<Object> errorResponseEntity = exception.createErrorResponseEntity();

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, errorResponseEntity.getStatusCode());
        Map<String, Object> errorResponse = (Map<String, Object>) errorResponseEntity.getBody();
        assertNotNull(errorResponse);
        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(service, serviceMessage.get("service"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseWithHVWException() {
        int returnCode = 403;
        String description = "Forbidden";
        String service = "MyService";
        HVWException exception = new HVWException(returnCode, description, service);

        Map<String, Object> errorResponse = HVWException.createErrorResponse(exception);

        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(service, serviceMessage.get("service"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseWithGenericException() {
        Exception exception = new Exception("Generic exception message");

        Map<String, Object> errorResponse = HVWException.createErrorResponse(exception);

        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(503, serviceMessage.get("returnCode"));
        assertEquals("Generic exception message", serviceMessage.get("returnCodeDescription"));
        assertEquals("Generic exception message", errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseMapWithReturnCodeAndDescription() {
        int returnCode = 401;
        String description = "Unauthorized";

        Map<String, Object> errorResponse = HVWException.createErrorResponseMap(returnCode, description);

        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseMapWithReturnCodeDescriptionAndService() {
        int returnCode = 503;
        String description = "SERVICE_UNAVAILABLE";
        String service = "MyService";

        Map<String, Object> errorResponse = HVWException.createErrorResponseMap(returnCode, description, service);

        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(service, serviceMessage.get("service"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseMapWithUnknownService() {
        int returnCode = 503;
        String description = "Server Error";
        String service = "unknown";

        Map<String, Object> errorResponse = HVWException.createErrorResponseMap(returnCode, description, service);

        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertFalse(serviceMessage.containsKey("service"));  // Should not contain the service key if it's "unknown"
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseEntityWithReturnCodeAndDescription() {
        int returnCode = 404;
        String description = "Not Found";

        ResponseEntity<Object> errorResponseEntity = HVWException.createErrorResponseEntity(returnCode, description);

        assertEquals(HttpStatus.NOT_FOUND, errorResponseEntity.getStatusCode());
        Map<String, Object> errorResponse = (Map<String, Object>) errorResponseEntity.getBody();
        assertNotNull(errorResponse);
        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseEntityWithService() {
        int returnCode = 403;
        String description = "Forbidden";
        String service = "MyService";

        ResponseEntity<Object> errorResponseEntity = HVWException.createErrorResponseEntity(returnCode, description, service);

        assertEquals(HttpStatus.FORBIDDEN, errorResponseEntity.getStatusCode());
        Map<String, Object> errorResponse = (Map<String, Object>) errorResponseEntity.getBody();
        assertNotNull(errorResponse);
        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(service, serviceMessage.get("service"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testCreateErrorResponseEntityFromHVWException() {
        int returnCode = 503;
        String description = "SERVICE_UNAVAILABLE";
        String service = "MyService";

        HVWException exception = new HVWException(returnCode, description, service);
        ResponseEntity<Object> errorResponseEntity = exception.createErrorResponseEntity();

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, errorResponseEntity.getStatusCode());
        Map<String, Object> errorResponse = (Map<String, Object>) errorResponseEntity.getBody();
        assertNotNull(errorResponse);
        assertEquals("error", errorResponse.get("status"));
        Map<String, Object> serviceMessage = (Map<String, Object>) errorResponse.get("serviceMessage");
        assertEquals(returnCode, serviceMessage.get("returnCode"));
        assertEquals(description, serviceMessage.get("returnCodeDescription"));
        assertEquals(service, serviceMessage.get("service"));
        assertEquals(description, errorResponse.get("message"));
    }

    @Test
    void testParseErrorResponseWithHVWException() {
        int returnCode = 401;
        String description = "Unauthorized";
        String service = "MyService";
        HVWException exception = new HVWException(returnCode, description, service);
        ResponseEntity<Map> responseEntity = new ResponseEntity<>(Map.of("serviceMessage", Map.of(
                "returnCode", returnCode,
                "returnCodeDescription", description
        )), HttpStatus.UNAUTHORIZED);

        HVWException parsedException = HVWException.parseErrorResponse(responseEntity, service);

        assertNotNull(parsedException);
        assertEquals(returnCode, parsedException.getReturnCode());
        assertEquals(description, parsedException.getReturnCodeDescription());
        assertEquals(service, parsedException.getService());
    }

    @Test
    void testParseErrorResponseWithGenericException() {
        ResponseEntity<Map> responseEntity = new ResponseEntity<>(Map.of(
                "serviceMessage", Map.of(
                        "returnCode", 503,
                        "returnCodeDescription", "SERVICE_UNAVAILABLE"
                )
        ), HttpStatus.SERVICE_UNAVAILABLE);

        HVWException parsedException = HVWException.parseErrorResponse(responseEntity, "MyService");

        assertNotNull(parsedException);
        assertEquals(503, parsedException.getReturnCode());
        assertEquals("SERVICE_UNAVAILABLE", parsedException.getReturnCodeDescription());
        assertEquals("MyService", parsedException.getService());
    }

    @Test
    void testParseErrorResponseFromResponseEntity() {
        ResponseEntity<Map> responseEntity = new ResponseEntity<>(Map.of(
                "serviceMessage", Map.of(
                        "returnCode", 404,
                        "returnCodeDescription", "Not Found"
                )
        ), HttpStatus.NOT_FOUND);

        HVWException parsedException = HVWException.parseErrorResponse(responseEntity);

        assertNotNull(parsedException);
        assertEquals(404, parsedException.getReturnCode());
        assertEquals("Not Found", parsedException.getReturnCodeDescription());
        assertEquals("unknown", parsedException.getService());
    }

    @Test
    void testParseGenericErrorResponse() {
        ResponseEntity<?> responseEntity = new ResponseEntity<>(Map.of(
                "serviceMessage", Map.of(
                        "returnCode", 403,
                        "returnCodeDescription", "Forbidden"
                )
        ), HttpStatus.FORBIDDEN);

        HVWException parsedException = HVWException.parseGenericErrorResponse(responseEntity, "MyService");

        assertNotNull(parsedException);
        assertEquals(403, parsedException.getReturnCode());
        assertEquals("Forbidden", parsedException.getReturnCodeDescription());
        assertEquals("MyService", parsedException.getService());
    }

    @Test
    void testExtractNestedErrorMessage_ValidJson() {
        String errorMessage = "Error occurred: {\"serviceMessage\":{\"returnCode\":400,\"returnCodeDescription\":\"Bad Request\"}}";
        String extractedMessage = HVWException.extractNestedErrorMessage(errorMessage);

        // Validate that the correct message is extracted from the nested JSON
        assertEquals("Bad Request", extractedMessage);
    }

    @Test
    void testExtractNestedErrorMessage_InvalidJson() {
        String errorMessage = "An error occurred!";
        String extractedMessage = HVWException.extractNestedErrorMessage(errorMessage);

        // Validate that when there is no JSON, the original error message is returned
        assertEquals("An error occurred!", extractedMessage);
    }

    @Test
    void testExtractNestedErrorMessage_MalformedJson() {
        // A malformed JSON string that would fail to parse
        String errorMessage = "Malformed message: {\"serviceMessage\":\"{\\returnCode\\\": 400}\"}";
        String extractedMessage = HVWException.extractNestedErrorMessage(errorMessage);

        // Validate that it still returns a clean message if JSON parsing fails
        assertTrue(extractedMessage.contains("Malformed message"));
    }

    @Test
    void testExtractNestedErrorMessage_EmptyString() {
        String errorMessage = "";
        String extractedMessage = HVWException.extractNestedErrorMessage(errorMessage);

        // Validate that an empty string is returned as is
        assertEquals("", extractedMessage);
    }

    @Test
    void testExtractNestedErrorMessage_NullMessage() {
        String errorMessage = null;
        String extractedMessage = HVWException.extractNestedErrorMessage(errorMessage);

        // Validate that a null string is handled properly and returns null
        assertNull(extractedMessage);
    }

    @Test
    void testParseErrorResponse_ValidServiceMessage() {
        // Prepare response entity with a valid serviceMessage
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 400);
        serviceMessage.put("returnCodeDescription", "Bad Request");

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("serviceMessage", serviceMessage);

        ResponseEntity<Map> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(400);
        when(response.getBody()).thenReturn(responseBody);

        // Call parseErrorResponse and check the exception thrown
        HVWException exception = HVWException.parseErrorResponse(response, "SomeService");

        assertEquals(400, exception.getReturnCode());
        assertEquals("Bad Request", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseErrorResponse_NestedErrorInString() {
        // Prepare a response entity where the serviceMessage is a string containing nested JSON
        String nestedErrorMessage = "{\"serviceMessage\":\"{\\\"returnCode\\\": 503, \\\"returnCodeDescription\\\": \\\"SERVICE_UNAVAILABLE\\\"}\"}";

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("error", nestedErrorMessage);  // Simulating a nested structure

        ResponseEntity<Map> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(503);
        when(response.getBody()).thenReturn(responseBody);

        // Call parseErrorResponse and check the exception thrown
        HVWException exception = HVWException.parseErrorResponse(response, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseErrorResponse_DeeplyNestedServiceMessage() {
        // Prepare a response entity with deeply nested serviceMessage in a map
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 503);
        serviceMessage.put("returnCodeDescription", "SERVICE_UNAVAILABLE");

        Map<String, Object> nestedMap = new HashMap<>();
        nestedMap.put("serviceMessage", serviceMessage);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("nested", nestedMap);

        ResponseEntity<Map> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(503);
        when(response.getBody()).thenReturn(responseBody);

        // Call parseErrorResponse and check the exception thrown
        HVWException exception = HVWException.parseErrorResponse(response, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("SERVICE_UNAVAILABLE", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseErrorResponse_OAuthError() {
        // Prepare response for OAuth error (returnCode 30)
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 30); // OAuth error code
        serviceMessage.put("returnCodeDescription", "OAuth token expired");

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("serviceMessage", serviceMessage);

        ResponseEntity<Map> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(401);
        when(response.getBody()).thenReturn(responseBody);

        // Call parseErrorResponse and check the exception thrown
        HVWException exception = HVWException.parseErrorResponse(response, "SomeService");

        assertEquals(401, exception.getReturnCode());
        assertEquals("Authentication token expired. Please log in again.", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseGenericErrorResponse_MapResponseBody() {
        // Simulate the scenario where the response body is a Map
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 400);
        serviceMessage.put("returnCodeDescription", "Bad Request");

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("serviceMessage", serviceMessage);

        ResponseEntity<Map> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(400);
        when(response.getBody()).thenReturn(responseBody);

        HVWException exception = HVWException.parseGenericErrorResponse(response, "SomeService");

        assertEquals(400, exception.getReturnCode());
        assertEquals("Bad Request", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseGenericErrorResponse_StringContainingServiceMessage() {
        // Test when the body is a string containing a serviceMessage (nested)
        String jsonErrorMessage = "{\"serviceMessage\": {\"returnCode\": 503, \"returnCodeDescription\": \"SERVICE_UNAVAILABLE\"}}";

        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(503);
        when(response.getBody()).thenReturn(jsonErrorMessage);

        HVWException exception = HVWException.parseGenericErrorResponse(response, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("SERVICE_UNAVAILABLE", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseGenericErrorResponse_InvalidJson() {
        // Test when the response contains an invalid JSON
        String invalidJson = "Invalid JSON string";

        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(503);
        when(response.getBody()).thenReturn(invalidJson);

        HVWException exception = HVWException.parseGenericErrorResponse(response, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseGenericErrorResponse_EmptyResponseBody() {
        // Test when the response body is empty (null)
        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(400);
        when(response.getBody()).thenReturn(null);

        HVWException exception = HVWException.parseGenericErrorResponse(response, "SomeService");

        assertEquals(400, exception.getReturnCode());
        assertEquals("Invalid request to service: SomeService", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseGenericErrorResponse_ExtractNestedServiceMessage() {
        // Test for a deeply nested error message
        Map<String, Object> innerServiceMessage = new HashMap<>();
        innerServiceMessage.put("returnCode", 503);
        innerServiceMessage.put("returnCodeDescription", "Deeply nested error");

        Map<String, Object> outerServiceMessage = new HashMap<>();
        outerServiceMessage.put("serviceMessage", innerServiceMessage);

        ResponseEntity<Map> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(503);
        when(response.getBody()).thenReturn(outerServiceMessage);

        HVWException exception = HVWException.parseGenericErrorResponse(response, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("Deeply nested error", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseGenericErrorResponse_DefaultErrorMessage() {
        // Test for a response body that does not contain a service message or other recognized structure
        String unknownErrorBody = "Unknown error body";

        ResponseEntity<String> response = mock(ResponseEntity.class);
        when(response.getStatusCodeValue()).thenReturn(502);
        when(response.getBody()).thenReturn(unknownErrorBody);

        HVWException exception = HVWException.parseGenericErrorResponse(response, "SomeService");

        assertEquals(502, exception.getReturnCode());
        assertEquals("\"Unknown error body\"", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testCreateStatusBasedError_400() {
        // Test the status code-based error message for HTTP 400
        HVWException exception = HVWException.createStatusBasedError(400, "Custom error", "SomeService");

        assertEquals(400, exception.getReturnCode());
        assertEquals("Invalid request to service: SomeService", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testCreateStatusBasedError_503() {
        // Test the status code-based error message for HTTP 503
        HVWException exception = HVWException.createStatusBasedError(503, "Custom error", "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("Service temporarily unavailable: SomeService", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseJsonString_InvalidJson() {
        // Test parsing an invalid JSON string
        String invalidJson = "This is not a valid JSON";

        HVWException exception = parseJsonString(invalidJson, 503, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseJsonString_ValidJsonWithServiceMessage() {
        // Test parsing a valid JSON string containing a service message
        String validJson = "{\"serviceMessage\": {\"returnCode\": 404, \"returnCodeDescription\": \"Not Found\"}}";

        HVWException exception = parseJsonString(validJson, 503, "SomeService");

        assertEquals(404, exception.getReturnCode());
        assertEquals("Not Found", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testParseJsonString_RegexErrorExtraction() {
        // Test extracting error details from JSON string using regex
        String jsonString = "{\"error\": \"Bad Request\", \"returnCode\": 400, \"returnCodeDescription\": \"Invalid input\"}";

        HVWException exception = parseJsonString(jsonString, 503, "SomeService");

        assertEquals(503, exception.getReturnCode());
        assertEquals("Service request failed with status: 503", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testMapResponse() {
        // Case 1: Map response body
        ResponseEntity<Map<String, Object>> response = new ResponseEntity<>(Map.of("key", "value"), HttpStatus.BAD_REQUEST);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("Invalid request to service: service", exception.getMessage());
        assertEquals(400, exception.getReturnCode());
    }

    @Test
    void testValidJsonWithServiceMessage() {
        // Case 2: Valid JSON with serviceMessage
        String json = "{ \"serviceMessage\": { \"returnCode\": 503, \"returnCodeDescription\": \"Service Unavailable\" } }";
        ResponseEntity<String> response = new ResponseEntity<>(json, HttpStatus.SERVICE_UNAVAILABLE);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("Service Unavailable", exception.getMessage());
        assertEquals(503, exception.getReturnCode());
    }

    @Test
    void testInvalidJson() {
        // Case 3: Invalid JSON structure
        String invalidJson = "{ serviceMessage: }"; // Malformed JSON
        ResponseEntity<String> response = new ResponseEntity<>(invalidJson, HttpStatus.BAD_REQUEST);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertTrue(exception.getMessage().contains("\"{ serviceMessage: }\""));
        assertEquals(400, exception.getReturnCode());
    }

    @Test
    void testNoServiceMessageInJson() {
        // Case 4: No serviceMessage, valid JSON body
        String json = "{ \"message\": \"Something went wrong\" }";
        ResponseEntity<String> response = new ResponseEntity<>(json, HttpStatus.BAD_REQUEST);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("\"{ \\\"message\\\": \\\"Something went wrong\\\" }\"", exception.getMessage());
        assertEquals(400, exception.getReturnCode());
    }

    @Test
    void testBodyIsNull() {
        // Case 5: Body is null
        ResponseEntity<String> response = new ResponseEntity<>(null, HttpStatus.SERVICE_UNAVAILABLE);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("Service temporarily unavailable: service", exception.getMessage());
        assertEquals(503, exception.getReturnCode());
    }

    @Test
    void testNonJsonBody() {
        // Case 6: Non-JSON body
        ResponseEntity<String> response = new ResponseEntity<>("Plain text error message", HttpStatus.BAD_REQUEST);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("\"Plain text error message\"", exception.getMessage());
        assertEquals(400, exception.getReturnCode());
    }

    @Test
    void testServiceUnavailable() {
        // Case 7: Service temporarily unavailable
        ResponseEntity<String> response = new ResponseEntity<>("Service unavailable", HttpStatus.SERVICE_UNAVAILABLE);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("\"Service unavailable\"", exception.getMessage());
        assertEquals(503, exception.getReturnCode());
    }

    @Test
    void testStatusCodeWithSpecificMessage() {
        // Case 8: Specific status code 401, message customization
        ResponseEntity<String> response = new ResponseEntity<>("Unauthorized", HttpStatus.UNAUTHORIZED);
        HVWException exception = HVWException.parseGenericErrorResponse(response, "service");
        assertEquals("\"Unauthorized\"", exception.getMessage());
        assertEquals(401, exception.getReturnCode());
    }

    @Test
    void testParseJsonString_WithFinalFallback() {
        String jsonString = "\"Bad request with missing code and description.\"";

        HVWException result = parseJsonString(jsonString, 503, "CMOD");

        assertNotNull(result);
        assertEquals(503, result.getReturnCode());
        assertTrue(result.getMessage().contains("Bad request with missing code"));
    }

    @Test
    void testParseJsonString_ValidJsonWithServiceMessage1() {
        String jsonString = "{\"serviceMessage\":{\"returnCode\":200,\"returnCodeDescription\":\"Success\"}}";
        int defaultCode = 503;
        String service = "testService";

        HVWException exception = parseJsonString(jsonString, defaultCode, service);

        assertEquals(200, exception.getReturnCode());  // Verify the return code
        assertEquals("Success", exception.getMessage());  // Verify the description
        assertEquals("testService", exception.getService());  // Verify the service name
    }

    @Test
    void testParseJsonString_HttpErrorMessageWithJson() {
        String jsonString = "Bad Request: {\"serviceMessage\":{\"returnCode\":400,\"returnCodeDescription\":\"Bad Request\"}}";
        int defaultCode = 503;
        String service = "testService";

        HVWException exception = parseJsonString(jsonString, defaultCode, service);

        assertEquals(400, exception.getReturnCode());  // Verify the return code
        assertEquals("Bad Request", exception.getMessage());  // Verify the description
        assertEquals("testService", exception.getService());  // Verify the service name
    }

    @Test
    void testParseJsonString_RegexFallback() {
        String jsonString = "{\"someKey\":\"someValue\",\"returnCode\":\"400\",\"returnCodeDescription\":\"Custom error\"}";
        int defaultCode = 503;
        String service = "testService";

        HVWException exception = parseJsonString(jsonString, defaultCode, service);

        assertEquals(503, exception.getReturnCode());  // Verify the extracted code
        assertEquals("Service request failed with status: 503", exception.getMessage());  // Verify the description
        assertEquals("testService", exception.getService());  // Verify the service name
    }

    @Test
    void testParseJsonString_NestedJsonInsideDescription() {
        String jsonString = "{\"serviceMessage\":{\"returnCode\":503,\"returnCodeDescription\":\"{\\\"innerCode\\\":400, \\\"innerDesc\\\":\\\"Inner error\\\"}\"}}";
        int defaultCode = 503;
        String service = "testService";

        HVWException exception = parseJsonString(jsonString, defaultCode, service);

        assertEquals(503, exception.getReturnCode());  // Verify the return code
        assertEquals("{", exception.getMessage());  // Verify the inner error description after parsing the nested JSON
        assertEquals("testService", exception.getService());  // Verify the service name
    }

    @Test
    void testParseJsonString_WithMessageField() {
        String jsonString = "{\"message\":\"An error occurred\"}";
        int defaultCode = 503;
        String service = "testService";

        HVWException exception = parseJsonString(jsonString, defaultCode, service);

        assertEquals(defaultCode, exception.getReturnCode());  // Verify the default code
        assertEquals("An error occurred", exception.getMessage());  // Verify the message field
        assertEquals("testService", exception.getService());  // Verify the service name
    }

    @Test
    void testParseJsonString_CleanerFallback() {
        String jsonString = "{\"returnCode\":400, \"returnCodeDescription\":\"Some error occurred\"}";
        int defaultCode = 503;
        String service = "testService";

        HVWException exception = parseJsonString(jsonString, defaultCode, service);

        assertEquals(503, exception.getReturnCode());  // Verify the extracted code
        assertEquals("Service request failed with status: 503", exception.getMessage());  // Verify the description
        assertEquals("testService", exception.getService());  // Verify the service name
    }

    @Test
    void testNullBody() {
        HVWException ex = extractNestedServiceMessage(null, DEFAULT_CODE, SERVICE);
        assertEquals(DEFAULT_CODE, ex.getReturnCode());
        assertEquals("Empty response body", ex.getMessage());
    }

    @Test
    void testBodyFieldContainsJsonString() {
        String json = "{\"serviceMessage\":{\"returnCode\":401,\"returnCodeDescription\":\"Unauthorized access\"}}";
        Map<String, Object> body = new HashMap<>();
        body.put("body", json);

        HVWException ex = extractNestedServiceMessage(body, DEFAULT_CODE, SERVICE);
        assertEquals(401, ex.getReturnCode());
        assertEquals("Unauthorized access", ex.getMessage());
    }

    @Test
    void testBodyFieldWithNestedJsonStringAsString() {
        String innerJson = "{\\\"serviceMessage\\\":{\\\"returnCode\\\":403,\\\"returnCodeDescription\\\":\\\"Forbidden\\\"}}";
        Map<String, Object> body = new HashMap<>();
        body.put("body", "\"" + innerJson + "\"");

        HVWException ex = extractNestedServiceMessage(body, DEFAULT_CODE, SERVICE);
        assertEquals(403, ex.getReturnCode());
        assertEquals("Forbidden", ex.getMessage());
    }

    @Test
    void testFallbackSerializationToJsonParsing() {
        Map<String, Object> body = new HashMap<>();
        body.put("message", "General failure");

        HVWException ex = extractNestedServiceMessage(body, DEFAULT_CODE, SERVICE);
        assertEquals(DEFAULT_CODE, ex.getReturnCode());
        assertEquals("General failure", ex.getMessage());
    }

    @Test
    void testFallbackSerializationWithoutMessage() {
        Map<String, Object> body = new HashMap<>();
        body.put("other", "data");

        HVWException ex = extractNestedServiceMessage(body, DEFAULT_CODE, SERVICE);
        assertEquals(DEFAULT_CODE, ex.getReturnCode());
        assertTrue(ex.getMessage().startsWith("Service request failed with status"));
    }

    @Test
    void testMalformedJsonInsideBody() {
        Map<String, Object> body = new HashMap<>();
        body.put("body", "{this is not: valid json}");

        HVWException ex = extractNestedServiceMessage(body, DEFAULT_CODE, SERVICE);
        assertEquals(DEFAULT_CODE, ex.getReturnCode());
        assertTrue(ex.getMessage().contains("this is not: valid json") || ex.getMessage().contains("Error response from service"));
    }

    @Test
    void testNullBody1() {
        // Should not throw anything
        assertDoesNotThrow(() -> checkServiceMessage(null, SERVICE));
    }

    @Test
    void testNoServiceMessage() {
        Map<String, Object> response = new HashMap<>();
        response.put("foo", "bar");

        assertDoesNotThrow(() -> checkServiceMessage(response, SERVICE));
    }

    @Test
    void testReturnCodeZero() {
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 0);
        serviceMessage.put("returnCodeDescription", "Everything is fine");

        Map<String, Object> response = new HashMap<>();
        response.put("serviceMessage", serviceMessage);

        assertDoesNotThrow(() -> checkServiceMessage(response, SERVICE));
    }

    @Test
    void testNonZeroReturnCodeWithDescription() {
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 503);
        serviceMessage.put("returnCodeDescription", "SERVICE_UNAVAILABLE");

        Map<String, Object> response = new HashMap<>();
        response.put("serviceMessage", serviceMessage);

        HVWException ex = assertThrows(HVWException.class, () -> checkServiceMessage(response, SERVICE));
        assertEquals(503, ex.getReturnCode());
        assertEquals("SERVICE_UNAVAILABLE", ex.getMessage());
        assertEquals(SERVICE, ex.getService());
    }

    @Test
    void testNonZeroReturnCodeWithoutDescription() {
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 123);

        Map<String, Object> response = new HashMap<>();
        response.put("serviceMessage", serviceMessage);

        HVWException ex = assertThrows(HVWException.class, () -> checkServiceMessage(response, SERVICE));
        assertEquals(123, ex.getReturnCode());
        assertEquals("Unknown error", ex.getMessage());
        assertEquals(SERVICE, ex.getService());
    }

    @Test
    void testOAuthTokenErrorCaseInsensitive() {
        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 30);
        serviceMessage.put("returnCodeDescription", "OAuth token expired");

        Map<String, Object> response = new HashMap<>();
        response.put("serviceMessage", serviceMessage);

        HVWException ex = assertThrows(HVWException.class, () -> checkServiceMessage(response, SERVICE));
        assertEquals(401, ex.getReturnCode());
        assertEquals("Authentication token expired. Please log in again.", ex.getMessage());
        assertEquals(SERVICE, ex.getService());
    }

    @Test
    void testCreateStatusBasedError_401() {
        int statusCode = 401;
        String errorMessage = "Unauthorized access";
        String service = "SomeService";

        HVWException exception = HVWException.createStatusBasedError(statusCode, errorMessage, service);

        assertEquals(401, exception.getReturnCode());
        assertEquals("Authentication required for service: SomeService", exception.getMessage());
        assertEquals("SomeService", exception.getService());
    }

    @Test
    void testCreateStatusBasedError_403() {
        int statusCode = 403;
        String errorMessage = "Forbidden access";
        String service = "AnotherService";

        HVWException exception = HVWException.createStatusBasedError(statusCode, errorMessage, service);

        assertEquals(403, exception.getReturnCode());
        assertEquals("Not authorized to access service: AnotherService", exception.getMessage());
        assertEquals("AnotherService", exception.getService());
    }

    @Test
    void testCreateStatusBasedError_404() {
        int statusCode = 404;
        String errorMessage = "Resource not found";
        String service = "TestService";

        HVWException exception = HVWException.createStatusBasedError(statusCode, errorMessage, service);

        assertEquals(404, exception.getReturnCode());
        assertEquals("Resource not found in service: TestService", exception.getMessage());
        assertEquals("TestService", exception.getService());
    }

}
