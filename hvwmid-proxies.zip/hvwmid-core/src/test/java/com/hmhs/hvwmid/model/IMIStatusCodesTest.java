package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMIStatusCodes enum classes
 * Tests all enum values, getters, and status descriptions
 * 
 */
class IMIStatusCodesTest {

    // ========== TRANSMIT FILE STATUS CODE TESTS ==========

    @Test
    void testTransmitFileStatusCdEnumValues() {
        IMIStatusCodes.TransmitFileStatusCd[] values = IMIStatusCodes.TransmitFileStatusCd.values();
        assertEquals(3, values.length);
        
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.A, values[0]);
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.R, values[1]);
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.C, values[2]);
    }

    @Test
    void testTransmitFileStatusCdA() {
        IMIStatusCodes.TransmitFileStatusCd status = IMIStatusCodes.TransmitFileStatusCd.A;
        assertEquals("Accepted", status.getStatusDesc());
    }

    @Test
    void testTransmitFileStatusCdR() {
        IMIStatusCodes.TransmitFileStatusCd status = IMIStatusCodes.TransmitFileStatusCd.R;
        assertEquals("Rejected", status.getStatusDesc());
    }

    @Test
    void testTransmitFileStatusCdC() {
        IMIStatusCodes.TransmitFileStatusCd status = IMIStatusCodes.TransmitFileStatusCd.C;
        assertEquals("Completed", status.getStatusDesc());
    }

    @Test
    void testTransmitFileStatusCdValueOf() {
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.A, IMIStatusCodes.TransmitFileStatusCd.valueOf("A"));
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.R, IMIStatusCodes.TransmitFileStatusCd.valueOf("R"));
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.C, IMIStatusCodes.TransmitFileStatusCd.valueOf("C"));
    }

    @Test
    void testTransmitFileStatusCdValueOfWithInvalidValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.TransmitFileStatusCd.valueOf("INVALID");
        });
    }

    @Test
    void testTransmitFileStatusCdValueOfWithNull() {
        assertThrows(NullPointerException.class, () -> {
            IMIStatusCodes.TransmitFileStatusCd.valueOf(null);
        });
    }

    @Test
    void testTransmitFileStatusCdValueOfWithEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.TransmitFileStatusCd.valueOf("");
        });
    }

    @Test
    void testTransmitFileStatusCdValueOfWithCaseSensitive() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.TransmitFileStatusCd.valueOf("a");
        });
    }

    @Test
    void testTransmitFileStatusCdValueOfWithWhitespace() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.TransmitFileStatusCd.valueOf(" A ");
        });
    }

    @Test
    void testTransmitFileStatusCdOrdinal() {
        assertEquals(0, IMIStatusCodes.TransmitFileStatusCd.A.ordinal());
        assertEquals(1, IMIStatusCodes.TransmitFileStatusCd.R.ordinal());
        assertEquals(2, IMIStatusCodes.TransmitFileStatusCd.C.ordinal());
    }

    @Test
    void testTransmitFileStatusCdName() {
        assertEquals("A", IMIStatusCodes.TransmitFileStatusCd.A.name());
        assertEquals("R", IMIStatusCodes.TransmitFileStatusCd.R.name());
        assertEquals("C", IMIStatusCodes.TransmitFileStatusCd.C.name());
    }

    @Test
    void testTransmitFileStatusCdToString() {
        assertEquals("A", IMIStatusCodes.TransmitFileStatusCd.A.toString());
        assertEquals("R", IMIStatusCodes.TransmitFileStatusCd.R.toString());
        assertEquals("C", IMIStatusCodes.TransmitFileStatusCd.C.toString());
    }

    @Test
    void testTransmitFileStatusCdEquals() {
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.A, IMIStatusCodes.TransmitFileStatusCd.A);
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.R, IMIStatusCodes.TransmitFileStatusCd.R);
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.C, IMIStatusCodes.TransmitFileStatusCd.C);
    }

    @Test
    void testTransmitFileStatusCdNotEquals() {
        assertNotEquals(IMIStatusCodes.TransmitFileStatusCd.A, IMIStatusCodes.TransmitFileStatusCd.R);
        assertNotEquals(IMIStatusCodes.TransmitFileStatusCd.A, IMIStatusCodes.TransmitFileStatusCd.C);
        assertNotEquals(IMIStatusCodes.TransmitFileStatusCd.R, IMIStatusCodes.TransmitFileStatusCd.C);
    }

    @Test
    void testTransmitFileStatusCdHashCode() {
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.A.hashCode(), IMIStatusCodes.TransmitFileStatusCd.A.hashCode());
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.R.hashCode(), IMIStatusCodes.TransmitFileStatusCd.R.hashCode());
        assertEquals(IMIStatusCodes.TransmitFileStatusCd.C.hashCode(), IMIStatusCodes.TransmitFileStatusCd.C.hashCode());
    }

    @Test
    void testTransmitFileStatusCdCompareTo() {
        assertTrue(IMIStatusCodes.TransmitFileStatusCd.A.compareTo(IMIStatusCodes.TransmitFileStatusCd.R) < 0);
        assertTrue(IMIStatusCodes.TransmitFileStatusCd.A.compareTo(IMIStatusCodes.TransmitFileStatusCd.C) < 0);
        assertTrue(IMIStatusCodes.TransmitFileStatusCd.R.compareTo(IMIStatusCodes.TransmitFileStatusCd.C) < 0);
        assertTrue(IMIStatusCodes.TransmitFileStatusCd.R.compareTo(IMIStatusCodes.TransmitFileStatusCd.A) > 0);
        assertTrue(IMIStatusCodes.TransmitFileStatusCd.C.compareTo(IMIStatusCodes.TransmitFileStatusCd.A) > 0);
        assertTrue(IMIStatusCodes.TransmitFileStatusCd.C.compareTo(IMIStatusCodes.TransmitFileStatusCd.R) > 0);
        assertEquals(0, IMIStatusCodes.TransmitFileStatusCd.A.compareTo(IMIStatusCodes.TransmitFileStatusCd.A));
    }

    // ========== PROCESS FILE STATUS CODE TESTS ==========

    @Test
    void testProcessFileStatusCdEnumValues() {
        IMIStatusCodes.ProcessFileStatusCd[] values = IMIStatusCodes.ProcessFileStatusCd.values();
        assertEquals(6, values.length);
        
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.V, values[0]);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.K, values[1]);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.T, values[2]);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.F, values[3]);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.E, values[4]);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.C, values[5]);
    }

    @Test
    void testProcessFileStatusCdV() {
        IMIStatusCodes.ProcessFileStatusCd status = IMIStatusCodes.ProcessFileStatusCd.V;
        assertEquals("Validation (Ready for)", status.getStatusDesc());
    }

    @Test
    void testProcessFileStatusCdK() {
        IMIStatusCodes.ProcessFileStatusCd status = IMIStatusCodes.ProcessFileStatusCd.K;
        assertEquals("Acknowledge (Ready for)", status.getStatusDesc());
    }

    @Test
    void testProcessFileStatusCdT() {
        IMIStatusCodes.ProcessFileStatusCd status = IMIStatusCodes.ProcessFileStatusCd.T;
        assertEquals("Transformation (Ready for)", status.getStatusDesc());
    }

    @Test
    void testProcessFileStatusCdF() {
        IMIStatusCodes.ProcessFileStatusCd status = IMIStatusCodes.ProcessFileStatusCd.F;
        assertEquals("Finalization (Ready for)", status.getStatusDesc());
    }

    @Test
    void testProcessFileStatusCdE() {
        IMIStatusCodes.ProcessFileStatusCd status = IMIStatusCodes.ProcessFileStatusCd.E;
        assertEquals("Error", status.getStatusDesc());
    }

    @Test
    void testProcessFileStatusCdC() {
        IMIStatusCodes.ProcessFileStatusCd status = IMIStatusCodes.ProcessFileStatusCd.C;
        assertEquals("Completed", status.getStatusDesc());
    }

    @Test
    void testProcessFileStatusCdValueOf() {
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.valueOf("V"));
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.K, IMIStatusCodes.ProcessFileStatusCd.valueOf("K"));
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.T, IMIStatusCodes.ProcessFileStatusCd.valueOf("T"));
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.F, IMIStatusCodes.ProcessFileStatusCd.valueOf("F"));
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.E, IMIStatusCodes.ProcessFileStatusCd.valueOf("E"));
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.C, IMIStatusCodes.ProcessFileStatusCd.valueOf("C"));
    }

    @Test
    void testProcessFileStatusCdValueOfWithInvalidValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.ProcessFileStatusCd.valueOf("INVALID");
        });
    }

    @Test
    void testProcessFileStatusCdValueOfWithNull() {
        assertThrows(NullPointerException.class, () -> {
            IMIStatusCodes.ProcessFileStatusCd.valueOf(null);
        });
    }

    @Test
    void testProcessFileStatusCdValueOfWithEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.ProcessFileStatusCd.valueOf("");
        });
    }

    @Test
    void testProcessFileStatusCdValueOfWithCaseSensitive() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.ProcessFileStatusCd.valueOf("v");
        });
    }

    @Test
    void testProcessFileStatusCdValueOfWithWhitespace() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.ProcessFileStatusCd.valueOf(" V ");
        });
    }

    @Test
    void testProcessFileStatusCdOrdinal() {
        assertEquals(0, IMIStatusCodes.ProcessFileStatusCd.V.ordinal());
        assertEquals(1, IMIStatusCodes.ProcessFileStatusCd.K.ordinal());
        assertEquals(2, IMIStatusCodes.ProcessFileStatusCd.T.ordinal());
        assertEquals(3, IMIStatusCodes.ProcessFileStatusCd.F.ordinal());
        assertEquals(4, IMIStatusCodes.ProcessFileStatusCd.E.ordinal());
        assertEquals(5, IMIStatusCodes.ProcessFileStatusCd.C.ordinal());
    }

    @Test
    void testProcessFileStatusCdName() {
        assertEquals("V", IMIStatusCodes.ProcessFileStatusCd.V.name());
        assertEquals("K", IMIStatusCodes.ProcessFileStatusCd.K.name());
        assertEquals("T", IMIStatusCodes.ProcessFileStatusCd.T.name());
        assertEquals("F", IMIStatusCodes.ProcessFileStatusCd.F.name());
        assertEquals("E", IMIStatusCodes.ProcessFileStatusCd.E.name());
        assertEquals("C", IMIStatusCodes.ProcessFileStatusCd.C.name());
    }

    @Test
    void testProcessFileStatusCdToString() {
        assertEquals("V", IMIStatusCodes.ProcessFileStatusCd.V.toString());
        assertEquals("K", IMIStatusCodes.ProcessFileStatusCd.K.toString());
        assertEquals("T", IMIStatusCodes.ProcessFileStatusCd.T.toString());
        assertEquals("F", IMIStatusCodes.ProcessFileStatusCd.F.toString());
        assertEquals("E", IMIStatusCodes.ProcessFileStatusCd.E.toString());
        assertEquals("C", IMIStatusCodes.ProcessFileStatusCd.C.toString());
    }

    @Test
    void testProcessFileStatusCdEquals() {
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.V);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.K, IMIStatusCodes.ProcessFileStatusCd.K);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.T, IMIStatusCodes.ProcessFileStatusCd.T);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.F, IMIStatusCodes.ProcessFileStatusCd.F);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.E, IMIStatusCodes.ProcessFileStatusCd.E);
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.C, IMIStatusCodes.ProcessFileStatusCd.C);
    }

    @Test
    void testProcessFileStatusCdNotEquals() {
        assertNotEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.K);
        assertNotEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.T);
        assertNotEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.F);
        assertNotEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.E);
        assertNotEquals(IMIStatusCodes.ProcessFileStatusCd.V, IMIStatusCodes.ProcessFileStatusCd.C);
        assertNotEquals(IMIStatusCodes.ProcessFileStatusCd.K, IMIStatusCodes.ProcessFileStatusCd.T);
    }

    @Test
    void testProcessFileStatusCdHashCode() {
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.V.hashCode(), IMIStatusCodes.ProcessFileStatusCd.V.hashCode());
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.K.hashCode(), IMIStatusCodes.ProcessFileStatusCd.K.hashCode());
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.T.hashCode(), IMIStatusCodes.ProcessFileStatusCd.T.hashCode());
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.F.hashCode(), IMIStatusCodes.ProcessFileStatusCd.F.hashCode());
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.E.hashCode(), IMIStatusCodes.ProcessFileStatusCd.E.hashCode());
        assertEquals(IMIStatusCodes.ProcessFileStatusCd.C.hashCode(), IMIStatusCodes.ProcessFileStatusCd.C.hashCode());
    }

    @Test
    void testProcessFileStatusCdCompareTo() {
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.V.compareTo(IMIStatusCodes.ProcessFileStatusCd.K) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.V.compareTo(IMIStatusCodes.ProcessFileStatusCd.T) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.V.compareTo(IMIStatusCodes.ProcessFileStatusCd.F) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.V.compareTo(IMIStatusCodes.ProcessFileStatusCd.E) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.V.compareTo(IMIStatusCodes.ProcessFileStatusCd.C) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.K.compareTo(IMIStatusCodes.ProcessFileStatusCd.T) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.K.compareTo(IMIStatusCodes.ProcessFileStatusCd.F) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.K.compareTo(IMIStatusCodes.ProcessFileStatusCd.E) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.K.compareTo(IMIStatusCodes.ProcessFileStatusCd.C) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.T.compareTo(IMIStatusCodes.ProcessFileStatusCd.F) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.T.compareTo(IMIStatusCodes.ProcessFileStatusCd.E) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.T.compareTo(IMIStatusCodes.ProcessFileStatusCd.C) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.F.compareTo(IMIStatusCodes.ProcessFileStatusCd.E) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.F.compareTo(IMIStatusCodes.ProcessFileStatusCd.C) < 0);
        assertTrue(IMIStatusCodes.ProcessFileStatusCd.E.compareTo(IMIStatusCodes.ProcessFileStatusCd.C) < 0);
        assertEquals(0, IMIStatusCodes.ProcessFileStatusCd.V.compareTo(IMIStatusCodes.ProcessFileStatusCd.V));
    }

    // ========== DOCUMENT STATUS CODE TESTS ==========

    @Test
    void testDocumentStatusCdEnumValues() {
        IMIStatusCodes.DocumentStatusCd[] values = IMIStatusCodes.DocumentStatusCd.values();
        assertEquals(11, values.length);
        
        assertEquals(IMIStatusCodes.DocumentStatusCd.A, values[0]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.X, values[1]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.I, values[2]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.L, values[3]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.P, values[4]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.O, values[5]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.S, values[6]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.M, values[7]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.F, values[8]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.E, values[9]);
        assertEquals(IMIStatusCodes.DocumentStatusCd.R, values[10]);
    }

    @Test
    void testDocumentStatusCdA() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.A;
        assertEquals("Accepted", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdX() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.X;
        assertEquals("Batch Capture (Ready for)", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdI() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.I;
        assertEquals("Image Store (Ready for)", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdL() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.L;
        assertEquals("Non-claim OCR (Ready for)", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdP() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.P;
        assertEquals("CMOD (Ready for)", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdO() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.O;
        assertEquals("Claim OCR (Ready for)", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdS() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.S;
        assertEquals("Stored", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdM() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.M;
        assertEquals("CMOD Stored", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdF() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.F;
        assertEquals("Finalization (Ready for)", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdE() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.E;
        assertEquals("Error", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdR() {
        IMIStatusCodes.DocumentStatusCd status = IMIStatusCodes.DocumentStatusCd.R;
        assertEquals("Rejected", status.getStatusDesc());
    }

    @Test
    void testDocumentStatusCdValueOf() {
        assertEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.valueOf("A"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.X, IMIStatusCodes.DocumentStatusCd.valueOf("X"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.I, IMIStatusCodes.DocumentStatusCd.valueOf("I"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.L, IMIStatusCodes.DocumentStatusCd.valueOf("L"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.P, IMIStatusCodes.DocumentStatusCd.valueOf("P"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.O, IMIStatusCodes.DocumentStatusCd.valueOf("O"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.S, IMIStatusCodes.DocumentStatusCd.valueOf("S"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.M, IMIStatusCodes.DocumentStatusCd.valueOf("M"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.F, IMIStatusCodes.DocumentStatusCd.valueOf("F"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.E, IMIStatusCodes.DocumentStatusCd.valueOf("E"));
        assertEquals(IMIStatusCodes.DocumentStatusCd.R, IMIStatusCodes.DocumentStatusCd.valueOf("R"));
    }

    @Test
    void testDocumentStatusCdValueOfWithInvalidValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.DocumentStatusCd.valueOf("INVALID");
        });
    }

    @Test
    void testDocumentStatusCdValueOfWithNull() {
        assertThrows(NullPointerException.class, () -> {
            IMIStatusCodes.DocumentStatusCd.valueOf(null);
        });
    }

    @Test
    void testDocumentStatusCdValueOfWithEmptyString() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.DocumentStatusCd.valueOf("");
        });
    }

    @Test
    void testDocumentStatusCdValueOfWithCaseSensitive() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.DocumentStatusCd.valueOf("a");
        });
    }

    @Test
    void testDocumentStatusCdValueOfWithWhitespace() {
        assertThrows(IllegalArgumentException.class, () -> {
            IMIStatusCodes.DocumentStatusCd.valueOf(" A ");
        });
    }

    @Test
    void testDocumentStatusCdOrdinal() {
        assertEquals(0, IMIStatusCodes.DocumentStatusCd.A.ordinal());
        assertEquals(1, IMIStatusCodes.DocumentStatusCd.X.ordinal());
        assertEquals(2, IMIStatusCodes.DocumentStatusCd.I.ordinal());
        assertEquals(3, IMIStatusCodes.DocumentStatusCd.L.ordinal());
        assertEquals(4, IMIStatusCodes.DocumentStatusCd.P.ordinal());
        assertEquals(5, IMIStatusCodes.DocumentStatusCd.O.ordinal());
        assertEquals(6, IMIStatusCodes.DocumentStatusCd.S.ordinal());
        assertEquals(7, IMIStatusCodes.DocumentStatusCd.M.ordinal());
        assertEquals(8, IMIStatusCodes.DocumentStatusCd.F.ordinal());
        assertEquals(9, IMIStatusCodes.DocumentStatusCd.E.ordinal());
        assertEquals(10, IMIStatusCodes.DocumentStatusCd.R.ordinal());
    }

    @Test
    void testDocumentStatusCdName() {
        assertEquals("A", IMIStatusCodes.DocumentStatusCd.A.name());
        assertEquals("X", IMIStatusCodes.DocumentStatusCd.X.name());
        assertEquals("I", IMIStatusCodes.DocumentStatusCd.I.name());
        assertEquals("L", IMIStatusCodes.DocumentStatusCd.L.name());
        assertEquals("P", IMIStatusCodes.DocumentStatusCd.P.name());
        assertEquals("O", IMIStatusCodes.DocumentStatusCd.O.name());
        assertEquals("S", IMIStatusCodes.DocumentStatusCd.S.name());
        assertEquals("M", IMIStatusCodes.DocumentStatusCd.M.name());
        assertEquals("F", IMIStatusCodes.DocumentStatusCd.F.name());
        assertEquals("E", IMIStatusCodes.DocumentStatusCd.E.name());
        assertEquals("R", IMIStatusCodes.DocumentStatusCd.R.name());
    }

    @Test
    void testDocumentStatusCdToString() {
        assertEquals("A", IMIStatusCodes.DocumentStatusCd.A.toString());
        assertEquals("X", IMIStatusCodes.DocumentStatusCd.X.toString());
        assertEquals("I", IMIStatusCodes.DocumentStatusCd.I.toString());
        assertEquals("L", IMIStatusCodes.DocumentStatusCd.L.toString());
        assertEquals("P", IMIStatusCodes.DocumentStatusCd.P.toString());
        assertEquals("O", IMIStatusCodes.DocumentStatusCd.O.toString());
        assertEquals("S", IMIStatusCodes.DocumentStatusCd.S.toString());
        assertEquals("M", IMIStatusCodes.DocumentStatusCd.M.toString());
        assertEquals("F", IMIStatusCodes.DocumentStatusCd.F.toString());
        assertEquals("E", IMIStatusCodes.DocumentStatusCd.E.toString());
        assertEquals("R", IMIStatusCodes.DocumentStatusCd.R.toString());
    }

    @Test
    void testDocumentStatusCdEquals() {
        assertEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.A);
        assertEquals(IMIStatusCodes.DocumentStatusCd.X, IMIStatusCodes.DocumentStatusCd.X);
        assertEquals(IMIStatusCodes.DocumentStatusCd.I, IMIStatusCodes.DocumentStatusCd.I);
        assertEquals(IMIStatusCodes.DocumentStatusCd.L, IMIStatusCodes.DocumentStatusCd.L);
        assertEquals(IMIStatusCodes.DocumentStatusCd.P, IMIStatusCodes.DocumentStatusCd.P);
        assertEquals(IMIStatusCodes.DocumentStatusCd.O, IMIStatusCodes.DocumentStatusCd.O);
        assertEquals(IMIStatusCodes.DocumentStatusCd.S, IMIStatusCodes.DocumentStatusCd.S);
        assertEquals(IMIStatusCodes.DocumentStatusCd.M, IMIStatusCodes.DocumentStatusCd.M);
        assertEquals(IMIStatusCodes.DocumentStatusCd.F, IMIStatusCodes.DocumentStatusCd.F);
        assertEquals(IMIStatusCodes.DocumentStatusCd.E, IMIStatusCodes.DocumentStatusCd.E);
        assertEquals(IMIStatusCodes.DocumentStatusCd.R, IMIStatusCodes.DocumentStatusCd.R);
    }

    @Test
    void testDocumentStatusCdNotEquals() {
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.X);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.I);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.L);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.P);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.O);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.S);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.M);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.F);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.E);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.A, IMIStatusCodes.DocumentStatusCd.R);
        assertNotEquals(IMIStatusCodes.DocumentStatusCd.X, IMIStatusCodes.DocumentStatusCd.I);
    }

    @Test
    void testDocumentStatusCdHashCode() {
        assertEquals(IMIStatusCodes.DocumentStatusCd.A.hashCode(), IMIStatusCodes.DocumentStatusCd.A.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.X.hashCode(), IMIStatusCodes.DocumentStatusCd.X.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.I.hashCode(), IMIStatusCodes.DocumentStatusCd.I.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.L.hashCode(), IMIStatusCodes.DocumentStatusCd.L.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.P.hashCode(), IMIStatusCodes.DocumentStatusCd.P.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.O.hashCode(), IMIStatusCodes.DocumentStatusCd.O.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.S.hashCode(), IMIStatusCodes.DocumentStatusCd.S.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.M.hashCode(), IMIStatusCodes.DocumentStatusCd.M.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.F.hashCode(), IMIStatusCodes.DocumentStatusCd.F.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.E.hashCode(), IMIStatusCodes.DocumentStatusCd.E.hashCode());
        assertEquals(IMIStatusCodes.DocumentStatusCd.R.hashCode(), IMIStatusCodes.DocumentStatusCd.R.hashCode());
    }

    @Test
    void testDocumentStatusCdCompareTo() {
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.X) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.I) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.L) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.P) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.O) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.S) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.M) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.F) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.E) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.R) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.I) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.L) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.P) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.O) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.S) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.M) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.F) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.E) < 0);
        assertTrue(IMIStatusCodes.DocumentStatusCd.X.compareTo(IMIStatusCodes.DocumentStatusCd.R) < 0);
        assertEquals(0, IMIStatusCodes.DocumentStatusCd.A.compareTo(IMIStatusCodes.DocumentStatusCd.A));
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testAllEnumValuesNotNull() {
        for (IMIStatusCodes.TransmitFileStatusCd status : IMIStatusCodes.TransmitFileStatusCd.values()) {
            assertNotNull(status);
            assertNotNull(status.getStatusDesc());
            assertFalse(status.getStatusDesc().isEmpty());
        }
        
        for (IMIStatusCodes.ProcessFileStatusCd status : IMIStatusCodes.ProcessFileStatusCd.values()) {
            assertNotNull(status);
            assertNotNull(status.getStatusDesc());
            assertFalse(status.getStatusDesc().isEmpty());
        }
        
        for (IMIStatusCodes.DocumentStatusCd status : IMIStatusCodes.DocumentStatusCd.values()) {
            assertNotNull(status);
            assertNotNull(status.getStatusDesc());
            assertFalse(status.getStatusDesc().isEmpty());
        }
    }

    @Test
    void testAllEnumValuesHaveUniqueNames() {
        String[] transmitNames = new String[IMIStatusCodes.TransmitFileStatusCd.values().length];
        for (int i = 0; i < IMIStatusCodes.TransmitFileStatusCd.values().length; i++) {
            transmitNames[i] = IMIStatusCodes.TransmitFileStatusCd.values()[i].name();
        }
        for (int i = 0; i < transmitNames.length; i++) {
            for (int j = i + 1; j < transmitNames.length; j++) {
                assertNotEquals(transmitNames[i], transmitNames[j]);
            }
        }
        
        String[] processNames = new String[IMIStatusCodes.ProcessFileStatusCd.values().length];
        for (int i = 0; i < IMIStatusCodes.ProcessFileStatusCd.values().length; i++) {
            processNames[i] = IMIStatusCodes.ProcessFileStatusCd.values()[i].name();
        }
        for (int i = 0; i < processNames.length; i++) {
            for (int j = i + 1; j < processNames.length; j++) {
                assertNotEquals(processNames[i], processNames[j]);
            }
        }
        
        String[] documentNames = new String[IMIStatusCodes.DocumentStatusCd.values().length];
        for (int i = 0; i < IMIStatusCodes.DocumentStatusCd.values().length; i++) {
            documentNames[i] = IMIStatusCodes.DocumentStatusCd.values()[i].name();
        }
        for (int i = 0; i < documentNames.length; i++) {
            for (int j = i + 1; j < documentNames.length; j++) {
                assertNotEquals(documentNames[i], documentNames[j]);
            }
        }
    }

    @Test
    void testAllEnumValuesHaveUniqueDescriptions() {
        String[] transmitDescriptions = new String[IMIStatusCodes.TransmitFileStatusCd.values().length];
        for (int i = 0; i < IMIStatusCodes.TransmitFileStatusCd.values().length; i++) {
            transmitDescriptions[i] = IMIStatusCodes.TransmitFileStatusCd.values()[i].getStatusDesc();
        }
        for (int i = 0; i < transmitDescriptions.length; i++) {
            for (int j = i + 1; j < transmitDescriptions.length; j++) {
                assertNotEquals(transmitDescriptions[i], transmitDescriptions[j]);
            }
        }
        
        String[] processDescriptions = new String[IMIStatusCodes.ProcessFileStatusCd.values().length];
        for (int i = 0; i < IMIStatusCodes.ProcessFileStatusCd.values().length; i++) {
            processDescriptions[i] = IMIStatusCodes.ProcessFileStatusCd.values()[i].getStatusDesc();
        }
        for (int i = 0; i < processDescriptions.length; i++) {
            for (int j = i + 1; j < processDescriptions.length; j++) {
                assertNotEquals(processDescriptions[i], processDescriptions[j]);
            }
        }
        
        String[] documentDescriptions = new String[IMIStatusCodes.DocumentStatusCd.values().length];
        for (int i = 0; i < IMIStatusCodes.DocumentStatusCd.values().length; i++) {
            documentDescriptions[i] = IMIStatusCodes.DocumentStatusCd.values()[i].getStatusDesc();
        }
        for (int i = 0; i < documentDescriptions.length; i++) {
            for (int j = i + 1; j < documentDescriptions.length; j++) {
                assertNotEquals(documentDescriptions[i], documentDescriptions[j]);
            }
        }
    }

    @Test
    void testAllEnumValuesHaveConsistentOrdinalAndName() {
        IMIStatusCodes.TransmitFileStatusCd[] transmitValues = IMIStatusCodes.TransmitFileStatusCd.values();
        for (int i = 0; i < transmitValues.length; i++) {
            assertEquals(i, transmitValues[i].ordinal());
        }
        
        IMIStatusCodes.ProcessFileStatusCd[] processValues = IMIStatusCodes.ProcessFileStatusCd.values();
        for (int i = 0; i < processValues.length; i++) {
            assertEquals(i, processValues[i].ordinal());
        }
        
        IMIStatusCodes.DocumentStatusCd[] documentValues = IMIStatusCodes.DocumentStatusCd.values();
        for (int i = 0; i < documentValues.length; i++) {
            assertEquals(i, documentValues[i].ordinal());
        }
    }

    @Test
    void testAllEnumValuesHaveConsistentToStringAndName() {
        for (IMIStatusCodes.TransmitFileStatusCd status : IMIStatusCodes.TransmitFileStatusCd.values()) {
            assertEquals(status.name(), status.toString());
        }
        
        for (IMIStatusCodes.ProcessFileStatusCd status : IMIStatusCodes.ProcessFileStatusCd.values()) {
            assertEquals(status.name(), status.toString());
        }
        
        for (IMIStatusCodes.DocumentStatusCd status : IMIStatusCodes.DocumentStatusCd.values()) {
            assertEquals(status.name(), status.toString());
        }
    }

    @Test
    void testAllEnumValuesHaveConsistentHashCode() {
        for (IMIStatusCodes.TransmitFileStatusCd status : IMIStatusCodes.TransmitFileStatusCd.values()) {
            assertEquals(status.hashCode(), status.hashCode());
        }
        
        for (IMIStatusCodes.ProcessFileStatusCd status : IMIStatusCodes.ProcessFileStatusCd.values()) {
            assertEquals(status.hashCode(), status.hashCode());
        }
        
        for (IMIStatusCodes.DocumentStatusCd status : IMIStatusCodes.DocumentStatusCd.values()) {
            assertEquals(status.hashCode(), status.hashCode());
        }
    }

    @Test
    void testAllEnumValuesHaveConsistentEquals() {
        for (IMIStatusCodes.TransmitFileStatusCd status : IMIStatusCodes.TransmitFileStatusCd.values()) {
            assertEquals(status, status);
        }
        
        for (IMIStatusCodes.ProcessFileStatusCd status : IMIStatusCodes.ProcessFileStatusCd.values()) {
            assertEquals(status, status);
        }
        
        for (IMIStatusCodes.DocumentStatusCd status : IMIStatusCodes.DocumentStatusCd.values()) {
            assertEquals(status, status);
        }
    }

    @Test
    void testAllEnumValuesHaveConsistentCompareTo() {
        for (IMIStatusCodes.TransmitFileStatusCd status : IMIStatusCodes.TransmitFileStatusCd.values()) {
            assertEquals(0, status.compareTo(status));
        }
        
        for (IMIStatusCodes.ProcessFileStatusCd status : IMIStatusCodes.ProcessFileStatusCd.values()) {
            assertEquals(0, status.compareTo(status));
        }
        
        for (IMIStatusCodes.DocumentStatusCd status : IMIStatusCodes.DocumentStatusCd.values()) {
            assertEquals(0, status.compareTo(status));
        }
    }
}
