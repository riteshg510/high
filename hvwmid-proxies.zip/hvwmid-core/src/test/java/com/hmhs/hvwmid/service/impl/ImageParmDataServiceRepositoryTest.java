package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Repository-focused test for parameter data functionality.
 * This test validates that the repository methods work correctly.
 */
@ExtendWith(MockitoExtension.class)
class ImageParmDataServiceRepositoryTest {

    @Mock
    private T222APRMRepository t222APRMRepository;

    private List<T222APRM> testData;

    @BeforeEach
    void setUp() {
        // Create test data
        testData = Arrays.asList(
            createTestParmData(HVWConstants.HVWBASE, "TEST_KEY_1", "TEST_VALUE_1"),
            createTestParmData(HVWConstants.HVWBASE, "TEST_KEY_2", "TEST_VALUE_2"),
            createTestParmData(HVWConstants.CMBASE, "CMOD_KEY_1", "CMOD_VALUE_1"),
            createTestParmData(HVWConstants.CODBASE, "COD_KEY_1", "COD_VALUE_1"),
            createTestParmData(HVWConstants.CMFLDMAP, "FIELD_1", "FOLDER_1"),
            createTestParmData(HVWConstants.CMUSEREX, "USER_KEY_1", "USER_VALUE_1")
        );
    }

    private T222APRM createTestParmData(String parmId, String parmKey, String parmData) {
        T222APRM entity = new T222APRM();
        entity.setParmId(parmId);
        entity.setParmKey(parmKey);
        entity.setParmData(parmData);
        entity.setModUser("TEST_USER");
        entity.setTimeChgd(new Timestamp(System.currentTimeMillis()));
        return entity;
    }

    @Test
    void testRepositoryBasicFunctionality() {
        // Mock repository methods
        when(t222APRMRepository.count()).thenReturn(6L);
        
        List<T222APRM> hvwbaseRecords = testData.stream()
            .filter(t -> HVWConstants.HVWBASE.equals(t.getParmId()))
            .collect(Collectors.toList());
        when(t222APRMRepository.findByParmId(HVWConstants.HVWBASE)).thenReturn(hvwbaseRecords);
        
        // Test basic repository methods
        assertEquals(6, t222APRMRepository.count());
        
        // Test findByParmId
        var records = t222APRMRepository.findByParmId(HVWConstants.HVWBASE);
        assertNotNull(records);
        assertEquals(2, records.size());
    }

    @Test
    void testGetParmDataAsMap() {
        // Mock HVWBASE data retrieval as map
        Map<String, String> hvwbaseMap = new HashMap<>();
        hvwbaseMap.put("TEST_KEY_1", "TEST_VALUE_1");
        hvwbaseMap.put("TEST_KEY_2", "TEST_VALUE_2");
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(hvwbaseMap);
        
        // Mock CMBASE data retrieval as map
        Map<String, String> cmbaseMap = new HashMap<>();
        cmbaseMap.put("CMOD_KEY_1", "CMOD_VALUE_1");
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE)).thenReturn(cmbaseMap);

        // Test HVWBASE data retrieval as map
        Map<String, String> hvwbaseResult = t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE);
        assertNotNull(hvwbaseResult);
        assertEquals(2, hvwbaseResult.size());
        assertEquals("TEST_VALUE_1", hvwbaseResult.get("TEST_KEY_1"));
        assertEquals("TEST_VALUE_2", hvwbaseResult.get("TEST_KEY_2"));

        // Test CMBASE data retrieval as map
        Map<String, String> cmbaseResult = t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE);
        assertNotNull(cmbaseResult);
        assertEquals(1, cmbaseResult.size());
        assertEquals("CMOD_VALUE_1", cmbaseResult.get("CMOD_KEY_1"));
    }

    @Test
    void testGetParmDataMapsGroupedByParmId() {
        // Mock grouped data retrieval
        var parmIds = Arrays.asList(HVWConstants.HVWBASE, HVWConstants.CMBASE);
        
        Map<String, Map<String, String>> mockGroupedData = new HashMap<>();
        Map<String, String> hvwbaseData = new HashMap<>();
        hvwbaseData.put("TEST_KEY_1", "TEST_VALUE_1");
        hvwbaseData.put("TEST_KEY_2", "TEST_VALUE_2");
        mockGroupedData.put(HVWConstants.HVWBASE, hvwbaseData);
        
        Map<String, String> cmbaseData = new HashMap<>();
        cmbaseData.put("CMOD_KEY_1", "CMOD_VALUE_1");
        mockGroupedData.put(HVWConstants.CMBASE, cmbaseData);
        
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(parmIds)).thenReturn(mockGroupedData);
        
        // Test grouped data retrieval
        Map<String, Map<String, String>> groupedData = t222APRMRepository.getParmDataMapsGroupedByParmId(parmIds);
        
        assertNotNull(groupedData);
        assertEquals(2, groupedData.size());
        
        assertTrue(groupedData.containsKey(HVWConstants.HVWBASE));
        assertTrue(groupedData.containsKey(HVWConstants.CMBASE));
        
        assertEquals("TEST_VALUE_1", groupedData.get(HVWConstants.HVWBASE).get("TEST_KEY_1"));
        assertEquals("CMOD_VALUE_1", groupedData.get(HVWConstants.CMBASE).get("CMOD_KEY_1"));
    }

    @Test
    void testFindByParmIdIn() {
        // Mock multiple parm ID retrieval
        var parmIds = Arrays.asList(HVWConstants.HVWBASE, HVWConstants.CMBASE, HVWConstants.CODBASE);
        
        List<T222APRM> mockRecords = testData.stream()
            .filter(t -> parmIds.contains(t.getParmId()))
            .collect(Collectors.toList());
        
        when(t222APRMRepository.findByParmIdIn(parmIds)).thenReturn(mockRecords);
        
        // Test multiple parm ID retrieval
        var records = t222APRMRepository.findByParmIdIn(parmIds);
        
        assertNotNull(records);
        assertEquals(4, records.size()); // 2 HVWBASE + 1 CMBASE + 1 CODBASE
        
        // Verify we have records for all requested parm IDs
        var parmIdCounts = records.stream()
                .collect(Collectors.groupingBy(
                        T222APRM::getParmId,
                        Collectors.counting()
                ));
        
        assertEquals(2L, parmIdCounts.get(HVWConstants.HVWBASE));
        assertEquals(1L, parmIdCounts.get(HVWConstants.CMBASE));
        assertEquals(1L, parmIdCounts.get(HVWConstants.CODBASE));
    }

    @Test
    void testEmptyResults() {
        // Mock empty results
        when(t222APRMRepository.getParmDataAsMap("NON_EXISTENT")).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(Collections.emptyList())).thenReturn(new HashMap<>());
        
        // Test with non-existent parm ID
        Map<String, String> emptyMap = t222APRMRepository.getParmDataAsMap("NON_EXISTENT");
        assertNotNull(emptyMap);
        assertTrue(emptyMap.isEmpty());
        
        // Test with empty parm ID list
        Map<String, Map<String, String>> emptyGrouped = t222APRMRepository.getParmDataMapsGroupedByParmId(Collections.emptyList());
        assertNotNull(emptyGrouped);
        assertTrue(emptyGrouped.isEmpty());
    }
}