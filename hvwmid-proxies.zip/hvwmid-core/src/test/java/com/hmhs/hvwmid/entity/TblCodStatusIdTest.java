package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TblCodStatusIdTest {

    @Test
    void testConstructorAndEquals_sameValues_shouldBeEqual() {
        LocalDateTime now = LocalDateTime.now();

        TblCodStatusId id1 = new TblCodStatusId(now, 101);
        TblCodStatusId id2 = new TblCodStatusId(now, 101);

        assertEquals(id1, id2);
        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testEquals_differentValues_shouldNotBeEqual() {
        LocalDateTime now = LocalDateTime.now();
        TblCodStatusId id1 = new TblCodStatusId(now, 101);
        TblCodStatusId id2 = new TblCodStatusId(now.plusSeconds(1), 102);

        assertNotEquals(id1, id2);
        assertNotEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testEquals_withNullAndDifferentType_shouldReturnFalse() {
        TblCodStatusId id = new TblCodStatusId(LocalDateTime.now(), 123);

        assertNotEquals(id, null);
        assertNotEquals(id, "some string");
    }

    @Test
    void testEquals_self_shouldReturnTrue() {
        TblCodStatusId id = new TblCodStatusId(LocalDateTime.now(), 999);
        assertEquals(id, id);
    }

    @Test
    void testHashCode_consistency() {
        LocalDateTime now = LocalDateTime.now();
        TblCodStatusId id = new TblCodStatusId(now, 42);

        int hash1 = id.hashCode();
        int hash2 = id.hashCode();

        assertEquals(hash1, hash2);
    }
}
