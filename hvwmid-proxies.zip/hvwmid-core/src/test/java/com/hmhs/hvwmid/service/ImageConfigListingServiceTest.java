package com.hmhs.hvwmid.service;

import static org.junit.jupiter.api.Assertions.*;

import com.hmhs.hvwmid.model.ListingSearchRequest;
import com.hmhs.hvwmid.repository.ImageConfigListingJdbcRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.IOException;
import java.util.List;
import java.util.Map;


import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ImageConfigListingServiceTest {

    @Mock
    private ImageConfigListingJdbcRepository repo;

    private ImageConfigListingService service;

    @BeforeEach
    void setUp() {
        service = new ImageConfigListingService(repo);
    }

    @Test
    void search_buildsDefinitionAndReturnsData() throws IOException {
        // Arrange
        ListingSearchRequest req = new ListingSearchRequest();
        List<Map<String, Object>> repoRows = List.of(
                Map.of("id", 1, "name", "Row 1"),
                Map.of("id", 2, "name", "Row 2")
        );
        when(repo.search(req)).thenReturn(repoRows);

        // Act
        Map<String, Object> result = service.search(req);

        // Assert
        assertNotNull(result, "result should not be null");
        assertTrue(result.containsKey("definition"), "definition should be present");
        assertTrue(result.containsKey("data"), "data should be present");

        // Data passthrough
        assertEquals(repoRows, result.get("data"), "data should match repo output");

        // Definition shape/constants
        @SuppressWarnings("unchecked")
        Map<String, Object> definition = (Map<String, Object>) result.get("definition");
        assertNotNull(definition);

        assertEquals(false, definition.get("allowMultipleSort"));
        assertEquals(false, definition.get("allowResizeColumns"));
        assertEquals("multiple", definition.get("selectionMode"));

        @SuppressWarnings("unchecked")
        Map<String, Object> pagination = (Map<String, Object>) definition.get("pagination");
        assertNotNull(pagination);
        assertEquals(0, pagination.get("pageNumber"));
        assertEquals(10, pagination.get("pageSize"));

        // Actions
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> actions = (List<Map<String, Object>>) definition.get("actions");
        assertNotNull(actions);
        assertFalse(actions.isEmpty(), "actions should not be empty");

        Map<String, Object> downloadAction = actions.get(0);
        assertEquals("downloadpdf", downloadAction.get("actionType"));
        assertEquals("Download Selected", downloadAction.get("label"));
        assertEquals("download", downloadAction.get("actionIcon"));
        assertEquals("report-archive/tokens/view", downloadAction.get("apiUrl"));

        // Columns exist (content depends on enum/request, so just sanity check type)
        assertTrue(definition.get("columns") instanceof List, "columns should be a List");
    }

    @Test
    void search_handlesNullRepoRowsAsEmptyList() throws IOException {
        // Arrange
        ListingSearchRequest req = new ListingSearchRequest();
        when(repo.search(req)).thenReturn(null);

        // Act
        Map<String, Object> result = service.search(req);

        // Assert
        assertNotNull(result);
        assertEquals(List.of(), result.get("data"), "data should be empty list when repo returns null");
    }
}
