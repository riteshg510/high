package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.*;
import com.hmhs.hvwmid.exception.ResourceNotFoundException;
import com.hmhs.hvwmid.model.*;
import com.hmhs.hvwmid.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

class CoversheetServiceTest {

    @InjectMocks
    private CoversheetServiceImpl coversheetService;

    @Mock
    private T117ImgCoverSheetRepository coverSheetRepo;

    @Mock
    private T117ImgCoverSheetOverrideRepository coverSheetOverrideRepo;

    @Mock
    private T117ImgCoverApplRepository applicationRepository;

    @Mock
    private T117ImgCoverObjectRepository templateRepository;

    private T117ImgCoverSheet mockCoverSheet;
    private T117ImgCoverSheetOverride mockOverride;
    private T117ImgCoverAppl mockApplication;
    private T117ImgCoverObject mockTemplate;
    private T117ImgCoverDept mockDepartment;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        
        // Setup mock department
        mockDepartment = new T117ImgCoverDept();
        mockDepartment.setDeptId(1);
        mockDepartment.setDescription("Test Department");
        mockDepartment.setMaintGroup("TestMaintGroup");
        mockDepartment.setPrintGroup("TestPrintGroup");

        // Setup mock coversheet
        mockCoverSheet = new T117ImgCoverSheet();
        mockCoverSheet.setApplication(100);
        mockCoverSheet.setName("TestSheet");
        mockCoverSheet.setDescription("Test Description");
        mockCoverSheet.setTemplate("TestTemplate");
        mockCoverSheet.setActive("Y");
        mockCoverSheet.setEnvironment("TEST");

        // Setup mock override
        mockOverride = new T117ImgCoverSheetOverride();
        mockOverride.setApplication(100);
        mockOverride.setName("TestSheet");
        mockOverride.setSequence(1);
        mockOverride.setTemplate("TestTemplate");
        mockOverride.setActive("Y");

        // Setup mock application
        mockApplication = new T117ImgCoverAppl();
        mockApplication.setApplication(100);
        mockApplication.setDescription("Test Application");
        mockApplication.setDepartment(mockDepartment);
        mockApplication.setActive("Y");
        mockApplication.setApplId("TestApplId");
        mockApplication.setSequence(1);

        // Setup mock template
        mockTemplate = new T117ImgCoverObject();
        mockTemplate.setObjName("TestTemplate");
        mockTemplate.setObjType("PDF");
        mockTemplate.setMimeType("application/pdf");
        mockTemplate.setObjData("sample template data");
        mockTemplate.setActive("Y");
    }

    @Test
    void getAllCoverSheets_ActiveOnly_ReturnsOnlyActiveSheets() {
        // Arrange
        List<T117ImgCoverSheet> activeSheets = Arrays.asList(mockCoverSheet);
        when(coverSheetRepo.findAllByActive()).thenReturn(activeSheets);

        // Act
        List<CoverSheetDTO> result = coversheetService.getAllCoverSheets(true);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(mockCoverSheet.getApplication(), result.get(0).getApplication());
        verify(coverSheetRepo, times(1)).findAllByActive();
        verify(coverSheetRepo, never()).findAll();
    }

    @Test
    void getAllCoverSheets_AllSheets_ReturnsAllSheets() {
        // Arrange
        T117ImgCoverSheet inactiveSheet = new T117ImgCoverSheet();
        inactiveSheet.setApplication(101);
        inactiveSheet.setName("InactiveSheet");
        inactiveSheet.setActive("N");
        
        List<T117ImgCoverSheet> allSheets = Arrays.asList(mockCoverSheet, inactiveSheet);
        when(coverSheetRepo.findAll()).thenReturn(allSheets);

        // Act
        List<CoverSheetDTO> result = coversheetService.getAllCoverSheets(false);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(coverSheetRepo, times(1)).findAll();
        verify(coverSheetRepo, never()).findAllByActive();
    }

    @Test
    void getCoversheetByApplicationIdAndName_ValidInputs_ReturnsCoverSheet() {
        // Arrange
        when(coverSheetRepo.findByApplicationAndName(100, "TestSheet")).thenReturn(Optional.of(mockCoverSheet));

        // Act
        CoverSheetDTO result = coversheetService.getCoversheetByApplicationIdAndName(100, "TestSheet");

        // Assert
        assertNotNull(result);
        assertEquals(mockCoverSheet.getApplication(), result.getApplication());
        assertEquals(mockCoverSheet.getName(), result.getName());
        verify(coverSheetRepo, times(1)).findByApplicationAndName(100, "TestSheet");
    }

    @Test
    void getCoversheetByApplicationIdAndName_NullApplicationId_ThrowsException() {
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetService.getCoversheetByApplicationIdAndName(null, "TestSheet");
        });

        assertEquals("Application ID and Coversheet Name must not be null or empty", exception.getMessage());
        verify(coverSheetRepo, never()).findByApplicationAndName(anyInt(), any());
    }

    @Test
    void getCoversheetByApplicationIdAndName_EmptyName_ThrowsException() {
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetService.getCoversheetByApplicationIdAndName(100, "");
        });

        assertEquals("Application ID and Coversheet Name must not be null or empty", exception.getMessage());
        verify(coverSheetRepo, never()).findByApplicationAndName(anyInt(), any());
    }

    @Test
    void getCoversheetByApplicationIdAndName_NotFound_ThrowsResourceNotFoundException() {
        // Arrange
        when(coverSheetRepo.findByApplicationAndName(100, "NonExistent")).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            coversheetService.getCoversheetByApplicationIdAndName(100, "NonExistent");
        });

        assertEquals("CoverSheet not found", exception.getMessage());
        verify(coverSheetRepo, times(1)).findByApplicationAndName(100, "NonExistent");
    }

    @Test
    void getAllCoversheetsAndOverridesByTemplateName_WithCoversAndOverrides_ReturnsCombinedList() {
        // Arrange
        String templateName = "TestTemplate";
        List<T117ImgCoverSheetOverride> overrides = Arrays.asList(mockOverride);
        List<T117ImgCoverSheet> covers = Arrays.asList(mockCoverSheet);
        
        when(coverSheetOverrideRepo.findAllByTemplate(templateName)).thenReturn(overrides);
        when(coverSheetRepo.findAllByTemplate(templateName)).thenReturn(covers);

        // Act
        List<CoverSheetOverrideDTO> result = coversheetService.getAllCoversheetsAndOverridesByTemplateName(templateName);

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size()); // 1 override + 1 cover sheet
        verify(coverSheetOverrideRepo, times(1)).findAllByTemplate(templateName);
        verify(coverSheetRepo, times(1)).findAllByTemplate(templateName);
    }

    @Test
    void getAllCoversheetsAndOverridesByTemplateName_NoCovers_ReturnsEmptyList() {
        // Arrange
        String templateName = "TestTemplate";
        when(coverSheetOverrideRepo.findAllByTemplate(templateName)).thenReturn(Arrays.asList());
        when(coverSheetRepo.findAllByTemplate(templateName)).thenReturn(null);

        // Act
        List<CoverSheetOverrideDTO> result = coversheetService.getAllCoversheetsAndOverridesByTemplateName(templateName);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(coverSheetOverrideRepo, times(1)).findAllByTemplate(templateName);
        verify(coverSheetRepo, times(1)).findAllByTemplate(templateName);
    }

    @Test
    void saveCoverSheet_ValidDTO_ReturnsSavedDTO() {
        // Arrange
        CoverSheetDTO inputDTO = new CoverSheetDTO();
        inputDTO.setApplication(100);
        inputDTO.setName("TestSheet");
        inputDTO.setDescription("Test Description");
        
        when(coverSheetRepo.save(any(T117ImgCoverSheet.class))).thenReturn(mockCoverSheet);

        // Act
        CoverSheetDTO result = coversheetService.saveCoverSheet(inputDTO);

        // Assert
        assertNotNull(result);
        assertEquals(mockCoverSheet.getApplication(), result.getApplication());
        assertEquals(mockCoverSheet.getName(), result.getName());
        verify(coverSheetRepo, times(1)).save(any(T117ImgCoverSheet.class));
    }

    @Test
    void updateCoverSheet_ValidDTO_ReturnsUpdatedCoverSheet() {
        // Arrange
        CoverSheetDTO inputDto = new CoverSheetDTO();
        inputDto.setApplication(100);
        inputDto.setName("TestSheet");
        inputDto.setDescription("Updated Description");
        inputDto.setSb1("Updated SB1");
        inputDto.setEb1("Updated EB1");
        inputDto.setEb2("Updated EB2");
        inputDto.setEb3("Updated EB3");
        inputDto.setTitle("Updated Title");
        inputDto.setStitle1("Updated Subtitle1");
        inputDto.setStitle2("Updated Subtitle2");
        inputDto.setUnit("Updated Unit");
        inputDto.setRcode("Updated RCode");
        inputDto.setTemplate("Updated Template");
        inputDto.setActive("Y");
        inputDto.setEnvironment("UPDATED");

        T117ImgCoverSheet existingEntity = new T117ImgCoverSheet();
        existingEntity.setApplication(100);
        existingEntity.setName("TestSheet");
        existingEntity.setDescription("Old Description");
        existingEntity.setTemplate("Old Template");

        T117ImgCoverSheet updatedEntity = new T117ImgCoverSheet();
        updatedEntity.setApplication(100);
        updatedEntity.setName("TestSheet");
        updatedEntity.setDescription("Updated Description");
        updatedEntity.setSb1("Updated SB1");
        updatedEntity.setEb1("Updated EB1");
        updatedEntity.setEb2("Updated EB2");
        updatedEntity.setEb3("Updated EB3");
        updatedEntity.setTitle("Updated Title");
        updatedEntity.setStitle1("Updated Subtitle1");
        updatedEntity.setStitle2("Updated Subtitle2");
        updatedEntity.setUnit("Updated Unit");
        updatedEntity.setRcode("Updated RCode");
        updatedEntity.setTemplate("Updated Template");
        updatedEntity.setActive("Y");
        updatedEntity.setEnvironment("UPDATED");

        when(coverSheetRepo.findByApplicationAndName(100, "TestSheet")).thenReturn(Optional.of(existingEntity));
        when(coverSheetRepo.save(any(T117ImgCoverSheet.class))).thenReturn(updatedEntity);

        // Act
        CoverSheetDTO result = coversheetService.updateCoverSheet(inputDto);

        // Assert
        assertNotNull(result);
        assertEquals(inputDto.getApplication(), result.getApplication());
        assertEquals(inputDto.getName(), result.getName());
        assertEquals(inputDto.getDescription(), result.getDescription());
        assertEquals(inputDto.getSb1(), result.getSb1());
        assertEquals(inputDto.getEb1(), result.getEb1());
        assertEquals(inputDto.getEb2(), result.getEb2());
        assertEquals(inputDto.getEb3(), result.getEb3());
        assertEquals(inputDto.getTitle(), result.getTitle());
        assertEquals(inputDto.getStitle1(), result.getStitle1());
        assertEquals(inputDto.getStitle2(), result.getStitle2());
        assertEquals(inputDto.getUnit(), result.getUnit());
        assertEquals(inputDto.getRcode(), result.getRcode());
        assertEquals(inputDto.getTemplate(), result.getTemplate());
        assertEquals(inputDto.getActive(), result.getActive());
        assertEquals(inputDto.getEnvironment(), result.getEnvironment());

        verify(coverSheetRepo, times(1)).findByApplicationAndName(100, "TestSheet");
        verify(coverSheetRepo, times(1)).save(any(T117ImgCoverSheet.class));
    }

    @Test
    void updateCoverSheet_NotFound_ThrowsResourceNotFoundException() {
        // Arrange
        CoverSheetDTO inputDto = new CoverSheetDTO();
        inputDto.setApplication(100);
        inputDto.setName("NonExistentSheet");

        when(coverSheetRepo.findByApplicationAndName(100, "NonExistentSheet")).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            coversheetService.updateCoverSheet(inputDto);
        });

        assertEquals("CoverSheet not found", exception.getMessage());
        verify(coverSheetRepo, times(1)).findByApplicationAndName(100, "NonExistentSheet");
        verify(coverSheetRepo, never()).save(any(T117ImgCoverSheet.class));
    }

    @Test
    void deleteCoverSheet_ValidId_SetsActiveToN() {
        // Arrange
        T117ImgCoverSheetId id = new T117ImgCoverSheetId();
        id.setApplication(100);
        id.setName("TestSheet");
        
        when(coverSheetRepo.findById(id)).thenReturn(Optional.of(mockCoverSheet));
        when(coverSheetRepo.save(any(T117ImgCoverSheet.class))).thenReturn(mockCoverSheet);

        // Act
        coversheetService.deleteCoverSheet(id);

        // Assert
        verify(coverSheetRepo, times(1)).findById(id);
        verify(coverSheetRepo, times(1)).save(any(T117ImgCoverSheet.class));
    }

    @Test
    void deleteCoverSheet_NullId_ThrowsException() {
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetService.deleteCoverSheet(null);
        });

        assertEquals("CoverSheet ID must not be null", exception.getMessage());
        verify(coverSheetRepo, never()).findById(any());
    }

    @Test
    void getAllOverrides_ReturnsAllOverrides() {
        // Arrange
        List<T117ImgCoverSheetOverride> overrides = Arrays.asList(mockOverride);
        when(coverSheetOverrideRepo.findAll()).thenReturn(overrides);

        // Act
        List<CoverSheetOverrideDTO> result = coversheetService.getAllOverrides();

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(coverSheetOverrideRepo, times(1)).findAll();
    }

    @Test
    void getCoversheetOverrideListByApplicationIdAndName_ReturnsOverrideList() {
        // Arrange
        List<T117ImgCoverSheetOverride> overrides = Arrays.asList(mockOverride);
        when(coverSheetOverrideRepo.findAllByApplicationAndName(100, "TestSheet")).thenReturn(overrides);

        // Act
        List<CoverSheetOverrideDTO> result = coversheetService.getCoversheetOverrideListByApplicationIdAndName(100, "TestSheet");

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(coverSheetOverrideRepo, times(1)).findAllByApplicationAndName(100, "TestSheet");
    }

    @Test
    void getCoversheetOverrideByApplicationIdAndName_ValidInputs_ReturnsOverride() {
        // Arrange
        when(coverSheetOverrideRepo.findByAppNameSequence(100, "TestSheet", 1)).thenReturn(Optional.of(mockOverride));

        // Act
        CoverSheetOverrideDTO result = coversheetService.getCoversheetOverrideByApplicationIdAndName(100, "TestSheet", 1);

        // Assert
        assertNotNull(result);
        assertEquals(mockOverride.getApplication(), result.getApplication());
        assertEquals(mockOverride.getName(), result.getName());
        verify(coverSheetOverrideRepo, times(1)).findByAppNameSequence(100, "TestSheet", 1);
    }

    @Test
    void getCoversheetOverrideByApplicationIdAndName_NullSequence_ThrowsException() {
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetService.getCoversheetOverrideByApplicationIdAndName(100, "TestSheet", null);
        });

        assertEquals("Application ID and Coversheet Name must not be null or empty", exception.getMessage());
        verify(coverSheetOverrideRepo, never()).findByAppNameSequence(anyInt(), any(), anyInt());
    }

    @Test
    void createNewOveride_ValidOverride_ReturnsOverrideWithSequence() {
        // Arrange
        CoverSheetOverrideDTO inputDTO = new CoverSheetOverrideDTO();
        inputDTO.setApplication(100);
        inputDTO.setName("TestSheet");
        
        when(coverSheetOverrideRepo.findMaxSequenceByApplicationAndName(100, "TestSheet")).thenReturn(5);
        when(coverSheetOverrideRepo.save(any(T117ImgCoverSheetOverride.class))).thenReturn(mockOverride);

        // Act
        CoverSheetOverrideDTO result = coversheetService.createNewOveride(inputDTO);

        // Assert
        assertNotNull(result);
        verify(coverSheetOverrideRepo, times(1)).findMaxSequenceByApplicationAndName(100, "TestSheet");
        verify(coverSheetOverrideRepo, times(1)).save(any(T117ImgCoverSheetOverride.class));
    }


    @Test
    void testUpdateOverride_notFound() {
        // Arrange
        CoverSheetOverrideDTO inputDto = new CoverSheetOverrideDTO();
        inputDto.setApplication(1);
        inputDto.setName("NAME");
        inputDto.setSequence(1);

        when(coverSheetOverrideRepo.findByAppNameSequence(1, "NAME", 1)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> coversheetService.updateOverride(inputDto));
        verify(coverSheetOverrideRepo).findByAppNameSequence(1, "NAME", 1);
        verify(coverSheetOverrideRepo, never()).save(any());
    }

    @Test
    void updateOverride_ValidDTO_ReturnsUpdatedOverride() {
        // Arrange
        CoverSheetOverrideDTO inputDto = new CoverSheetOverrideDTO();
        inputDto.setApplication(100);
        inputDto.setName("TestSheet");
        inputDto.setSequence(1);
        inputDto.setDescription("Updated Description");
        inputDto.setSb1("Updated SB1");
        inputDto.setEb1("Updated EB1");
        inputDto.setEb2("Updated EB2");
        inputDto.setEb3("Updated EB3");
        inputDto.setTitle("Updated Title");
        inputDto.setStitle1("Updated Subtitle1");
        inputDto.setStitle2("Updated Subtitle2");
        inputDto.setUnit("Updated Unit");
        inputDto.setRcode("Updated RCode");
        inputDto.setTemplate("Updated Template");
        inputDto.setActive("Y");
        inputDto.setEnvironment("UPDATED");

        T117ImgCoverSheetOverride existingEntity = new T117ImgCoverSheetOverride();
        existingEntity.setApplication(100);
        existingEntity.setName("TestSheet");
        existingEntity.setSequence(1);
        existingEntity.setDescription("Old Description");
        existingEntity.setTemplate("Old Template");

        T117ImgCoverSheetOverride updatedEntity = new T117ImgCoverSheetOverride();
        updatedEntity.setApplication(100);
        updatedEntity.setName("TestSheet");
        updatedEntity.setSequence(1);
        updatedEntity.setDescription("Updated Description");
        updatedEntity.setSb1("Updated SB1");
        updatedEntity.setEb1("Updated EB1");
        updatedEntity.setEb2("Updated EB2");
        updatedEntity.setEb3("Updated EB3");
        updatedEntity.setTitle("Updated Title");
        updatedEntity.setStitle1("Updated Subtitle1");
        updatedEntity.setStitle2("Updated Subtitle2");
        updatedEntity.setUnit("Updated Unit");
        updatedEntity.setRcode("Updated RCode");
        updatedEntity.setTemplate("Updated Template");
        updatedEntity.setActive("Y");
        updatedEntity.setEnvironment("UPDATED");

        when(coverSheetOverrideRepo.findByAppNameSequence(100, "TestSheet", 1)).thenReturn(Optional.of(existingEntity));
        when(coverSheetOverrideRepo.save(any(T117ImgCoverSheetOverride.class))).thenReturn(updatedEntity);

        // Act
        CoverSheetOverrideDTO result = coversheetService.updateOverride(inputDto);

        // Assert
        assertNotNull(result);
        assertEquals(inputDto.getApplication(), result.getApplication());
        assertEquals(inputDto.getName(), result.getName());
        assertEquals(inputDto.getSequence(), result.getSequence());
        assertEquals(inputDto.getDescription(), result.getDescription());
        assertEquals(inputDto.getSb1(), result.getSb1());
        assertEquals(inputDto.getEb1(), result.getEb1());
        assertEquals(inputDto.getEb2(), result.getEb2());
        assertEquals(inputDto.getEb3(), result.getEb3());
        assertEquals(inputDto.getTitle(), result.getTitle());
        assertEquals(inputDto.getStitle1(), result.getStitle1());
        assertEquals(inputDto.getStitle2(), result.getStitle2());
        assertEquals(inputDto.getUnit(), result.getUnit());
        assertEquals(inputDto.getRcode(), result.getRcode());
        assertEquals(inputDto.getTemplate(), result.getTemplate());
        assertEquals(inputDto.getActive(), result.getActive());
        assertEquals(inputDto.getEnvironment(), result.getEnvironment());

        verify(coverSheetOverrideRepo, times(1)).findByAppNameSequence(100, "TestSheet", 1);
        verify(coverSheetOverrideRepo, times(1)).save(any(T117ImgCoverSheetOverride.class));
    }

    @Test
    void deleteOverride_ValidId_SetsActiveToN() {
        // Arrange
        T117ImgCoverSheetOverrideId id = new T117ImgCoverSheetOverrideId();
        id.setApplication(100);
        id.setName("TestSheet");
        id.setSequence(1);
        
        when(coverSheetOverrideRepo.getOne(id)).thenReturn(mockOverride);
        when(coverSheetOverrideRepo.save(any(T117ImgCoverSheetOverride.class))).thenReturn(mockOverride);

        // Act
        coversheetService.deleteOverride(id);

        // Assert
        verify(coverSheetOverrideRepo, times(1)).getOne(id);
        verify(coverSheetOverrideRepo, times(1)).save(any(T117ImgCoverSheetOverride.class));
    }

    @Test
    void getAllApplicationsByDepartment_ValidInputs_ReturnsApplications() {
        // Arrange
        List<String> groups = Arrays.asList("TestPrintGroup");
        List<T117ImgCoverAppl> applications = Arrays.asList(mockApplication);
        when(applicationRepository.findAllByDepartmentIdAndPrintGroupIn(1, groups)).thenReturn(applications);

        // Act
        List<CoverSheetApplicationDTO> result = coversheetService.getAllApplicationsByDepartment(1, groups);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(applicationRepository, times(1)).findAllByDepartmentIdAndPrintGroupIn(1, groups);
    }

    @Test
    void getApplicationsById_ValidId_ReturnsApplication() {
        // Arrange
        List<String> groups = Arrays.asList("TestPrintGroup");
        when(applicationRepository.findApplicationByIdAndPrintGroupIn(1, groups)).thenReturn(Optional.of(mockApplication));

        // Act
        CoverSheetApplicationDTO result = coversheetService.getApplicationsById(1, groups);

        // Assert
        assertNotNull(result);
        assertEquals(mockApplication.getApplication(), result.getApplication());
        verify(applicationRepository, times(1)).findApplicationByIdAndPrintGroupIn(1, groups);
    }

    @Test
    void getApplicationsById_NullId_ThrowsException() {
        // Arrange
        List<String> groups = Arrays.asList("TestPrintGroup");

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetService.getApplicationsById(null, groups);
        });

        assertEquals("Application ID must not be null", exception.getMessage());
        verify(applicationRepository, never()).findApplicationByIdAndPrintGroupIn(any(), any());
    }

    @Test
    void saveApplication_ValidDTO_ReturnsSavedApplication() {
        // Arrange
        CoverSheetApplicationDTO inputDTO = new CoverSheetApplicationDTO();
        inputDTO.setApplication(100);
        inputDTO.setDescription("Test Application");
        
        when(applicationRepository.save(any(T117ImgCoverAppl.class))).thenReturn(mockApplication);

        // Act
        CoverSheetApplicationDTO result = coversheetService.saveApplication(inputDTO);

        // Assert
        assertNotNull(result);
        verify(applicationRepository, times(1)).save(any(T117ImgCoverAppl.class));
    }

    @Test
    void deleteApplication_ValidId_SetsActiveToN() {
        // Arrange
        when(applicationRepository.getOne(1)).thenReturn(mockApplication);
        when(applicationRepository.save(any(T117ImgCoverAppl.class))).thenReturn(mockApplication);

        // Act
        coversheetService.deleteApplication(1);

        // Assert
        verify(applicationRepository, times(1)).getOne(1);
        verify(applicationRepository, times(1)).save(any(T117ImgCoverAppl.class));
    }

    @Test
    void getCoverSheet_WithOverride_ReturnsFileResult() {
        // Arrange
        when(coverSheetOverrideRepo.findByAppNameSequence(100, "TestApp", 1)).thenReturn(Optional.of(mockOverride));
        when(templateRepository.findByNameIgnoreCase("TestTemplate")).thenReturn(Optional.of(mockTemplate));

        // Act
        CoversheetFileResult result = coversheetService.getCoverSheet(100, 1, "TestApp", true);

        // Assert
        assertNotNull(result);
        assertEquals("application/pdf", result.getMimeType());
        assertEquals("TestTemplate.pdf", result.getFilename());
        assertNotNull(result.getData());
        verify(coverSheetOverrideRepo, times(1)).findByAppNameSequence(100, "TestApp", 1);
        verify(templateRepository, times(1)).findByNameIgnoreCase("TestTemplate");
    }

    @Test
    void getCoverSheet_WithoutOverride_ReturnsFileResult() {
        // Arrange
        when(coverSheetRepo.findByApplicationAndName(100, "TestApp")).thenReturn(Optional.of(mockCoverSheet));
        when(templateRepository.findByNameIgnoreCase("TestTemplate")).thenReturn(Optional.of(mockTemplate));

        // Act
        CoversheetFileResult result = coversheetService.getCoverSheet(100, 1, "TestApp", false);

        // Assert
        assertNotNull(result);
        assertEquals("application/pdf", result.getMimeType());
        assertEquals("TestTemplate.pdf", result.getFilename());
        verify(coverSheetRepo, times(1)).findByApplicationAndName(100, "TestApp");
        verify(templateRepository, times(1)).findByNameIgnoreCase("TestTemplate");
    }

    @Test
    void saveNewCoverSheetTemplate_ValidTemplate_SavesTemplate() {
        // Arrange
        T117ImgCoverObject template = new T117ImgCoverObject();
        template.setObjName("newtemplate");
        template.setObjType("pdf");
        template.setObjData("template data");
        
        when(templateRepository.save(any(T117ImgCoverObject.class))).thenReturn(template);

        // Act
        coversheetService.saveNewCoverSheetTemplate(template);

        // Assert
        verify(templateRepository, times(1)).save(any(T117ImgCoverObject.class));
        assertEquals("NEWTEMPLATE", template.getObjName());
        assertEquals("PDF", template.getObjType());
        assertEquals("Y", template.getActive());
    }

    @Test
    void saveNewCoverSheetTemplate_NullName_ThrowsException() {
        // Arrange
        T117ImgCoverObject template = new T117ImgCoverObject();
        template.setObjType("PDF");

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetService.saveNewCoverSheetTemplate(template);
        });

        assertEquals("Template name cannot be empty", exception.getMessage());
        verify(templateRepository, never()).save(any());
    }

    @Test
    void updateCoverSheetTemplate_ValidTemplate_ReturnsUpdateCount() {
        // Arrange
        T117ImgCoverObject template = new T117ImgCoverObject();
        template.setObjName("TestTemplate");
        template.setObjType("PDF");
        template.setMimeType("application/pdf");
        template.setObjData("updated data");
        
        when(templateRepository.updateTemplate(anyString(), anyString(), anyString(), anyString())).thenReturn(1);

        // Act
        int result = coversheetService.updateCoverSheetTemplate(template);

        // Assert
        assertEquals(1, result);
        verify(templateRepository, times(1)).updateTemplate("TestTemplate", "PDF", "application/pdf", "updated data");
    }

    @Test
    void getOverrideApplSequence_ReturnsNextSequence() {
        // Arrange
        when(coverSheetOverrideRepo.findMaxSequenceByApplicationAndName(100, "TestApp")).thenReturn(5);

        // Act
        int result = coversheetService.getOverrideApplSequence(100, "TestApp");

        // Assert
        assertEquals(6, result);
        verify(coverSheetOverrideRepo, times(1)).findMaxSequenceByApplicationAndName(100, "TestApp");
    }

    @Test
    void getCoversheetByApplicationId_ReturnsCoversheetsForApplication() {
        // Arrange
        List<T117ImgCoverSheet> coverSheets = Arrays.asList(mockCoverSheet);
        when(coverSheetRepo.findAllByApplication(100)).thenReturn(coverSheets);

        // Act
        List<CoverSheetDTO> result = coversheetService.getCoversheetByApplicationId(100);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(coverSheetRepo, times(1)).findAllByApplication(100);
    }

    @Test
    void getAllOverridesByApplicationId_ReturnsOverridesForApplication() {
        // Arrange
        List<T117ImgCoverSheetOverride> overrides = Arrays.asList(mockOverride);
        when(coverSheetOverrideRepo.findAllByApplication(100)).thenReturn(overrides);

        // Act
        List<CoverSheetOverrideDTO> result = coversheetService.getAllOverridesByApplicationId(100);

        // Assert
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(coverSheetOverrideRepo, times(1)).findAllByApplication(100);
    }

    @Test
    void getCoverApplSequence_ReturnsNextApplicationSequence() {
        // Arrange
        when(applicationRepository.findMaxApplication()).thenReturn(999);

        // Act
        int result = coversheetService.getCoverApplSequence();

        // Assert
        assertEquals(1000, result);
        verify(applicationRepository, times(1)).findMaxApplication();
    }
}