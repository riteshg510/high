package com.hmhs.hvwmid.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HvwDataRefreshTest {

    private HvwDataRefresh hvwDataRefresh;

    @BeforeEach
    void setUp() throws NoSuchFieldException, IllegalAccessException {
        hvwDataRefresh = new HvwDataRefresh();

        Field field = HvwDataRefresh.class.getDeclaredField("parmDataMapByCmodbase");
        field.setAccessible(true);

        Map<String, String> mockParmDataMap = new HashMap<>();
        mockParmDataMap.put("key1", "value1");
        mockParmDataMap.put("key2", "value2");

        field.set(hvwDataRefresh, mockParmDataMap);
    }

    @Test
    void testGetParmDataByKeyByCmodbase_KeyExists() {
        String result = hvwDataRefresh.getParmDataByKeyByCmodbase("key1", "defaultValue");

        assertEquals("value1", result, "Expected value for key1");
    }

    @Test
    void testGetParmDataByKeyByCmodbase_KeyDoesNotExist() {
        String result = hvwDataRefresh.getParmDataByKeyByCmodbase("nonExistentKey", "defaultValue");

        assertEquals("defaultValue", result, "Expected default value for non-existent key");
    }

    @Test
    void testGetParmDataByKeyByCmodbase_EmptyMap() throws NoSuchFieldException, IllegalAccessException {
        Field field = HvwDataRefresh.class.getDeclaredField("parmDataMapByCmodbase");
        field.setAccessible(true);

        field.set(hvwDataRefresh, new HashMap<>());

        String result = hvwDataRefresh.getParmDataByKeyByCmodbase("anyKey", "defaultValue");

        assertEquals("defaultValue", result, "Expected default value when map is empty");
    }
}
