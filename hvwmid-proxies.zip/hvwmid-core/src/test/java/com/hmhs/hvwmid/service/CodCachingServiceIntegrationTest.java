package com.hmhs.hvwmid.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.TestConfiguration;          // ← corrected
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.hmhs.hvwmid.entity.TblCodObject;
import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.repository.CodObjectRepository;
import com.hmhs.hvwmid.repository.CodTokenRepository;


//@SpringBootTest(classes = {CachingService.class, CachingServiceIntegrationTest.SeqGenStubConfig.class, CodTokenRepository.class})
@AutoConfigureTestDatabase(replace = Replace.ANY)  // use H2 in-memory

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        CodCachingService.class,
        CodCachingServiceIntegrationTest.SeqGenStubConfig.class,
        CodTokenRepository.class,
})
@Transactional  // roll back after each test
class CodCachingServiceIntegrationTest {

    @Autowired
    private CodCachingService codCachingService;

//    @Autowired
    @MockBean
    private CodTokenRepository tokenRepo;

   // @Autowired
   @MockBean
    private CodObjectRepository objectRepo;

    @TestConfiguration
    static class SeqGenStubConfig {
        @Bean @Primary
        public GenericUDFService seqGenStub() {
            return new GenericUDFService(null, "DB2222055A_UDF") {
                private final AtomicInteger counter = new AtomicInteger(0);
                @Override
                public int generateRequestId(String env) {
                    return counter.incrementAndGet();
                }
            };
        }
    }

    @Value("${cleanup.token.retention-days:7}")
    private long retentionDays;

    // @Test
    // void cacheAndStream_splitsIntoCorrectChunksAndReassembles() throws IOException {
    //     // 1) Prepare a 100 KiB payload
    //     int totalSize = 100 * 1024;
    //     byte[] original = new byte[totalSize];
    //     new Random(0).nextBytes(original);
    //     ByteArrayInputStream in = new ByteArrayInputStream(original);

    //     // 2) Cache it
    //     String userId = "test-user";
    //     String docToken = "test-doc";
    //     String securityToken = "jwt-token";
    //     int requestId = codCachingService.cacheDocument(in, userId, docToken, securityToken);

    //     // 3) Verify CodToken row
    //     Optional<TblCodToken> maybeToken = tokenRepo.findById(requestId);
    //     assertThat(maybeToken)
    //             .as("CodToken created")
    //             .isPresent();
    //     TblCodToken tok = maybeToken.get();
    //     assertThat(tok.getUserId()).isEqualTo(userId);
    //     assertThat(tok.getDocumentToken()).isEqualTo(docToken);

    //     // 4) Verify chunking
    //     List<TblCodObject> chunks = objectRepo.findByRequestIdOrderBySequenceNo(requestId);
    //     int expectedChunks = (totalSize + (32*1024 - 1)) / (32*1024);
    //     assertThat(chunks)
    //             .as("Number of chunks")
    //             .hasSize(expectedChunks);

    //     // 5) Reassemble from repository and compare
    //     ByteArrayOutputStream assembled = new ByteArrayOutputStream(totalSize);
    //     for (TblCodObject c : chunks) {
    //         assembled.write(c.getObjectSegment());
    //     }
    //     assertThat(assembled.toByteArray())
    //             .as("Reassembled payload matches original")
    //             .isEqualTo(original);

    //     // 6) Now stream via the service and compare again
    //     StreamingResponseBody body = codCachingService.streamDocument(userId, docToken);
    //     ByteArrayOutputStream streamed = new ByteArrayOutputStream(totalSize);
    //     body.writeTo(streamed);

    //     assertThat(streamed.toByteArray())
    //             .as("Streamed payload matches original")
    //             .isEqualTo(original);
    // }
}
