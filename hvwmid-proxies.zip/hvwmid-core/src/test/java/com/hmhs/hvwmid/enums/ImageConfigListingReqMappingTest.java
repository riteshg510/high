package com.hmhs.hvwmid.enums;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.HashSet;
import java.util.Set;



class ImageConfigListingReqMappingTest {

    @Test
    void allMembersHaveNonNullAndNonBlankFields() {
        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            assertNotNull(m.getQueryField(), () -> m.name() + " queryField null");
            assertNotNull(m.getDisplayField(), () -> m.name() + " displayField null");
            assertNotNull(m.getOutputField(), () -> m.name() + " outputField null");
            assertNotNull(m.getColumnHeader(), () -> m.name() + " columnHeader null");
            assertNotNull(m.getSearchStringField(), () -> m.name() + " searchStringField null");
            assertNotNull(m.getGroupName(), () -> m.name() + " groupName null");
            assertNotNull(m.getColumnName(), () -> m.name() + " columnName null");
            assertNotNull(m.getAlias(), () -> m.name() + " alias null");

            assertFalse(m.getQueryField().isBlank(), () -> m.name() + " queryField blank");
            assertFalse(m.getDisplayField().isBlank(), () -> m.name() + " displayField blank");
            assertFalse(m.getOutputField().isBlank(), () -> m.name() + " outputField blank");
            assertFalse(m.getColumnHeader().isBlank(), () -> m.name() + " columnHeader blank");
            assertFalse(m.getSearchStringField().isBlank(), () -> m.name() + " searchStringField blank");
            assertFalse(m.getGroupName().isBlank(), () -> m.name() + " groupName blank");
            assertFalse(m.getColumnName().isBlank(), () -> m.name() + " columnName blank");
            assertFalse(m.getAlias().isBlank(), () -> m.name() + " alias blank");
        }
    }

    @Test
    void namingConventionsHoldForQueryAndDisplay() {
        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            assertTrue(m.getQueryField().endsWith("Query"),
                    () -> m.name() + " queryField should end with 'Query' but was: " + m.getQueryField());
            assertTrue(m.getDisplayField().endsWith("Display"),
                    () -> m.name() + " displayField should end with 'Display' but was: " + m.getDisplayField());
        }
    }

    @Test
    void aliasAndColumnNameCombinationIsUnique() {
        Set<String> seen = new HashSet<>();
        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            String key = m.getAlias() + "::" + m.getColumnName();
            assertTrue(seen.add(key), () ->
                    "Duplicate alias+columnName pair found: " + key + " (member: " + m.name() + ")");
        }
    }

    @Test
    void atLeastOneUsesNaAsSearchStringField() {
        boolean foundNa = false;
        for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
            if ("na".equalsIgnoreCase(m.getSearchStringField())) {
                foundNa = true;
                break;
            }
        }
        assertTrue(foundNa, "Expected at least one enum member to have searchStringField='na'");
    }

    @Test
    void sanityCheckForSomeKeyMembers() {
        // ENTTTLPR_APPLIDCD
        ImageConfigListingReqMapping applIdCd = ImageConfigListingReqMapping.ENTTTLPR_APPLIDCD;
        assertEquals("lprApplIdCdQuery", applIdCd.getQueryField());
        assertEquals("lprApplIdCdDisplay", applIdCd.getDisplayField());
        assertEquals("APPLIDCD", applIdCd.getColumnName());
        assertEquals("LPR", applIdCd.getAlias());
        assertEquals("na", applIdCd.getSearchStringField());

        // BATCHTBL_BPRIORITY
        ImageConfigListingReqMapping bpriority = ImageConfigListingReqMapping.BATCHTBL_BPRIORITY;
        assertEquals("na", bpriority.getSearchStringField());

        // ENTTTFRM_FORMNUM
        ImageConfigListingReqMapping frmFormNum = ImageConfigListingReqMapping.ENTTTFRM_FORMNUM;
        assertEquals("frmFormNumSearchOperator", frmFormNum.getSearchStringField());
        assertEquals("FRM", frmFormNum.getAlias());
        assertEquals("FORMNUM", frmFormNum.getColumnName());
    }
}
