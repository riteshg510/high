package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMIUISearchRequest POJO
 * Tests all getters, setters, and legacy fields
 * 
 */
class IMIUISearchRequestTest {

    private IMIUISearchRequest imiUISearchRequest;

    @BeforeEach
    void setUp() {
        imiUISearchRequest = new IMIUISearchRequest();
    }

    // ========== CORE FIELDS TESTS ==========

    @Test
    void testNaicCodeGetterAndSetter() {
        String naicCode = "TEST_NAIC";
        imiUISearchRequest.setNaicCode(naicCode);
        assertEquals(naicCode, imiUISearchRequest.getNaicCode());
    }

    @Test
    void testBeginDateGetterAndSetter() {
        String begindate = "2023-01-01";
        imiUISearchRequest.setBegindate(begindate);
        assertEquals(begindate, imiUISearchRequest.getBegindate());
    }

    @Test
    void testStartTimeHourGetterAndSetter() {
        String startTimeHour = "10";
        imiUISearchRequest.setStartTimeHour(startTimeHour);
        assertEquals(startTimeHour, imiUISearchRequest.getStartTimeHour());
    }

    @Test
    void testStartTimeMinGetterAndSetter() {
        String startTimeMin = "30";
        imiUISearchRequest.setStartTimeMin(startTimeMin);
        assertEquals(startTimeMin, imiUISearchRequest.getStartTimeMin());
    }

    @Test
    void testEndDateGetterAndSetter() {
        String enddate = "2023-12-31";
        imiUISearchRequest.setEnddate(enddate);
        assertEquals(enddate, imiUISearchRequest.getEnddate());
    }

    @Test
    void testEndTimeHourGetterAndSetter() {
        String endTimeHour = "23";
        imiUISearchRequest.setEndTimeHour(endTimeHour);
        assertEquals(endTimeHour, imiUISearchRequest.getEndTimeHour());
    }

    @Test
    void testEndTimeMinGetterAndSetter() {
        String endTimeMin = "59";
        imiUISearchRequest.setEndTimeMin(endTimeMin);
        assertEquals(endTimeMin, imiUISearchRequest.getEndTimeMin());
    }

    @Test
    void testSubmitTopGetterAndSetter() {
        String submitTop = "submit";
        imiUISearchRequest.setSubmitTop(submitTop);
        assertEquals(submitTop, imiUISearchRequest.getSubmitTop());
    }

    @Test
    void testAllFieldsSelUnSelTopGetterAndSetter() {
        imiUISearchRequest.setAllFieldsSelUnSelTop(true);
        assertTrue(imiUISearchRequest.isAllFieldsSelUnSelTop());
        
        imiUISearchRequest.setAllFieldsSelUnSelTop(false);
        assertFalse(imiUISearchRequest.isAllFieldsSelUnSelTop());
    }

    @Test
    void testAllFieldsSelUnSelBottomGetterAndSetter() {
        imiUISearchRequest.setAllFieldsSelUnSelBottom(true);
        assertTrue(imiUISearchRequest.isAllFieldsSelUnSelBottom());
        
        imiUISearchRequest.setAllFieldsSelUnSelBottom(false);
        assertFalse(imiUISearchRequest.isAllFieldsSelUnSelBottom());
    }

    // ========== TRANSMIT FILE FIELDS TESTS ==========

    @Test
    void testTransmitFileIdQueryGetterAndSetter() {
        String transmitFileIdQuery = "123456";
        imiUISearchRequest.setTransmitFileIdQuery(transmitFileIdQuery);
        assertEquals(transmitFileIdQuery, imiUISearchRequest.getTransmitFileIdQuery());
    }

    @Test
    void testTransmitFileIdSearchOperatorGetterAndSetter() {
        String transmitFileIdSearchOperator = "EQ";
        imiUISearchRequest.setTransmitFileIdSearchOperator(transmitFileIdSearchOperator);
        assertEquals(transmitFileIdSearchOperator, imiUISearchRequest.getTransmitFileIdSearchOperator());
    }

    @Test
    void testTransmitFileIdDisplayGetterAndSetter() {
        imiUISearchRequest.setTransmitFileIdDisplay(true);
        assertTrue(imiUISearchRequest.isTransmitFileIdDisplay());
        
        imiUISearchRequest.setTransmitFileIdDisplay(false);
        assertFalse(imiUISearchRequest.isTransmitFileIdDisplay());
    }

    @Test
    void testTransmitFileNameQueryGetterAndSetter() {
        String transmitFileNameQuery = "test_file.txt";
        imiUISearchRequest.setTransmitFileNameQuery(transmitFileNameQuery);
        assertEquals(transmitFileNameQuery, imiUISearchRequest.getTransmitFileNameQuery());
    }

    @Test
    void testTransmitFileNameSearchOperatorGetterAndSetter() {
        String transmitFileNameSearchOperator = "LK";
        imiUISearchRequest.setTransmitFileNameSearchOperator(transmitFileNameSearchOperator);
        assertEquals(transmitFileNameSearchOperator, imiUISearchRequest.getTransmitFileNameSearchOperator());
    }

    @Test
    void testTransmitFileNameDisplayGetterAndSetter() {
        imiUISearchRequest.setTransmitFileNameDisplay(true);
        assertTrue(imiUISearchRequest.isTransmitFileNameDisplay());
        
        imiUISearchRequest.setTransmitFileNameDisplay(false);
        assertFalse(imiUISearchRequest.isTransmitFileNameDisplay());
    }

    @Test
    void testTransmitFileStatusCdQueryGetterAndSetter() {
        String transmitFileStatusCdQuery = "A";
        imiUISearchRequest.setTransmitFileStatusCdQuery(transmitFileStatusCdQuery);
        assertEquals(transmitFileStatusCdQuery, imiUISearchRequest.getTransmitFileStatusCdQuery());
    }

    @Test
    void testTransmitFileStatusCdSearchOperatorGetterAndSetter() {
        String transmitFileStatusCdSearchOperator = "EQ";
        imiUISearchRequest.setTransmitFileStatusCdSearchOperator(transmitFileStatusCdSearchOperator);
        assertEquals(transmitFileStatusCdSearchOperator, imiUISearchRequest.getTransmitFileStatusCdSearchOperator());
    }

    @Test
    void testTransmitFileStatusCdDisplayGetterAndSetter() {
        imiUISearchRequest.setTransmitFileStatusCdDisplay(true);
        assertTrue(imiUISearchRequest.isTransmitFileStatusCdDisplay());
        
        imiUISearchRequest.setTransmitFileStatusCdDisplay(false);
        assertFalse(imiUISearchRequest.isTransmitFileStatusCdDisplay());
    }

    // ========== IMI FILE FIELDS TESTS ==========

    @Test
    void testImiFileIdQueryGetterAndSetter() {
        String imiFileIdQuery = "789";
        imiUISearchRequest.setImiFileIdQuery(imiFileIdQuery);
        assertEquals(imiFileIdQuery, imiUISearchRequest.getImiFileIdQuery());
    }

    @Test
    void testImiFileIdSearchOperatorGetterAndSetter() {
        String imiFileIdSearchOperator = "GT";
        imiUISearchRequest.setImiFileIdSearchOperator(imiFileIdSearchOperator);
        assertEquals(imiFileIdSearchOperator, imiUISearchRequest.getImiFileIdSearchOperator());
    }

    @Test
    void testImiFileIdDisplayGetterAndSetter() {
        imiUISearchRequest.setImiFileIdDisplay(true);
        assertTrue(imiUISearchRequest.isImiFileIdDisplay());
        
        imiUISearchRequest.setImiFileIdDisplay(false);
        assertFalse(imiUISearchRequest.isImiFileIdDisplay());
    }

    // ========== PLAN FILE FIELDS TESTS ==========

    @Test
    void testPlanFileIdQueryGetterAndSetter() {
        String planFileIdQuery = "PLAN123";
        imiUISearchRequest.setPlanFileIdQuery(planFileIdQuery);
        assertEquals(planFileIdQuery, imiUISearchRequest.getPlanFileIdQuery());
    }

    @Test
    void testPlanFileIdSearchOperatorGetterAndSetter() {
        String planFileIdSearchOperator = "EQ";
        imiUISearchRequest.setPlanFileIdSearchOperator(planFileIdSearchOperator);
        assertEquals(planFileIdSearchOperator, imiUISearchRequest.getPlanFileIdSearchOperator());
    }

    @Test
    void testPlanFileIdDisplayGetterAndSetter() {
        imiUISearchRequest.setPlanFileIdDisplay(true);
        assertTrue(imiUISearchRequest.isPlanFileIdDisplay());
        
        imiUISearchRequest.setPlanFileIdDisplay(false);
        assertFalse(imiUISearchRequest.isPlanFileIdDisplay());
    }

    // ========== PROCESS FILE FIELDS TESTS ==========

    @Test
    void testProcessFileNameQueryGetterAndSetter() {
        String processFileNameQuery = "process.log";
        imiUISearchRequest.setProcessFileNameQuery(processFileNameQuery);
        assertEquals(processFileNameQuery, imiUISearchRequest.getProcessFileNameQuery());
    }

    @Test
    void testProcessFileNameSearchOperatorGetterAndSetter() {
        String processFileNameSearchOperator = "LK";
        imiUISearchRequest.setProcessFileNameSearchOperator(processFileNameSearchOperator);
        assertEquals(processFileNameSearchOperator, imiUISearchRequest.getProcessFileNameSearchOperator());
    }

    @Test
    void testProcessFileNameDisplayGetterAndSetter() {
        imiUISearchRequest.setProcessFileNameDisplay(true);
        assertTrue(imiUISearchRequest.isProcessFileNameDisplay());
        
        imiUISearchRequest.setProcessFileNameDisplay(false);
        assertFalse(imiUISearchRequest.isProcessFileNameDisplay());
    }

    @Test
    void testProcessFileStatusCdQueryGetterAndSetter() {
        String processFileStatusCdQuery = "C";
        imiUISearchRequest.setProcessFileStatusCdQuery(processFileStatusCdQuery);
        assertEquals(processFileStatusCdQuery, imiUISearchRequest.getProcessFileStatusCdQuery());
    }

    @Test
    void testProcessFileStatusCdSearchOperatorGetterAndSetter() {
        String processFileStatusCdSearchOperator = "EQ";
        imiUISearchRequest.setProcessFileStatusCdSearchOperator(processFileStatusCdSearchOperator);
        assertEquals(processFileStatusCdSearchOperator, imiUISearchRequest.getProcessFileStatusCdSearchOperator());
    }

    @Test
    void testProcessFileStatusCdDisplayGetterAndSetter() {
        imiUISearchRequest.setProcessFileStatusCdDisplay(true);
        assertTrue(imiUISearchRequest.isProcessFileStatusCdDisplay());
        
        imiUISearchRequest.setProcessFileStatusCdDisplay(false);
        assertFalse(imiUISearchRequest.isProcessFileStatusCdDisplay());
    }

    @Test
    void testProcessFileReasonCdQueryGetterAndSetter() {
        String processFileReasonCdQuery = "REASON1";
        imiUISearchRequest.setProcessFileReasonCdQuery(processFileReasonCdQuery);
        assertEquals(processFileReasonCdQuery, imiUISearchRequest.getProcessFileReasonCdQuery());
    }

    @Test
    void testProcessFileReasonSearchOperatorGetterAndSetter() {
        String processFileReasonSearchOperator = "EQ";
        imiUISearchRequest.setProcessFileReasonSearchOperator(processFileReasonSearchOperator);
        assertEquals(processFileReasonSearchOperator, imiUISearchRequest.getProcessFileReasonSearchOperator());
    }

    @Test
    void testProcessFileReasonCdDescGetterAndSetter() {
        String processFileReasonCdDesc = "Process File Reason Description";
        imiUISearchRequest.setProcessFileReasonCdDesc(processFileReasonCdDesc);
        assertEquals(processFileReasonCdDesc, imiUISearchRequest.getProcessFileReasonCdDesc());
    }

    @Test
    void testProcessFileReasonCdDisplayGetterAndSetter() {
        imiUISearchRequest.setProcessFileReasonCdDisplay(true);
        assertTrue(imiUISearchRequest.isProcessFileReasonCdDisplay());
        
        imiUISearchRequest.setProcessFileReasonCdDisplay(false);
        assertFalse(imiUISearchRequest.isProcessFileReasonCdDisplay());
    }

    @Test
    void testProcessFileReasonCdSearchOperatorGetterAndSetter() {
        String processFileReasonCdSearchOperator = "LK";
        imiUISearchRequest.setProcessFileReasonCdSearchOperator(processFileReasonCdSearchOperator);
        assertEquals(processFileReasonCdSearchOperator, imiUISearchRequest.getProcessFileReasonCdSearchOperator());
    }

    // ========== DOCUMENT FIELDS TESTS ==========

    @Test
    void testImiDocumentIdQueryGetterAndSetter() {
        String imiDocumentIdQuery = "999";
        imiUISearchRequest.setImiDocumentIdQuery(imiDocumentIdQuery);
        assertEquals(imiDocumentIdQuery, imiUISearchRequest.getImiDocumentIdQuery());
    }

    @Test
    void testImiDocumentIdSearchOperatorGetterAndSetter() {
        String imiDocumentIdSearchOperator = "LT";
        imiUISearchRequest.setImiDocumentIdSearchOperator(imiDocumentIdSearchOperator);
        assertEquals(imiDocumentIdSearchOperator, imiUISearchRequest.getImiDocumentIdSearchOperator());
    }

    @Test
    void testImiDocumentIdDisplayGetterAndSetter() {
        imiUISearchRequest.setImiDocumentIdDisplay(true);
        assertTrue(imiUISearchRequest.isImiDocumentIdDisplay());
        
        imiUISearchRequest.setImiDocumentIdDisplay(false);
        assertFalse(imiUISearchRequest.isImiDocumentIdDisplay());
    }

    @Test
    void testDocumentStatusCdQueryGetterAndSetter() {
        String documentStatusCdQuery = "S";
        imiUISearchRequest.setDocumentStatusCdQuery(documentStatusCdQuery);
        assertEquals(documentStatusCdQuery, imiUISearchRequest.getDocumentStatusCdQuery());
    }

    @Test
    void testDocumentStatusCdSearchOperatorGetterAndSetter() {
        String documentStatusCdSearchOperator = "EQ";
        imiUISearchRequest.setDocumentStatusCdSearchOperator(documentStatusCdSearchOperator);
        assertEquals(documentStatusCdSearchOperator, imiUISearchRequest.getDocumentStatusCdSearchOperator());
    }

    @Test
    void testDocumentStatusCdDisplayGetterAndSetter() {
        imiUISearchRequest.setDocumentStatusCdDisplay(true);
        assertTrue(imiUISearchRequest.isDocumentStatusCdDisplay());
        
        imiUISearchRequest.setDocumentStatusCdDisplay(false);
        assertFalse(imiUISearchRequest.isDocumentStatusCdDisplay());
    }

    @Test
    void testDocumentReasonCdQueryGetterAndSetter() {
        String documentReasonCdQuery = "DOC_REASON";
        imiUISearchRequest.setDocumentReasonCdQuery(documentReasonCdQuery);
        assertEquals(documentReasonCdQuery, imiUISearchRequest.getDocumentReasonCdQuery());
    }

    @Test
    void testDocumentReasonCdSearchOperatorGetterAndSetter() {
        String documentReasonCdSearchOperator = "EQ";
        imiUISearchRequest.setDocumentReasonCdSearchOperator(documentReasonCdSearchOperator);
        assertEquals(documentReasonCdSearchOperator, imiUISearchRequest.getDocumentReasonCdSearchOperator());
    }

    @Test
    void testDocumentReasonCdDisplayGetterAndSetter() {
        imiUISearchRequest.setDocumentReasonCdDisplay(true);
        assertTrue(imiUISearchRequest.isDocumentReasonCdDisplay());
        
        imiUISearchRequest.setDocumentReasonCdDisplay(false);
        assertFalse(imiUISearchRequest.isDocumentReasonCdDisplay());
    }

    @Test
    void testDocumentReasonSearchOperatorGetterAndSetter() {
        String documentReasonSearchOperator = "LK";
        imiUISearchRequest.setDocumentReasonSearchOperator(documentReasonSearchOperator);
        assertEquals(documentReasonSearchOperator, imiUISearchRequest.getDocumentReasonSearchOperator());
    }

    // ========== DCN AND DPK FIELDS TESTS ==========

    @Test
    void testPlanDCNQueryGetterAndSetter() {
        String planDCNQuery = "DCN123";
        imiUISearchRequest.setPlanDCNQuery(planDCNQuery);
        assertEquals(planDCNQuery, imiUISearchRequest.getPlanDCNQuery());
    }

    @Test
    void testPlanDCNSearchOperatorGetterAndSetter() {
        String planDCNSearchOperator = "EQ";
        imiUISearchRequest.setPlanDCNSearchOperator(planDCNSearchOperator);
        assertEquals(planDCNSearchOperator, imiUISearchRequest.getPlanDCNSearchOperator());
    }

    @Test
    void testPlanDCNDisplayGetterAndSetter() {
        imiUISearchRequest.setPlanDCNDisplay(true);
        assertTrue(imiUISearchRequest.isPlanDCNDisplay());
        
        imiUISearchRequest.setPlanDCNDisplay(false);
        assertFalse(imiUISearchRequest.isPlanDCNDisplay());
    }

    @Test
    void testDpkQueryGetterAndSetter() {
        String dpkQuery = "DPK456";
        imiUISearchRequest.setDpkQuery(dpkQuery);
        assertEquals(dpkQuery, imiUISearchRequest.getDpkQuery());
    }

    @Test
    void testDpkSearchOperatorGetterAndSetter() {
        String dpkSearchOperator = "EQ";
        imiUISearchRequest.setDpkSearchOperator(dpkSearchOperator);
        assertEquals(dpkSearchOperator, imiUISearchRequest.getDpkSearchOperator());
    }

    @Test
    void testDpkDisplayGetterAndSetter() {
        imiUISearchRequest.setDpkDisplay(true);
        assertTrue(imiUISearchRequest.isDpkDisplay());
        
        imiUISearchRequest.setDpkDisplay(false);
        assertFalse(imiUISearchRequest.isDpkDisplay());
    }

    @Test
    void testInitialProcessDCNQueryGetterAndSetter() {
        String initialProcessDCNQuery = "INITDCN";
        imiUISearchRequest.setInitialProcessDCNQuery(initialProcessDCNQuery);
        assertEquals(initialProcessDCNQuery, imiUISearchRequest.getInitialProcessDCNQuery());
    }

    @Test
    void testInitialProcessDCNSearchOperatorGetterAndSetter() {
        String initialProcessDCNSearchOperator = "EQ";
        imiUISearchRequest.setInitialProcessDCNSearchOperator(initialProcessDCNSearchOperator);
        assertEquals(initialProcessDCNSearchOperator, imiUISearchRequest.getInitialProcessDCNSearchOperator());
    }

    @Test
    void testInitialProcessDCNDisplayGetterAndSetter() {
        imiUISearchRequest.setInitialProcessDCNDisplay(true);
        assertTrue(imiUISearchRequest.isInitialProcessDCNDisplay());
        
        imiUISearchRequest.setInitialProcessDCNDisplay(false);
        assertFalse(imiUISearchRequest.isInitialProcessDCNDisplay());
    }

    @Test
    void testFinalProcessDCNQueryGetterAndSetter() {
        String finalProcessDCNQuery = "FINDCN";
        imiUISearchRequest.setFinalProcessDCNQuery(finalProcessDCNQuery);
        assertEquals(finalProcessDCNQuery, imiUISearchRequest.getFinalProcessDCNQuery());
    }

    @Test
    void testFinalProcessDCNSearchOperatorGetterAndSetter() {
        String finalProcessDCNSearchOperator = "EQ";
        imiUISearchRequest.setFinalProcessDCNSearchOperator(finalProcessDCNSearchOperator);
        assertEquals(finalProcessDCNSearchOperator, imiUISearchRequest.getFinalProcessDCNSearchOperator());
    }

    @Test
    void testFinalProcessDCNDisplayGetterAndSetter() {
        imiUISearchRequest.setFinalProcessDCNDisplay(true);
        assertTrue(imiUISearchRequest.isFinalProcessDCNDisplay());
        
        imiUISearchRequest.setFinalProcessDCNDisplay(false);
        assertFalse(imiUISearchRequest.isFinalProcessDCNDisplay());
    }

    // ========== APPLICATION AND CAPTURE FIELDS TESTS ==========

    @Test
    void testApplIdCdQueryGetterAndSetter() {
        String applIdCdQuery = "APPL1";
        imiUISearchRequest.setApplIdCdQuery(applIdCdQuery);
        assertEquals(applIdCdQuery, imiUISearchRequest.getApplIdCdQuery());
    }

    @Test
    void testApplIdCdSearchOperatorGetterAndSetter() {
        String applIdCdSearchOperator = "EQ";
        imiUISearchRequest.setApplIdCdSearchOperator(applIdCdSearchOperator);
        assertEquals(applIdCdSearchOperator, imiUISearchRequest.getApplIdCdSearchOperator());
    }

    @Test
    void testApplIdCdDisplayGetterAndSetter() {
        imiUISearchRequest.setApplIdCdDisplay(true);
        assertTrue(imiUISearchRequest.isApplIdCdDisplay());
        
        imiUISearchRequest.setApplIdCdDisplay(false);
        assertFalse(imiUISearchRequest.isApplIdCdDisplay());
    }

    @Test
    void testCaptureItemIdQueryGetterAndSetter() {
        String captureItemIdQuery = "CAPTURE1";
        imiUISearchRequest.setCaptureItemIdQuery(captureItemIdQuery);
        assertEquals(captureItemIdQuery, imiUISearchRequest.getCaptureItemIdQuery());
    }

    @Test
    void testCaptureItemIdSearchOperatorGetterAndSetter() {
        String captureItemIdSearchOperator = "EQ";
        imiUISearchRequest.setCaptureItemIdSearchOperator(captureItemIdSearchOperator);
        assertEquals(captureItemIdSearchOperator, imiUISearchRequest.getCaptureItemIdSearchOperator());
    }

    @Test
    void testCaptureItemIdDisplayGetterAndSetter() {
        imiUISearchRequest.setCaptureItemIdDisplay(true);
        assertTrue(imiUISearchRequest.isCaptureItemIdDisplay());
        
        imiUISearchRequest.setCaptureItemIdDisplay(false);
        assertFalse(imiUISearchRequest.isCaptureItemIdDisplay());
    }

    // ========== TIME FIELDS TESTS ==========

    @Test
    void testTimeAckQueryGetterAndSetter() {
        String timeAckQuery = "2023-01-01 10:00:00";
        imiUISearchRequest.setTimeAckQuery(timeAckQuery);
        assertEquals(timeAckQuery, imiUISearchRequest.getTimeAckQuery());
    }

    @Test
    void testTimeAckGetterAndSetter() {
        String timeAck = "2023-01-01 10:05:00";
        imiUISearchRequest.setTimeAck(timeAck);
        assertEquals(timeAck, imiUISearchRequest.getTimeAck());
    }

    @Test
    void testTimeAckDisplayGetterAndSetter() {
        imiUISearchRequest.setTimeAckDisplay(true);
        assertTrue(imiUISearchRequest.isTimeAckDisplay());
        
        imiUISearchRequest.setTimeAckDisplay(false);
        assertFalse(imiUISearchRequest.isTimeAckDisplay());
    }

    @Test
    void testTimeAckSearchOperatorGetterAndSetter() {
        String timeAckSearchOperator = "GT";
        imiUISearchRequest.setTimeAckSearchOperator(timeAckSearchOperator);
        assertEquals(timeAckSearchOperator, imiUISearchRequest.getTimeAckSearchOperator());
    }

    @Test
    void testTimeUpdateQueryGetterAndSetter() {
        String timeUpdateQuery = "2023-01-01 11:00:00";
        imiUISearchRequest.setTimeUpdateQuery(timeUpdateQuery);
        assertEquals(timeUpdateQuery, imiUISearchRequest.getTimeUpdateQuery());
    }

    @Test
    void testTimeUpdateSearchOperatorGetterAndSetter() {
        String timeUpdateSearchOperator = "LT";
        imiUISearchRequest.setTimeUpdateSearchOperator(timeUpdateSearchOperator);
        assertEquals(timeUpdateSearchOperator, imiUISearchRequest.getTimeUpdateSearchOperator());
    }

    @Test
    void testTimeUpdateDisplayGetterAndSetter() {
        imiUISearchRequest.setTimeUpdateDisplay(true);
        assertTrue(imiUISearchRequest.isTimeUpdateDisplay());
        
        imiUISearchRequest.setTimeUpdateDisplay(false);
        assertFalse(imiUISearchRequest.isTimeUpdateDisplay());
    }

    // ========== LEGACY FIELDS TESTS ==========

    @Test
    void testMemberIdGetterAndSetter() {
        String memberId = "MEMBER123";
        imiUISearchRequest.setMemberId(memberId);
        assertEquals(memberId, imiUISearchRequest.getMemberId());
    }

    @Test
    void testMemberIdDisplayGetterAndSetter() {
        imiUISearchRequest.setMemberIdDisplay(true);
        assertTrue(imiUISearchRequest.isMemberIdDisplay());
        
        imiUISearchRequest.setMemberIdDisplay(false);
        assertFalse(imiUISearchRequest.isMemberIdDisplay());
    }

    @Test
    void testMemberIdSearchOperatorGetterAndSetter() {
        String memberIdSearchOperator = "EQ";
        imiUISearchRequest.setMemberIdSearchOperator(memberIdSearchOperator);
        assertEquals(memberIdSearchOperator, imiUISearchRequest.getMemberIdSearchOperator());
    }

    @Test
    void testMemberIdTypeGetterAndSetter() {
        String memberIdType = "SSN";
        imiUISearchRequest.setMemberIdType(memberIdType);
        assertEquals(memberIdType, imiUISearchRequest.getMemberIdType());
    }

    @Test
    void testMemberIdTypeDisplayGetterAndSetter() {
        imiUISearchRequest.setMemberIdTypeDisplay(true);
        assertTrue(imiUISearchRequest.isMemberIdTypeDisplay());
        
        imiUISearchRequest.setMemberIdTypeDisplay(false);
        assertFalse(imiUISearchRequest.isMemberIdTypeDisplay());
    }

    @Test
    void testMemberIdTypeSearchOperatorGetterAndSetter() {
        String memberIdTypeSearchOperator = "EQ";
        imiUISearchRequest.setMemberIdTypeSearchOperator(memberIdTypeSearchOperator);
        assertEquals(memberIdTypeSearchOperator, imiUISearchRequest.getMemberIdTypeSearchOperator());
    }

    @Test
    void testDocumentTypeGetterAndSetter() {
        String documentType = "CLAIM";
        imiUISearchRequest.setDocumentType(documentType);
        assertEquals(documentType, imiUISearchRequest.getDocumentType());
    }

    @Test
    void testDocumentTypeDisplayGetterAndSetter() {
        imiUISearchRequest.setDocumentTypeDisplay(true);
        assertTrue(imiUISearchRequest.isDocumentTypeDisplay());
        
        imiUISearchRequest.setDocumentTypeDisplay(false);
        assertFalse(imiUISearchRequest.isDocumentTypeDisplay());
    }

    @Test
    void testDocumentTypeSearchOperatorGetterAndSetter() {
        String documentTypeSearchOperator = "EQ";
        imiUISearchRequest.setDocumentTypeSearchOperator(documentTypeSearchOperator);
        assertEquals(documentTypeSearchOperator, imiUISearchRequest.getDocumentTypeSearchOperator());
    }

    @Test
    void testDocumentIdGetterAndSetter() {
        String documentId = "DOC123";
        imiUISearchRequest.setDocumentId(documentId);
        assertEquals(documentId, imiUISearchRequest.getDocumentId());
    }

    @Test
    void testDocumentIdDisplayGetterAndSetter() {
        imiUISearchRequest.setDocumentIdDisplay(true);
        assertTrue(imiUISearchRequest.isDocumentIdDisplay());
        
        imiUISearchRequest.setDocumentIdDisplay(false);
        assertFalse(imiUISearchRequest.isDocumentIdDisplay());
    }

    @Test
    void testDocumentIdSearchOperatorGetterAndSetter() {
        String documentIdSearchOperator = "EQ";
        imiUISearchRequest.setDocumentIdSearchOperator(documentIdSearchOperator);
        assertEquals(documentIdSearchOperator, imiUISearchRequest.getDocumentIdSearchOperator());
    }

    // ========== NULL VALUE TESTS ==========

    @Test
    void testAllFieldsWithNullValues() {
        // Set all fields to null
        imiUISearchRequest.setNaicCode(null);
        imiUISearchRequest.setBegindate(null);
        imiUISearchRequest.setStartTimeHour(null);
        imiUISearchRequest.setStartTimeMin(null);
        imiUISearchRequest.setEnddate(null);
        imiUISearchRequest.setEndTimeHour(null);
        imiUISearchRequest.setEndTimeMin(null);
        imiUISearchRequest.setSubmitTop(null);
        imiUISearchRequest.setTransmitFileIdQuery(null);
        imiUISearchRequest.setTransmitFileIdSearchOperator(null);
        imiUISearchRequest.setTransmitFileNameQuery(null);
        imiUISearchRequest.setTransmitFileNameSearchOperator(null);
        imiUISearchRequest.setTransmitFileStatusCdQuery(null);
        imiUISearchRequest.setTransmitFileStatusCdSearchOperator(null);
        imiUISearchRequest.setImiFileIdQuery(null);
        imiUISearchRequest.setImiFileIdSearchOperator(null);
        imiUISearchRequest.setPlanFileIdQuery(null);
        imiUISearchRequest.setPlanFileIdSearchOperator(null);
        imiUISearchRequest.setProcessFileNameQuery(null);
        imiUISearchRequest.setProcessFileNameSearchOperator(null);
        imiUISearchRequest.setProcessFileStatusCdQuery(null);
        imiUISearchRequest.setProcessFileStatusCdSearchOperator(null);
        imiUISearchRequest.setImiDocumentIdQuery(null);
        imiUISearchRequest.setImiDocumentIdSearchOperator(null);
        imiUISearchRequest.setPlanDCNQuery(null);
        imiUISearchRequest.setPlanDCNSearchOperator(null);
        imiUISearchRequest.setDpkQuery(null);
        imiUISearchRequest.setDpkSearchOperator(null);
        imiUISearchRequest.setInitialProcessDCNQuery(null);
        imiUISearchRequest.setInitialProcessDCNSearchOperator(null);
        imiUISearchRequest.setFinalProcessDCNQuery(null);
        imiUISearchRequest.setFinalProcessDCNSearchOperator(null);
        imiUISearchRequest.setDocumentStatusCdQuery(null);
        imiUISearchRequest.setDocumentStatusCdSearchOperator(null);
        imiUISearchRequest.setApplIdCdQuery(null);
        imiUISearchRequest.setApplIdCdSearchOperator(null);
        imiUISearchRequest.setCaptureItemIdQuery(null);
        imiUISearchRequest.setCaptureItemIdSearchOperator(null);
        imiUISearchRequest.setProcessFileReasonCdQuery(null);
        imiUISearchRequest.setProcessFileReasonSearchOperator(null);
        imiUISearchRequest.setTimeAckQuery(null);
        imiUISearchRequest.setDocumentReasonSearchOperator(null);
        imiUISearchRequest.setMemberId(null);
        imiUISearchRequest.setMemberIdSearchOperator(null);
        imiUISearchRequest.setMemberIdType(null);
        imiUISearchRequest.setMemberIdTypeSearchOperator(null);
        imiUISearchRequest.setDocumentType(null);
        imiUISearchRequest.setDocumentTypeSearchOperator(null);
        imiUISearchRequest.setDocumentId(null);
        imiUISearchRequest.setDocumentIdSearchOperator(null);
        imiUISearchRequest.setProcessFileReasonCdDesc(null);
        imiUISearchRequest.setProcessFileReasonCdSearchOperator(null);
        imiUISearchRequest.setTimeAck(null);
        imiUISearchRequest.setTimeAckSearchOperator(null);
        imiUISearchRequest.setTimeUpdateQuery(null);
        imiUISearchRequest.setTimeUpdateSearchOperator(null);
        imiUISearchRequest.setDocumentReasonCdQuery(null);
        imiUISearchRequest.setDocumentReasonCdSearchOperator(null);

        // Verify all fields are null
        assertNull(imiUISearchRequest.getNaicCode());
        assertNull(imiUISearchRequest.getBegindate());
        assertNull(imiUISearchRequest.getStartTimeHour());
        assertNull(imiUISearchRequest.getStartTimeMin());
        assertNull(imiUISearchRequest.getEnddate());
        assertNull(imiUISearchRequest.getEndTimeHour());
        assertNull(imiUISearchRequest.getEndTimeMin());
        assertNull(imiUISearchRequest.getSubmitTop());
        assertNull(imiUISearchRequest.getTransmitFileIdQuery());
        assertNull(imiUISearchRequest.getTransmitFileIdSearchOperator());
        assertNull(imiUISearchRequest.getTransmitFileNameQuery());
        assertNull(imiUISearchRequest.getTransmitFileNameSearchOperator());
        assertNull(imiUISearchRequest.getTransmitFileStatusCdQuery());
        assertNull(imiUISearchRequest.getTransmitFileStatusCdSearchOperator());
        assertNull(imiUISearchRequest.getImiFileIdQuery());
        assertNull(imiUISearchRequest.getImiFileIdSearchOperator());
        assertNull(imiUISearchRequest.getPlanFileIdQuery());
        assertNull(imiUISearchRequest.getPlanFileIdSearchOperator());
        assertNull(imiUISearchRequest.getProcessFileNameQuery());
        assertNull(imiUISearchRequest.getProcessFileNameSearchOperator());
        assertNull(imiUISearchRequest.getProcessFileStatusCdQuery());
        assertNull(imiUISearchRequest.getProcessFileStatusCdSearchOperator());
        assertNull(imiUISearchRequest.getImiDocumentIdQuery());
        assertNull(imiUISearchRequest.getImiDocumentIdSearchOperator());
        assertNull(imiUISearchRequest.getPlanDCNQuery());
        assertNull(imiUISearchRequest.getPlanDCNSearchOperator());
        assertNull(imiUISearchRequest.getDpkQuery());
        assertNull(imiUISearchRequest.getDpkSearchOperator());
        assertNull(imiUISearchRequest.getInitialProcessDCNQuery());
        assertNull(imiUISearchRequest.getInitialProcessDCNSearchOperator());
        assertNull(imiUISearchRequest.getFinalProcessDCNQuery());
        assertNull(imiUISearchRequest.getFinalProcessDCNSearchOperator());
        assertNull(imiUISearchRequest.getDocumentStatusCdQuery());
        assertNull(imiUISearchRequest.getDocumentStatusCdSearchOperator());
        assertNull(imiUISearchRequest.getApplIdCdQuery());
        assertNull(imiUISearchRequest.getApplIdCdSearchOperator());
        assertNull(imiUISearchRequest.getCaptureItemIdQuery());
        assertNull(imiUISearchRequest.getCaptureItemIdSearchOperator());
        assertNull(imiUISearchRequest.getProcessFileReasonCdQuery());
        assertNull(imiUISearchRequest.getProcessFileReasonSearchOperator());
        assertNull(imiUISearchRequest.getTimeAckQuery());
        assertNull(imiUISearchRequest.getDocumentReasonSearchOperator());
        assertNull(imiUISearchRequest.getMemberId());
        assertNull(imiUISearchRequest.getMemberIdSearchOperator());
        assertNull(imiUISearchRequest.getMemberIdType());
        assertNull(imiUISearchRequest.getMemberIdTypeSearchOperator());
        assertNull(imiUISearchRequest.getDocumentType());
        assertNull(imiUISearchRequest.getDocumentTypeSearchOperator());
        assertNull(imiUISearchRequest.getDocumentId());
        assertNull(imiUISearchRequest.getDocumentIdSearchOperator());
        assertNull(imiUISearchRequest.getProcessFileReasonCdDesc());
        assertNull(imiUISearchRequest.getProcessFileReasonCdSearchOperator());
        assertNull(imiUISearchRequest.getTimeAck());
        assertNull(imiUISearchRequest.getTimeAckSearchOperator());
        assertNull(imiUISearchRequest.getTimeUpdateQuery());
        assertNull(imiUISearchRequest.getTimeUpdateSearchOperator());
        assertNull(imiUISearchRequest.getDocumentReasonCdQuery());
        assertNull(imiUISearchRequest.getDocumentReasonCdSearchOperator());
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteIMIUISearchRequestSetup() {
        // Set all fields with sample data
        imiUISearchRequest.setNaicCode("TEST_NAIC");
        imiUISearchRequest.setBegindate("2023-01-01");
        imiUISearchRequest.setStartTimeHour("10");
        imiUISearchRequest.setStartTimeMin("30");
        imiUISearchRequest.setEnddate("2023-12-31");
        imiUISearchRequest.setEndTimeHour("23");
        imiUISearchRequest.setEndTimeMin("59");
        imiUISearchRequest.setSubmitTop("submit");
        imiUISearchRequest.setAllFieldsSelUnSelTop(true);
        imiUISearchRequest.setTransmitFileIdQuery("123456");
        imiUISearchRequest.setTransmitFileIdSearchOperator("EQ");
        imiUISearchRequest.setTransmitFileIdDisplay(true);
        imiUISearchRequest.setTransmitFileNameQuery("test_file.txt");
        imiUISearchRequest.setTransmitFileNameSearchOperator("LK");
        imiUISearchRequest.setTransmitFileNameDisplay(true);
        imiUISearchRequest.setTransmitFileStatusCdQuery("A");
        imiUISearchRequest.setTransmitFileStatusCdSearchOperator("EQ");
        imiUISearchRequest.setTransmitFileStatusCdDisplay(true);
        imiUISearchRequest.setImiFileIdQuery("789");
        imiUISearchRequest.setImiFileIdSearchOperator("GT");
        imiUISearchRequest.setImiFileIdDisplay(true);
        imiUISearchRequest.setPlanFileIdQuery("PLAN123");
        imiUISearchRequest.setPlanFileIdSearchOperator("EQ");
        imiUISearchRequest.setPlanFileIdDisplay(true);
        imiUISearchRequest.setProcessFileNameQuery("process.log");
        imiUISearchRequest.setProcessFileNameSearchOperator("LK");
        imiUISearchRequest.setProcessFileNameDisplay(true);
        imiUISearchRequest.setProcessFileStatusCdQuery("C");
        imiUISearchRequest.setProcessFileStatusCdSearchOperator("EQ");
        imiUISearchRequest.setProcessFileStatusCdDisplay(true);
        imiUISearchRequest.setProcessFileReasonCdQuery("REASON1");
        imiUISearchRequest.setProcessFileReasonSearchOperator("EQ");
        imiUISearchRequest.setTimeAckQuery("2023-01-01 10:00:00");
        imiUISearchRequest.setImiDocumentIdQuery("999");
        imiUISearchRequest.setImiDocumentIdSearchOperator("LT");
        imiUISearchRequest.setImiDocumentIdDisplay(true);
        imiUISearchRequest.setPlanDCNQuery("DCN123");
        imiUISearchRequest.setPlanDCNSearchOperator("EQ");
        imiUISearchRequest.setPlanDCNDisplay(true);
        imiUISearchRequest.setDpkQuery("DPK456");
        imiUISearchRequest.setDpkSearchOperator("EQ");
        imiUISearchRequest.setDpkDisplay(true);
        imiUISearchRequest.setInitialProcessDCNQuery("INITDCN");
        imiUISearchRequest.setInitialProcessDCNSearchOperator("EQ");
        imiUISearchRequest.setInitialProcessDCNDisplay(true);
        imiUISearchRequest.setFinalProcessDCNQuery("FINDCN");
        imiUISearchRequest.setFinalProcessDCNSearchOperator("EQ");
        imiUISearchRequest.setFinalProcessDCNDisplay(true);
        imiUISearchRequest.setDocumentStatusCdQuery("S");
        imiUISearchRequest.setDocumentStatusCdSearchOperator("EQ");
        imiUISearchRequest.setDocumentStatusCdDisplay(true);
        imiUISearchRequest.setDocumentReasonCdQuery("DOC_REASON");
        imiUISearchRequest.setDocumentReasonCdSearchOperator("EQ");
        imiUISearchRequest.setDocumentReasonCdDisplay(true);
        imiUISearchRequest.setTimeUpdateQuery("2023-01-01 11:00:00");
        imiUISearchRequest.setTimeUpdateSearchOperator("LT");
        imiUISearchRequest.setTimeUpdateDisplay(true);
        imiUISearchRequest.setApplIdCdQuery("APPL1");
        imiUISearchRequest.setApplIdCdSearchOperator("EQ");
        imiUISearchRequest.setApplIdCdDisplay(true);
        imiUISearchRequest.setCaptureItemIdQuery("CAPTURE1");
        imiUISearchRequest.setCaptureItemIdSearchOperator("EQ");
        imiUISearchRequest.setCaptureItemIdDisplay(true);
        imiUISearchRequest.setAllFieldsSelUnSelBottom(true);
        imiUISearchRequest.setProcessFileReasonCdDesc("Process File Reason Description");
        imiUISearchRequest.setProcessFileReasonCdDisplay(true);
        imiUISearchRequest.setProcessFileReasonCdSearchOperator("LK");
        imiUISearchRequest.setTimeAck("2023-01-01 10:05:00");
        imiUISearchRequest.setTimeAckDisplay(true);
        imiUISearchRequest.setTimeAckSearchOperator("GT");
        imiUISearchRequest.setDocumentReasonSearchOperator("LK");
        
        // Legacy fields
        imiUISearchRequest.setMemberId("MEMBER123");
        imiUISearchRequest.setMemberIdDisplay(true);
        imiUISearchRequest.setMemberIdSearchOperator("EQ");
        imiUISearchRequest.setMemberIdType("SSN");
        imiUISearchRequest.setMemberIdTypeDisplay(true);
        imiUISearchRequest.setMemberIdTypeSearchOperator("EQ");
        imiUISearchRequest.setDocumentType("CLAIM");
        imiUISearchRequest.setDocumentTypeDisplay(true);
        imiUISearchRequest.setDocumentTypeSearchOperator("EQ");
        imiUISearchRequest.setDocumentId("DOC123");
        imiUISearchRequest.setDocumentIdDisplay(true);
        imiUISearchRequest.setDocumentIdSearchOperator("EQ");

        // Verify all fields are set correctly
        assertEquals("TEST_NAIC", imiUISearchRequest.getNaicCode());
        assertEquals("2023-01-01", imiUISearchRequest.getBegindate());
        assertEquals("10", imiUISearchRequest.getStartTimeHour());
        assertEquals("30", imiUISearchRequest.getStartTimeMin());
        assertEquals("2023-12-31", imiUISearchRequest.getEnddate());
        assertEquals("23", imiUISearchRequest.getEndTimeHour());
        assertEquals("59", imiUISearchRequest.getEndTimeMin());
        assertEquals("submit", imiUISearchRequest.getSubmitTop());
        assertTrue(imiUISearchRequest.isAllFieldsSelUnSelTop());
        assertEquals("123456", imiUISearchRequest.getTransmitFileIdQuery());
        assertEquals("EQ", imiUISearchRequest.getTransmitFileIdSearchOperator());
        assertTrue(imiUISearchRequest.isTransmitFileIdDisplay());
        assertEquals("test_file.txt", imiUISearchRequest.getTransmitFileNameQuery());
        assertEquals("LK", imiUISearchRequest.getTransmitFileNameSearchOperator());
        assertTrue(imiUISearchRequest.isTransmitFileNameDisplay());
        assertEquals("A", imiUISearchRequest.getTransmitFileStatusCdQuery());
        assertEquals("EQ", imiUISearchRequest.getTransmitFileStatusCdSearchOperator());
        assertTrue(imiUISearchRequest.isTransmitFileStatusCdDisplay());
        assertEquals("789", imiUISearchRequest.getImiFileIdQuery());
        assertEquals("GT", imiUISearchRequest.getImiFileIdSearchOperator());
        assertTrue(imiUISearchRequest.isImiFileIdDisplay());
        assertEquals("PLAN123", imiUISearchRequest.getPlanFileIdQuery());
        assertEquals("EQ", imiUISearchRequest.getPlanFileIdSearchOperator());
        assertTrue(imiUISearchRequest.isPlanFileIdDisplay());
        assertEquals("process.log", imiUISearchRequest.getProcessFileNameQuery());
        assertEquals("LK", imiUISearchRequest.getProcessFileNameSearchOperator());
        assertTrue(imiUISearchRequest.isProcessFileNameDisplay());
        assertEquals("C", imiUISearchRequest.getProcessFileStatusCdQuery());
        assertEquals("EQ", imiUISearchRequest.getProcessFileStatusCdSearchOperator());
        assertTrue(imiUISearchRequest.isProcessFileStatusCdDisplay());
        assertEquals("REASON1", imiUISearchRequest.getProcessFileReasonCdQuery());
        assertEquals("EQ", imiUISearchRequest.getProcessFileReasonSearchOperator());
        assertEquals("2023-01-01 10:00:00", imiUISearchRequest.getTimeAckQuery());
        assertEquals("999", imiUISearchRequest.getImiDocumentIdQuery());
        assertEquals("LT", imiUISearchRequest.getImiDocumentIdSearchOperator());
        assertTrue(imiUISearchRequest.isImiDocumentIdDisplay());
        assertEquals("DCN123", imiUISearchRequest.getPlanDCNQuery());
        assertEquals("EQ", imiUISearchRequest.getPlanDCNSearchOperator());
        assertTrue(imiUISearchRequest.isPlanDCNDisplay());
        assertEquals("DPK456", imiUISearchRequest.getDpkQuery());
        assertEquals("EQ", imiUISearchRequest.getDpkSearchOperator());
        assertTrue(imiUISearchRequest.isDpkDisplay());
        assertEquals("INITDCN", imiUISearchRequest.getInitialProcessDCNQuery());
        assertEquals("EQ", imiUISearchRequest.getInitialProcessDCNSearchOperator());
        assertTrue(imiUISearchRequest.isInitialProcessDCNDisplay());
        assertEquals("FINDCN", imiUISearchRequest.getFinalProcessDCNQuery());
        assertEquals("EQ", imiUISearchRequest.getFinalProcessDCNSearchOperator());
        assertTrue(imiUISearchRequest.isFinalProcessDCNDisplay());
        assertEquals("S", imiUISearchRequest.getDocumentStatusCdQuery());
        assertEquals("EQ", imiUISearchRequest.getDocumentStatusCdSearchOperator());
        assertTrue(imiUISearchRequest.isDocumentStatusCdDisplay());
        assertEquals("DOC_REASON", imiUISearchRequest.getDocumentReasonCdQuery());
        assertEquals("EQ", imiUISearchRequest.getDocumentReasonCdSearchOperator());
        assertTrue(imiUISearchRequest.isDocumentReasonCdDisplay());
        assertEquals("2023-01-01 11:00:00", imiUISearchRequest.getTimeUpdateQuery());
        assertEquals("LT", imiUISearchRequest.getTimeUpdateSearchOperator());
        assertTrue(imiUISearchRequest.isTimeUpdateDisplay());
        assertEquals("APPL1", imiUISearchRequest.getApplIdCdQuery());
        assertEquals("EQ", imiUISearchRequest.getApplIdCdSearchOperator());
        assertTrue(imiUISearchRequest.isApplIdCdDisplay());
        assertEquals("CAPTURE1", imiUISearchRequest.getCaptureItemIdQuery());
        assertEquals("EQ", imiUISearchRequest.getCaptureItemIdSearchOperator());
        assertTrue(imiUISearchRequest.isCaptureItemIdDisplay());
        assertTrue(imiUISearchRequest.isAllFieldsSelUnSelBottom());
        assertEquals("Process File Reason Description", imiUISearchRequest.getProcessFileReasonCdDesc());
        assertTrue(imiUISearchRequest.isProcessFileReasonCdDisplay());
        assertEquals("LK", imiUISearchRequest.getProcessFileReasonCdSearchOperator());
        assertEquals("2023-01-01 10:05:00", imiUISearchRequest.getTimeAck());
        assertTrue(imiUISearchRequest.isTimeAckDisplay());
        assertEquals("GT", imiUISearchRequest.getTimeAckSearchOperator());
        assertEquals("LK", imiUISearchRequest.getDocumentReasonSearchOperator());
        
        // Legacy fields
        assertEquals("MEMBER123", imiUISearchRequest.getMemberId());
        assertTrue(imiUISearchRequest.isMemberIdDisplay());
        assertEquals("EQ", imiUISearchRequest.getMemberIdSearchOperator());
        assertEquals("SSN", imiUISearchRequest.getMemberIdType());
        assertTrue(imiUISearchRequest.isMemberIdTypeDisplay());
        assertEquals("EQ", imiUISearchRequest.getMemberIdTypeSearchOperator());
        assertEquals("CLAIM", imiUISearchRequest.getDocumentType());
        assertTrue(imiUISearchRequest.isDocumentTypeDisplay());
        assertEquals("EQ", imiUISearchRequest.getDocumentTypeSearchOperator());
        assertEquals("DOC123", imiUISearchRequest.getDocumentId());
        assertTrue(imiUISearchRequest.isDocumentIdDisplay());
        assertEquals("EQ", imiUISearchRequest.getDocumentIdSearchOperator());
    }

    @Test
    void testDefaultBooleanValues() {
        // Test that boolean fields have default false values
        assertFalse(imiUISearchRequest.isAllFieldsSelUnSelTop());
        assertFalse(imiUISearchRequest.isAllFieldsSelUnSelBottom());
        assertFalse(imiUISearchRequest.isTransmitFileIdDisplay());
        assertFalse(imiUISearchRequest.isTransmitFileNameDisplay());
        assertFalse(imiUISearchRequest.isTransmitFileStatusCdDisplay());
        assertFalse(imiUISearchRequest.isImiFileIdDisplay());
        assertFalse(imiUISearchRequest.isPlanFileIdDisplay());
        assertFalse(imiUISearchRequest.isProcessFileNameDisplay());
        assertFalse(imiUISearchRequest.isProcessFileStatusCdDisplay());
        assertFalse(imiUISearchRequest.isImiDocumentIdDisplay());
        assertFalse(imiUISearchRequest.isPlanDCNDisplay());
        assertFalse(imiUISearchRequest.isDpkDisplay());
        assertFalse(imiUISearchRequest.isInitialProcessDCNDisplay());
        assertFalse(imiUISearchRequest.isFinalProcessDCNDisplay());
        assertFalse(imiUISearchRequest.isDocumentStatusCdDisplay());
        assertFalse(imiUISearchRequest.isApplIdCdDisplay());
        assertFalse(imiUISearchRequest.isCaptureItemIdDisplay());
        assertFalse(imiUISearchRequest.isProcessFileReasonCdDisplay());
        assertFalse(imiUISearchRequest.isTimeAckDisplay());
        assertFalse(imiUISearchRequest.isTimeUpdateDisplay());
        assertFalse(imiUISearchRequest.isDocumentReasonCdDisplay());
        assertFalse(imiUISearchRequest.isMemberIdDisplay());
        assertFalse(imiUISearchRequest.isMemberIdTypeDisplay());
        assertFalse(imiUISearchRequest.isDocumentTypeDisplay());
        assertFalse(imiUISearchRequest.isDocumentIdDisplay());
    }
}
