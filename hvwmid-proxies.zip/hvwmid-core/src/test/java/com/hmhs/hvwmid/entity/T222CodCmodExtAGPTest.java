package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class T222CodCmodExtAGPTest {

    @Test
    void testNoArgsConstructorAndSetters() {
        T222CodCmodExtAGP entity = new T222CodCmodExtAGP();

        entity.setCmodApplicationGroup("GROUP1");
        entity.setCmodUserGroupName("USER1");
        entity.setCmodUserQR("QUERY123");
        entity.setCmodUserGroupIndicator("U");

        assertEquals("GROUP1", entity.getCmodApplicationGroup());
        assertEquals("USER1", entity.getCmodUserGroupName());
        assertEquals("QUERY123", entity.getCmodUserQR());
        assertEquals("U", entity.getCmodUserGroupIndicator());
    }

    @Test
    void testAllArgsConstructor() {
        T222CodCmodExtAGP entity = new T222CodCmodExtAGP(
                "APPGRP1",
                "USRGRP1",
                "QR456",
                "A"
        );

        assertEquals("APPGRP1", entity.getCmodApplicationGroup());
        assertEquals("USRGRP1", entity.getCmodUserGroupName());
        assertEquals("QR456", entity.getCmodUserQR());
        assertEquals("A", entity.getCmodUserGroupIndicator());
    }

    @Test
    void testEqualsAndHashCode() {
        // This only applies if you override equals/hashCode in T222CodCmodExtAGPId
        T222CodCmodExtAGP e1 = new T222CodCmodExtAGP("G1", "U1", "Q1", "U");
        T222CodCmodExtAGP e2 = new T222CodCmodExtAGP("G1", "U1", "Q1", "U");

        assertNotEquals(e1, e2); // Different instances, no equals() override
    }
}
