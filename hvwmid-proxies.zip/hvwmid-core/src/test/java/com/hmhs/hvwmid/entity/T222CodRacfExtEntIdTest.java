package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class T222CodRacfExtEntIdTest {

    @Test
    void testNoArgsConstructorAndSetters() {
        T222CodRacfExtEntId id = new T222CodRacfExtEntId();

        id.setRacfEntity("ENTITY123");
        id.setRacfUserId("USER1234");
        id.setRacfClass("CLASS001");

        assertEquals("ENTITY123", id.getRacfEntity());
        assertEquals("USER1234", id.getRacfUserId());
        assertEquals("CLASS001", id.getRacfClass());
    }

    @Test
    void testAllArgsConstructor() {
        T222CodRacfExtEntId id = new T222CodRacfExtEntId("ENT456", "USR456", "CL456");

        assertEquals("ENT456", id.getRacfEntity());
        assertEquals("USR456", id.getRacfUserId());
        assertEquals("CL456", id.getRacfClass());
    }

    @Test
    void testEqualsAndHashCode() {
        T222CodRacfExtEntId id1 = new T222CodRacfExtEntId("E1", "U1", "C1");
        T222CodRacfExtEntId id2 = new T222CodRacfExtEntId("E1", "U1", "C1");
        T222CodRacfExtEntId id3 = new T222CodRacfExtEntId("E2", "U2", "C2");

        assertEquals(id1, id2);
        assertEquals(id1.hashCode(), id2.hashCode());

        assertNotEquals(id1, id3);
    }

    @Test
    void testEqualsWithNullAndDifferentClass() {
        T222CodRacfExtEntId id = new T222CodRacfExtEntId("E1", "U1", "C1");

        assertNotEquals(null, id);
        assertNotEquals(id, "not-an-id");
    }
}
