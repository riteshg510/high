package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TblColumnsTest {

    private TblColumns tblColumns;

    @BeforeEach
    void setUp() {
        tblColumns = new TblColumns();
    }

    @Test
    void testSetGetColumnId() {
        String columnId = "column123";
        tblColumns.setColumnId(columnId);
        assertEquals(columnId.toUpperCase(), tblColumns.getColumnId());
    }

    @Test
    void testSetGetColumnsOrder() {
        int columnsOrder = 5;
        tblColumns.setColumnsOrder(columnsOrder);
        assertEquals(columnsOrder, tblColumns.getColumnsOrder());
    }

    @Test
    void testSetGetColumnWidth() {
        int columnWidth = 100;
        tblColumns.setColumnWidth(columnWidth);
        assertEquals(columnWidth, tblColumns.getColumnWidth());
    }

    @Test
    void testSetGetCreateTimestamp() {
        LocalDateTime timestamp = LocalDateTime.now();
        tblColumns.setCreateTimestamp(timestamp);
        assertEquals(timestamp, tblColumns.getCreateTimestamp());
    }

    @Test
    void testSetGetDateFormat() {
        String dateFormat = "MM/dd/yyyy";
        tblColumns.setDateFormat(dateFormat);
        assertEquals(dateFormat, tblColumns.getDateFormat());
    }

    @Test
    void testSetGetFilterable() {
        Short filterable = 1;
        tblColumns.setFilterable(filterable);
        assertEquals(filterable, tblColumns.getFilterable());
    }

    @Test
    void testSetGetLabel() {
        String label = "test label";
        tblColumns.setLabel(label);
        assertEquals("Test Label", tblColumns.getLabel());
    }

    @Test
    void testSetGetName() {
        String name = "columnName";
        tblColumns.setName(name);
        assertEquals(name, tblColumns.getName());
    }

    @Test
    void testSetGetPickListOptions() {
        String pickListOptions = "option1, option2";
        tblColumns.setPickListOptions(pickListOptions);
        assertEquals(pickListOptions, tblColumns.getPickListOptions());
    }

    @Test
    void testSetGetSortable() {
        Short sortable = 1;
        tblColumns.setSortable(sortable);
        assertEquals(sortable, tblColumns.getSortable());
    }

    @Test
    void testSetGetTableId() {
        String tableId = "table123";
        tblColumns.setTableId(tableId);
        assertEquals(tableId.toUpperCase(), tblColumns.getTableId());
    }

    @Test
    void testSetGetType() {
        String type = "integer";
        tblColumns.setType(type);
        assertEquals(type, tblColumns.getType());
    }

    @Test
    void testSetGetUrl() {
        String url = "http://example.com";
        tblColumns.setUrl(url);
        assertEquals(url, tblColumns.getUrl());
    }

    @Test
    void testCapitalize() {
        // Test normal string
        String result = TblColumns.capitalize("test label");
        assertEquals("Test Label", result);

        // Test string with multiple words
        result = TblColumns.capitalize("multiple   words");
        assertEquals("Multiple Words", result);

        // Test empty string
        result = TblColumns.capitalize("");
        assertEquals("", result);

        // Test null string
        result = TblColumns.capitalize(null);
        assertEquals("", result);
    }
}
