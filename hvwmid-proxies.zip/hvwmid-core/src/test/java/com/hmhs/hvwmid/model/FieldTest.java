package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FieldTest {

    private Field field;

    // Setup method to initialize the field object before each test
    @BeforeEach
    void setUp() {
        field = new Field();
    }

    @Test
    void testGetAndSetId() {
        // Test set and get for the 'id' field
        String testId = "123";
        field.setId(testId);
        assertEquals(testId, field.getId(), "The id should match the set value");
    }

    @Test
    void testGetAndSetLabel() {
        // Test set and get for the 'label' field
        String testLabel = "Test Label";
        field.setLabel(testLabel);
        assertEquals(testLabel, field.getLabel(), "The label should match the set value");
    }

    @Test
    void testGetAndSetName() {
        // Test set and get for the 'name' field
        String testName = "Test Name";
        field.setName(testName);
        assertEquals(testName, field.getName(), "The name should match the set value");
    }

    @Test
    void testGetAndSetType() {
        // Test set and get for the 'type' field
        String testType = "String";
        field.setType(testType);
        assertEquals(testType, field.getType(), "The type should match the set value");
    }

    @Test
    void testGetAndSetSortable() {
        // Test set and get for the 'sortable' field (Short type)
        Short testSortable = 1;
        field.setSortable(testSortable);
        assertEquals(testSortable, field.getSortable(), "The sortable value should match the set value");
    }

    @Test
    void testGetAndSetFilterable() {
        // Test set and get for the 'filterable' field (Short type)
        Short testFilterable = 1;
        field.setFilterable(testFilterable);
        assertEquals(testFilterable, field.getFilterable(), "The filterable value should match the set value");
    }

    @Test
    void testGetAndSetColumnWidth() {
        // Test set and get for the 'columnWidth' field
        int testColumnWidth = 50;
        field.setColumnWidth(testColumnWidth);
        assertEquals(testColumnWidth, field.getColumnWidth(), "The column width should match the set value");
    }

    @Test
    void testGetAndSetUrl() {
        // Test set and get for the 'url' field
        String testUrl = "http://example.com";
        field.setUrl(testUrl);
        assertEquals(testUrl, field.getUrl(), "The URL should match the set value");
    }

    @Test
    void testGetAndSetDateFormat() {
        // Test set and get for the 'dateFormat' field
        String testDateFormat = "yyyy-MM-dd";
        field.setDateFormat(testDateFormat);
        assertEquals(testDateFormat, field.getDateFormat(), "The date format should match the set value");
    }

    @Test
    void testGetAndSetTrueLabel() {
        // Test set and get for the 'trueLabel' field
        String testTrueLabel = "Yes";
        field.setTrueLabel(testTrueLabel);
        assertEquals(testTrueLabel, field.getTrueLabel(), "The true label should match the set value");
    }

    @Test
    void testGetAndSetFalseLabel() {
        // Test set and get for the 'falseLabel' field
        String testFalseLabel = "No";
        field.setFalseLabel(testFalseLabel);
        assertEquals(testFalseLabel, field.getFalseLabel(), "The false label should match the set value");
    }

    @Test
    void testGetAndSetColumnsOrder() {
        // Test set and get for the 'columnsOrder' field
        int testColumnsOrder = 2;
        field.setColumnsOrder(testColumnsOrder);
        assertEquals(testColumnsOrder, field.getColumnsOrder(), "The columns order should match the set value");
    }
}
