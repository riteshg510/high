package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblCodObject;
import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.repository.CodCachingRepository;
import com.hmhs.hvwmid.repository.CodObjectRepository;
import com.hmhs.hvwmid.repository.CodTokenRepository;
import com.ibm.db2.jcc.am.l;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.*;
import java.sql.SQLException;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest(properties = {"db-logging-env=testEnv"}, classes = CodCachingService.class)
class CodCachingServiceTest {
    @Test
    void testGetTokenByStatusAndType_TOPDF_Converted() {
        TblCodToken token = new TblCodToken();
        token.setDocumentType("PDF");
        token.setDocCnvStatus("Converted");
        token.setSecurityToken("mockAuthToken");
        token.setUserId("user1");
        token.setDocumentToken("doc1");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of(token));
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", "TOPDF","mockAuthToken");
        assertEquals(token, result);
    }

    @Test
    void testGetTokenByStatusAndType_TOPDF_ConversionFailed() {
        TblCodToken token = new TblCodToken();
        token.setDocumentType("PDF");
        token.setDocCnvStatus("Conversion Failed");
        token.setSecurityToken("mockAuthToken");
        token.setUserId("user1");
        token.setDocumentToken("doc1");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of(token));
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", "TOPDF","mockAuthToken");
        assertEquals(token, result);
    }

    @Test
    void testGetTokenByStatusAndType_TOPDF_SpecialType() {
        TblCodToken token = new TblCodToken();
        token.setDocumentType("docx"); // not in specialTypes
        token.setDocCnvStatus("Other");
        token.setSecurityToken("mockAuthToken");
        token.setUserId("user1");
        token.setDocumentToken("doc1");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of(token));
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", "TOPDF","mockAuthToken");
        assertEquals(token, result);
    }

    @Test
    void testGetTokenByStatusAndType_NotTOPDF_Original() {
        TblCodToken token = new TblCodToken();
        token.setDocumentType("PDF");
        token.setDocCnvStatus("Original");
        token.setSecurityToken("mockAuthToken");
        token.setUserId("user1");
        token.setDocumentToken("doc1");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of(token));
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", null,"mockAuthToken");
        assertEquals(token, result);
    }

    @Test
    void testGetTokenByStatusAndType_NotTOPDF_ConversionFailed() {
        TblCodToken token = new TblCodToken();
        token.setDocumentType("PDF");
        token.setDocCnvStatus("Conversion Failed");
        token.setSecurityToken("mockAuthToken");
        token.setUserId("user1");
        token.setDocumentToken("doc1");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of(token));
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", "","mockAuthToken");
        assertEquals(token, result);
    }

    @Test
    void testGetTokenByStatusAndType_NotTOPDF_SpecialType() {
        TblCodToken token = new TblCodToken();
        token.setDocumentType("docx"); // not in specialTypes
        token.setDocCnvStatus("Other");
        token.setSecurityToken("mockAuthToken");
        token.setUserId("user1");
        token.setDocumentToken("doc1");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of(token));
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", "","mockAuthToken");
        assertEquals(token, result);
    }

    @Test
    void testGetTokenByStatusAndType_NoneFound() {
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "mockAuthToken"))
            .thenReturn(java.util.List.of());
        TblCodToken result = service.getTokenByStatusAndType("user1", "doc1", "TOPDF","mockAuthToken");
        assertNull(result);
    }

    @Autowired
    CodCachingService service;

    @MockBean
    CodCachingRepository codCachingRepository;

    @MockBean
    CodTokenRepository tokenRepo;

    @MockBean
    CodObjectRepository objectRepo;

    @MockBean
    TransactionTemplate txTemplate;

    @MockBean
    HvwDataRefresh hvwDataRefresh;

    @MockBean
    JdbcTemplate jdbcTemplate;

    @MockBean
    GenericUDFService seqGen;

    @MockBean
    PlatformTransactionManager txManager;

    @BeforeEach
    void setup() throws Exception {
        service.setDbLoggingEnv("testEnv");

        when(hvwDataRefresh.getParmDataByKeyByCmodbase(anyString(), anyString()))
                .thenAnswer(invocation -> invocation.getArgument(1));

        var field = CodCachingService.class.getDeclaredField("seqGen");
        field.setAccessible(true);
        field.set(service, seqGen);
    }

    @Test
    void testGetDocumentToken_foundByRequestIdAndSecurityToken() {
        TblCodToken token = new TblCodToken();
        token.setRequestId(5);
        token.setDocumentType("PDF");
        when(tokenRepo.findByRequestIdAndSecurityTokenSafe(5, "secToken")).thenReturn(java.util.Optional.of(token)); // unchanged, as repo returns Optional

        TblCodToken result = service.getDocumentToken(5, "secToken");
        assertEquals(token, result);
    }

    @Test
    void testGetDocumentToken_notFoundByRequestIdAndSecurityToken_throws() {
        when(tokenRepo.findByRequestIdAndSecurityTokenSafe(5, "secToken")).thenReturn(java.util.Optional.empty()); // unchanged, as repo returns Optional

        SecurityException ex = assertThrows(SecurityException.class, () -> service.getDocumentToken(5, "secToken"));
        assertEquals("Not found", ex.getMessage());
    }

    @Test
    void testGetDocumentToken_foundByUserIdAndDocTokenAndSecurityToken_pdf() {
        TblCodToken token = new TblCodToken();
        token.setRequestId(10);
        token.setDocumentType("PDF");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "secToken"))
                .thenReturn(java.util.List.of(token));

        TblCodToken result = service.getDocumentToken("user1", "doc1", "secToken");
        assertEquals(token, result);
    }

    @Test
    void testGetDocumentToken_foundByUserIdAndDocTokenAndSecurityToken_notPdf_throws() {
        TblCodToken token = new TblCodToken();
        token.setRequestId(10);
        token.setDocumentType("TXT");
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "secToken"))
                .thenReturn(java.util.List.of(token));

        SecurityException ex = assertThrows(SecurityException.class, () -> service.getDocumentToken("user1", "doc1", "secToken"));
        assertEquals("Not found or not a PDF document", ex.getMessage());
    }

    @Test
    void testGetDocumentToken_notFoundByUserIdAndDocTokenAndSecurityToken_throws() {
        when(tokenRepo.findByUserIdAndDocumentTokenAndSecurityTokenSafe("user1", "doc1", "secToken"))
                .thenReturn(java.util.List.of());

        SecurityException ex = assertThrows(SecurityException.class,
                () -> service.getDocumentToken("user1", "doc1", "secToken"));
        assertEquals("Not found or not a PDF document", ex.getMessage());
    }

    @Test
    void testStreamDocument_success() throws Exception {
        // Arrange
        //CodCachingRepository repository = mock(CodCachingRepository.class);

        int requestId = 123;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        doAnswer(invocation -> {
            OutputStream os = invocation.getArgument(1);
            os.write("test data".getBytes());
            return null;
        }).when(codCachingRepository).streamSegmentsByRequestId(eq(requestId), any(OutputStream.class));

        // Act
        StreamingResponseBody responseBody = service.streamDocument(requestId);
        responseBody.writeTo(outputStream);

        // Assert
        String result = outputStream.toString();
        assert result.equals("test data");
        verify(codCachingRepository, times(1)).streamSegmentsByRequestId(eq(requestId), any(OutputStream.class));
    }


    @Test
    void testStreamDocument_sqlExceptionWrappedAsIOException() throws Exception {
        int requestId = 42;

        doThrow(new SQLException("DB fail")).when(codCachingRepository)
                .streamSegmentsByRequestId(eq(requestId), any(OutputStream.class));

        StreamingResponseBody responseBody = service.streamDocument(requestId);

        OutputStream outputStream = mock(OutputStream.class);

        IOException exception = assertThrows(IOException.class, () -> {
            responseBody.writeTo(outputStream);
        });

        assertEquals("Database error while streaming document", exception.getMessage());
        assertTrue(exception.getCause() instanceof SQLException);
        assertEquals("DB fail", exception.getCause().getMessage());
    }

    @Test
    void testSaveToken() {
        when(seqGen.generateRequestId("testEnv")).thenReturn(12345);
        TblCodToken savedToken = new TblCodToken();
        when(tokenRepo.save(any())).thenReturn(savedToken);

        TblCodToken result = service.saveToken("userX", "secToken", "docToken");

        assertNotNull(result);
        verify(tokenRepo).save(any(TblCodToken.class));

        ArgumentCaptor<TblCodToken> captor = ArgumentCaptor.forClass(TblCodToken.class);
        verify(tokenRepo).save(captor.capture());

        TblCodToken captured = captor.getValue();
        assertEquals(12345, captured.getRequestId());
        assertEquals("userX", captured.getUserId());
        assertEquals("docToken", captured.getDocumentToken());
        assertEquals("secToken", captured.getSecurityToken());
        assertEquals("", captured.getDocumentType());
        assertEquals(1, captured.getDocumentPages());
        assertNotNull(captured.getTimeCreate());
    }

    @Test
    void testCacheDocument() throws IOException {
        when(seqGen.generateRequestId("testEnv")).thenReturn(777);
        when(hvwDataRefresh.getParmDataByKeyByCmodbase(anyString(), anyString())).thenReturn("testEnv");

        byte[] data = "HelloWorld".getBytes();
        InputStream input = new ByteArrayInputStream(data);

        int requestId = service.cacheDocument(input, "user1", "docTok", "secTok");

        assertEquals(777, requestId);

        verify(tokenRepo, times(1)).save(any(TblCodToken.class));

        verify(objectRepo, atLeastOnce()).save(any(TblCodObject.class));
    }
}
