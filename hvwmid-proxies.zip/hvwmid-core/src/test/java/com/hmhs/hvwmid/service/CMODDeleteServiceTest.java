package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyMap;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CMODDeleteServiceTest {

    @InjectMocks
    private CMODDeleteService deleteService;

    @Mock
    private RestClientUtil restClientUtil;

    private static final String DOCUMENT_TOKEN = "dummyDocumentToken";
    private static final String OD_FOLDER = "dummyFolder";
    private static final String AUTH_TOKEN = "dummyAuthToken";
    private static final String UPDATE_URL = "http://mock-update-url.com";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Set the updateUrl for soft delete
        deleteService.updateUrl = UPDATE_URL;
    }

    @Test
    void testDeleteDocument_SoftDeleteRequest() {
        // Mock RestClientUtil behavior
        Map<String, Object> mockResponse = Map.of("status", "success");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        // Call the method under test
        Map<String, Object> result = deleteService.deleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);

        // Assertions
        assertNotNull(result);
        assertEquals("success", result.get("status"));
        verify(restClientUtil, times(1)).postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap());
    }

    @Test
    void testDeleteDocument_InvalidFolder() {
        CMODDeleteService spyDeleteService = spy(deleteService);
        doThrow(HVWException.class).when(spyDeleteService).validateFolder(anyString());
        assertThrows(HVWException.class, () -> {
            spyDeleteService.deleteDocument(DOCUMENT_TOKEN, "invalidFolder", AUTH_TOKEN);
        });
        verify(spyDeleteService, times(1)).validateFolder("invalidFolder");
    }

    @Test
    void testDeleteDocument_SuccessfulApiCall() {
        Map<String, Object> mockResponse = Map.of("status", "deleted");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        Map<String, Object> result = deleteService.deleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);
        assertNotNull(result);
        assertEquals("deleted", result.get("status"));
        verify(restClientUtil, times(1)).postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap());
    }

    
   @Test
    void testDeleteDocument_FailedApiCall() {
    when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
            .thenReturn(new ResponseEntity<>(HttpStatus.SERVICE_UNAVAILABLE));
    assertThrows(HVWException.class, () -> deleteService.deleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN));
    }

    @Test
    void testDeleteDocument_ContainsDeletedYInPayload() {
        Map<String, Object> mockResponse = Map.of("status", "ok");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        deleteService.deleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);
        // Capture the payload and verify it contains updateValues.DELETED = "Y"
        verify(restClientUtil).postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), org.mockito.ArgumentMatchers.argThat(payload -> {
            Object updateValues = ((Map<?, ?>) payload).get("updateValues");
            return updateValues instanceof Map && "Y".equals(((Map<?, ?>) updateValues).get("DELETED"));
        }));
    }

    // Tests for undeleteDocument method
    @Test
    void testUndeleteDocument_SuccessfulUndelete() {
        // Mock RestClientUtil behavior
        Map<String, Object> mockResponse = Map.of("status", "success", "message", "Document undeleted");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));

        // Call the method under test
        Map<String, Object> result = deleteService.undeleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);

        // Assertions
        assertNotNull(result);
        assertEquals("success", result.get("status"));
        assertEquals("Document undeleted", result.get("message"));
        verify(restClientUtil, times(1)).postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap());
    }

    @Test
    void testUndeleteDocument_ContainsDeletedBlankInPayload() {
        Map<String, Object> mockResponse = Map.of("status", "ok");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        
        deleteService.undeleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);
        
        // Capture the payload and verify it contains updateValues.DELETED = "" (blank)
        verify(restClientUtil).postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), org.mockito.ArgumentMatchers.argThat(payload -> {
            Object updateValues = ((Map<?, ?>) payload).get("updateValues");
            return updateValues instanceof Map && "".equals(((Map<?, ?>) updateValues).get("DELETED"));
        }));
    }

    @Test
    void testUndeleteDocument_InvalidDocumentToken() {
        CMODDeleteService spyDeleteService = spy(deleteService);
        doThrow(HVWException.class).when(spyDeleteService).validateDocumentToken(anyString());
        
        assertThrows(HVWException.class, () -> {
            spyDeleteService.undeleteDocument("invalidToken", OD_FOLDER, AUTH_TOKEN);
        });
        
        verify(spyDeleteService, times(1)).validateDocumentToken("invalidToken");
    }

    @Test
    void testUndeleteDocument_InvalidFolder() {
        CMODDeleteService spyDeleteService = spy(deleteService);
        doThrow(HVWException.class).when(spyDeleteService).validateFolder(anyString());
        
        assertThrows(HVWException.class, () -> {
            spyDeleteService.undeleteDocument(DOCUMENT_TOKEN, "invalidFolder", AUTH_TOKEN);
        });
        
        verify(spyDeleteService, times(1)).validateFolder("invalidFolder");
    }

    @Test
    void testUndeleteDocument_FailedApiCall() {
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        
        assertThrows(HVWException.class, () -> 
            deleteService.undeleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN));
    }

    @Test
    void testUndeleteDocument_ApiCallWithErrorResponse() {
        Map<String, Object> errorResponse = Map.of("error", "Service unavailable");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(errorResponse, HttpStatus.SERVICE_UNAVAILABLE));
        
        assertThrows(HVWException.class, () -> 
            deleteService.undeleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN));
    }

    @Test
    void testUndeleteDocument_VerifyPayloadStructure() {
        Map<String, Object> mockResponse = Map.of("status", "success");
        when(restClientUtil.postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), anyMap()))
                .thenReturn(new ResponseEntity<>(mockResponse, HttpStatus.OK));
        
        deleteService.undeleteDocument(DOCUMENT_TOKEN, OD_FOLDER, AUTH_TOKEN);
        
        // Verify the complete payload structure
        verify(restClientUtil).postRequest(eq(UPDATE_URL), eq(AUTH_TOKEN), org.mockito.ArgumentMatchers.argThat(payload -> {
            // Check if payload contains required fields
            boolean hasDocumentToken = payload.containsKey("documentToken") && 
                                     DOCUMENT_TOKEN.equals(payload.get("documentToken"));
            boolean hasOdFolder = payload.containsKey("odFolder") && 
                                OD_FOLDER.equals(payload.get("odFolder"));
            boolean hasUpdateValues = payload.containsKey("updateValues");
            
            if (hasUpdateValues) {
                Object updateValues = payload.get("updateValues");
                boolean hasDeletedField = updateValues instanceof Map && 
                                        ((Map<?, ?>) updateValues).containsKey("DELETED");
                return hasDocumentToken && hasOdFolder && hasDeletedField;
            }
            return false;
        }));
    }
}
