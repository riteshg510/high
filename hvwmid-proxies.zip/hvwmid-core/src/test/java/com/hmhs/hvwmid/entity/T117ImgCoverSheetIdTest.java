package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class T117ImgCoverSheetIdTest {

    private T117ImgCoverSheetId id;

    @BeforeEach
    void setup() {
        id = new T117ImgCoverSheetId();
    }

    @Test
    void application_shouldSetAndGetCorrectly() {
        // Given
        Integer application = 100;

        // When
        id.setApplication(application);

        // Then
        assertEquals(application, id.getApplication());
    }

    @Test
    void application_shouldHandleNullValue() {
        // Given
        id.setApplication(null);

        // When & Then
        assertNull(id.getApplication());
    }

    @Test
    void application_shouldHandleBoundaryValues() {
        // Given & When & Then
        id.setApplication(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, id.getApplication());

        id.setApplication(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, id.getApplication());

        id.setApplication(0);
        assertEquals(0, id.getApplication());
    }

    @Test
    void name_shouldSetAndGetCorrectly() {
        // Given
        String name = "SHEET_ID";

        // When
        id.setName(name);

        // Then
        assertEquals(name, id.getName());
    }

    @Test
    void name_shouldHandleNullValue() {
        // Given
        id.setName(null);

        // When & Then
        assertNull(id.getName());
    }

    @Test
    void name_shouldHandleEmptyString() {
        // Given
        id.setName("");

        // When & Then
        assertEquals("", id.getName());
    }

    @Test
    void name_shouldHandleVariousFormats() {
        // Test different name formats
        String[] names = {"SHEET001", "SHT001", "ABC123", "TEST_SHEET", "X", "1234567890"};

        for (String name : names) {
            // When
            id.setName(name);

            // Then
            assertEquals(name, id.getName());
        }
    }

    @Test
    void equals_shouldReturnTrueForSameObject() {
        // Given & When & Then
        assertEquals(id, id);
        assertTrue(id.equals(id));
    }

    @Test
    void equals_shouldReturnFalseForNull() {
        // Given & When & Then
        assertFalse(id.equals(null));
        assertNotEquals(id, null);
    }

    @Test
    void equals_shouldReturnFalseForDifferentClass() {
        // Given
        String differentObject = "not an ID object";

        // When & Then
        assertFalse(id.equals(differentObject));
        assertNotEquals(id, differentObject);
    }

    @Test
    void equals_shouldReturnTrueForSameValues() {
        // Given
        id.setApplication(100);
        id.setName("TEST");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("TEST");

        // When & Then
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);
    }

    @Test
    void equals_shouldReturnFalseForDifferentApplication() {
        // Given
        id.setApplication(100);
        id.setName("TEST");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(200);
        otherId.setName("TEST");

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldReturnFalseForDifferentName() {
        // Given
        id.setApplication(100);
        id.setName("TEST1");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("TEST2");

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldHandleNullValues() {
        // Given - Both IDs with null values
        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();

        // When & Then - Both have null values, should be equal
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);

        // Given - One has null, other doesn't
        id.setApplication(100);

        // When & Then - Should not be equal
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldHandleMixedNullValues() {
        // Given
        id.setApplication(100);
        id.setName(null);

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName(null);

        // When & Then - Should be equal with matching null values
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);

        // Given - Change null to non-null
        otherId.setName("TEST");

        // When & Then - Should not be equal
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldHandleOneNullApplication() {
        // Given
        id.setApplication(null);
        id.setName("TEST");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("TEST");

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldHandleOneNullName() {
        // Given
        id.setApplication(100);
        id.setName(null);

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("TEST");

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void hashCode_shouldReturnSameValueForEqualObjects() {
        // Given
        id.setApplication(100);
        id.setName("TEST");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("TEST");

        // When & Then
        assertEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void hashCode_shouldReturnDifferentValueForDifferentObjects() {
        // Given
        id.setApplication(100);
        id.setName("TEST1");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(200);
        otherId.setName("TEST2");

        // When & Then
        assertNotEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void hashCode_shouldHandleNullValues() {
        // Given - Default constructor creates all null values
        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();

        // When & Then - Same null values should produce same hash code
        assertEquals(id.hashCode(), otherId.hashCode());

        // Given - Set one field
        id.setApplication(100);

        // When & Then - Different values should produce different hash codes
        assertNotEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void hashCode_shouldBeConsistent() {
        // Given
        id.setApplication(100);
        id.setName("CONSISTENT");

        // When
        int firstHash = id.hashCode();
        int secondHash = id.hashCode();

        // Then
        assertEquals(firstHash, secondHash);
    }

    @Test
    void hashCode_shouldHandleMixedNullValues() {
        // Given - Application set, name null
        id.setApplication(100);
        id.setName(null);

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName(null);

        // When & Then
        assertEquals(id.hashCode(), otherId.hashCode());

        // Given - Name set, application null
        id.setApplication(null);
        id.setName("TEST");

        otherId.setApplication(null);
        otherId.setName("TEST");

        // When & Then
        assertEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void id_shouldImplementSerializable() {
        // Then
        assertTrue(id instanceof java.io.Serializable);
    }

    @Test
    void id_shouldCreateWithDefaultConstructor() {
        // When
        T117ImgCoverSheetId newId = new T117ImgCoverSheetId();

        // Then - All fields should be null by default
        assertNull(newId.getApplication());
        assertNull(newId.getName());
    }

    @Test
    void id_shouldHandleCompleteCompositeKey() {
        // Given
        Integer application = 300;
        String name = "COMPLETE_KEY";

        // When
        id.setApplication(application);
        id.setName(name);

        // Then
        assertEquals(application, id.getApplication());
        assertEquals(name, id.getName());
    }

    @Test
    void id_shouldHandleFieldIndependence() {
        // Given
        id.setApplication(1);
        id.setName("ID1");

        // When - Create another ID to verify independence
        T117ImgCoverSheetId id2 = new T117ImgCoverSheetId();
        id2.setApplication(2);
        id2.setName("ID2");

        // Then - IDs should be independent
        assertEquals(1, id.getApplication());
        assertEquals("ID1", id.getName());
        assertEquals(2, id2.getApplication());
        assertEquals("ID2", id2.getName());
    }

    @Test
    void id_shouldHandleSpecialCharactersInName() {
        // Given
        String nameWithSpecialChars = "ID_!@#$%";

        // When
        id.setName(nameWithSpecialChars);

        // Then
        assertEquals(nameWithSpecialChars, id.getName());
    }

    @Test
    void id_shouldHandleUnicodeCharacters() {
        // Given
        String unicodeName = "ÏD_Ünïcödé";

        // When
        id.setName(unicodeName);

        // Then
        assertEquals(unicodeName, id.getName());
    }

    @Test
    void equals_shouldSupportSymmetricProperty() {
        // Given
        id.setApplication(100);
        id.setName("SYMMETRIC");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("SYMMETRIC");

        // When & Then - Symmetric: if x.equals(y), then y.equals(x)
        assertTrue(id.equals(otherId));
        assertTrue(otherId.equals(id));
    }

    @Test
    void equals_shouldSupportTransitiveProperty() {
        // Given
        id.setApplication(100);
        id.setName("TRANSITIVE");

        T117ImgCoverSheetId id2 = new T117ImgCoverSheetId();
        id2.setApplication(100);
        id2.setName("TRANSITIVE");

        T117ImgCoverSheetId id3 = new T117ImgCoverSheetId();
        id3.setApplication(100);
        id3.setName("TRANSITIVE");

        // When & Then - Transitive: if x.equals(y) and y.equals(z), then x.equals(z)
        assertTrue(id.equals(id2));
        assertTrue(id2.equals(id3));
        assertTrue(id.equals(id3));
    }

    @Test
    void equals_shouldSupportReflexiveProperty() {
        // Given
        id.setApplication(100);
        id.setName("REFLEXIVE");

        // When & Then - Reflexive: x.equals(x) should always be true
        assertTrue(id.equals(id));
    }

    @Test
    void equals_shouldSupportConsistentProperty() {
        // Given
        id.setApplication(100);
        id.setName("CONSISTENT");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName("CONSISTENT");

        // When & Then - Consistent: multiple calls should return same result
        boolean firstCall = id.equals(otherId);
        boolean secondCall = id.equals(otherId);
        assertEquals(firstCall, secondCall);
        assertTrue(firstCall);
        assertTrue(secondCall);
    }

    @Test
    void id_shouldSupportTypicalCoverSheetKeyScenarios() {
        // Test creating cover sheet keys for different scenarios
        
        // Scenario 1: Invoice cover sheet
        id.setApplication(100);
        id.setName("INVOICE");

        assertEquals(100, id.getApplication());
        assertEquals("INVOICE", id.getName());

        // Scenario 2: Purchase order cover sheet
        id.setApplication(200);
        id.setName("PO");

        assertEquals(200, id.getApplication());
        assertEquals("PO", id.getName());

        // Scenario 3: Same name, different application
        id.setApplication(300);
        id.setName("INVOICE");

        assertEquals(300, id.getApplication());
        assertEquals("INVOICE", id.getName());
    }

    @Test
    void id_shouldHandleZeroValues() {
        // Given
        id.setApplication(0);
        id.setName("ZERO_TEST");

        // When & Then
        assertEquals(0, id.getApplication());
        assertEquals("ZERO_TEST", id.getName());
    }

    @Test
    void id_shouldHandleNegativeValues() {
        // Given
        id.setApplication(-1);
        id.setName("NEGATIVE");

        // When & Then
        assertEquals(-1, id.getApplication());
        assertEquals("NEGATIVE", id.getName());
    }

    @Test
    void id_shouldMaintainStateAfterModification() {
        // Given
        id.setApplication(100);
        id.setName("ORIGINAL");

        // When - Modify one field
        id.setName("MODIFIED");

        // Then - Other field should remain unchanged
        assertEquals(100, id.getApplication());
        assertEquals("MODIFIED", id.getName());

        // When - Modify application
        id.setApplication(200);

        // Then - Name should remain unchanged
        assertEquals(200, id.getApplication());
        assertEquals("MODIFIED", id.getName());
    }

    @Test
    void equals_shouldHandlePartiallyNullCompositeKeys() {
        // Given - First ID with application null, name set
        id.setApplication(null);
        id.setName("TEST");

        // Second ID with application set, name null
        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName(null);

        // When & Then - Should not be equal
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);

        // Third ID with same null pattern as first
        T117ImgCoverSheetId thirdId = new T117ImgCoverSheetId();
        thirdId.setApplication(null);
        thirdId.setName("TEST");

        // When & Then - Should be equal
        assertTrue(id.equals(thirdId));
        assertEquals(id, thirdId);
    }

    @Test
    void id_shouldHandleLongNames() {
        // Given - Test with longer names (though entity constraint is 10 chars)
        String longName = "VERY_LONG_SHEET_NAME";

        // When
        id.setName(longName);

        // Then
        assertEquals(longName, id.getName());
    }

    @Test
    void id_shouldHandleNumericNames() {
        // Given
        String numericName = "123456";

        // When
        id.setName(numericName);

        // Then
        assertEquals(numericName, id.getName());
    }

    @Test
    void id_shouldHandleAlphanumericNames() {
        // Given
        String alphanumericName = "SHT123ABC";

        // When
        id.setName(alphanumericName);

        // Then
        assertEquals(alphanumericName, id.getName());
    }

    @Test
    void equals_shouldHandleBothFieldsNull() {
        // Given - Both IDs with both fields null
        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();

        // When & Then - Should be equal
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);
        assertEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void equals_shouldHandleOnlyApplicationSet() {
        // Given
        id.setApplication(100);
        id.setName(null);

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(100);
        otherId.setName(null);

        // When & Then
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);
        assertEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void equals_shouldHandleOnlyNameSet() {
        // Given
        id.setApplication(null);
        id.setName("TEST");

        T117ImgCoverSheetId otherId = new T117ImgCoverSheetId();
        otherId.setApplication(null);
        otherId.setName("TEST");

        // When & Then
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);
        assertEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void id_shouldSupportDualCompositeKeyFunctionality() {
        // Test that this ID class properly supports dual composite key (application + name)
        // unlike the triple key (application + name + sequence) for override entities
        
        // Given
        Integer application = 500;
        String name = "DUAL_KEY";

        // When
        id.setApplication(application);
        id.setName(name);

        // Then - Should have exactly 2 key components
        assertEquals(application, id.getApplication());
        assertEquals(name, id.getName());
        
        // Verify this creates a unique identity
        T117ImgCoverSheetId sameId = new T117ImgCoverSheetId();
        sameId.setApplication(application);
        sameId.setName(name);
        
        T117ImgCoverSheetId differentId = new T117ImgCoverSheetId();
        differentId.setApplication(application + 1);
        differentId.setName(name);

        assertTrue(id.equals(sameId));
        assertFalse(id.equals(differentId));
    }
}