package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.service.VCodReportSecurityExitService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class ImageParmDataServiceSimpleTest {

    @Mock
    private T222APRMRepository t222APRMRepository;
    @Mock
    private VCodReportSecurityExitService vCodReportSecurityExitService;

    private ImageParmDataServiceImpl imageParmDataService;

    private Map<String, String> hvwbaseTestData;
    private Map<String, String> cmbaseTestData;
    private Map<String, String> codbaseTestData;
    private Map<String, String> cmfldmapTestData;
    private Map<String, Map<String, String>> additionalParmMapsTestData;

    @BeforeEach
    void setUp() {
        // Create service instance manually
        imageParmDataService = new ImageParmDataServiceImpl(t222APRMRepository, vCodReportSecurityExitService);

        // Set up test data
        hvwbaseTestData = new HashMap<>();
        hvwbaseTestData.put("TEST_KEY_1", "TEST_VALUE_1");
        hvwbaseTestData.put("TEST_KEY_2", "TEST_VALUE_2");

        cmbaseTestData = new HashMap<>();
        cmbaseTestData.put("CMOD_KEY_1", "CMOD_VALUE_1");
        cmbaseTestData.put("CMOD_KEY_2", "CMOD_VALUE_2");

        codbaseTestData = new HashMap<>();
        codbaseTestData.put("COD_KEY_1", "COD_VALUE_1");
        codbaseTestData.put("COD_KEY_2", "COD_VALUE_2");

        cmfldmapTestData = new HashMap<>();
        cmfldmapTestData.put("FIELD_1", "FOLDER_1");
        cmfldmapTestData.put("FIELD_2", "FOLDER_2");

        additionalParmMapsTestData = new HashMap<>();
        Map<String, String> cmuserexData = new HashMap<>();
        cmuserexData.put("USER_KEY_1", "USER_VALUE_1");
        additionalParmMapsTestData.put(HVWConstants.CMUSEREX, cmuserexData);

        // Setup lenient mocks to avoid strict stubbing issues
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.HVWBASE))).thenReturn(hvwbaseTestData);
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.CMBASE))).thenReturn(cmbaseTestData);
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.CODBASE))).thenReturn(codbaseTestData);
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.CMFLDMAP))).thenReturn(cmfldmapTestData);
        lenient().when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalParmMapsTestData);
    }

    @Test
    void testGetParmDataByKeyByHvwbase() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
        assertEquals("TEST_VALUE_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByHvwbase("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);

        // Test null key
        String nullResult = imageParmDataService.getParmDataByKeyByHvwbase(null, "DEFAULT");
        assertEquals("DEFAULT", nullResult);
    }

    @Test
    void testGetParmDataByKeyByHvwbaseWithoutDefault() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1");
        assertEquals("TEST_VALUE_1", result);

        // Test non-existing key
        String nullResult = imageParmDataService.getParmDataByKeyByHvwbase("NON_EXISTING_KEY");
        assertNull(nullResult);
    }

    @Test
    void testGetParmDataByKeyByCmodbase() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByCmodbase("CMOD_KEY_1", "DEFAULT");
        assertEquals("CMOD_VALUE_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByCmodbase("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetParmDataByKeyByCODBase() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByCODBase("COD_KEY_1", "DEFAULT");
        assertEquals("COD_VALUE_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByCODBase("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetParmDataByKeyByCmodfld() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByCmodfld("FIELD_1", "DEFAULT");
        assertEquals("FOLDER_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByCmodfld("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetParmData() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing parm ID and key
        String result = imageParmDataService.getParmData(HVWConstants.CMUSEREX, "USER_KEY_1");
        assertEquals("USER_VALUE_1", result);

        // Test non-existing parm ID
        String nullResult = imageParmDataService.getParmData("NON_EXISTING_PARM_ID", "USER_KEY_1");
        assertNull(nullResult);

        // Test null parameters
        String nullParmIdResult = imageParmDataService.getParmData(null, "USER_KEY_1");
        assertNull(nullParmIdResult);

        String nullKeyResult = imageParmDataService.getParmData(HVWConstants.CMUSEREX, null);
        assertNull(nullKeyResult);
    }

    @Test
    void testGetParmDataMap() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test HVWBASE
        Map<String, String> hvwbaseResult = imageParmDataService.getParmDataMap(HVWConstants.HVWBASE);
        assertNotNull(hvwbaseResult);
        assertEquals(hvwbaseTestData.size(), hvwbaseResult.size());
        assertEquals("TEST_VALUE_1", hvwbaseResult.get("TEST_KEY_1"));

        // Test CMBASE
        Map<String, String> cmbaseResult = imageParmDataService.getParmDataMap(HVWConstants.CMBASE);
        assertNotNull(cmbaseResult);
        assertEquals(cmbaseTestData.size(), cmbaseResult.size());
        assertEquals("CMOD_VALUE_1", cmbaseResult.get("CMOD_KEY_1"));

        // Test CODBASE
        Map<String, String> codbaseResult = imageParmDataService.getParmDataMap(HVWConstants.CODBASE);
        assertNotNull(codbaseResult);
        assertEquals(codbaseTestData.size(), codbaseResult.size());
        assertEquals("COD_VALUE_1", codbaseResult.get("COD_KEY_1"));

        // Test additional parm ID
        Map<String, String> cmuserexResult = imageParmDataService.getParmDataMap(HVWConstants.CMUSEREX);
        assertNotNull(cmuserexResult);
        assertEquals("USER_VALUE_1", cmuserexResult.get("USER_KEY_1"));

        // Test non-existing parm ID
        Map<String, String> nullResult = imageParmDataService.getParmDataMap("NON_EXISTING_PARM_ID");
        assertNull(nullResult);

        // Test null parm ID
        Map<String, String> nullParmIdResult = imageParmDataService.getParmDataMap(null);
        assertNull(nullParmIdResult);
    }

    @Test
    void testRefreshParmData() {
        // This test just ensures refreshParmData doesn't throw an exception
        assertDoesNotThrow(() -> imageParmDataService.refreshParmData());
    }
}