package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222ImgExtendedparmRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for SaveXMLservice.
 * Tests the scheduled XML export functionality and error handling.
 */
@ExtendWith(MockitoExtension.class)
class SaveXMLServiceTest {

    @Mock
    private ImageParmDataService imageParmDataService;

    @Mock
    private T222ImgExtendedparmRepository extendedparmRepository;

    private SaveXMLService saveXMLService;

    @TempDir
    Path tempDir;

    private static final String TEST_FILENAME = "FLDR-PERMS-EXPORT.xml";
    private static final String TEST_EPARM_ID = "TEST_EPARM_ID";
    private static final String TEST_EPARM_KEY = "TEST_EPARM_KEY";

    @BeforeEach
    void setUp() {
        // Mock the ImageParmDataService calls used in constructor
        when(imageParmDataService.getParmDataByKeyByCmodbase("MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME",
                HVWConstants.MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME))
                .thenReturn(TEST_FILENAME);

        // Create the service after mocks are set up
        saveXMLService = new SaveXMLService(imageParmDataService, extendedparmRepository);

        // Set up test values via reflection
        ReflectionTestUtils.setField(saveXMLService, "exportARSXMLDirectory", tempDir.toString());
        ReflectionTestUtils.setField(saveXMLService, "eparmId", TEST_EPARM_ID);
        ReflectionTestUtils.setField(saveXMLService, "eparmKey", TEST_EPARM_KEY);
    }

    @Test
    void testExportExtendedParmDataToXML_Success() throws Exception {
        // Given
        doAnswer(invocation -> {
            FileOutputStream fos = invocation.getArgument(2);
            fos.write("test xml data".getBytes());
            fos.flush();
            return null;
        }).when(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When
        saveXMLService.exportExtendedParmDataToXML();

        // Then
        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // Just verify the method was called and completed without exception
        // File creation is a side effect that's harder to test with mocks
    }

    @Test
    void testExportExtendedParmDataToXML_CreatesDirectoryIfNotExists() throws Exception {
        // Given
        Path nonExistentDir = tempDir.resolve("non-existent-dir");
        ReflectionTestUtils.setField(saveXMLService, "exportARSXMLDirectory", nonExistentDir.toString());

        doAnswer(invocation -> {
            FileOutputStream fos = invocation.getArgument(2);
            fos.write("test xml data".getBytes());
            return null;
        }).when(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When
        saveXMLService.exportExtendedParmDataToXML();

        // Then
        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));
        // Directory creation is tested indirectly by successful method completion
    }

    @Test
    void testExportExtendedParmDataToXML_UsesConfiguredDirectory() throws Exception {
        // Given - exportARSXMLDirectory is already set in setUp()
        doNothing().when(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When
        saveXMLService.exportExtendedParmDataToXML();

        // Then
        // Should not call getParmDataByKeyByCODBase since directory is already
        // configured
        verify(imageParmDataService, never()).getParmDataByKeyByCODBase(anyString(), anyString());
        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));
    }

    @Test
    void testExportExtendedParmDataToXML_UsesParameterDataWhenDirectoryNotConfigured() throws Exception {
        // Given
        ReflectionTestUtils.setField(saveXMLService, "exportARSXMLDirectory", null);

        when(imageParmDataService.getParmDataByKeyByCODBase("CMOD_ARSXML_COD_DIRECTORY",
                HVWConstants.CMOD_ARSXML_COD_DIRECTORY))
                .thenReturn(tempDir.toString());

        doAnswer(invocation -> {
            FileOutputStream fos = invocation.getArgument(2);
            fos.write("test xml data".getBytes());
            return null;
        }).when(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When
        saveXMLService.exportExtendedParmDataToXML();

        // Then
        verify(imageParmDataService).getParmDataByKeyByCODBase("CMOD_ARSXML_COD_DIRECTORY",
                HVWConstants.CMOD_ARSXML_COD_DIRECTORY);
        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));
    }

    @Test
    void testExportExtendedParmDataToXML_UsesParameterDataWhenDirectoryEmpty() throws Exception {
        // Given
        ReflectionTestUtils.setField(saveXMLService, "exportARSXMLDirectory", "");

        when(imageParmDataService.getParmDataByKeyByCODBase("CMOD_ARSXML_COD_DIRECTORY",
                HVWConstants.CMOD_ARSXML_COD_DIRECTORY))
                .thenReturn(tempDir.toString());

        doAnswer(invocation -> {
            FileOutputStream fos = invocation.getArgument(2);
            fos.write("test xml data".getBytes());
            return null;
        }).when(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When
        saveXMLService.exportExtendedParmDataToXML();

        // Then
        verify(imageParmDataService).getParmDataByKeyByCODBase("CMOD_ARSXML_COD_DIRECTORY",
                HVWConstants.CMOD_ARSXML_COD_DIRECTORY);
        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));
    }

    @Test
    void testExportExtendedParmDataToXML_HandlesSQLException() throws Exception {

        doThrow(new SQLException("Database connection failed"))
                .when(extendedparmRepository).streamEparmDataByIdAndKey(
                        eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When & Then - should not throw exception, just log error
        assertThrows(RuntimeException.class,() -> saveXMLService.exportExtendedParmDataToXML());

        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));
    }
/* 
    @Test
    void testExportExtendedParmDataToXML_HandlesIOException() throws Exception {
        // Given - set invalid directory path to trigger IOException
        ReflectionTestUtils.setField(saveXMLService, "exportARSXMLDirectory", "/invalid/path/that/cannot/be/created");

        // When & Then - should throw RuntimeException wrapping IOException
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> saveXMLService.exportExtendedParmDataToXML());

        // The IOException might be wrapped or the cause might be different depending on the OS
        // Let's check if it's an IOException or if the message contains IO-related content
        assertTrue(exception.getCause() instanceof IOException ||
                  exception.getMessage().contains("IO error") ||
                  exception.getCause() != null && exception.getCause().getMessage().contains("No such file"));

        // Repository is not called because opening the file stream fails first
    }*/

    @Test
    void testExportExtendedParmDataToXML_HandlesGenericException() throws Exception {

        doThrow(new RuntimeException("Unexpected error"))
                .when(extendedparmRepository).streamEparmDataByIdAndKey(
                        eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When & Then - should throw RuntimeException wrapping the original RuntimeException
        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> saveXMLService.exportExtendedParmDataToXML());

        assertTrue(exception.getCause() instanceof RuntimeException);
        assertEquals("Unexpected error", exception.getCause().getMessage());

        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));
    }

    @Test
    void testConstructor_InitializesFilename() {
        // Given - reset mock to clear previous interactions and set up new expectation
        reset(imageParmDataService);
        when(imageParmDataService.getParmDataByKeyByCmodbase("MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME",
                HVWConstants.MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME))
                .thenReturn("TEST_FILENAME.xml");

        // When
        SaveXMLService newService = new SaveXMLService(imageParmDataService, extendedparmRepository);

        // Then - verify the method was called exactly once in this test
        verify(imageParmDataService, times(1)).getParmDataByKeyByCmodbase("MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME",
                HVWConstants.MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME);

        // Verify filename is stored (we can't directly access private field, but
        // constructor completed successfully)
        assertNotNull(newService);
    }

    @Test
    void testServiceIsComponent() {
        // Verify the service is annotated as a Spring component
        var componentAnnotation = SaveXMLService.class.getAnnotation(org.springframework.stereotype.Component.class);
        assertNotNull(componentAnnotation);
    }

    @Test
    void testExportExtendedParmDataToXML_FileStreamClosedProperly() throws Exception {
        // Given
        doAnswer(invocation -> {
            FileOutputStream fos = invocation.getArgument(2);
            fos.write("test data".getBytes());
            return null;
        }).when(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // When
        saveXMLService.exportExtendedParmDataToXML();

        // Then
        verify(extendedparmRepository).streamEparmDataByIdAndKey(
                eq(TEST_EPARM_ID), eq(TEST_EPARM_KEY), any(FileOutputStream.class));

        // The fact that the method completes without exception indicates proper stream
        // handling
        // File system tests are complex with mocks, so we focus on behavior
        // verification
    }
}