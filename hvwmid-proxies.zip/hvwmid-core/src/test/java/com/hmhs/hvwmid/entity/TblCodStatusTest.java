package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TblCodStatusTest {

    private TblCodStatus tblCodStatus;

    @BeforeEach
    void setUp() {
        tblCodStatus = new TblCodStatus();
    }

    @Test
    void testSetGetRequestId() {
        Integer requestId = 321;
        tblCodStatus.setRequestId(requestId);
        assertEquals(requestId, tblCodStatus.getRequestId());
    }

    @Test
    void testSetGetTimeCreate() {
        LocalDateTime now = LocalDateTime.now();
        tblCodStatus.setTimeCreate(now);
        assertEquals(now, tblCodStatus.getTimeCreate());
    }

    @Test
    void testSetGetUserId() {
        String userId = "tester";
        tblCodStatus.setUserId(userId);
        assertEquals(userId, tblCodStatus.getUserId());
    }

    @Test
    void testSetGetApiMethod() {
        String method = "POST /api/doc";
        tblCodStatus.setApiMethod(method);
        assertEquals(method, tblCodStatus.getApiMethod());
    }

    @Test
    void testSetGetHttpStatusCode() {
        String code = "200 OK";
        tblCodStatus.setHttpStatusCode(code);
        assertEquals(code, tblCodStatus.getHttpStatusCode());
    }

    @Test
    void testSetGetReturnCode() {
        String returnCode = "SUCCESS";
        tblCodStatus.setReturnCode(returnCode);
        assertEquals(returnCode, tblCodStatus.getReturnCode());
    }

    @Test
    void testSetGetStatusDescription() {
        String desc = "Document processed successfully";
        tblCodStatus.setStatusDescription(desc);
        assertEquals(desc, tblCodStatus.getStatusDescription());
    }

    @Test
    void testEqualityAndHashCode() {
        LocalDateTime now = LocalDateTime.now();

        TblCodStatus s1 = new TblCodStatus();
        s1.setTimeCreate(now);
        s1.setRequestId(10);

        TblCodStatus s2 = new TblCodStatus();
        s2.setTimeCreate(now);
        s2.setRequestId(10);

        TblCodStatus s3 = new TblCodStatus();
        s3.setTimeCreate(now);
        s3.setRequestId(11);

        assertEquals(s1, s2);
        assertNotEquals(s1, s3);
        assertEquals(s1.hashCode(), s2.hashCode());
    }
}
