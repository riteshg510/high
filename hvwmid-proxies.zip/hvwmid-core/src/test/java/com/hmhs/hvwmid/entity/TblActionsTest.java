package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TblActionsTest {

    private TblActions tblActions;

    @BeforeEach
    void setUp() {
        tblActions = new TblActions();
    }

    // Test for actionId
    @Test
    void testSetGetActionId() {
        String actionId = "ACTION123";
        tblActions.setActionId(actionId);
        assertEquals(actionId.toUpperCase(), tblActions.getActionId());
    }

    // Test for action
    @Test
    void testSetGetAction() {
        String action = "submit";
        tblActions.setAction(action);
        assertEquals(action, tblActions.getAction());
    }

    // Test for actionIcon (lowercase conversion)
    @Test
    void testSetGetActionIcon() {
        String actionIcon = "Icon123";
        tblActions.setActionIcon(actionIcon);
        assertEquals(actionIcon.toLowerCase(), tblActions.getActionIcon());

        tblActions.setActionIcon(null);
        assertNull(tblActions.getActionIcon());
    }

    // Test for actionOrder
    @Test
    void testSetGetActionOrder() {
        int actionOrder = 1;
        tblActions.setActionOrder(actionOrder);
        assertEquals(actionOrder, tblActions.getActionOrder());
    }

    // Test for actionType
    @Test
    void testSetGetActionType() {
        String actionType = "type1";
        tblActions.setActionType(actionType);
        assertEquals(actionType, tblActions.getActionType());
    }

    // Test for apiUrl
    @Test
    void testSetGetApiUrl() {
        String apiUrl = "http://example.com/api";
        tblActions.setApiUrl(apiUrl);
        assertEquals(apiUrl, tblActions.getApiUrl());
    }

    // Test for createTimestamp
    @Test
    void testSetGetCreateTimestamp() {
        LocalDateTime timestamp = LocalDateTime.of(2024, 10, 9, 12, 0, 0, 0);
        tblActions.setCreateTimestamp(timestamp);
        assertEquals(timestamp, tblActions.getCreateTimestamp());
    }

    // Test for formId
    @Test
    void testSetGetFormId() {
        String formId = "FORM123";
        tblActions.setFormId(formId);
        assertEquals(formId.toUpperCase(), tblActions.getFormId());
    }

    // Test for label
    @Test
    void testSetGetLabel() {
        String label = "Submit Action";
        tblActions.setLabel(label);
        assertEquals(label, tblActions.getLabel());
    }

    // Test for navigateUrl
    @Test
    void testSetGetNavigateUrl() {
        String navigateUrl = "http://example.com/navigate";
        tblActions.setNavigateUrl(navigateUrl);
        assertEquals(navigateUrl, tblActions.getNavigateUrl());
    }

    // Test for tableId
    @Test
    void testSetGetTableId() {
        String tableId = "TABLE123";
        tblActions.setTableId(tableId);
        assertEquals(tableId, tblActions.getTableId());
    }

    // Test for variant
    @Test
    void testSetGetVariant() {
        String variant = "variant1";
        tblActions.setVariant(variant);
        assertEquals(variant, tblActions.getVariant());
    }

    // Test for constructor with actionId
    @Test
    void testConstructorWithActionId() {
        String actionId = "ACTION123";
        TblActions action = new TblActions();
        action.setActionId(actionId);
        assertEquals(actionId.toUpperCase(), action.getActionId());
    }

    // Test for constructor with all fields (optional)
    @Test
    void testConstructorWithAllFields() {
        String actionId = "ACTION123";
        String action = "submit";
        String actionIcon = "icon123";
        int actionOrder = 1;
        String actionType = "type1";
        String apiUrl = "http://example.com/api";
        LocalDateTime createTimestamp = LocalDateTime.of(2024, 10, 9, 12, 0, 0, 0);
        String formId = "FORM123";
        String label = "Submit Action";
        String navigateUrl = "http://example.com/navigate";
        String tableId = "TABLE123";
        String variant = "variant1";

        TblActions actionEntity = new TblActions();
        actionEntity.setActionId(actionId);
        actionEntity.setAction(action);
        actionEntity.setActionIcon(actionIcon);
        actionEntity.setActionOrder(actionOrder);
        actionEntity.setActionType(actionType);
        actionEntity.setApiUrl(apiUrl);
        actionEntity.setCreateTimestamp(createTimestamp);
        actionEntity.setFormId(formId);
        actionEntity.setLabel(label);
        actionEntity.setNavigateUrl(navigateUrl);
        actionEntity.setTableId(tableId);
        actionEntity.setVariant(variant);

        assertEquals(actionId.toUpperCase(), actionEntity.getActionId());
        assertEquals(action, actionEntity.getAction());
        assertEquals(actionIcon.toLowerCase(), actionEntity.getActionIcon());
        assertEquals(actionOrder, actionEntity.getActionOrder());
        assertEquals(actionType, actionEntity.getActionType());
        assertEquals(apiUrl, actionEntity.getApiUrl());
        assertEquals(createTimestamp, actionEntity.getCreateTimestamp());
        assertEquals(formId.toUpperCase(), actionEntity.getFormId());
        assertEquals(label, actionEntity.getLabel());
        assertEquals(navigateUrl, actionEntity.getNavigateUrl());
        assertEquals(tableId, actionEntity.getTableId());
        assertEquals(variant, actionEntity.getVariant());
    }
}
