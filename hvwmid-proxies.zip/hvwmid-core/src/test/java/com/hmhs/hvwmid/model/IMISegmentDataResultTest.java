package com.hmhs.hvwmid.model;

import com.hmhs.hvwmid.entity.T222ADSG;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMISegmentDataResult POJO
 * Tests all getters, setters, and nested ServiceMessage class
 * 
 */
class IMISegmentDataResultTest {

    private IMISegmentDataResult imiSegmentDataResult;
    private List<T222ADSG> mockT222adsgList;

    @BeforeEach
    void setUp() {
        imiSegmentDataResult = new IMISegmentDataResult();
        
        // Create mock T222ADSG objects
        T222ADSG mockT222adsg1 = new T222ADSG();
        T222ADSG mockT222adsg2 = new T222ADSG();
        mockT222adsgList = Arrays.asList(mockT222adsg1, mockT222adsg2);
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        IMISegmentDataResult result = new IMISegmentDataResult();
        assertNotNull(result);
        assertNull(result.getT222adsgList());
        assertNull(result.getServiceMessage());
    }

    // ========== GETTER AND SETTER TESTS ==========

    @Test
    void testT222adsgListGetterAndSetter() {
        // Test setter
        imiSegmentDataResult.setT222adsgList(mockT222adsgList);
        
        // Test getter
        List<T222ADSG> result = imiSegmentDataResult.getT222adsgList();
        assertNotNull(result);
        assertEquals(mockT222adsgList, result);
        assertEquals(2, result.size());
    }

    @Test
    void testT222adsgListWithNull() {
        imiSegmentDataResult.setT222adsgList(null);
        assertNull(imiSegmentDataResult.getT222adsgList());
    }

    @Test
    void testT222adsgListWithEmptyList() {
        imiSegmentDataResult.setT222adsgList(Arrays.asList());
        assertNotNull(imiSegmentDataResult.getT222adsgList());
        assertTrue(imiSegmentDataResult.getT222adsgList().isEmpty());
    }

    @Test
    void testServiceMessageGetterAndSetter() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("Success");
        
        imiSegmentDataResult.setServiceMessage(serviceMessage);
        
        IMISegmentDataResult.ServiceMessage result = imiSegmentDataResult.getServiceMessage();
        assertNotNull(result);
        assertEquals(serviceMessage, result);
        assertEquals(200, result.getReturnCode());
        assertEquals("Success", result.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithNull() {
        imiSegmentDataResult.setServiceMessage(null);
        assertNull(imiSegmentDataResult.getServiceMessage());
    }

    // ========== NESTED CLASS TESTS - ServiceMessage ==========

    @Test
    void testServiceMessageDefaultConstructor() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        assertNotNull(serviceMessage);
        assertNull(serviceMessage.getReturnCode());
        assertNull(serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeGetterAndSetter() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        
        // Test setter
        serviceMessage.setReturnCode(201);
        
        // Test getter
        assertEquals(201, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithNull() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(null);
        assertNull(serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithZero() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(0);
        assertEquals(0, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithNegativeValue() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(-1);
        assertEquals(-1, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithMaxValue() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithMinValue() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionGetterAndSetter() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        
        // Test setter
        serviceMessage.setReturnCodeDescription("Created successfully");
        
        // Test getter
        assertEquals("Created successfully", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionWithNull() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCodeDescription(null);
        assertNull(serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionWithEmptyString() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCodeDescription("");
        assertEquals("", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionWithLongString() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        String longDescription = "A".repeat(1000);
        serviceMessage.setReturnCodeDescription(longDescription);
        assertEquals(longDescription, serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithAllFields() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(400);
        serviceMessage.setReturnCodeDescription("Bad Request");
        
        assertEquals(400, serviceMessage.getReturnCode());
        assertEquals("Bad Request", serviceMessage.getReturnCodeDescription());
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteIMISegmentDataResultSetup() {
        // Setup T222ADSG list
        T222ADSG t222adsg1 = new T222ADSG();
        T222ADSG t222adsg2 = new T222ADSG();
        T222ADSG t222adsg3 = new T222ADSG();
        List<T222ADSG> t222adsgList = Arrays.asList(t222adsg1, t222adsg2, t222adsg3);
        imiSegmentDataResult.setT222adsgList(t222adsgList);

        // Setup service message
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("Segment data retrieved successfully");
        imiSegmentDataResult.setServiceMessage(serviceMessage);

        // Verify all fields are set correctly
        assertNotNull(imiSegmentDataResult.getT222adsgList());
        assertEquals(3, imiSegmentDataResult.getT222adsgList().size());
        assertEquals(t222adsgList, imiSegmentDataResult.getT222adsgList());

        assertNotNull(imiSegmentDataResult.getServiceMessage());
        assertEquals(200, imiSegmentDataResult.getServiceMessage().getReturnCode());
        assertEquals("Segment data retrieved successfully", imiSegmentDataResult.getServiceMessage().getReturnCodeDescription());
    }

    @Test
    void testIMISegmentDataResultWithAllNullValues() {
        imiSegmentDataResult.setT222adsgList(null);
        imiSegmentDataResult.setServiceMessage(null);

        assertNull(imiSegmentDataResult.getT222adsgList());
        assertNull(imiSegmentDataResult.getServiceMessage());
    }

    @Test
    void testIMISegmentDataResultWithEmptyT222adsgList() {
        imiSegmentDataResult.setT222adsgList(Arrays.asList());
        
        assertNotNull(imiSegmentDataResult.getT222adsgList());
        assertTrue(imiSegmentDataResult.getT222adsgList().isEmpty());
    }

    @Test
    void testIMISegmentDataResultWithServiceMessageOnly() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(404);
        serviceMessage.setReturnCodeDescription("No segment data found");
        imiSegmentDataResult.setServiceMessage(serviceMessage);

        assertNull(imiSegmentDataResult.getT222adsgList());
        assertNotNull(imiSegmentDataResult.getServiceMessage());
        assertEquals(404, imiSegmentDataResult.getServiceMessage().getReturnCode());
        assertEquals("No segment data found", imiSegmentDataResult.getServiceMessage().getReturnCodeDescription());
    }

    @Test
    void testIMISegmentDataResultWithT222adsgListOnly() {
        T222ADSG t222adsg1 = new T222ADSG();
        T222ADSG t222adsg2 = new T222ADSG();
        List<T222ADSG> t222adsgList = Arrays.asList(t222adsg1, t222adsg2);
        imiSegmentDataResult.setT222adsgList(t222adsgList);

        assertNotNull(imiSegmentDataResult.getT222adsgList());
        assertEquals(2, imiSegmentDataResult.getT222adsgList().size());
        assertNull(imiSegmentDataResult.getServiceMessage());
    }

    // ========== EDGE CASE TESTS ==========

    @Test
    void testServiceMessageWithSpecialCharacters() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(500);
        serviceMessage.setReturnCodeDescription("Error with special chars: !@#$%^&*()");
        
        assertEquals(500, serviceMessage.getReturnCode());
        assertEquals("Error with special chars: !@#$%^&*()", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithUnicodeCharacters() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("Success with unicode: 测试成功");
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals("Success with unicode: 测试成功", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithNewlinesAndTabs() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(400);
        serviceMessage.setReturnCodeDescription("Error message with\nnewlines\tand\ttabs");
        
        assertEquals(400, serviceMessage.getReturnCode());
        assertEquals("Error message with\nnewlines\tand\ttabs", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithVeryLongDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        String veryLongDescription = "This is a very long description that contains a lot of text to test the handling of long strings in the service message return code description field. ".repeat(10);
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription(veryLongDescription);
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals(veryLongDescription, serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithDifferentReturnCodes() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        
        // Test various return codes
        int[] returnCodes = {0, 1, 100, 200, 201, 204, 300, 301, 302, 400, 401, 403, 404, 405, 500, 501, 502, 503, 504};
        
        for (int returnCode : returnCodes) {
            serviceMessage.setReturnCode(returnCode);
            assertEquals(returnCode, serviceMessage.getReturnCode());
        }
    }

    @Test
    void testServiceMessageWithEmptyDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("");
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals("", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithWhitespaceDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("   ");
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals("   ", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithNumericDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("12345");
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals("12345", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithJsonLikeDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(400);
        serviceMessage.setReturnCodeDescription("{\"error\": \"Invalid request\", \"code\": 400}");
        
        assertEquals(400, serviceMessage.getReturnCode());
        assertEquals("{\"error\": \"Invalid request\", \"code\": 400}", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithHtmlDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(500);
        serviceMessage.setReturnCodeDescription("<html><body><h1>Internal Server Error</h1></body></html>");
        
        assertEquals(500, serviceMessage.getReturnCode());
        assertEquals("<html><body><h1>Internal Server Error</h1></body></html>", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithXmlDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("<response><status>success</status><message>Operation completed</message></response>");
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals("<response><status>success</status><message>Operation completed</message></response>", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithSqlLikeDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(500);
        serviceMessage.setReturnCodeDescription("SELECT * FROM t222adsg WHERE segment_name = 'test'");
        
        assertEquals(500, serviceMessage.getReturnCode());
        assertEquals("SELECT * FROM t222adsg WHERE segment_name = 'test'", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithUrlDescription() {
        IMISegmentDataResult.ServiceMessage serviceMessage = new IMISegmentDataResult.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("https://api.example.com/segment-data?param1=value1&param2=value2");
        
        assertEquals(200, serviceMessage.getReturnCode());
        assertEquals("https://api.example.com/segment-data?param1=value1&param2=value2", serviceMessage.getReturnCodeDescription());
    }
}
