package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.entity.VCodReportSecurityExit;
import com.hmhs.hvwmid.repository.VCodReportSecurityExitRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.SQLException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for VCodReportSecurityExitServiceImpl.
 * Tests the CMOD security exit data retrieval and mapping functionality.
 */
@ExtendWith(MockitoExtension.class)
class VCodReportSecurityExitServiceImplTest {

    @Mock
    private VCodReportSecurityExitRepository repository;

    @InjectMocks
    private VCodReportSecurityExitServiceImpl service;

    @BeforeEach
    void setUp() {
        // Setup is handled by @InjectMocks and @Mock annotations
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_Success() throws SQLException {
        // Given
        List<VCodReportSecurityExit> mockData = createMockSecurityExitData();
        when(repository.getSecurityExitData()).thenReturn(mockData);

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertEquals(3, result.size());

        // Verify APP1 mapping
        assertTrue(result.containsKey("APP1"));
        Map<String, String> app1Data = result.get("APP1");
        assertEquals("INDEX1", app1Data.get("Index"));
        assertEquals("BPD1", app1Data.get("BpdId"));

        // Verify APP2 mapping
        assertTrue(result.containsKey("APP2"));
        Map<String, String> app2Data = result.get("APP2");
        assertEquals("INDEX2", app2Data.get("Index"));
        assertEquals("BPD2", app2Data.get("BpdId"));

        // Verify APP3 mapping (with trimmed application name)
        assertTrue(result.containsKey("APP3"));
        Map<String, String> app3Data = result.get("APP3");
        assertEquals("INDEX3", app3Data.get("Index"));
        assertEquals("BPD3", app3Data.get("BpdId"));

        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_EmptyResult() throws SQLException {
        // Given
        when(repository.getSecurityExitData()).thenReturn(Collections.emptyList());

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_FiltersNullApplications() throws SQLException {
        // Given
        List<VCodReportSecurityExit> mockData = Arrays.asList(
            createSecurityExit(null, "INDEX1", "BPD1"),
            createSecurityExit("APP1", "INDEX1", "BPD1"),
            createSecurityExit("", "INDEX2", "BPD2")
        );
        when(repository.getSecurityExitData()).thenReturn(mockData);

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size()); // Only APP1 should be included
        assertTrue(result.containsKey("APP1"));
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_FiltersEmptyStrings() throws SQLException {
        // Given
        List<VCodReportSecurityExit> mockData = Arrays.asList(
            createSecurityExit("APP1", "", "BPD1"),        // Empty index
            createSecurityExit("APP2", "INDEX2", ""),      // Empty BPD ID
            createSecurityExit("APP3", null, "BPD3"),      // Null index
            createSecurityExit("APP4", "INDEX4", null),    // Null BPD ID
            createSecurityExit("APP5", "INDEX5", "BPD5")   // Valid entry
        );
        when(repository.getSecurityExitData()).thenReturn(mockData);

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size()); // Only APP5 should be included
        assertTrue(result.containsKey("APP5"));
        assertEquals("INDEX5", result.get("APP5").get("Index"));
        assertEquals("BPD5", result.get("APP5").get("BpdId"));
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_HandlesWhitespace() throws SQLException {
        // Given
        List<VCodReportSecurityExit> mockData = Arrays.asList(
            createSecurityExit("  APP1  ", "INDEX1", "BPD1"),    // Application with whitespace
            createSecurityExit("   ", "INDEX2", "BPD2"),         // Only whitespace
            createSecurityExit("APP3", "  INDEX3  ", "  BPD3  ") // Index/BPD with whitespace
        );
        when(repository.getSecurityExitData()).thenReturn(mockData);

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        
        // Verify trimmed application name is used as key
        assertTrue(result.containsKey("APP1"));
        assertTrue(result.containsKey("APP3"));
        
        // Verify data is stored correctly (should preserve original spacing for index/bpdid)
        assertEquals("INDEX1", result.get("APP1").get("Index"));
        assertEquals("BPD1", result.get("APP1").get("BpdId"));
        assertEquals("  INDEX3  ", result.get("APP3").get("Index"));
        assertEquals("  BPD3  ", result.get("APP3").get("BpdId"));
        
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_HandlesRepositoryException() {
        // Given
        when(repository.getSecurityExitData()).thenThrow(new RuntimeException("Database connection failed"));

        // When & Then
        SQLException exception = assertThrows(SQLException.class, 
            () -> service.getCmodIndexBpdIdByCmodApplication());
        
        assertTrue(exception.getMessage().contains("Exception in getting Parm Data from DB2"));
        assertTrue(exception.getMessage().contains("Database connection failed"));
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_HandlesNullRepositoryResult() {
        // Given
        when(repository.getSecurityExitData()).thenReturn(null);

        // When & Then
        SQLException exception = assertThrows(SQLException.class, 
            () -> service.getCmodIndexBpdIdByCmodApplication());
        
        assertTrue(exception.getMessage().contains("Exception in getting Parm Data from DB2"));
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_OverwritesDuplicateApplications() throws SQLException {
        // Given - same application appears twice with different data
        List<VCodReportSecurityExit> mockData = Arrays.asList(
            createSecurityExit("APP1", "INDEX1", "BPD1"),
            createSecurityExit("APP1", "INDEX2", "BPD2")  // Same app, different data
        );
        when(repository.getSecurityExitData()).thenReturn(mockData);

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.containsKey("APP1"));
        
        // Should contain the last processed entry
        Map<String, String> app1Data = result.get("APP1");
        assertEquals("INDEX2", app1Data.get("Index"));
        assertEquals("BPD2", app1Data.get("BpdId"));
        
        verify(repository).getSecurityExitData();
    }

    @Test
    void testGetCmodIndexBpdIdByCmodApplication_ReturnsCorrectMapStructure() throws SQLException {
        // Given
        List<VCodReportSecurityExit> mockData = Arrays.asList(
            createSecurityExit("APP1", "INDEX1", "BPD1")
        );
        when(repository.getSecurityExitData()).thenReturn(mockData);

        // When
        Map<String, Map<String, String>> result = service.getCmodIndexBpdIdByCmodApplication();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        
        Map<String, String> innerMap = result.get("APP1");
        assertNotNull(innerMap);
        assertEquals(2, innerMap.size());
        assertTrue(innerMap.containsKey("Index"));
        assertTrue(innerMap.containsKey("BpdId"));
        assertEquals("INDEX1", innerMap.get("Index"));
        assertEquals("BPD1", innerMap.get("BpdId"));
        
        verify(repository).getSecurityExitData();
    }

    @Test
    void testServiceAnnotation() {
        // Verify the service is annotated as a Spring service
        var serviceAnnotation = VCodReportSecurityExitServiceImpl.class.getAnnotation(org.springframework.stereotype.Service.class);
        assertNotNull(serviceAnnotation);
    }

    @Test
    void testConstructorInjection() {
        // Verify constructor accepts repository dependency
        assertNotNull(service);
        // Repository is injected via constructor - tested implicitly through other tests
    }

    // Helper methods

    private List<VCodReportSecurityExit> createMockSecurityExitData() {
        return Arrays.asList(
            createSecurityExit("APP1", "INDEX1", "BPD1"),
            createSecurityExit("APP2", "INDEX2", "BPD2"),
            createSecurityExit("  APP3  ", "INDEX3", "BPD3"), // Test trimming
            createSecurityExit("APP4", "", "BPD4"),           // Empty index - should be filtered
            createSecurityExit("APP5", "INDEX5", ""),         // Empty BPD - should be filtered
            createSecurityExit(null, "INDEX6", "BPD6"),       // Null app - should be filtered
            createSecurityExit("", "INDEX7", "BPD7")          // Empty app - should be filtered
        );
    }

    private VCodReportSecurityExit createSecurityExit(String cmodApplication, String cmodIndex, String bpdId) {
        VCodReportSecurityExit entity = new VCodReportSecurityExit();
        entity.setCmodApplication(cmodApplication);
        entity.setCmodIndex(cmodIndex);
        entity.setBpdId(bpdId);
        return entity;
    }
}