package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class T222ImgExtendedparmIdTest {

    @Test
    void testSettersAndGetters() {
        T222ImgExtendedparmId id = new T222ImgExtendedparmId();

        id.setEparmId("ID001");
        id.setEparmKey("KEY001");
        id.setEsequenceNo(123);

        assertEquals("ID001", id.getEparmId());
        assertEquals("KEY001", id.getEparmKey());
        assertEquals(123, id.getEsequenceNo());
    }

    @Test
    void testEqualsAndHashCode_sameValues_shouldBeEqual() {
        T222ImgExtendedparmId id1 = new T222ImgExtendedparmId();
        id1.setEparmId("ID001");
        id1.setEparmKey("KEY001");
        id1.setEsequenceNo(123);

        T222ImgExtendedparmId id2 = new T222ImgExtendedparmId();
        id2.setEparmId("ID001");
        id2.setEparmKey("KEY001");
        id2.setEsequenceNo(123);

        assertEquals(id1, id2);
        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testEqualsAndHashCode_differentValues_shouldNotBeEqual() {
        T222ImgExtendedparmId id1 = new T222ImgExtendedparmId();
        id1.setEparmId("ID001");
        id1.setEparmKey("KEY001");
        id1.setEsequenceNo(123);

        T222ImgExtendedparmId id2 = new T222ImgExtendedparmId();
        id2.setEparmId("ID002");
        id2.setEparmKey("KEY002");
        id2.setEsequenceNo(999);

        assertNotEquals(id1, id2);
        assertNotEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testEqualsWithNullAndDifferentClass() {
        T222ImgExtendedparmId id = new T222ImgExtendedparmId();
        id.setEparmId("ID001");
        id.setEparmKey("KEY001");
        id.setEsequenceNo(123);

        assertNotEquals(id, null);
        assertNotEquals(id, "some string");
    }

    @Test
    void testEquals_selfComparison_shouldBeTrue() {
        T222ImgExtendedparmId id = new T222ImgExtendedparmId();
        id.setEparmId("ID001");
        id.setEparmKey("KEY001");
        id.setEsequenceNo(123);

        assertEquals(id, id);
    }
}
