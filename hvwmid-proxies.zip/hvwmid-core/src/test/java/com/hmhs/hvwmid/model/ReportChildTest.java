package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ReportChildTest {

    private ReportChild reportChild;

    // Setup method to initialize the ReportChild object before each test
    @BeforeEach
    void setUp() {
        reportChild = new ReportChild();
    }

    @Test
    void testGetAndSetLayoutType() {
        // Test set and get for the 'layoutType' field
        String testLayoutType = "grid";
        reportChild.setLayoutType(testLayoutType);
        assertEquals(testLayoutType, reportChild.getLayoutType(), "The layoutType should match the set value");
    }

    @Test
    void testGetAndSetDefaultValue() {
        // Test set and get for the 'defaultValue' field
        String testDefaultValue = "default value";
        reportChild.setDefaultValue(testDefaultValue);
        assertEquals(testDefaultValue, reportChild.getDefaultValue(), "The defaultValue should match the set value");
    }

    @Test
    void testGetAndSetId() {
        // Test set and get for the 'id' field
        String testId = "12345";
        reportChild.setId(testId);
        assertEquals(testId, reportChild.getId(), "The id should match the set value");
    }

    @Test
    void testGetAndSetInputType() {
        // Test set and get for the 'inputType' field
        String testInputType = "text";
        reportChild.setInputType(testInputType);
        assertEquals(testInputType, reportChild.getInputType(), "The inputType should match the set value");
    }

    @Test
    void testGetAndSetType() {
        // Test set and get for the 'type' field
        String testType = "string";
        reportChild.setType(testType);
        assertEquals(testType, reportChild.getType(), "The type should match the set value");
    }

    @Test
    void testGetAndSetName() {
        // Test set and get for the 'name' field
        String testName = "Report Child";
        reportChild.setName(testName);
        assertEquals(testName, reportChild.getName(), "The name should match the set value");
    }

    @Test
    void testGetAndSetMaxLength() {
        // Test set and get for the 'maxLength' field
        Integer testMaxLength = 100;
        reportChild.setMaxLength(testMaxLength);
        assertEquals(testMaxLength, reportChild.getMaxLength(), "The maxLength should match the set value");
    }

    @Test
    void testGetAndSetRequired() {
        // Test set and get for the 'required' field
        Boolean testRequired = true;
        reportChild.setRequired(testRequired);
        assertEquals(testRequired, reportChild.getRequired(), "The required value should match the set value");
    }

    @Test
    void testGetAndSetDisplay() {
        // Test set and get for the 'display' field
        Boolean testDisplay = true;
        reportChild.setDisplay(testDisplay);
        assertEquals(testDisplay, reportChild.getDisplay(), "The display value should match the set value");
    }

    @Test
    void testGetAndSetCollapsible() {
        // Test set and get for the 'collapsible' field
        Boolean testCollapsible = false;
        reportChild.setCollapsible(testCollapsible);
        assertEquals(testCollapsible, reportChild.getCollapsible(), "The collapsible value should match the set value");
    }

    @Test
    void testGetAndSetDefaultCollapsed() {
        // Test set and get for the 'defaultCollapsed' field
        Boolean testDefaultCollapsed = true;
        reportChild.setDefaultCollapsed(testDefaultCollapsed);
        assertEquals(testDefaultCollapsed, reportChild.getDefaultCollapsed(), "The defaultCollapsed value should match the set value");
    }

    @Test
    void testGetAndSetChildren() {
        // Test set and get for the 'children' field
        ReportChild child = new ReportChild();
        child.setId("child1");
        List<ReportChild> children = List.of(child);
        reportChild.setChildren(children);
        assertEquals(children, reportChild.getChildren(), "The children list should match the set value");
    }

    @Test
    void testSetReadonly() {
        // Test set and get for the 'readonly' field
        Boolean testReadonly = true;
        reportChild.setReadonly(testReadonly);
        assertEquals(testReadonly, reportChild.getReadonly(), "The readonly value should match the set value");
    }
}
