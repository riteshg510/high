package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblUserCabinets;
import com.hmhs.hvwmid.repository.UserCabinetRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class UserCabinetServiceTest {

    @InjectMocks
    private UserCabinetService userCabinetService;

    @Mock
    private UserCabinetRepository userCabinetRepository;

    private TblUserCabinets mockUserCabinet;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockUserCabinet = new TblUserCabinets();
        mockUserCabinet.setUserCabinetId("123_user1");
        mockUserCabinet.setUserId("user1");
        mockUserCabinet.setCabinetId("123");
    }

    @Test
    void addCabinetForUser() {
        // Act: Call the service method
        userCabinetService.addCabinetForUser("user1", "123");

        // Assert: Verify that the repository's save method was called exactly once
        verify(userCabinetRepository, times(1)).save(any(TblUserCabinets.class));
    }

    @Test
    void getUserCabinets() {
        // Arrange: Mock the repository findCabinetIdsByUserId method
        when(userCabinetRepository.findCabinetIdsByUserId("user1")).thenReturn(List.of("123", "456"));

        // Act: Call the service method
        List<String> result = userCabinetService.getUserCabinets("user1");

        // Assert: Verify the expected output
        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains("123"));
        assertTrue(result.contains("456"));
    }

    @Test
    void removeCabinetForUser() {
        // Arrange: Mock the repository's findByUserIdAndCabinetId method to return an Optional containing the mock cabinet
        when(userCabinetRepository.findByUserIdAndCabinetId("user1", "123")).thenReturn(Optional.of(mockUserCabinet));

        // Arrange: Mock the repository's delete method to do nothing
        doNothing().when(userCabinetRepository).delete(any(TblUserCabinets.class));

        // Act: Call the service method
        userCabinetService.removeCabinetForUser("user1", "123");

        // Assert: Verify if the repository's delete method was called
        verify(userCabinetRepository, times(1)).delete(any(TblUserCabinets.class));
    }

    @Test
    void removeCabinetForUser_CabinetNotFound() {
        // Arrange: Mock the repository's findByUserIdAndCabinetId method to return an empty Optional
        when(userCabinetRepository.findByUserIdAndCabinetId("user1", "123")).thenReturn(Optional.empty());

        // Act & Assert: Verify that an exception is thrown
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            userCabinetService.removeCabinetForUser("user1", "123");
        });

        // Assert: Verify the exception message
        assertEquals("Cabinet not found for user: user1, cabinetId: 123", exception.getMessage());
    }
}
