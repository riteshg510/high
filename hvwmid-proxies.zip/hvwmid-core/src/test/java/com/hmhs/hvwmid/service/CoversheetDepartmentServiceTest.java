package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.repository.T117ImgCoverDeptRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class CoversheetDepartmentServiceTest {

    @InjectMocks
    private CoversheetDepartmentServiceImpl coversheetDepartmentService;

    @Mock
    private T117ImgCoverDeptRepository departmentRepository;

    private T117ImgCoverDept mockDepartment;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockDepartment = new T117ImgCoverDept();
        mockDepartment.setDeptId(1);
        mockDepartment.setDescription("Test Department");
        mockDepartment.setMaintGroup("Test Maint Group");
        mockDepartment.setPrintGroup("Test Print Group");
    }

    @Test
    void getAllDepartments_ReturnsAllDepartments() {
        // Arrange
        T117ImgCoverDept department2 = new T117ImgCoverDept();
        department2.setDeptId(2);
        department2.setDescription("Department 2");
        department2.setMaintGroup("Maint Group 2");
        department2.setPrintGroup("Print Group 2");

        List<T117ImgCoverDept> expectedDepartments = Arrays.asList(mockDepartment, department2);
        when(departmentRepository.findAll()).thenReturn(expectedDepartments);

        // Act
        List<T117ImgCoverDept> result = coversheetDepartmentService.getAllDepartments();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedDepartments, result);
        verify(departmentRepository, times(1)).findAll();
    }

    @Test
    void getAllDepartments_ReturnsEmptyList_WhenNoDepartments() {
        // Arrange
        when(departmentRepository.findAll()).thenReturn(Arrays.asList());

        // Act
        List<T117ImgCoverDept> result = coversheetDepartmentService.getAllDepartments();

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(departmentRepository, times(1)).findAll();
    }

    @Test
    void saveDepartment_SavesAndReturnsDepartment() {
        // Arrange
        when(departmentRepository.save(any(T117ImgCoverDept.class))).thenReturn(mockDepartment);

        // Act
        T117ImgCoverDept result = coversheetDepartmentService.saveDepartment(mockDepartment);

        // Assert
        assertNotNull(result);
        assertEquals(mockDepartment, result);
        verify(departmentRepository, times(1)).save(mockDepartment);
    }

    @Test
    void deleteDepartment_DeletesById() {
        // Arrange
        Integer departmentId = 1;
        doNothing().when(departmentRepository).deleteById(departmentId);

        // Act
        coversheetDepartmentService.deleteDepartment(departmentId);

        // Assert
        verify(departmentRepository, times(1)).deleteById(departmentId);
    }

    @Test
    void getAllMaintananceGroups_ReturnsDistinctGroups() {
        // Arrange
        List<String> expectedGroups = Arrays.asList("Group 1", "Group 2", "Group 3");
        when(departmentRepository.findDistinctMaintGroups()).thenReturn(expectedGroups);

        // Act
        List<String> result = coversheetDepartmentService.getAllMaintananceGroups();

        // Assert
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(expectedGroups, result);
        verify(departmentRepository, times(1)).findDistinctMaintGroups();
    }

    @Test
    void getAllMaintananceGroups_ReturnsEmptyList_WhenNoGroups() {
        // Arrange
        when(departmentRepository.findDistinctMaintGroups()).thenReturn(Arrays.asList());

        // Act
        List<String> result = coversheetDepartmentService.getAllMaintananceGroups();

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(departmentRepository, times(1)).findDistinctMaintGroups();
    }

    @Test
    void getDepartmentById_ReturnsCorrectDepartment_WhenFound() {
        // Arrange
        Integer departmentId = 1;
        when(departmentRepository.findById(departmentId)).thenReturn(Optional.of(mockDepartment));

        // Act
        T117ImgCoverDept result = coversheetDepartmentService.getDepartmentById(departmentId);

        // Assert
        assertNotNull(result);
        assertEquals(mockDepartment, result);
        verify(departmentRepository, times(1)).findById(departmentId);
    }

    @Test
    void getDepartmentById_ThrowsException_WhenIdIsNull() {
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetDepartmentService.getDepartmentById(null);
        });

        assertEquals("Department ID cannot be null", exception.getMessage());
        verify(departmentRepository, never()).findById(any());
    }

    @Test
    void getDepartmentById_ThrowsException_WhenDepartmentNotFound() {
        // Arrange
        Integer departmentId = 999;
        when(departmentRepository.findById(departmentId)).thenReturn(Optional.empty());

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            coversheetDepartmentService.getDepartmentById(departmentId);
        });

        assertEquals("Department not found with ID: " + departmentId, exception.getMessage());
        verify(departmentRepository, times(1)).findById(departmentId);
    }
}