package com.hmhs.hvwmid.layouts;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.*;
import com.hmhs.hvwmid.model.Action;
import com.hmhs.hvwmid.model.ChoiceList;
import com.hmhs.hvwmid.model.Column;
import com.hmhs.hvwmid.model.Columns;
import com.hmhs.hvwmid.model.Form;
import com.hmhs.hvwmid.model.Property;
import com.hmhs.hvwmid.model.Section;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

class LayoutsAndActionsTest {

    @Mock
    private AppDataService service;

    @InjectMocks
    private LayoutsAndActions layoutsAndActions;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @Mock
    private TblSectionDetails mockTblSectionDetails;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        layoutsAndActions.setBasePath("/base");
        layoutsAndActions.setSearchPath("/search");
    }

    @Test
    void testCreateProperty_Select_WithPickListId_Ordered1_WithDependency() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(9);
        when(mockTblSectionDetails.getMultiSelect()).thenReturn((short) 0);
        when(mockTblSectionDetails.getPickListId()).thenReturn("departments");
        when(mockTblSectionDetails.getPickListOrder()).thenReturn(1);
        when(mockTblSectionDetails.getSectionId()).thenReturn("section1");
        when(mockTblSectionDetails.getFieldName()).thenReturn("Dept");
        when(mockTblSectionDetails.getIsDependentOn()).thenReturn("Region");

        List<String> mockChildren = List.of("Team1", "Team2");
        when(service.getChildList("section1", "Dept")).thenReturn(mockChildren);

        Property prop = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("select", prop.getInputType());
        assertEquals("string", prop.getType());
    }

    @Test
    void testCreateProperty_Date_MMDDYYYYFormat() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(2);
        when(mockTblSectionDetails.getValidationRules()).thenReturn("MMDDYYYY");
        when(mockTblSectionDetails.getValidationMessage()).thenReturn("Invalid date format");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("01012025");

        Property prop = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("date", prop.getType());
        assertEquals("date", prop.getInputType());
        assertEquals("MMDDYYYY", prop.getDateFormat());
        assertEquals("Invalid date format", prop.getPatternMessage());
        assertNotNull(prop.getPattern());
    }

    @Test
    void testCreateProperty_Date_CCYYMMDDFormat() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(2);
        when(mockTblSectionDetails.getValidationRules()).thenReturn("CCYYMMDD");
        when(mockTblSectionDetails.getValidationMessage()).thenReturn("Wrong format");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("20250401");

        Property prop = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("date", prop.getType());
        assertEquals("YYYYMMDD", prop.getDateFormat());
        assertEquals("Wrong format", prop.getPatternMessage());
        assertNotNull(prop.getPattern());
    }

    @Test
    void testCreateProperty_Date_OtherValidationFormat() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(2);
        when(mockTblSectionDetails.getValidationRules()).thenReturn("MM-DD");
        when(mockTblSectionDetails.getValidationMessage()).thenReturn("Custom error");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("01-01");

        Property prop = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("MM-DD", prop.getDateFormat());
        assertEquals("MM-DD", prop.getPattern());
        assertEquals("Custom error", prop.getPatternMessage());
    }

    @Test
    void testCreateProperty_Date_NoValidationRules() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(2);
        when(mockTblSectionDetails.getValidationRules()).thenReturn("");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("2025-04-01");

        Property prop = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("date", prop.getType());
        assertEquals("date", prop.getInputType());
        assertEquals("YYYYMMDD", prop.getDateFormat());
        assertNull(prop.getPattern());
    }

    @Test
    void testCreateChildSections() {
        TblSections mockSection1 = mock(TblSections.class);
        TblSections mockSection2 = mock(TblSections.class);
        List<TblSections> listSections = List.of(mockSection1, mockSection2);

        when(mockSection1.getSectionId()).thenReturn("sec1");
        when(mockSection2.getSectionId()).thenReturn("sec2");
        when(mockSection1.getFormId()).thenReturn("form1");
        when(mockSection2.getFormId()).thenReturn("form1");

        when(service.getSectionsByParentSectionId(anyString(), anyString())).thenReturn(Collections.emptyList());
        when(service.getSectionDetailsBySectionId(anyString())).thenReturn(Collections.emptyList());

        List<Section> sections = layoutsAndActions.createChildSections(listSections, true);

        assertNotNull(sections);
        assertEquals(2, sections.size());
        assertEquals("sec1", sections.get(0).getSid());
        assertEquals("sec2", sections.get(1).getSid());
    }

    @Test
    void testCreateChildSectionColumns() {
        TblSections sec1 = mock(TblSections.class);
        TblSections sec2 = mock(TblSections.class);

        when(sec1.getParentColumnNumber()).thenReturn(0);
        when(sec2.getParentColumnNumber()).thenReturn(1);

        when(sec1.getSectionId()).thenReturn("s1");
        when(sec1.getFormId()).thenReturn("f1");
        when(sec2.getSectionId()).thenReturn("s2");
        when(sec2.getFormId()).thenReturn("f1");

        when(service.getSectionsByParentSectionId(anyString(), anyString())).thenReturn(Collections.emptyList());
        when(service.getSectionDetailsBySectionId(anyString())).thenReturn(Collections.emptyList());

        List<TblSections> sections = List.of(sec1, sec2);

        Columns result = layoutsAndActions.createChildSectionColumns(sections, true);

        assertNotNull(result);
        assertEquals(2, result.getChildren().size());

        Column col1 = result.getChildren().get(0);
        Column col2 = result.getChildren().get(1);
        assertFalse(col1.getChildren().isEmpty());
        assertFalse(col2.getChildren().isEmpty());
    }

    @Test
    void testCreateChildSection_NoNestedSections() {
        TblSections section = mock(TblSections.class);
        when(section.getFormId()).thenReturn("form1");
        when(section.getSectionId()).thenReturn("sec1");
        when(section.getSectionName()).thenReturn("Test Section");

        when(service.getSectionsByParentSectionId("sec1", "form1")).thenReturn(Collections.emptyList());

        List<TblSectionDetails> fieldProps = new ArrayList<>();
        when(service.getSectionDetailsBySectionId("sec1")).thenReturn(fieldProps);

        Section result = layoutsAndActions.createChildSection(section, true);

        assertNotNull(result);
        assertEquals("sec1", result.getSid());
        assertEquals("Test Section", result.getName());
        assertFalse(result.isCollapsible());
        assertEquals("form1", result.getId());
    }

    @Test
    void testCreateProperty_ButtonType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(0);
        when(mockTblSectionDetails.getFieldName()).thenReturn("submitButton");
        when(mockTblSectionDetails.getLabel()).thenReturn("Submit");

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("button", property.getInputType());
    }

    @Test
    void testCreateProperty_ButtonType2() {
        // Mock TblSectionDetails for Button field type (case 0 in the switch statement)
        when(mockTblSectionDetails.getFieldType()).thenReturn(0); // "Button"
        when(mockTblSectionDetails.getFieldName()).thenReturn("submitBtn");
        when(mockTblSectionDetails.getLabel()).thenReturn("Submit");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("Submit Now");
        when(mockTblSectionDetails.getNotes()).thenReturn("This is a submit button.");
        when(mockTblSectionDetails.getReadOnly()).thenReturn((short) 0); // Read-only is false
        when(mockTblSectionDetails.getRequired()).thenReturn((short) 1); // Required field
        when(mockTblSectionDetails.getValidationRules()).thenReturn("");

        // Call createProperty method with the mocked TblSectionDetails
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Assertions for Button field type
        assertEquals("button", property.getInputType());
        assertEquals("boolean", property.getType()); // As per the switch case for Button
        assertEquals("submitBtn", property.getId());
        assertEquals("Submit", property.getName());
        assertEquals("$$ return true", property.getRequired()); // Should be a required field
        assertEquals("This is a submit button.", property.getDescription());
    }

    @Test
    void testCase6_LookupField_WithDependents() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(6); // case 6: Lookup
        when(mockTblSectionDetails.getFieldName()).thenReturn("CustomerLookup");
        when(mockTblSectionDetails.getPickListId()).thenReturn("CustomerList");
        when(mockTblSectionDetails.getIsDependentOn()).thenReturn("Region,Country");
        when(mockTblSectionDetails.getPickListOrder()).thenReturn(1);
        when(mockTblSectionDetails.getSectionId()).thenReturn("section123");

        when(service.getChildList("section123", "CustomerLookup")).thenReturn(List.of("City"));

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertTrue(property.getLookupApi().contains("lookup/CustomerLookup/{Region}/{Country}/{lookupValue}"));
        assertEquals(List.of("Region", "Country"), property.getParentFields());
        assertEquals(List.of("City"), property.getChildFields());
        assertEquals("lookup", property.getInputType());
    }

    @Test
    void testCase7_NumberField() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(7); // case 7: Number
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("42.0");
        when(mockTblSectionDetails.getMaximum()).thenReturn((int) 100.0);
        when(mockTblSectionDetails.getMinimum()).thenReturn((int) 1.0);

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals(42.0, property.getDefaultValue());
        assertEquals(100.0, property.getMaxValue());
        assertEquals(1.0, property.getMinValue());
        assertEquals("number", property.getType());
    }

    @Test
    void testCreateProperty_CheckboxType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(1);
        when(mockTblSectionDetails.getFieldName()).thenReturn("acceptTerms");
        when(mockTblSectionDetails.getPickListOptions()).thenReturn("Yes,No");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("Yes");

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("inputgroup", property.getInputType());
        assertTrue(property.isChoiceListMultiSelect());
    }

    @Test
    void testCreateProperty_DateType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(2);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("01/01/2023");
        when(mockTblSectionDetails.getValidationRules()).thenReturn("MMDDYYYY");

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("date", property.getType());
        assertEquals("MMDDYYYY", property.getDateFormat());
    }

    @Test
    void testCreateProperty_HiddenType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(4);
        when(mockTblSectionDetails.getFieldName()).thenReturn("hiddenField");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("secret");

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("hidden", property.getInputType());
        assertEquals("secret", property.getDefaultValue());
        assertFalse(property.isMultiline());
    }

    @Test
    void testCreateProperty_IntegerType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(5);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("100");
        when(mockTblSectionDetails.getMaximum()).thenReturn(200);
        when(mockTblSectionDetails.getMinimum()).thenReturn(50);

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("integer", property.getType());
        assertEquals(100, property.getDefaultValue());
        assertEquals(200, property.getMaxValue());
        assertEquals(50, property.getMinValue());
    }

    @Test
    void testCreateProperty_SelectType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(9);
        when(mockTblSectionDetails.getPickListId()).thenReturn("picklist123");
        when(mockTblSectionDetails.getPickListOptions()).thenReturn("Option1,Option2");

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("select", property.getInputType());
        assertNotNull(property.getChoiceList());
    }

    @Test
    void testCreateProperty_InvalidType() {
        // Given
        when(mockTblSectionDetails.getFieldType()).thenReturn(99); // Invalid type

        // When
        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        // Then
        assertNotNull(property);
        assertEquals("None", property.getType());
    }

    @Test
    void testGetLayoutAndActions() {
        // Arrange
        String formId = "123";
        List<Action> actionsMock = new ArrayList<>();
        Action action = new Action();
        action.setActionName("action1");
        actionsMock.add(action);

        List<Section> layoutMock = new ArrayList<>();
        Section section = new Section();
        section.setId("1");
        section.setName("section1");
        layoutMock.add(section);

        when(service.getActionsByFormId(formId)).thenReturn(createMockTblActions());
        when(service.getSections(formId)).thenReturn(createMockTblSections());

        // Act
        Form form = layoutsAndActions.getLayoutAndActions(formId);

        // Assert
        assertNotNull(form);
        assertEquals(1, form.getLayout().size());
    }

    @Test
    void testGetActionsByFormId() {
        // Arrange
        String formId = "123";
        when(service.getActionsByFormId(formId)).thenReturn(createMockTblActions());

        // Act
        List<Action> actions = layoutsAndActions.getActionsByFormId(formId);

        // Assert
        assertNotNull(actions);
    }

    @Test
    void testGetLayoutsByFormId() {
        // Arrange
        String formId = "123";
        when(service.getSections(formId)).thenReturn(createMockTblSections());

        // Act
        List<Section> sections = layoutsAndActions.getLayoutsByFormId(formId);

        // Assert
        assertNotNull(sections);
        assertEquals(1, sections.size());
    }

    @Test
    void testGetChoiceList() {
        // Arrange
        String pickListOptions = "Option1, Option2";

        // Act
        List<ChoiceList> choiceList = layoutsAndActions.getChoiceList(pickListOptions);

        // Assert
        assertNotNull(choiceList);
        assertEquals(2, choiceList.size());
        assertEquals("Option1", choiceList.get(0).getDisplayName());
    }

    @Test
    void testGetChoiceListByID() {
        // Arrange
        String pickListId = "1";
        when(service.getPickList(pickListId)).thenReturn(createMockPickListItems());

        // Act
        List<ChoiceList> choiceList = layoutsAndActions.getChoiceListByID(pickListId);

        // Assert
        assertNotNull(choiceList);
    }

    @Test
    void testCreateProperty_StaticHTML() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(10);
        when(mockTblSectionDetails.getFieldName()).thenReturn("Static Info");
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("<p>Hello</p>");

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("StaticInfo", property.getId());
        assertEquals("<p>Hello</p>", property.getHtmlText());
        assertEquals("", property.getDefaultValue());
        assertEquals("statichtml", property.getType());
        assertEquals("text", property.getLayoutType());
    }

    @Test
    void testCreateProperty_Switch() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(11);

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("switch", property.getInputType());
        assertEquals("boolean", property.getType());
        assertEquals("yes", property.getTrueLabel());
        assertEquals("no", property.getFalseLabel());
    }

    @Test
    void testCreateProperty_Text() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(12);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("SampleText");
        when(mockTblSectionDetails.getMaximum()).thenReturn(255);
        when(mockTblSectionDetails.getMinimum()).thenReturn(10);
        when(mockTblSectionDetails.getValidationRules()).thenReturn("[A-Za-z]+");
        when(mockTblSectionDetails.getValidationMessage()).thenReturn("Only letters allowed");

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("SampleText", property.getDefaultValue());
        assertEquals("text", property.getInputType());
        assertEquals(255, property.getMaxLength());
        assertEquals(10, property.getMinLength());
        assertFalse(property.isMultiline());
        assertEquals("[A-Za-z]+", property.getPattern());
        assertEquals("Only letters allowed", property.getPatternMessage());
        assertEquals("string", property.getType());
    }

    @Test
    void testCreateProperty_Textarea() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(13);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("Some multiline text");
        when(mockTblSectionDetails.getMaximum()).thenReturn(503);
        when(mockTblSectionDetails.getMinimum()).thenReturn(20);
        when(mockTblSectionDetails.getValidationRules()).thenReturn(".*");
        when(mockTblSectionDetails.getValidationMessage()).thenReturn("Enter some text");

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("Some multiline text", property.getDefaultValue());
        assertEquals("textarea", property.getInputType());
        assertEquals(503, property.getMaxLength());
        assertEquals(20, property.getMinLength());
        assertTrue(property.isMultiline());
        assertEquals(".*", property.getPattern());
        assertEquals("Enter some text", property.getPatternMessage());
        assertEquals("string", property.getType());
    }

    @Test
    void testCreateProperty_Boolean() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(14);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("Yes,No");

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals(List.of("No", "Yes"), property.getDefaultValue());
        assertFalse(property.isChoiceListMultiSelect());
        assertEquals("radiogroup", property.getInputType());
        assertFalse(property.isMultiline());
        assertEquals("Yes", property.getTrueLabel());
        assertEquals("No", property.getFalseLabel());
        assertEquals("boolean", property.getType());
    }

    @Test
    void testCreateProperty_StaticData() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(15);
        when(mockTblSectionDetails.getFieldName()).thenReturn("StaticDataField");
        when(mockTblSectionDetails.getHtmlContent()).thenReturn("<b>Static HTML</b>".getBytes(StandardCharsets.UTF_8));

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("StaticDataField", property.getId());
        assertEquals("statichtml", property.getType());
        assertEquals("text", property.getLayoutType());
    }

    @Test
    void testCreateProperty_Radio() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(8);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("Option1,Option2");
        when(mockTblSectionDetails.getPickListOptions()).thenReturn("Option1,Option2,Option3");

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals(List.of("Option2", "Option1"), property.getDefaultValue()); // reversed in loop
        assertFalse(property.isChoiceListMultiSelect());
        assertEquals("inputgroup", property.getInputType());
        assertFalse(property.isMultiline());
        assertEquals("string", property.getType());
    }

    private List<TblActions> createMockTblActions() {
        TblActions tblAction = new TblActions();
        tblAction.setAction("action1");
        tblAction.setActionIcon("icon1");
        tblAction.setActionType("type1");
        tblAction.setApiUrl("url1");
        tblAction.setLabel("label1");
        tblAction.setNavigateUrl("navigateUrl1");
        tblAction.setVariant("variant1");
        tblAction.setTableId("table1");
        return Collections.singletonList(tblAction);
    }

    @Test
    void testCreateProperty_DateTime() {
        when(mockTblSectionDetails.getFieldType()).thenReturn(3);
        when(mockTblSectionDetails.getDefaultValue()).thenReturn("2025-04-14T13:45");

        Property property = layoutsAndActions.createProperty(mockTblSectionDetails);

        assertEquals("2025-04-14T13:45", property.getDefaultValue());
        assertEquals("datetime", property.getInputType());
        assertEquals("datetime", property.getType());
    }

    private List<TblSections> createMockTblSections() {
        TblSections section = new TblSections();
        section.setSectionId("1");
        section.setSectionName("section1");
        section.setFormId("123");
        section.setIsRoot((short) 1); // Root section
        return Collections.singletonList(section);
    }

    private List<TblPickListItems> createMockPickListItems() {
        TblPickListItems item = new TblPickListItems();
        item.setKey("1");
        item.setDisplayName("Option1");
        TblPickListItems item2 = new TblPickListItems();
        item2.setKey("2");
        item2.setDisplayName("Option2");
        return Arrays.asList(item, item2);
    }

    @Test
    void testGetActionsByFormId_ReturnsMappedActions() {
        String fid = "form123";

        TblActions tblAction1 = new TblActions();
        tblAction1.setAction("act1");
        tblAction1.setActionIcon("icon1");
        tblAction1.setActionType("type1");
        tblAction1.setApiUrl("listApiUrl1");
        tblAction1.setLabel("label1");
        tblAction1.setNavigateUrl("navigateUrl1.html");
        tblAction1.setVariant("variant1");
        tblAction1.setTableId("table1");

        TblActions tblAction2 = new TblActions();
        tblAction2.setAction("act2");
        tblAction2.setActionIcon("icon2");
        tblAction2.setActionType("type2");
        tblAction2.setApiUrl("otherApiUrl");
        tblAction2.setLabel("label2");
        tblAction2.setNavigateUrl("navigateUrl2.html");
        tblAction2.setVariant("variant2");
        tblAction2.setTableId("table2");

        List<TblActions> tblActionsList = List.of(tblAction1, tblAction2);
        when(service.getActionsByFormId(fid)).thenReturn(tblActionsList);

        LayoutsAndActions spyLayouts = spy(layoutsAndActions);
        doAnswer(invocation -> invocation.getArgument(0)).when(spyLayouts).getUpdatedUrl(anyString());

        List<Action> result = spyLayouts.getActionsByFormId(fid);

        assertEquals(2, result.size());

        Action act1 = result.get(0);
        assertEquals("act1", act1.getActionName());
        assertEquals("/search/listApiUrl1", act1.getApiUrl());
        assertEquals("navigateUrl1.html", act1.getNavigateUrl());

        Action act2 = result.get(1);
        assertEquals("act2", act2.getActionName());
        assertEquals("otherApiUrl", act2.getApiUrl());
    }

    @Test
    void testGetQueryMap_EmptyOrNoQuery() {
        assertTrue(layoutsAndActions.getQueryMap("http://example.com").isEmpty());
        assertTrue(layoutsAndActions.getQueryMap("http://example.com?").isEmpty());
        assertTrue(layoutsAndActions.getQueryMap("").isEmpty());
    }

    @Test
    void testGetQueryMap_SingleParam() {
        Map<String, String> params = layoutsAndActions.getQueryMap("http://example.com?key=value");
        assertEquals(1, params.size());
        assertEquals("value", params.get("key"));
    }

    @Test
    void testGetQueryMap_MultipleParams() {
        Map<String, String> params = layoutsAndActions.getQueryMap("http://example.com?key1=value1&key2=value2");
        assertEquals(2, params.size());
        assertEquals("value1", params.get("key1"));
        assertEquals("value2", params.get("key2"));
    }

    @Test
    void testGetQueryMap_ParamWithoutValue() {
        Map<String, String> params = layoutsAndActions.getQueryMap("http://example.com?key1=&key2=value2");
        assertEquals(2, params.size());
        assertEquals("", params.get("key1"));
        assertEquals("value2", params.get("key2"));
    }

    @Test
    void testGetQueryMap_EncodedParams() {
        Map<String, String> params = layoutsAndActions
                .getQueryMap("http://example.com?key1=hello%20world&key2=value%2Bplus");
        assertEquals(2, params.size());
        assertEquals("hello world", params.get("key1"));
        assertEquals("value+plus", params.get("key2"));
    }

    @Test
    void testGetQueryMap_IgnoreFragment() {
        Map<String, String> params = layoutsAndActions.getQueryMap("http://example.com?key=value#section1");
        assertEquals(1, params.size());
        assertEquals("value", params.get("key"));
    }

    @Test
    void testGetQueryMap_MalformedParamHandledGracefully() {
        // param without = sign, should treat value as empty string
        Map<String, String> params = layoutsAndActions.getQueryMap("http://example.com?key1=value1&flag");
        assertEquals(2, params.size());
        assertEquals("value1", params.get("key1"));
        assertEquals("", params.get("flag"));
    }

    @Test
    void shouldReturnOriginalUrl_ifNoHtml() {
        String url = "https://example.com/view.pdf";
        String result = layoutsAndActions.getUpdatedUrl(url);
        assertEquals(url, result);
    }

    @Test
    void shouldReturnTransformedWorkflowUrl_forPlainHtmlFile() {
        String url = "work.html";
        when(service.getFormIdByFileName("work")).thenReturn(List.of(formWithId("123")));
        String result = layoutsAndActions.getUpdatedUrl(url);
        assertEquals(HVWConstants.WORKFLOW + "123", result);
    }

    @Test
    void shouldReturnTransformedCabinetScanUrl_forScanHtml() {
        String url = "scan.html";
        when(service.getFormIdByFileName("scan")).thenReturn(List.of(formWithId("456")));
        String result = layoutsAndActions.getUpdatedUrl(url);
        assertEquals(HVWConstants.CABINETSCAN + "456", result);
    }

    @Test
    void shouldReturnSingleCabinetUrl_whenFormFound_butNotWorkOrScan() {
        String url = "letter.html";
        when(service.getFormIdByFileName("letter")).thenReturn(List.of(formWithId("789")));
        String result = layoutsAndActions.getUpdatedUrl(url);
        assertEquals(HVWConstants.SINGLECABINET + "789", result);
    }

    @Test
    void shouldBuildRedirectUrl_whenUsingImgSessionMgrWithTemplate() {
        String url = "pages/ImgSessionMgr?template=work.html&user=test";
        when(service.getFormIdByFileName("work")).thenReturn(List.of(formWithId("123")));

        String result = layoutsAndActions.getUpdatedUrl(url);

        assertEquals(HVWConstants.WORKFLOW + "123?user=test", result);
    }

    @Test
    void shouldFallbackToOriginalImgSessionMgrUrl_whenNoFormFound() {
        String url = "pages/ImgSessionMgr?template=unknown.html&user=test";
        when(service.getFormIdByFileName("unknown")).thenReturn(List.of());

        String result = layoutsAndActions.getUpdatedUrl(url);

        assertEquals("pages/ImgSessionMgr?template=unknown.html&user=test", result);
    }

    @Test
    void shouldRemoveTrailingQuestionMark_whenRedirectQueryIsEmpty() {
        String url = "pages/ImgSessionMgr?template=scan.html";
        when(service.getFormIdByFileName("scan")).thenReturn(List.of(formWithId("456")));

        String result = layoutsAndActions.getUpdatedUrl(url);

        assertEquals(HVWConstants.CABINETSCAN + "456", result);
    }

    private TblForms formWithId(String id) {
        TblForms form = new TblForms();
        form.setFormId(id);
        return form;
    }
}