package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.repository.GenericUDFDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GenericUDFDaoTest {
    @Mock
    private JdbcTemplate jdbcTemplate;

    private GenericUDFDao udfDao;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        udfDao = new GenericUDFDao(jdbcTemplate, "DB2222056A_UDF");
    }

    @Test
    void testGetSequenceNumber() {
        when(jdbcTemplate.queryForObject("SELECT DB2222056A_UDF() FROM SYSIBM.SYSDUMMY1", String.class)).thenReturn("REQ123");
        String result = udfDao.getSequenceNumber();
        assertEquals("REQ123", result);
    }

    @Test
    void testGetSequenceNumberWithCollection() {
        when(jdbcTemplate.queryForObject("SELECT DEV_COLL.DB2222056A_UDF() FROM SYSIBM.SYSDUMMY1", Integer.class)).thenReturn(456789);
        int result = udfDao.getSequenceNumber("DEV_COLL");
        assertEquals(456789, result);
    }
}
