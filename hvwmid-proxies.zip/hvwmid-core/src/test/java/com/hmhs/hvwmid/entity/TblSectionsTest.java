package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TblSectionsTest {

    @Test
    void testSectionIdSetterAndGetterToUpperCase() {
        TblSections section = new TblSections();
        section.setSectionId("abc123xyz");
        assertEquals("ABC123XYZ", section.getSectionId());
    }

    @Test
    void testFormIdSetterAndGetter() {
        TblSections section = new TblSections();
        section.setFormId("FORM-001");
        assertEquals("FORM-001", section.getFormId());
    }

    @Test
    void testParentColumnNumberSetterAndGetter() {
        TblSections section = new TblSections();
        section.setParentColumnNumber(2);
        assertEquals(2, section.getParentColumnNumber());
    }

    @Test
    void testParentSectionIdSetterAndGetterToUpperCase() {
        TblSections section = new TblSections();
        section.setParentSectionId("parent-456");
        assertEquals("PARENT-456", section.getParentSectionId());
    }

    @Test
    void testSectionNameSetterAndGetter() {
        TblSections section = new TblSections();
        section.setSectionName("Main Section");
        assertEquals("Main Section", section.getSectionName());
    }
}
