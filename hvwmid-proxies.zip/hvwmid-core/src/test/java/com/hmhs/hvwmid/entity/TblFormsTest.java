package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TblFormsTest {

    private TblForms tblForm;

    @BeforeEach
    void setUp() {
        tblForm = new TblForms();
    }

    @Test
    void testSetAndGetFormId() {
        // Test setting and getting formId
        String formId = "form123";
        tblForm.setFormId(formId);
        assertEquals(formId.toUpperCase(), tblForm.getFormId(), "FormId should be correctly set and retrieved in uppercase.");
    }

    @Test
    void testSetAndGetFormName() {
        // Test setting and getting formName
        String formName = "Test Form";
        tblForm.setFormName(formName);
        assertEquals(formName, tblForm.getFormName(), "FormName should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetFormNameWithNull() {
        // Test setting and getting formName with null value
        tblForm.setFormName(null);
        assertNull(tblForm.getFormName(), "FormName should be null.");
    }

    @Test
    void testSetAndGetFileName() {
        // Test setting and getting fileName
        String fileName = "myFile.txt";
        tblForm.setFileName(fileName);
        assertEquals(fileName, tblForm.getFileName(), "FileName should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetFileNameWithNull() {
        // Test setting and getting fileName with null value
        tblForm.setFileName(null);
        assertNull(tblForm.getFileName(), "FileName should be null.");
    }

    @Test
    void testSetAndGetType() {
        // Test setting and getting type
        String type = "PDF";
        tblForm.setType(type);
        assertEquals(type, tblForm.getType(), "Type should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetTypeWithNull() {
        // Test setting and getting type with null value
        tblForm.setType(null);
        assertNull(tblForm.getType(), "Type should be null.");
    }
}
