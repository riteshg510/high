package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for T222ADSGId composite key
 * Tests constructors, getters, setters, equals, and hashCode methods
 * 
 */
class T222ADSGIdTest {

    private T222ADSGId t222adsgId;

    @BeforeEach
    void setUp() {
        t222adsgId = new T222ADSGId();
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        T222ADSGId id = new T222ADSGId();
        assertNotNull(id);
        assertNull(id.getImiDocumentId());
        assertNull(id.getSegmentSeqNo());
    }

    @Test
    void testParameterizedConstructor() {
        Integer imiDocumentId = 12345;
        Integer segmentSeqNo = 1;
        T222ADSGId id = new T222ADSGId(imiDocumentId, segmentSeqNo);
        assertEquals(imiDocumentId, id.getImiDocumentId());
        assertEquals(segmentSeqNo, id.getSegmentSeqNo());
    }

    @Test
    void testParameterizedConstructorWithNullValues() {
        T222ADSGId id = new T222ADSGId(null, null);
        assertNull(id.getImiDocumentId());
        assertNull(id.getSegmentSeqNo());
    }

    @Test
    void testParameterizedConstructorWithZeroValues() {
        T222ADSGId id = new T222ADSGId(0, 0);
        assertEquals(0, id.getImiDocumentId());
        assertEquals(0, id.getSegmentSeqNo());
    }

    @Test
    void testParameterizedConstructorWithNegativeValues() {
        T222ADSGId id = new T222ADSGId(-1, -1);
        assertEquals(-1, id.getImiDocumentId());
        assertEquals(-1, id.getSegmentSeqNo());
    }

    @Test
    void testParameterizedConstructorWithMaxValues() {
        T222ADSGId id = new T222ADSGId(Integer.MAX_VALUE, Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, id.getImiDocumentId());
        assertEquals(Integer.MAX_VALUE, id.getSegmentSeqNo());
    }

    @Test
    void testParameterizedConstructorWithMinValues() {
        T222ADSGId id = new T222ADSGId(Integer.MIN_VALUE, Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, id.getImiDocumentId());
        assertEquals(Integer.MIN_VALUE, id.getSegmentSeqNo());
    }

    // ========== GETTER AND SETTER TESTS ==========

    @Test
    void testImiDocumentIdGetterAndSetter() {
        Integer imiDocumentId = 12345;
        t222adsgId.setImiDocumentId(imiDocumentId);
        assertEquals(imiDocumentId, t222adsgId.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithNull() {
        t222adsgId.setImiDocumentId(null);
        assertNull(t222adsgId.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithZero() {
        t222adsgId.setImiDocumentId(0);
        assertEquals(0, t222adsgId.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithNegativeValue() {
        t222adsgId.setImiDocumentId(-1);
        assertEquals(-1, t222adsgId.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithMaxValue() {
        t222adsgId.setImiDocumentId(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, t222adsgId.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithMinValue() {
        t222adsgId.setImiDocumentId(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, t222adsgId.getImiDocumentId());
    }

    @Test
    void testSegmentSeqNoGetterAndSetter() {
        Integer segmentSeqNo = 1;
        t222adsgId.setSegmentSeqNo(segmentSeqNo);
        assertEquals(segmentSeqNo, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithNull() {
        t222adsgId.setSegmentSeqNo(null);
        assertNull(t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithZero() {
        t222adsgId.setSegmentSeqNo(0);
        assertEquals(0, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithNegativeValue() {
        t222adsgId.setSegmentSeqNo(-1);
        assertEquals(-1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithMaxValue() {
        t222adsgId.setSegmentSeqNo(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithMinValue() {
        t222adsgId.setSegmentSeqNo(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, t222adsgId.getSegmentSeqNo());
    }

    // ========== EQUALS METHOD TESTS ==========

    @Test
    void testEqualsWithSameInstance() {
        assertTrue(t222adsgId.equals(t222adsgId));
    }

    @Test
    void testEqualsWithNull() {
        assertFalse(t222adsgId.equals(null));
    }

    @Test
    void testEqualsWithDifferentClass() {
        assertFalse(t222adsgId.equals("not a T222ADSGId"));
    }

    @Test
    void testEqualsWithSameValues() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);
        
        T222ADSGId other = new T222ADSGId(12345, 1);
        assertTrue(t222adsgId.equals(other));
    }

    @Test
    void testEqualsWithDifferentImiDocumentId() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);
        
        T222ADSGId other = new T222ADSGId(54321, 1);
        assertFalse(t222adsgId.equals(other));
    }

    @Test
    void testEqualsWithDifferentSegmentSeqNo() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);
        
        T222ADSGId other = new T222ADSGId(12345, 2);
        assertFalse(t222adsgId.equals(other));
    }

    @Test
    void testEqualsWithZeroValues() {
        t222adsgId.setImiDocumentId(0);
        t222adsgId.setSegmentSeqNo(0);
        
        T222ADSGId other = new T222ADSGId(0, 0);
        assertTrue(t222adsgId.equals(other));
    }

    @Test
    void testEqualsWithNegativeValues() {
        t222adsgId.setImiDocumentId(-1);
        t222adsgId.setSegmentSeqNo(-1);
        
        T222ADSGId other = new T222ADSGId(-1, -1);
        assertTrue(t222adsgId.equals(other));
    }

    @Test
    void testEqualsWithMaxValues() {
        t222adsgId.setImiDocumentId(Integer.MAX_VALUE);
        t222adsgId.setSegmentSeqNo(Integer.MAX_VALUE);
        
        T222ADSGId other = new T222ADSGId(Integer.MAX_VALUE, Integer.MAX_VALUE);
        assertTrue(t222adsgId.equals(other));
    }

    @Test
    void testEqualsWithMinValues() {
        t222adsgId.setImiDocumentId(Integer.MIN_VALUE);
        t222adsgId.setSegmentSeqNo(Integer.MIN_VALUE);
        
        T222ADSGId other = new T222ADSGId(Integer.MIN_VALUE, Integer.MIN_VALUE);
        assertTrue(t222adsgId.equals(other));
    }

    // ========== HASHCODE METHOD TESTS ==========

    @Test
    void testHashCodeWithSameValues() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);
        
        T222ADSGId other = new T222ADSGId(12345, 1);
        assertEquals(t222adsgId.hashCode(), other.hashCode());
    }

    @Test
    void testHashCodeWithDifferentValues() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);
        
        T222ADSGId other = new T222ADSGId(54321, 2);
        assertNotEquals(t222adsgId.hashCode(), other.hashCode());
    }

    @Test
    void testHashCodeWithZeroValues() {
        t222adsgId.setImiDocumentId(0);
        t222adsgId.setSegmentSeqNo(0);
        
        T222ADSGId other = new T222ADSGId(0, 0);
        assertEquals(t222adsgId.hashCode(), other.hashCode());
    }

    @Test
    void testHashCodeWithNegativeValues() {
        t222adsgId.setImiDocumentId(-1);
        t222adsgId.setSegmentSeqNo(-1);
        
        T222ADSGId other = new T222ADSGId(-1, -1);
        assertEquals(t222adsgId.hashCode(), other.hashCode());
    }

    @Test
    void testHashCodeWithMaxValues() {
        t222adsgId.setImiDocumentId(Integer.MAX_VALUE);
        t222adsgId.setSegmentSeqNo(Integer.MAX_VALUE);
        
        T222ADSGId other = new T222ADSGId(Integer.MAX_VALUE, Integer.MAX_VALUE);
        assertEquals(t222adsgId.hashCode(), other.hashCode());
    }

    @Test
    void testHashCodeWithMinValues() {
        t222adsgId.setImiDocumentId(Integer.MIN_VALUE);
        t222adsgId.setSegmentSeqNo(Integer.MIN_VALUE);
        
        T222ADSGId other = new T222ADSGId(Integer.MIN_VALUE, Integer.MIN_VALUE);
        assertEquals(t222adsgId.hashCode(), other.hashCode());
    }

    @Test
    void testHashCodeConsistency() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);
        
        int hashCode1 = t222adsgId.hashCode();
        int hashCode2 = t222adsgId.hashCode();
        assertEquals(hashCode1, hashCode2);
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteT222ADSGIdSetup() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithAllNullValues() {
        t222adsgId.setImiDocumentId(null);
        t222adsgId.setSegmentSeqNo(null);

        assertNull(t222adsgId.getImiDocumentId());
        assertNull(t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithAllZeroValues() {
        t222adsgId.setImiDocumentId(0);
        t222adsgId.setSegmentSeqNo(0);

        assertEquals(0, t222adsgId.getImiDocumentId());
        assertEquals(0, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithAllNegativeValues() {
        t222adsgId.setImiDocumentId(-1);
        t222adsgId.setSegmentSeqNo(-1);

        assertEquals(-1, t222adsgId.getImiDocumentId());
        assertEquals(-1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithAllMaxValues() {
        t222adsgId.setImiDocumentId(Integer.MAX_VALUE);
        t222adsgId.setSegmentSeqNo(Integer.MAX_VALUE);

        assertEquals(Integer.MAX_VALUE, t222adsgId.getImiDocumentId());
        assertEquals(Integer.MAX_VALUE, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithAllMinValues() {
        t222adsgId.setImiDocumentId(Integer.MIN_VALUE);
        t222adsgId.setSegmentSeqNo(Integer.MIN_VALUE);

        assertEquals(Integer.MIN_VALUE, t222adsgId.getImiDocumentId());
        assertEquals(Integer.MIN_VALUE, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithMixedValues() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(0);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertEquals(0, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithReversedValues() {
        t222adsgId.setImiDocumentId(0);
        t222adsgId.setSegmentSeqNo(12345);

        assertEquals(0, t222adsgId.getImiDocumentId());
        assertEquals(12345, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithBoundaryValues() {
        t222adsgId.setImiDocumentId(1);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(1, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithLargeValues() {
        t222adsgId.setImiDocumentId(999999);
        t222adsgId.setSegmentSeqNo(999999);

        assertEquals(999999, t222adsgId.getImiDocumentId());
        assertEquals(999999, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithSmallValues() {
        t222adsgId.setImiDocumentId(1);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(1, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    // ========== EDGE CASE TESTS ==========

    @Test
    void testT222ADSGIdWithOneNullOneValue() {
        t222adsgId.setImiDocumentId(null);
        t222adsgId.setSegmentSeqNo(1);

        assertNull(t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneValueOneNull() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(null);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertNull(t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneZeroOneValue() {
        t222adsgId.setImiDocumentId(0);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(0, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneValueOneZero() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(0);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertEquals(0, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneNegativeOneValue() {
        t222adsgId.setImiDocumentId(-1);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(-1, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneValueOneNegative() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(-1);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertEquals(-1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneMaxOneValue() {
        t222adsgId.setImiDocumentId(Integer.MAX_VALUE);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(Integer.MAX_VALUE, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneValueOneMax() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(Integer.MAX_VALUE);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertEquals(Integer.MAX_VALUE, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneMinOneValue() {
        t222adsgId.setImiDocumentId(Integer.MIN_VALUE);
        t222adsgId.setSegmentSeqNo(1);

        assertEquals(Integer.MIN_VALUE, t222adsgId.getImiDocumentId());
        assertEquals(1, t222adsgId.getSegmentSeqNo());
    }

    @Test
    void testT222ADSGIdWithOneValueOneMin() {
        t222adsgId.setImiDocumentId(12345);
        t222adsgId.setSegmentSeqNo(Integer.MIN_VALUE);

        assertEquals(12345, t222adsgId.getImiDocumentId());
        assertEquals(Integer.MIN_VALUE, t222adsgId.getSegmentSeqNo());
    }
}
