package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ReportLayoutTest {

    private ReportLayout reportLayout;

    // Setup method to initialize ReportLayout object before each test
    @BeforeEach
    void setUp() {
        reportLayout = new ReportLayout();
    }

    @Test
    void testGetAndSetLayoutType() {
        // Test set and get for 'layoutType' field
        String testLayoutType = "grid";
        reportLayout.setLayoutType(testLayoutType);
        assertEquals(testLayoutType, reportLayout.getLayoutType(), "The layoutType should match the set value");
    }

    @Test
    void testGetAndSetName() {
        // Test set and get for 'name' field
        String testName = "Report Grid Layout";
        reportLayout.setName(testName);
        assertEquals(testName, reportLayout.getName(), "The name should match the set value");
    }

    @Test
    void testGetAndSetId() {
        // Test set and get for 'id' field
        String testId = "layout123";
        reportLayout.setId(testId);
        assertEquals(testId, reportLayout.getId(), "The id should match the set value");
    }

    @Test
    void testGetAndSetSid() {
        // Test set and get for 'sid' field
        String testSid = "sid456";
        reportLayout.setSid(testSid);
        assertEquals(testSid, reportLayout.getSid(), "The sid should match the set value");
    }

    @Test
    void testGetAndSetCollapsible() {
        // Test set and get for 'collapsible' field
        Boolean testCollapsible = true;
        reportLayout.setCollapsible(testCollapsible);
        assertEquals(testCollapsible, reportLayout.getCollapsible(), "The collapsible value should match the set value");
    }

    @Test
    void testGetAndSetDefaultCollapsed() {
        // Test set and get for 'defaultCollapsed' field
        Boolean testDefaultCollapsed = false;
        reportLayout.setDefaultCollapsed(testDefaultCollapsed);
        assertEquals(testDefaultCollapsed, reportLayout.getDefaultCollapsed(), "The defaultCollapsed value should match the set value");
    }

    @Test
    void testGetAndSetChildren() {
        // Test set and get for 'children' field (list of ReportChild objects)
        List<ReportChild> testChildren = new ArrayList<>();
        ReportChild child = new ReportChild();
        child.setId("child1");
        testChildren.add(child);

        reportLayout.setChildren(testChildren);
        assertEquals(testChildren, reportLayout.getChildren(), "The children list should match the set value");
    }

    @Test
    void testDefaultValues() {
        // Verify default values for the class fields
        assertNull(reportLayout.getLayoutType(), "The default layoutType should be null");
        assertNull(reportLayout.getName(), "The default name should be null");
        assertNull(reportLayout.getId(), "The default id should be null");
        assertNull(reportLayout.getSid(), "The default sid should be null");
        assertNull(reportLayout.getCollapsible(), "The default collapsible value should be null");
        assertNull(reportLayout.getDefaultCollapsed(), "The default defaultCollapsed value should be null");
        assertNull(reportLayout.getChildren(), "The default children list should be null");
    }
}
