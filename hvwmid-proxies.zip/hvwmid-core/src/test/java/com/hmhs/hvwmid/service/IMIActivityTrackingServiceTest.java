package com.hmhs.hvwmid.service;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertFalse;
 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Set;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.http.ResponseEntity;
 
import com.hmhs.hvwmid.entity.T222ADSG;
import com.hmhs.hvwmid.model.IMISearchData;
import com.hmhs.hvwmid.model.IMISearchRequest;
import com.hmhs.hvwmid.model.IMISearchResults;
import com.hmhs.hvwmid.model.IMISegmentDataResult;
import com.hmhs.hvwmid.model.IMIUISearchRequest;
import com.hmhs.hvwmid.repository.T222ADSGRepository;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.ImgGlobals2Utils;
import com.hmhs.hvwmid.utils.RestClientUtil;

@SuppressWarnings("unchecked")
class IMIActivityTrackingServiceTest {

    private static final String AUTH_TOKEN = "valid.jwt.token";
    private static final String MOCK_USER = "testUser";
    private static final String DB2INST1 = "DB2INST1";
    private static final String SEARCH = "search";
    private static final String STATUS = "status";
    private static final String ERROR = "error";
    private static final String SERVICE_ERROR = "Service error";
    private static final String PHI_ACCESS_GROUP = "IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT";
    
    // Test data constants
    private static final String TEST_ENVIRONMENT = "Noservice";
    private static final String TEST_HOST = "testhost";
    private static final String TEST_DATE_START = "01012023";
    private static final String TEST_DATE_END = "12312023";
    private static final String TEST_NAIC_BCBSMN = "BCBSMN";
    private static final String TEST_NAIC_HMRK = "HMRK";
    private static final String TEST_STATUS = "Test Status";
    private static final String DEFINITION = "definition";
    private static final String PAGINATION_ROW_COUNT = "paginationRowCount";
    private static final String NAIC_CODE = "naicCode";
    private static final String TEST_PATH = "/test/path";
    private static final String INVALID_VALUE = "invalid";
    private static final String API_URL = "apiUrl";
    private static final String ACTION_TYPE = "actionType";
    private static final String LABEL = "label";
    private static final String CREATE_CMOD_ACTION = "createCMODAction";
    private static final String TEST_TIMESTAMP = "2023-06-01 10:00:00.0";
    private static final String TEST_PARAM = "testParam";
    private static final String TEST_DATE_2023_01_01 = "2023-01-01";
    private static final String IS_TRANSMIT_TIMESTAMP_AFTER_CMOD_THRESHOLD = "isTransmitTimestampAfterCMODThreshold";
    private static final String DOCUMENT_STATUS_CD = "documentStatusCd";
    private static final String TEST_VALUE = "testValue";
    private static final String ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT = "ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT";
    private static final String ACCESS_DENIED = "Access denied";
    private static final String FAILED_TO_RETRIEVE_SEGMENT_DATA = "Failed to retrieve segment data";
    private static final String CMOD_SEARCH_LINK_DATE = "CMOD_SEARCH_LINK_DATE";
    private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";

    private IMIActivityTrackingService imiActivityTrackingService;
    private T222ADSGRepository t222ADSGRepository;
    private RestClientUtil restClientUtil;
    private ImageParmDataService imageParmDataService;

    @BeforeEach
    void setup() {
        t222ADSGRepository = mock(T222ADSGRepository.class);
        restClientUtil = mock(RestClientUtil.class);
        imageParmDataService = mock(ImageParmDataService.class);

        imiActivityTrackingService = new IMIActivityTrackingService();
        setField(imiActivityTrackingService, "t222ADSGRepository", t222ADSGRepository);
        setField(imiActivityTrackingService, "restClientUtil", restClientUtil);
        setField(imiActivityTrackingService, "imageParmDataService", imageParmDataService);
        setField(imiActivityTrackingService, "imiRetrieveBaseURL", "http://test.com/api");
        setField(imiActivityTrackingService, "environment", TEST_ENVIRONMENT);
        setField(imiActivityTrackingService, "viewImageFormId", "testFormId");
        setField(imiActivityTrackingService, "viewImageNavigatePath", TEST_PATH);
        setField(imiActivityTrackingService, "viewImageFormParam1", "param1");
        setField(imiActivityTrackingService, "viewImageFormParam2", "param2");
        setField(imiActivityTrackingService, "viewImageFormParam3", "param3");
        setField(imiActivityTrackingService, "viewImageFormParam4", "param4");
        setField(imiActivityTrackingService, "cmodNavigatePath", TEST_PATH);
        setField(imiActivityTrackingService, "cmodParam1", "cmodParam1");
        setField(imiActivityTrackingService, "cmodParam2", "cmodParam2");
        setField(imiActivityTrackingService, "phiAccessLdapGroup", PHI_ACCESS_GROUP);
        setField(imiActivityTrackingService, "imiRetrieveSegmentData", "http://test.com/segment");
    }

    private void setField(Object target, String fieldName, Object value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new IllegalStateException("Failed to set field: " + fieldName, e);
        }
    }

    @Test
    void testImiOnLoadSuccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(Arrays.asList("IMI-ACTIVITYTRK-BCBSMN-30701-INT", "IMI-ACTIVITYTRK-HMRK-54771-INT"));
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            
            // Mock buildNAICMap to return expected NAIC map
            Map<String, String> expectedNaicMap = new HashMap<>();
            expectedNaicMap.put(TEST_NAIC_BCBSMN, "30701");
            expectedNaicMap.put(TEST_NAIC_HMRK, "54771");
            utils.when(() -> HVWUtils.buildNAICMap(anyList())).thenReturn(expectedNaicMap);


            IMISearchData result = imiActivityTrackingService.imiOnLoad(AUTH_TOKEN);

            assertNotNull(result);
            assertNotNull(result.getNaicMap());
            assertTrue(result.getNaicMap().containsKey(TEST_NAIC_BCBSMN));
            assertTrue(result.getNaicMap().containsKey(TEST_NAIC_HMRK));
            assertEquals("30701", result.getNaicMap().get(TEST_NAIC_BCBSMN));
            assertEquals("54771", result.getNaicMap().get(TEST_NAIC_HMRK));
        }
    }

    @Test
    void testImiOnLoadNoLDAPGroups() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(null);
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);

            IMISearchData result = imiActivityTrackingService.imiOnLoad(AUTH_TOKEN);

            assertNotNull(result);
            assertNull(result.getNaicMap());
        }
    }

    @Test
    void testImiOnLoadEmptyLDAPGroups() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(new ArrayList<>());
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);

            IMISearchData result = imiActivityTrackingService.imiOnLoad(AUTH_TOKEN);

            assertNotNull(result);
            assertNull(result.getNaicMap());
        }
    }

    @Test
    void testImiRetrieveSuccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class);
             MockedStatic<ImgGlobals2Utils> imgUtils = mockStatic(ImgGlobals2Utils.class)) {
            
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);
            utils.when(() -> HVWUtils.convertTransmitFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertProcessFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertDocumentStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.hasPhiAccess(anyString(), anyString())).thenReturn(false);

            imgUtils.when(() -> ImgGlobals2Utils.getPropertyVal(any(), anyString())).thenReturn(TEST_VALUE);
            imgUtils.when(() -> ImgGlobals2Utils.setPropertyVals(any(), anyString(), any())).thenAnswer(invocation -> null);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setApplIdCdQuery("123");
            searchRequest.setApplIdCdDisplay(true);
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            Map<String, String> mockParmData = new HashMap<>();
            mockParmData.put(ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT, "50");
            when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

            when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(anyInt(), anyList())).thenReturn(new ArrayList<>());

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, SEARCH, "0", "20");

            assertNotNull(result);
        }
    }

    @Test
    void testImiRetrieveNextResults() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class);
             MockedStatic<ImgGlobals2Utils> imgUtils = mockStatic(ImgGlobals2Utils.class)) {
            
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);
            utils.when(() -> HVWUtils.convertTransmitFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertProcessFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertDocumentStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.hasPhiAccess(anyString(), anyString())).thenReturn(false);

            imgUtils.when(() -> ImgGlobals2Utils.getPropertyVal(any(), anyString())).thenReturn(TEST_VALUE);
            imgUtils.when(() -> ImgGlobals2Utils.setPropertyVals(any(), anyString(), any())).thenAnswer(invocation -> null);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(anyInt(), anyList())).thenReturn(new ArrayList<>());

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, "imiNextResults", "10", "20");

            assertNotNull(result);
        }
    }

    @Test
    void testImiRetrievePreviousResults() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class);
             MockedStatic<ImgGlobals2Utils> imgUtils = mockStatic(ImgGlobals2Utils.class)) {
            
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);
            utils.when(() -> HVWUtils.convertTransmitFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertProcessFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertDocumentStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.hasPhiAccess(anyString(), anyString())).thenReturn(false);

            imgUtils.when(() -> ImgGlobals2Utils.getPropertyVal(any(), anyString())).thenReturn(TEST_VALUE);
            imgUtils.when(() -> ImgGlobals2Utils.setPropertyVals(any(), anyString(), any())).thenAnswer(invocation -> null);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(anyInt(), anyList())).thenReturn(new ArrayList<>());

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, "imiPreviousResults", "5", "20");

            assertNotNull(result);
        }
    }

    @Test
    void testRetrieveSegmentDataSuccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN))
                    .thenReturn(Arrays.asList(PHI_ACCESS_GROUP));
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(true);

            IMISegmentDataResult segmentDataResult = new IMISegmentDataResult();
            List<T222ADSG> segments = new ArrayList<>();
            T222ADSG segment = new T222ADSG();
            segment.setSegmentName("TEST_SEGMENT");
            segment.setSegmentData("test data");
            segments.add(segment);
            segmentDataResult.setT222adsgList(segments);
            
            ResponseEntity<IMISegmentDataResult> mockResponse = ResponseEntity.ok(segmentDataResult);
            when(restClientUtil.getRequest(anyString(), anyString(), any(Class.class))).thenReturn(mockResponse);

            Map<String, Object> result = imiActivityTrackingService.retrieveSegmentData(MOCK_USER, AUTH_TOKEN, 123);

            assertNotNull(result);
            assertEquals("success", result.get(STATUS));
            assertNotNull(result.get("phiData"));
        }
    }

    @Test
    void testRetrieveSegmentDataNoAccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN))
                    .thenReturn(Arrays.asList("OTHER_GROUP"));
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(false);

            when(restClientUtil.getRequest(anyString(), anyString(), any(Class.class)))
                    .thenThrow(new RuntimeException(ACCESS_DENIED));

            Map<String, Object> result = imiActivityTrackingService.retrieveSegmentData(MOCK_USER, AUTH_TOKEN, 123);

            assertNotNull(result);
            assertEquals(ERROR, result.get(STATUS));
            assertTrue(result.get(ERROR).toString().contains(FAILED_TO_RETRIEVE_SEGMENT_DATA));
            
        }
    }

    @Test
    void testRetrieveSegmentDataNoLDAPGroups() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(null);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(false);

            when(restClientUtil.getRequest(anyString(), anyString(), any(Class.class)))
                    .thenThrow(new RuntimeException(ACCESS_DENIED));

            Map<String, Object> result = imiActivityTrackingService.retrieveSegmentData(MOCK_USER, AUTH_TOKEN, 123);

            assertNotNull(result);
            assertEquals(ERROR, result.get(STATUS));
            assertTrue(result.get(ERROR).toString().contains(FAILED_TO_RETRIEVE_SEGMENT_DATA));
            
        }
    }

    @Test
    void testRetrieveSegmentDataEmptyLDAPGroups() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(new ArrayList<>());
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(false);

            when(restClientUtil.getRequest(anyString(), anyString(), any(Class.class)))
                    .thenThrow(new RuntimeException(ACCESS_DENIED));

            Map<String, Object> result = imiActivityTrackingService.retrieveSegmentData(MOCK_USER, AUTH_TOKEN, 123);

            assertNotNull(result);
            assertEquals(ERROR, result.get(STATUS));
            assertTrue(result.get(ERROR).toString().contains(FAILED_TO_RETRIEVE_SEGMENT_DATA));
            
        }
    }

    @Test
    void testRetrieveSegmentDataServiceError() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN))
                    .thenReturn(Arrays.asList(PHI_ACCESS_GROUP));
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasPhiAccess(anyString(), anyString())).thenReturn(true);

            when(restClientUtil.getRequest(anyString(), anyString(), any(Class.class))).thenThrow(new RuntimeException(SERVICE_ERROR));

            Map<String, Object> result = imiActivityTrackingService.retrieveSegmentData(MOCK_USER, AUTH_TOKEN, 123);

            assertNotNull(result);
            assertEquals(ERROR, result.get(STATUS));
            assertTrue(result.get(ERROR).toString().contains(FAILED_TO_RETRIEVE_SEGMENT_DATA));
        }
    }

    @Test
    void testImiOnLoadException() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenThrow(new RuntimeException("JWT error"));

            // The method doesn't catch exceptions, so it should throw the RuntimeException
            try {
                IMISearchData result = imiActivityTrackingService.imiOnLoad(AUTH_TOKEN);
                // If we get here, the method should have handled the exception gracefully
                assertNotNull(result);
            } catch (Exception e) {
                // Expected behavior - the method should throw the RuntimeException
                assertTrue(e instanceof RuntimeException);
                assertTrue(e.getMessage().contains("JWT error"));
            }
        }
    }

    @Test
    void testImiRetrieveException() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class);
             MockedStatic<ImgGlobals2Utils> imgUtils = mockStatic(ImgGlobals2Utils.class)) {
            
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);

            imgUtils.when(() -> ImgGlobals2Utils.getPropertyVal(any(), anyString())).thenReturn(TEST_VALUE);
            imgUtils.when(() -> ImgGlobals2Utils.setPropertyVals(any(), anyString(), any())).thenAnswer(invocation -> null);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            Map<String, String> mockParmData = new HashMap<>();
            mockParmData.put(ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT, "50");
            when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

            when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(anyInt(), anyList())).thenReturn(new ArrayList<>());

            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenThrow(new RuntimeException(SERVICE_ERROR));

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, SEARCH, "0", "20");

            assertNotNull(result);
            // The method can return:
            // 1. Map (for exceptions in the main try-catch)
            // 2. String (for date parsing errors) 
            // 3. IMISearchData (for API call errors or successful responses)
            if (result instanceof Map) {
                Map<String, Object> resultMap = (Map<String, Object>) result;
                assertTrue(resultMap.containsKey(ERROR));
                assertTrue(resultMap.get(ERROR).toString().contains("Error occurred while retrieving Activity Tracking Search Results"));
            } else if (result instanceof String) {
                // If date parsing fails, it returns an empty string
                assertEquals("", result);
            } else if (result instanceof IMISearchData) {
                // If API call fails, it returns an IMISearchData with error information
                IMISearchData searchData = (IMISearchData) result;
                assertNotNull(searchData.getBaseMessage());
                assertTrue(searchData.getBaseMessage().getReturnCodeDescription().contains("Error occurred while retrieving Activity Tracking Search Results"));
            } else {
                fail("Unexpected result type: " + result.getClass());
            }
        }
    }

    @Test
    void testImiRetrieveInvalidAction() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            // Mock the RestClientUtil call
            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, "invalidAction", "0", "20");

            assertNotNull(result);
            // The service treats any non-null, non-empty action as valid and processes it as a search
            // So we just verify that a result is returned (it will be a table format response)
            assertTrue(result instanceof Map);
        }
    }

    @Test
    void testImiRetrieveNullSearchRequest() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);

            // This should throw a NullPointerException due to null search request
            try {
                Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, null, AUTH_TOKEN, SEARCH, "0", "20");
                // If we get here, the method should have handled the null gracefully
                assertNotNull(result);
            } catch (Exception e) {
                // Expected behavior - null search request should cause a NullPointerException
                assertTrue(e instanceof NullPointerException || 
                          e.getCause() instanceof NullPointerException);
            }
        }
    }

    @Test
    void testImiRetrieveEmptySearchRequest() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            // Mock the RestClientUtil call
            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, SEARCH, "0", "20");

            assertNotNull(result);
        }
    }

    @Test
    void testConvertToTableFormat() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            // Mock the hasPhiAccess method
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(false);
            // Mock the hasText method
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);
            // Mock the convert methods
            utils.when(() -> HVWUtils.convertTransmitFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertProcessFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertDocumentStatusCd(anyString())).thenReturn(TEST_STATUS);

            // Set paginationRowCount to ensure data is processed
            setField(imiActivityTrackingService, PAGINATION_ROW_COUNT, 250);

            // Mock the repository call for segment data
            when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(anyInt(), anyList())).thenReturn(new ArrayList<>());

            // Mock ImageParmDataService for CMOD threshold
            Map<String, String> mockParmData = new HashMap<>();
            mockParmData.put(CMOD_SEARCH_LINK_DATE, TEST_DATE_2023_01_01);
            when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

            // Create mock search data
            IMISearchData searchData = new IMISearchData();
            List<IMISearchResults> searchResults = new ArrayList<>();
            IMISearchResults results = new IMISearchResults();
            results.setNaicCode("TEST_NAIC");
            results.setTransmitTimeStamp("2023-01-01 10:00:00");
            results.setDocumentStatusCd("S");
            results.setImiDocumentId(123);
            searchResults.add(results);
            searchData.setSearchResultsList(searchResults);

            // Create mock search request with display fields
            IMISearchRequest searchRequest = new IMISearchRequest();
            searchRequest.setTransmitFileIdDisplay(true);
            searchRequest.setTransmitFileNameDisplay(true);
            searchRequest.setDocumentStatusCdDisplay(true);

            Map<String, Object> result = imiActivityTrackingService.convertToTableFormat(searchData, AUTH_TOKEN, searchRequest);

            assertNotNull(result);
            assertTrue(result instanceof Map);
            assertTrue(result.containsKey(DEFINITION));
            assertTrue(result.containsKey("data"));
            
            Map<String, Object> definition = (Map<String, Object>) result.get(DEFINITION);
            assertTrue(definition.containsKey("columns"));
            assertTrue(definition.containsKey("pagination"));
            
            List<Map<String, Object>> data = (List<Map<String, Object>>) result.get("data");
            assertNotNull(data);
            assertEquals(1, data.size());
        }
    }

    @Test
    void testConvertToTableFormatWithEmptySearchData() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(false);

            // Set paginationRowCount to ensure data is processed
            setField(imiActivityTrackingService, PAGINATION_ROW_COUNT, 250);

            // Create empty search data instead of null
            IMISearchData searchData = new IMISearchData();
            searchData.setSearchResultsList(new ArrayList<>());

            IMISearchRequest searchRequest = new IMISearchRequest();
            searchRequest.setTransmitFileIdDisplay(true);

            Map<String, Object> result = imiActivityTrackingService.convertToTableFormat(searchData, AUTH_TOKEN, searchRequest);

            assertNotNull(result);
            assertTrue(result instanceof Map);
            assertTrue(result.containsKey(DEFINITION));
            assertTrue(result.containsKey("data"));
        }
    }

    @Test
    void testConvertToTableFormatWithEmptySearchResults() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.hasPhiAccess(anyString(), anyString())).thenReturn(false);
            
            // Set paginationRowCount to ensure data is processed
            setField(imiActivityTrackingService, PAGINATION_ROW_COUNT, 250);

            IMISearchData searchData = new IMISearchData();
            searchData.setSearchResultsList(new ArrayList<>());

            IMISearchRequest searchRequest = new IMISearchRequest();
            searchRequest.setTransmitFileIdDisplay(true);

            Map<String, Object> result = imiActivityTrackingService.convertToTableFormat(searchData, AUTH_TOKEN, searchRequest);

            assertNotNull(result);
            assertTrue(result instanceof Map);
            assertTrue(result.containsKey(DEFINITION));
            assertTrue(result.containsKey("data"));
            
            List<Map<String, Object>> data = (List<Map<String, Object>>) result.get("data");
            assertNotNull(data);
            assertTrue(data.isEmpty());
        }
    }

    @Test
    void testConvertToTableFormatWithPHIAccess() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            // Mock the hasPhiAccess method to return true
            utils.when(() -> HVWUtils.hasPhiAccess(AUTH_TOKEN, PHI_ACCESS_GROUP)).thenReturn(true);
            // Mock the hasText method
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);
            // Mock the convert methods
            utils.when(() -> HVWUtils.convertTransmitFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertProcessFileStatusCd(anyString())).thenReturn(TEST_STATUS);
            utils.when(() -> HVWUtils.convertDocumentStatusCd(anyString())).thenReturn(TEST_STATUS);

            // Set paginationRowCount to ensure data is processed
            setField(imiActivityTrackingService, PAGINATION_ROW_COUNT, 250);

            // Mock the repository call for segment data
            when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(anyInt(), anyList())).thenReturn(new ArrayList<>());

            // Create mock search data
            IMISearchData searchData = new IMISearchData();
            List<IMISearchResults> searchResults = new ArrayList<>();
            IMISearchResults results = new IMISearchResults();
            results.setNaicCode("TEST_NAIC");
            results.setTransmitTimeStamp("2023-01-01 10:00:00");
            results.setDocumentStatusCd("S");
            results.setImiDocumentId(123);
            searchResults.add(results);
            searchData.setSearchResultsList(searchResults);

            // Create mock search request
            IMISearchRequest searchRequest = new IMISearchRequest();
            searchRequest.setTransmitFileIdDisplay(true);
            searchRequest.setDocumentStatusCdDisplay(true);

            Map<String, Object> result = imiActivityTrackingService.convertToTableFormat(searchData, AUTH_TOKEN, searchRequest);

            assertNotNull(result);
            assertTrue(result instanceof Map);
            
            List<Map<String, Object>> data = (List<Map<String, Object>>) result.get("data");
            assertNotNull(data);
            assertEquals(1, data.size());
            
            Map<String, Object> row = data.get(0);
            assertTrue(row.containsKey("action"));
        }
    }

    @Test
    void testBuildActiveKeysFromSearchRequest() throws Exception {
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("buildActiveKeysFromSearchRequest", IMISearchRequest.class);
        method.setAccessible(true);

        IMISearchRequest searchRequest = new IMISearchRequest();
            searchRequest.setTransmitFileIdDisplay(true);
            searchRequest.setTransmitFileNameDisplay(true);
            searchRequest.setDocumentStatusCdDisplay(true);
            searchRequest.setTransmitFileIdDisplay(true);

        Set<String> result = (Set<String>) method.invoke(imiActivityTrackingService, searchRequest);

        assertNotNull(result);
        assertTrue(result.contains(NAIC_CODE));
        assertTrue(result.contains("transmitTimestamp"));
        assertTrue(result.contains(DOCUMENT_STATUS_CD));
        assertTrue(result.contains("transmitFileId"));
    }

    @Test
    void testBuildActiveKeysFromSearchRequestWithNoDisplayFields() throws Exception {
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("buildActiveKeysFromSearchRequest", IMISearchRequest.class);
        method.setAccessible(true);

        IMISearchRequest searchRequest = new IMISearchRequest();
        searchRequest.setTransmitFileIdDisplay(true);
        searchRequest.setTransmitFileNameDisplay(true);
        searchRequest.setDocumentStatusCdDisplay(true);
        searchRequest.setTransmitFileIdDisplay(true);

        Set<String> result = (Set<String>) method.invoke(imiActivityTrackingService, searchRequest);

        assertNotNull(result);
        assertTrue(result.contains(NAIC_CODE));
        assertTrue(result.contains("transmitTimestamp"));
        // Should only contain core fields
        assertEquals(5, result.size());
    }

    @Test
    void testGenerateColumns() throws Exception {
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("generateColumns", Set.class);
        method.setAccessible(true);

        Set<String> activeKeys = new HashSet<>();
        activeKeys.add(NAIC_CODE);
        activeKeys.add("transmitTimeStamp");
        activeKeys.add(DOCUMENT_STATUS_CD);

        com.fasterxml.jackson.databind.node.ArrayNode result = (com.fasterxml.jackson.databind.node.ArrayNode) method.invoke(imiActivityTrackingService, activeKeys);

        assertNotNull(result);
        assertTrue(result.size() > 0);
        
        // Check that actions column is included
        boolean hasActionsColumn = false;
        for (int i = 0; i < result.size(); i++) {
            com.fasterxml.jackson.databind.node.ObjectNode column = (com.fasterxml.jackson.databind.node.ObjectNode) result.get(i);
            if ("action".equals(column.get("id").asText())) {
                hasActionsColumn = true;
                break;
            }
        }
        assertTrue(hasActionsColumn);
    }

    @Test
    void testConstructActions() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);

            java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("constructActions", IMISearchResults.class, boolean.class, Date.class);
            method.setAccessible(true);

            IMISearchResults searchResult = new IMISearchResults();
            searchResult.setDocumentStatusCd("S");
            searchResult.setImiDocumentId(123);

            com.fasterxml.jackson.databind.node.ArrayNode result = (com.fasterxml.jackson.databind.node.ArrayNode) method.invoke(imiActivityTrackingService, searchResult, false, null);

            assertNotNull(result);
            // Should have at least one action for document status "S"
            assertTrue(result.size() > 0);
        }
    }

    @Test
    void testConstructActionsWithPHIAccess() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);

            java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("constructActions", IMISearchResults.class, boolean.class, Date.class);
            method.setAccessible(true);

            IMISearchResults searchResult = new IMISearchResults();
            searchResult.setDocumentStatusCd("S");
            searchResult.setImiDocumentId(123);

            com.fasterxml.jackson.databind.node.ArrayNode result = (com.fasterxml.jackson.databind.node.ArrayNode) method.invoke(imiActivityTrackingService, searchResult, true, null);

            assertNotNull(result);
            // Should have actions for both PHI access and document status
            assertTrue(result.size() > 0);
        }
    }


    @Test
    void testFormatDateIfValid() throws Exception {
        // Test valid date format
        String result1 = IMIActivityTrackingService.formatDateIfValid(TEST_DATE_START);
        assertEquals("01/01/23", result1);

        // Test invalid date format
        String result2 = IMIActivityTrackingService.formatDateIfValid(INVALID_VALUE);
        assertEquals(INVALID_VALUE, result2);

        // Test null input
        String result3 = IMIActivityTrackingService.formatDateIfValid(null);
        assertNull(result3);

        // Test short input
        String result4 = IMIActivityTrackingService.formatDateIfValid("123");
        assertEquals("123", result4);
    }

    @Test
    void testTransformSegmentsToTableFormat() throws Exception {
        // Create mock T222ADSG entities
        List<T222ADSG> segments = new ArrayList<>();
        T222ADSG segment = new T222ADSG();
        segment.setSegmentName("TEST_SEGMENT");
        segment.setSegmentData("test data");
        segments.add(segment);

        Map<String, Object> result = imiActivityTrackingService.transformSegmentsToTableFormat(segments);

        assertNotNull(result);
        assertTrue(result.containsKey(DEFINITION));
        assertTrue(result.containsKey("data"));
        
        Map<String, Object> definition = (Map<String, Object>) result.get(DEFINITION);
        assertTrue(definition.containsKey("columns"));
        assertTrue(definition.containsKey("pagination"));
        
        List<Map<String, Object>> data = (List<Map<String, Object>>) result.get("data");
        assertNotNull(data);
        assertEquals(1, data.size());
    }

    @Test
    void testTransformSegmentsToTableFormatHeadersHumanized() throws Exception {
        // Create mock T222ADSG entities
        List<T222ADSG> segments = new ArrayList<>();
        T222ADSG segment = new T222ADSG();
        segment.setSegmentName("BOD");
        segment.setSegmentStatusCode("A");
        segment.setSegmentReasonCode("S000");
        segment.setSegmentData("TEST");
        segments.add(segment);

        Map<String, Object> result = imiActivityTrackingService.transformSegmentsToTableFormat(segments);

        assertNotNull(result);
        assertTrue(result.containsKey(DEFINITION));
        Map<String, Object> definition = (Map<String, Object>) result.get(DEFINITION);
        assertTrue(definition.containsKey("columns"));

        List<Map<String, Object>> columns = (List<Map<String, Object>>) definition.get("columns");
        assertNotNull(columns);
        // Verify that key segment columns are humanized with spaces
        assertColumnName(columns, "SEGMENTNAME", "Segment Name");
        assertColumnName(columns, "SEGMENTSTATUSCODE", "Segment Status Code");
        assertColumnName(columns, "SEGMENTREASONCODE", "Segment Reason Code");
        assertColumnName(columns, "SEGMENTDATA", "Segment Data");
    }

    // Helper to assert a column exists with id and expected humanized name
    private void assertColumnName(List<Map<String, Object>> columns, String id, String expectedName) {
        boolean found = false;
        for (Map<String, Object> col : columns) {
            Object colId = col.get("id");
            if (colId != null && id.equals(colId.toString())) {
                Object name = col.get("name");
                assertNotNull(name, "Column name should not be null for id: " + id);
                assertEquals(expectedName, name.toString());
                found = true;
                break;
            }
        }
        assertTrue(found, "Column with id '" + id + "' not found");
    }

    @Test
    void testTransformSegmentsToTableFormatWithNullSegments() throws Exception {
        Map<String, Object> result = imiActivityTrackingService.transformSegmentsToTableFormat(null);

        assertNotNull(result);
        assertTrue(result.containsKey(DEFINITION));
        assertTrue(result.containsKey("data"));
        
        List<Map<String, Object>> data = (List<Map<String, Object>>) result.get("data");
        assertNotNull(data);
        assertTrue(data.isEmpty());
    }

    @Test
    void testParseIntegerSafely() throws Exception {
        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("parseIntegerSafely", String.class);
        method.setAccessible(true);

        int result1 = (int) method.invoke(imiActivityTrackingService, "123");
        assertEquals(123, result1);

        int result2 = (int) method.invoke(imiActivityTrackingService, INVALID_VALUE);
        assertEquals(5, result2); // Should return default value

        int result3 = (int) method.invoke(imiActivityTrackingService, (String) null);
        assertEquals(5, result3); // Should return default value
    }

    @Test
    void testParseSearchDatesSafely() throws Exception {
        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("parseSearchDatesSafely", 
                com.hmhs.hvwmid.model.IMIUISearchRequest.class, com.hmhs.hvwmid.model.IMISearchRequest.class);
        method.setAccessible(true);

        IMIUISearchRequest uiRequest = new IMIUISearchRequest();
        uiRequest.setBegindate(TEST_DATE_START);
        uiRequest.setEnddate(TEST_DATE_END);
        uiRequest.setStartTimeHour("00");
        uiRequest.setStartTimeMin("00");
        uiRequest.setEndTimeHour("23");
        uiRequest.setEndTimeMin("59");

        IMISearchRequest searchRequest = new IMISearchRequest();

        boolean result1 = (boolean) method.invoke(imiActivityTrackingService, uiRequest, searchRequest);
        assertTrue(result1);

        uiRequest.setBegindate(INVALID_VALUE + "_date");
        boolean result2 = (boolean) method.invoke(imiActivityTrackingService, uiRequest, searchRequest);
        assertFalse(result2);
    }

    @Test
    void testGetSegmentDataByDocumentIdAndSegmentNames() throws Exception {
        // Create mock T222ADSG entities
        List<T222ADSG> mockSegments = new ArrayList<>();
        T222ADSG segment1 = new T222ADSG();
        segment1.setSegmentName("CFL");
        segment1.setSegmentData(TEST_PATH);
        mockSegments.add(segment1);
        
        T222ADSG segment2 = new T222ADSG();
        segment2.setSegmentName("CFF");
        segment2.setSegmentData(TEST_PARAM);
        mockSegments.add(segment2);

        when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(123, Arrays.asList("CFL", "CFF")))
                .thenReturn(mockSegments);

        Map<String, String> result = imiActivityTrackingService.getSegmentDataByDocumentIdAndSegmentNames(123, 
                Arrays.asList("CFL", "CFF"));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(TEST_PATH, result.get("CFL"));
        assertEquals(TEST_PARAM, result.get("CFF"));
    }

    @Test
    void testGetSegmentDataByDocumentIdAndSegmentNamesWithNoResults() throws Exception {
        when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(123, Arrays.asList("CFL", "CFF")))
                .thenReturn(new ArrayList<>());

        Map<String, String> result = imiActivityTrackingService.getSegmentDataByDocumentIdAndSegmentNames(123, 
                Arrays.asList("CFL", "CFF"));

        assertNull(result);
    }

    @Test
    void testGetSegmentDataByDocumentIdAndSegmentNamesWithNullResults() throws Exception {
        when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(123, Arrays.asList("CFL", "CFF")))
                .thenReturn(null);

        Map<String, String> result = imiActivityTrackingService.getSegmentDataByDocumentIdAndSegmentNames(123, 
                Arrays.asList("CFL", "CFF"));

        assertNull(result);
    }

    @Test
    void testCreateCMODActionWithDateThreshold() throws Exception {
        // Mock segment data
        List<T222ADSG> mockSegments = new ArrayList<>();
        T222ADSG segment1 = new T222ADSG();
        segment1.setSegmentName("CFL");
        segment1.setSegmentData(TEST_PATH);
        mockSegments.add(segment1);
        
        T222ADSG segment2 = new T222ADSG();
        segment2.setSegmentName("CFF");
        segment2.setSegmentData(TEST_PARAM);
        mockSegments.add(segment2);
        when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(123, Arrays.asList("CFL", "CFF")))
                .thenReturn(mockSegments);

        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod(CREATE_CMOD_ACTION, 
                com.hmhs.hvwmid.model.IMISearchResults.class, Date.class);
        method.setAccessible(true);

        // Create test date threshold
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        Date thresholdDate = sdf.parse(TEST_DATE_2023_01_01);

        // Test with transmit timestamp after threshold
        IMISearchResults searchResult = new IMISearchResults();
        searchResult.setImiDocumentId(123);
        searchResult.setTransmitTimeStamp(TEST_TIMESTAMP);

        com.fasterxml.jackson.databind.node.ObjectNode result = (com.fasterxml.jackson.databind.node.ObjectNode) 
                method.invoke(imiActivityTrackingService, searchResult, thresholdDate);

        assertNotNull(result);
        assertTrue(result.has(API_URL));
        assertTrue(result.has(ACTION_TYPE));
        assertEquals("CMOD Search", result.get(LABEL).asText());
    }

    @Test
    void testCreateCMODActionWithDateThresholdBefore() throws Exception {
        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod(CREATE_CMOD_ACTION, 
                com.hmhs.hvwmid.model.IMISearchResults.class, Date.class);
        method.setAccessible(true);

        // Create test date threshold (after the test timestamp)
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        Date thresholdDate = sdf.parse("2023-06-01");

        // Test with transmit timestamp before threshold
        IMISearchResults searchResult = new IMISearchResults();
        searchResult.setImiDocumentId(123);
        searchResult.setTransmitTimeStamp("2023-01-01 10:00:00.0");

        com.fasterxml.jackson.databind.node.ObjectNode result = (com.fasterxml.jackson.databind.node.ObjectNode) 
                method.invoke(imiActivityTrackingService, searchResult, thresholdDate);

        assertNotNull(result); // Should return empty ObjectNode when date threshold not met
        assertTrue(result.isEmpty()); // Should be empty when date threshold not met
    }


    @Test
    void testIsTransmitTimestampAfterCMODThreshold() throws Exception {
        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod(IS_TRANSMIT_TIMESTAMP_AFTER_CMOD_THRESHOLD, String.class, Date.class);
        method.setAccessible(true);

        // Create test date threshold
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD);
        Date thresholdDate = sdf.parse(TEST_DATE_2023_01_01);

        boolean result1 = (boolean) method.invoke(imiActivityTrackingService, TEST_TIMESTAMP, thresholdDate);
        assertTrue(result1);

        boolean result2 = (boolean) method.invoke(imiActivityTrackingService, "2022-06-01 10:00:00.0", thresholdDate);
        assertFalse(result2);

        boolean result3 = (boolean) method.invoke(imiActivityTrackingService, (String) null, thresholdDate);
        assertFalse(result3);

        boolean result4 = (boolean) method.invoke(imiActivityTrackingService, "", thresholdDate);
        assertFalse(result4);

        boolean result5 = (boolean) method.invoke(imiActivityTrackingService, TEST_TIMESTAMP, (Date) null);
        assertFalse(result5);
    }

    @Test
    void testParseTransmitTimestamp() throws Exception{
        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("parseTransmitTimestamp", String.class);
        method.setAccessible(true);

        Date result1 = (Date) method.invoke(imiActivityTrackingService, TEST_TIMESTAMP);
        assertNotNull(result1);

        Date result2 = (Date) method.invoke(imiActivityTrackingService, "2023-06-01 10:00:00");
        assertNotNull(result2);

        Date result3 = (Date) method.invoke(imiActivityTrackingService, (String) null);
        assertNull(result3);

        Date result4 = (Date) method.invoke(imiActivityTrackingService, "invalid-date");
        assertNull(result4);
    }

    @Test
    void testParseDateFromParameter() throws Exception {
        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("parseDateFromParameter", String.class);
        method.setAccessible(true);

        Date result1 = (Date) method.invoke(imiActivityTrackingService, "2023-06-01");
        assertNotNull(result1);

        Date result2 = (Date) method.invoke(imiActivityTrackingService, (String) null);
        assertNull(result2);

        Date result3 = (Date) method.invoke(imiActivityTrackingService, "");
        assertNull(result3);

        Date result4 = (Date) method.invoke(imiActivityTrackingService, "2023/06/01");
        assertNull(result4);

        Date result5 = (Date) method.invoke(imiActivityTrackingService, "2023-13-01");
        assertNull(result5);
    }

    @Test
    void testConstructDataRetrievesCMODThresholdOnce() throws Exception {
        // Mock parameter data with CMOD date threshold
        Map<String, String> mockParmData = new HashMap<>();
        mockParmData.put(CMOD_SEARCH_LINK_DATE, TEST_DATE_2023_01_01);
        when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

        // Set paginationRowCount to ensure all results are processed
        setField(imiActivityTrackingService, PAGINATION_ROW_COUNT, 250);

        // Mock search data with multiple results
        IMISearchData searchData = new IMISearchData();
        List<IMISearchResults> searchResults = new ArrayList<>();
        
        IMISearchResults result1 = new IMISearchResults();
        result1.setDocumentStatusCd("M");
        result1.setTransmitTimeStamp(TEST_TIMESTAMP);
        searchResults.add(result1);
        
        IMISearchResults result2 = new IMISearchResults();
        result2.setDocumentStatusCd("M");
        result2.setTransmitTimeStamp(TEST_TIMESTAMP);
        searchResults.add(result2);
        
        searchData.setSearchResultsList(searchResults);

        Set<String> activeKeys = new HashSet<>();
        activeKeys.add(DOCUMENT_STATUS_CD);
        activeKeys.add("transmitTimeStamp");

        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.hasPhiAccess(anyString(), anyString())).thenReturn(false);
            utils.when(() -> HVWUtils.hasText(anyString())).thenReturn(true);
            utils.when(() -> HVWUtils.convertDocumentStatusCd(anyString())).thenReturn(TEST_STATUS);

            // Call constructData
            com.fasterxml.jackson.databind.node.ArrayNode result = imiActivityTrackingService.constructData(activeKeys, searchData, AUTH_TOKEN);

            // Verify that ImageParmDataService was called only once
            verify(imageParmDataService, times(1)).getParmDataMap(anyString());
            
            // Verify result structure
            assertNotNull(result);
            assertEquals(2, result.size());
        }
    }


    @Test
    void testCMODActionWithNoThresholdConfigured() throws Exception {
        // Mock parameter data without CMOD date threshold
        Map<String, String> mockParmData = new HashMap<>();
        mockParmData.put("OTHER_PARAM", "some value");
        when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

        // Mock segment data
        List<T222ADSG> mockSegments = new ArrayList<>();
        T222ADSG segment1 = new T222ADSG();
        segment1.setSegmentName("CFL");
        segment1.setSegmentData(TEST_PATH);
        mockSegments.add(segment1);
        
        T222ADSG segment2 = new T222ADSG();
        segment2.setSegmentName("CFF");
        segment2.setSegmentData(TEST_PARAM);
        mockSegments.add(segment2);
        when(t222ADSGRepository.findByImiDocumentIdAndSegmentNameIn(123, Arrays.asList("CFL", "CFF")))
                .thenReturn(mockSegments);

        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod(CREATE_CMOD_ACTION, 
                com.hmhs.hvwmid.model.IMISearchResults.class, Date.class);
        method.setAccessible(true);

        // Test with any transmit timestamp (should work when no threshold configured)
        IMISearchResults searchResult = new IMISearchResults();
        searchResult.setImiDocumentId(123);
        searchResult.setTransmitTimeStamp("2020-01-01 10:00:00.0");

        // Pass null as cmodDateThreshold to simulate no threshold configured
        com.fasterxml.jackson.databind.node.ObjectNode result = (com.fasterxml.jackson.databind.node.ObjectNode) 
                method.invoke(imiActivityTrackingService, searchResult, (Date) null);

        assertNotNull(result); // Should return action when no threshold configured
        assertTrue(result.has(API_URL));
        assertTrue(result.has(ACTION_TYPE));
        assertEquals("CMOD Search", result.get(LABEL).asText());
    }

    @Test
    void testImageParmDataServiceIntegration() throws Exception {
        // Test that the service properly uses ImageParmDataService for parameter retrieval
        Map<String, String> mockParmData = new HashMap<>();
        mockParmData.put("TEST_KEY", "TEST_VALUE");
        when(imageParmDataService.getParmDataMap("TEST_PARAM_ID")).thenReturn(mockParmData);

        // This test verifies that the service is properly integrated with ImageParmDataService
        // The actual method calls are tested through the existing test cases
        // Note: This test doesn't call any methods that would trigger ImageParmDataService
        verify(imageParmDataService, never()).getParmDataMap(anyString());
    }

    @Test
    void testCachingBehaviorInImiRetrieve() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            Map<String, String> mockParmData = new HashMap<>();
            mockParmData.put(ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT, "50");
            when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, SEARCH, "0", "20");

            assertNotNull(result);
            // Verify that ImageParmDataService was called for parameter data
            verify(imageParmDataService, times(1)).getParmDataMap(anyString());
        }
    }

    @Test
    void testCachingBehaviorInGetCMODDateThreshold() throws Exception {
        // Test that getCMODDateThreshold uses the cached service
        Map<String, String> mockParmData = new HashMap<>();
        mockParmData.put(CMOD_SEARCH_LINK_DATE, TEST_DATE_2023_01_01);
        when(imageParmDataService.getParmDataMap(anyString())).thenReturn(mockParmData);

        // Use reflection to test the private method
        java.lang.reflect.Method method = IMIActivityTrackingService.class.getDeclaredMethod("getCMODDateThreshold");
        method.setAccessible(true);

        Date result = (Date) method.invoke(imiActivityTrackingService);

        assertNotNull(result);
        // Verify that ImageParmDataService was called
        verify(imageParmDataService, times(1)).getParmDataMap(anyString());
    }

    @Test
    void testImageParmDataServiceErrorHandling() throws Exception {
        // Test error handling when ImageParmDataService returns null
        when(imageParmDataService.getParmDataMap(anyString())).thenReturn(null);

        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOST);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            searchRequest.setBegindate(TEST_DATE_START);
            searchRequest.setEnddate(TEST_DATE_END);
            searchRequest.setStartTimeHour("00");
            searchRequest.setStartTimeMin("00");
            searchRequest.setEndTimeHour("23");
            searchRequest.setEndTimeMin("59");

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(new IMISearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), any(Class.class))).thenReturn(mockResponse);

            Object result = imiActivityTrackingService.imiRetrieve(MOCK_USER, searchRequest, AUTH_TOKEN, SEARCH, "0", "20");

            assertNotNull(result);
            // Should handle null response gracefully and use default values
        }
    }
}