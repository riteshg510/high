package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TblCodTokenTest {

    private TblCodToken tblCodToken;

    @BeforeEach
    void setUp() {
        tblCodToken = new TblCodToken();
    }

    @Test
    void testSetGetRequestId() {
        Integer id = 123;
        tblCodToken.setRequestId(id);
        assertEquals(id, tblCodToken.getRequestId());
    }

    @Test
    void testSetGetUserId() {
        String userId = "jsmith";
        tblCodToken.setUserId(userId);
        assertEquals(userId, tblCodToken.getUserId());
    }

    @Test
    void testSetGetTimeCreate() {
        LocalDateTime now = LocalDateTime.now();
        tblCodToken.setTimeCreate(now);
        assertEquals(now, tblCodToken.getTimeCreate());
    }

    @Test
    void testSetGetDocumentType() {
        String type = "PDF";
        tblCodToken.setDocumentType(type);
        assertEquals(type, tblCodToken.getDocumentType());
    }

    @Test
    void testSetGetDocumentPages() {
        int pages = 12;
        tblCodToken.setDocumentPages(pages);
        assertEquals(pages, tblCodToken.getDocumentPages());
    }

    @Test
    void testSetGetDocumentToken() {
        String token = "DOC-ABC-123";
        tblCodToken.setDocumentToken(token);
        assertEquals(token, tblCodToken.getDocumentToken());
    }

    @Test
    void testSetGetSecurityToken() {
        String security = "eyJhbGciOi..."; // mock JWT
        tblCodToken.setSecurityToken(security);
        assertEquals(security, tblCodToken.getSecurityToken());

        tblCodToken.setSecurityToken(null);
        assertNull(tblCodToken.getSecurityToken());
    }

    @Test
    void testEqualityAndHashCode() {
        TblCodToken a = new TblCodToken();
        TblCodToken b = new TblCodToken();
        TblCodToken c = new TblCodToken();

        a.setRequestId(1);
        b.setRequestId(1);
        c.setRequestId(2);

        assertEquals(a, b);
        assertNotEquals(a, c);
        assertEquals(a.hashCode(), b.hashCode());
    }
}
