package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class T222APRMIdTest {

    private T222APRMId id1;
    private T222APRMId id2;

    @BeforeEach
    void setUp() {
        id1 = new T222APRMId();
        id2 = new T222APRMId();
    }

    @Test
    void testSetAndGetParmId() {
        id1.setParmId("PARAM1");
        assertEquals("PARAM1", id1.getParmId());
    }

    @Test
    void testSetAndGetParmKey() {
        id1.setParmKey("KEY1");
        assertEquals("KEY1", id1.getParmKey());
    }

    @Test
    void testEqualsSameObject() {
        id1.setParmId("P1");
        id1.setParmKey("K1");
        assertEquals(id1, id1); // Should be true for same object
    }

    @Test
    void testEqualsEqualObjects() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        id2.setParmId("P1");
        id2.setParmKey("K1");

        assertEquals(id1, id2); // Should be true for same values
    }

    @Test
    void testEqualsDifferentParmId() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        id2.setParmId("P2");
        id2.setParmKey("K1");

        assertNotEquals(id1, id2); // parmId differs
    }

    @Test
    void testEqualsDifferentParmKey() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        id2.setParmId("P1");
        id2.setParmKey("K2");

        assertNotEquals(id1, id2); // parmKey differs
    }

    @Test
    void testEqualsNull() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        assertNotEquals(id1, null);
    }

    @Test
    void testEqualsDifferentClass() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        assertNotEquals(id1, "some string");
    }

    @Test
    void testHashCodeConsistency() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        id2.setParmId("P1");
        id2.setParmKey("K1");

        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testHashCodeDifference() {
        id1.setParmId("P1");
        id1.setParmKey("K1");

        id2.setParmId("P1");
        id2.setParmKey("K2");

        assertNotEquals(id1.hashCode(), id2.hashCode());
    }
}
