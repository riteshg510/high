package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.dto.PolicyWithHoldDTO;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.repository.T222ImgRmaPolicyRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PolicyServiceTest {

	// Test constants
	private static final String TEST_POLICY_ID = "POL123";
	private static final String TEST_POLICY_TYPE = "TYPE1";
	private static final String TEST_POLICY_DESCRIPTION = "Test Policy";
	private static final String TEST_PROGRAM_NAME = "TEST_PROG";
	private static final String TEST_USER = "testuser";
	private static final String TEST_BPD_ID = "bpdId";
	private static final String TEST_POLICY_EDIT_FLAG = "policyEditFlag";
	private static final String TEST_DATE = "2024-01-01";
	private static final String TEST_POLICY_CODE = "policyCode";
	private static final String TEST_RMPOLTYP = "RMPOLTYP";

	@Mock
	private T222ImgRmaPolicyRepository t222ImgRmaPolicyRepository;

	@Mock
	private PolicyHoldService policyHoldService;

	@Mock
	private T222APRMRepository t222aprmRepository;

	@Mock
	private EntityManager entityManager;

	@Mock
	private Query query;

	@InjectMocks
	private PolicyService policyService;

	private T222ImgRmaPolicy testPolicy;
	private Map<String, String> testPolicyFields;
	private List<T222APRM> testPolicyTypeRecords;

	@BeforeEach
	void setUp() {
		// Setup test policy entity
		testPolicy = new T222ImgRmaPolicy();
		testPolicy.setPolicyCode(12345);
		testPolicy.setBpdId(1001);
		testPolicy.setPolicyId(TEST_POLICY_ID);
		testPolicy.setPolicyIdType(TEST_POLICY_TYPE);
		testPolicy.setPolicyDescription(TEST_POLICY_DESCRIPTION);
		testPolicy.setPolicyDays(30);
		testPolicy.setPolicyEditFlag("Y");
		testPolicy.setPolicyEditPgmName(TEST_PROGRAM_NAME);
		testPolicy.setModUser(TEST_USER);
		testPolicy.setModDate(LocalDateTime.now());

		// Setup test policy fields map
		testPolicyFields = new HashMap<>();
		testPolicyFields.put(TEST_BPD_ID, "1001");
		testPolicyFields.put("policyId", TEST_POLICY_ID);
		testPolicyFields.put("policyIdType", TEST_POLICY_TYPE);
		testPolicyFields.put("policyDescription", TEST_POLICY_DESCRIPTION);
		testPolicyFields.put("policyDays", "30");
		testPolicyFields.put(TEST_POLICY_EDIT_FLAG, "Y");
		testPolicyFields.put("policyEditPgmName", TEST_PROGRAM_NAME);
		testPolicyFields.put("policyBaseDate", TEST_DATE);

		// Setup test policy type records
		testPolicyTypeRecords = Arrays.asList(createPolicyTypeRecord("t1", "Type 1"),
				createPolicyTypeRecord("t2", "Type 2"), createPolicyTypeRecord("t3", "Type 3"));
	}

	private T222APRM createPolicyTypeRecord(String key, String data) {
		T222APRM policyTypeRecord = new T222APRM();
		policyTypeRecord.setParmId(TEST_RMPOLTYP);
		policyTypeRecord.setParmKey(key);
		policyTypeRecord.setParmData(data);
		return policyTypeRecord;
	}

	@Test
	void testGetClientIdsReturnsListOfIntegers() {
		// Given
		List<Integer> expectedClientIds = Arrays.asList(1001, 1002, 1003);
		when(t222ImgRmaPolicyRepository.findDistinctBpdIds()).thenReturn(expectedClientIds);

		// When
		List<Integer> result = policyService.getClientIds();

		// Then
		assertNotNull(result);
		assertEquals(3, result.size());
		assertEquals(expectedClientIds, result);
		verify(t222ImgRmaPolicyRepository).findDistinctBpdIds();
	}

	@Test
	void testGetNoServiceClientIdsReturnsPickListItems() {
		// Given
		List<Integer> bpdIds = Arrays.asList(1001, 1002);
		when(t222ImgRmaPolicyRepository.findDistinctBpdIds()).thenReturn(bpdIds);

		// When
		List<PickListItems> result = policyService.getNoServiceClientIds();

		// Then
		assertNotNull(result);
		assertEquals(2, result.size());

		// Verify items exist (order may vary due to HashMap)
		Set<String> expectedKeys = Set.of("1001", "1002");
		Set<String> actualKeys = result.stream().map(PickListItems::getKey).collect(Collectors.toSet());
		assertEquals(expectedKeys, actualKeys);

		// Verify each item has correct properties
		for (PickListItems item : result) {
			assertEquals(item.getKey(), item.getDisplayName());
			assertEquals("", item.getParentKey());
			assertTrue(item.getId() >= 0 && item.getId() < 2);
		}
	}

	@Test
	void testListPoliciesReturnsPaginatedResults() {
		// Given
		Map<String, String> otherFields = new HashMap<>();
		otherFields.put(TEST_BPD_ID, "1001");
		otherFields.put("page", "0");
		otherFields.put("pageSize", "10");
		otherFields.put("sortColumn", TEST_POLICY_CODE);
		otherFields.put("sortDirection", "asc");

		Object[] mockRow = { "12345", TEST_POLICY_ID, TEST_POLICY_DESCRIPTION, TEST_POLICY_TYPE, 30, "Y",
				TEST_PROGRAM_NAME, TEST_DATE, TEST_USER, "2024-01-01 10:00:00", 1001, "HOLD1", "HOLD123",
				"Hold Description", "Y", "HOLD_PROG", TEST_USER, TEST_DATE, "2024-01-31" };
		List<Object[]> mockResults = new ArrayList<>();
		mockResults.add(mockRow);

		when(entityManager.createNativeQuery(anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(mockResults);
		when(query.getSingleResult()).thenReturn(1L);

		// When
		Page<PolicyWithHoldDTO> result = policyService.listPolicies(otherFields);

		// Then
		assertNotNull(result);
		assertEquals(1, result.getTotalElements());
		assertEquals(1, result.getContent().size());
		verify(entityManager, times(2)).createNativeQuery(anyString()); // Once for data, once for count
	}

	@Test
	void testCreatePolicySuccess() {
		// Given
		String loginUser = TEST_USER;
		when(t222ImgRmaPolicyRepository.save(any(T222ImgRmaPolicy.class))).thenReturn(testPolicy);

		// When
		T222ImgRmaPolicy result = policyService.createPolicy(testPolicyFields, loginUser);

		// Then
		assertNotNull(result);
		assertEquals(testPolicy.getPolicyCode(), result.getPolicyCode());
		assertEquals(testPolicy.getBpdId(), result.getBpdId());
		verify(t222ImgRmaPolicyRepository).save(any(T222ImgRmaPolicy.class));
	}

	@Test
	void testCreatePolicyWithHolds() {
		// Given
		String loginUser = TEST_USER;
		testPolicyFields.put("holds", "HOLD1,HOLD2");
		when(t222ImgRmaPolicyRepository.save(any(T222ImgRmaPolicy.class))).thenReturn(testPolicy);

		// When
		T222ImgRmaPolicy result = policyService.createPolicy(testPolicyFields, loginUser);

		// Then
		assertNotNull(result);
		verify(policyHoldService).create(eq(loginUser), eq("HOLD1,HOLD2"), any(T222ImgRmaPolicy.class));
	}

	@Test
	void testCreatePolicyMissingMandatoryFieldsThrowsException() {
		// Given
		Map<String, String> incompleteFields = new HashMap<>();
		incompleteFields.put(TEST_BPD_ID, "1001");
		// Missing other mandatory fields
		String loginUser = TEST_USER;

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.createPolicy(incompleteFields, loginUser));

		assertTrue(exception.getMessage().contains("Missing mandatory field"));
	}

	@Test
	void testUpdatePolicySuccess() {
		// Given
		String loginUser = TEST_USER;
		testPolicyFields.put(TEST_POLICY_CODE, "12345");
		when(t222ImgRmaPolicyRepository.findByPolicyCode(12345)).thenReturn(Optional.of(testPolicy));
		when(t222ImgRmaPolicyRepository.save(any(T222ImgRmaPolicy.class))).thenReturn(testPolicy);

		// When
		T222ImgRmaPolicy result = policyService.updatePolicy(testPolicyFields, loginUser);

		// Then
		assertNotNull(result);
		verify(t222ImgRmaPolicyRepository).findByPolicyCode(12345);
		verify(t222ImgRmaPolicyRepository).save(any(T222ImgRmaPolicy.class));
	}

	@Test
	void testUpdatePolicyPolicyNotFoundThrowsException() {
		// Given
		String loginUser = TEST_USER;
		testPolicyFields.put(TEST_POLICY_CODE, "99999");
		when(t222ImgRmaPolicyRepository.findByPolicyCode(99999)).thenReturn(Optional.empty());

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.updatePolicy(testPolicyFields, loginUser));

		assertTrue(exception.getMessage().contains("Policy with code 99999 not found"));
	}

	@Test
	void testUpdatePolicyMissingPolicyCodeThrowsException() {
		// Given
		String loginUser = TEST_USER;
		// Missing policyCode in fields

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.updatePolicy(testPolicyFields, loginUser));

		assertTrue(exception.getMessage().contains("Missing mandatory field: policy_code for update"));
	}

	@Test
	void testGetByPolicyCodeSuccess() {
		// Given
		Integer policyCode = 12345;
		when(t222ImgRmaPolicyRepository.findByPolicyCode(policyCode)).thenReturn(Optional.of(testPolicy));

		// When
		T222ImgRmaPolicy result = policyService.getByPolicyCode(policyCode);

		// Then
		assertNotNull(result);
		assertEquals(testPolicy.getPolicyCode(), result.getPolicyCode());
		verify(t222ImgRmaPolicyRepository).findByPolicyCode(policyCode);
	}

	@Test
	void testGetByPolicyCodeNotFoundThrowsException() {
		// Given
		Integer policyCode = 99999;
		when(t222ImgRmaPolicyRepository.findByPolicyCode(policyCode)).thenReturn(Optional.empty());

		// When & Then
		HVWException exception = assertThrows(HVWException.class, () -> policyService.getByPolicyCode(policyCode));

		assertTrue(exception.getMessage().contains("Policy with code 99999 not found"));
	}

	@Test
	void testDeleteSuccess() {
		// Given
		Integer policyCode = 12345;

		// When
		policyService.delete(policyCode);

		// Then
		verify(policyHoldService).deleteByPolicyCode(policyCode);
		verify(t222ImgRmaPolicyRepository).deleteByPolicyCode(policyCode);
	}

	@Test
    void testGetPolicyTypeKeysFromDatabase() {
        // Given
        when(t222aprmRepository.findByParmId(TEST_RMPOLTYP)).thenReturn(testPolicyTypeRecords);

        // When
        List<String> result = policyService.getPolicyTypeKeys();

        // Then
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(Arrays.asList("t1", "t2", "t3"), result);
        verify(t222aprmRepository).findByParmId(TEST_RMPOLTYP);
    }

	@Test
    void testGetPolicyTypeKeysEmptyDatabaseReturnsDefaults() {
        // Given
        when(t222aprmRepository.findByParmId(TEST_RMPOLTYP)).thenReturn(Collections.emptyList());

        // When
        List<String> result = policyService.getPolicyTypeKeys();

        // Then
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals(Arrays.asList("t1", "t2", "t3"), result);
    }

	@Test
	void testTransformMapToPickListItems() {
		// Given
		Map<String, String> sourceMap = new HashMap<>();
		sourceMap.put("key1", "value1");
		sourceMap.put("key2", "value2");

		// When
		List<PickListItems> result = policyService.transformMapToPickListItems(sourceMap);

		// Then
		assertNotNull(result);
		assertEquals(2, result.size());

		// Verify first item
		PickListItems firstItem = result.get(0);
		assertEquals("key1", firstItem.getKey());
		assertEquals("value1", firstItem.getDisplayName());
		assertEquals(0L, firstItem.getId());
		assertEquals("", firstItem.getParentKey());

		// Verify second item
		PickListItems secondItem = result.get(1);
		assertEquals("key2", secondItem.getKey());
		assertEquals("value2", secondItem.getDisplayName());
		assertEquals(1L, secondItem.getId());
		assertEquals("", secondItem.getParentKey());
	}

	@Test
	void testCreatePolicyInvalidPolicyDaysThrowsException() {
		// Given
		testPolicyFields.put("policyDays", "invalid");
		String loginUser = TEST_USER;

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.createPolicy(testPolicyFields, loginUser));

		assertTrue(exception.getMessage().contains("Invalid numeric value for policyDays"));
	}

	@Test
	void testCreatePolicyInvalidBpdIdThrowsException() {
		// Given
		testPolicyFields.put(TEST_BPD_ID, "invalid");
		String loginUser = TEST_USER;

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.createPolicy(testPolicyFields, loginUser));

		assertTrue(exception.getMessage().contains("Invalid numeric value for bpdId"));
	}

	@Test
	void testCreatePolicyInvalidEditFlagThrowsException() {
		// Given
		testPolicyFields.put(TEST_POLICY_EDIT_FLAG, "X"); // Invalid value
		String loginUser = TEST_USER;

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.createPolicy(testPolicyFields, loginUser));

		assertTrue(exception.getMessage().contains("Invalid value for policyEditFlag"));
	}

	@Test
	void testCreatePolicyEditFlagYWithoutProgramNameThrowsException() {
		// Given
		testPolicyFields.put(TEST_POLICY_EDIT_FLAG, "Y");
		testPolicyFields.remove("policyEditPgmName"); // Remove program name
		String loginUser = TEST_USER;

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.createPolicy(testPolicyFields, loginUser));

		// The validation happens in validateMandatoryFields first, so we check for that
		// error message
		assertTrue(exception.getMessage().contains("Missing mandatory field: policyEditPgmName"));
	}

	@Test
	void testCreatePolicyInvalidDateFormatThrowsException() {
		// Given
		testPolicyFields.put("policyBaseDate", "invalid-date");
		String loginUser = TEST_USER;

		// When & Then
		HVWException exception = assertThrows(HVWException.class,
				() -> policyService.createPolicy(testPolicyFields, loginUser));

		assertTrue(exception.getMessage().contains("Invalid date format for policyBaseDate"));
	}
}
