package com.hmhs.hvwmid.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.entity.TblUserReport;
import com.hmhs.hvwmid.repository.UserReportRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class UserReportServiceTest {

    @InjectMocks
    private UserReportService userReportService;

    @Mock
    private UserReportRepository userReportRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);  // Initialize mocks
    }

    @Test
    void saveUserReport() {
        // Arrange: Set up mock behavior for the repository's save method
        TblUserReport mockReport = new TblUserReport();
        mockReport.setUserId("user1");
        mockReport.setReportId("report123");
        mockReport.setUserReportId("report123_user1");

        when(userReportRepository.save(any(TblUserReport.class))).thenReturn(mockReport);

        // Act: Call the service method
        TblUserReport result = userReportService.saveUserReport("user1", "report123");

        // Assert: Verify that the save method was called and the result is correct
        verify(userReportRepository, times(1)).save(any(TblUserReport.class));
        assertNotNull(result);
        assertEquals("user1", result.getUserId());
        assertEquals("report123", result.getReportId());
        assertEquals("report123_user1", result.getUserReportId());
    }

    @Test
    void filterJsonByDb() throws JsonProcessingException {
        // Arrange: Prepare mock data and behavior
        String jsonInput = "[{\"actionFolderNameId\": \"report123\"}, {\"actionFolderNameId\": \"report456\"}]";
        String userId = "user1";
        when(userReportRepository.findReportsByUserId(userId)).thenReturn(Arrays.asList("report123", "report789"));

        // Act: Call the method with the mocked data
        String result = userReportService.filterJsonByDb(userId, jsonInput);

        // Assert: Check the result, expecting only the matching report (report123)
        ObjectMapper mapper = new ObjectMapper();
        JsonNode resultJson = mapper.readTree(result);
        assertEquals(1, resultJson.size());
        assertEquals("report123", resultJson.get(0).get("actionFolderNameId").asText());
    }

    @Test
    void filterJsonByDb_NoMatchingReports() {
        // Arrange: Prepare mock data with no matching reports
        String jsonInput = "[{\"actionFolderNameId\": \"report123\"}, {\"actionFolderNameId\": \"report456\"}]";
        String userId = "user1";
        when(userReportRepository.findReportsByUserId(userId)).thenReturn(Arrays.asList("report999"));

        // Act: Call the method with the mocked data
        String result = userReportService.filterJsonByDb(userId, jsonInput);

        // Assert: Expect an empty JSON array
        assertEquals("[]", result);
    }

    @Test
    void removeFromMyReport_Success() {
        // Arrange: Set up a mock report that exists
        TblUserReport mockReport = new TblUserReport();
        mockReport.setUserId("user1");
        mockReport.setReportId("report123");
        when(userReportRepository.findByUserIdAndReportId("user1", "report123")).thenReturn(Optional.of(mockReport));

        // Act: Call the service method to remove the report
        boolean result = userReportService.removeFromMyReport("user1", "report123");

        // Assert: Verify that the report was removed and the result is true
        verify(userReportRepository, times(1)).delete(mockReport);
        assertTrue(result);
    }

    @Test
    void removeFromMyReport_ReportNotFound() {
        // Arrange: Mock the repository to return an empty Optional (report not found)
        when(userReportRepository.findByUserIdAndReportId("user1", "report123")).thenReturn(Optional.empty());

        // Act: Call the service method
        boolean result = userReportService.removeFromMyReport("user1", "report123");

        // Assert: Verify that the report was not found and the result is false
        assertFalse(result);
        verify(userReportRepository, times(0)).delete(any(TblUserReport.class));
    }
}
