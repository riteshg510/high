package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

class TblSectionDetailsTest {

    private TblSectionDetails tblSectionDetails;

    @BeforeEach
    void setUp() {
        tblSectionDetails = new TblSectionDetails();
    }

    // Test for FieldId
    @Test
    void testSetGetFieldId() {
        tblSectionDetails.setFieldId("field123");
        assertEquals("FIELD123", tblSectionDetails.getFieldId());
    }

    // Test for ColumnNumber
    @Test
    void testSetGetColumnNumber() {
        BigDecimal columnNumber = new BigDecimal("123.45");
        tblSectionDetails.setColumnNumber(columnNumber);
        assertEquals(columnNumber, tblSectionDetails.getColumnNumber());
    }

    // Test for CreateTimestamp
    @Test
    void testSetGetCreateTimestamp() {
        LocalDateTime timestamp = LocalDateTime.now();
        tblSectionDetails.setCreateTimestamp(timestamp);
        assertEquals(timestamp, tblSectionDetails.getCreateTimestamp());
    }

    // Test for DefaultValue
    @Test
    void testSetGetDefaultValue() {
        tblSectionDetails.setDefaultValue("default");
        assertEquals("default", tblSectionDetails.getDefaultValue());
    }

    // Test for FieldName (with lowercase transformation)
    @Test
    void testSetGetFieldName() {
        tblSectionDetails.setFieldName("MyFieldName");
        assertEquals("myfieldname", tblSectionDetails.getFieldName());
    }

    // Test for FieldOrder
    @Test
    void testSetGetFieldOrder() {
        tblSectionDetails.setFieldOrder(10);
        assertEquals(10, tblSectionDetails.getFieldOrder());
    }

    // Test for FieldType
    @Test
    void testSetGetFieldType() {
        tblSectionDetails.setFieldType(2);
        assertEquals(2, tblSectionDetails.getFieldType());
    }

    // Test for HtmlContent
    @Test
    void testSetGetHtmlContent() {
        byte[] htmlContent = "HTML Content".getBytes();
        tblSectionDetails.setHtmlContent(htmlContent);
        assertArrayEquals(htmlContent, tblSectionDetails.getHtmlContent());
    }

    // Test for IsDependentOn
    @Test
    void testSetGetIsDependentOn() {
        tblSectionDetails.setIsDependentOn("Field1");
        assertEquals("Field1", tblSectionDetails.getIsDependentOn());
    }

    // Test for Label (with capitalization)
    @Test
    void testSetGetLabel() {
        tblSectionDetails.setLabel("my label");
        assertEquals("My Label", tblSectionDetails.getLabel());
    }

    // Test for Maximum
    @Test
    void testSetGetMaximum() {
        tblSectionDetails.setMaximum(100);
        assertEquals(100, tblSectionDetails.getMaximum());
    }

    // Test for Minimum
    @Test
    void testSetGetMinimum() {
        tblSectionDetails.setMinimum(1);
        assertEquals(1, tblSectionDetails.getMinimum());
    }

    // Test for MultiSelect
    @Test
    void testSetGetMultiSelect() {
        tblSectionDetails.setMultiSelect((short) 1);
        assertEquals((short) 1, tblSectionDetails.getMultiSelect());
    }

    // Test for Notes
    @Test
    void testSetGetNotes() {
        tblSectionDetails.setNotes("Some notes here");
        assertEquals("Some notes here", tblSectionDetails.getNotes());
    }

    // Test for PickListId (with uppercase transformation)
    @Test
    void testSetGetPickListId() {
        tblSectionDetails.setPickListId("pickList123");
        assertEquals("PICKLIST123", tblSectionDetails.getPickListId());
    }

    // Test for PickListOptions
    @Test
    void testSetGetPickListOptions() {
        tblSectionDetails.setPickListOptions("Option1, Option2");
        assertEquals("Option1, Option2", tblSectionDetails.getPickListOptions());
    }

    // Test for PickListOrder
    @Test
    void testSetGetPickListOrder() {
        tblSectionDetails.setPickListOrder(3);
        assertEquals(3, tblSectionDetails.getPickListOrder());
    }

    // Test for ReadOnly
    @Test
    void testSetGetReadOnly() {
        tblSectionDetails.setReadOnly((short) 0);
        assertEquals((short) 0, tblSectionDetails.getReadOnly());
    }

    // Test for Required
    @Test
    void testSetGetRequired() {
        tblSectionDetails.setRequired((short) 1);
        assertEquals((short) 1, tblSectionDetails.getRequired());
    }

    // Test for SectionId (with uppercase transformation)
    @Test
    void testSetGetSectionId() {
        tblSectionDetails.setSectionId("section123");
        assertEquals("SECTION123", tblSectionDetails.getSectionId());
    }

    // Test for ValidationMessage
    @Test
    void testSetGetValidationMessage() {
        tblSectionDetails.setValidationMessage("Invalid value");
        assertEquals("Invalid value", tblSectionDetails.getValidationMessage());
    }

    // Test for ValidationRules
    @Test
    void testSetGetValidationRules() {
        tblSectionDetails.setValidationRules("Rule1");
        assertEquals("Rule1", tblSectionDetails.getValidationRules());
    }

    // Test for Visible
    @Test
    void testSetGetVisible() {
        tblSectionDetails.setVisible((short) 1);
        assertEquals((short) 1, tblSectionDetails.getVisible());
    }

    // Test for Name
    @Test
    void testSetGetName() {
        tblSectionDetails.setName("name123");
        assertEquals("name123", tblSectionDetails.getName());
    }

    // Test for DisplayExp
    @Test
    void testSetGetDisplayExp() {
        tblSectionDetails.setDisplayExp("Display expression");
        assertEquals("Display expression", tblSectionDetails.getDisplayExp());
    }

    // Test for RequiredExp
    @Test
    void testSetGetRequiredExp() {
        tblSectionDetails.setRequiredExp("Required expression");
        assertEquals("Required expression", tblSectionDetails.getRequiredExp());
    }

    // Test for capitalize method (null input)
    @Test
    void testCapitalizeNull() {
        assertEquals("", TblSectionDetails.capitalize(null));
    }

    // Test for capitalize method (empty input)
    @Test
    void testCapitalizeEmpty() {
        assertEquals("", TblSectionDetails.capitalize(""));
    }

    // Test for capitalize method (single word)
    @Test
    void testCapitalizeSingleWord() {
        assertEquals("Hello", TblSectionDetails.capitalize("hello"));
    }

    // Test for capitalize method (multiple words)
    @Test
    void testCapitalizeMultipleWords() {
        assertEquals("Hello World", TblSectionDetails.capitalize("hello world"));
    }

    // Test for capitalize method (multiple spaces between words)
    @Test
    void testCapitalizeMultipleSpaces() {
        assertEquals("Hello World", TblSectionDetails.capitalize("hello     world"));
    }

}
