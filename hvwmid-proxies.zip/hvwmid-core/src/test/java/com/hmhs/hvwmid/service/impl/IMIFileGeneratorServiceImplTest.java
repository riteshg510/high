package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.model.FileStorageResult;
import com.hmhs.hvwmid.model.GenerateIMIRequest;
import com.hmhs.hvwmid.model.GenerateIMIResponse;
import com.hmhs.hvwmid.repository.ImageCachingRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.service.FileStorageService;
import com.hmhs.hvwmid.service.GenericUDFService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IMIFileGeneratorServiceImplTest {

    @Mock
    private T222APRMRepository aprmRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private FileStorageService fileStorageService;

    @Mock
    private ImageCachingRepository imageCachingRepository;

    @Mock
    private GenericUDFService seqGen;

    private IMIFileGeneratorServiceImpl service;

    @BeforeEach
    void setUp() {
        service = new IMIFileGeneratorServiceImpl(aprmRepository, jdbcTemplate, fileStorageService, imageCachingRepository);
        
        // Mock the sequence generator in the service
        try {
            var seqGenField = IMIFileGeneratorServiceImpl.class.getDeclaredField("seqGen");
            seqGenField.setAccessible(true);
            seqGenField.set(service, seqGen);
        } catch (Exception e) {
            // If we can't inject the mock, we'll handle it in individual tests
        }
    }

    // Helper method to create a valid request
    private GenerateIMIRequest createValidRequest() {
        GenerateIMIRequest request = new GenerateIMIRequest();
        request.setExcelId(123);
        
        // File mappings - Use actual filename from the Excel file
        List<GenerateIMIRequest.FileIdMapping> fileMappings = new ArrayList<>();
        GenerateIMIRequest.FileIdMapping mapping1 = new GenerateIMIRequest.FileIdMapping();
        mapping1.setFileId(124);
        mapping1.setExcelFileName("images\\ND UM Faxes- Test File.pdf");
        fileMappings.add(mapping1);
        
        request.setFileIdMappings(fileMappings);
        
        // Segment mappings
        List<GenerateIMIRequest.SegmentMapping> segmentMappings = new ArrayList<>();
        
        GenerateIMIRequest.SegmentMapping fidMapping = new GenerateIMIRequest.SegmentMapping();
        fidMapping.setSegmentName("FID");
        fidMapping.setType("U");
        fidMapping.setValue("");
        segmentMappings.add(fidMapping);
        
        GenerateIMIRequest.SegmentMapping dpkMapping = new GenerateIMIRequest.SegmentMapping();
        dpkMapping.setSegmentName("DPK");
        dpkMapping.setType("M");
        dpkMapping.setValue("FileName");
        segmentMappings.add(dpkMapping);
        
        GenerateIMIRequest.SegmentMapping imgMapping = new GenerateIMIRequest.SegmentMapping();
        imgMapping.setSegmentName("IMG");
        imgMapping.setType("M");
        imgMapping.setValue("FileName");
        segmentMappings.add(imgMapping);
        
        GenerateIMIRequest.SegmentMapping bodMapping = new GenerateIMIRequest.SegmentMapping();
        bodMapping.setSegmentName("BOD");
        bodMapping.setType("U");
        bodMapping.setValue("");
        segmentMappings.add(bodMapping);
        
        GenerateIMIRequest.SegmentMapping eodMapping = new GenerateIMIRequest.SegmentMapping();
        eodMapping.setSegmentName("EOD");
        eodMapping.setType("U");
        eodMapping.setValue("");
        segmentMappings.add(eodMapping);
        
        request.setMappings(segmentMappings);
        
        // Output config
        GenerateIMIRequest.OutputConfig outputConfig = new GenerateIMIRequest.OutputConfig();
        outputConfig.setDocumentsPerIMI(10);
        outputConfig.setFilePriority(10);
        request.setOutputConfig(outputConfig);
        
        return request;
    }

    // Helper method to load real Excel file from test resources


    private byte[] loadTestExcelFile() {
        String[][] data = {
                // header
                {"FileName","DPK","DTR","P01","P02","P03","P04","PGC","AUD"},
                // rows
                {"images\\ND UM Faxes- Test File.pdf","4UM","10132022","2023/03/29 11:06:14 AM","FAX","1122","01","22","2023/03/30"},
                {"images\\ND UM Faxes- Test File.pdf","4UM","10132022","2023/03/29 11:06:14 AM","FAX","1122","02","22","2023/03/30"}
        };

        try (org.apache.poi.ss.usermodel.Workbook wb = new org.apache.poi.xssf.usermodel.XSSFWorkbook();
             java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream()) {

            org.apache.poi.ss.usermodel.Sheet sheet = wb.createSheet("NDUM");
            for (int r = 0; r < data.length; r++) {
                org.apache.poi.ss.usermodel.Row row = sheet.createRow(r);
                for (int c = 0; c < data[r].length; c++) {
                    row.createCell(c).setCellValue(data[r][c]); // keep as strings; adjust types if your parser needs dates/numbers
                }
            }
            wb.write(baos);
            return baos.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Failed to build test Excel", e);
        }
    }



    @Test
    void testGenerateIMIFiles_ValidRequest_ShouldSucceed() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        String userId = "testuser";
        
        // Mock file storage service
        when(fileStorageService.validateAccess(123, userId)).thenReturn(true);
        when(fileStorageService.validateAccess(124, userId)).thenReturn(true);
        
        // Mock PARM repository for segments
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        // Mock Excel content streaming
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(123), any(ByteArrayOutputStream.class));
        
        // Mock image content streaming (lenient because it may not be called with specific ID)
        lenient().doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write("FAKE_PDF_CONTENT".getBytes());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(124), any(ByteArrayOutputStream.class));
        
        // Mock file storage for generated files
        FileStorageResult imiResult = new FileStorageResult();
        imiResult.setRequestId(200);
        imiResult.setFileName("test.imi");
        imiResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), eq("IMI")))
            .thenReturn(imiResult);
        
        FileStorageResult excelResult = new FileStorageResult();
        excelResult.setRequestId(201);
        excelResult.setFileName("results.xlsx");
        excelResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), eq("XLSX")))
            .thenReturn(excelResult);
        
        // Act
        GenerateIMIResponse response = service.generateIMIFiles(request, userId);
        
        // Assert
        assertNotNull(response);
        assertNotNull(response.getGeneratedFiles());
        assertFalse(response.getGeneratedFiles().isEmpty());
        
        assertEquals(201, response.getOutputExcelId());
        
        assertNotNull(response.getSummary());
        assertTrue(response.getSummary().getTotalRows() > 0);
        assertTrue(response.getSummary().getSuccessful() > 0);
        assertEquals(0, response.getSummary().getFailed());
        
        assertNotNull(response.getMessage());
        assertTrue(response.getMessage().contains("Successfully generated"));
        
        // Verify interactions
        verify(fileStorageService).validateAccess(123, userId);
        verify(aprmRepository).findByParmId("IMISEG");
        verify(imageCachingRepository, atLeastOnce()).streamSegmentsByRequestId(anyInt(), any(ByteArrayOutputStream.class));
        verify(fileStorageService, atLeastOnce()).storeFileContent(any(byte[].class), anyString(), eq(userId), anyString());
    }

    @Test
    void testGenerateIMIFiles_NullRequest_ShouldThrowException() {
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.generateIMIFiles(null, "testuser");
        });
    }

    @Test
    void testGenerateIMIFiles_NullExcelId_ShouldThrowException() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setExcelId(null);
        
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.generateIMIFiles(request, "testuser");
        });
    }

    @Test
    void testGenerateIMIFiles_EmptyFileIdMappings_ShouldThrowException() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setFileIdMappings(new ArrayList<>());
        
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.generateIMIFiles(request, "testuser");
        });
    }

    @Test
    void testGenerateIMIFiles_InvalidDocumentsPerIMI_ShouldThrowException() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setDocumentsPerIMI(0);
        
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.generateIMIFiles(request, "testuser");
        });
    }

    @Test
    void testGenerateIMIFiles_InvalidFilePriority_ShouldThrowException() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setFilePriority(101);
        
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.generateIMIFiles(request, "testuser");
        });
    }

    @Test
    void testGenerateIMIFiles_NoAccessToExcelFile_ShouldThrowSecurityException() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        String userId = "testuser";
        
        when(fileStorageService.validateAccess(123, userId)).thenReturn(false);
        
        // Act & Assert
        assertThrows(SecurityException.class, () -> {
            service.generateIMIFiles(request, userId);
        });
    }

    @Test
    void testGenerateIMIFiles_NoAccessToImageFile_ShouldThrowSecurityException() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        String userId = "testuser";
        
        // Mock file access - Excel allowed, image file denied
        when(fileStorageService.validateAccess(123, userId)).thenReturn(true);
        when(fileStorageService.validateAccess(124, userId)).thenReturn(false);
        
        // Mock PARM repository (needed to reach validation step)
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> {
            service.generateIMIFiles(request, userId);
        });
        assertTrue(exception.getMessage().contains("User does not have access to file"));
        assertTrue(exception.getCause() instanceof SecurityException);
    }

    @Test
    void testGenerateIMIFiles_EmptySegmentMap_ShouldThrowException() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        String userId = "testuser";
        
        when(fileStorageService.validateAccess(anyInt(), eq(userId))).thenReturn(true);
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(new ArrayList<>());
        
        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> {
            service.generateIMIFiles(request, userId);
        });
        assertTrue(exception.getMessage().contains("Unable to load segments from PARM table"));
    }

    @Test
    void testGenerateIMIFiles_WithDefaultOutputConfig_ShouldSucceed() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setOutputConfig(null); // Test with null config
        String userId = "testuser";
        
        // Mock dependencies similar to valid test
        when(fileStorageService.validateAccess(anyInt(), eq(userId))).thenReturn(true);
        
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(123), any(ByteArrayOutputStream.class));
        
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write("FAKE_CONTENT".getBytes());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(124), any(ByteArrayOutputStream.class));
        
        FileStorageResult mockResult = new FileStorageResult();
        mockResult.setRequestId(200);
        mockResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), anyString()))
            .thenReturn(mockResult);
        
        // Act
        GenerateIMIResponse response = service.generateIMIFiles(request, userId);
        
        // Assert
        assertNotNull(response);
        // Should use defaults: documentsPerIMI=25, filePriority=99
        assertNotNull(response.getGeneratedFiles());
    }

    @Test
    void testGenerateIMIFiles_MultipleDocumentsPerIMI_ShouldCreateMultipleFiles() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setDocumentsPerIMI(1); // Force each document into separate IMI
        String userId = "testuser";
        
        // Mock dependencies
        when(fileStorageService.validateAccess(anyInt(), eq(userId))).thenReturn(true);
        
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        // Mock Excel with multiple rows (use real Excel file)
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(123), any(ByteArrayOutputStream.class));
        
        // Mock image content for each file
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write("FAKE_CONTENT".getBytes());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(124), any(ByteArrayOutputStream.class));
        
        FileStorageResult mockResult = new FileStorageResult();
        mockResult.setRequestId(200);
        mockResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), anyString()))
            .thenReturn(mockResult);
        
        // Act
        GenerateIMIResponse response = service.generateIMIFiles(request, userId);
        
        // Assert
        assertNotNull(response);
        assertNotNull(response.getGeneratedFiles());
        // With documentsPerIMI=1, should create multiple IMI files
        assertTrue(response.getGeneratedFiles().size() > 1);
    }

    @Test
    void testGenerateIMIFiles_MissingImageFile_ShouldHandleGracefully() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        String userId = "testuser";
        
        // Mock access validation
        when(fileStorageService.validateAccess(anyInt(), eq(userId))).thenReturn(true);
        
        // Mock PARM data
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        // Mock Excel content
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(123), any(ByteArrayOutputStream.class));
        
        // Make streaming fail for the image file (file not found scenario)
        doThrow(new RuntimeException("File not found")).when(imageCachingRepository)
            .streamSegmentsByRequestId(eq(124), any(ByteArrayOutputStream.class));
        
        FileStorageResult mockResult = new FileStorageResult();
        mockResult.setRequestId(200);
        mockResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), anyString()))
            .thenReturn(mockResult);
        
        // Act
        GenerateIMIResponse response = service.generateIMIFiles(request, userId);
        
        // Assert
        assertNotNull(response);
        assertNotNull(response.getSummary());
        // Should have some failures due to missing image file
        assertTrue(response.getSummary().getFailed() > 0);
    }

    // Helper method to create T222APRM entity
    private T222APRM createParmEntity(String key, String data) {
        T222APRM entity = new T222APRM();
        entity.setParmKey(key);
        entity.setParmData(data);
        return entity;
    }

    @Test
    void testGenerateIMIFiles_ConstantSegmentMapping_ShouldUseConstantValue() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        
        // Modify IMG segment to use constant value
        request.getMappings().stream()
            .filter(mapping -> "IMG".equals(mapping.getSegmentName()))
            .findFirst()
            .ifPresent(mapping -> {
                mapping.setType("C");
                mapping.setValue("CONSTANT_IMG_VALUE");
            });
        
        String userId = "testuser";
        
        // Mock dependencies similar to valid test
        when(fileStorageService.validateAccess(anyInt(), eq(userId))).thenReturn(true);
        
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(123), any(ByteArrayOutputStream.class));
        
        // Lenient because constant segments don't load image files
        lenient().doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write("FAKE_CONTENT".getBytes());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(124), any(ByteArrayOutputStream.class));
        
        FileStorageResult mockResult = new FileStorageResult();
        mockResult.setRequestId(200);
        mockResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), anyString()))
            .thenReturn(mockResult);
        
        // Act
        GenerateIMIResponse response = service.generateIMIFiles(request, userId);
        
        // Assert
        assertNotNull(response);
        assertTrue(response.getSummary().getSuccessful() > 0);
        // The constant value should be used in the generated IMI file
    }

    @Test
    void testGenerateIMIFiles_MappedSegmentType_ShouldUseExcelColumnValue() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        String userId = "testuser";
        
        // Mock dependencies
        when(fileStorageService.validateAccess(anyInt(), eq(userId))).thenReturn(true);
        
        List<T222APRM> segmentParms = Arrays.asList(
            createParmEntity("FID", "File ID segment"),
            createParmEntity("DPK", "Document Processing Key"),
            createParmEntity("IMG", "Image segment"),
            createParmEntity("BOD", "Beginning of Document"),
            createParmEntity("EOD", "End of Document")
        );
        when(aprmRepository.findByParmId("IMISEG")).thenReturn(segmentParms);
        lenient().when(aprmRepository.findByParmId("IMIGENDT")).thenReturn(new ArrayList<>());
        
        // Mock Excel with specific column that DPK maps to (use real Excel file) - lenient because generic stub below covers this
        lenient().doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(123), any(ByteArrayOutputStream.class));
        
        doAnswer(invocation -> {
            ByteArrayOutputStream outputStream = invocation.getArgument(1);
            outputStream.write(loadTestExcelFile());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(124), any(ByteArrayOutputStream.class));
        
        FileStorageResult mockResult = new FileStorageResult();
        mockResult.setRequestId(200);
        mockResult.setTimeCreated(LocalDateTime.now());
        when(fileStorageService.storeFileContent(any(byte[].class), anyString(), eq(userId), anyString()))
            .thenReturn(mockResult);
        
        // Act
        GenerateIMIResponse response = service.generateIMIFiles(request, userId);
        
        // Assert
        assertNotNull(response);
        assertTrue(response.getSummary().getSuccessful() > 0);
    }
}