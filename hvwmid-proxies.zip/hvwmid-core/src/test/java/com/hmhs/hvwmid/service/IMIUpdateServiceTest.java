package com.hmhs.hvwmid.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hmhs.hvwmid.model.IMISearchData;
import com.hmhs.hvwmid.model.IMIUpdateData;
import com.hmhs.hvwmid.model.IMIUpdateRetrieveRequest;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IMIUpdateServiceTest {

    // Test constants
    private static final String AUTH_TOKEN = "valid.jwt.token";
    private static final String MOCK_USER = "testUser";
    private static final String DB2INST1 = "DB2INST1";
    private static final String SERVICE_ERROR = "Service error";
    private static final String UPDATE_GROUP = "IMI-ACTIVITYTRK-UPDATE-INT";
    
    
    // Field constants
    private static final String TABLE_FLAG = "updateFieldName";
    private static final String ID_FIELD = "updateFieldValue";
    private static final String TRANSMIT_FILE_STATUS_CD = "transmitFileStatusCd";
    private static final String PROCESS_FILE_STATUS_CD = "processFileStatusCd";
    private static final String DOCUMENT_STATUS_CD = "documentStatusCd";
    
    // Field type constants
    private static final String TF_FIELD = "TF";
    private static final String PF_FIELD = "PF";
    private static final String DT_FIELD = "DT";
    private static final String INVALID_FIELD = "INVALID";
    
    // Status constants
    private static final String PROCESSED_STATUS = "PROCESSED";
    private static final String COMPLETED_STATUS = "COMPLETED";
    private static final String ACTIVE_STATUS = "ACTIVE";
    private static final String PENDING_STATUS = "PENDING";
    private static final String PROCESSING_STATUS = "PROCESSING";
    
    // Test IDs
    private static final String TEST_ID_123 = "123";
    private static final String TEST_ID_456 = "456";
    private static final String TEST_ID_789 = "789";
    
    // URL constants
    private static final String RETRIEVE_BASE_URL = "http://test.com/retrieve";
    private static final String UPDATE_BASE_URL = "http://test.com/update";
    private static final String TEST_ENVIRONMENT = "test";
    private static final String TEST_HOSTNAME = "test-hostname";
    
    // Error message constants
    private static final String INVALID_TABLE_FLAG_MSG = "Invalid table flag";
    private static final String ID_REQUIRED_MSG = "ID is required";
    private static final String UPDATE_REQUEST_REQUIRED_MSG = "Update request is required";

    @Mock
    private RestClientUtil restClientUtil;

    private IMIUpdateService imiUpdateService;

    @BeforeEach
    void setup() {
        imiUpdateService = new IMIUpdateService(restClientUtil);
        setField(imiUpdateService, "imiRetrieveBaseURL", RETRIEVE_BASE_URL);
        setField(imiUpdateService, "imiUpdateBaseURL", UPDATE_BASE_URL);
        setField(imiUpdateService, "environment", TEST_ENVIRONMENT);
    }

    private void setField(Object target, String fieldName, Object value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
            // Suppress accessibility warning for test purposes
            @SuppressWarnings("java:S3011")
            java.lang.reflect.Field accessibleField = field;
            accessibleField.setAccessible(true);
            accessibleField.set(target, value);
        } catch (Exception e) {
            throw new TestConfigurationException("Failed to set field: " + fieldName, e);
        }
    }
    
    // Custom exception for test configuration errors
    private static class TestConfigurationException extends RuntimeException {
        public TestConfigurationException(String message, Throwable cause) {
            super(message, cause);
        }
    }
    
    // Helper methods to create mock data objects
    private IMISearchData createMockSearchData() {
        IMISearchData searchData = new IMISearchData();
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(0);
        serviceMessage.setReturnCodeDescription("Success");
        searchData.setServiceMessage(serviceMessage);
        searchData.setSearchResultsList(new ArrayList<>());
        return searchData;
    }
    
    private IMIUpdateData createMockUpdateData() {
        IMIUpdateData updateData = new IMIUpdateData();
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("0");
        baseMessage.setReturnCodeDescription("Success");
        updateData.setBaseMessage(baseMessage);
        return updateData;
    }

    @Test
    void testImionLoadUpdateWithAccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN))
                    .thenReturn(Arrays.asList(UPDATE_GROUP, "OTHER_GROUP"));

            boolean result = imiUpdateService.imionLoadUpdate(AUTH_TOKEN);

            assertTrue(result);
        }
    }

    @Test
    void testImionLoadUpdateWithoutAccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN))
                    .thenReturn(Arrays.asList("OTHER_GROUP", "ANOTHER_GROUP"));

            boolean result = imiUpdateService.imionLoadUpdate(AUTH_TOKEN);

            assertFalse(result);
        }
    }

    @Test
    void testImionLoadUpdateNoLDAPGroups() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(null);

            boolean result = imiUpdateService.imionLoadUpdate(AUTH_TOKEN);

            assertFalse(result);
        }
    }

    @Test
    void testImionLoadUpdateEmptyLDAPGroups() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN)).thenReturn(new ArrayList<>());

            boolean result = imiUpdateService.imionLoadUpdate(AUTH_TOKEN);

            assertFalse(result);
        }
    }

    @Test
    void testImionLoadUpdateException() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(AUTH_TOKEN))
                    .thenThrow(new RuntimeException("JWT error"));

            // The service method doesn't handle JWT exceptions, so it should throw the exception
            assertThrows(RuntimeException.class, () -> 
                imiUpdateService.imionLoadUpdate(AUTH_TOKEN));
        }
    }

    @Test
    void testImiUpdateRetrieveSuccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(createMockSearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMISearchData.class))).thenReturn(mockResponse);

            IMISearchData result = imiUpdateService.imiUpdateRetrieve(MOCK_USER, AUTH_TOKEN, TF_FIELD, TEST_ID_123);

            assertNotNull(result);
        }
    }

    @Test
    void testImiUpdateRetrieveWithPF() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(createMockSearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMISearchData.class))).thenReturn(mockResponse);

            IMISearchData result = imiUpdateService.imiUpdateRetrieve(MOCK_USER, AUTH_TOKEN, PF_FIELD, TEST_ID_456);

            assertNotNull(result);
        }
    }

    @Test
    void testImiUpdateRetrieveWithDT() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            ResponseEntity<IMISearchData> mockResponse = ResponseEntity.ok(createMockSearchData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMISearchData.class))).thenReturn(mockResponse);

            IMISearchData result = imiUpdateService.imiUpdateRetrieve(MOCK_USER, AUTH_TOKEN, DT_FIELD, TEST_ID_789);

            assertNotNull(result);
        }
    }

    @Test
    void testImiUpdateRetrieveInvalidField() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            IMISearchData result = imiUpdateService.imiUpdateRetrieve(MOCK_USER, AUTH_TOKEN, INVALID_FIELD, TEST_ID_123);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
            assertTrue(result.getBaseMessage().getReturnCodeDescription().contains("Invalid field type"));
        }
    }

    @Test
    void testImiUpdateRetrieveException() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMISearchData.class)))
                    .thenThrow(new RuntimeException(SERVICE_ERROR));

            IMISearchData result = imiUpdateService.imiUpdateRetrieve(MOCK_USER, AUTH_TOKEN, TF_FIELD, TEST_ID_123);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
            assertTrue(result.getBaseMessage().getReturnCodeDescription().contains(SERVICE_ERROR));
        }
    }

    @Test
    void testImiUpdateSuccess() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, TF_FIELD);
            inputRequest.put(ID_FIELD, TEST_ID_123);
            inputRequest.put(TRANSMIT_FILE_STATUS_CD, PROCESSED_STATUS);

            ResponseEntity<IMIUpdateData> mockResponse = ResponseEntity.ok(createMockUpdateData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMIUpdateData.class))).thenReturn(mockResponse);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
        }
    }

    @Test
    void testImiUpdateWithProcessFileStatusCd() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, PF_FIELD);
            inputRequest.put(ID_FIELD, TEST_ID_456);
            inputRequest.put(PROCESS_FILE_STATUS_CD, COMPLETED_STATUS);

            ResponseEntity<IMIUpdateData> mockResponse = ResponseEntity.ok(createMockUpdateData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMIUpdateData.class))).thenReturn(mockResponse);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
        }
    }

    @Test
    void testImiUpdateWithDocumentStatusCd() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, DT_FIELD);
            inputRequest.put(ID_FIELD, TEST_ID_789);
            inputRequest.put(DOCUMENT_STATUS_CD, ACTIVE_STATUS);

            ResponseEntity<IMIUpdateData> mockResponse = ResponseEntity.ok(createMockUpdateData());
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMIUpdateData.class))).thenReturn(mockResponse);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
        }
    }


    @Test
    void testImiUpdateException() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));
            when(restClientUtil.postIMIRequest(anyString(), anyString(), any(), eq(IMIUpdateData.class)))
            .thenThrow(new RuntimeException(SERVICE_ERROR));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, TF_FIELD);
            inputRequest.put(ID_FIELD, TEST_ID_123);
            inputRequest.put(TRANSMIT_FILE_STATUS_CD, PROCESSED_STATUS);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
            assertTrue(result.getBaseMessage().getReturnCodeDescription().contains(SERVICE_ERROR));
        }
    }

    @Test
    void testConvertToTableFormatSuccess() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put("name", "Test1");
        searchResults.add(result1);

        Map<String, Object> result2 = new HashMap<>();
        result2.put("id", 2);
        result2.put("name", "Test2");
        searchResults.add(result2);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(TF_FIELD);

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
        @SuppressWarnings("unchecked")
        Map<String, Object> resultMap = (Map<String, Object>) result;
        assertTrue(resultMap.containsKey("definition"));
        assertTrue(resultMap.containsKey("data"));
    }


    @Test
    void testConvertToTableFormatEmptyResults() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
        @SuppressWarnings("unchecked")
        Map<String, Object> resultMap = (Map<String, Object>) result;
        assertTrue(resultMap.containsKey("definition"));
        assertTrue(resultMap.containsKey("data"));
    }

    @Test
    void testConvertToTableFormatNullResults() {
        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();

        // The service method doesn't handle null backendResponseList, so it should throw NPE
        assertThrows(NullPointerException.class, () -> 
            imiUpdateService.convertToTableFormat(null, retrieveRequest));
    }

    @Test
    void testConvertToTableFormatWithTF() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put(TRANSMIT_FILE_STATUS_CD, PENDING_STATUS);
        searchResults.add(result1);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(TF_FIELD);

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
    }

    @Test
    void testConvertToTableFormatWithPF() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put(PROCESS_FILE_STATUS_CD, PROCESSING_STATUS);
        searchResults.add(result1);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(PF_FIELD);

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
    }

    @Test
    void testConvertToTableFormatWithDT() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put(DOCUMENT_STATUS_CD, ACTIVE_STATUS);
        searchResults.add(result1);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(DT_FIELD);

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
    }

    // Additional comprehensive test cases for better coverage

    @Test
    void testImionLoadUpdateWithNullToken() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(null))
                    .thenThrow(new IllegalArgumentException("Token cannot be null"));

            // The service method doesn't handle JWT exceptions, so it should throw the exception
            assertThrows(IllegalArgumentException.class, () -> 
                imiUpdateService.imionLoadUpdate(null));
        }
    }

    @Test
    void testImionLoadUpdateWithEmptyToken() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserGroups(""))
                    .thenReturn(new ArrayList<>());

            boolean result = imiUpdateService.imionLoadUpdate("");

            assertFalse(result);
        }
    }

    @Test
    void testImiUpdateRetrieveWithNullParameters() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);

            IMISearchData result = imiUpdateService.imiUpdateRetrieve(null, null, null, null);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
        }
    }

    @Test
    void testImiUpdateRetrieveWithEmptyParameters() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);

            IMISearchData result = imiUpdateService.imiUpdateRetrieve("", "", "", "");

            assertNotNull(result);
        }
    }

    @Test
    void testImiUpdateWithNullRequest() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            // The service method doesn't handle null inputRequest, so it should throw NPE
            assertThrows(NullPointerException.class, () -> 
                imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, null));
        }
    }

    @Test
    void testImiUpdateWithNullTableFlag() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, null);
            inputRequest.put(ID_FIELD, TEST_ID_123);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
            assertTrue(result.getBaseMessage().getReturnCodeDescription().contains("Table flag parameter is required but not provided"));
        }
    }

    @Test
    void testImiUpdateWithEmptyTableFlag() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, "");
            inputRequest.put(ID_FIELD, TEST_ID_123);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
            assertTrue(result.getBaseMessage().getReturnCodeDescription().contains("Table flag parameter is required but not provided"));
        }
    }

    @Test
    void testImiUpdateWithNullId() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getCollection(TEST_ENVIRONMENT)).thenReturn(DB2INST1);
            // Mock hostname to prevent NullPointerException
            utils.when(() -> HVWUtils.getHostname()).thenReturn(TEST_HOSTNAME);
            // Mock LDAP groups for access control
            utils.when(() -> HVWUtils.getUserGroups(anyString())).thenReturn(Arrays.asList(UPDATE_GROUP));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put(TABLE_FLAG, TF_FIELD);
            inputRequest.put(ID_FIELD, null);
            inputRequest.put(TRANSMIT_FILE_STATUS_CD, PROCESSED_STATUS);

            IMIUpdateData result = imiUpdateService.imiUpdate(MOCK_USER, AUTH_TOKEN, inputRequest);

            assertNotNull(result);
            assertNotNull(result.getBaseMessage());
            assertTrue(result.getBaseMessage().getReturnCodeDescription().contains("ID parameter is required but not provided"));
        }
    }

    @Test
    void testConvertToTableFormatWithNullRequest() {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put("name", "Test");
        searchResults.add(result1);
        
        // Verify the test data is properly set up
        assertEquals(1, searchResults.size());
        assertEquals(1, result1.get("id"));

        // The service method doesn't handle null retrieveRequest, so it should throw NPE
        assertThrows(NullPointerException.class, () -> 
            imiUpdateService.convertToTableFormat(searchResults, null));
    }

    @Test
    void testConvertToTableFormatWithEmptyField() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        searchResults.add(result1);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField("");

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
    }

    @Test
    void testConvertToTableFormatWithNullField() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        searchResults.add(result1);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(null);

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
    }

    @Test
    void testConvertToTableFormatWithComplexData() throws JsonProcessingException {
        List<Map<String, Object>> searchResults = new ArrayList<>();
        
        // Test with multiple records and various field types
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put("name", "Test Document 1");
        result1.put(TRANSMIT_FILE_STATUS_CD, PENDING_STATUS);
        result1.put("createdDate", "2024-01-01");
        result1.put("isActive", true);
        searchResults.add(result1);

        Map<String, Object> result2 = new HashMap<>();
        result2.put("id", 2);
        result2.put("name", "Test Document 2");
        result2.put(TRANSMIT_FILE_STATUS_CD, PROCESSED_STATUS);
        result2.put("createdDate", "2024-01-02");
        result2.put("isActive", false);
        searchResults.add(result2);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(TF_FIELD);

        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);

        assertNotNull(result);
        assertTrue(result instanceof Map);
        @SuppressWarnings("unchecked")
        Map<String, Object> resultMap = (Map<String, Object>) result;
        assertTrue(resultMap.containsKey("definition"));
        assertTrue(resultMap.containsKey("data"));
    }

    @Test
    void testConvertToTableFormatWithJsonProcessingException() throws JsonProcessingException {
        // This test verifies that JsonProcessingException is properly declared
        // The actual exception would be thrown by the ObjectMapper in the service
        // but we can't easily mock that without complex setup
        List<Map<String, Object>> searchResults = new ArrayList<>();
        Map<String, Object> result1 = new HashMap<>();
        result1.put("id", 1);
        result1.put("name", "Test");
        searchResults.add(result1);

        IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
        retrieveRequest.setField(TF_FIELD);

        // This should not throw JsonProcessingException in normal circumstances
        // but the method signature allows it to be thrown
        Object result = imiUpdateService.convertToTableFormat(searchResults, retrieveRequest);
        assertNotNull(result);
        assertTrue(result instanceof Map);
        @SuppressWarnings("unchecked")
        Map<String, Object> resultMap = (Map<String, Object>) result;
        assertTrue(resultMap.containsKey("definition"));
        assertTrue(resultMap.containsKey("data"));
    }
}