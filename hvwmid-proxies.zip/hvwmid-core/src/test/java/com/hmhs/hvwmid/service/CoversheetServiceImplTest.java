package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverAppl;
import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.entity.T117ImgCoverSheet;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetOverride;
import com.hmhs.hvwmid.exception.ResourceNotFoundException;
import com.hmhs.hvwmid.model.CoverSheetDTO;
import com.hmhs.hvwmid.model.CoverSheetDepartmentDTO;
import com.hmhs.hvwmid.model.CoversheetFileResult;
import com.hmhs.hvwmid.model.CoversheetMapper;
import com.hmhs.hvwmid.repository.T117ImgCoverApplRepository;
import com.hmhs.hvwmid.repository.T117ImgCoverObjectRepository;
import com.hmhs.hvwmid.repository.T117ImgCoverSheetOverrideRepository;
import com.hmhs.hvwmid.repository.T117ImgCoverSheetRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class CoversheetServiceImplTest {

    @Mock private T117ImgCoverSheetRepository coverSheetRepo;
    @Mock private T117ImgCoverSheetOverrideRepository overrideRepo;
    @Mock private T117ImgCoverApplRepository applRepo;
    @Mock private T117ImgCoverObjectRepository templateRepository;




    @InjectMocks private CoversheetServiceImpl service;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllCoverSheets() {
        T117ImgCoverSheet entity = new T117ImgCoverSheet();
        entity.setApplication(1);
        when(coverSheetRepo.findAll()).thenReturn(List.of(entity));

        List<CoverSheetDTO> results = service.getAllCoverSheets(false);
        assertEquals(1, results.size());
        assertEquals(1, results.get(0).getApplication());
    }

    @Test
    void testSaveCoverSheet() {
        CoverSheetDTO dto = new CoverSheetDTO();
        dto.setApplication(2);
        T117ImgCoverSheet entity = CoversheetMapper.toEntity(dto);

        when(coverSheetRepo.save(any())).thenReturn(entity);
        CoverSheetDTO saved = service.saveCoverSheet(dto);

        assertEquals(dto.getApplication(), saved.getApplication());
    }

    @Test
    void getAllCoverSheets() {
    }

    @Test
    void saveCoverSheet() {
    }

    @Test
    void deleteCoverSheet() {
    }

    @Test
    void getAllOverrides() {
    }

    @Test
    void updateOverride() {
    }

    @Test
    void deleteOverride() {
    }

    @Test
    void getAllApplications() {
    }

    @Test
    void saveApplication() {
    }

    @Test
    void deleteApplication() {
    }

    @Test
    void getCoverSheet_ShouldReturnCoversheetData_WhenValidInputsAndOverrideFalse() {
        T117ImgCoverSheet sheet = new T117ImgCoverSheet();
        sheet.setTemplate("TestTemplate");
        when(coverSheetRepo.findByApplicationAndName(1, "AppA"))
                .thenReturn(Optional.of(sheet));

        T117ImgCoverObject template = new T117ImgCoverObject();
        template.setObjName("TestTemplate");
        template.setMimeType("application/pdf");
        template.setObjData("Dummy PDF Data");
        when(templateRepository.findByNameIgnoreCase("TestTemplate"))
                .thenReturn(Optional.of(template));

        CoversheetFileResult result = service.getCoverSheet(1, 0, "AppA", false);

        assertEquals("application/pdf", result.getMimeType());
        assertEquals("TestTemplate.pdf", result.getFilename());
        assertArrayEquals("Dummy PDF Data".getBytes(StandardCharsets.UTF_8), result.getData());
    }

    @Test
    void getCoverSheet_ShouldReturnCoversheetData_WhenValidInputsAndOverrideTrue() {
        T117ImgCoverSheetOverride override = new T117ImgCoverSheetOverride();
        override.setTemplate("TestOverrideTemplate");
        when(overrideRepo.findByAppNameSequence(1, "AppA", 42))
                .thenReturn(Optional.of(override));

        T117ImgCoverObject template = new T117ImgCoverObject();
        template.setObjName("TestOverrideTemplate");
        template.setMimeType("application/pdf");
        template.setObjData("Override PDF Data");
        when(templateRepository.findByNameIgnoreCase("TestOverrideTemplate"))
                .thenReturn(Optional.of(template));

        CoversheetFileResult result = service.getCoverSheet(1, 42, "AppA", true);

        assertEquals("application/pdf", result.getMimeType());
        assertEquals("TestOverrideTemplate.pdf", result.getFilename());
        assertArrayEquals("Override PDF Data".getBytes(StandardCharsets.UTF_8), result.getData());
    }

    @Test
    void getCoverSheet_ShouldThrow_WhenTemplateNotFound() {
        T117ImgCoverSheet sheet = new T117ImgCoverSheet();
        sheet.setTemplate("MissingTemplate");
        when(coverSheetRepo.findByApplicationAndName(1, "AppA"))
                .thenReturn(Optional.of(sheet));

        when(templateRepository.findByNameIgnoreCase("MissingTemplate"))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.getCoverSheet(1, 0, "AppA", false));
    }

    @Test
    void getCoverSheet_ShouldThrow_WhenCoverSheetNotFound() {
        when(coverSheetRepo.findByApplicationAndName(1, "AppA"))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.getCoverSheet(1, 0, "AppA", false));
    }

    @Test
    void getCoverSheet_ShouldThrow_WhenOverrideNotFound() {
        when(overrideRepo.findByAppNameSequence(1, "AppA", 42))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> service.getCoverSheet(1, 42, "AppA", true));
    }

    @Test
    void getAllApplications_ShouldReturnDepartmentsGroupedByDeptId_WithProperFields() {
        T117ImgCoverDept dept1 = new T117ImgCoverDept();
        dept1.setDeptId(1);
        dept1.setDescription("Dept One");
        dept1.setMaintGroup("GroupA");
        dept1.setPrintGroup("PrintA");

        T117ImgCoverDept dept2 = new T117ImgCoverDept();
        dept2.setDeptId(2);
        dept2.setDescription("Dept Two");
        dept2.setMaintGroup("GroupB");
        dept2.setPrintGroup("PrintB");

        T117ImgCoverAppl appl1 = new T117ImgCoverAppl();
        appl1.setApplication(101);
        appl1.setDescription("App 101");
        appl1.setSequence(1);
        appl1.setDepartment(dept1);
        appl1.setActive("Y");
        appl1.setApplId("1001");

        T117ImgCoverAppl appl2 = new T117ImgCoverAppl();
        appl2.setApplication(102);
        appl2.setDescription("App 102");
        appl2.setSequence(2);
        appl2.setDepartment(dept1);
        appl2.setActive("Y");
        appl2.setApplId("1002");

        T117ImgCoverAppl appl3 = new T117ImgCoverAppl();
        appl3.setApplication(201);
        appl3.setDescription("App 201");
        appl3.setSequence(1);
        appl3.setDepartment(dept2);
        appl3.setActive("N");
        appl3.setApplId("2001");

        List<T117ImgCoverAppl> mockApplications = List.of(appl1, appl2, appl3);

        when(applRepo.findAllByPrintGroupIn(List.of("GroupA", "GroupB"))).thenReturn(mockApplications);

        List<CoverSheetDepartmentDTO> result = service.getAllApplications(true, List.of("GroupA", "GroupB"));

        assertEquals(2, result.size()); // Two departments

        CoverSheetDepartmentDTO deptDto1 = result.stream().filter(d -> d.getDeptId() == 1).findFirst().orElse(null);
        assertNotNull(deptDto1);
        assertEquals("Dept One", deptDto1.getDescription());
        assertTrue(deptDto1.getCanMaintain()); // Because "GroupA" is in groups
        assertEquals(2, deptDto1.getDepartments().size());
        assertTrue(deptDto1.getDepartments().stream().anyMatch(app -> app.getApplication() == 101));
        assertTrue(deptDto1.getDepartments().stream().anyMatch(app -> app.getApplication() == 102));

        CoverSheetDepartmentDTO deptDto2 = result.stream().filter(d -> d.getDeptId() == 2).findFirst().orElse(null);
        assertNotNull(deptDto2);
        assertEquals("Dept Two", deptDto2.getDescription());
        assertTrue(deptDto2.getCanMaintain());
        assertEquals(1, deptDto2.getDepartments().size());
        assertEquals(201, deptDto2.getDepartments().get(0).getApplication());
    }

    @Test
    void getAllApplications_ShouldReturnEmptyList_WhenNoApplications() {
        when(applRepo.findAllByPrintGroupIn(List.of("GroupA"))).thenReturn(List.of());

        List<CoverSheetDepartmentDTO> result = service.getAllApplications(true, List.of("GroupA"));
        assertTrue(result.isEmpty());
    }
}
