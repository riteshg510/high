package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(SpringExtension.class)
class ListViolationServiceTest {
    @InjectMocks
    private ListViolationService listViolationService;

    @Mock
    private RestClientUtil restClientUtil;

    private static final String BPDID_FIELD = "bpdid";

    @Test
    void testFilterReturnsExpectedResult() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> imageViolationListing = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> values = new ArrayList<>();

        Map<String, Object> value1 = new HashMap<>();
        value1.put("userId", "user123");
        value1.put("transactionID", "1001");
        value1.put("violationTime", "2025-08-22T09:45:00Z");
        value1.put("description", "Unauthorized access attempt");
        value1.put("application", "FinanceApp");
        value1.put("racfResource2", "RESOURCE2");
        value1.put("racfString2", "READ ONLY");

        Map<String, Object> value2 = new HashMap<>();
        value2.put("userId", "user456");
        value2.put("transactionID", "1002");
        value2.put("violationTime", "2025-08-22T09:50:00Z");
        value2.put("description", "Write attempt without permission");
        value2.put("application", "HRSystem");
        value2.put("racfResource2", "RESOURCE4");
        value2.put("racfString2", "NO ACCESS");

        values.add(value1);
        values.add(value2);

        results.put("row", values);
        imageViolationListing.put("results", results);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(imageViolationListing, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listViolationService.filter(otherFields, "token");

        List<Map> expected = new ArrayList<>();
        Map<String, String> expectedEntry = new HashMap<>();
        expectedEntry.put("tranId", "1001");
        expectedEntry.put("date", "2025-08-22T09:45:00Z");
        expectedEntry.put("application", "FinanceApp");
        expectedEntry.put("description", "Unauthorized access attempt");
        expectedEntry.put("acf2Resource", "RESOURCE2");
        expectedEntry.put("acf2String", "READ ONLY");
        expectedEntry.put("userId", "user123");
        expected.add(expectedEntry);
        expectedEntry = new HashMap<>();
        expectedEntry.put("tranId", "1002");
        expectedEntry.put("date", "2025-08-22T09:50:00Z");
        expectedEntry.put("application", "HRSystem");
        expectedEntry.put("description", "Write attempt without permission");
        expectedEntry.put("acf2Resource", "RESOURCE4");
        expectedEntry.put("acf2String", "NO ACCESS");
        expectedEntry.put("userId", "user456");
        expected.add(expectedEntry);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
    }

    @Test
    void testFilterWithEmptyResponse() {
        Map<String, String> otherFields = new HashMap<>();
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listViolationService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }

    @Test
    void testFilterDoesNotHaveAllProperties() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> responseMap = new HashMap<>();
        Map<String, Object> imageViolationListing = new HashMap<>();
        Map<String, Object> segmentData = new HashMap<>();
        Map<String, Object> results = new HashMap<>();

        segmentData.put("results", results);
        imageViolationListing.put("segmentData", segmentData);
        responseMap.put("imageViolationListing", imageViolationListing);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseMap, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        //no Applidcd
        ResponseEntity<Object> result = listViolationService.filter(otherFields, "token");

        List<Map> expected = new ArrayList<>();

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());


        //No Results
        results.clear();
        result = listViolationService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No Results
        segmentData.clear();
        result = listViolationService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No penaltybox
        imageViolationListing.clear();
        result = listViolationService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No nothing
        responseMap.clear();
        result = listViolationService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

    }

    @Test
    void testFilterGenerateDifferentExtraHeaders() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put(BPDID_FIELD, "   "); // blank value
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listViolationService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());

        otherFields.put(BPDID_FIELD, "abc"); // not blank value
        result = listViolationService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }
}