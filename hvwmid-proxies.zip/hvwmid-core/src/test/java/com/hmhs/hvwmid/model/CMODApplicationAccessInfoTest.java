package com.hmhs.hvwmid.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for CMODApplicationAccessInfo DTO.
 * Tests DTO serialization, validation, and constructor behavior.
 */
class CMODApplicationAccessInfoTest {

    @Test
    void testDefaultConstructor() {
        // Act
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo();

        // Assert
        assertNotNull(info);
        assertNull(info.getApplicationName());
        assertNull(info.getApplicationVersions());
        assertFalse(info.isUserAccess());
        assertFalse(info.isClientEmployeeSecurity());
        assertNull(info.getVpieApplication());
        assertNull(info.getVpieRoleDescription());
        assertNull(info.getAcf2String());
        assertNull(info.getModifiedDate());
    }

    @Test
    void testParameterizedConstructor() {
        // Arrange
        String applicationName = "TEST_APP";
        Set<String> versions = Set.of("TEST_APP-HMRK-V1", "TEST_APP-HMRK-V2");
        boolean userAccess = true;
        boolean clientEmployeeSecurity = false;

        // Act
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo(
            applicationName, versions, userAccess, clientEmployeeSecurity);

        // Assert
        assertNotNull(info);
        assertEquals(applicationName, info.getApplicationName());
        assertEquals(versions, info.getApplicationVersions());
        assertTrue(info.isUserAccess());
        assertFalse(info.isClientEmployeeSecurity());
        // Other fields should be null since they're not set by constructor
        assertNull(info.getVpieApplication());
        assertNull(info.getVpieRoleDescription());
        assertNull(info.getAcf2String());
        assertNull(info.getModifiedDate());
    }

    @Test
    void testSettersAndGetters() {
        // Arrange
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo();
        String applicationName = "MY_APPLICATION";
        Set<String> versions = Set.of("MY_APPLICATION-NDAK-V3");
        String vpieApplication = "VPIE_APP";
        String vpieRoleDescription = "Test Role Description";
        String acf2String = "ACF2_TEST_STRING";
        Date modifiedDate = new Date();

        // Act
        info.setApplicationName(applicationName);
        info.setApplicationVersions(versions);
        info.setUserAccess(true);
        info.setClientEmployeeSecurity(true);
        info.setVpieApplication(vpieApplication);
        info.setVpieRoleDescription(vpieRoleDescription);
        info.setAcf2String(acf2String);
        info.setModifiedDate(modifiedDate);

        // Assert
        assertEquals(applicationName, info.getApplicationName());
        assertEquals(versions, info.getApplicationVersions());
        assertTrue(info.isUserAccess());
        assertTrue(info.isClientEmployeeSecurity());
        assertEquals(vpieApplication, info.getVpieApplication());
        assertEquals(vpieRoleDescription, info.getVpieRoleDescription());
        assertEquals(acf2String, info.getAcf2String());
        assertEquals(modifiedDate, info.getModifiedDate());
    }

    @Test
    void testBooleanFields() {
        // Arrange
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo();

        // Test default false values
        assertFalse(info.isUserAccess());
        assertFalse(info.isClientEmployeeSecurity());

        // Test setting to true
        info.setUserAccess(true);
        info.setClientEmployeeSecurity(true);
        assertTrue(info.isUserAccess());
        assertTrue(info.isClientEmployeeSecurity());

        // Test setting back to false
        info.setUserAccess(false);
        info.setClientEmployeeSecurity(false);
        assertFalse(info.isUserAccess());
        assertFalse(info.isClientEmployeeSecurity());
    }

    @Test
    void testApplicationVersionsHandling() {
        // Arrange
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo();
        Set<String> emptyVersions = Set.of();
        Set<String> multipleVersions = Set.of("APP-CLNT-V1", "APP-CLNT-V2", "APP-CLNT-V3");

        // Test null versions
        info.setApplicationVersions(null);
        assertNull(info.getApplicationVersions());

        // Test empty versions
        info.setApplicationVersions(emptyVersions);
        assertEquals(emptyVersions, info.getApplicationVersions());
        assertTrue(info.getApplicationVersions().isEmpty());

        // Test multiple versions
        info.setApplicationVersions(multipleVersions);
        assertEquals(multipleVersions, info.getApplicationVersions());
        assertEquals(3, info.getApplicationVersions().size());
        assertTrue(info.getApplicationVersions().contains("APP-CLNT-V1"));
        assertTrue(info.getApplicationVersions().contains("APP-CLNT-V2"));
        assertTrue(info.getApplicationVersions().contains("APP-CLNT-V3"));
    }

    @Test
    void testNullStringFields() {
        // Arrange
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo();

        // Act - Set all string fields to null
        info.setApplicationName(null);
        info.setVpieApplication(null);
        info.setVpieRoleDescription(null);
        info.setAcf2String(null);

        // Assert - Should handle null values gracefully
        assertNull(info.getApplicationName());
        assertNull(info.getVpieApplication());
        assertNull(info.getVpieRoleDescription());
        assertNull(info.getAcf2String());
    }

    @Test
    void testDateFieldHandling() {
        // Arrange
        CMODApplicationAccessInfo info = new CMODApplicationAccessInfo();
        Date testDate = new Date(1234567890000L); // Fixed timestamp for testing

        // Act
        info.setModifiedDate(testDate);

        // Assert
        assertEquals(testDate, info.getModifiedDate());
        assertEquals(1234567890000L, info.getModifiedDate().getTime());

        // Test null date
        info.setModifiedDate(null);
        assertNull(info.getModifiedDate());
    }
}