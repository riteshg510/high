package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(SpringExtension.class)
class ListIdxValServiceTest {
    @InjectMocks
    private ListIdxValService listIdxValService;

    @Mock
    private RestClientUtil restClientUtil;

    private static final String BPDID_FIELD = "bpdid";

    @Test
    void testFilterReturnsExpectedResult() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> imageIndexValueListing = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> values = new ArrayList<>();

        Map<String, Object> value1 = new HashMap<>();
        value1.put("indexCount", 1);
        value1.put("indexValue", "A");

        Map<String, Object> value2 = new HashMap<>();
        value2.put("indexCount", 2);
        value2.put("indexValue", "B");

        values.add(value1);
        values.add(value2);

        results.put("values", values);
        imageIndexValueListing.put("results", results);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(imageIndexValueListing, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listIdxValService.filter(otherFields, "token");

        List<Map> expected = new ArrayList<>();
        Map<String, String> expectedEntry = new HashMap<>();
        expectedEntry.put("key", "1");
        expectedEntry.put("displayName", "A");
        expected.add(expectedEntry);
        expectedEntry = new HashMap<>();
        expectedEntry.put("key", "2");
        expectedEntry.put("displayName", "B");
        expected.add(expectedEntry);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
    }

    @Test
    void testFilterWithEmptyResponse() {
        Map<String, String> otherFields = new HashMap<>();
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listIdxValService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }

    @Test
    void testFilterDoesNotHaveAllProperties() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> responseMap = new HashMap<>();
        Map<String, Object> imageApplidListing = new HashMap<>();
        Map<String, Object> segmentData = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> applicationList = new ArrayList<>();

        Map<String, Object> appl1 = new HashMap<>();
        appl1.put("securityClass", "S1");
        applicationList.add(appl1);

        results.put("application", applicationList);
        segmentData.put("results", results);
        imageApplidListing.put("segmentData", segmentData);
        responseMap.put("imageApplidListing", imageApplidListing);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseMap, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        //no Applidcd
        ResponseEntity<Object> result = listIdxValService.filter(otherFields, "token");

        List<Map> expected = new ArrayList<>();

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

        //No SecurityClass
        applicationList.clear();
        appl1.clear();
        appl1.put("applidcd", "A1");
        applicationList.add(appl1);
        result = listIdxValService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

        //No Application
        results.clear();
        result = listIdxValService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No Results
        segmentData.clear();
        result = listIdxValService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No SegmentData
        imageApplidListing.clear();
        result = listIdxValService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No ImageApplidListing
        responseMap.clear();
        result = listIdxValService.filter(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

    }

    @Test
    void testFilterGenerateDifferentExtraHeaders() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put(BPDID_FIELD, "   "); // blank value
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listIdxValService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());

        otherFields.put(BPDID_FIELD, "abc"); // not blank value
        result = listIdxValService.filter(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }
}