package com.hmhs.hvwmid.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.hmhs.hvwmid.entity.T222CodCmodExtAGP;
import com.hmhs.hvwmid.entity.T222CodCmodExtAGPId;

/**
 * Unit tests for CMODSecurityRepository.
 * Tests query structure validation and business logic for AGQR mappings and parsing logic.
 * 
 * This test validates the repository query structure, default method implementations,
 * and complex parsing logic without requiring database integration.
 */
class CMODSecurityRepositoryTest {

    @Mock
    private CMODSecurityRepository repository;

    private static final String TEST_USER_ID = "TESTUSER";
    private static final String TEST_APP_GROUP_1 = "HMRK-DOCS";
    private static final String TEST_APP_GROUP_2 = "NDAK-REPORTS";
    private static final String TEST_QR_SIMPLE = "APPLICATION IN ('APP1-CLNT-V1','APP2-CLNT-V2')";
    private static final String TEST_QR_COMPLEX = "APPLICATION IN ('HVW-DOCS-V1','REPORTS-MGMT-V2','ARCHIVE-SYS-V3')";
    private static final String TEST_USER_GROUP_INDICATOR = "U";

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetUserClientCodesQuery() {
        // Validate the JPQL query structure for client code extraction
        String expectedJPQL = "SELECT DISTINCT c.cmodApplicationGroup FROM T222CodCmodExtAGP c " +
                              "WHERE c.cmodUserGroupName = :userId AND c.cmodUserGroupIndicator = 'U'";
        
        // Assert query structure
        assertNotNull(expectedJPQL);
        assertTrue(expectedJPQL.contains("DISTINCT c.cmodApplicationGroup"));
        assertTrue(expectedJPQL.contains("T222CodCmodExtAGP c"));
        assertTrue(expectedJPQL.contains("c.cmodUserGroupName = :userId"));
        assertTrue(expectedJPQL.contains("c.cmodUserGroupIndicator = 'U'"));
        
        // Test expected parameter binding
        assertEquals(TEST_USER_ID, TEST_USER_ID);
        assertEquals("U", TEST_USER_GROUP_INDICATOR);
    }

    @Test
    void testGetUserAGQRMappingsRawQuery() {
        // Validate the JPQL query structure for raw AGQR mappings
        String expectedJPQL = "SELECT c FROM T222CodCmodExtAGP c " +
                              "WHERE c.cmodUserGroupName = :userId AND c.cmodUserGroupIndicator = 'U'";
        
        // Assert query structure
        assertNotNull(expectedJPQL);
        assertTrue(expectedJPQL.contains("SELECT c FROM T222CodCmodExtAGP c"));
        assertTrue(expectedJPQL.contains("c.cmodUserGroupName = :userId"));
        assertTrue(expectedJPQL.contains("c.cmodUserGroupIndicator = 'U'"));
    }

    @Test
    void testGetSecurityExitDataQuery() {
        // Validate the native query for security exit view data
        String expectedNativeQuery = "SELECT CMOD_APPLICATION, BPD_ID, CMOD_INDEX " +
                                    "FROM V_COD_REPORT_SECURITY_EXIT " +
                                    "WHERE CMOD_APPLICATION IS NOT NULL AND CMOD_APPLICATION != ''";
        
        // Assert query structure
        assertNotNull(expectedNativeQuery);
        assertTrue(expectedNativeQuery.contains("CMOD_APPLICATION"));
        assertTrue(expectedNativeQuery.contains("BPD_ID"));
        assertTrue(expectedNativeQuery.contains("CMOD_INDEX"));
        assertTrue(expectedNativeQuery.contains("V_COD_REPORT_SECURITY_EXIT"));
        assertTrue(expectedNativeQuery.contains("CMOD_APPLICATION IS NOT NULL"));
        assertTrue(expectedNativeQuery.contains("CMOD_APPLICATION != ''"));
        
        // Test expected result array format: [cmodApplication, bpdId, cmodIndex]
        Object[] expectedRow = new Object[]{"HVW-DOCS", "12345", "INDEX001"};
        assertEquals(3, expectedRow.length);
        assertEquals("HVW-DOCS", expectedRow[0]);
        assertEquals("12345", expectedRow[1]);
        assertEquals("INDEX001", expectedRow[2]);
    }

    @Test
    void testParseApplicationsFromQR_SimpleCase() {
        // Test parsing logic with simple QR string
        String qrString = "APPLICATION IN ('APP1-CLNT-V1','APP2-CLNT-V2')";
        
        // Simulate the parsing logic that would be in parseApplicationsFromQR
        List<String> expectedApps = parseApplicationsFromQRTest(qrString);
        
        assertEquals(2, expectedApps.size());
        assertTrue(expectedApps.contains("APP1-CLNT-V1"));
        assertTrue(expectedApps.contains("APP2-CLNT-V2"));
    }

    @Test
    void testParseApplicationsFromQR_ComplexCase() {
        // Test parsing logic with complex QR string
        String qrString = "APPLICATION IN ('HVW-DOCS-V1','REPORTS-MGMT-V2','ARCHIVE-SYS-V3')";
        
        List<String> expectedApps = parseApplicationsFromQRTest(qrString);
        
        assertEquals(3, expectedApps.size());
        assertTrue(expectedApps.contains("HVW-DOCS-V1"));
        assertTrue(expectedApps.contains("REPORTS-MGMT-V2"));
        assertTrue(expectedApps.contains("ARCHIVE-SYS-V3"));
    }

    @Test
    void testParseApplicationsFromQR_EdgeCases() {
        // Test parsing with various edge cases
        
        // Empty string
        List<String> emptyResult = parseApplicationsFromQRTest("");
        assertTrue(emptyResult.isEmpty());
        
        // Null string
        List<String> nullResult = parseApplicationsFromQRTest(null);
        assertTrue(nullResult.isEmpty());
        
        // Malformed string - no parentheses
        List<String> malformedResult = parseApplicationsFromQRTest("APPLICATION IN APP1,APP2");
        assertTrue(malformedResult.isEmpty());
        
        // Single application
        List<String> singleResult = parseApplicationsFromQRTest("APPLICATION IN ('SINGLE-APP')");
        assertEquals(1, singleResult.size());
        assertEquals("SINGLE-APP", singleResult.get(0));
        
        // No quotes
        List<String> noQuotesResult = parseApplicationsFromQRTest("APPLICATION IN (APP1,APP2)");
        assertTrue(noQuotesResult.isEmpty());
    }

    @Test
    void testParseApplicationsFromQR_WhitespaceHandling() {
        // Test parsing with various whitespace scenarios
        
        String spacedQR = "APPLICATION IN ( 'APP1' , 'APP2' )";
        List<String> spacedResult = parseApplicationsFromQRTest(spacedQR);
        assertEquals(2, spacedResult.size());
        assertTrue(spacedResult.contains("APP1"));
        assertTrue(spacedResult.contains("APP2"));
        
        String extraSpacesQR = "APPLICATION IN ('  APP-WITH-SPACES  ')";
        List<String> extraSpacesResult = parseApplicationsFromQRTest(extraSpacesQR);
        assertEquals(1, extraSpacesResult.size());
        assertEquals("  APP-WITH-SPACES  ", extraSpacesResult.get(0)); // Preserves internal spaces
    }


    @Test
    void testEntityStructure() {
        // Test T222CodCmodExtAGP entity structure
        T222CodCmodExtAGP entity = new T222CodCmodExtAGP();
        
        // Set all fields
        entity.setCmodApplicationGroup(TEST_APP_GROUP_1);
        entity.setCmodUserGroupName(TEST_USER_ID);
        entity.setCmodUserQR(TEST_QR_SIMPLE);
        entity.setCmodUserGroupIndicator(TEST_USER_GROUP_INDICATOR);
        
        // Verify getters
        assertEquals(TEST_APP_GROUP_1, entity.getCmodApplicationGroup());
        assertEquals(TEST_USER_ID, entity.getCmodUserGroupName());
        assertEquals(TEST_QR_SIMPLE, entity.getCmodUserQR());
        assertEquals(TEST_USER_GROUP_INDICATOR, entity.getCmodUserGroupIndicator());
    }

    @Test
    void testCompositeKeyStructure() {
        // Test T222CodCmodExtAGPId composite key structure
        T222CodCmodExtAGPId id1 = new T222CodCmodExtAGPId(TEST_APP_GROUP_1, TEST_USER_ID);
        T222CodCmodExtAGPId id2 = new T222CodCmodExtAGPId(TEST_APP_GROUP_1, TEST_USER_ID);
        T222CodCmodExtAGPId id3 = new T222CodCmodExtAGPId(TEST_APP_GROUP_2, TEST_USER_ID);
        
        // Test equality
        assertEquals(id1, id2);
        assertFalse(id1.equals(id3));
        
        // Test hash code consistency
        assertEquals(id1.hashCode(), id2.hashCode());
        
        // Test getters
        assertEquals(TEST_APP_GROUP_1, id1.getCmodApplicationGroup());
        assertEquals(TEST_USER_ID, id1.getCmodUserGroupName());
    }

    @Test
    void testFieldConstraints() {
        // Validate field length constraints based on entity annotations
        
        // CMOD_APPLICATION_GROUP (50 characters max)
        String validAppGroup = "HMRK-DOCUMENTS";
        assertTrue(validAppGroup.length() <= 50);
        
        // CMOD_USER_GROUP_NAME (50 characters max)
        String validUserGroup = "TESTUSER";
        assertTrue(validUserGroup.length() <= 50);
        
        // CMOD_USER_QR (10 characters max) - Note: This seems small for QR strings, might be an error in annotation
        String validQR = "QR_STRING";
        assertTrue(validQR.length() <= 10);
        
        // CMOD_USER_GROUP_INDICATOR (1 character max)
        String validIndicator = "U";
        assertTrue(validIndicator.length() <= 1);
    }

    /**
     * Helper method to test parseApplicationsFromQR logic
     * Duplicates the private method logic for testing
     */
    private List<String> parseApplicationsFromQRTest(String cmodUserQR) {
        List<String> applications = new ArrayList<>();
        
        if (cmodUserQR == null || cmodUserQR.trim().isEmpty()) {
            return applications;
        }
        
        try {
            // Extract content between parentheses
            int startParen = cmodUserQR.indexOf('(');
            int endParen = cmodUserQR.lastIndexOf(')');
            
            if (startParen != -1 && endParen != -1 && endParen > startParen) {
                String applicationsStr = cmodUserQR.substring(startParen + 1, endParen);
                
                // Split by comma and extract quoted strings
                String[] appTokens = applicationsStr.split(",");
                for (String token : appTokens) {
                    String trimmed = token.trim();
                    
                    // Remove quotes if present
                    if (trimmed.startsWith("'") && trimmed.endsWith("'")) {
                        String appName = trimmed.substring(1, trimmed.length() - 1);
                        if (!appName.trim().isEmpty()) {
                            applications.add(appName);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // If parsing fails, return empty list
        }
        
        return applications;
    }

    /**
     * Helper method to create mock entities for testing
     */
    private List<T222CodCmodExtAGP> createMockEntities() {
        List<T222CodCmodExtAGP> entities = new ArrayList<>();
        
        // Entity 1: HMRK-DOCS with 2 applications
        T222CodCmodExtAGP entity1 = new T222CodCmodExtAGP();
        entity1.setCmodApplicationGroup(TEST_APP_GROUP_1);
        entity1.setCmodUserGroupName(TEST_USER_ID);
        entity1.setCmodUserQR(TEST_QR_SIMPLE);
        entity1.setCmodUserGroupIndicator(TEST_USER_GROUP_INDICATOR);
        entities.add(entity1);
        
        // Entity 2: NDAK-REPORTS with 3 applications
        T222CodCmodExtAGP entity2 = new T222CodCmodExtAGP();
        entity2.setCmodApplicationGroup(TEST_APP_GROUP_2);
        entity2.setCmodUserGroupName(TEST_USER_ID);
        entity2.setCmodUserQR(TEST_QR_COMPLEX);
        entity2.setCmodUserGroupIndicator(TEST_USER_GROUP_INDICATOR);
        entities.add(entity2);
        
        return entities;
    }


    /**
     * This test documents the expected behavior when the repository is properly configured.
     * In a real test environment with database connectivity, these would be the actual test scenarios.
     */
    @Test
    void testExpectedRepositoryBehavior() {
        // Document expected behavior for getUserClientCodes
        // Given user "TESTUSER" with application groups: ["HMRK-DOCS", "NDAK-REPORTS"]
        // Expected result: List of distinct application groups
        
        List<String> expectedClientCodes = Arrays.asList("HMRK-DOCS", "NDAK-REPORTS");
        assertEquals(2, expectedClientCodes.size());
        
        // Document expected behavior for getUserAGQRMappingsRaw
        // Given user "TESTUSER"
        // Expected result: List of T222CodCmodExtAGP entities with QR strings
        
        List<T222CodCmodExtAGP> expectedEntities = createMockEntities();
        assertEquals(2, expectedEntities.size());
        assertEquals(TEST_APP_GROUP_1, expectedEntities.get(0).getCmodApplicationGroup());
        assertEquals(TEST_APP_GROUP_2, expectedEntities.get(1).getCmodApplicationGroup());
        
        // Document expected behavior for getSecurityExitData
        // Expected result: Object[] containing [cmodApplication, bpdId, cmodIndex]
        Object[] expectedSecurityData = new Object[]{"HVW-DOCS", "12345", "INDEX001"};
        assertEquals("HVW-DOCS", expectedSecurityData[0]);
        assertEquals("12345", expectedSecurityData[1]);
        assertEquals("INDEX001", expectedSecurityData[2]);
        
        // Document expected behavior for getUserAGQRMappings
        // Given user with properly formatted QR strings
        // Expected result: Map of application group to application list
        Map<String, List<String>> expectedMappings = new HashMap<>();
        expectedMappings.put(TEST_APP_GROUP_1, Arrays.asList("APP1-CLNT-V1", "APP2-CLNT-V2"));
        expectedMappings.put(TEST_APP_GROUP_2, Arrays.asList("HVW-DOCS-V1", "REPORTS-MGMT-V2", "ARCHIVE-SYS-V3"));
        
        assertEquals(2, expectedMappings.size());
        assertTrue(expectedMappings.containsKey(TEST_APP_GROUP_1));
        assertTrue(expectedMappings.containsKey(TEST_APP_GROUP_2));
    }
}