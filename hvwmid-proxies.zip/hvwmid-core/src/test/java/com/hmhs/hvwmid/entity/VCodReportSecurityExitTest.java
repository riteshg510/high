package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class VCodReportSecurityExitTest {

    @Test
    void testSettersAndGetters_withValidValues_shouldReturnUppercase() {
        VCodReportSecurityExit entity = new VCodReportSecurityExit();

        LocalDateTime now = LocalDateTime.now();

        entity.setCdtype("report");
        entity.setSecExit("sec01");
        entity.setAcf2ResourceName("res1");
        entity.setSecType("read");
        entity.setModUser("admin");
        entity.setModTime(now);
        entity.setComments("some comment");
        entity.setSegmentKey("seg-key");
        entity.setCmodApplication("app1");
        entity.setCmodIndex("index1");
        entity.setBpdId("bpd001");

        assertEquals("REPORT", entity.getCdtype());
        assertEquals("SEC01", entity.getSecExit());
        assertEquals("RES1", entity.getAcf2ResourceName());
        assertEquals("READ", entity.getSecType());
        assertEquals("ADMIN", entity.getModUser());
        assertEquals(now, entity.getModTime());
        assertEquals("some comment", entity.getComments());
        assertEquals("SEG-KEY", entity.getSegmentKey());
        assertEquals("APP1", entity.getCmodApplication());
        assertEquals("INDEX1", entity.getCmodIndex());
        assertEquals("BPD001", entity.getBpdId());
    }

    @Test
    void testSettersAndGetters_withNullValues_shouldReturnNull() {
        VCodReportSecurityExit entity = new VCodReportSecurityExit();

        entity.setCdtype(null);
        entity.setSecExit(null);
        entity.setAcf2ResourceName(null);
        entity.setSecType(null);
        entity.setModUser(null);
        entity.setModTime(null);
        entity.setComments(null);
        entity.setSegmentKey(null);
        entity.setCmodApplication(null);
        entity.setCmodIndex(null);
        entity.setBpdId(null);

        assertNull(entity.getCdtype());
        assertNull(entity.getSecExit());
        assertNull(entity.getAcf2ResourceName());
        assertNull(entity.getSecType());
        assertNull(entity.getModUser());
        assertNull(entity.getModTime());
        assertNull(entity.getComments());
        assertNull(entity.getSegmentKey());
        assertNull(entity.getCmodApplication());
        assertNull(entity.getCmodIndex());
        assertNull(entity.getBpdId());
    }
}
