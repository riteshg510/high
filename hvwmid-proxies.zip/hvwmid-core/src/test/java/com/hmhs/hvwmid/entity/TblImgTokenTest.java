package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TblImgTokenTest {

    private TblImgToken tblImgToken;

    @BeforeEach
    void setUp() {
        tblImgToken = new TblImgToken();
    }

    @Test
    void testSetGetRequestId() {
        Integer id = 500;
        tblImgToken.setRequestId(id);
        assertEquals(id, tblImgToken.getRequestId());
    }

    @Test
    void testSetGetUserId() {
        String userId = "userX";
        tblImgToken.setUserId(userId);
        assertEquals(userId, tblImgToken.getUserId());
    }

    @Test
    void testSetGetTimeCreate() {
        LocalDateTime now = LocalDateTime.now();
        tblImgToken.setTimeCreate(now);
        assertEquals(now, tblImgToken.getTimeCreate());
    }

    @Test
    void testSetGetDocumentType() {
        String type = "JPG";
        tblImgToken.setDocumentType(type);
        assertEquals(type, tblImgToken.getDocumentType());
    }

    @Test
    void testSetGetDocumentPages() {
        int pages = 1;
        tblImgToken.setDocumentPages(pages);
        assertEquals(pages, tblImgToken.getDocumentPages());
    }

    @Test
    void testSetGetDocumentToken() {
        String token = "IMG-123-456";
        tblImgToken.setDocumentToken(token);
        assertEquals(token, tblImgToken.getDocumentToken());
    }

    @Test
    void testSetGetSecurityToken() {
        String secToken = "jwt-sec-token";
        tblImgToken.setSecurityToken(secToken);
        assertEquals(secToken, tblImgToken.getSecurityToken());

        tblImgToken.setSecurityToken(null);
        assertNull(tblImgToken.getSecurityToken());
    }

    @Test
    void testEqualityAndHashCode() {
        TblImgToken a = new TblImgToken();
        TblImgToken b = new TblImgToken();
        TblImgToken c = new TblImgToken();

        a.setRequestId(101);
        b.setRequestId(101);
        c.setRequestId(102);

        assertEquals(a, b);
        assertNotEquals(a, c);
        assertEquals(a.hashCode(), b.hashCode());
    }
}
