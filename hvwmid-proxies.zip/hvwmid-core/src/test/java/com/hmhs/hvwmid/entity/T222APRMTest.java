package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.assertEquals;

class T222APRMTest {

    @Test
    void testSetAndGetParmId() {
        T222APRM aprm = new T222APRM();
        aprm.setParmId("PRM123");
        assertEquals("PRM123", aprm.getParmId());
    }

    @Test
    void testSetAndGetParmKey() {
        T222APRM aprm = new T222APRM();
        aprm.setParmKey("KEY456");
        assertEquals("KEY456", aprm.getParmKey());
    }

    @Test
    void testSetAndGetModUser() {
        T222APRM aprm = new T222APRM();
        aprm.setModUser("USR001");
        assertEquals("USR001", aprm.getModUser());
    }

    @Test
    void testSetAndGetTimeChgd() {
        T222APRM aprm = new T222APRM();
        Timestamp now = new Timestamp(System.currentTimeMillis());
        aprm.setTimeChgd(now);
        assertEquals(now, aprm.getTimeChgd());
    }

    @Test
    void testSetAndGetParmData() {
        T222APRM aprm = new T222APRM();
        aprm.setParmData("Sample data value for test");
        assertEquals("Sample data value for test", aprm.getParmData());
    }
}
