package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class OdscrtIdTest {

    private OdscrtId id1;
    private OdscrtId id2;

    @BeforeEach
    void setUp() {
        id1 = new OdscrtId();
        id2 = new OdscrtId();
    }

    @Test
    void testSetAndGetAgName() {
        id1.setAgName("Agency1");
        assertEquals("Agency1", id1.getAgName());
    }

    @Test
    void testSetAndGetAppName() {
        id1.setAppName("Application1");
        assertEquals("Application1", id1.getAppName());
    }

    @Test
    void testEqualsSameObject() {
        id1.setAgName("AG");
        id1.setAppName("APP");
        assertEquals(id1, id1); // Same instance
    }

    @Test
    void testEqualsEqualObjects() {
        id1.setAgName("AG");
        id1.setAppName("APP");

        id2.setAgName("AG");
        id2.setAppName("APP");

        assertEquals(id1, id2); // Equal values
    }

    @Test
    void testEqualsDifferentAgName() {
        id1.setAgName("AG1");
        id1.setAppName("APP");

        id2.setAgName("AG2");
        id2.setAppName("APP");

        assertNotEquals(id1, id2); // agName differs
    }

    @Test
    void testEqualsDifferentAppName() {
        id1.setAgName("AG");
        id1.setAppName("APP1");

        id2.setAgName("AG");
        id2.setAppName("APP2");

        assertNotEquals(id1, id2); // appName differs
    }

    @Test
    void testEqualsNull() {
        id1.setAgName("AG");
        id1.setAppName("APP");

        assertNotEquals(id1, null);
    }

    @Test
    void testEqualsDifferentClass() {
        id1.setAgName("AG");
        id1.setAppName("APP");

        assertNotEquals(id1, "some string");
    }

    @Test
    void testHashCodeConsistency() {
        id1.setAgName("AG");
        id1.setAppName("APP");

        id2.setAgName("AG");
        id2.setAppName("APP");

        assertEquals(id1.hashCode(), id2.hashCode());
    }

    @Test
    void testHashCodeDifference() {
        id1.setAgName("AG");
        id1.setAppName("APP1");

        id2.setAgName("AG");
        id2.setAppName("APP2");

        assertNotEquals(id1.hashCode(), id2.hashCode());
    }
}
