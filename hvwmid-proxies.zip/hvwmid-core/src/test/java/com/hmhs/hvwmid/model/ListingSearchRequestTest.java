package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ListingSearchRequestTest {

    @Test
    void normalize_rtrimToNull_targetsOnly() {
        ListingSearchRequest req = new ListingSearchRequest();


        req.setA01FormNumQuery("A01-123   ");
        req.setFrmFormNumQuery(null);
        req.setTblFormNumQuery("     ");
        req.setUrcQueueDescQuery("QDESC\t  ");


        req.setA01CommentQuery("  hello  ");

        req.normalize();

        assertEquals("A01-123", req.getA01FormNumQuery());
        assertNull(req.getFrmFormNumQuery());
        assertNull(req.getTblFormNumQuery());
        assertEquals("QDESC", req.getUrcQueueDescQuery());
        assertEquals("hello", req.getA01CommentQuery());
    }

    @Test
    void normalize_ttn_trimsAndNullsProperly() {
        ListingSearchRequest req = new ListingSearchRequest();


        req.setAprSecResClassQuery("  SECRES  ");
        req.setFrmFormCdQuery("   ");
        req.setRttRLOBQuery("LOB_X");
        req.setRttTranTypeQuery("  TRN  ");
        req.setFtbFileTabQuery("\nTAB01\t");

        req.normalize();

        assertEquals("SECRES", req.getAprSecResClassQuery());
        assertNull(req.getFrmFormCdQuery());
        assertEquals("LOB_X", req.getRttRLOBQuery());
        assertEquals("TRN", req.getRttTranTypeQuery());
        assertEquals("TAB01", req.getFtbFileTabQuery());
    }

    @Test
    void normalize_doesNotAffectNumericAndBooleanFields() {
        ListingSearchRequest req = new ListingSearchRequest();


        req.setTblBatchIdQuery(123L);
        req.setA01PriorityQuery(5L);
        req.setTblBPriorityQuery(9L);
        req.setTblBPriorityDisplay(Boolean.TRUE);
        req.setLprApplIdCdDisplay(Boolean.FALSE);
        req.setLimit(100);
        req.setMainSchema("DB2INST1");
        req.setBatchtblschema("DB2INST1");
        req.setUserApplids(List.of(10, 20));


        req.setParmDataQuery("  PDATA ");
        req.setA01DpkQuery("   ");

        req.normalize();


        assertEquals(123L, req.getTblBatchIdQuery());
        assertEquals(5L, req.getA01PriorityQuery());
        assertEquals(9L, req.getTblBPriorityQuery());
        assertEquals(Boolean.TRUE, req.getTblBPriorityDisplay());
        assertEquals(Boolean.FALSE, req.getLprApplIdCdDisplay());
        assertEquals(100, req.getLimit());
        assertEquals("DB2INST1", req.getMainSchema());
        assertEquals("DB2INST1", req.getBatchtblschema());
        assertEquals(List.of(10, 20), req.getUserApplids());


        assertEquals("PDATA", req.getParmDataQuery());
        assertNull(req.getA01DpkQuery());
    }

    @Test
    void normalize_isIdempotent() {
        ListingSearchRequest req = new ListingSearchRequest();


        req.setA01FormNumQuery("VAL   ");
        req.setFrmRLOBQuery("  RLOB ");
        req.setTblFormNumQuery("   ");
        req.setRttCatWorkQuery("  CAT ");

        req.normalize();

        String v1 = req.getA01FormNumQuery();
        String v2 = req.getFrmRLOBQuery();
        String v3 = req.getTblFormNumQuery();
        String v4 = req.getRttCatWorkQuery();


        req.normalize();

        assertEquals(v1, req.getA01FormNumQuery());
        assertEquals(v2, req.getFrmRLOBQuery());
        assertEquals(v3, req.getTblFormNumQuery());
        assertEquals(v4, req.getRttCatWorkQuery());
    }

    @Test
    void normalize_preservesInternalSpacesButTrimsEnds() {
        ListingSearchRequest req = new ListingSearchRequest();

        req.setFrmObjDescQuery("  some  text  ");
        req.setUrcQueueDescQuery("desc  with  spaces   ");

        req.normalize();

        assertEquals("some  text", req.getFrmObjDescQuery());
        assertEquals("desc  with  spaces", req.getUrcQueueDescQuery());
    }
}
