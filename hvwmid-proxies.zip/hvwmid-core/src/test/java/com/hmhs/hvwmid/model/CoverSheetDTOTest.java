package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CoverSheetDTOTest {

    private CoverSheetDTO dto;

    @BeforeEach
    void setup() {
        dto = new CoverSheetDTO();
    }

    @Test
    void application_shouldSetAndGetCorrectly() {
        // Given
        Integer applicationId = 123;

        // When
        dto.setApplication(applicationId);

        // Then
        assertEquals(applicationId, dto.getApplication());
    }

    @Test
    void application_shouldHandleNullValue() {
        // Given
        dto.setApplication(null);

        // When & Then
        assertNull(dto.getApplication());
    }

    @Test
    void application_shouldHandleBoundaryValues() {
        // Given & When & Then
        dto.setApplication(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, dto.getApplication());

        dto.setApplication(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, dto.getApplication());
    }

    @Test
    void name_shouldTrimWhitespace() {
        // Given
        String nameWithSpaces = "  INVOICE  ";

        // When
        dto.setName(nameWithSpaces);

        // Then
        assertEquals("INVOICE", dto.getName());
    }

    @Test
    void name_shouldHandleEmptyString() {
        // Given
        dto.setName("");

        // When & Then
        assertEquals("", dto.getName());
    }

    @Test
    void name_shouldHandleStringWithOnlySpaces() {
        // Given
        dto.setName("   ");

        // When & Then
        assertEquals("", dto.getName());
    }

    @Test
    void description_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String descriptionWithSpaces = "  Test Description  ";

        // When
        dto.setDescription(descriptionWithSpaces);

        // Then
        assertEquals("Test Description", dto.getDescription());
    }

    @Test
    void description_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setDescription(null);

        // When & Then
        assertEquals("", dto.getDescription());
    }

    @Test
    void description_shouldHandleEmptyString() {
        // Given
        dto.setDescription("");

        // When & Then
        assertEquals("", dto.getDescription());
    }

    @Test
    void sb1_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String sb1WithSpaces = "  SB1 Value  ";

        // When
        dto.setSb1(sb1WithSpaces);

        // Then
        assertEquals("SB1 Value", dto.getSb1());
    }

    @Test
    void sb1_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setSb1(null);

        // When & Then
        assertEquals("", dto.getSb1());
    }

    @Test
    void eb1_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String eb1WithSpaces = "  EB1 Value  ";

        // When
        dto.setEb1(eb1WithSpaces);

        // Then
        assertEquals("EB1 Value", dto.getEb1());
    }

    @Test
    void eb1_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setEb1(null);

        // When & Then
        assertEquals("", dto.getEb1());
    }

    @Test
    void eb2_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String eb2WithSpaces = "  EB2 Value  ";

        // When
        dto.setEb2(eb2WithSpaces);

        // Then
        assertEquals("EB2 Value", dto.getEb2());
    }

    @Test
    void eb2_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setEb2(null);

        // When & Then
        assertEquals("", dto.getEb2());
    }

    @Test
    void eb3_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String eb3WithSpaces = "  EB3 Value  ";

        // When
        dto.setEb3(eb3WithSpaces);

        // Then
        assertEquals("EB3 Value", dto.getEb3());
    }

    @Test
    void eb3_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setEb3(null);

        // When & Then
        assertEquals("", dto.getEb3());
    }

    @Test
    void title_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String titleWithSpaces = "  Main Title  ";

        // When
        dto.setTitle(titleWithSpaces);

        // Then
        assertEquals("Main Title", dto.getTitle());
    }

    @Test
    void title_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setTitle(null);

        // When & Then
        assertEquals("", dto.getTitle());
    }

    @Test
    void stitle1_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String stitle1WithSpaces = "  Subtitle 1  ";

        // When
        dto.setStitle1(stitle1WithSpaces);

        // Then
        assertEquals("Subtitle 1", dto.getStitle1());
    }

    @Test
    void stitle1_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setStitle1(null);

        // When & Then
        assertEquals("", dto.getStitle1());
    }

    @Test
    void stitle2_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String stitle2WithSpaces = "  Subtitle 2  ";

        // When
        dto.setStitle2(stitle2WithSpaces);

        // Then
        assertEquals("Subtitle 2", dto.getStitle2());
    }

    @Test
    void stitle2_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setStitle2(null);

        // When & Then
        assertEquals("", dto.getStitle2());
    }

    @Test
    void unit_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String unitWithSpaces = "  UNIT1  ";

        // When
        dto.setUnit(unitWithSpaces);

        // Then
        assertEquals("UNIT1", dto.getUnit());
    }

    @Test
    void unit_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setUnit(null);

        // When & Then
        assertEquals("", dto.getUnit());
    }

    @Test
    void rcode_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String rcodeWithSpaces = "  RC001  ";

        // When
        dto.setRcode(rcodeWithSpaces);

        // Then
        assertEquals("RC001", dto.getRcode());
    }

    @Test
    void rcode_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setRcode(null);

        // When & Then
        assertEquals("", dto.getRcode());
    }

    @Test
    void template_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String templateWithSpaces = "  TEMPLATE1  ";

        // When
        dto.setTemplate(templateWithSpaces);

        // Then
        assertEquals("TEMPLATE1", dto.getTemplate());
    }

    @Test
    void template_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setTemplate(null);

        // When & Then
        assertEquals("", dto.getTemplate());
    }

    @Test
    void active_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String activeWithSpaces = "  Y  ";

        // When
        dto.setActive(activeWithSpaces);

        // Then
        assertEquals("Y", dto.getActive());
    }

    @Test
    void active_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setActive(null);

        // When & Then
        assertEquals("", dto.getActive());
    }

    @Test
    void environment_shouldTrimWhitespaceAndHandleNull() {
        // Given
        String environmentWithSpaces = "  TEST  ";

        // When
        dto.setEnvironment(environmentWithSpaces);

        // Then
        assertEquals("TEST", dto.getEnvironment());
    }

    @Test
    void environment_shouldReturnEmptyStringWhenNull() {
        // Given
        dto.setEnvironment(null);

        // When & Then
        assertEquals("", dto.getEnvironment());
    }

    @Test
    void dto_shouldHandleCompleteObjectCreation() {
        // Given
        Integer application = 100;
        String name = "INVOICE";
        String description = "Invoice Coversheet";
        String sb1 = "SB1";
        String eb1 = "EB1";
        String eb2 = "EB2";
        String eb3 = "EB3";
        String title = "Main Title";
        String stitle1 = "Subtitle 1";
        String stitle2 = "Subtitle 2";
        String unit = "UNIT1";
        String rcode = "RC001";
        String template = "TEMPLATE1";
        String active = "Y";
        String environment = "TEST";

        // When
        dto.setApplication(application);
        dto.setName(name);
        dto.setDescription(description);
        dto.setSb1(sb1);
        dto.setEb1(eb1);
        dto.setEb2(eb2);
        dto.setEb3(eb3);
        dto.setTitle(title);
        dto.setStitle1(stitle1);
        dto.setStitle2(stitle2);
        dto.setUnit(unit);
        dto.setRcode(rcode);
        dto.setTemplate(template);
        dto.setActive(active);
        dto.setEnvironment(environment);

        // Then
        assertEquals(application, dto.getApplication());
        assertEquals(name, dto.getName());
        assertEquals(description, dto.getDescription());
        assertEquals(sb1, dto.getSb1());
        assertEquals(eb1, dto.getEb1());
        assertEquals(eb2, dto.getEb2());
        assertEquals(eb3, dto.getEb3());
        assertEquals(title, dto.getTitle());
        assertEquals(stitle1, dto.getStitle1());
        assertEquals(stitle2, dto.getStitle2());
        assertEquals(unit, dto.getUnit());
        assertEquals(rcode, dto.getRcode());
        assertEquals(template, dto.getTemplate());
        assertEquals(active, dto.getActive());
        assertEquals(environment, dto.getEnvironment());
    }

    @Test
    void dto_shouldHandleCompleteObjectWithWhitespace() {
        // Given - All string fields have leading/trailing whitespace
        String nameWithSpaces = "  INVOICE  ";
        String descriptionWithSpaces = "  Invoice Coversheet  ";
        String sb1WithSpaces = "  SB1  ";
        String eb1WithSpaces = "  EB1  ";
        String eb2WithSpaces = "  EB2  ";
        String eb3WithSpaces = "  EB3  ";
        String titleWithSpaces = "  Main Title  ";
        String stitle1WithSpaces = "  Subtitle 1  ";
        String stitle2WithSpaces = "  Subtitle 2  ";
        String unitWithSpaces = "  UNIT1  ";
        String rcodeWithSpaces = "  RC001  ";
        String templateWithSpaces = "  TEMPLATE1  ";
        String activeWithSpaces = "  Y  ";
        String environmentWithSpaces = "  TEST  ";

        // When
        dto.setName(nameWithSpaces);
        dto.setDescription(descriptionWithSpaces);
        dto.setSb1(sb1WithSpaces);
        dto.setEb1(eb1WithSpaces);
        dto.setEb2(eb2WithSpaces);
        dto.setEb3(eb3WithSpaces);
        dto.setTitle(titleWithSpaces);
        dto.setStitle1(stitle1WithSpaces);
        dto.setStitle2(stitle2WithSpaces);
        dto.setUnit(unitWithSpaces);
        dto.setRcode(rcodeWithSpaces);
        dto.setTemplate(templateWithSpaces);
        dto.setActive(activeWithSpaces);
        dto.setEnvironment(environmentWithSpaces);

        // Then - All getters should return trimmed values
        assertEquals("INVOICE", dto.getName());
        assertEquals("Invoice Coversheet", dto.getDescription());
        assertEquals("SB1", dto.getSb1());
        assertEquals("EB1", dto.getEb1());
        assertEquals("EB2", dto.getEb2());
        assertEquals("EB3", dto.getEb3());
        assertEquals("Main Title", dto.getTitle());
        assertEquals("Subtitle 1", dto.getStitle1());
        assertEquals("Subtitle 2", dto.getStitle2());
        assertEquals("UNIT1", dto.getUnit());
        assertEquals("RC001", dto.getRcode());
        assertEquals("TEMPLATE1", dto.getTemplate());
        assertEquals("Y", dto.getActive());
        assertEquals("TEST", dto.getEnvironment());
    }

    @Test
    void dto_shouldCreateWithDefaultConstructor() {
        // When
        CoverSheetDTO newDto = new CoverSheetDTO();

        // Then - Application should be null, all string fields should return empty when accessed
        assertNull(newDto.getApplication());
        
        // These should return empty string because they handle null
        assertEquals("", newDto.getDescription());
        assertEquals("", newDto.getSb1());
        assertEquals("", newDto.getEb1());
        assertEquals("", newDto.getEb2());
        assertEquals("", newDto.getEb3());
        assertEquals("", newDto.getTitle());
        assertEquals("", newDto.getStitle1());
        assertEquals("", newDto.getStitle2());
        assertEquals("", newDto.getUnit());
        assertEquals("", newDto.getRcode());
        assertEquals("", newDto.getTemplate());
        assertEquals("", newDto.getActive());
        assertEquals("", newDto.getEnvironment());
    }

    @Test
    void dto_shouldHandleSpecialCharactersInStrings() {
        // Given
        String specialChars = "!@#$%^&*()";

        // When
        dto.setName(specialChars);
        dto.setDescription(specialChars);
        dto.setSb1(specialChars);
        dto.setEb1(specialChars);

        // Then
        assertEquals(specialChars, dto.getName());
        assertEquals(specialChars, dto.getDescription());
        assertEquals(specialChars, dto.getSb1());
        assertEquals(specialChars, dto.getEb1());
    }

    @Test
    void dto_shouldHandleUnicodeCharacters() {
        // Given
        String unicodeChars = "Tëst Üñîçødë";

        // When
        dto.setName(unicodeChars);
        dto.setDescription(unicodeChars);
        dto.setTitle(unicodeChars);

        // Then
        assertEquals(unicodeChars, dto.getName());
        assertEquals(unicodeChars, dto.getDescription());
        assertEquals(unicodeChars, dto.getTitle());
    }

    @Test
    void dto_shouldHandleEmptyStringsForAllFields() {
        // Given
        String emptyString = "";

        // When
        dto.setName(emptyString);
        dto.setDescription(emptyString);
        dto.setSb1(emptyString);
        dto.setEb1(emptyString);
        dto.setEb2(emptyString);
        dto.setEb3(emptyString);
        dto.setTitle(emptyString);
        dto.setStitle1(emptyString);
        dto.setStitle2(emptyString);
        dto.setUnit(emptyString);
        dto.setRcode(emptyString);
        dto.setTemplate(emptyString);
        dto.setActive(emptyString);
        dto.setEnvironment(emptyString);

        // Then
        assertEquals("", dto.getName());
        assertEquals("", dto.getDescription());
        assertEquals("", dto.getSb1());
        assertEquals("", dto.getEb1());
        assertEquals("", dto.getEb2());
        assertEquals("", dto.getEb3());
        assertEquals("", dto.getTitle());
        assertEquals("", dto.getStitle1());
        assertEquals("", dto.getStitle2());
        assertEquals("", dto.getUnit());
        assertEquals("", dto.getRcode());
        assertEquals("", dto.getTemplate());
        assertEquals("", dto.getActive());
        assertEquals("", dto.getEnvironment());
    }

    @Test
    void dto_shouldHandleOnlyWhitespaceStrings() {
        // Given
        String onlySpaces = "   ";

        // When
        dto.setName(onlySpaces);
        dto.setDescription(onlySpaces);
        dto.setSb1(onlySpaces);
        dto.setEb1(onlySpaces);
        dto.setEb2(onlySpaces);
        dto.setEb3(onlySpaces);
        dto.setTitle(onlySpaces);
        dto.setStitle1(onlySpaces);
        dto.setStitle2(onlySpaces);
        dto.setUnit(onlySpaces);
        dto.setRcode(onlySpaces);
        dto.setTemplate(onlySpaces);
        dto.setActive(onlySpaces);
        dto.setEnvironment(onlySpaces);

        // Then - All should return empty string after trim
        assertEquals("", dto.getName());
        assertEquals("", dto.getDescription());
        assertEquals("", dto.getSb1());
        assertEquals("", dto.getEb1());
        assertEquals("", dto.getEb2());
        assertEquals("", dto.getEb3());
        assertEquals("", dto.getTitle());
        assertEquals("", dto.getStitle1());
        assertEquals("", dto.getStitle2());
        assertEquals("", dto.getUnit());
        assertEquals("", dto.getRcode());
        assertEquals("", dto.getTemplate());
        assertEquals("", dto.getActive());
        assertEquals("", dto.getEnvironment());
    }

    @Test
    void dto_shouldHandleNullBehaviorConsistency() {
        // Given - Set all string fields to null
        dto.setName(null);
        dto.setDescription(null);
        dto.setSb1(null);
        dto.setEb1(null);
        dto.setEb2(null);
        dto.setEb3(null);
        dto.setTitle(null);
        dto.setStitle1(null);
        dto.setStitle2(null);
        dto.setUnit(null);
        dto.setRcode(null);
        dto.setTemplate(null);
        dto.setActive(null);
        dto.setEnvironment(null);

        assertEquals("", dto.getDescription());
        assertEquals("", dto.getSb1());
        assertEquals("", dto.getEb1());
        assertEquals("", dto.getEb2());
        assertEquals("", dto.getEb3());
        assertEquals("", dto.getTitle());
        assertEquals("", dto.getStitle1());
        assertEquals("", dto.getStitle2());
        assertEquals("", dto.getUnit());
        assertEquals("", dto.getRcode());
        assertEquals("", dto.getTemplate());
        assertEquals("", dto.getActive());
        assertEquals("", dto.getEnvironment());
    }
}