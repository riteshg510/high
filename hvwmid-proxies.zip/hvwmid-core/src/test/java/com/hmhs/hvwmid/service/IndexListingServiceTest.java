package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IndexListingServiceTest {

    @Mock
    private RestClientUtil restClientUtil;

    @InjectMocks
    private IndexListingService indexListingService;

    @BeforeEach
    void setup() {
        indexListingService.setApiUrl("http://mock-api/index");
        indexListingService.setAccessUrl("http://mock-api/access");
    }

    @Test
    void processReportData_success() throws IOException {
        // Arrange
        String authToken = "mock-token";

        Map<String, String> input = new HashMap<>();
        input.put("odFolderName", "CMODTestFolder");
        input.put("startdate", "20240101");
        input.put("enddate", "20240131");

        Map<String, Object> docData = new HashMap<>();
        docData.put("REPORT ID", "REP123");
        docData.put("NAME", "Sample Report");

        Map<String, Object> indexResponse = new HashMap<>();
        indexResponse.put("reportArchiveData", Map.of("reportArchiveDocumentData", List.of(docData)));

        Map<String, Object> accessResponse = new HashMap<>();
        accessResponse.put("authorizedApplicationGroups", List.of(
                Map.of("applications", List.of("REP123"), "accessLevel", "Update,Delete")
        ));

        when(restClientUtil.postRequest(eq("http://mock-api/index"), eq(authToken), any()))
                .thenReturn(new ResponseEntity<>(indexResponse, HttpStatus.OK));

        when(restClientUtil.postRequest(eq("http://mock-api/access"), eq(authToken), any()))
                .thenReturn(new ResponseEntity<>(accessResponse, HttpStatus.OK));

        // Act
        Map<String, Object> result = indexListingService.processReportData(input, authToken);

        // Assert
        assertNotNull(result);
        assertTrue(result.containsKey("definition"));
        assertTrue(result.containsKey("data"));
        List<?> data = (List<?>) result.get("data");
        assertFalse(data.isEmpty());
        Map<?, ?> row = (Map<?, ?>) data.get(0);
        assertTrue(row.containsKey("action"));
    }

    @Test
    void fetchAccessRights_shouldReturnPermissionsForEachApp() {
        // Arrange
        String token = "mock-token";
        String folderName = "SomeFolder";

        Map<String, Object> apiResponse = Map.of(
                "authorizedApplicationGroups", List.of(
                        Map.of(
                                "applications", List.of("APP123", "APP456"),
                                "accessLevel", "Update,Delete"
                        )
                )
        );

        when(restClientUtil.postRequest(eq("http://mock-api/access"), eq(token), any()))
                .thenReturn(new ResponseEntity<>(apiResponse, HttpStatus.OK));

        // Act
        Map<String, Set<String>> result = indexListingService.fetchAccessRights(token, folderName);

        // Assert
        assertTrue(result.containsKey("APP123"));
        assertTrue(result.get("APP123").contains("Delete"));
        assertTrue(result.get("APP456").contains("Update"));
    }

    @Test
    void fetchAccessRights_shouldReturnEmptyIfNoAccessGroups() {
        // Arrange
        String token = "mock-token";
        String folderName = "SomeFolder";

        Map<String, Object> emptyResponse = new HashMap<>();

        when(restClientUtil.postRequest(anyString(), eq(token), any()))
                .thenReturn(new ResponseEntity<>(emptyResponse, HttpStatus.OK));

        // Act
        Map<String, Set<String>> result = indexListingService.fetchAccessRights(token, folderName);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void fetchAccessRights_shouldHandleExceptionGracefully() {
        // Arrange
        String token = "mock-token";
        String folderName = "Folder123";

        when(restClientUtil.postRequest(anyString(), eq(token), any()))
                .thenThrow(new RuntimeException("Simulated failure"));

        // Act
        Map<String, Set<String>> result = indexListingService.fetchAccessRights(token, folderName);

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testAddActionButtons_WithUpdateAndDeleteAccess() throws Exception {
        // Given
        Map<String, Object> row = new HashMap<>();
        row.put("REPORT ID", "123");
        row.put("TITLE", "Report A");
        row.put("DELETED", "false");

        List<Map<String, Object>> data = List.of(row);
        String token = "mockToken";
        String folder = "Invoices";

        Map<String, Set<String>> accessRights = Map.of(
                "123", Set.of("Update", "Delete")
        );

        // Spy the method to mock fetchAccessRights
        IndexListingService spyService = Mockito.spy(indexListingService);
        doReturn(accessRights).when(spyService).fetchAccessRights(token, folder);

        // When
        List<Map<String, Object>> result = spyService.addActionButtons(data, token, folder);

        // Then
        assertEquals(1, result.size());
        Map<String, Object> resultRow = result.get(0);
        assertTrue(resultRow.containsKey("action"));

        List<?> actions = (List<?>) resultRow.get("action");
        assertEquals(4, actions.size(), "Should contain View, Download, Update, Delete actions");

        // Check structure of actions
        List<String> labels = actions.stream()
                .map(obj -> ((Map<?, ?>) obj).get("actionType").toString())
                .toList();

        assertTrue(labels.containsAll(List.of("downloadpdf", "download", "edit", "delete")));
    }

    @Test
    void testAddActionButtons_DeleteAction_WhenDocumentNotDeleted() throws Exception {
        // Given: Document is NOT deleted
        Map<String, Object> row = new HashMap<>();
        row.put("REPORT ID", "123");
        row.put("TITLE", "Report A");
        row.put("DELETED", "N"); // Not deleted

        List<Map<String, Object>> data = List.of(row);
        String token = "mockToken";
        String folder = "Invoices";

        Map<String, Set<String>> accessRights = Map.of(
                "123", Set.of("Delete")
        );

        // Spy the method to mock fetchAccessRights
        IndexListingService spyService = Mockito.spy(indexListingService);
        doReturn(accessRights).when(spyService).fetchAccessRights(token, folder);

        // When
        List<Map<String, Object>> result = spyService.addActionButtons(data, token, folder);

        // Then
        assertEquals(1, result.size());
        Map<String, Object> resultRow = result.get(0);
        List<?> actions = (List<?>) resultRow.get("action");
        
        // Find the delete action
        Map<?, ?> deleteAction = actions.stream()
                .map(obj -> (Map<?, ?>) obj)
                .filter(action -> "delete".equals(action.get("actionType")))
                .findFirst()
                .orElse(null);
        
        assertNotNull(deleteAction, "Delete action should be present");
        assertEquals("Delete", deleteAction.get("label"), "Label should be 'Delete' for non-deleted document");
        assertEquals("report-archive/tokens/delete", deleteAction.get("apiUrl"), "API URL should be delete endpoint");
    }

    @Test
    void testAddActionButtons_UndeleteAction_WhenDocumentIsDeleted() throws Exception {
        // Given: Document IS deleted
        Map<String, Object> row = new HashMap<>();
        row.put("REPORT ID", "123");
        row.put("TITLE", "Report A");
        row.put("DELETED", "Y"); // Document is deleted

        List<Map<String, Object>> data = List.of(row);
        String token = "mockToken";
        String folder = "Invoices";

        Map<String, Set<String>> accessRights = Map.of(
                "123", Set.of("Delete")
        );

        // Spy the method to mock fetchAccessRights
        IndexListingService spyService = Mockito.spy(indexListingService);
        doReturn(accessRights).when(spyService).fetchAccessRights(token, folder);

        // When
        List<Map<String, Object>> result = spyService.addActionButtons(data, token, folder);

        // Then
        assertEquals(1, result.size());
        Map<String, Object> resultRow = result.get(0);
        List<?> actions = (List<?>) resultRow.get("action");
        
        // Find the delete action
        Map<?, ?> deleteAction = actions.stream()
                .map(obj -> (Map<?, ?>) obj)
                .filter(action -> "delete".equals(action.get("actionType")))
                .findFirst()
                .orElse(null);
        
        assertNotNull(deleteAction, "Delete action should be present");
        assertEquals("Undelete", deleteAction.get("label"), "Label should be 'Undelete' for deleted document");
        assertEquals("report-archive/tokens/undelete", deleteAction.get("apiUrl"), "API URL should be undelete endpoint");
    }

    @Test
    void testAddActionButtons_DeleteAction_WhenDocumentDeletedLowerCase() throws Exception {
        // Given: Document is deleted with lowercase 'y'
        Map<String, Object> row = new HashMap<>();
        row.put("REPORT ID", "123");
        row.put("TITLE", "Report A");
        row.put("DELETED", "y"); // Document is deleted (lowercase)

        List<Map<String, Object>> data = List.of(row);
        String token = "mockToken";
        String folder = "Invoices";

        Map<String, Set<String>> accessRights = Map.of(
                "123", Set.of("Delete")
        );

        // Spy the method to mock fetchAccessRights
        IndexListingService spyService = Mockito.spy(indexListingService);
        doReturn(accessRights).when(spyService).fetchAccessRights(token, folder);

        // When
        List<Map<String, Object>> result = spyService.addActionButtons(data, token, folder);

        // Then
        assertEquals(1, result.size());
        Map<String, Object> resultRow = result.get(0);
        List<?> actions = (List<?>) resultRow.get("action");
        
        // Find the delete action
        Map<?, ?> deleteAction = actions.stream()
                .map(obj -> (Map<?, ?>) obj)
                .filter(action -> "delete".equals(action.get("actionType")))
                .findFirst()
                .orElse(null);
        
        assertNotNull(deleteAction, "Delete action should be present");
        assertEquals("Undelete", deleteAction.get("label"), "Label should be 'Undelete' for deleted document (lowercase)");
        assertEquals("report-archive/tokens/undelete", deleteAction.get("apiUrl"), "API URL should be undelete endpoint for lowercase 'y'");
    }

    @Test
    void testAddActionButtons_DeleteAction_WhenDocumentDeletedMixedCase() throws Exception {
        // Given: Document is deleted with mixed case values
        Map<String, Object> row = new HashMap<>();
        row.put("REPORT ID", "123");
        row.put("TITLE", "Report A");
        row.put("DELETED", "Yes"); // Document is deleted (mixed case, should not match)

        List<Map<String, Object>> data = List.of(row);
        String token = "mockToken";
        String folder = "Invoices";

        Map<String, Set<String>> accessRights = Map.of(
                "123", Set.of("Delete")
        );

        // Spy the method to mock fetchAccessRights
        IndexListingService spyService = Mockito.spy(indexListingService);
        doReturn(accessRights).when(spyService).fetchAccessRights(token, folder);

        // When
        List<Map<String, Object>> result = spyService.addActionButtons(data, token, folder);

        // Then
        assertEquals(1, result.size());
        Map<String, Object> resultRow = result.get(0);
        List<?> actions = (List<?>) resultRow.get("action");
        
        // Find the delete action
        Map<?, ?> deleteAction = actions.stream()
                .map(obj -> (Map<?, ?>) obj)
                .filter(action -> "delete".equals(action.get("actionType")))
                .findFirst()
                .orElse(null);
        
        assertNotNull(deleteAction, "Delete action should be present");
        assertEquals("Delete", deleteAction.get("label"), "Label should remain 'Delete' for non-matching deleted value");
        assertEquals("report-archive/tokens/delete", deleteAction.get("apiUrl"), "API URL should remain delete endpoint for non-matching value");
    }

    @Test
    void testBuildColumnsold_NoDocuments_ReturnsOnlyActionsColumn() {
        // Given: Empty document list
        Map<String, Object> apiResponse = Map.of("documents", List.of());

        IndexListingService spyService = Mockito.spy(indexListingService);
        doReturn(Map.of("field", "actions", "header", "Actions")).when(spyService).createActionsColumn();

        // When
        List<Map<String, String>> result = spyService.buildColumnsold(apiResponse);

        // Then
        assertEquals(1, result.size());
        assertEquals("actions", result.get(0).get("field"));
    }

     @Test
    void processReportData_withSrchopO_setsSearchCriteriaOR() throws IOException {
        // Arrange
        String authToken = "mock-token";

        Map<String, String> input = new HashMap<>();
        input.put("odFolderName", "CMODTestFolder");
        input.put("startdate", "20240101");
        input.put("enddate", "20240131");
        input.put("srchop", "O");

        Map<String, Object> docData = new HashMap<>();
        docData.put("REPORT ID", "REP123");
        docData.put("NAME", "Sample Report");

        Map<String, Object> indexResponse = new HashMap<>();
        indexResponse.put("reportArchiveData", Map.of("reportArchiveDocumentData", List.of(docData)));

        Map<String, Object> accessResponse = new HashMap<>();
        accessResponse.put("authorizedApplicationGroups", List.of(
                Map.of("applications", List.of("REP123"), "accessLevel", "Update,Delete")
        ));

        // Capture the request body sent to postRequest
        final Map<String, Object>[] capturedRequest = new Map[1];
        when(restClientUtil.postRequest(eq("http://mock-api/index"), eq(authToken), any()))
                .thenAnswer(invocation -> {
                    capturedRequest[0] = invocation.getArgument(2);
                    return new ResponseEntity<>(indexResponse, HttpStatus.OK);
                });

        when(restClientUtil.postRequest(eq("http://mock-api/access"), eq(authToken), any()))
                .thenReturn(new ResponseEntity<>(accessResponse, HttpStatus.OK));

        // Act
        Map<String, Object> result = indexListingService.processReportData(input, authToken);

        // Assert
        assertNotNull(result);
        assertTrue(result.containsKey("definition"));
        assertTrue(result.containsKey("data"));
        assertNotNull(capturedRequest[0]);
        assertEquals("OR", capturedRequest[0].get("searchCriteria"));
        // srchop should not be present in folderSearchCriteria
        List<?> folderSearchCriteria = (List<?>) capturedRequest[0].get("folderSearchCriteria");
        assertFalse(((Map<?, ?>) folderSearchCriteria.get(0)).containsKey("srchop"));
    }

    @Test
    void processReportData_withSrchopa_setsSearchCriteriaAND() throws IOException {
        // Arrange
        String authToken = "mock-token";

        Map<String, String> input = new HashMap<>();
        input.put("odFolderName", "CMODTestFolder");
        input.put("startdate", "20240101");
        input.put("enddate", "20240131");
        input.put("srchop", "a");

        Map<String, Object> docData = new HashMap<>();
        docData.put("REPORT ID", "REP123");
        docData.put("NAME", "Sample Report");

        Map<String, Object> indexResponse = new HashMap<>();
        indexResponse.put("reportArchiveData", Map.of("reportArchiveDocumentData", List.of(docData)));

        Map<String, Object> accessResponse = new HashMap<>();
        accessResponse.put("authorizedApplicationGroups", List.of(
                Map.of("applications", List.of("REP123"), "accessLevel", "Update,Delete")
        ));

        // Capture the request body sent to postRequest
        final Map<String, Object>[] capturedRequest = new Map[1];
        when(restClientUtil.postRequest(eq("http://mock-api/index"), eq(authToken), any()))
                .thenAnswer(invocation -> {
                    capturedRequest[0] = invocation.getArgument(2);
                    return new ResponseEntity<>(indexResponse, HttpStatus.OK);
                });

        when(restClientUtil.postRequest(eq("http://mock-api/access"), eq(authToken), any()))
                .thenReturn(new ResponseEntity<>(accessResponse, HttpStatus.OK));

        // Act
        Map<String, Object> result = indexListingService.processReportData(input, authToken);

        // Assert
        assertNotNull(result);
        assertTrue(result.containsKey("definition"));
        assertTrue(result.containsKey("data"));
        assertNotNull(capturedRequest[0]);
        assertEquals("AND", capturedRequest[0].get("searchCriteria"));
        // srchop should not be present in folderSearchCriteria
        List<?> folderSearchCriteria = (List<?>) capturedRequest[0].get("folderSearchCriteria");
        assertFalse(((Map<?, ?>) folderSearchCriteria.get(0)).containsKey("srchop"));
    }
}
