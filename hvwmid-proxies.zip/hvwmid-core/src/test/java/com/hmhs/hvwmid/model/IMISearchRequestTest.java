package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMISearchRequest POJO
 * Tests all getters, setters, default values, and toString method
 * 
 */
class IMISearchRequestTest {

    private IMISearchRequest imiSearchRequest;

    @BeforeEach
    void setUp() {
        imiSearchRequest = new IMISearchRequest();
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        IMISearchRequest request = new IMISearchRequest();
        assertNotNull(request);
        
        // Test default values
        assertEquals(0L, request.getResultSetPointer());
        assertTrue(request.isPaginationOn());
        assertEquals(250L, request.getPaginationRowCount());
        assertFalse(request.isSearchById());
    }

    // ========== BASIC FIELD TESTS ==========

    @Test
    void testNaicCodeGetterAndSetter() {
        imiSearchRequest.setNaicCode("12345");
        assertEquals("12345", imiSearchRequest.getNaicCode());
    }

    @Test
    void testNaicCodeWithNull() {
        imiSearchRequest.setNaicCode(null);
        assertNull(imiSearchRequest.getNaicCode());
    }

    @Test
    void testNaicCodeWithEmptyString() {
        imiSearchRequest.setNaicCode("");
        assertEquals("", imiSearchRequest.getNaicCode());
    }

    @Test
    void testTransmitTimestampFromGetterAndSetter() {
        imiSearchRequest.setTransmitTimestampFrom("2023-01-01 00:00:00");
        assertEquals("2023-01-01 00:00:00", imiSearchRequest.getTransmitTimestampFrom());
    }

    @Test
    void testTransmitTimestampToGetterAndSetter() {
        imiSearchRequest.setTransmitTimestampTo("2023-12-31 23:59:59");
        assertEquals("2023-12-31 23:59:59", imiSearchRequest.getTransmitTimestampTo());
    }

    // ========== TRANSMIT FILE TESTS ==========

    @Test
    void testTransmitFileIdQueryGetterAndSetter() {
        imiSearchRequest.setTransmitFileIdQuery(12345L);
        assertEquals(12345L, imiSearchRequest.getTransmitFileIdQuery());
    }

    @Test
    void testTransmitFileIdDisplayGetterAndSetter() {
        imiSearchRequest.setTransmitFileIdDisplay(true);
        assertTrue(imiSearchRequest.isTransmitFileIdDisplay());
        
        imiSearchRequest.setTransmitFileIdDisplay(false);
        assertFalse(imiSearchRequest.isTransmitFileIdDisplay());
    }

    @Test
    void testTransmitFileNameQueryGetterAndSetter() {
        imiSearchRequest.setTransmitFileNameQuery("test_file.txt");
        assertEquals("test_file.txt", imiSearchRequest.getTransmitFileNameQuery());
    }

    @Test
    void testTransmitFileNameSearchOperatorGetterAndSetter() {
        imiSearchRequest.setTransmitFileNameSearchOperator("LIKE");
        assertEquals("LIKE", imiSearchRequest.getTransmitFileNameSearchOperator());
    }

    @Test
    void testTransmitFileNameDisplayGetterAndSetter() {
        imiSearchRequest.setTransmitFileNameDisplay(true);
        assertTrue(imiSearchRequest.isTransmitFileNameDisplay());
    }

    @Test
    void testTransmitFileStatusCdQueryGetterAndSetter() {
        imiSearchRequest.setTransmitFileStatusCdQuery("A");
        assertEquals("A", imiSearchRequest.getTransmitFileStatusCdQuery());
    }

    @Test
    void testTransmitFileStatusCdSearchOperatorGetterAndSetter() {
        imiSearchRequest.setTransmitFileStatusCdSearchOperator("=");
        assertEquals("=", imiSearchRequest.getTransmitFileStatusCdSearchOperator());
    }

    @Test
    void testTransmitFileStatusCdDisplayGetterAndSetter() {
        imiSearchRequest.setTransmitFileStatusCdDisplay(true);
        assertTrue(imiSearchRequest.isTransmitFileStatusCdDisplay());
    }

    // ========== IMI FILE TESTS ==========

    @Test
    void testImiFileIdQueryGetterAndSetter() {
        imiSearchRequest.setImiFileIdQuery(67890L);
        assertEquals(67890L, imiSearchRequest.getImiFileIdQuery());
    }

    @Test
    void testImiFileIdDisplayGetterAndSetter() {
        imiSearchRequest.setImiFileIdDisplay(true);
        assertTrue(imiSearchRequest.isImiFileIdDisplay());
    }

    // ========== PLAN FILE TESTS ==========

    @Test
    void testPlanFileIdQueryGetterAndSetter() {
        imiSearchRequest.setPlanFileIdQuery("PLAN123");
        assertEquals("PLAN123", imiSearchRequest.getPlanFileIdQuery());
    }

    @Test
    void testPlanFileIdSearchOperatorGetterAndSetter() {
        imiSearchRequest.setPlanFileIdSearchOperator("CONTAINS");
        assertEquals("CONTAINS", imiSearchRequest.getPlanFileIdSearchOperator());
    }

    @Test
    void testPlanFileIdDisplayGetterAndSetter() {
        imiSearchRequest.setPlanFileIdDisplay(true);
        assertTrue(imiSearchRequest.isPlanFileIdDisplay());
    }

    // ========== PROCESS FILE TESTS ==========

    @Test
    void testProcessFileNameQueryGetterAndSetter() {
        imiSearchRequest.setProcessFileNameQuery("process_file.pdf");
        assertEquals("process_file.pdf", imiSearchRequest.getProcessFileNameQuery());
    }

    @Test
    void testProcessFileNameSearchOperatorGetterAndSetter() {
        imiSearchRequest.setProcessFileNameSearchOperator("STARTS_WITH");
        assertEquals("STARTS_WITH", imiSearchRequest.getProcessFileNameSearchOperator());
    }

    @Test
    void testProcessFileNameDisplayGetterAndSetter() {
        imiSearchRequest.setProcessFileNameDisplay(true);
        assertTrue(imiSearchRequest.isProcessFileNameDisplay());
    }

    @Test
    void testProcessFileStatusCdQueryGetterAndSetter() {
        imiSearchRequest.setProcessFileStatusCdQuery("C");
        assertEquals("C", imiSearchRequest.getProcessFileStatusCdQuery());
    }

    @Test
    void testProcessFileStatusCdSearchOperatorGetterAndSetter() {
        imiSearchRequest.setProcessFileStatusCdSearchOperator("=");
        assertEquals("=", imiSearchRequest.getProcessFileStatusCdSearchOperator());
    }

    @Test
    void testProcessFileStatusCdDisplayGetterAndSetter() {
        imiSearchRequest.setProcessFileStatusCdDisplay(true);
        assertTrue(imiSearchRequest.isProcessFileStatusCdDisplay());
    }

    @Test
    void testProcessFileReasonCdQueryGetterAndSetter() {
        imiSearchRequest.setProcessFileReasonCdQuery("REASON001");
        assertEquals("REASON001", imiSearchRequest.getProcessFileReasonCdQuery());
    }

    @Test
    void testProcessFileReasonCdSearchOperatorGetterAndSetter() {
        imiSearchRequest.setProcessFileReasonCdSearchOperator("=");
        assertEquals("=", imiSearchRequest.getProcessFileReasonCdSearchOperator());
    }

    @Test
    void testProcessFileReasonCdDisplayGetterAndSetter() {
        imiSearchRequest.setProcessFileReasonCdDisplay(true);
        assertTrue(imiSearchRequest.isProcessFileReasonCdDisplay());
    }

    // ========== TIME ACK TESTS ==========

    @Test
    void testTimeAckQueryGetterAndSetter() {
        imiSearchRequest.setTimeAckQuery("2023-01-01 10:30:00");
        assertEquals("2023-01-01 10:30:00", imiSearchRequest.getTimeAckQuery());
    }

    @Test
    void testTimeAckSearchOperatorGetterAndSetter() {
        imiSearchRequest.setTimeAckSearchOperator(">=");
        assertEquals(">=", imiSearchRequest.getTimeAckSearchOperator());
    }

    @Test
    void testTimeAckDisplayGetterAndSetter() {
        imiSearchRequest.setTimeAckDisplay(true);
        assertTrue(imiSearchRequest.isTimeAckDisplay());
    }

    // ========== IMI DOCUMENT TESTS ==========

    @Test
    void testImiDocumentIdQueryGetterAndSetter() {
        imiSearchRequest.setImiDocumentIdQuery(98765L);
        assertEquals(98765L, imiSearchRequest.getImiDocumentIdQuery());
    }

    @Test
    void testImiDocumentIdDisplayGetterAndSetter() {
        imiSearchRequest.setImiDocumentIdDisplay(true);
        assertTrue(imiSearchRequest.isImiDocumentIdDisplay());
    }

    // ========== PLAN DCN TESTS ==========

    @Test
    void testPlanDCNQueryGetterAndSetter() {
        imiSearchRequest.setPlanDCNQuery("DCN123456");
        assertEquals("DCN123456", imiSearchRequest.getPlanDCNQuery());
    }

    @Test
    void testPlanDCNSearchOperatorGetterAndSetter() {
        imiSearchRequest.setPlanDCNSearchOperator("LIKE");
        assertEquals("LIKE", imiSearchRequest.getPlanDCNSearchOperator());
    }

    @Test
    void testPlanDCNDisplayGetterAndSetter() {
        imiSearchRequest.setPlanDCNDisplay(true);
        assertTrue(imiSearchRequest.isPlanDCNDisplay());
    }

    // ========== DPK TESTS ==========

    @Test
    void testDpkQueryGetterAndSetter() {
        imiSearchRequest.setDpkQuery("DPK789");
        assertEquals("DPK789", imiSearchRequest.getDpkQuery());
    }

    @Test
    void testDpkSearchOperatorGetterAndSetter() {
        imiSearchRequest.setDpkSearchOperator("=");
        assertEquals("=", imiSearchRequest.getDpkSearchOperator());
    }

    @Test
    void testDpkDisplayGetterAndSetter() {
        imiSearchRequest.setDpkDisplay(true);
        assertTrue(imiSearchRequest.isDpkDisplay());
    }

    // ========== INITIAL PROCESS DCN TESTS ==========

    @Test
    void testInitialProcessDCNQueryGetterAndSetter() {
        imiSearchRequest.setInitialProcessDCNQuery("INIT_DCN123");
        assertEquals("INIT_DCN123", imiSearchRequest.getInitialProcessDCNQuery());
    }

    @Test
    void testInitialProcessDCNSearchOperatorGetterAndSetter() {
        imiSearchRequest.setInitialProcessDCNSearchOperator("LIKE");
        assertEquals("LIKE", imiSearchRequest.getInitialProcessDCNSearchOperator());
    }

    @Test
    void testInitialProcessDCNDisplayGetterAndSetter() {
        imiSearchRequest.setInitialProcessDCNDisplay(true);
        assertTrue(imiSearchRequest.isInitialProcessDCNDisplay());
    }

    // ========== FINAL PROCESS DCN TESTS ==========

    @Test
    void testFinalProcessDCNQueryGetterAndSetter() {
        imiSearchRequest.setFinalProcessDCNQuery("FINAL_DCN456");
        assertEquals("FINAL_DCN456", imiSearchRequest.getFinalProcessDCNQuery());
    }

    @Test
    void testFinalProcessDCNSearchOperatorGetterAndSetter() {
        imiSearchRequest.setFinalProcessDCNSearchOperator("LIKE");
        assertEquals("LIKE", imiSearchRequest.getFinalProcessDCNSearchOperator());
    }

    @Test
    void testFinalProcessDCNDisplayGetterAndSetter() {
        imiSearchRequest.setFinalProcessDCNDisplay(true);
        assertTrue(imiSearchRequest.isFinalProcessDCNDisplay());
    }

    // ========== DOCUMENT STATUS TESTS ==========

    @Test
    void testDocumentStatusCdQueryGetterAndSetter() {
        imiSearchRequest.setDocumentStatusCdQuery("S");
        assertEquals("S", imiSearchRequest.getDocumentStatusCdQuery());
    }

    @Test
    void testDocumentStatusCdSearchOperatorGetterAndSetter() {
        imiSearchRequest.setDocumentStatusCdSearchOperator("=");
        assertEquals("=", imiSearchRequest.getDocumentStatusCdSearchOperator());
    }

    @Test
    void testDocumentStatusCdDisplayGetterAndSetter() {
        imiSearchRequest.setDocumentStatusCdDisplay(true);
        assertTrue(imiSearchRequest.isDocumentStatusCdDisplay());
    }

    // ========== DOCUMENT REASON TESTS ==========

    @Test
    void testDocumentReasonCdQueryGetterAndSetter() {
        imiSearchRequest.setDocumentReasonCdQuery("REASON002");
        assertEquals("REASON002", imiSearchRequest.getDocumentReasonCdQuery());
    }

    @Test
    void testDocumentReasonCdSearchOperatorGetterAndSetter() {
        imiSearchRequest.setDocumentReasonCdSearchOperator("=");
        assertEquals("=", imiSearchRequest.getDocumentReasonCdSearchOperator());
    }

    @Test
    void testDocumentReasonCdDisplayGetterAndSetter() {
        imiSearchRequest.setDocumentReasonCdDisplay(true);
        assertTrue(imiSearchRequest.isDocumentReasonCdDisplay());
    }

    // ========== TIME UPDATE TESTS ==========

    @Test
    void testTimeUpdateQueryGetterAndSetter() {
        imiSearchRequest.setTimeUpdateQuery("2023-01-01 15:45:00");
        assertEquals("2023-01-01 15:45:00", imiSearchRequest.getTimeUpdateQuery());
    }

    @Test
    void testTimeUpdateSearchOperatorGetterAndSetter() {
        imiSearchRequest.setTimeUpdateSearchOperator(">=");
        assertEquals(">=", imiSearchRequest.getTimeUpdateSearchOperator());
    }

    @Test
    void testTimeUpdateDisplayGetterAndSetter() {
        imiSearchRequest.setTimeUpdateDisplay(true);
        assertTrue(imiSearchRequest.isTimeUpdateDisplay());
    }

    // ========== APPLICATION ID TESTS ==========

    @Test
    void testApplIdCdQueryGetterAndSetter() {
        List<Integer> applIds = Arrays.asList(1, 2, 3, 4, 5);
        imiSearchRequest.setApplIdCdQuery(applIds);
        assertEquals(applIds, imiSearchRequest.getApplIdCdQuery());
    }

    @Test
    void testApplIdCdQueryWithNull() {
        imiSearchRequest.setApplIdCdQuery(null);
        assertNull(imiSearchRequest.getApplIdCdQuery());
    }

    @Test
    void testApplIdCdQueryWithEmptyList() {
        imiSearchRequest.setApplIdCdQuery(Arrays.asList());
        assertNotNull(imiSearchRequest.getApplIdCdQuery());
        assertTrue(imiSearchRequest.getApplIdCdQuery().isEmpty());
    }

    @Test
    void testApplIdCdDisplayGetterAndSetter() {
        imiSearchRequest.setApplIdCdDisplay(true);
        assertTrue(imiSearchRequest.isApplIdCdDisplay());
    }

    // ========== CAPTURE ITEM TESTS ==========

    @Test
    void testCaptureItemIdQueryGetterAndSetter() {
        imiSearchRequest.setCaptureItemIdQuery("CAPTURE123");
        assertEquals("CAPTURE123", imiSearchRequest.getCaptureItemIdQuery());
    }

    @Test
    void testCaptureItemIdDisplayGetterAndSetter() {
        imiSearchRequest.setCaptureItemIdDisplay(true);
        assertTrue(imiSearchRequest.isCaptureItemIdDisplay());
    }

    // ========== PAGINATION TESTS ==========

    @Test
    void testResultSetPointerGetterAndSetter() {
        imiSearchRequest.setResultSetPointer(100L);
        assertEquals(100L, imiSearchRequest.getResultSetPointer());
    }

    @Test
    void testResultSetPointerWithZero() {
        imiSearchRequest.setResultSetPointer(0L);
        assertEquals(0L, imiSearchRequest.getResultSetPointer());
    }

    @Test
    void testResultSetPointerWithNegativeValue() {
        imiSearchRequest.setResultSetPointer(-1L);
        assertEquals(-1L, imiSearchRequest.getResultSetPointer());
    }

    @Test
    void testPaginationOnGetterAndSetter() {
        imiSearchRequest.setPaginationOn(false);
        assertFalse(imiSearchRequest.isPaginationOn());
        
        imiSearchRequest.setPaginationOn(true);
        assertTrue(imiSearchRequest.isPaginationOn());
    }

    @Test
    void testPaginationRowCountGetterAndSetter() {
        imiSearchRequest.setPaginationRowCount(500L);
        assertEquals(500L, imiSearchRequest.getPaginationRowCount());
    }

    @Test
    void testPaginationRowCountWithZero() {
        imiSearchRequest.setPaginationRowCount(0L);
        assertEquals(0L, imiSearchRequest.getPaginationRowCount());
    }

    @Test
    void testPaginationRowCountWithNegativeValue() {
        imiSearchRequest.setPaginationRowCount(-100L);
        assertEquals(-100L, imiSearchRequest.getPaginationRowCount());
    }

    @Test
    void testSearchByIdGetterAndSetter() {
        imiSearchRequest.setSearchById(true);
        assertTrue(imiSearchRequest.isSearchById());
        
        imiSearchRequest.setSearchById(false);
        assertFalse(imiSearchRequest.isSearchById());
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteSearchRequestSetup() {
        // Set all fields with sample data
        imiSearchRequest.setNaicCode("12345");
        imiSearchRequest.setTransmitTimestampFrom("2023-01-01 00:00:00");
        imiSearchRequest.setTransmitTimestampTo("2023-12-31 23:59:59");
        imiSearchRequest.setTransmitFileIdQuery(12345L);
        imiSearchRequest.setTransmitFileIdDisplay(true);
        imiSearchRequest.setTransmitFileNameQuery("test_file.txt");
        imiSearchRequest.setTransmitFileNameSearchOperator("LIKE");
        imiSearchRequest.setTransmitFileNameDisplay(true);
        imiSearchRequest.setTransmitFileStatusCdQuery("A");
        imiSearchRequest.setTransmitFileStatusCdSearchOperator("=");
        imiSearchRequest.setTransmitFileStatusCdDisplay(true);
        imiSearchRequest.setImiFileIdQuery(67890L);
        imiSearchRequest.setImiFileIdDisplay(true);
        imiSearchRequest.setPlanFileIdQuery("PLAN123");
        imiSearchRequest.setPlanFileIdSearchOperator("CONTAINS");
        imiSearchRequest.setPlanFileIdDisplay(true);
        imiSearchRequest.setProcessFileNameQuery("process_file.pdf");
        imiSearchRequest.setProcessFileNameSearchOperator("STARTS_WITH");
        imiSearchRequest.setProcessFileNameDisplay(true);
        imiSearchRequest.setProcessFileStatusCdQuery("C");
        imiSearchRequest.setProcessFileStatusCdSearchOperator("=");
        imiSearchRequest.setProcessFileStatusCdDisplay(true);
        imiSearchRequest.setProcessFileReasonCdQuery("REASON001");
        imiSearchRequest.setProcessFileReasonCdSearchOperator("=");
        imiSearchRequest.setProcessFileReasonCdDisplay(true);
        imiSearchRequest.setTimeAckQuery("2023-01-01 10:30:00");
        imiSearchRequest.setTimeAckSearchOperator(">=");
        imiSearchRequest.setTimeAckDisplay(true);
        imiSearchRequest.setImiDocumentIdQuery(98765L);
        imiSearchRequest.setImiDocumentIdDisplay(true);
        imiSearchRequest.setPlanDCNQuery("DCN123456");
        imiSearchRequest.setPlanDCNSearchOperator("LIKE");
        imiSearchRequest.setPlanDCNDisplay(true);
        imiSearchRequest.setDpkQuery("DPK789");
        imiSearchRequest.setDpkSearchOperator("=");
        imiSearchRequest.setDpkDisplay(true);
        imiSearchRequest.setInitialProcessDCNQuery("INIT_DCN123");
        imiSearchRequest.setInitialProcessDCNSearchOperator("LIKE");
        imiSearchRequest.setInitialProcessDCNDisplay(true);
        imiSearchRequest.setFinalProcessDCNQuery("FINAL_DCN456");
        imiSearchRequest.setFinalProcessDCNSearchOperator("LIKE");
        imiSearchRequest.setFinalProcessDCNDisplay(true);
        imiSearchRequest.setDocumentStatusCdQuery("S");
        imiSearchRequest.setDocumentStatusCdSearchOperator("=");
        imiSearchRequest.setDocumentStatusCdDisplay(true);
        imiSearchRequest.setDocumentReasonCdQuery("REASON002");
        imiSearchRequest.setDocumentReasonCdSearchOperator("=");
        imiSearchRequest.setDocumentReasonCdDisplay(true);
        imiSearchRequest.setTimeUpdateQuery("2023-01-01 15:45:00");
        imiSearchRequest.setTimeUpdateSearchOperator(">=");
        imiSearchRequest.setTimeUpdateDisplay(true);
        imiSearchRequest.setApplIdCdQuery(Arrays.asList(1, 2, 3, 4, 5));
        imiSearchRequest.setApplIdCdDisplay(true);
        imiSearchRequest.setCaptureItemIdQuery("CAPTURE123");
        imiSearchRequest.setCaptureItemIdDisplay(true);
        imiSearchRequest.setResultSetPointer(100L);
        imiSearchRequest.setPaginationOn(true);
        imiSearchRequest.setPaginationRowCount(500L);
        imiSearchRequest.setSearchById(true);

        // Verify all fields are set correctly
        assertEquals("12345", imiSearchRequest.getNaicCode());
        assertEquals("2023-01-01 00:00:00", imiSearchRequest.getTransmitTimestampFrom());
        assertEquals("2023-12-31 23:59:59", imiSearchRequest.getTransmitTimestampTo());
        assertEquals(12345L, imiSearchRequest.getTransmitFileIdQuery());
        assertTrue(imiSearchRequest.isTransmitFileIdDisplay());
        assertEquals("test_file.txt", imiSearchRequest.getTransmitFileNameQuery());
        assertEquals("LIKE", imiSearchRequest.getTransmitFileNameSearchOperator());
        assertTrue(imiSearchRequest.isTransmitFileNameDisplay());
        assertEquals("A", imiSearchRequest.getTransmitFileStatusCdQuery());
        assertEquals("=", imiSearchRequest.getTransmitFileStatusCdSearchOperator());
        assertTrue(imiSearchRequest.isTransmitFileStatusCdDisplay());
        assertEquals(67890L, imiSearchRequest.getImiFileIdQuery());
        assertTrue(imiSearchRequest.isImiFileIdDisplay());
        assertEquals("PLAN123", imiSearchRequest.getPlanFileIdQuery());
        assertEquals("CONTAINS", imiSearchRequest.getPlanFileIdSearchOperator());
        assertTrue(imiSearchRequest.isPlanFileIdDisplay());
        assertEquals("process_file.pdf", imiSearchRequest.getProcessFileNameQuery());
        assertEquals("STARTS_WITH", imiSearchRequest.getProcessFileNameSearchOperator());
        assertTrue(imiSearchRequest.isProcessFileNameDisplay());
        assertEquals("C", imiSearchRequest.getProcessFileStatusCdQuery());
        assertEquals("=", imiSearchRequest.getProcessFileStatusCdSearchOperator());
        assertTrue(imiSearchRequest.isProcessFileStatusCdDisplay());
        assertEquals("REASON001", imiSearchRequest.getProcessFileReasonCdQuery());
        assertEquals("=", imiSearchRequest.getProcessFileReasonCdSearchOperator());
        assertTrue(imiSearchRequest.isProcessFileReasonCdDisplay());
        assertEquals("2023-01-01 10:30:00", imiSearchRequest.getTimeAckQuery());
        assertEquals(">=", imiSearchRequest.getTimeAckSearchOperator());
        assertTrue(imiSearchRequest.isTimeAckDisplay());
        assertEquals(98765L, imiSearchRequest.getImiDocumentIdQuery());
        assertTrue(imiSearchRequest.isImiDocumentIdDisplay());
        assertEquals("DCN123456", imiSearchRequest.getPlanDCNQuery());
        assertEquals("LIKE", imiSearchRequest.getPlanDCNSearchOperator());
        assertTrue(imiSearchRequest.isPlanDCNDisplay());
        assertEquals("DPK789", imiSearchRequest.getDpkQuery());
        assertEquals("=", imiSearchRequest.getDpkSearchOperator());
        assertTrue(imiSearchRequest.isDpkDisplay());
        assertEquals("INIT_DCN123", imiSearchRequest.getInitialProcessDCNQuery());
        assertEquals("LIKE", imiSearchRequest.getInitialProcessDCNSearchOperator());
        assertTrue(imiSearchRequest.isInitialProcessDCNDisplay());
        assertEquals("FINAL_DCN456", imiSearchRequest.getFinalProcessDCNQuery());
        assertEquals("LIKE", imiSearchRequest.getFinalProcessDCNSearchOperator());
        assertTrue(imiSearchRequest.isFinalProcessDCNDisplay());
        assertEquals("S", imiSearchRequest.getDocumentStatusCdQuery());
        assertEquals("=", imiSearchRequest.getDocumentStatusCdSearchOperator());
        assertTrue(imiSearchRequest.isDocumentStatusCdDisplay());
        assertEquals("REASON002", imiSearchRequest.getDocumentReasonCdQuery());
        assertEquals("=", imiSearchRequest.getDocumentReasonCdSearchOperator());
        assertTrue(imiSearchRequest.isDocumentReasonCdDisplay());
        assertEquals("2023-01-01 15:45:00", imiSearchRequest.getTimeUpdateQuery());
        assertEquals(">=", imiSearchRequest.getTimeUpdateSearchOperator());
        assertTrue(imiSearchRequest.isTimeUpdateDisplay());
        assertEquals(Arrays.asList(1, 2, 3, 4, 5), imiSearchRequest.getApplIdCdQuery());
        assertTrue(imiSearchRequest.isApplIdCdDisplay());
        assertEquals("CAPTURE123", imiSearchRequest.getCaptureItemIdQuery());
        assertTrue(imiSearchRequest.isCaptureItemIdDisplay());
        assertEquals(100L, imiSearchRequest.getResultSetPointer());
        assertTrue(imiSearchRequest.isPaginationOn());
        assertEquals(500L, imiSearchRequest.getPaginationRowCount());
        assertTrue(imiSearchRequest.isSearchById());
    }

    // ========== TO STRING TESTS ==========

    @Test
    void testToStringWithAllFields() {
        // Set some fields
        imiSearchRequest.setNaicCode("12345");
        imiSearchRequest.setTransmitFileIdQuery(12345L);
        imiSearchRequest.setTransmitFileIdDisplay(true);
        imiSearchRequest.setTransmitFileNameQuery("test_file.txt");
        imiSearchRequest.setTransmitFileNameDisplay(true);
        imiSearchRequest.setTransmitFileStatusCdQuery("A");
        imiSearchRequest.setTransmitFileStatusCdDisplay(true);
        imiSearchRequest.setImiFileIdQuery(67890L);
        imiSearchRequest.setImiFileIdDisplay(true);
        imiSearchRequest.setPlanFileIdQuery("PLAN123");
        imiSearchRequest.setPlanFileIdDisplay(true);
        imiSearchRequest.setProcessFileNameQuery("process_file.pdf");
        imiSearchRequest.setProcessFileNameDisplay(true);
        imiSearchRequest.setProcessFileStatusCdQuery("C");
        imiSearchRequest.setProcessFileStatusCdDisplay(true);
        imiSearchRequest.setProcessFileReasonCdQuery("REASON001");
        imiSearchRequest.setProcessFileReasonCdDisplay(true);
        imiSearchRequest.setTimeAckQuery("2023-01-01 10:30:00");
        imiSearchRequest.setTimeAckDisplay(true);
        imiSearchRequest.setImiDocumentIdQuery(98765L);
        imiSearchRequest.setImiDocumentIdDisplay(true);
        imiSearchRequest.setPlanDCNQuery("DCN123456");
        imiSearchRequest.setPlanDCNDisplay(true);
        imiSearchRequest.setDpkQuery("DPK789");
        imiSearchRequest.setDpkDisplay(true);
        imiSearchRequest.setInitialProcessDCNQuery("INIT_DCN123");
        imiSearchRequest.setInitialProcessDCNDisplay(true);
        imiSearchRequest.setFinalProcessDCNQuery("FINAL_DCN456");
        imiSearchRequest.setFinalProcessDCNDisplay(true);
        imiSearchRequest.setDocumentStatusCdQuery("S");
        imiSearchRequest.setDocumentStatusCdDisplay(true);
        imiSearchRequest.setDocumentReasonCdQuery("REASON002");
        imiSearchRequest.setDocumentReasonCdDisplay(true);
        imiSearchRequest.setTimeUpdateQuery("2023-01-01 15:45:00");
        imiSearchRequest.setTimeUpdateDisplay(true);
        imiSearchRequest.setApplIdCdQuery(Arrays.asList(1, 2, 3));
        imiSearchRequest.setApplIdCdDisplay(true);
        imiSearchRequest.setCaptureItemIdQuery("CAPTURE123");
        imiSearchRequest.setCaptureItemIdDisplay(true);
        imiSearchRequest.setResultSetPointer(100L);
        imiSearchRequest.setPaginationOn(true);
        imiSearchRequest.setPaginationRowCount(500L);
        imiSearchRequest.setSearchById(true);

        String result = imiSearchRequest.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMISearchRequest"));
        assertTrue(result.contains("naicCode=12345"));
        assertTrue(result.contains("transmitFileIdQuery=12345"));
        assertTrue(result.contains("transmitFileIdDisplay=true"));
        assertTrue(result.contains("transmitFileNameQuery=test_file.txt"));
        assertTrue(result.contains("transmitFileNameDisplay=true"));
        assertTrue(result.contains("transmitFileStatusCdQuery=A"));
        assertTrue(result.contains("transmitFileStatusCdDisplay=true"));
        assertTrue(result.contains("imiFileIdQuery=67890"));
        assertTrue(result.contains("imiFileIdDisplay=true"));
        assertTrue(result.contains("planFileIdQuery=PLAN123"));
        assertTrue(result.contains("planFileIdDisplay=true"));
        assertTrue(result.contains("processFileNameQuery=process_file.pdf"));
        assertTrue(result.contains("processFileNameDisplay=true"));
        assertTrue(result.contains("processFileStatusCdQuery=C"));
        assertTrue(result.contains("processFileStatusCdDisplay=true"));
        assertTrue(result.contains("processFileReasonCdQuery=REASON001"));
        assertTrue(result.contains("processFileReasonCdDisplay=true"));
        assertTrue(result.contains("timeAckQuery=2023-01-01 10:30:00"));
        assertTrue(result.contains("timeAckDisplay=true"));
        assertTrue(result.contains("imiDocumentIdQuery=98765"));
        assertTrue(result.contains("imiDocumentIdDisplay=true"));
        assertTrue(result.contains("planDCNQuery=DCN123456"));
        assertTrue(result.contains("planDCNDisplay=true"));
        assertTrue(result.contains("dpkQuery=DPK789"));
        assertTrue(result.contains("dpkDisplay=true"));
        assertTrue(result.contains("initialProcessDCNQuery=INIT_DCN123"));
        assertTrue(result.contains("initialProcessDCNDisplay=true"));
        assertTrue(result.contains("finalProcessDCNQuery=FINAL_DCN456"));
        assertTrue(result.contains("finalProcessDCNDisplay=true"));
        assertTrue(result.contains("documentStatusCdQuery=S"));
        assertTrue(result.contains("documentStatusCdDisplay=true"));
        assertTrue(result.contains("documentReasonCdQuery=REASON002"));
        assertTrue(result.contains("documentReasonCdDisplay=true"));
        assertTrue(result.contains("timeUpdateQuery=2023-01-01 15:45:00"));
        assertTrue(result.contains("timeUpdateDisplay=true"));
        assertTrue(result.contains("applIdCdQuery=[1, 2, 3]"));
        assertTrue(result.contains("applIdCdDisplay=true"));
        assertTrue(result.contains("captureItemIdQuery=CAPTURE123"));
        assertTrue(result.contains("captureItemIdDisplay=true"));
        assertTrue(result.contains("resultSetPointer=100"));
        assertTrue(result.contains("paginationOn=true"));
        assertTrue(result.contains("paginationRowCount=500"));
        assertTrue(result.contains("searchById=true"));
    }

    @Test
    void testToStringWithDefaultValues() {
        String result = imiSearchRequest.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMISearchRequest"));
        assertTrue(result.contains("resultSetPointer=0"));
        assertTrue(result.contains("paginationOn=true"));
        assertTrue(result.contains("paginationRowCount=250"));
        assertTrue(result.contains("searchById=false"));
    }

    // ========== EDGE CASE TESTS ==========

    @Test
    void testWithSpecialCharacters() {
        imiSearchRequest.setNaicCode("12345!@#$%");
        imiSearchRequest.setTransmitFileNameQuery("file with spaces & special chars.txt");
        imiSearchRequest.setPlanFileIdQuery("PLAN-123_456");
        
        assertEquals("12345!@#$%", imiSearchRequest.getNaicCode());
        assertEquals("file with spaces & special chars.txt", imiSearchRequest.getTransmitFileNameQuery());
        assertEquals("PLAN-123_456", imiSearchRequest.getPlanFileIdQuery());
    }

    @Test
    void testWithEmptyStrings() {
        imiSearchRequest.setNaicCode("");
        imiSearchRequest.setTransmitFileNameQuery("");
        imiSearchRequest.setPlanFileIdQuery("");
        
        assertEquals("", imiSearchRequest.getNaicCode());
        assertEquals("", imiSearchRequest.getTransmitFileNameQuery());
        assertEquals("", imiSearchRequest.getPlanFileIdQuery());
    }

    @Test
    void testWithNullValues() {
        imiSearchRequest.setNaicCode(null);
        imiSearchRequest.setTransmitFileNameQuery(null);
        imiSearchRequest.setPlanFileIdQuery(null);
        imiSearchRequest.setApplIdCdQuery(null);
        
        assertNull(imiSearchRequest.getNaicCode());
        assertNull(imiSearchRequest.getTransmitFileNameQuery());
        assertNull(imiSearchRequest.getPlanFileIdQuery());
        assertNull(imiSearchRequest.getApplIdCdQuery());
    }

    @Test
    void testWithLargeNumbers() {
        imiSearchRequest.setTransmitFileIdQuery(Long.MAX_VALUE);
        imiSearchRequest.setImiFileIdQuery(Long.MAX_VALUE);
        imiSearchRequest.setImiDocumentIdQuery(Long.MAX_VALUE);
        imiSearchRequest.setResultSetPointer(Long.MAX_VALUE);
        imiSearchRequest.setPaginationRowCount(Long.MAX_VALUE);
        
        assertEquals(Long.MAX_VALUE, imiSearchRequest.getTransmitFileIdQuery());
        assertEquals(Long.MAX_VALUE, imiSearchRequest.getImiFileIdQuery());
        assertEquals(Long.MAX_VALUE, imiSearchRequest.getImiDocumentIdQuery());
        assertEquals(Long.MAX_VALUE, imiSearchRequest.getResultSetPointer());
        assertEquals(Long.MAX_VALUE, imiSearchRequest.getPaginationRowCount());
    }

    @Test
    void testWithNegativeNumbers() {
        imiSearchRequest.setTransmitFileIdQuery(-1L);
        imiSearchRequest.setImiFileIdQuery(-1L);
        imiSearchRequest.setImiDocumentIdQuery(-1L);
        imiSearchRequest.setResultSetPointer(-1L);
        imiSearchRequest.setPaginationRowCount(-1L);
        
        assertEquals(-1L, imiSearchRequest.getTransmitFileIdQuery());
        assertEquals(-1L, imiSearchRequest.getImiFileIdQuery());
        assertEquals(-1L, imiSearchRequest.getImiDocumentIdQuery());
        assertEquals(-1L, imiSearchRequest.getResultSetPointer());
        assertEquals(-1L, imiSearchRequest.getPaginationRowCount());
    }
}
