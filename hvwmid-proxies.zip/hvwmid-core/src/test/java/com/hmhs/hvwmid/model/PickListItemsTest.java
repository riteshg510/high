package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class PickListItemsTest {

    private PickListItems pickListItems;

    // Setup method to initialize PickListItems object before each test
    @BeforeEach
    void setUp() {
        pickListItems = new PickListItems();
    }

    @Test
    void testGetAndSetDisplayName() {
        // Test set and get for 'displayName' field
        String testDisplayName = "Sample Display Name";
        pickListItems.setDisplayName(testDisplayName);
        assertEquals(testDisplayName, pickListItems.getDisplayName(), "The displayName should match the set value");
    }

    @Test
    void testGetAndSetId() {
        // Test set and get for 'id' field
        Long testId = 123L;
        pickListItems.setId(testId);
        assertEquals(testId, pickListItems.getId(), "The id should match the set value");
    }

    @Test
    void testGetAndSetKey() {
        // Test set and get for 'key' field
        String testKey = "key123";
        pickListItems.setKey(testKey);
        assertEquals(testKey, pickListItems.getKey(), "The key should match the set value");
    }

    @Test
    void testGetAndSetParentKey() {
        // Test set and get for 'parentKey' field
        String testParentKey = "parentKey123";
        pickListItems.setParentKey(testParentKey);
        assertEquals(testParentKey, pickListItems.getParentKey(), "The parentKey should match the set value");
    }

    @Test
    void testDefaultValues() {
        // Verify default values for the class fields
        assertNull(pickListItems.getDisplayName(), "The default displayName should be null");
        assertNull(pickListItems.getId(), "The default id should be null");
        assertNull(pickListItems.getKey(), "The default key should be null");
        assertNull(pickListItems.getParentKey(), "The default parentKey should be null");
    }
}
