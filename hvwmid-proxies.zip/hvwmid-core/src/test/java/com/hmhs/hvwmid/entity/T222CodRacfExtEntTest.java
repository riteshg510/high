package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

class T222CodRacfExtEntTest {

    @Test
    void testNoArgsConstructorAndSetters() {
        Instant now = Instant.now();

        T222CodRacfExtEnt entity = new T222CodRacfExtEnt();
        entity.setRacfClass("CLASS10");
        entity.setRacfEntity("ENTITY-XYZ");
        entity.setRacfUserId("USR12345");
        entity.setRacfUserName("John Doe");
        entity.setTimeupdate(now);

        assertEquals("CLASS10", entity.getRacfClass());
        assertEquals("ENTITY-XYZ", entity.getRacfEntity());
        assertEquals("USR12345", entity.getRacfUserId());
        assertEquals("John Doe", entity.getRacfUserName());
        assertEquals(now, entity.getTimeupdate());
    }

    @Test
    void testAllArgsConstructor() {
        Instant now = Instant.now();

        T222CodRacfExtEnt entity = new T222CodRacfExtEnt(
                "CL01", "ENT01", "USR01", "Jane Smith", now
        );

        assertEquals("CL01", entity.getRacfClass());
        assertEquals("ENT01", entity.getRacfEntity());
        assertEquals("USR01", entity.getRacfUserId());
        assertEquals("Jane Smith", entity.getRacfUserName());
        assertEquals(now, entity.getTimeupdate());
    }

    @Test
    void testFieldLengthConstraints() {
        T222CodRacfExtEnt entity = new T222CodRacfExtEnt();
        entity.setRacfClass("1234567890");       // exactly 10
        entity.setRacfEntity("12345678901234567890123456789012345678901234567890"); // 50
        entity.setRacfUserId("12345678");         // 8
        entity.setRacfUserName("A".repeat(40));   // 40

        assertEquals(10, entity.getRacfClass().length());
        assertEquals(50, entity.getRacfEntity().length());
        assertEquals(8, entity.getRacfUserId().length());
        assertEquals(40, entity.getRacfUserName().length());
    }
}
