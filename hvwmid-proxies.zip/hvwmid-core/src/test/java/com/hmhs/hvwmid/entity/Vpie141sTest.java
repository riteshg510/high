package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class Vpie141sTest {

    @Test
    void testDefaultConstructorAndSetters() {
        Vpie141s entity = new Vpie141s();

        LocalDateTime now = LocalDateTime.now();

        entity.setAcf2Resource("SEC123");
        entity.setAcf2String("ACF2_STRING_VALUE");
        entity.setApplication("CMOD_APP");
        entity.setRoleDescription("Admin Role");
        entity.setDateModified(now);
        entity.setCustodian("CUST001");
        entity.setGeneralText("General Information");

        assertEquals("SEC123", entity.getAcf2Resource());
        assertEquals("ACF2_STRING_VALUE", entity.getAcf2String());
        assertEquals("CMOD_APP", entity.getApplication());
        assertEquals("Admin Role", entity.getRoleDescription());
        assertEquals(now, entity.getDateModified());
        assertEquals("CUST001", entity.getCustodian());
        assertEquals("General Information", entity.getGeneralText());
    }

    @Test
    void testParameterizedConstructor() {
        LocalDateTime modifiedDate = LocalDateTime.of(2023, 7, 1, 12, 30);

        Vpie141s entity = new Vpie141s(
                "RES001",
                "ACF2_STRING_01",
                "APP01",
                "User Role",
                modifiedDate
        );

        assertEquals("RES001", entity.getAcf2Resource());
        assertEquals("ACF2_STRING_01", entity.getAcf2String());
        assertEquals("APP01", entity.getApplication());
        assertEquals("User Role", entity.getRoleDescription());
        assertEquals(modifiedDate, entity.getDateModified());

        // Check default nulls for other fields
        assertNull(entity.getCustodian());
        assertNull(entity.getGeneralText());
    }
}
