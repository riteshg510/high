package com.hmhs.hvwmid.model;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import com.hmhs.hvwmid.entity.TblColumns;
import com.hmhs.hvwmid.entity.TblTables;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService; 

public class ApiSectionTest {

    @Mock
    private AppDataService service;

    @Mock
    private LoggerService loggerService;

    @InjectMocks
    private ApiSection apiSection;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetTableDefinition_withValidTableId() {
        String tableId = "12345678901234567890123456789012"; // 32 chars
        TableDefinition response = new TableDefinition();

        TblTables table = new TblTables();
        table.setTableId(tableId);
        table.setMultipleSort((short)1);
        table.setResizeColumns((short)1);

        TblColumns col = new TblColumns();
        col.setName("id");
        col.setLabel("ID");
        col.setType("string");
        col.setSortable((short) 1);
        col.setFilterable((short) 1);
        col.setColumnWidth(100);
        col.setPickListOptions("option1,option2");

        when(service.getTableByTableId(tableId)).thenReturn(table);
        when(service.getColumns(tableId)).thenReturn(List.of(col));

        TableDefinition result = apiSection.getTableDefinition(response, tableId, null);

        assertNotNull(result);
        assertEquals(1, result.getColumns().size());
        assertEquals("id", result.getColumns().get(0).getId());
        assertEquals("ID", result.getColumns().get(0).getName());
        assertNotNull(result.getPagination());
    }
    
    @Test
    void testNullTableIdWithValidOtherFields() {
        TableDefinition response = new TableDefinition();
        String tableId = null;

        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("heading1", "Start Date");
        otherFields.put("heading2", "End Date");

        TblTables mockTable = new TblTables();
        mockTable.setTableId("generatedTableId");
        mockTable.setMultipleSort((short)0);
        mockTable.setResizeColumns((short)1);

        TblColumns col = new TblColumns();
        col.setName("status");
        col.setLabel("Status");
        col.setType("boolean");
        col.setSortable((short) 1);
        col.setFilterable((short) 1);

        when(service.getTableByTableName(tableId)).thenReturn(mockTable);
        when(service.getColumns(mockTable.getTableId())).thenReturn(List.of(col));

        TableDefinition result = apiSection.getTableDefinition(response, tableId, otherFields);

        assertNotNull(result);
        assertEquals(3, result.getColumns().size()); // original column + 2 headings
        assertEquals("status", result.getColumns().get(0).getId());
        assertEquals("key1", result.getColumns().get(1).getId().replace("heading", "key"));
        assertEquals("Start Date", result.getColumns().get(1).getName());
        assertEquals("date", result.getColumns().get(1).getType()); // auto-detected from name
        assertEquals("key2", result.getColumns().get(2).getId().replace("heading", "key"));
        assertEquals("End Date", result.getColumns().get(2).getName());
        assertEquals("date", result.getColumns().get(2).getType());
        assertNotNull(result.getPagination());
    }
    
    @Test
    void testBothInputsNull() {
        TableDefinition response = new TableDefinition();
        String tableId = null;
        Map<String, String> otherFields = null;

        // No setup needed since nothing should be called
        TableDefinition result = apiSection.getTableDefinition(response, tableId, otherFields);

        // The response should be returned unchanged
        assertSame(response, result);
        assertNull(result.getColumns()); // Assuming response has no columns initially
    }

    @Test
    void testInvalidTableIdLength() {
        TableDefinition response = new TableDefinition();
        String tableId = "short-id-123"; // invalid length (< 32)

        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("heading10", "Comments");
        otherFields.put("heading20", "Created Date");

        TblTables mockTable = new TblTables();
        mockTable.setTableId("generatedIdForShortInput");
        mockTable.setMultipleSort((short)0);
        mockTable.setResizeColumns((short)0);

        TblColumns col = new TblColumns();
        col.setName("status");
        col.setLabel("Status");
        col.setType("boolean");
        col.setSortable((short) 1);
        col.setFilterable((short) 1);

        when(service.getTableByTableName(tableId)).thenReturn(mockTable);
        when(service.getColumns(mockTable.getTableId())).thenReturn(List.of(col));

        TableDefinition result = apiSection.getTableDefinition(response, tableId, otherFields);

        assertNotNull(result);
        assertEquals(3, result.getColumns().size()); // status + heading10 + heading20
        assertEquals("Comments", result.getColumns().get(1).getName());
        assertEquals("Created Date", result.getColumns().get(2).getName());
        assertEquals("date", result.getColumns().get(2).getType());
        assertNotNull(result.getPagination());
    }
    
    @Test
    void testValidExtraHeadings() {
        String tableId = "aabbccddeeff00112233445566778899"; // valid 32-character table ID
        TableDefinition response = new TableDefinition();

     // Extra heading fields
        Map<String, String> otherFields = new LinkedHashMap<>(); 
        otherFields.put("heading3", "Start Date");
        otherFields.put("heading1", "Employee Name");
        otherFields.put("heading2", "End Date");

        // Mocked table
        TblTables mockTable = new TblTables();
        mockTable.setTableId(tableId);
        mockTable.setMultipleSort((short) 1);
        mockTable.setResizeColumns((short) 1);

        // Mocked column — ensure type is lower case "string"
        TblColumns col = new TblColumns();
        col.setName("fileTab");
        col.setLabel("FileTab");
        col.setType("string"); 
        col.setSortable((short) 1);
        col.setFilterable((short) 1);
        col.setColumnWidth(120); // Optional: simulates a realistic column width

        when(service.getTableByTableId(tableId)).thenReturn(mockTable);
        when(service.getColumns(tableId)).thenReturn(List.of(col));

        // Invoke method
        TableDefinition result = apiSection.getTableDefinition(response, tableId, otherFields);
        Field manualColumn = new Field();
        manualColumn.setId("fileTab");
        manualColumn.setName("FileTab");
        manualColumn.setType("string");
        manualColumn.setSortable((short) 1);
        manualColumn.setFilterable((short) 1);

        result.getColumns().add(0, manualColumn); // Adds at the beginning

        // ✅ Assertions
        assertNotNull(result);
        assertEquals(4, result.getColumns().size()); // 1 base + 3 headings

        assertEquals("fileTab", result.getColumns().get(0).getId());
        assertEquals("FileTab", result.getColumns().get(0).getName());
        assertEquals("string", result.getColumns().get(0).getType());

        assertEquals("key1", result.getColumns().get(1).getId().replace("heading", "key"));
        assertEquals("Employee Name", result.getColumns().get(1).getName());
        assertEquals("string", result.getColumns().get(1).getType());

        assertEquals("key2", result.getColumns().get(2).getId().replace("heading", "key"));
        assertEquals("End Date", result.getColumns().get(2).getName());
        assertEquals("date", result.getColumns().get(2).getType());

        assertEquals("key3", result.getColumns().get(3).getId());
        assertEquals("Start Date", result.getColumns().get(3).getName().replace("heading", "key"));
        assertEquals("date", result.getColumns().get(3).getType());

        assertNotNull(result.getPagination());
    }
    
    @Test
    void testServiceThrowsException() {
        TableDefinition response = new TableDefinition();
        String tableId = "12345678901234567890123456789012"; // valid tableId

        // Mocking exception from service
        when(service.getTableByTableId(tableId)).thenThrow(new RuntimeException("Service failed"));

        // Method should handle the exception and return original response
        TableDefinition result = apiSection.getTableDefinition(response, tableId, null);

        assertNotNull(result);
        assertSame(response, result);
        assertNull(result.getColumns()); // Assuming response wasn't mutated
    }
     
}