package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblImgObject;
import com.hmhs.hvwmid.entity.TblImgToken;
import com.hmhs.hvwmid.repository.ImageCachingRepository;
import com.hmhs.hvwmid.repository.ImgTokenRepository;
import com.hmhs.hvwmid.repository.TblImgObjectRepository;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.io.*;
import java.sql.SQLException;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest(properties = {"db-logging-env=testEnv"}, classes = ImageCachingService.class)
class ImageCachingServiceTest {

    @Autowired
    ImageCachingService service;

    @MockBean
    ImageCachingRepository imageCachingRepository;

    @MockBean
    ImgTokenRepository tokenRepo;

    @MockBean
    TblImgObjectRepository objectRepo;

    @MockBean
    TransactionTemplate txTemplate;

    @MockBean
    HvwDataRefresh hvwDataRefresh;

    @MockBean
    RestClientUtil restClientUtil;

    @MockBean
    JdbcTemplate jdbcTemplate;

    @MockBean
    GenericUDFService seqGen;

    @BeforeEach
    void setup() {
        service.setDbLoggingEnv("testEnv");

        service.setDbLoggingEnv("testEnv");


        when(hvwDataRefresh.getParmDataByKeyByCmodbase(anyString(), anyString()))
                .thenAnswer(invocation -> invocation.getArgument(1));

        try {
            var field = ImageCachingService.class.getDeclaredField("seqGen");
            field.setAccessible(true);
            field.set(service, seqGen);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testGetDocumentToken_found() {
        TblImgToken token = new TblImgToken();
        token.setRequestId(5);
        when(tokenRepo.findByRequestId(5)).thenReturn(java.util.Optional.of(token));

        TblImgToken result = service.getDocumentToken(5);
        assertEquals(token, result);
    }

    @Test
    void testGetDocumentToken_notFound_throws() {
        when(tokenRepo.findByRequestId(5)).thenReturn(java.util.Optional.empty());

        SecurityException ex = assertThrows(SecurityException.class, () -> service.getDocumentToken(5));
        assertEquals("Not found", ex.getMessage());
    }

    @Test
    void testStreamDocument_success() throws Exception {

        int requestId = 123;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        doAnswer(invocation -> {
            OutputStream os = invocation.getArgument(1);
            os.write("test data".getBytes());
            return null;
        }).when(imageCachingRepository).streamSegmentsByRequestId(eq(requestId), any(OutputStream.class));

        // Act
        StreamingResponseBody responseBody = service.streamDocument(requestId);
        responseBody.writeTo(outputStream);

        // Assert
        String result = outputStream.toString();
        assert result.equals("test data");
        verify(imageCachingRepository, times(1)).streamSegmentsByRequestId(eq(requestId), any(OutputStream.class));
    }


    @Test
    void testStreamDocument_sqlExceptionWrappedAsIOException() throws Exception {
        int requestId = 42;

        doThrow(new SQLException("DB fail")).when(imageCachingRepository)
                .streamSegmentsByRequestId(eq(requestId), any(OutputStream.class));

        StreamingResponseBody responseBody = service.streamDocument(requestId);

        OutputStream outputStream = mock(OutputStream.class);

        IOException exception = assertThrows(IOException.class, () -> {
            responseBody.writeTo(outputStream);
        });

        assertEquals("Database error while streaming document", exception.getMessage());
        assertTrue(exception.getCause() instanceof SQLException);
        assertEquals("DB fail", exception.getCause().getMessage());
    }


    @Test
    void testSaveToken() {
        when(seqGen.generateRequestId("testEnv")).thenReturn(12345);
        TblImgToken savedToken = new TblImgToken();
        when(tokenRepo.save(any())).thenReturn(savedToken);

        TblImgToken result = service.saveToken("userX", "secToken", "docToken");

        assertNotNull(result);
        verify(tokenRepo).save(any(TblImgToken.class));

        ArgumentCaptor<TblImgToken> captor = ArgumentCaptor.forClass(TblImgToken.class);
        verify(tokenRepo).save(captor.capture());

        TblImgToken captured = captor.getValue();
        assertEquals(12345, captured.getRequestId());
        assertEquals("userX", captured.getUserId());
        assertEquals("docToken", captured.getDocumentToken());
        assertEquals("secToken", captured.getSecurityToken());
        assertEquals("", captured.getDocumentType());
        assertEquals(1, captured.getDocumentPages());
        assertNotNull(captured.getTimeCreate());
    }

    @Test
    void testCacheDocument() throws IOException {
        when(seqGen.generateRequestId("testEnv")).thenReturn(777);
        when(hvwDataRefresh.getParmDataByKeyByCmodbase(anyString(), anyString())).thenReturn("testEnv");

        byte[] data = "HelloWorld".getBytes();
        InputStream input = new ByteArrayInputStream(data);

        int requestId = service.cacheDocument(input, "user1", "docTok", "secTok");

        assertEquals(777, requestId);

        // tokenRepo.save se mora pozvati jednom za token
        verify(tokenRepo, times(1)).save(any(TblImgToken.class));

        // objectRepo.save mora biti pozvano bar jednom jer ulazni stream ima podatke
        verify(objectRepo, atLeastOnce()).save(any(TblImgObject.class));
    }
}
