package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMISearchData POJO
 * Tests all getters, setters, constructors, and nested classes
 * 
 */
class IMISearchDataTest {

    private IMISearchData imiSearchData;
    private List<IMISearchResults> mockSearchResults;
    private Map<String, String> mockNaicMap;

    @BeforeEach
    void setUp() {
        imiSearchData = new IMISearchData();
        mockSearchResults = List.of(new IMISearchResults());
        mockNaicMap = new HashMap<>();
        mockNaicMap.put("12345", "Test NAIC");
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        IMISearchData data = new IMISearchData();
        assertNotNull(data);
        assertNull(data.getSearchResultsList());
        assertNull(data.getBaseMessage());
        assertNull(data.getServiceMessage());
        assertNull(data.getNaicMap());
    }

    // ========== GETTER AND SETTER TESTS ==========

    @Test
    void testSearchResultsListGetterAndSetter() {
        // Test setter
        imiSearchData.setSearchResultsList(mockSearchResults);
        
        // Test getter
        List<IMISearchResults> result = imiSearchData.getSearchResultsList();
        assertNotNull(result);
        assertEquals(mockSearchResults, result);
        assertEquals(1, result.size());
    }

    @Test
    void testSearchResultsListWithNull() {
        imiSearchData.setSearchResultsList(null);
        assertNull(imiSearchData.getSearchResultsList());
    }

    @Test
    void testSearchResultsListWithEmptyList() {
        imiSearchData.setSearchResultsList(List.of());
        assertNotNull(imiSearchData.getSearchResultsList());
        assertTrue(imiSearchData.getSearchResultsList().isEmpty());
    }

    @Test
    void testBaseMessageGetterAndSetter() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Success");
        
        imiSearchData.setBaseMessage(baseMessage);
        
        IMISearchData.BaseMessage result = imiSearchData.getBaseMessage();
        assertNotNull(result);
        assertEquals(baseMessage, result);
        assertEquals("200", result.getReturnCode());
        assertEquals("Success", result.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithNull() {
        imiSearchData.setBaseMessage(null);
        assertNull(imiSearchData.getBaseMessage());
    }

    @Test
    void testServiceMessageGetterAndSetter() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("Operation successful");
        
        imiSearchData.setServiceMessage(serviceMessage);
        
        IMISearchData.ServiceMessage result = imiSearchData.getServiceMessage();
        assertNotNull(result);
        assertEquals(serviceMessage, result);
        assertEquals(200, result.getReturnCode());
        assertEquals("Operation successful", result.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithNull() {
        imiSearchData.setServiceMessage(null);
        assertNull(imiSearchData.getServiceMessage());
    }

    @Test
    void testNaicMapGetterAndSetter() {
        imiSearchData.setNaicMap(mockNaicMap);
        
        Map<String, String> result = imiSearchData.getNaicMap();
        assertNotNull(result);
        assertEquals(mockNaicMap, result);
        assertEquals("Test NAIC", result.get("12345"));
    }

    @Test
    void testNaicMapWithNull() {
        imiSearchData.setNaicMap(null);
        assertNull(imiSearchData.getNaicMap());
    }

    @Test
    void testNaicMapWithEmptyMap() {
        Map<String, String> emptyMap = new HashMap<>();
        imiSearchData.setNaicMap(emptyMap);
        
        Map<String, String> result = imiSearchData.getNaicMap();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ========== NESTED CLASS TESTS - BaseMessage ==========

    @Test
    void testBaseMessageDefaultConstructor() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        assertNotNull(baseMessage);
        assertNull(baseMessage.getReturnCode());
        assertNull(baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeGetterAndSetter() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        
        // Test setter
        baseMessage.setReturnCode("404");
        
        // Test getter
        assertEquals("404", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithNull() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCode(null);
        assertNull(baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithEmptyString() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCode("");
        assertEquals("", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionGetterAndSetter() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        
        // Test setter
        baseMessage.setReturnCodeDescription("Not Found");
        
        // Test getter
        assertEquals("Not Found", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithNull() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCodeDescription(null);
        assertNull(baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithEmptyString() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCodeDescription("");
        assertEquals("", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithAllFields() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCode("500");
        baseMessage.setReturnCodeDescription("Internal Server Error");
        
        assertEquals("500", baseMessage.getReturnCode());
        assertEquals("Internal Server Error", baseMessage.getReturnCodeDescription());
    }

    // ========== NESTED CLASS TESTS - ServiceMessage ==========

    @Test
    void testServiceMessageDefaultConstructor() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        assertNotNull(serviceMessage);
        assertNull(serviceMessage.getReturnCode());
        assertNull(serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeGetterAndSetter() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        
        // Test setter
        serviceMessage.setReturnCode(201);
        
        // Test getter
        assertEquals(201, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithNull() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(null);
        assertNull(serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithZero() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(0);
        assertEquals(0, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeWithNegativeValue() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(-1);
        assertEquals(-1, serviceMessage.getReturnCode());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionGetterAndSetter() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        
        // Test setter
        serviceMessage.setReturnCodeDescription("Created successfully");
        
        // Test getter
        assertEquals("Created successfully", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionWithNull() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCodeDescription(null);
        assertNull(serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageReturnCodeDescriptionWithEmptyString() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCodeDescription("");
        assertEquals("", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithAllFields() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(400);
        serviceMessage.setReturnCodeDescription("Bad Request");
        
        assertEquals(400, serviceMessage.getReturnCode());
        assertEquals("Bad Request", serviceMessage.getReturnCodeDescription());
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteIMISearchDataSetup() {
        // Setup search results
        IMISearchResults searchResult = new IMISearchResults();
        searchResult.setNaicCode("12345");
        searchResult.setTransmitTimeStamp("2023-01-01 10:00:00");
        imiSearchData.setSearchResultsList(List.of(searchResult));

        // Setup base message
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Success");
        imiSearchData.setBaseMessage(baseMessage);

        // Setup service message
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(200);
        serviceMessage.setReturnCodeDescription("Operation completed successfully");
        imiSearchData.setServiceMessage(serviceMessage);

        // Setup NAIC map
        Map<String, String> naicMap = new HashMap<>();
        naicMap.put("12345", "Test Insurance Company");
        naicMap.put("67890", "Another Insurance Company");
        imiSearchData.setNaicMap(naicMap);

        // Verify all fields are set correctly
        assertNotNull(imiSearchData.getSearchResultsList());
        assertEquals(1, imiSearchData.getSearchResultsList().size());
        assertEquals("12345", imiSearchData.getSearchResultsList().get(0).getNaicCode());

        assertNotNull(imiSearchData.getBaseMessage());
        assertEquals("200", imiSearchData.getBaseMessage().getReturnCode());
        assertEquals("Success", imiSearchData.getBaseMessage().getReturnCodeDescription());

        assertNotNull(imiSearchData.getServiceMessage());
        assertEquals(200, imiSearchData.getServiceMessage().getReturnCode());
        assertEquals("Operation completed successfully", imiSearchData.getServiceMessage().getReturnCodeDescription());

        assertNotNull(imiSearchData.getNaicMap());
        assertEquals(2, imiSearchData.getNaicMap().size());
        assertEquals("Test Insurance Company", imiSearchData.getNaicMap().get("12345"));
        assertEquals("Another Insurance Company", imiSearchData.getNaicMap().get("67890"));
    }

    @Test
    void testIMISearchDataWithAllNullValues() {
        imiSearchData.setSearchResultsList(null);
        imiSearchData.setBaseMessage(null);
        imiSearchData.setServiceMessage(null);
        imiSearchData.setNaicMap(null);

        assertNull(imiSearchData.getSearchResultsList());
        assertNull(imiSearchData.getBaseMessage());
        assertNull(imiSearchData.getServiceMessage());
        assertNull(imiSearchData.getNaicMap());
    }

    // ========== EDGE CASE TESTS ==========

    @Test
    void testBaseMessageWithSpecialCharacters() {
        IMISearchData.BaseMessage baseMessage = new IMISearchData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Success with special chars: !@#$%^&*()");
        
        assertEquals("200", baseMessage.getReturnCode());
        assertEquals("Success with special chars: !@#$%^&*()", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testServiceMessageWithLargeNumbers() {
        IMISearchData.ServiceMessage serviceMessage = new IMISearchData.ServiceMessage();
        serviceMessage.setReturnCode(Integer.MAX_VALUE);
        serviceMessage.setReturnCodeDescription("Maximum integer value");
        
        assertEquals(Integer.MAX_VALUE, serviceMessage.getReturnCode());
        assertEquals("Maximum integer value", serviceMessage.getReturnCodeDescription());
    }

    @Test
    void testNaicMapWithSpecialKeys() {
        Map<String, String> specialNaicMap = new HashMap<>();
        specialNaicMap.put("", "Empty key");
        specialNaicMap.put("key with spaces", "Value with spaces");
        specialNaicMap.put("key-with-dashes", "Value-with-dashes");
        specialNaicMap.put("key_with_underscores", "Value_with_underscores");
        
        imiSearchData.setNaicMap(specialNaicMap);
        
        Map<String, String> result = imiSearchData.getNaicMap();
        assertEquals(4, result.size());
        assertEquals("Empty key", result.get(""));
        assertEquals("Value with spaces", result.get("key with spaces"));
        assertEquals("Value-with-dashes", result.get("key-with-dashes"));
        assertEquals("Value_with_underscores", result.get("key_with_underscores"));
    }
}
