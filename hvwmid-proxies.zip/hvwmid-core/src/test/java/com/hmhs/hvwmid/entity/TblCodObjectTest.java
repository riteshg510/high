package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class TblCodObjectTest {

    private TblCodObject tblCodObject;

    @BeforeEach
    void setUp() {
        tblCodObject = new TblCodObject();
    }

    @Test
    void testSetGetRequestId() {
        Integer requestId = 12345;
        tblCodObject.setRequestId(requestId);
        assertEquals(requestId, tblCodObject.getRequestId());
    }

    @Test
    void testSetGetSequenceNo() {
        Integer sequenceNo = 1;
        tblCodObject.setSequenceNo(sequenceNo);
        assertEquals(sequenceNo, tblCodObject.getSequenceNo());
    }

    @Test
    void testSetGetTimeCreate() {
        LocalDateTime now = LocalDateTime.now();
        tblCodObject.setTimeCreate(now);
        assertEquals(now, tblCodObject.getTimeCreate());
    }

    @Test
    void testSetGetObjectSegment() {
        byte[] data = new byte[]{1, 2, 3, 4};
        tblCodObject.setObjectSegment(data);
        assertArrayEquals(data, tblCodObject.getObjectSegment());

        tblCodObject.setObjectSegment(null);
        assertNull(tblCodObject.getObjectSegment());
    }

    @Test
    void testEqualityAndHashCode() {
        TblCodObject obj1 = new TblCodObject();
        obj1.setRequestId(123);
        obj1.setSequenceNo(1);

        TblCodObject obj2 = new TblCodObject();
        obj2.setRequestId(123);
        obj2.setSequenceNo(1);

        TblCodObject obj3 = new TblCodObject();
        obj3.setRequestId(124);
        obj3.setSequenceNo(2);

        assertEquals(obj1, obj2);
        assertNotEquals(obj1, obj3);
        assertEquals(obj1.hashCode(), obj2.hashCode());
    }
}
