package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for IMIUpdateData POJO
 * Tests all getters, setters, constructors, toString method, and nested BaseMessage class
 * 
 */
class IMIUpdateDataTest {

    private IMIUpdateData imiUpdateData;

    @BeforeEach
    void setUp() {
        imiUpdateData = new IMIUpdateData();
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        IMIUpdateData data = new IMIUpdateData();
        assertNotNull(data);
        assertNull(data.getResponseMessage());
        assertNull(data.getBaseMessage());
    }

    @Test
    void testConstructorWithResponseMessage() {
        String responseMessage = "Update successful";
        IMIUpdateData data = new IMIUpdateData(responseMessage);
        
        assertNotNull(data);
        assertEquals(responseMessage, data.getResponseMessage());
        assertNull(data.getBaseMessage());
    }

    @Test
    void testConstructorWithNullResponseMessage() {
        IMIUpdateData data = new IMIUpdateData(null);
        
        assertNotNull(data);
        assertNull(data.getResponseMessage());
        assertNull(data.getBaseMessage());
    }

    @Test
    void testConstructorWithEmptyResponseMessage() {
        IMIUpdateData data = new IMIUpdateData("");
        
        assertNotNull(data);
        assertEquals("", data.getResponseMessage());
        assertNull(data.getBaseMessage());
    }

    // ========== GETTER AND SETTER TESTS ==========

    @Test
    void testResponseMessageGetterAndSetter() {
        String responseMessage = "Update completed successfully";
        imiUpdateData.setResponseMessage(responseMessage);
        assertEquals(responseMessage, imiUpdateData.getResponseMessage());
    }

    @Test
    void testResponseMessageWithNull() {
        imiUpdateData.setResponseMessage(null);
        assertNull(imiUpdateData.getResponseMessage());
    }

    @Test
    void testResponseMessageWithEmptyString() {
        imiUpdateData.setResponseMessage("");
        assertEquals("", imiUpdateData.getResponseMessage());
    }

    @Test
    void testResponseMessageWithSpecialCharacters() {
        String responseMessage = "Update with special chars: !@#$%^&*()";
        imiUpdateData.setResponseMessage(responseMessage);
        assertEquals(responseMessage, imiUpdateData.getResponseMessage());
    }

    @Test
    void testResponseMessageWithUnicodeCharacters() {
        String responseMessage = "Update with unicode: 更新成功";
        imiUpdateData.setResponseMessage(responseMessage);
        assertEquals(responseMessage, imiUpdateData.getResponseMessage());
    }

    @Test
    void testResponseMessageWithNewlinesAndTabs() {
        String responseMessage = "Update message with\nnewlines\tand\ttabs";
        imiUpdateData.setResponseMessage(responseMessage);
        assertEquals(responseMessage, imiUpdateData.getResponseMessage());
    }

    @Test
    void testResponseMessageWithVeryLongString() {
        String responseMessage = "A".repeat(1000);
        imiUpdateData.setResponseMessage(responseMessage);
        assertEquals(responseMessage, imiUpdateData.getResponseMessage());
    }

    @Test
    void testBaseMessageGetterAndSetter() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Success");
        
        imiUpdateData.setBaseMessage(baseMessage);
        
        IMIUpdateData.BaseMessage result = imiUpdateData.getBaseMessage();
        assertNotNull(result);
        assertEquals(baseMessage, result);
        assertEquals("200", result.getReturnCode());
        assertEquals("Success", result.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithNull() {
        imiUpdateData.setBaseMessage(null);
        assertNull(imiUpdateData.getBaseMessage());
    }

    // ========== NESTED CLASS TESTS - BaseMessage ==========

    @Test
    void testBaseMessageDefaultConstructor() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        assertNotNull(baseMessage);
        assertNull(baseMessage.getReturnCode());
        assertNull(baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeGetterAndSetter() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        
        // Test setter
        baseMessage.setReturnCode("404");
        
        // Test getter
        assertEquals("404", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithNull() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode(null);
        assertNull(baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithEmptyString() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("");
        assertEquals("", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithNumericString() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("500");
        assertEquals("500", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithNonNumericString() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("ERROR");
        assertEquals("ERROR", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeWithSpecialCharacters() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("ERR-001");
        assertEquals("ERR-001", baseMessage.getReturnCode());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionGetterAndSetter() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        
        // Test setter
        baseMessage.setReturnCodeDescription("Not Found");
        
        // Test getter
        assertEquals("Not Found", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithNull() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCodeDescription(null);
        assertNull(baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithEmptyString() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCodeDescription("");
        assertEquals("", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithLongString() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        String longDescription = "A".repeat(1000);
        baseMessage.setReturnCodeDescription(longDescription);
        assertEquals(longDescription, baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithSpecialCharacters() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCodeDescription("Error with special chars: !@#$%^&*()");
        assertEquals("Error with special chars: !@#$%^&*()", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithUnicodeCharacters() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCodeDescription("Error with unicode: 错误信息");
        assertEquals("Error with unicode: 错误信息", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageReturnCodeDescriptionWithNewlinesAndTabs() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCodeDescription("Error message with\nnewlines\tand\ttabs");
        assertEquals("Error message with\nnewlines\tand\ttabs", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithAllFields() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("500");
        baseMessage.setReturnCodeDescription("Internal Server Error");
        
        assertEquals("500", baseMessage.getReturnCode());
        assertEquals("Internal Server Error", baseMessage.getReturnCodeDescription());
    }

    // ========== TO STRING TESTS ==========

    @Test
    void testToStringWithAllFields() {
        imiUpdateData.setResponseMessage("Update successful");
        
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Success");
        imiUpdateData.setBaseMessage(baseMessage);

        String result = imiUpdateData.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMIUpdateData"));
        assertTrue(result.contains("responseMessage='Update successful'"));
        assertTrue(result.contains("baseMessage="));
    }

    @Test
    void testToStringWithNullFields() {
        String result = imiUpdateData.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMIUpdateData"));
        assertTrue(result.contains("baseMessage=null"));
    }

    @Test
    void testToStringWithResponseMessageOnly() {
        imiUpdateData.setResponseMessage("Update completed");
        
        String result = imiUpdateData.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMIUpdateData"));
        assertTrue(result.contains("responseMessage='Update completed'"));
        assertTrue(result.contains("baseMessage=null"));
    }

    @Test
    void testToStringWithBaseMessageOnly() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("400");
        baseMessage.setReturnCodeDescription("Bad Request");
        imiUpdateData.setBaseMessage(baseMessage);
        
        String result = imiUpdateData.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMIUpdateData"));
        assertTrue(result.contains("baseMessage="));
    }

    @Test
    void testToStringWithEmptyResponseMessage() {
        imiUpdateData.setResponseMessage("");
        
        String result = imiUpdateData.toString();
        assertNotNull(result);
        assertTrue(result.contains("IMIUpdateData"));
        assertTrue(result.contains("responseMessage=''"));
        assertTrue(result.contains("baseMessage=null"));
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteIMIUpdateDataSetup() {
        // Setup response message
        imiUpdateData.setResponseMessage("IMI update operation completed successfully");
        
        // Setup base message
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Update operation completed successfully");
        imiUpdateData.setBaseMessage(baseMessage);

        // Verify all fields are set correctly
        assertEquals("IMI update operation completed successfully", imiUpdateData.getResponseMessage());
        assertNotNull(imiUpdateData.getBaseMessage());
        assertEquals("200", imiUpdateData.getBaseMessage().getReturnCode());
        assertEquals("Update operation completed successfully", imiUpdateData.getBaseMessage().getReturnCodeDescription());
    }

    @Test
    void testIMIUpdateDataWithAllNullValues() {
        imiUpdateData.setResponseMessage(null);
        imiUpdateData.setBaseMessage(null);

        assertNull(imiUpdateData.getResponseMessage());
        assertNull(imiUpdateData.getBaseMessage());
    }

    @Test
    void testIMIUpdateDataWithErrorScenario() {
        imiUpdateData.setResponseMessage("Update failed");
        
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("500");
        baseMessage.setReturnCodeDescription("Internal server error occurred during update");
        imiUpdateData.setBaseMessage(baseMessage);

        assertEquals("Update failed", imiUpdateData.getResponseMessage());
        assertNotNull(imiUpdateData.getBaseMessage());
        assertEquals("500", imiUpdateData.getBaseMessage().getReturnCode());
        assertEquals("Internal server error occurred during update", imiUpdateData.getBaseMessage().getReturnCodeDescription());
    }

    @Test
    void testIMIUpdateDataWithValidationErrorScenario() {
        imiUpdateData.setResponseMessage("Validation failed");
        
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("400");
        baseMessage.setReturnCodeDescription("Invalid input parameters provided");
        imiUpdateData.setBaseMessage(baseMessage);

        assertEquals("Validation failed", imiUpdateData.getResponseMessage());
        assertNotNull(imiUpdateData.getBaseMessage());
        assertEquals("400", imiUpdateData.getBaseMessage().getReturnCode());
        assertEquals("Invalid input parameters provided", imiUpdateData.getBaseMessage().getReturnCodeDescription());
    }

    @Test
    void testIMIUpdateDataWithNotFoundErrorScenario() {
        imiUpdateData.setResponseMessage("Record not found");
        
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("404");
        baseMessage.setReturnCodeDescription("The requested record was not found");
        imiUpdateData.setBaseMessage(baseMessage);

        assertEquals("Record not found", imiUpdateData.getResponseMessage());
        assertNotNull(imiUpdateData.getBaseMessage());
        assertEquals("404", imiUpdateData.getBaseMessage().getReturnCode());
        assertEquals("The requested record was not found", imiUpdateData.getBaseMessage().getReturnCodeDescription());
    }

    // ========== EDGE CASE TESTS ==========

    @Test
    void testBaseMessageToString() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("200");
        baseMessage.setReturnCodeDescription("Success");
        
        String result = baseMessage.toString();
        assertNotNull(result);
        assertTrue(result.contains("BaseMessage"));
        assertTrue(result.contains("returnCode='200'"));
        assertTrue(result.contains("returnCodeDescription='Success'"));
    }

    @Test
    void testBaseMessageToStringWithEmptyFields() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("");
        baseMessage.setReturnCodeDescription("");
        
        String result = baseMessage.toString();
        assertNotNull(result);
        assertTrue(result.contains("BaseMessage"));
        assertTrue(result.contains("returnCode=''"));
        assertTrue(result.contains("returnCodeDescription=''"));
    }

    @Test
    void testBaseMessageWithJsonLikeReturnCode() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("{\"code\": 200, \"status\": \"success\"}");
        baseMessage.setReturnCodeDescription("JSON response");
        
        assertEquals("{\"code\": 200, \"status\": \"success\"}", baseMessage.getReturnCode());
        assertEquals("JSON response", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithXmlLikeReturnCode() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("<response><code>200</code><status>success</status></response>");
        baseMessage.setReturnCodeDescription("XML response");
        
        assertEquals("<response><code>200</code><status>success</status></response>", baseMessage.getReturnCode());
        assertEquals("XML response", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithUrlLikeReturnCode() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("https://api.example.com/update?status=success");
        baseMessage.setReturnCodeDescription("URL response");
        
        assertEquals("https://api.example.com/update?status=success", baseMessage.getReturnCode());
        assertEquals("URL response", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithSqlLikeReturnCode() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("UPDATE t222adsg SET status = 'UPDATED' WHERE id = 123");
        baseMessage.setReturnCodeDescription("SQL update statement");
        
        assertEquals("UPDATE t222adsg SET status = 'UPDATED' WHERE id = 123", baseMessage.getReturnCode());
        assertEquals("SQL update statement", baseMessage.getReturnCodeDescription());
    }

    @Test
    void testBaseMessageWithHtmlLikeReturnCode() {
        IMIUpdateData.BaseMessage baseMessage = new IMIUpdateData.BaseMessage();
        baseMessage.setReturnCode("<html><body><h1>Update Successful</h1></body></html>");
        baseMessage.setReturnCodeDescription("HTML response");
        
        assertEquals("<html><body><h1>Update Successful</h1></body></html>", baseMessage.getReturnCode());
        assertEquals("HTML response", baseMessage.getReturnCodeDescription());
    }
}
