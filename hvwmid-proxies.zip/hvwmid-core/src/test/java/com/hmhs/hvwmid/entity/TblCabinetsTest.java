package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TblCabinetsTest {

    private TblCabinets tblCabinets;

    @BeforeEach
    void setUp() {
        tblCabinets = new TblCabinets();
    }

    // Test for cabinetId (uppercase conversion)
    @Test
    void testSetGetCabinetId() {
        String cabinetId = "CAB123";
        tblCabinets.setCabinetId(cabinetId);
        assertEquals(cabinetId.toUpperCase(), tblCabinets.getCabinetId());
    }

    // Test for cabinetName
    @Test
    void testSetGetCabinetName() {
        String cabinetName = "Storage Cabinet";
        tblCabinets.setCabinetName(cabinetName);
        assertEquals(cabinetName, tblCabinets.getCabinetName());
    }

    // Test for departmentId (uppercase conversion)
    @Test
    void testSetGetDepartmentId() {
        String departmentId = "DEPT123";
        tblCabinets.setDepartmentId(departmentId);
        assertEquals(departmentId.toUpperCase(), tblCabinets.getDepartmentId());
    }

    // Test for createTimestamp
    @Test
    void testSetGetCreateTimestamp() {
        LocalDateTime timestamp = LocalDateTime.of(2024, 11, 19, 10, 0, 0, 0);
        tblCabinets.setCreateTimestamp(timestamp);
        assertEquals(timestamp, tblCabinets.getCreateTimestamp());
    }

    // Test for actions (List<TblActions>)
    @Test
    void testSetGetActions() {
        List<TblActions> actions = new ArrayList<>();
        TblActions action = new TblActions();
        action.setActionId("ACTION123");
        actions.add(action);

        tblCabinets.setActions(actions);
        assertNotNull(tblCabinets.getActions());
        assertEquals(1, tblCabinets.getActions().size());
        assertEquals("ACTION123", tblCabinets.getActions().get(0).getActionId());
    }
}
