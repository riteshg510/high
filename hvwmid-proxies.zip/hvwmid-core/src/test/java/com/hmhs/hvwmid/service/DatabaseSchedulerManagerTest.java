package com.hmhs.hvwmid.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;

import java.util.concurrent.ScheduledFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for DatabaseSchedulerManager.
 * Tests the dynamic task scheduling functionality for XML refresh and parameter
 * data refresh.
 */
@ExtendWith(MockitoExtension.class)
class DatabaseSchedulerManagerTest {

    @Mock
    private TaskScheduler scheduler;

    @Mock
    private CMODDataRefreshService cmodDataRefreshService;

    @Mock
    private ImageParmDataService imageParmDataService;

    @Mock
    private ScheduledFuture<?> scheduledFuture;

    @InjectMocks
    private DatabaseSchedulerManager databaseSchedulerManager;

    private static final String DEFAULT_CRON = "0 0 2 * * *";
    private static final String CUSTOM_CRON = "0 30 1 * * *";

    @BeforeEach
    void setUp() {
        // Reset mocks for each test
        reset(scheduler, cmodDataRefreshService, imageParmDataService, scheduledFuture);
    }

    @Test
    void testConstructor_InitializesDependencies() {
        // Given & When - constructor is called via @InjectMocks

        // Then
        assertNotNull(databaseSchedulerManager);
    }

    @Test
    void testStart_CallsBothSchedulingMethods() {
        // Given
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON);
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshParmData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON);
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.start();

        // Then
        verify(imageParmDataService).getParmDataByKey("HVWCRON", "refreshCMODData", DEFAULT_CRON);
        verify(imageParmDataService).getParmDataByKey("HVWCRON", "refreshParmData", DEFAULT_CRON);
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testScheduleXmlRefreshTaskFromDb_WithDefaultCron() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // Then
        ArgumentCaptor<CronTrigger> cronCaptor = ArgumentCaptor.forClass(CronTrigger.class);
        ArgumentCaptor<Runnable> runnableCaptor = ArgumentCaptor.forClass(Runnable.class);
        verify(scheduler).schedule(runnableCaptor.capture(), cronCaptor.capture());

        CronTrigger capturedTrigger = cronCaptor.getValue();
        assertEquals(DEFAULT_CRON, capturedTrigger.getExpression());
        // Verify the cron expression is correct
        assertNotNull(capturedTrigger.getExpression());

        // Test the runnable executes the correct service method
        Runnable capturedRunnable = runnableCaptor.getValue();
        capturedRunnable.run();
        verify(cmodDataRefreshService).refreshCMODData();
    }

    @Test
    void testScheduleXmlRefreshTaskFromDb_WithCustomCron() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(CUSTOM_CRON);

        // Then
        ArgumentCaptor<CronTrigger> cronCaptor = ArgumentCaptor.forClass(CronTrigger.class);
        verify(scheduler).schedule(any(Runnable.class), cronCaptor.capture());

        CronTrigger capturedTrigger = cronCaptor.getValue();
        assertEquals(CUSTOM_CRON, capturedTrigger.getExpression());
        // Verify the cron expression is correct
        assertNotNull(capturedTrigger.getExpression());
    }

    @Test
    void testScheduleRefreshParamDataTaskFromDb_WithDefaultCron() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // Then
        ArgumentCaptor<CronTrigger> cronCaptor = ArgumentCaptor.forClass(CronTrigger.class);
        ArgumentCaptor<Runnable> runnableCaptor = ArgumentCaptor.forClass(Runnable.class);
        verify(scheduler).schedule(runnableCaptor.capture(), cronCaptor.capture());

        CronTrigger capturedTrigger = cronCaptor.getValue();
        assertEquals(DEFAULT_CRON, capturedTrigger.getExpression());
        // Verify the cron expression is correct
        assertNotNull(capturedTrigger.getExpression());

        // Test the runnable executes the correct service method
        Runnable capturedRunnable = runnableCaptor.getValue();
        capturedRunnable.run();
        verify(imageParmDataService).refreshParmData();
    }

    @Test
    void testScheduleRefreshParamDataTaskFromDb_WithCustomCron() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(CUSTOM_CRON);

        // Then
        ArgumentCaptor<CronTrigger> cronCaptor = ArgumentCaptor.forClass(CronTrigger.class);
        verify(scheduler).schedule(any(Runnable.class), cronCaptor.capture());

        CronTrigger capturedTrigger = cronCaptor.getValue();
        assertEquals(CUSTOM_CRON, capturedTrigger.getExpression());
    }

    @Test
    void testScheduleXmlRefreshTaskFromDb_CancelsPreviousTask() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
        when(scheduledFuture.isCancelled()).thenReturn(false);

        // First call to set up the scheduled future
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // When - second call to test cancellation
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // Then
        verify(scheduledFuture).cancel(false);
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testScheduleRefreshParamDataTaskFromDb_CancelsPreviousTask() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
        when(scheduledFuture.isCancelled()).thenReturn(false);

        // First call to set up the scheduled future
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // When - second call to test cancellation
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // Then
        verify(scheduledFuture).cancel(false);
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testScheduleXmlRefreshTaskFromDb_DoesNotCancelIfAlreadyCancelled() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
        when(scheduledFuture.isCancelled()).thenReturn(true);

        // First call to set up the scheduled future
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // When - second call with already cancelled future
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // Then - cancel should not be called since it's already cancelled
        verify(scheduledFuture, never()).cancel(anyBoolean());
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testScheduleRefreshParamDataTaskFromDb_DoesNotCancelIfAlreadyCancelled() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
        when(scheduledFuture.isCancelled()).thenReturn(true);

        // First call to set up the scheduled future
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // When - second call with already cancelled future
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // Then - cancel should not be called since it's already cancelled
        verify(scheduledFuture, never()).cancel(anyBoolean());
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testCheckAndUpdateSchedulesIfChanged_WithNoChanges() {
        // Given - simulate that the values haven't changed from initial empty state
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // First call to set up the initial state (lastCmodCronValue = DEFAULT_CRON, lastParmDataCronValue = DEFAULT_CRON)
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();
        reset(scheduler); // Reset to clear previous calls

        // When - second call with same values should not reschedule
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();

        // Then - should not reschedule since values haven't changed
        verify(scheduler, never()).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testCheckAndUpdateSchedulesIfChanged_WithCMODChange() {
        // Given - first call returns DEFAULT_CRON, second call returns CUSTOM_CRON
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON)
                .thenReturn(CUSTOM_CRON); // Second call returns different value
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshParmData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON);
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // First call to set up the initial state (lastCmodCronValue = DEFAULT_CRON)
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();
        reset(scheduler); // Reset to clear previous calls

        // When - second call should detect the change
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();

        // Then - should reschedule CMOD task only
        verify(scheduler, times(1)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testCheckAndUpdateSchedulesIfChanged_WithParmDataChange() {
        // Given - first call returns DEFAULT_CRON, second call returns CUSTOM_CRON
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON);
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshParmData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON)
                .thenReturn(CUSTOM_CRON); // Second call returns different value
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // First call to set up the initial state (lastParmDataCronValue = DEFAULT_CRON)
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();
        reset(scheduler); // Reset to clear previous calls

        // When - second call should detect the change
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();

        // Then - should reschedule ParmData task only
        verify(scheduler, times(1)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testCheckAndUpdateSchedulesIfChanged_WithBothChanges() {
        // Given
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON)
                .thenReturn(CUSTOM_CRON); // Second call returns different value
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshParmData", DEFAULT_CRON))
                .thenReturn(DEFAULT_CRON)
                .thenReturn(CUSTOM_CRON); // Second call returns different value
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // Set up initial values (simulate first run)
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);
        reset(scheduler); // Reset to clear previous calls

        // When - call the hourly check method
        databaseSchedulerManager.checkAndUpdateSchedulesIfChanged();

        // Then - should reschedule both tasks
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testCheckAndUpdateSchedulesIfChanged_HandlesException() {
        // Given
        RuntimeException serviceException = new RuntimeException("Database error");
        when(imageParmDataService.getParmDataByKey("HVWCRON", "refreshCMODData", DEFAULT_CRON))
                .thenThrow(serviceException);

        // When & Then - should not throw exception, should handle gracefully
        assertDoesNotThrow(() -> databaseSchedulerManager.checkAndUpdateSchedulesIfChanged());
        verify(scheduler, never()).schedule(any(Runnable.class), any(CronTrigger.class));
    }


    @Test
    void testScheduleXmlRefreshTaskFromDb_HandlesSchedulerException() {
        // Given
        RuntimeException schedulerException = new RuntimeException("Scheduler error");
        when(scheduler.schedule(any(Runnable.class), any(CronTrigger.class)))
                .thenThrow(schedulerException);

        // When & Then
        assertThrows(RuntimeException.class, () -> databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON));
    }

    @Test
    void testScheduleRefreshParamDataTaskFromDb_HandlesSchedulerException() {
        // Given
        RuntimeException schedulerException = new RuntimeException("Scheduler error");
        when(scheduler.schedule(any(Runnable.class), any(CronTrigger.class)))
                .thenThrow(schedulerException);

        // When & Then
        assertThrows(RuntimeException.class, () -> databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON));
    }

    @Test
    void testScheduledAnnotation() throws NoSuchMethodException {
        // Test checkAndUpdateSchedulesIfChanged() annotation
        var checkMethod = DatabaseSchedulerManager.class.getMethod("checkAndUpdateSchedulesIfChanged");
        var scheduledAnnotation = checkMethod
                .getAnnotation(org.springframework.scheduling.annotation.Scheduled.class);
        assertNotNull(scheduledAnnotation);
        assertEquals("0 0 * * * *", scheduledAnnotation.cron());
        assertEquals("America/New_York", scheduledAnnotation.zone());
    }

    @Test
    void testServiceAnnotation() {
        // Verify the scheduler is annotated as a Spring service
        var serviceAnnotation = DatabaseSchedulerManager.class
                .getAnnotation(org.springframework.stereotype.Service.class);
        assertNotNull(serviceAnnotation);
    }

    @Test
    void testPostConstructAnnotation() throws NoSuchMethodException {
        // Verify the start() method is annotated with @PostConstruct
        var startMethod = DatabaseSchedulerManager.class.getMethod("start");
        var postConstructAnnotation = startMethod.getAnnotation(jakarta.annotation.PostConstruct.class);
        assertNotNull(postConstructAnnotation);
    }

    @Test
    void testScheduleXmlRefreshTaskFromDb_WithNullFuture() {
        // Given - no previous scheduled future
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // Then - should not attempt to cancel null future
        verify(scheduledFuture, never()).cancel(anyBoolean());
        verify(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testScheduleRefreshParamDataTaskFromDb_WithNullFuture() {
        // Given - no previous scheduled future
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // Then - should not attempt to cancel null future
        verify(scheduledFuture, never()).cancel(anyBoolean());
        verify(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
    }

    @Test
    void testCronTriggerTimeZone_IsNewYork() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));

        // When
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);

        // Then
        ArgumentCaptor<CronTrigger> cronCaptor = ArgumentCaptor.forClass(CronTrigger.class);
        verify(scheduler).schedule(any(Runnable.class), cronCaptor.capture());

        CronTrigger capturedTrigger = cronCaptor.getValue();
        // Verify the cron expression is correct
        assertNotNull(capturedTrigger.getExpression());
    }

    @Test
    void testBothSchedulingMethods_UsesSameScheduledFutureField() {
        // Given
        doReturn(scheduledFuture).when(scheduler).schedule(any(Runnable.class), any(CronTrigger.class));
        when(scheduledFuture.isCancelled()).thenReturn(false);

        // When - call XML refresh first, then param data refresh
        databaseSchedulerManager.scheduleXmlRefreshTaskFromDb(DEFAULT_CRON);
        databaseSchedulerManager.scheduleRefreshParamDataTaskFromDb(DEFAULT_CRON);

        // Then - the second call should cancel the first scheduled future
        verify(scheduledFuture).cancel(false);
        verify(scheduler, times(2)).schedule(any(Runnable.class), any(CronTrigger.class));
    }
}