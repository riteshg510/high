package com.hmhs.hvwmid.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.ReportAction;
import com.hmhs.hvwmid.model.ReportChild;
import com.hmhs.hvwmid.model.ReportLayout;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyMap;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CmodFolderServiceTest {

    @Mock
    private RestClientUtil restClientUtil;

    @InjectMocks
    @Spy
    private CmodFolderService service;

    @Mock
    private UploadActionService uploadActionService;

    @Mock
    private Logger logger;

    @Mock
    private CMODAppService cmodAppService;


    @BeforeEach
    void setUp() throws Exception {
        // Set value of @Value field (fieldsUrl) using reflection
        var field = CmodFolderService.class.getDeclaredField("fieldsUrl");
        field.setAccessible(true);
        field.set(service, "http://mock-api/fields");
    }

    @Test
    void testDivideFieldsIntoSingleColumn() {
        // Case 1: Total fields <= 5
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            fields.add(new ReportChild()); // Add dummy ReportChild objects
        }

        List<ReportChild> columns = service.divideFieldsIntoColumns(fields);
        assertEquals(1, columns.size(), "There should be a single column.");
    }

    @Test
    void testDivideFieldsIntoTwoColumns() {
        // Case 2: Total fields <= 10
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            fields.add(new ReportChild()); // Add dummy ReportChild objects
        }

        List<ReportChild> columns = service.divideFieldsIntoColumns(fields);
        assertEquals(2, columns.size(), "There should be two columns.");
    }

    // Test when the number of fields is more than 10
    @Test
    void testDivideFieldsIntoMultipleColumns() {
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            fields.add(new ReportChild()); // Add dummy ReportChild objects
        }

        List<ReportChild> columns = service.divideFieldsIntoColumns(fields);

        // Check that there are three columns
        assertEquals(3, columns.size(), "There should be three columns.");

        // Verify the correct number of fields in each column (row-wise grouping)
        assertEquals(4, columns.get(0).getChildren().size(), "The first column should contain 4 fields.");
        assertEquals(4, columns.get(1).getChildren().size(), "The second column should contain 4 fields.");
        assertEquals(4, columns.get(2).getChildren().size(), "The third column should contain 4 fields.");
    }

    // Test when the number of fields is a multiple of 5 (like 15)
    @Test
    void testDivideFieldsWithExactMultipleOf5() {
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 15; i++) {
            fields.add(new ReportChild()); // Add dummy ReportChild objects
        }

        List<ReportChild> columns = service.divideFieldsIntoColumns(fields);

        // Check that there are three columns
        assertEquals(3, columns.size(), "There should be three columns.");

        // Verify the number of fields in each column
        assertEquals(5, columns.get(0).getChildren().size(), "The first column should contain 5 fields.");
        assertEquals(5, columns.get(1).getChildren().size(), "The second column should contain 5 fields.");
        assertEquals(5, columns.get(2).getChildren().size(), "The third column should contain 5 fields.");
    }

    @Test
    void getCmodFolderData_shouldReturnJson_whenValidInputs() throws Exception {
        // Arrange
        String folderId = "CMOD123";
        String helpText = "Some help text";
        String authToken = "Bearer xyz";

        // Mock JSON read for date fields
        InputStream mockStream = this.getClass().getClassLoader()
                .getResourceAsStream("data/Dates.json");
        ObjectMapper mapper = new ObjectMapper();
        List<ReportChild> mockDateFields = mapper.readValue(mockStream,
                mapper.getTypeFactory().constructCollectionType(List.class, ReportChild.class));

        // Inject mock ObjectMapper using reflection
        var objectMapperField = CmodFolderService.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(service, mapper);

        // Mock response from fields API
        Map<String, Object> mockResponseBody = Map.of(
                "folderSearchCriteria", List.of(
                        Map.of("name", "INVOICE NUMBER", "maxEntryChars", 10),
                        Map.of("name", "POSTING DATE", "defaultValueAvailable", true,
                                "searchValues", List.of("2023-01-01", "2023-12-31"))
                )
        );

        ResponseEntity<Map> mockResponse = ResponseEntity.ok(mockResponseBody);

        when(restClientUtil.postRequest(eq("http://mock-api/fields"), eq(authToken), anyMap()))
                .thenReturn(mockResponse);

        // Act
        String resultJson = service.getCmodFolderData(folderId, helpText, authToken);

        // Assert
        assertNotNull(resultJson);
        assertTrue(resultJson.contains("CMOD Search"));
        assertTrue(resultJson.contains("INVOICE NUMBER"));
        //assertTrue(resultJson.contains("POSTING DATE"));
        assertTrue(resultJson.contains(helpText));
    }

    @Test
    void getCmodFolderData_shouldReturnUploadFormName_whenUploadFolder() throws Exception {
        // Arrange
        String folderId = "CMODUPLOADInvoices";
        String helpText = "Help for upload";
        String authToken = "Bearer upload";

        // Mock JSON read for date fields (not used for upload)
        ObjectMapper mapper = new ObjectMapper();
        var objectMapperField = CmodFolderService.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(service, mapper);

        // Mock response from fields API
        Map<String, Object> mockResponseBody = Map.of(
                "folderSearchCriteria", List.of(
                        Map.of("name", "INVOICE NUMBER", "maxEntryChars", 10)
                )
        );
        ResponseEntity<Map> mockResponse = ResponseEntity.ok(mockResponseBody);
        when(restClientUtil.postRequest(eq("http://mock-api/fields"), eq(authToken), anyMap()))
                .thenReturn(mockResponse);

        // Act
        String resultJson = service.getCmodFolderData(folderId, helpText, authToken);

        // Assert
        assertNotNull(resultJson);
        assertTrue(resultJson.contains("Upload Invoices Document"), "Should contain the new upload form name");
        assertTrue(resultJson.contains("INVOICE NUMBER"));
        assertTrue(resultJson.contains(helpText));
    }

    @Test
    void getCmodFolderData_shouldThrowException_whenFieldsServiceFails() throws Exception {
        // Arrange
        String folderId = "CMOD999";
        String authToken = "Bearer abc";

        // Set ObjectMapper manually like in the other test
        ObjectMapper mapper = new ObjectMapper();
        var objectMapperField = CmodFolderService.class.getDeclaredField("objectMapper");
        objectMapperField.setAccessible(true);
        objectMapperField.set(service, mapper);

        // Mocking RestClientUtil to throw an exception when postRequest is called
        when(restClientUtil.postRequest(any(), any(), any()))
                .thenThrow(new RuntimeException("Service down"));

        // Act + Assert
        HVWException ex = assertThrows(HVWException.class,
                () -> service.getCmodFolderData(folderId, null, authToken));

        // Verify that the exception message contains the expected text
        System.out.println(ex.getMessage());
        assertTrue(ex.getMessage().equalsIgnoreCase("Error fetching index fields: Service down"));
    }

    @Test
    void testCreateApplicationSelectionFields_withValidChoices() {
        // Arrange
        String folderId = "folder123";
        Map<String, String> choice1 = Map.of("key", "app1", "displayName", "Application 1");
        Map<String, String> choice2 = Map.of("key", "app2", "displayName", "Application 2");

        when(cmodAppService.getApplicationChoicesForFolder(folderId))
                .thenReturn(List.of(choice1, choice2));

        // Act
        List<ReportChild> result = service.createApplicationSelectionFields(folderId);

        // Assert
        assertEquals(1, result.size());
        ReportChild appField = result.get(0);
        assertTrue(appField.getDisplay());
        assertEquals("Application", appField.getName());
        assertEquals("select", appField.getInputType());
        assertEquals("property", appField.getLayoutType());
        assertEquals("string", appField.getType());
        assertTrue(appField.getRequired());
        assertEquals("applicationId", appField.getId());
        assertEquals(2, appField.getChoiceList().size());
        assertEquals("app1", appField.getChoiceList().get(0).get("key"));
        assertEquals("Application 1", appField.getChoiceList().get(0).get("displayName"));
    }

    @Test
    void testCreateApplicationSelectionFields_withEmptyChoices() {
        // Arrange
        String folderId = "folderEmpty";
        when(cmodAppService.getApplicationChoicesForFolder(folderId))
                .thenReturn(Collections.emptyList());

        // Act
        List<ReportChild> result = service.createApplicationSelectionFields(folderId);

        // Assert
        assertEquals(1, result.size());
        ReportChild appField = result.get(0);
        assertEquals(1, appField.getChoiceList().size());
        assertEquals("", appField.getChoiceList().get(0).get("key"));
        assertEquals("No applications found for this folder",
                appField.getChoiceList().get(0).get("displayName"));
    }

    @Test
    void testCreateApplicationSelectionFields_whenExceptionThrown() {
        // Arrange
        String folderId = "folderError";
        when(cmodAppService.getApplicationChoicesForFolder(folderId))
                .thenThrow(new RuntimeException("Service failure"));

        // Act
        List<ReportChild> result = service.createApplicationSelectionFields(folderId);

        // Assert
        assertEquals(1, result.size());
        ReportChild appField = result.get(0);
        assertEquals(1, appField.getChoiceList().size());
        assertEquals("", appField.getChoiceList().get(0).get("key"));
        assertEquals("Error loading applications",
                appField.getChoiceList().get(0).get("displayName"));
    }

    @Test
    void testIsUploadFolder_nullFolderId_returnsFalse() {
        assertFalse(service.isUploadFolder(null));
    }

    @Test
    void testIsUploadFolder_startsWithCmodUpload_returnsTrue() {
        String folderId = "CMODUPLOAD123";
        assertTrue(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_startsWithUploadOnly_returnsTrue() {
        String folderId = "UPLOAD_456";
        assertTrue(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_startsWithCmodThenUpload_returnsTrue() {
        String folderId = "CMODUPLOAD_789";
        assertTrue(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_startsWithCmodNonUpload_returnsFalse() {
        String folderId = "CMODABCDEF";
        assertFalse(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_randomNonMatching_returnsFalse() {
        String folderId = "OTHER_123";
        assertFalse(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_normalizedCheck_returnsTrue() {
        String folderId = "CMODUPLOAD_TEMP_001";
        assertTrue(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_cmodOnlyPrefixButNoUpload_returnsFalse() {
        String folderId = "CMODNOTUPLOAD";
        assertFalse(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_exactUploadPrefixOnly_returnsTrue() {
        String folderId = "UPLOAD";
        assertTrue(service.isUploadFolder(folderId));
    }

    @Test
    void testIsUploadFolder_exactCmodUploadPrefixOnly_returnsTrue() {
        String folderId = "CMODUPLOAD";
        assertTrue(service.isUploadFolder(folderId));
    }

    @Test
    void testCreateFormActions_whenUploadForm_returnsUploadAndReset() {
        List<ReportAction> actions = service.createFormActions("anyFolder", "token123", true);

        assertEquals(3, actions.size());
        assertEquals("upload", actions.get(0).getAction());
        assertEquals("reset", actions.get(1).getAction());
        assertEquals("goToSearch", actions.get(2).getAction());
    }

    @Test
    void testCreateFormActions_whenRegularFormWithUploadAllowed_returnsSearchResetUpload() {
        String folder = "Finance";
        String token = "auth123";

        when(uploadActionService.shouldShowUploadAction(folder, token)).thenReturn(true);

        List<ReportAction> actions = service.createFormActions(folder, token, false);

        assertEquals(4, actions.size());
        assertEquals("search", actions.get(0).getAction());
        assertEquals("reset", actions.get(1).getAction());
        assertEquals("clear", actions.get(2).getAction());
        assertEquals("upload", actions.get(3).getAction());
        assertEquals("pages/report-upload/CMODUPLOADFinance", actions.get(3).getNavigateUrl());
    }

    @Test
    void testCreateFormActions_whenRegularFormWithoutUpload_returnsSearchAndReset() {
        String folder = "HR";
        String token = "auth456";

        when(uploadActionService.shouldShowUploadAction(folder, token)).thenReturn(false);

        List<ReportAction> actions = service.createFormActions(folder, token, false);

        assertEquals(3, actions.size());
        assertEquals("search", actions.get(0).getAction());
        assertEquals("reset", actions.get(1).getAction());
    }

    @Test
    void testCreateFormActions_whenUploadActionThrowsException_returnsSearchAndReset() {
        String folder = "Legal";
        String token = "authFail";

        when(uploadActionService.shouldShowUploadAction(folder, token)).thenThrow(new RuntimeException("error"));

        List<ReportAction> actions = service.createFormActions(folder, token, false);

        assertEquals(3, actions.size());
        assertEquals("search", actions.get(0).getAction());
        assertEquals("reset", actions.get(1).getAction());
    }

    @Test
    void testCreateFileUploadFields_returnsSingleFileUploadField() {
        List<ReportChild> fields = service.createFileUploadFields();

        assertEquals(1, fields.size(), "Should return only one field (file upload)");

        ReportChild field = fields.get(0);
        assertTrue(field.getDisplay(), "Field should be displayed");
        assertEquals("Upload Document", field.getName());
        assertEquals("file", field.getInputType());
        assertEquals("property", field.getLayoutType());
        assertEquals("file", field.getType());
        assertEquals("binary", field.getId());
        assertTrue(field.getRequired(), "Field should be required");
    }

    @Test
    void testDivideFieldsIntoColumnsOld_SingleColumn() {
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            fields.add(new ReportChild());
        }

        List<ReportChild> columns = service.divideFieldsIntoColumnsold(fields);

        assertEquals(1, columns.size(), "Expected a single column");
        assertEquals(3, columns.get(0).getChildren().size(), "Expected all fields in the single column");
    }

    @Test
    void testDivideFieldsIntoColumnsOld_TwoColumns() {
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            fields.add(new ReportChild());
        }

        List<ReportChild> columns = service.divideFieldsIntoColumnsold(fields);

        assertEquals(2, columns.size(), "Expected two columns");
        assertEquals(4, columns.get(0).getChildren().size(), "First column should contain 4 fields");
        assertEquals(4, columns.get(1).getChildren().size(), "Second column should contain 4 fields");
    }

    @Test
    void testDivideFieldsIntoColumnsOld_MultipleColumns() {
        List<ReportChild> fields = new ArrayList<>();
        for (int i = 0; i < 13; i++) {
            fields.add(new ReportChild());
        }

        List<ReportChild> columns = service.divideFieldsIntoColumnsold(fields);

        assertEquals(3, columns.size(), "Expected 3 columns of 5, 5, and 3 fields respectively");
        assertEquals(5, columns.get(0).getChildren().size());
        assertEquals(5, columns.get(1).getChildren().size());
        assertEquals(3, columns.get(2).getChildren().size());
    }

    @Test
    void testDivideFieldsIntoColumnsOld_EmptyList() {
        List<ReportChild> fields = new ArrayList<>();

        List<ReportChild> columns = service.divideFieldsIntoColumnsold(fields);

        assertEquals(1, columns.size(), "Should return a single empty column when input list is empty");
        assertEquals(0, columns.get(0).getChildren().size(), "Column should have 0 children");
    }

    @Test
    void testCreateFormLayouts_UploadForm_Success() throws Exception {
        String folderId = "folder123";
        String authToken = "token";
        boolean isUploadForm = true;

        // Mock return values
        List<ReportChild> uploadFields = List.of(new ReportChild());
        List<ReportChild> appSelectionFields = List.of(new ReportChild());
        List<ReportChild> indexFields = List.of(new ReportChild());

        // Stub method calls
        doReturn("folder123").when(service).normalizeFolderId(folderId);
        doReturn(uploadFields).when(service).createFileUploadFields();
        doReturn(appSelectionFields).when(service).createApplicationSelectionFields(folderId);
        doReturn(indexFields).when(service).getIndexFields(eq(folderId), eq(authToken), isNull(), eq(true));
        doReturn(new ReportLayout()).when(service).createSection(anyList(), anyString(), anyString(), anyString());

        List<ReportLayout> result = service.createFormLayouts(folderId, "help", authToken, isUploadForm);

        assertEquals(4, result.size(), "Upload form should return 4 sections.");
    }

    @Test
    void testCreateFormLayouts_SearchForm_SuccessWithPostingDates() throws Exception {
        String folderId = "folderABC";
        String authToken = "token";
        boolean isUploadForm = false;

        // Prepare mocks
        List<ReportChild> dateFields = new ArrayList<>();
        ReportChild startDate = new ReportChild();
        startDate.setId("startdate");
        ReportChild endDate = new ReportChild();
        endDate.setId("enddate");
        dateFields.add(startDate);
        dateFields.add(endDate);

        List<ReportChild> indexFields = List.of(new ReportChild());

        Map<String, List<String>> postingDates = Map.of("POSTING DATE", List.of("2023-01-01", "2023-02-01"));

        // Stub internal methods
        doReturn("folderABC").when(service).normalizeFolderId(folderId);
        doReturn(dateFields).when(service).readFieldsFromJson(anyString());
        doAnswer(invocation -> {
            ((Map<String, List<String>>) invocation.getArgument(2)).putAll(postingDates);
            return indexFields;
        }).when(service).getIndexFields(eq(folderId), eq(authToken), anyMap(), eq(false));
        doReturn(new ReportLayout()).when(service).createSection(anyList(), anyString(), anyString(), anyString());

        List<ReportLayout> result = service.createFormLayouts(folderId, "help", authToken, isUploadForm);

        assertEquals(3, result.size(), "Search form should return 3 sections.");
        assertEquals("2023-01-01", startDate.getDefaultValue());
        assertEquals("2023-02-01", endDate.getDefaultValue());
    }

    @Test
    void testCreateFormLayouts_SearchForm_SuccessWithDefaultDates() throws Exception {
        String folderId = "folderXYZ";
        String authToken = "token";
        boolean isUploadForm = false;

        // Prepare mock date fields
        List<ReportChild> dateFields = new ArrayList<>();
        ReportChild startDate = new ReportChild();
        startDate.setId("startdate");
        ReportChild endDate = new ReportChild();
        endDate.setId("enddate");
        dateFields.add(startDate);
        dateFields.add(endDate);

        List<ReportChild> indexFields = List.of(new ReportChild());

        // Stub internal methods
        doReturn("folderXYZ").when(service).normalizeFolderId(folderId);
        doReturn(dateFields).when(service).readFieldsFromJson(anyString());
        doAnswer(invocation -> {
            Map<String, List<String>> map = invocation.getArgument(2);
            // Don't add anything to simulate no posting date
            return indexFields;
        }).when(service).getIndexFields(eq(folderId), eq(authToken), anyMap(), eq(false));
        doReturn(new ReportLayout()).when(service).createSection(anyList(), anyString(), anyString(), anyString());

        List<ReportLayout> result = service.createFormLayouts(folderId, "help", authToken, isUploadForm);

        assertEquals(3, result.size(), "Search form should return 3 sections.");
        assertNotNull(startDate.getDefaultValue(), "Start date should be set.");
        assertNotNull(endDate.getDefaultValue(), "End date should be set.");
    }

    @Test
    void testCreateFormLayouts_ThrowsWrappedException() {
        String folderId = "fail";
        String authToken = "token";

        // Simulate unexpected exception
        doThrow(new RuntimeException("Unexpected")).when(service).normalizeFolderId(folderId);

        HVWException ex = assertThrows(HVWException.class, () ->
                service.createFormLayouts(folderId, "help", authToken, true));

        assertTrue(ex.getMessage().contains("Unexpected"));
        assertEquals(503, ex.getReturnCode());
    }

    @Test
    void testTransformFieldsFromDetailFormat_SuccessWithPostingDateAndUploadForm() {
        // Given
        Map<String, Object> response = new HashMap<>();
        List<Map<String, Object>> fieldList = new ArrayList<>();

        Map<String, Object> field = new HashMap<>();
        field.put("name", "POSTING DATE");
        field.put("defaultValueAvailable", true);
        field.put("searchValues", List.of("2023-01-01", "2023-01-31"));
        field.put("maxEntryChars", 20);

        fieldList.add(field);
        response.put("folderSearchCriteria", fieldList);

        Map<String, List<String>> dateValues = new HashMap<>();

        // When
        List<ReportChild> result = service.transformFieldsFromDetailFormat(response, "folderABC", dateValues, true);

        // Then
        assertEquals(1, result.size());
        ReportChild rc = result.get(0);
        assertEquals("POSTING DATE", rc.getId());
        assertEquals("POSTING DATE", rc.getName());
        assertEquals(20, rc.getMaxLength());
        assertEquals("text", rc.getInputType());

        assertTrue(dateValues.containsKey("POSTING DATE"));
        assertEquals(List.of("2023-01-01", "2023-01-31"), dateValues.get("POSTING DATE"));
    }

    @Test
    void testTransformFieldsFromDetailFormat_ExcludesPostingDateIfNotUploadForm() {
        // Given
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> field = new HashMap<>();
        field.put("name", "POSTING DATE");
        field.put("defaultValueAvailable", true);
        field.put("searchValues", List.of("2023-01-01", "2023-01-31"));
        response.put("folderSearchCriteria", List.of(field));

        Map<String, List<String>> dateValues = new HashMap<>();

        // When
        List<ReportChild> result = service.transformFieldsFromDetailFormat(response, "folderABC", dateValues, false);

        // Then
        assertEquals(0, result.size(), "POSTING DATE should be excluded when not an upload form.");
        assertTrue(dateValues.containsKey("POSTING DATE"));
    }

    @Test
    void testTransformFieldsFromDetailFormat_MissingFolderSearchCriteria_Throws() {
        Map<String, Object> response = new HashMap<>();
        HVWException ex = assertThrows(HVWException.class, () ->
                service.transformFieldsFromDetailFormat(response, "folder", new HashMap<>(), true)
        );
        assertEquals(503, ex.getReturnCode());
        assertTrue(ex.getMessage().contains("Missing folderSearchCriteria"));
    }

    @Test
    void testTransformFieldsFromDetailFormat_NullResponse_Throws() {
        HVWException ex = assertThrows(HVWException.class, () ->
                service.transformFieldsFromDetailFormat(null, "folder", new HashMap<>(), true)
        );
        assertEquals(503, ex.getReturnCode());
        assertTrue(ex.getMessage().contains("Null response body"));
    }

    @Test
    void testTransformFieldsFromDetailFormat_EmptyFields_Throws404() {
        Map<String, Object> response = new HashMap<>();
        response.put("folderSearchCriteria", List.of());

        HVWException ex = assertThrows(HVWException.class, () ->
                service.transformFieldsFromDetailFormat(response, "folder", new HashMap<>(), true)
        );

        assertEquals(404, ex.getReturnCode());
        assertTrue(ex.getMessage().contains("No field criteria found"));
    }

    @Test
    void testTransformFieldsFromDetailFormat_FieldWithNullName_Skipped() {
        Map<String, Object> response = new HashMap<>();
        Map<String, Object> field = new HashMap<>();
        field.put("name", null);
        response.put("folderSearchCriteria", List.of(field));

        List<ReportChild> result = service.transformFieldsFromDetailFormat(response, "folder", new HashMap<>(), true);
        assertEquals(0, result.size(), "Field with null name should be skipped");
    }


}
