package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyMap;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class ImageServiceTest {
    @InjectMocks
    private ImageService imageService;

    @Mock
    private RestClientUtil restClientUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        imageService.allImagesUrl = "http://test-api/images";
        imageService.downloadUrl = "http://test-api/download";
        imageService.copyToFolderUrl = "http://test-api/copy";
    }

    @Test
    void testGetImagesListObja_success() throws IOException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("filetab", "tab1");
        otherFields.put("startdate", "20230101");
        otherFields.put("enddate", "20231231");
        otherFields.put("showdeleted", "false");

        Map<String, Object> doc1 = new HashMap<>();
        doc1.put("fileTab", "tab1");
        doc1.put("receivedDate", "2023-05-01");
        doc1.put("objectUserStatus", "0");

        Map<String, Object> doc2 = new HashMap<>();
        doc2.put("fileTab", "tab2");
        doc2.put("receivedDate", "2023-06-01");
        doc2.put("objectUserStatus", "0");

        List<Map<String, Object>> documentData = Arrays.asList(doc1, doc2);

        Map<String, Object> imageListData = new HashMap<>();
        imageListData.put("documentData", documentData);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("imageListData", imageListData);

        ResponseEntity<Map> fakeResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap())).thenReturn(fakeResponse);

    ResponseEntity<Object> response = imageService.getImagesListObja(otherFields, "fakeAuthToken");
    assertEquals(HttpStatus.OK, response.getStatusCode());
    @SuppressWarnings("unchecked")
    Map<String, Object> respBody = (Map<String, Object>) response.getBody();
    assertNotNull(respBody);
    assertTrue(respBody.containsKey("data"));
    assertTrue(respBody.containsKey("counts"));
    List<Map<String, Object>> data = (List<Map<String, Object>>) respBody.get("data");
    Map<String, Object> counts = (Map<String, Object>) respBody.get("counts");
    assertEquals(1, data.size()); // only doc1 matches fileTab filter
    Map<String, Object> firstDoc = data.get(0);
    assertTrue(firstDoc.containsKey("action"));
    assertNotNull(firstDoc.get("action"));
    assertEquals(2, counts.get("total"));
    assertEquals(0, counts.get("secured"));
    assertEquals(0, counts.get("deleted"));
    // filtered = total - data.size() - secured - deleted
    assertEquals(1, counts.get("filtered"));
    }

    @Test
    void testDownload_withValidDocumentToken_returnsResponse() {
        String token = "validToken";
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", token);

        byte[] fakeData = "dummy".getBytes();
        ByteArrayResource resource = new ByteArrayResource(fakeData);
        ResponseEntity<ByteArrayResource> fakeResponse = new ResponseEntity<>(resource, HttpStatus.OK);

        when(restClientUtil.postRequestForBinary(anyString(), anyString(), anyMap())).thenReturn(fakeResponse);

        ResponseEntity<ByteArrayResource> response = imageService.download(otherFields, "authToken");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertArrayEquals(fakeData, response.getBody().getByteArray());
    }

    @Test
    void testDownload_withEmptyDocumentToken_throwsException() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "  ");

        HVWException ex = assertThrows(com.hmhs.hvwmid.exceptions.HVWException.class,
                () -> imageService.download(otherFields, "authToken"));

        assertEquals("Document token cannot be null or empty", ex.getMessage());
    }

    @Test
    void testFilterResults_filtersCorrectly() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("filetab", "tab1");
        otherFields.put("startdate", "20230101");
        otherFields.put("enddate", "20231231");
        otherFields.put("showdeleted", "false");

        Map<String, Object> doc1 = new HashMap<>();
        doc1.put("fileTab", "tab1");
        doc1.put("receivedDate", "2023-05-01");
        doc1.put("objectUserStatus", "0");

        Map<String, Object> doc2 = new HashMap<>();
        doc2.put("fileTab", "tab1");
        doc2.put("receivedDate", "2022-12-31");
        doc2.put("objectUserStatus", "0");

        Map<String, Object> doc3 = new HashMap<>();
        doc3.put("fileTab", "tab1");
        doc3.put("receivedDate", "2023-05-01");
        doc3.put("objectUserStatus", "1"); // deleted

        List<Map<String, Object>> input = Arrays.asList(doc1, doc2, doc3);

        List<Map<String, Object>> filtered =
                ImageService.filterResults(otherFields, input);

        assertEquals(1, filtered.size());
        assertEquals(doc1, filtered.get(0));
    }

    @Test
    void testGetImagesListObj2_buildsExtendedRequestCorrectly() throws IOException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("field1", "value1");
        otherFields.put("field2", "value2");
        otherFields.put("field3", "value3");
        otherFields.put("field4", "value4");
        otherFields.put("applidcd", "app123");

        Map<String, Object> doc = new HashMap<>();
        doc.put("fileTab", "tab1");
        doc.put("receivedDate", "2023-01-01");
        doc.put("objectUserStatus", "0");

        List<Map<String, Object>> documentData = List.of(doc);

        Map<String, Object> imageListData = new HashMap<>();
        imageListData.put("documentData", documentData);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("imageListData", imageListData);

        ResponseEntity<Map> fakeResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);
        // Mock the 4-argument version to avoid null response
        when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap())).thenReturn(fakeResponse);

    ResponseEntity<Object> response = imageService.getImagesListObj2(otherFields, "authToken");
    assertEquals(HttpStatus.OK, response.getStatusCode());
    @SuppressWarnings("unchecked")
    Map<String, Object> respBody = (Map<String, Object>) response.getBody();
    assertNotNull(respBody);
    assertTrue(respBody.containsKey("data"));
    assertTrue(respBody.containsKey("counts"));
    List<Map<String, Object>> data = (List<Map<String, Object>>) respBody.get("data");
    Map<String, Object> counts = (Map<String, Object>) respBody.get("counts");
    assertEquals(1, data.size());
    assertEquals(1, counts.get("total"));
    assertEquals(0, counts.get("secured"));
    assertEquals(0, counts.get("deleted"));
    assertEquals(0, counts.get("filtered"));

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, Object>> requestCaptor = ArgumentCaptor.forClass((Class<Map<String, Object>>) (Class<?>) Map.class);
        verify(restClientUtil).postRequest(eq(imageService.allImagesUrl), eq("authToken"), requestCaptor.capture(), anyMap());

        Map<String, Object> capturedRequest = requestCaptor.getValue();

        assertEquals("value1", capturedRequest.get("key1")); // from field1
        assertEquals("value2", capturedRequest.get("key2")); // from field2
        assertEquals("value3", capturedRequest.get("key3")); // from field3
        assertEquals("value4", capturedRequest.get("key4")); // from field4
        assertEquals("app123", capturedRequest.get("applIdcd"));
        assertEquals("true", capturedRequest.get("searchSecondaryIndexMetaData"));

        assertNull(capturedRequest.get("key5"));
    }

    @Test
    void testCopy2folder_SuccessfulResponse() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "doc123");
        otherFields.put("objectUserStatus", "userABC");
        otherFields.put("destinationFolder", "folder1; folder2 ;folder3");
        otherFields.put("action", "copy");
        String authToken = "Bearer token";

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("key", "value");

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restClientUtil.postRequest(eq(imageService.copyToFolderUrl), eq(authToken), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = imageService.copy2folder(otherFields, authToken);

        verify(restClientUtil).postRequest(eq(imageService.copyToFolderUrl), eq(authToken), anyMap());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(responseBody, response.getBody());
    }

    @Test
    void testCopy2folder_Non2xxResponse() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "doc123");
        otherFields.put("objectUserStatus", "userABC");
        otherFields.put("destinationFolder", "folder1;folder2");
        otherFields.put("action", "copy");
        String authToken = "Bearer token";

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("error", "some error");

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST);

        when(restClientUtil.postRequest(eq(imageService.copyToFolderUrl), eq(authToken), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = imageService.copy2folder(otherFields, authToken);

        verify(restClientUtil).postRequest(eq(imageService.copyToFolderUrl), eq(authToken), anyMap());

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(responseBody, response.getBody());
    }

    @Test
    void testCopy2folder_EmptyDestinationFolder() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "doc123");
        otherFields.put("objectUserStatus", "userABC");
        otherFields.put("destinationFolder", " ; ; ");
        otherFields.put("action", "copy");
        String authToken = "Bearer token";

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("key", "value");

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restClientUtil.postRequest(eq(imageService.copyToFolderUrl), eq(authToken), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = imageService.copy2folder(otherFields, authToken);

        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String, Object>> captor = ArgumentCaptor.forClass((Class<Map<String, Object>>) (Class<?>) Map.class);
        verify(restClientUtil).postRequest(eq(imageService.copyToFolderUrl), eq(authToken), captor.capture());

        Map<String, Object> sentBody = captor.getValue();
        @SuppressWarnings("unchecked")
        Map<String, Object> targetMap = (Map<String, Object>) sentBody.get("target");
        @SuppressWarnings("unchecked")
        List<String> foldIds = (List<String>) targetMap.get("targetFoldIds");

        assertTrue(foldIds.isEmpty());

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(responseBody, response.getBody());
    }

    @Test
    void testValidateAndGetData_Success() throws Exception {
        Map<String, Object> document1 = Map.of("docId", 1);
        Map<String, Object> document2 = Map.of("docId", 2);

        List<Map<String, Object>> documentData = Arrays.asList(document1, document2);
        Map<String, Object> imageListData = new HashMap<>();
        imageListData.put("documentData", documentData);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("imageListData", imageListData);

        ResponseEntity<Map> response = new ResponseEntity<>(responseBody, HttpStatus.OK);

        Method method = ImageService.class.getDeclaredMethod("validateAndGetData", ResponseEntity.class);
        method.setAccessible(true);

        List<Map<String, Object>> result = (List<Map<String, Object>>) method.invoke(imageService, response);

        assertEquals(2, result.size());
        assertEquals(document1, result.get(0));
        assertEquals(document2, result.get(1));
    }

    @Test
    void testValidateAndGetData_Success_NoDocumentData() throws Exception {
        Map<String, Object> imageListData = new HashMap<>();
        imageListData.put("documentData", null);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("imageListData", imageListData);

        ResponseEntity<Map> response = new ResponseEntity<>(responseBody, HttpStatus.OK);

        Method method = ImageService.class.getDeclaredMethod("validateAndGetData", ResponseEntity.class);
        method.setAccessible(true);

        List<Map<String, Object>> result = (List<Map<String, Object>>) method.invoke(imageService, response);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testValidateAndGetData_NullResponseBody() {
        Map<String, Object> responseBody = null;
        ResponseEntity<Map> response = new ResponseEntity<>(responseBody, HttpStatus.OK);

        HVWException thrown = assertThrows(HVWException.class, () -> {
            imageService.validateAndGetData(response);
        });

        assertEquals(503, thrown.getReturnCode());
        assertEquals("Empty response received from report service", thrown.getMessage());
    }

    @Test
    void testValidateAndGetData_NoImageListData() {
        Map<String, Object> responseBody = new HashMap<>();
        ResponseEntity<Map> response = new ResponseEntity<>(responseBody, HttpStatus.OK);

        HVWException thrown = assertThrows(HVWException.class, () -> {
            imageService.validateAndGetData(response);
        });

        assertEquals(503, thrown.getReturnCode());
        assertEquals("No imageListData in response", thrown.getMessage());
    }

    @Test
    void testValidateAndGetData_Non2xxResponse() {
        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("error", "fail");
        ResponseEntity<Map> response = new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST);

        HVWException thrown = assertThrows(HVWException.class, () -> {
            imageService.validateAndGetData(response);
        });

        assertNotNull(thrown);
    }
        @Test
    void testGetImagesListObj2a_success() throws IOException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("fieldA", "valueA");
        otherFields.put("applidcd", "app456");

        Map<String, Object> doc = new HashMap<>();
        doc.put("fileTab", "tabA");
        doc.put("receivedDate", "2024-01-01");
        doc.put("objectUserStatus", "0");

        List<Map<String, Object>> documentData = List.of(doc);
        Map<String, Object> imageListData = new HashMap<>();
        imageListData.put("documentData", documentData);
        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("imageListData", imageListData);

        ResponseEntity<Map> fakeResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);
        when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap())).thenReturn(fakeResponse);

        ResponseEntity<Object> response = imageService.getImagesListObj2(otherFields, "authToken2a");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        @SuppressWarnings("unchecked")
        Map<String, Object> respBody = (Map<String, Object>) response.getBody();
        assertNotNull(respBody);
        assertTrue(respBody.containsKey("data"));
        assertTrue(respBody.containsKey("counts"));
        List<Map<String, Object>> data = (List<Map<String, Object>>) respBody.get("data");
        Map<String, Object> counts = (Map<String, Object>) respBody.get("counts");
        assertEquals(1, data.size());
        Map<String, Object> resultDoc = data.get(0);
        assertEquals("tabA", resultDoc.get("fileTab"));
        assertEquals("0", resultDoc.get("objectUserStatus"));
        assertEquals("2024-01-01", resultDoc.get("receivedDate"));
        assertTrue(resultDoc.containsKey("action"));
        assertEquals(1, counts.get("total"));
        assertEquals(0, counts.get("secured"));
        assertEquals(0, counts.get("deleted"));
        assertEquals(0, counts.get("filtered"));

    }

    @Test
    void testGetImagesListObja_securedAndDeletedCounts() throws IOException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("filetab", "tab1");
        otherFields.put("startdate", "20230101");
        otherFields.put("enddate", "20231231");
        otherFields.put("showdeleted", "false");

        Map<String, Object> doc1 = new HashMap<>();
        doc1.put("fileTab", "tab1");
        doc1.put("receivedDate", "2023-05-01");
        doc1.put("objectUserStatus", "0");

        Map<String, Object> doc2 = new HashMap<>();
        doc2.put("fileTab", "tab1");
        doc2.put("receivedDate", "2023-06-01");
        doc2.put("objectUserStatus", "1"); // deleted

        Map<String, Object> doc3 = new HashMap<>();
        doc3.put("fileTab", "tab1");
        doc3.put("receivedDate", "2023-07-01");
        doc3.put("objectUserStatus", "0");
        doc3.put("secure", "yes"); // secured

        List<Map<String, Object>> documentData = Arrays.asList(doc1, doc2, doc3);

        Map<String, Object> imageListData = new HashMap<>();
        imageListData.put("documentData", documentData);

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("imageListData", imageListData);

        ResponseEntity<Map> fakeResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);
        when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap())).thenReturn(fakeResponse);

        ResponseEntity<Object> response = imageService.getImagesListObja(otherFields, "fakeAuthToken");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        @SuppressWarnings("unchecked")
        Map<String, Object> respBody = (Map<String, Object>) response.getBody();
        assertNotNull(respBody);
        assertTrue(respBody.containsKey("data"));
        assertTrue(respBody.containsKey("counts"));
        List<Map<String, Object>> data = (List<Map<String, Object>>) respBody.get("data");
        Map<String, Object> counts = (Map<String, Object>) respBody.get("counts");
        // Only doc1 should remain (doc2 is deleted, doc3 is secured)
        assertEquals(1, data.size());
        assertEquals(doc1.get("fileTab"), data.get(0).get("fileTab"));
        assertEquals(3, counts.get("total"));
        assertEquals(1, counts.get("secured"));
        assertEquals(1, counts.get("deleted"));
        assertEquals(0, counts.get("filtered"));
    }


    @Test
    void testDeleteRestore_successResponse() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "doc123");
        otherFields.put("objectUserStatus", "user456");
        otherFields.put("userStat", "1");

        Map<String, Object> expectedBody = new HashMap<>();
        expectedBody.put("message", "Restored successfully");

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(expectedBody, HttpStatus.OK);

        when(restClientUtil.postRequest(eq(imageService.deleteRestoreUrl), eq("Bearer token"), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = imageService.deleteRestore(otherFields, "Bearer token");

        verify(restClientUtil).postRequest(eq(imageService.deleteRestoreUrl), eq("Bearer token"), anyMap());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedBody, response.getBody());
    }

    @Test
    void testDeleteRestore_non2xxResponse() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "doc123");
        otherFields.put("objectUserStatus", "user456");
        otherFields.put("userStat", "1");

        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("error", "Bad request");

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);

        when(restClientUtil.postRequest(eq(imageService.deleteRestoreUrl), eq("Bearer token"), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> response = imageService.deleteRestore(otherFields, "Bearer token");

        verify(restClientUtil).postRequest(eq(imageService.deleteRestoreUrl), eq("Bearer token"), anyMap());
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(errorBody, response.getBody());
    }

    @Test
    void testDeleteRestore_requestBodyConstruction() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("documentToken", "docXYZ");
        otherFields.put("objectUserStatus", "user789");
        otherFields.put("userStat", "0");

        Map<String, Object> expectedResponse = new HashMap<>();
        expectedResponse.put("result", "ok");

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(expectedResponse, HttpStatus.OK);

        ArgumentCaptor<Map<String, Object>> requestBodyCaptor = ArgumentCaptor.forClass(Map.class);
        when(restClientUtil.postRequest(eq(imageService.deleteRestoreUrl), eq("Bearer token"), requestBodyCaptor.capture()))
                .thenReturn(mockResponse);

        imageService.deleteRestore(otherFields, "Bearer token");

        Map<String, Object> capturedBody = requestBodyCaptor.getValue();

        assertEquals("docXYZ", capturedBody.get("documentToken"));
       // assertEquals("user789", capturedBody.get("initiatingUserId"));
        assertEquals("0", capturedBody.get("userStat"));
    }

}