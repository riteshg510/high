package com.hmhs.hvwmid.model;

import static org.junit.jupiter.api.Assertions.*;
import com.hmhs.hvwmid.model.*;
import com.hmhs.hvwmid.entity.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CoversheetMapperTest {

    @Test
    void testCoverSheetMapping() {
        CoverSheetDTO dto = new CoverSheetDTO();
        dto.setApplication(1);
        dto.setName("COV01");
        dto.setDescription("Main Coversheet");
        dto.setEnvironment("INTA");
        dto.setActive("Y");

        T117ImgCoverSheet entity = CoversheetMapper.toEntity(dto);
        CoverSheetDTO result = CoversheetMapper.toDTO(entity);

        assertEquals(dto.getApplication(), result.getApplication());
        assertEquals(dto.getName(), result.getName());
        assertEquals(dto.getDescription(), result.getDescription());
        assertEquals(dto.getEnvironment(), result.getEnvironment());
        assertEquals(dto.getActive(), result.getActive());
    }

    @Test
    void testCoverSheetOverrideMapping() {
        CoverSheetOverrideDTO dto = new CoverSheetOverrideDTO();
        dto.setApplication(2);
        dto.setName("OVR01");
        dto.setSequence(1);
        dto.setTitle("Override Title");
        dto.setActive("Y");

        T117ImgCoverSheetOverride entity = CoversheetMapper.toEntity(dto);
        CoverSheetOverrideDTO result = CoversheetMapper.toDTO(entity);

        assertEquals(dto.getApplication(), result.getApplication());
        assertEquals(dto.getName(), result.getName());
        assertEquals(dto.getSequence(), result.getSequence());
        assertEquals(dto.getTitle(), result.getTitle());
        assertEquals(dto.getActive(), result.getActive());
    }

    @Test
    void testCoverSheetApplicationMapping() {
        CoverSheetApplicationDTO dto = new CoverSheetApplicationDTO();
        dto.setApplication(3);
        dto.setDescription("Finance");
        dto.setSequence(10);
        dto.setDeptId(new T117ImgCoverDept(1, "Finance Dept", "Finance Maint", "Finance Print"));
        dto.setActive("Y");
        dto.setApplId("FIN01");

        T117ImgCoverAppl entity = CoversheetMapper.toEntity(dto);
        CoverSheetApplicationDTO result = CoversheetMapper.toDTO(entity);

        assertEquals(dto.getApplication(), result.getApplication());
        assertEquals(dto.getDescription(), result.getDescription());
        assertEquals(dto.getSequence(), result.getSequence());
        assertEquals(dto.getDeptId().getDeptId(), 1);
        assertEquals(dto.getActive(), result.getActive());
        assertEquals(dto.getApplId(), result.getApplId());
    }
}
