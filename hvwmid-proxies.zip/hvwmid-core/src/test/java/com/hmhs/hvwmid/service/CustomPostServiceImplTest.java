package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.model.ImageDataModel;
import com.hmhs.hvwmid.repository.ImageDataRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class CustomPostServiceImplTest {

    @Mock
    private ImageDataRepository imageDataRepo;

    @InjectMocks
    private CustomPostServiceImpl customPostService;

    private ImageDataModel inputData;
    private List<ImageData> imageDataList;

    @BeforeEach
    void setUp() {
        inputData = new ImageDataModel();
        inputData.setApplid("app1");

        imageDataList = Arrays.asList(
                new ImageData(12321312L, "app1"),
                new ImageData(12325446L, "app1")
        );
    }

    @Test
    void getViewImageData_ShouldReturnImageData_WhenApplicationIdIsProvided() {
        when(imageDataRepo.findImageDataByApplicationId(inputData)).thenReturn(imageDataList);

        List<ImageData> result = customPostService.getViewImageData(inputData);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(12321312L, result.get(0).getId());
        verify(imageDataRepo, times(1)).findImageDataByApplicationId(inputData);
    }

    @Test
    void getViewImageData_ShouldReturnEmptyList_WhenNoDataFound() {
        when(imageDataRepo.findImageDataByApplicationId(inputData)).thenReturn(Arrays.asList());

        List<ImageData> result = customPostService.getViewImageData(inputData);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(imageDataRepo, times(1)).findImageDataByApplicationId(inputData);
    }

    @Test
    void getLookupValues_ShouldReturnApplicationIds_WhenFieldNameStartsWithAppl() {
        String fieldName = "applicationField";
        String lookupValue = "app";
        List<String> applicationIds = Arrays.asList("app1", "app2");

        when(imageDataRepo.getAllApplicationIdsSatrtsWith(lookupValue)).thenReturn(applicationIds);

        List<String> result = customPostService.getLookupValues(fieldName, lookupValue);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains("app1"));
        assertTrue(result.contains("app2"));
        verify(imageDataRepo, times(1)).getAllApplicationIdsSatrtsWith(lookupValue);
    }

    @Test
    void getLookupValues_ShouldReturnFolderIds_WhenFieldNameStartsWithFold() {
        String fieldName = "folderField";
        String lookupValue = "fold";
        List<String> folderIds = Arrays.asList("fold1", "fold2");

        when(imageDataRepo.getAllFolderIdsSatrtsWith(lookupValue)).thenReturn(folderIds);

        List<String> result = customPostService.getLookupValues(fieldName, lookupValue);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains("fold1"));
        assertTrue(result.contains("fold2"));
        verify(imageDataRepo, times(1)).getAllFolderIdsSatrtsWith(lookupValue);
    }

    @Test
    void getLookupValues_ShouldReturnEmptyList_WhenFieldNameDoesNotMatch() {
        String fieldName = "unknownField";
        String lookupValue = "xyz";

        List<String> result = customPostService.getLookupValues(fieldName, lookupValue);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(imageDataRepo, times(0)).getAllApplicationIdsSatrtsWith(lookupValue);
        verify(imageDataRepo, times(0)).getAllFolderIdsSatrtsWith(lookupValue);
    }
}
