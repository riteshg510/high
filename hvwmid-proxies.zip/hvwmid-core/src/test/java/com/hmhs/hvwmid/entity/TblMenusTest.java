package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TblMenusTest {

    private TblMenus tblMenus;

    @BeforeEach
    void setUp() {
        tblMenus = new TblMenus();
    }

    @Test
    void testSetAndGetMenuId() {
        String menuId = "menu123";
        tblMenus.setMenuId(menuId);
        assertEquals(menuId.toUpperCase(), tblMenus.getMenuId(), "MenuId should be converted to uppercase.");
    }

    @Test
    void testSetAndGetParentId() {
        String parentId = "parent123";
        tblMenus.setParentId(parentId);
        assertEquals(parentId.toUpperCase(), tblMenus.getParentId(), "ParentId should be converted to uppercase.");
    }


    @Test
    void testSetAndGetRoute() {
        String route = "/home";
        tblMenus.setRoute(route);
        assertEquals(route, tblMenus.getRoute(), "Route should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetSortOrder() {
        int sortOrder = 5;
        tblMenus.setSortOrder(sortOrder);
        assertEquals(sortOrder, tblMenus.getSortOrder(), "SortOrder value should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetType() {
        String type = "admin";
        tblMenus.setType(type);
        assertEquals(type.toLowerCase(), tblMenus.getType(), "Type should be converted to lowercase.");
    }

    @Test
    void testSetAndGetIsRoot() {
        tblMenus.setIsRoot(true);
        assertTrue(tblMenus.getIsRoot(), "IsRoot should return true.");

        tblMenus.setIsRoot(false);
        assertFalse(tblMenus.getIsRoot(), "IsRoot should return false.");
    }

    @Test
    void testMenuIdUpperCaseLogic() {
        String menuId = "MENU123";
        tblMenus.setMenuId(menuId);
        assertEquals(menuId, tblMenus.getMenuId(), "MenuId should remain the same if it's already uppercase.");
    }

    @Test
    void testParentIdUpperCaseLogic() {
        String parentId = "PARENT123";
        tblMenus.setParentId(parentId);
        assertEquals(parentId, tblMenus.getParentId(), "ParentId should remain the same if it's already uppercase.");
    }

    @Test
    void testTypeLowerCaseLogic() {
        String type = "admin";
        tblMenus.setType(type);
        assertEquals(type, tblMenus.getType(), "Type should remain the same if it's already lowercase.");
    }
}
