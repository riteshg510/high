package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.assertEquals;

class OdscrtTest {

    private Odscrt ods;

    @BeforeEach
    void setUp() {
        ods = new Odscrt();
    }

    @Test
    void testAgName() {
        String agName = "AgencyName";
        ods.setAgName(agName);
        assertEquals(agName, ods.getAgName());
    }

    @Test
    void testAppName() {
        String appName = "AppName";
        ods.setAppName(appName);
        assertEquals(appName, ods.getAppName());
    }

    @Test
    void testJob() {
        String job = "JOB12345";
        ods.setJob(job);
        assertEquals(job, ods.getJob());
    }

    @Test
    void testStep() {
        String step = "STEP001";
        ods.setStep(step);
        assertEquals(step, ods.getStep());
    }

    @Test
    void testProcStep() {
        String procStep = "PROC001";
        ods.setProcStep(procStep);
        assertEquals(procStep, ods.getProcStep());
    }

    @Test
    void testDd() {
        String dd = "DD001";
        ods.setDd(dd);
        assertEquals(dd, ods.getDd());
    }

    @Test
    void testForeignRid() {
        String foreignRid = "RID1234567890123456789012345";
        ods.setForeignRid(foreignRid);
        assertEquals(foreignRid, ods.getForeignRid());
    }

    @Test
    void testSNodeName() {
        String sNodeName = "NodeName01";
        ods.setsNodeName(sNodeName);
        assertEquals(sNodeName, ods.getsNodeName());
    }

    @Test
    void testTitle() {
        String title = "Test Title";
        ods.setTitle(title);
        assertEquals(title, ods.getTitle());
    }

    @Test
    void testIndex1() {
        String index1 = "Index One Value";
        ods.setIndex1(index1);
        assertEquals(index1, ods.getIndex1());
    }

    @Test
    void testIndex2() {
        String index2 = "Index Two Value";
        ods.setIndex2(index2);
        assertEquals(index2, ods.getIndex2());
    }

    @Test
    void testIndex3() {
        String index3 = "Index Three Value";
        ods.setIndex3(index3);
        assertEquals(index3, ods.getIndex3());
    }

    @Test
    void testUpdTs() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        ods.setUpdTs(now);
        assertEquals(now, ods.getUpdTs());
    }

    @Test
    void testUpdUserId() {
        String updUserId = "USR12345";
        ods.setUpdUserId(updUserId);
        assertEquals(updUserId, ods.getUpdUserId());
    }
}
