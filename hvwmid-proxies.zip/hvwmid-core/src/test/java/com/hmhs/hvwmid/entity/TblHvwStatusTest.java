package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TblHvwStatusTest {

    private TblHvwStatus status;

    @BeforeEach
    void setUp() {
        status = new TblHvwStatus();
        status.setId(new TblHvwStatusId(123, new Timestamp(System.currentTimeMillis())));
    }

    @Test
    void testRequestId() {
        int requestId = 456;
        status.setRequestId(requestId);
        assertEquals(requestId, status.getRequestId());
    }

    @Test
    void testImgRequestId() {
        int imgRequestId = 456;
        status.setImgRequestId(imgRequestId);
        assertEquals(imgRequestId, status.getImgRequestId());
    }

    @Test
    void testCodRequestId() {
        int codRequestId = 789;
        status.setCodRequestId(codRequestId);
        assertEquals(codRequestId, status.getCodRequestId());
    }

    @Test
    void testUserId() {
        String userId = "user123";
        status.setUserId(userId);
        assertEquals(userId, status.getUserId());
    }

    @Test
    void testTimeCreate() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        status.setTimeCreate(now);
        assertEquals(now, status.getTimeCreate());
    }

    @Test
    void testFunction() {
        String function = "TEST_FUNCTION";
        status.setFunction(function);
        assertEquals(function, status.getFunction());
    }

    @Test
    void testOriginalUrl() {
        String url = "http://example.com";
        status.setOriginalUrl(url);
        assertEquals(url, status.getOriginalUrl());
    }

    @Test
    void testStatusCode() {
        String code = "200_OK";
        status.setStatusCode(code);
        assertEquals(code, status.getStatusCode());
    }

    @Test
    void testStatusDescription() {
        String desc = "Operation completed successfully.";
        status.setStatusDescription(desc);
        assertEquals(desc, status.getStatusDescription());
    }
}
