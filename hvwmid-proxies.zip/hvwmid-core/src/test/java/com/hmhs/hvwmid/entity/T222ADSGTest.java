package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive test class for T222ADSG entity
 * Tests all getters, setters, and entity behavior
 * 
 * @author HighView Development Team
 * @since 1.0
 */
class T222ADSGTest {

    // Test constants to avoid string literal duplication
    private static final String REASON_01 = "REASON01";
    private static final String REASON_MAX_LENGTH = "12345678";
    private static final String REASON_7_CHARS = "1234567";
    private static final String REASON_WITH_DASH = "REASON-1";
    private static final String REASON_WITH_SPACE = "REASON 1";
    private static final String REASON_MIXED_CASE = "Reason01";
    private static final String TEST_SEGMENT_DATA = "This is test segment data";
    private static final String TEST_NUMERIC_DATA = "123456789";
    private static final String TEST_SPECIAL_CHARS_DATA = "Test data with !@#$%^&*()";
    private static final String TEST_MIXED_CASE_DATA = "Test Data With Mixed Case";

    private T222ADSG t222adsg;

    @BeforeEach
    void setUp() {
        t222adsg = new T222ADSG();
    }

    // ========== CONSTRUCTOR TESTS ==========

    @Test
    void testDefaultConstructor() {
        T222ADSG entity = new T222ADSG();
        assertNotNull(entity);
        assertNull(entity.getImiDocumentId());
        assertNull(entity.getSegmentSeqNo());
        assertNull(entity.getSegmentName());
        assertNull(entity.getSegmentStatusCode());
        assertNull(entity.getSegmentReasonCode());
        assertNull(entity.getSegmentData());
    }

    // ========== GETTER AND SETTER TESTS ==========

    @Test
    void testImiDocumentIdGetterAndSetter() {
        Integer imiDocumentId = 12345;
        t222adsg.setImiDocumentId(imiDocumentId);
        assertEquals(imiDocumentId, t222adsg.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithNull() {
        t222adsg.setImiDocumentId(null);
        assertNull(t222adsg.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithZero() {
        t222adsg.setImiDocumentId(0);
        assertEquals(0, t222adsg.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithNegativeValue() {
        t222adsg.setImiDocumentId(-1);
        assertEquals(-1, t222adsg.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithMaxValue() {
        t222adsg.setImiDocumentId(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, t222adsg.getImiDocumentId());
    }

    @Test
    void testImiDocumentIdWithMinValue() {
        t222adsg.setImiDocumentId(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, t222adsg.getImiDocumentId());
    }

    @Test
    void testSegmentSeqNoGetterAndSetter() {
        Integer segmentSeqNo = 1;
        t222adsg.setSegmentSeqNo(segmentSeqNo);
        assertEquals(segmentSeqNo, t222adsg.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithNull() {
        t222adsg.setSegmentSeqNo(null);
        assertNull(t222adsg.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithZero() {
        t222adsg.setSegmentSeqNo(0);
        assertEquals(0, t222adsg.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithNegativeValue() {
        t222adsg.setSegmentSeqNo(-1);
        assertEquals(-1, t222adsg.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithMaxValue() {
        t222adsg.setSegmentSeqNo(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, t222adsg.getSegmentSeqNo());
    }

    @Test
    void testSegmentSeqNoWithMinValue() {
        t222adsg.setSegmentSeqNo(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, t222adsg.getSegmentSeqNo());
    }

    @Test
    void testSegmentNameGetterAndSetter() {
        String segmentName = "ABC";
        t222adsg.setSegmentName(segmentName);
        assertEquals(segmentName, t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithNull() {
        t222adsg.setSegmentName(null);
        assertNull(t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithEmptyString() {
        t222adsg.setSegmentName("");
        assertEquals("", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithSingleCharacter() {
        t222adsg.setSegmentName("A");
        assertEquals("A", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithTwoCharacters() {
        t222adsg.setSegmentName("AB");
        assertEquals("AB", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithThreeCharacters() {
        t222adsg.setSegmentName("ABC");
        assertEquals("ABC", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithNumbers() {
        t222adsg.setSegmentName("123");
        assertEquals("123", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithSpecialCharacters() {
        t222adsg.setSegmentName("A-1");
        assertEquals("A-1", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithUnicodeCharacters() {
        t222adsg.setSegmentName("测试");
        assertEquals("测试", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithSpaces() {
        t222adsg.setSegmentName("A B");
        assertEquals("A B", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithUnderscores() {
        t222adsg.setSegmentName("A_B");
        assertEquals("A_B", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithDashes() {
        t222adsg.setSegmentName("A-B");
        assertEquals("A-B", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentNameWithMixedCase() {
        t222adsg.setSegmentName("AbC");
        assertEquals("AbC", t222adsg.getSegmentName());
    }

    @Test
    void testSegmentStatusCodeGetterAndSetter() {
        String segmentStatusCode = "A";
        t222adsg.setSegmentStatusCode(segmentStatusCode);
        assertEquals(segmentStatusCode, t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithNull() {
        t222adsg.setSegmentStatusCode(null);
        assertNull(t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithEmptyString() {
        t222adsg.setSegmentStatusCode("");
        assertEquals("", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithSingleCharacter() {
        t222adsg.setSegmentStatusCode("A");
        assertEquals("A", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithNumbers() {
        t222adsg.setSegmentStatusCode("1");
        assertEquals("1", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithSpecialCharacters() {
        t222adsg.setSegmentStatusCode("!");
        assertEquals("!", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithUnicodeCharacters() {
        t222adsg.setSegmentStatusCode("测");
        assertEquals("测", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithSpaces() {
        t222adsg.setSegmentStatusCode(" ");
        assertEquals(" ", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithUnderscores() {
        t222adsg.setSegmentStatusCode("_");
        assertEquals("_", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithDashes() {
        t222adsg.setSegmentStatusCode("-");
        assertEquals("-", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentStatusCodeWithMixedCase() {
        t222adsg.setSegmentStatusCode("a");
        assertEquals("a", t222adsg.getSegmentStatusCode());
    }

    @Test
    void testSegmentReasonCodeGetterAndSetter() {
        String segmentReasonCode = REASON_01;
        t222adsg.setSegmentReasonCode(segmentReasonCode);
        assertEquals(segmentReasonCode, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithNull() {
        t222adsg.setSegmentReasonCode(null);
        assertNull(t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithEmptyString() {
        t222adsg.setSegmentReasonCode("");
        assertEquals("", t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithSingleCharacter() {
        t222adsg.setSegmentReasonCode("R");
        assertEquals("R", t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithMaxLength() {
        t222adsg.setSegmentReasonCode(REASON_MAX_LENGTH);
        assertEquals(REASON_MAX_LENGTH, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithNumbers() {
        t222adsg.setSegmentReasonCode(REASON_7_CHARS);
        assertEquals(REASON_7_CHARS, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithSpecialCharacters() {
        t222adsg.setSegmentReasonCode(REASON_WITH_DASH);
        assertEquals(REASON_WITH_DASH, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithUnicodeCharacters() {
        t222adsg.setSegmentReasonCode("测试原因");
        assertEquals("测试原因", t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithSpaces() {
        t222adsg.setSegmentReasonCode(REASON_WITH_SPACE);
        assertEquals(REASON_WITH_SPACE, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithUnderscores() {
        t222adsg.setSegmentReasonCode("REASON_1");
        assertEquals("REASON_1", t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithDashes() {
        t222adsg.setSegmentReasonCode(REASON_WITH_DASH);
        assertEquals(REASON_WITH_DASH, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentReasonCodeWithMixedCase() {
        t222adsg.setSegmentReasonCode(REASON_MIXED_CASE);
        assertEquals(REASON_MIXED_CASE, t222adsg.getSegmentReasonCode());
    }

    @Test
    void testSegmentDataGetterAndSetter() {
        String segmentData = TEST_SEGMENT_DATA;
        t222adsg.setSegmentData(segmentData);
        assertEquals(segmentData, t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithNull() {
        t222adsg.setSegmentData(null);
        assertNull(t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithEmptyString() {
        t222adsg.setSegmentData("");
        assertEquals("", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithSingleCharacter() {
        t222adsg.setSegmentData("A");
        assertEquals("A", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithMaxLength() {
        String maxLengthData = "A".repeat(1024);
        t222adsg.setSegmentData(maxLengthData);
        assertEquals(maxLengthData, t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithNumbers() {
        t222adsg.setSegmentData(TEST_NUMERIC_DATA);
        assertEquals(TEST_NUMERIC_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithSpecialCharacters() {
        t222adsg.setSegmentData(TEST_SPECIAL_CHARS_DATA);
        assertEquals(TEST_SPECIAL_CHARS_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithUnicodeCharacters() {
        t222adsg.setSegmentData("测试数据内容");
        assertEquals("测试数据内容", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithSpaces() {
        t222adsg.setSegmentData("Test data with spaces");
        assertEquals("Test data with spaces", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithUnderscores() {
        t222adsg.setSegmentData("Test_data_with_underscores");
        assertEquals("Test_data_with_underscores", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithDashes() {
        t222adsg.setSegmentData("Test-data-with-dashes");
        assertEquals("Test-data-with-dashes", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithMixedCase() {
        t222adsg.setSegmentData(TEST_MIXED_CASE_DATA);
        assertEquals(TEST_MIXED_CASE_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithNewlinesAndTabs() {
        t222adsg.setSegmentData("Test data\nwith\ttabs");
        assertEquals("Test data\nwith\ttabs", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithJsonLikeContent() {
        t222adsg.setSegmentData("{\"field\": \"value\", \"number\": 123}");
        assertEquals("{\"field\": \"value\", \"number\": 123}", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithXmlLikeContent() {
        t222adsg.setSegmentData("<segment><field>value</field></segment>");
        assertEquals("<segment><field>value</field></segment>", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithHtmlLikeContent() {
        t222adsg.setSegmentData("<html><body><h1>Test</h1></body></html>");
        assertEquals("<html><body><h1>Test</h1></body></html>", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithSqlLikeContent() {
        t222adsg.setSegmentData("SELECT * FROM table WHERE id = 1");
        assertEquals("SELECT * FROM table WHERE id = 1", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithUrlLikeContent() {
        t222adsg.setSegmentData("https://example.com/api/endpoint");
        assertEquals("https://example.com/api/endpoint", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithEmailLikeContent() {
        t222adsg.setSegmentData("test@example.com");
        assertEquals("test@example.com", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithUuidLikeContent() {
        t222adsg.setSegmentData("550e8400-e29b-41d4-a716-446655440000");
        assertEquals("550e8400-e29b-41d4-a716-446655440000", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithBase64LikeContent() {
        t222adsg.setSegmentData("VGVzdCBkYXRh");
        assertEquals("VGVzdCBkYXRh", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithRegexLikeContent() {
        t222adsg.setSegmentData("^[a-zA-Z0-9_.-]+$");
        assertEquals("^[a-zA-Z0-9_.-]+$", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithPathLikeContent() {
        t222adsg.setSegmentData("/path/to/file.txt");
        assertEquals("/path/to/file.txt", t222adsg.getSegmentData());
    }

    @Test
    void testSegmentDataWithQueryStringLikeContent() {
        t222adsg.setSegmentData("name=value&id=123&type=test");
        assertEquals("name=value&id=123&type=test", t222adsg.getSegmentData());
    }

    // ========== INTEGRATION TESTS ==========

    @Test
    void testCompleteT222ADSGSetup() {
        // Set all fields with sample data
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("ABC");
        t222adsg.setSegmentStatusCode("A");
        t222adsg.setSegmentReasonCode(REASON_01);
        t222adsg.setSegmentData(TEST_SEGMENT_DATA);

        // Verify all fields are set correctly
        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("ABC", t222adsg.getSegmentName());
        assertEquals("A", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_01, t222adsg.getSegmentReasonCode());
        assertEquals(TEST_SEGMENT_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithAllNullValues() {
        t222adsg.setImiDocumentId(null);
        t222adsg.setSegmentSeqNo(null);
        t222adsg.setSegmentName(null);
        t222adsg.setSegmentStatusCode(null);
        t222adsg.setSegmentReasonCode(null);
        t222adsg.setSegmentData(null);

        assertNull(t222adsg.getImiDocumentId());
        assertNull(t222adsg.getSegmentSeqNo());
        assertNull(t222adsg.getSegmentName());
        assertNull(t222adsg.getSegmentStatusCode());
        assertNull(t222adsg.getSegmentReasonCode());
        assertNull(t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithAllEmptyValues() {
        t222adsg.setImiDocumentId(0);
        t222adsg.setSegmentSeqNo(0);
        t222adsg.setSegmentName("");
        t222adsg.setSegmentStatusCode("");
        t222adsg.setSegmentReasonCode("");
        t222adsg.setSegmentData("");

        assertEquals(0, t222adsg.getImiDocumentId());
        assertEquals(0, t222adsg.getSegmentSeqNo());
        assertEquals("", t222adsg.getSegmentName());
        assertEquals("", t222adsg.getSegmentStatusCode());
        assertEquals("", t222adsg.getSegmentReasonCode());
        assertEquals("", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithErrorScenario() {
        t222adsg.setImiDocumentId(-1);
        t222adsg.setSegmentSeqNo(-1);
        t222adsg.setSegmentName("ERR");
        t222adsg.setSegmentStatusCode("E");
        t222adsg.setSegmentReasonCode("ERROR001");
        t222adsg.setSegmentData("Error: Invalid segment data");

        assertEquals(-1, t222adsg.getImiDocumentId());
        assertEquals(-1, t222adsg.getSegmentSeqNo());
        assertEquals("ERR", t222adsg.getSegmentName());
        assertEquals("E", t222adsg.getSegmentStatusCode());
        assertEquals("ERROR001", t222adsg.getSegmentReasonCode());
        assertEquals("Error: Invalid segment data", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithMaxValues() {
        t222adsg.setImiDocumentId(Integer.MAX_VALUE);
        t222adsg.setSegmentSeqNo(Integer.MAX_VALUE);
        t222adsg.setSegmentName("ZZZ");
        t222adsg.setSegmentStatusCode("Z");
        t222adsg.setSegmentReasonCode(REASON_MAX_LENGTH);
        t222adsg.setSegmentData("A".repeat(1024));

        assertEquals(Integer.MAX_VALUE, t222adsg.getImiDocumentId());
        assertEquals(Integer.MAX_VALUE, t222adsg.getSegmentSeqNo());
        assertEquals("ZZZ", t222adsg.getSegmentName());
        assertEquals("Z", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_MAX_LENGTH, t222adsg.getSegmentReasonCode());
        assertEquals("A".repeat(1024), t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithMinValues() {
        t222adsg.setImiDocumentId(Integer.MIN_VALUE);
        t222adsg.setSegmentSeqNo(Integer.MIN_VALUE);
        t222adsg.setSegmentName("AAA");
        t222adsg.setSegmentStatusCode("A");
        t222adsg.setSegmentReasonCode("00000000");
        t222adsg.setSegmentData("A");

        assertEquals(Integer.MIN_VALUE, t222adsg.getImiDocumentId());
        assertEquals(Integer.MIN_VALUE, t222adsg.getSegmentSeqNo());
        assertEquals("AAA", t222adsg.getSegmentName());
        assertEquals("A", t222adsg.getSegmentStatusCode());
        assertEquals("00000000", t222adsg.getSegmentReasonCode());
        assertEquals("A", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithPartialData() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("ABC");
        t222adsg.setSegmentStatusCode("A");
        // Leave reason code and data as null

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("ABC", t222adsg.getSegmentName());
        assertEquals("A", t222adsg.getSegmentStatusCode());
        assertNull(t222adsg.getSegmentReasonCode());
        assertNull(t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithDifferentDataTypes() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("ABC");
        t222adsg.setSegmentStatusCode("A");
        t222adsg.setSegmentReasonCode(REASON_01);
        t222adsg.setSegmentData("{\"type\": \"json\", \"value\": 123, \"active\": true}");

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("ABC", t222adsg.getSegmentName());
        assertEquals("A", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_01, t222adsg.getSegmentReasonCode());
        assertEquals("{\"type\": \"json\", \"value\": 123, \"active\": true}", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithUnicodeData() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("测试");
        t222adsg.setSegmentStatusCode("测");
        t222adsg.setSegmentReasonCode("测试原因");
        t222adsg.setSegmentData("这是测试数据内容");

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("测试", t222adsg.getSegmentName());
        assertEquals("测", t222adsg.getSegmentStatusCode());
        assertEquals("测试原因", t222adsg.getSegmentReasonCode());
        assertEquals("这是测试数据内容", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithSpecialCharacters() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("A-1");
        t222adsg.setSegmentStatusCode("!");
        t222adsg.setSegmentReasonCode(REASON_WITH_DASH);
        t222adsg.setSegmentData(TEST_SPECIAL_CHARS_DATA);

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("A-1", t222adsg.getSegmentName());
        assertEquals("!", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_WITH_DASH, t222adsg.getSegmentReasonCode());
        assertEquals(TEST_SPECIAL_CHARS_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithWhitespaceData() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("A B");
        t222adsg.setSegmentStatusCode(" ");
        t222adsg.setSegmentReasonCode(REASON_WITH_SPACE);
        t222adsg.setSegmentData("Test data with spaces and\ttabs");

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("A B", t222adsg.getSegmentName());
        assertEquals(" ", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_WITH_SPACE, t222adsg.getSegmentReasonCode());
        assertEquals("Test data with spaces and\ttabs", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithNumericData() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("123");
        t222adsg.setSegmentStatusCode("1");
        t222adsg.setSegmentReasonCode(REASON_7_CHARS);
        t222adsg.setSegmentData(TEST_NUMERIC_DATA);

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("123", t222adsg.getSegmentName());
        assertEquals("1", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_7_CHARS, t222adsg.getSegmentReasonCode());
        assertEquals(TEST_NUMERIC_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithMixedCaseData() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("AbC");
        t222adsg.setSegmentStatusCode("a");
        t222adsg.setSegmentReasonCode(REASON_MIXED_CASE);
        t222adsg.setSegmentData(TEST_MIXED_CASE_DATA);

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("AbC", t222adsg.getSegmentName());
        assertEquals("a", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_MIXED_CASE, t222adsg.getSegmentReasonCode());
        assertEquals(TEST_MIXED_CASE_DATA, t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithBoundaryValues() {
        t222adsg.setImiDocumentId(0);
        t222adsg.setSegmentSeqNo(0);
        t222adsg.setSegmentName("A");
        t222adsg.setSegmentStatusCode("A");
        t222adsg.setSegmentReasonCode("R");
        t222adsg.setSegmentData("A");

        assertEquals(0, t222adsg.getImiDocumentId());
        assertEquals(0, t222adsg.getSegmentSeqNo());
        assertEquals("A", t222adsg.getSegmentName());
        assertEquals("A", t222adsg.getSegmentStatusCode());
        assertEquals("R", t222adsg.getSegmentReasonCode());
        assertEquals("A", t222adsg.getSegmentData());
    }

    @Test
    void testT222ADSGWithComplexData() {
        t222adsg.setImiDocumentId(12345);
        t222adsg.setSegmentSeqNo(1);
        t222adsg.setSegmentName("ABC");
        t222adsg.setSegmentStatusCode("A");
        t222adsg.setSegmentReasonCode(REASON_01);
        t222adsg.setSegmentData("{\"segment\": {\"id\": 1, \"name\": \"ABC\", \"status\": \"A\", \"reason\": \"REASON01\", \"data\": \"This is complex segment data with special characters !@#$%^&*() and unicode 测试数据\"}}");

        assertEquals(12345, t222adsg.getImiDocumentId());
        assertEquals(1, t222adsg.getSegmentSeqNo());
        assertEquals("ABC", t222adsg.getSegmentName());
        assertEquals("A", t222adsg.getSegmentStatusCode());
        assertEquals(REASON_01, t222adsg.getSegmentReasonCode());
        assertEquals("{\"segment\": {\"id\": 1, \"name\": \"ABC\", \"status\": \"A\", \"reason\": \"REASON01\", \"data\": \"This is complex segment data with special characters !@#$%^&*() and unicode 测试数据\"}}", t222adsg.getSegmentData());
    }
}
