package com.hmhs.hvwmid.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for CMODSecurityAccessResponse DTO.
 * Tests response structure, constructor behavior, and navigation flag functionality.
 */
class CMODSecurityAccessResponseTest {

    @Test
    void testDefaultConstructor() {
        // Act
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();

        // Assert
        assertNotNull(response);
        assertNull(response.getFolderAccessMap());
        assertNull(response.getMissingRacfEntries());
        assertNull(response.getSaraPathInfo());
        assertNull(response.getUserGroups());
        assertNull(response.getTriageInfo());
        assertNull(response.getErrorMessage());
        assertFalse(response.isHasError());
        assertFalse(response.isCmodFolderNavigation()); // Default should be false
    }

    @Test
    void testSuccessConstructor() {
        // Arrange
        Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = createTestFolderAccessMap();
        Map<String, Set<String>> missingRacfEntries = createTestMissingRacfEntries();
        CMODSARAPathInfo saraPathInfo = createTestSARAPathInfo();
        String userGroups = "HMRK, NDAK";
        String triageInfo = "Contact admin for issues";

        // Act
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse(
            folderAccessMap, missingRacfEntries, saraPathInfo, userGroups, triageInfo);

        // Assert
        assertNotNull(response);
        assertEquals(folderAccessMap, response.getFolderAccessMap());
        assertEquals(missingRacfEntries, response.getMissingRacfEntries());
        assertEquals(saraPathInfo, response.getSaraPathInfo());
        assertEquals(userGroups, response.getUserGroups());
        assertEquals(triageInfo, response.getTriageInfo());
        assertNull(response.getErrorMessage());
        assertFalse(response.isHasError()); // Success constructor should set hasError to false
        assertFalse(response.isCmodFolderNavigation()); // Default should be false
    }

    @Test
    void testErrorConstructor() {
        // Arrange
        String errorMessage = "You do not have access to any CMOD applications.";

        // Act
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse(errorMessage);

        // Assert
        assertNotNull(response);
        assertNull(response.getFolderAccessMap());
        assertNull(response.getMissingRacfEntries());
        assertNull(response.getSaraPathInfo());
        assertNull(response.getUserGroups());
        assertNull(response.getTriageInfo());
        assertEquals(errorMessage, response.getErrorMessage());
        assertTrue(response.isHasError()); // Error constructor should set hasError to true
        assertFalse(response.isCmodFolderNavigation()); // Default should be false
    }

    @Test
    void testSettersAndGetters() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();
        Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = createTestFolderAccessMap();
        Map<String, Set<String>> missingRacfEntries = createTestMissingRacfEntries();
        CMODSARAPathInfo saraPathInfo = createTestSARAPathInfo();
        String userGroups = "TEST_GROUP";
        String triageInfo = "Test triage info";
        String errorMessage = "Test error message";

        // Act
        response.setFolderAccessMap(folderAccessMap);
        response.setMissingRacfEntries(missingRacfEntries);
        response.setSaraPathInfo(saraPathInfo);
        response.setUserGroups(userGroups);
        response.setTriageInfo(triageInfo);
        response.setErrorMessage(errorMessage);
        response.setHasError(true);
        response.setCmodFolderNavigation(true);

        // Assert
        assertEquals(folderAccessMap, response.getFolderAccessMap());
        assertEquals(missingRacfEntries, response.getMissingRacfEntries());
        assertEquals(saraPathInfo, response.getSaraPathInfo());
        assertEquals(userGroups, response.getUserGroups());
        assertEquals(triageInfo, response.getTriageInfo());
        assertEquals(errorMessage, response.getErrorMessage());
        assertTrue(response.isHasError());
        assertTrue(response.isCmodFolderNavigation());
    }

    @Test
    void testCmodFolderNavigationFlag() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();

        // Test default value
        assertFalse(response.isCmodFolderNavigation());

        // Test setting to true
        response.setCmodFolderNavigation(true);
        assertTrue(response.isCmodFolderNavigation());

        // Test setting back to false
        response.setCmodFolderNavigation(false);
        assertFalse(response.isCmodFolderNavigation());
    }

    @Test
    void testHasErrorFlag() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();

        // Test default value
        assertFalse(response.isHasError());

        // Test setting to true
        response.setHasError(true);
        assertTrue(response.isHasError());

        // Test setting back to false
        response.setHasError(false);
        assertFalse(response.isHasError());
    }

    @Test
    void testNullFieldsHandling() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();

        // Act - Set all fields to null
        response.setFolderAccessMap(null);
        response.setMissingRacfEntries(null);
        response.setSaraPathInfo(null);
        response.setUserGroups(null);
        response.setTriageInfo(null);
        response.setErrorMessage(null);

        // Assert - Should handle null values gracefully
        assertNull(response.getFolderAccessMap());
        assertNull(response.getMissingRacfEntries());
        assertNull(response.getSaraPathInfo());
        assertNull(response.getUserGroups());
        assertNull(response.getTriageInfo());
        assertNull(response.getErrorMessage());
    }

    @Test  
    void testEmptyStringFields() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();

        // Act - Set string fields to empty strings
        response.setUserGroups("");
        response.setTriageInfo("");
        response.setErrorMessage("");

        // Assert - Should handle empty strings gracefully
        assertEquals("", response.getUserGroups());
        assertEquals("", response.getTriageInfo());
        assertEquals("", response.getErrorMessage());
    }

    @Test
    void testFolderAccessMapStructure() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();
        Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = createTestFolderAccessMap();

        // Act
        response.setFolderAccessMap(folderAccessMap);

        // Assert
        assertNotNull(response.getFolderAccessMap());
        assertEquals(1, response.getFolderAccessMap().size());
        assertTrue(response.getFolderAccessMap().containsKey("TEST_FOLDER"));
        
        Map<String, CMODApplicationAccessInfo> applications = response.getFolderAccessMap().get("TEST_FOLDER");
        assertNotNull(applications);
        assertEquals(1, applications.size());
        assertTrue(applications.containsKey("TEST_ACF2"));
    }

    @Test
    void testMissingRacfEntriesStructure() {
        // Arrange
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse();
        Map<String, Set<String>> missingRacfEntries = createTestMissingRacfEntries();

        // Act
        response.setMissingRacfEntries(missingRacfEntries);

        // Assert
        assertNotNull(response.getMissingRacfEntries());
        assertEquals(1, response.getMissingRacfEntries().size());
        assertTrue(response.getMissingRacfEntries().containsKey("TEST_FOLDER"));
        
        Set<String> missingApps = response.getMissingRacfEntries().get("TEST_FOLDER");
        assertNotNull(missingApps);
        assertEquals(2, missingApps.size());
        assertTrue(missingApps.contains("MISSING_APP_1"));
        assertTrue(missingApps.contains("MISSING_APP_2"));
    }

    @Test
    void testCompleteSuccessResponse() {
        // Arrange & Act
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse(
            createTestFolderAccessMap(),
            createTestMissingRacfEntries(),
            createTestSARAPathInfo(),
            "HMRK, NDAK, MINN",
            "Contact system administrator for access issues"
        );
        response.setCmodFolderNavigation(true);

        // Assert - Complete success response
        assertNotNull(response);
        assertFalse(response.isHasError());
        assertTrue(response.isCmodFolderNavigation());
        assertNotNull(response.getFolderAccessMap());
        assertNotNull(response.getMissingRacfEntries());
        assertNotNull(response.getSaraPathInfo());
        assertEquals("HMRK, NDAK, MINN", response.getUserGroups());
        assertEquals("Contact system administrator for access issues", response.getTriageInfo());
        assertNull(response.getErrorMessage());
    }

    @Test
    void testCompleteErrorResponse() {
        // Arrange & Act
        CMODSecurityAccessResponse response = new CMODSecurityAccessResponse(
            "CMOD Access UI is currently disabled."
        );

        // Assert - Complete error response
        assertNotNull(response);
        assertTrue(response.isHasError());
        assertFalse(response.isCmodFolderNavigation());
        assertEquals("CMOD Access UI is currently disabled.", response.getErrorMessage());
        assertNull(response.getFolderAccessMap());
        assertNull(response.getMissingRacfEntries());
        assertNull(response.getSaraPathInfo());
        assertNull(response.getUserGroups());
        assertNull(response.getTriageInfo());
    }

    /**
     * Helper method to create test folder access map.
     */
    private Map<String, Map<String, CMODApplicationAccessInfo>> createTestFolderAccessMap() {
        Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = new HashMap<>();
        Map<String, CMODApplicationAccessInfo> applications = new HashMap<>();

        CMODApplicationAccessInfo appInfo = new CMODApplicationAccessInfo();
        appInfo.setApplicationName("TEST_APP");
        appInfo.setUserAccess(true);
        appInfo.setAcf2String("TEST_ACF2");
        appInfo.setApplicationVersions(Set.of("TEST_APP-HMRK-V1"));

        applications.put("TEST_ACF2", appInfo);
        folderAccessMap.put("TEST_FOLDER", applications);

        return folderAccessMap;
    }

    /**
     * Helper method to create test missing RACF entries.
     */
    private Map<String, Set<String>> createTestMissingRacfEntries() {
        Map<String, Set<String>> missingRacfEntries = new HashMap<>();
        missingRacfEntries.put("TEST_FOLDER", Set.of("MISSING_APP_1", "MISSING_APP_2"));
        return missingRacfEntries;
    }

    /**
     * Helper method to create test SARA path info.
     */
    private CMODSARAPathInfo createTestSARAPathInfo() {
        return new CMODSARAPathInfo(
            "/test/root/path",
            Map.of("HIGHVIEW_PATH", "/highview/test"),
            Map.of("RENO_PATH", "/reno/test")
        );
    }
}