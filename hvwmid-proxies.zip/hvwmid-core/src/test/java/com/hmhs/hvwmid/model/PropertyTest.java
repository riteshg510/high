package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PropertyTest {

    private Property property;

    @BeforeEach
    void setUp() {
        property = new Property();
    }

    @Test
    void testSetAndGetId() {
        property.setId("12345");
        assertEquals("12345", property.getId());
    }

    @Test
    void testSetAndGetName() {
        property.setName("Test Property");
        assertEquals("Test Property", property.getName());
    }

    @Test
    void testSetAndGetDescription() {
        property.setDescription("Property Description");
        assertEquals("Property Description", property.getDescription());
    }

    @Test
    void testSetAndGetMaxLength() {
        property.setMaxLength(255);
        assertEquals(255, property.getMaxLength());
    }

    @Test
    void testSetAndGetMultiline() {
        property.setMultiline(true);
        assertTrue(property.isMultiline());
    }

    @Test
    void testSetAndGetChoiceListMultiSelect() {
        property.setChoiceListMultiSelect(true);
        assertTrue(property.isChoiceListMultiSelect());
    }

    @Test
    void testSetAndGetRequired() {
        property.setRequired("true");
        assertEquals("true", property.getRequired());
    }

    @Test
    void testSetAndGetDateFormat() {
        property.setDateFormat("MM/dd/yyyy");
        assertEquals("MM/dd/yyyy", property.getDateFormat());
    }

    @Test
    void testSetAndGetInputType() {
        property.setInputType("text");
        assertEquals("text", property.getInputType());
    }

    @Test
    void testSetAndGetHtmlText() {
        property.setHtmlText("<p>Test</p>");
        assertEquals("<p>Test</p>", property.getHtmlText());
    }

    @Test
    void testSetAndGetPattern() {
        property.setPattern("[A-Za-z0-9]+");
        assertEquals("[A-Za-z0-9]+", property.getPattern());
    }

    @Test
    void testSetAndGetPatternMessage() {
        property.setPatternMessage("Invalid input");
        assertEquals("Invalid input", property.getPatternMessage());
    }

    @Test
    void testSetAndGetSid() {
        property.setSid("SID123");
        assertEquals("SID123", property.getSid());
    }

    @Test
    void testSetAndGetLayoutType() {
        property.setLayoutType("standard");
        assertEquals("standard", property.getLayoutType());
    }

    @Test
    void testSetAndGetChoicelistApi() {
        property.setChoicelistApi("api/choiceList");
        assertEquals("api/choiceList", property.getChoicelistApi());
    }

    @Test
    void testSetAndGetLookupApi() {
        property.setLookupApi("api/lookup");
        assertEquals("api/lookup", property.getLookupApi());
    }

    @Test
    void testSetAndGetFalseLabel() {
        property.setFalseLabel("No");
        assertEquals("No", property.getFalseLabel());
    }

    @Test
    void testSetAndGetTrueLabel() {
        property.setTrueLabel("Yes");
        assertEquals("Yes", property.getTrueLabel());
    }

    @Test
    void testSetAndGetDefaultValue() {
        property.setDefaultValue("Default");
        assertEquals("Default", property.getDefaultValue());
    }

    @Test
    void testSetAndGetChildren() {
        List<BaseLayout> children = Arrays.asList(new BaseLayout(), new BaseLayout());
        property.setChildren(children);
        assertNotNull(property.getChildren());
        assertEquals(2, property.getChildren().size());
    }

    @Test
    void testSetAndGetParentFields() {
        property.setParentFields("ParentField");
        assertEquals("ParentField", property.getParentFields());
    }

    @Test
    void testSetAndGetReadOnly() {
        property.setReadonly(true);
        assertTrue(property.isReadonly());
    }

    @Test
    void testSetAndGetType() {
        property.setType("String");
        assertEquals("String", property.getType());
    }
}
