package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.Map;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CMODUpdateServiceTest {

    @Mock
    private RestClientUtil restClientUtil;

    @InjectMocks
    private CMODUpdateService cmodUpdateService;

    private String validAuthToken;
    private Map<String, Object> validRequest;

    @BeforeEach
    void setUp() {
        validAuthToken = "Bearer validAuthToken";
        validRequest = new HashMap<>();
        validRequest.put("documentToken", "validToken");
        validRequest.put("odFolder", "CMODFolder");
        validRequest.put("key1", "value1");
        validRequest.put("key2", "value2");
    }

    @Test
    void updateDocument_shouldReturnUpdatedData_whenValidInput() {
        // Arrange
        Map<String, Object> expectedResponse = Map.of("status", "success");

        // Mock the actual URL used in the method
        String updateUrl = "http://example.com/update";
        cmodUpdateService.updateUrl = updateUrl;  // Assuming updateUrl is set as a field in CMODUpdateService

        when(restClientUtil.postRequest(eq(updateUrl), eq(validAuthToken), anyMap()))
                .thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        Map<String, Object> result = cmodUpdateService.updateDocument(validRequest, validAuthToken);

        // Assert
        assertNotNull(result);
        assertEquals("success", result.get("status"));
        verify(restClientUtil, times(1)).postRequest(eq(updateUrl), eq(validAuthToken), anyMap());
    }

    @Test
    void updateDocument_shouldThrowException_whenFolderIsMissing() {
        // Arrange
        validRequest.remove("odFolder");

        // Act + Assert
        assertThrows(HVWException.class, () -> cmodUpdateService.updateDocument(validRequest, validAuthToken));
    }


    @Test
    void updateDocument_shouldThrowException_whenDocumentTokenIsMissing() {
        // Arrange
        validRequest.remove("documentToken");

        // Act + Assert
        assertThrows(HVWException.class, () -> cmodUpdateService.updateDocument(validRequest, validAuthToken));
    }


@Test
void updateDocument_shouldReturnError_whenApiCallFails() {
    // Arrange
    Map<String, Object> expectedErrorResponse = Map.of("status", "error", "message", "Service unavailable");

    String updateUrl = "http://example.com/update";
    cmodUpdateService.updateUrl = updateUrl;

    when(restClientUtil.postRequest(eq(updateUrl), eq(validAuthToken), anyMap()))
            .thenReturn(ResponseEntity.status(503).body(expectedErrorResponse));

    // Act + Assert
    HVWException ex = assertThrows(HVWException.class, () -> cmodUpdateService.updateDocument(validRequest, validAuthToken));
    assertEquals("Service temporarily unavailable: CMOD", ex.getMessage());
    assertEquals(503, ex.getReturnCode());
    assertEquals("CMOD", ex.getService());
}

    @Test
    void updateDocument_shouldThrowException_whenInvalidAuthToken() {
        // Arrange
        String invalidAuthToken = "Bearer invalidAuthToken";

        // Mock the actual URL used in the method
        String updateUrl = "http://example.com/update";
        cmodUpdateService.updateUrl = updateUrl;

        when(restClientUtil.postRequest(eq(updateUrl), eq(invalidAuthToken), anyMap()))
                .thenThrow(new RuntimeException("Unauthorized"));

        // Act + Assert
        assertThrows(RuntimeException.class, () -> cmodUpdateService.updateDocument(validRequest, invalidAuthToken));
    }

    @Test
    void updateDocument_shouldHandleEmptyUpdateValues() {
        // Arrange
        Map<String, Object> requestWithEmptyUpdateValues = new HashMap<>();
        requestWithEmptyUpdateValues.put("documentToken", "validToken");
        requestWithEmptyUpdateValues.put("odFolder", "CMODFolder");

        // Mock the actual URL used in the method
        String updateUrl = "http://example.com/update";
        cmodUpdateService.updateUrl = updateUrl;

        Map<String, Object> expectedResponse = Map.of("status", "success");
        when(restClientUtil.postRequest(eq(updateUrl), eq(validAuthToken), anyMap()))
                .thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        Map<String, Object> result = cmodUpdateService.updateDocument(requestWithEmptyUpdateValues, validAuthToken);

        // Assert
        assertNotNull(result);
        assertEquals("success", result.get("status"));
        verify(restClientUtil, times(1)).postRequest(eq(updateUrl), eq(validAuthToken), anyMap());
    }
}
