package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class T117ImgCoverSheetOverrideIdTest {

    private T117ImgCoverSheetOverrideId id;

    @BeforeEach
    void setup() {
        id = new T117ImgCoverSheetOverrideId();
    }

    @Test
    void application_shouldSetAndGetCorrectly() {
        // Given
        Integer application = 100;

        // When
        id.setApplication(application);

        // Then
        assertEquals(application, id.getApplication());
    }

    @Test
    void application_shouldHandleNullValue() {
        // Given
        id.setApplication(null);

        // When & Then
        assertNull(id.getApplication());
    }

    @Test
    void application_shouldHandleBoundaryValues() {
        // Given & When & Then
        id.setApplication(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, id.getApplication());

        id.setApplication(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, id.getApplication());

        id.setApplication(0);
        assertEquals(0, id.getApplication());
    }

    @Test
    void name_shouldSetAndGetCorrectly() {
        // Given
        String name = "OVERRIDE_ID";

        // When
        id.setName(name);

        // Then
        assertEquals(name, id.getName());
    }

    @Test
    void name_shouldHandleNullValue() {
        // Given
        id.setName(null);

        // When & Then
        assertNull(id.getName());
    }

    @Test
    void name_shouldHandleEmptyString() {
        // Given
        id.setName("");

        // When & Then
        assertEquals("", id.getName());
    }

    @Test
    void name_shouldHandleVariousFormats() {
        // Test different name formats
        String[] names = {"OVERRIDE1", "OVR001", "ABC123", "TEST_OVR", "X", "1234567890"};

        for (String name : names) {
            // When
            id.setName(name);

            // Then
            assertEquals(name, id.getName());
        }
    }

    @Test
    void sequence_shouldSetAndGetCorrectly() {
        // Given
        Integer sequence = 5;

        // When
        id.setSequence(sequence);

        // Then
        assertEquals(sequence, id.getSequence());
    }

    @Test
    void sequence_shouldHandleNullValue() {
        // Given
        id.setSequence(null);

        // When & Then
        assertNull(id.getSequence());
    }

    @Test
    void sequence_shouldHandleBoundaryValues() {
        // Given & When & Then
        id.setSequence(0);
        assertEquals(0, id.getSequence());

        id.setSequence(1);
        assertEquals(1, id.getSequence());

        id.setSequence(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, id.getSequence());

        id.setSequence(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, id.getSequence());
    }

    @Test
    void sequence_shouldHandleTypicalOverrideValues() {
        // Test sequence values commonly used in overrides
        Integer[] typicalSequences = {1, 2, 3, 5, 10, 99, 100};

        for (Integer seq : typicalSequences) {
            // When
            id.setSequence(seq);

            // Then
            assertEquals(seq, id.getSequence());
        }
    }

    @Test
    void equals_shouldReturnTrueForSameObject() {
        // Given & When & Then
        assertEquals(id, id);
        assertTrue(id.equals(id));
    }

    @Test
    void equals_shouldReturnFalseForNull() {
        // Given & When & Then
        assertFalse(id.equals(null));
        assertNotEquals(id, null);
    }

    @Test
    void equals_shouldReturnFalseForDifferentClass() {
        // Given
        String differentObject = "not an ID object";

        // When & Then
        assertFalse(id.equals(differentObject));
        assertNotEquals(id, differentObject);
    }

    @Test
    void equals_shouldReturnTrueForSameValues() {
        // Given
        id.setApplication(100);
        id.setName("TEST");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName("TEST");
        otherId.setSequence(1);

        // When & Then
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);
    }

    @Test
    void equals_shouldReturnFalseForDifferentApplication() {
        // Given
        id.setApplication(100);
        id.setName("TEST");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(200);
        otherId.setName("TEST");
        otherId.setSequence(1);

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldReturnFalseForDifferentName() {
        // Given
        id.setApplication(100);
        id.setName("TEST1");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName("TEST2");
        otherId.setSequence(1);

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldReturnFalseForDifferentSequence() {
        // Given
        id.setApplication(100);
        id.setName("TEST");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName("TEST");
        otherId.setSequence(2);

        // When & Then
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldHandleNullValues() {
        // Given - Both IDs with null values
        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();

        // When & Then - Both have null values, should be equal
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);

        // Given - One has null, other doesn't
        id.setApplication(100);

        // When & Then - Should not be equal
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void equals_shouldHandleMixedNullValues() {
        // Given
        id.setApplication(100);
        id.setName(null);
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName(null);
        otherId.setSequence(1);

        // When & Then - Should be equal with matching null values
        assertTrue(id.equals(otherId));
        assertEquals(id, otherId);

        // Given - Change null to non-null
        otherId.setName("TEST");

        // When & Then - Should not be equal
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);
    }

    @Test
    void hashCode_shouldReturnSameValueForEqualObjects() {
        // Given
        id.setApplication(100);
        id.setName("TEST");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName("TEST");
        otherId.setSequence(1);

        // When & Then
        assertEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void hashCode_shouldReturnDifferentValueForDifferentObjects() {
        // Given
        id.setApplication(100);
        id.setName("TEST1");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(200);
        otherId.setName("TEST2");
        otherId.setSequence(2);

        // When & Then
        assertNotEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void hashCode_shouldHandleNullValues() {
        // Given - Default constructor creates all null values
        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();

        // When & Then - Same null values should produce same hash code
        assertEquals(id.hashCode(), otherId.hashCode());

        // Given - Set one field
        id.setApplication(100);

        // When & Then - Different values should produce different hash codes
        assertNotEquals(id.hashCode(), otherId.hashCode());
    }

    @Test
    void hashCode_shouldBeConsistent() {
        // Given
        id.setApplication(100);
        id.setName("CONSISTENT");
        id.setSequence(1);

        // When
        int firstHash = id.hashCode();
        int secondHash = id.hashCode();

        // Then
        assertEquals(firstHash, secondHash);
    }

    @Test
    void id_shouldImplementSerializable() {
        // Then
        assertTrue(id instanceof java.io.Serializable);
    }

    @Test
    void id_shouldCreateWithDefaultConstructor() {
        // When
        T117ImgCoverSheetOverrideId newId = new T117ImgCoverSheetOverrideId();

        // Then - All fields should be null by default
        assertNull(newId.getApplication());
        assertNull(newId.getName());
        assertNull(newId.getSequence());
    }

    @Test
    void id_shouldHandleCompleteCompositeKey() {
        // Given
        Integer application = 300;
        String name = "COMPLETE_KEY";
        Integer sequence = 5;

        // When
        id.setApplication(application);
        id.setName(name);
        id.setSequence(sequence);

        // Then
        assertEquals(application, id.getApplication());
        assertEquals(name, id.getName());
        assertEquals(sequence, id.getSequence());
    }

    @Test
    void id_shouldHandleFieldIndependence() {
        // Given
        id.setApplication(1);
        id.setName("ID1");
        id.setSequence(1);

        // When - Create another ID to verify independence
        T117ImgCoverSheetOverrideId id2 = new T117ImgCoverSheetOverrideId();
        id2.setApplication(2);
        id2.setName("ID2");
        id2.setSequence(2);

        // Then - IDs should be independent
        assertEquals(1, id.getApplication());
        assertEquals("ID1", id.getName());
        assertEquals(1, id.getSequence());
        assertEquals(2, id2.getApplication());
        assertEquals("ID2", id2.getName());
        assertEquals(2, id2.getSequence());
    }

    @Test
    void id_shouldHandleSpecialCharactersInName() {
        // Given
        String nameWithSpecialChars = "ID_!@#$%";

        // When
        id.setName(nameWithSpecialChars);

        // Then
        assertEquals(nameWithSpecialChars, id.getName());
    }

    @Test
    void id_shouldHandleUnicodeCharacters() {
        // Given
        String unicodeName = "ÏD_Ünïcödé";

        // When
        id.setName(unicodeName);

        // Then
        assertEquals(unicodeName, id.getName());
    }

    @Test
    void equals_shouldSupportSymmetricProperty() {
        // Given
        id.setApplication(100);
        id.setName("SYMMETRIC");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName("SYMMETRIC");
        otherId.setSequence(1);

        // When & Then - Symmetric: if x.equals(y), then y.equals(x)
        assertTrue(id.equals(otherId));
        assertTrue(otherId.equals(id));
    }

    @Test
    void equals_shouldSupportTransitiveProperty() {
        // Given
        id.setApplication(100);
        id.setName("TRANSITIVE");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId id2 = new T117ImgCoverSheetOverrideId();
        id2.setApplication(100);
        id2.setName("TRANSITIVE");
        id2.setSequence(1);

        T117ImgCoverSheetOverrideId id3 = new T117ImgCoverSheetOverrideId();
        id3.setApplication(100);
        id3.setName("TRANSITIVE");
        id3.setSequence(1);

        // When & Then - Transitive: if x.equals(y) and y.equals(z), then x.equals(z)
        assertTrue(id.equals(id2));
        assertTrue(id2.equals(id3));
        assertTrue(id.equals(id3));
    }

    @Test
    void equals_shouldSupportReflexiveProperty() {
        // Given
        id.setApplication(100);
        id.setName("REFLEXIVE");
        id.setSequence(1);

        // When & Then - Reflexive: x.equals(x) should always be true
        assertTrue(id.equals(id));
    }

    @Test
    void equals_shouldSupportConsistentProperty() {
        // Given
        id.setApplication(100);
        id.setName("CONSISTENT");
        id.setSequence(1);

        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(100);
        otherId.setName("CONSISTENT");
        otherId.setSequence(1);

        // When & Then - Consistent: multiple calls should return same result
        boolean firstCall = id.equals(otherId);
        boolean secondCall = id.equals(otherId);
        assertEquals(firstCall, secondCall);
        assertTrue(firstCall);
        assertTrue(secondCall);
    }

    @Test
    void id_shouldSupportTypicalOverrideKeyScenarios() {
        // Test creating override keys for different scenarios
        
        // Scenario 1: First override for a sheet
        id.setApplication(100);
        id.setName("INVOICE");
        id.setSequence(1);

        assertEquals(100, id.getApplication());
        assertEquals("INVOICE", id.getName());
        assertEquals(1, id.getSequence());

        // Scenario 2: Second override for same sheet
        id.setSequence(2);
        assertEquals(2, id.getSequence());

        // Scenario 3: Override for different application
        id.setApplication(200);
        id.setSequence(1);
        assertEquals(200, id.getApplication());
        assertEquals(1, id.getSequence());
    }

    @Test
    void id_shouldHandleZeroValues() {
        // Given
        id.setApplication(0);
        id.setSequence(0);
        id.setName("ZERO_TEST");

        // When & Then
        assertEquals(0, id.getApplication());
        assertEquals(0, id.getSequence());
        assertEquals("ZERO_TEST", id.getName());
    }

    @Test
    void id_shouldHandleNegativeValues() {
        // Given
        id.setApplication(-1);
        id.setSequence(-1);
        id.setName("NEGATIVE");

        // When & Then
        assertEquals(-1, id.getApplication());
        assertEquals(-1, id.getSequence());
        assertEquals("NEGATIVE", id.getName());
    }

    @Test
    void id_shouldMaintainStateAfterModification() {
        // Given
        id.setApplication(100);
        id.setName("ORIGINAL");
        id.setSequence(1);

        // When - Modify one field
        id.setSequence(2);

        // Then - Other fields should remain unchanged
        assertEquals(100, id.getApplication());
        assertEquals("ORIGINAL", id.getName());
        assertEquals(2, id.getSequence());
    }

    @Test
    void equals_shouldHandlePartiallyNullCompositeKeys() {
        // Given - First ID with mixed null values
        id.setApplication(100);
        id.setName(null);
        id.setSequence(1);

        // Second ID with different null pattern
        T117ImgCoverSheetOverrideId otherId = new T117ImgCoverSheetOverrideId();
        otherId.setApplication(null);
        otherId.setName("TEST");
        otherId.setSequence(1);

        // When & Then - Should not be equal
        assertFalse(id.equals(otherId));
        assertNotEquals(id, otherId);

        // Third ID with same null pattern as first
        T117ImgCoverSheetOverrideId thirdId = new T117ImgCoverSheetOverrideId();
        thirdId.setApplication(100);
        thirdId.setName(null);
        thirdId.setSequence(1);

        // When & Then - Should be equal
        assertTrue(id.equals(thirdId));
        assertEquals(id, thirdId);
    }
}