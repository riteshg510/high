package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TblTemplatesTest {

    private TblTemplates tblTemplate;

    @BeforeEach
    void setUp() {
        tblTemplate = new TblTemplates();
    }

    @Test
    void testSetAndGetTemplateId() {
        // Test setting and getting templateId
        String templateId = "template123";
        tblTemplate.setTemplateId(templateId);
        assertEquals(templateId, tblTemplate.getTemplateId(), "TemplateId should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetTemplateIdWithNull() {
        // Test setting and getting templateId with null value
        tblTemplate.setTemplateId(null);
        assertNull(tblTemplate.getTemplateId(), "TemplateId should be null.");
    }

    @Test
    void testSetAndGetContent() {
        // Test setting and getting content (byte array)
        byte[] content = {1, 2, 3, 4};
        tblTemplate.setContent(content);
        assertArrayEquals(content, tblTemplate.getContent(), "Content should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetContentWithNull() {
        // Test setting and getting content with null value
        tblTemplate.setContent(null);
        assertNull(tblTemplate.getContent(), "Content should be null.");
    }

    @Test
    void testSetAndGetEnvId() {
        // Test setting and getting envId
        String envId = "env123";
        tblTemplate.setEnvId(envId);
        assertEquals(envId, tblTemplate.getEnvId(), "EnvId should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetEnvIdWithNull() {
        // Test setting and getting envId with null value
        tblTemplate.setEnvId(null);
        assertNull(tblTemplate.getEnvId(), "EnvId should be null.");
    }

    @Test
    void testSetAndGetLastModifiedDate() {
        // Test setting and getting lastModifiedDate
        LocalDateTime date = LocalDateTime.now();
        tblTemplate.setLastModifiedDate(date);
        assertEquals(date, tblTemplate.getLastModifiedDate(), "LastModifiedDate should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetLastModifiedDateWithNull() {
        // Test setting and getting lastModifiedDate with null value
        tblTemplate.setLastModifiedDate(null);
        assertNull(tblTemplate.getLastModifiedDate(), "LastModifiedDate should be null.");
    }

    @Test
    void testSetAndGetLastModifiedUser() {
        // Test setting and getting lastModifiedUser
        String user = "user123";
        tblTemplate.setLastModifiedUser(user);
        assertEquals(user, tblTemplate.getLastModifiedUser(), "LastModifiedUser should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetLastModifiedUserWithNull() {
        // Test setting and getting lastModifiedUser with null value
        tblTemplate.setLastModifiedUser(null);
        assertNull(tblTemplate.getLastModifiedUser(), "LastModifiedUser should be null.");
    }

    @Test
    void testSetAndGetTemplateName() {
        // Test setting and getting templateName
        String templateName = "Template Name";
        tblTemplate.setTemplateName(templateName);
        assertEquals(templateName, tblTemplate.getTemplateName(), "TemplateName should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetTemplateNameWithNull() {
        // Test setting and getting templateName with null value
        tblTemplate.setTemplateName(null);
        assertNull(tblTemplate.getTemplateName(), "TemplateName should be null.");
    }

    @Test
    void testSetAndGetTemplateDesc() {
        // Test setting and getting templateDesc
        String templateDesc = "Description of the template.";
        tblTemplate.setTemplateDesc(templateDesc);
        assertEquals(templateDesc, tblTemplate.getTemplateDesc(), "TemplateDesc should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetTemplateDescWithNull() {
        // Test setting and getting templateDesc with null value
        tblTemplate.setTemplateDesc(null);
        assertNull(tblTemplate.getTemplateDesc(), "TemplateDesc should be null.");
    }

    @Test
    void testSetAndGetTemplateType() {
        // Test setting and getting templateType
        int templateType = 1;
        tblTemplate.setTemplateType(templateType);
        assertEquals(templateType, tblTemplate.getTemplateType(), "TemplateType should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetTemplateTypeWithNegativeValue() {
        // Test setting and getting templateType with a negative value
        int templateType = -1;
        tblTemplate.setTemplateType(templateType);
        assertEquals(templateType, tblTemplate.getTemplateType(), "TemplateType should allow negative values.");
    }
}
