package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.repository.CodTokenRepository;
import com.hmhs.hvwmid.repository.ImgTokenRepository;
import com.hmhs.hvwmid.repository.TblHvwStatusRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CacheCleanupScheduler.
 * Tests the scheduled cleanup functionality for tokens and HVW status records.
 */
@ExtendWith(MockitoExtension.class)
class CacheCleanupSchedulerTest {

    @Mock
    private CodTokenRepository codTokenRepo;

    @Mock
    private ImgTokenRepository imgTokenRepo;

    @Mock
    private TblHvwStatusRepository hvwStatusRepo;

    @InjectMocks
    private CacheCleanupScheduler scheduler;

    private static final long DEFAULT_RETENTION_DAYS = 7L;
    private static final long CUSTOM_RETENTION_DAYS = 14L;

    @BeforeEach
    void setUp() {
        // Set default retention days
        ReflectionTestUtils.setField(scheduler, "retentionDays", DEFAULT_RETENTION_DAYS);
    }

    @Test
    void testCleanupOldTokens_CallsDeleteWithCorrectCutoff() {
        // Given
        LocalDateTime beforeCall = LocalDateTime.now().minusDays(DEFAULT_RETENTION_DAYS);

        // When
        scheduler.cleanupOldTokens();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(codTokenRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime cutoff = captor.getValue();
        assertNotNull(cutoff);
        assertTrue(cutoff.isBefore(LocalDateTime.now()));
        assertTrue(cutoff.isAfter(beforeCall.minusMinutes(1))); // Allow for small timing differences
        assertTrue(cutoff.isBefore(beforeCall.plusMinutes(1)));
        verifyNoMoreInteractions(codTokenRepo);
    }

    @Test
    void testCleanupOldTokensImg_CallsDeleteWithCorrectCutoff() {
        // Given
        LocalDateTime beforeCall = LocalDateTime.now().minusDays(DEFAULT_RETENTION_DAYS);

        // When
        scheduler.cleanupOldTokensImg();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(imgTokenRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime cutoff = captor.getValue();
        assertNotNull(cutoff);
        assertTrue(cutoff.isBefore(LocalDateTime.now()));
        assertTrue(cutoff.isAfter(beforeCall.minusMinutes(1))); // Allow for small timing differences
        assertTrue(cutoff.isBefore(beforeCall.plusMinutes(1)));
        verifyNoMoreInteractions(imgTokenRepo);
    }

    @Test
    void testCleanupOldHvwStatus_CallsDeleteWithCorrectCutoff() {
        // Given
        LocalDateTime beforeCall = LocalDateTime.now().minusDays(DEFAULT_RETENTION_DAYS);

        // When
        scheduler.cleanupOldHvwStatus();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(hvwStatusRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime cutoff = captor.getValue();
        assertNotNull(cutoff);
        assertTrue(cutoff.isBefore(LocalDateTime.now()));
        assertTrue(cutoff.isAfter(beforeCall.minusMinutes(1))); // Allow for small timing differences
        assertTrue(cutoff.isBefore(beforeCall.plusMinutes(1)));
        verifyNoMoreInteractions(hvwStatusRepo);
    }

    @Test
    void testCleanupOldTokens_WithCustomRetentionDays() {
        // Given
        ReflectionTestUtils.setField(scheduler, "retentionDays", CUSTOM_RETENTION_DAYS);
        LocalDateTime expectedCutoff = LocalDateTime.now().minusDays(CUSTOM_RETENTION_DAYS);

        // When
        scheduler.cleanupOldTokens();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(codTokenRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime actualCutoff = captor.getValue();
        assertNotNull(actualCutoff);
        
        // Verify the cutoff is approximately 14 days ago (within 1 minute tolerance)
        long daysDifference = ChronoUnit.DAYS.between(actualCutoff, LocalDateTime.now());
        assertEquals(CUSTOM_RETENTION_DAYS, daysDifference);
    }

    @Test
    void testCleanupOldTokensImg_WithCustomRetentionDays() {
        // Given
        ReflectionTestUtils.setField(scheduler, "retentionDays", CUSTOM_RETENTION_DAYS);

        // When
        scheduler.cleanupOldTokensImg();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(imgTokenRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime actualCutoff = captor.getValue();
        assertNotNull(actualCutoff);
        
        // Verify the cutoff is approximately 14 days ago
        long daysDifference = ChronoUnit.DAYS.between(actualCutoff, LocalDateTime.now());
        assertEquals(CUSTOM_RETENTION_DAYS, daysDifference);
    }

    @Test
    void testCleanupOldHvwStatus_WithCustomRetentionDays() {
        // Given
        ReflectionTestUtils.setField(scheduler, "retentionDays", CUSTOM_RETENTION_DAYS);

        // When
        scheduler.cleanupOldHvwStatus();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(hvwStatusRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime actualCutoff = captor.getValue();
        assertNotNull(actualCutoff);
        
        // Verify the cutoff is approximately 14 days ago
        long daysDifference = ChronoUnit.DAYS.between(actualCutoff, LocalDateTime.now());
        assertEquals(CUSTOM_RETENTION_DAYS, daysDifference);
    }

    @Test
    void testCleanupOldTokens_WithZeroRetentionDays() {
        // Given
        ReflectionTestUtils.setField(scheduler, "retentionDays", 0L);
        LocalDateTime beforeCall = LocalDateTime.now();

        // When
        scheduler.cleanupOldTokens();

        // Then
        ArgumentCaptor<LocalDateTime> captor = ArgumentCaptor.forClass(LocalDateTime.class);
        verify(codTokenRepo, times(1)).deleteByTimeCreateBefore(captor.capture());

        LocalDateTime cutoff = captor.getValue();
        assertNotNull(cutoff);
        
        // With 0 retention days, cutoff should be approximately now
        assertTrue(cutoff.isBefore(LocalDateTime.now().plusMinutes(1)));
        assertTrue(cutoff.isAfter(beforeCall.minusMinutes(1)));
    }

    @Test
    void testCleanupMethods_PropagateRepositoryExceptions() {
        // Given
        RuntimeException dbError = new RuntimeException("Database error");
        doThrow(dbError).when(codTokenRepo).deleteByTimeCreateBefore(any());
        doThrow(dbError).when(imgTokenRepo).deleteByTimeCreateBefore(any());
        doThrow(dbError).when(hvwStatusRepo).deleteByTimeCreateBefore(any());

        // When & Then - methods should propagate exceptions from repositories
        assertThrows(RuntimeException.class, () -> scheduler.cleanupOldTokens());
        assertThrows(RuntimeException.class, () -> scheduler.cleanupOldTokensImg());
        assertThrows(RuntimeException.class, () -> scheduler.cleanupOldHvwStatus());

        // Verify all repositories were called
        verify(codTokenRepo).deleteByTimeCreateBefore(any());
        verify(imgTokenRepo).deleteByTimeCreateBefore(any());
        verify(hvwStatusRepo).deleteByTimeCreateBefore(any());
    }

    @Test
    void testScheduledAnnotations() throws NoSuchMethodException {
        // Test cleanupOldTokens() annotation
        var cleanupTokensMethod = CacheCleanupScheduler.class.getMethod("cleanupOldTokens");
        var scheduledAnnotation1 = cleanupTokensMethod.getAnnotation(org.springframework.scheduling.annotation.Scheduled.class);
        assertNotNull(scheduledAnnotation1);
        assertEquals("0 0 2 * * *", scheduledAnnotation1.cron());
        assertEquals("America/New_York", scheduledAnnotation1.zone());

        // Test cleanupOldTokensImg() annotation
        var cleanupTokensImgMethod = CacheCleanupScheduler.class.getMethod("cleanupOldTokensImg");
        var scheduledAnnotation2 = cleanupTokensImgMethod.getAnnotation(org.springframework.scheduling.annotation.Scheduled.class);
        assertNotNull(scheduledAnnotation2);
        assertEquals("0 0 2 * * *", scheduledAnnotation2.cron());
        assertEquals("America/New_York", scheduledAnnotation2.zone());

        // Test cleanupOldHvwStatus() annotation
        var cleanupHvwStatusMethod = CacheCleanupScheduler.class.getMethod("cleanupOldHvwStatus");
        var scheduledAnnotation3 = cleanupHvwStatusMethod.getAnnotation(org.springframework.scheduling.annotation.Scheduled.class);
        assertNotNull(scheduledAnnotation3);
        assertEquals("0 0 2 * * *", scheduledAnnotation3.cron());
        assertEquals("America/New_York", scheduledAnnotation3.zone());
    }

    @Test
    void testComponentAnnotation() {
        // Verify the scheduler is annotated as a Spring component
        var componentAnnotation = CacheCleanupScheduler.class.getAnnotation(org.springframework.stereotype.Component.class);
        assertNotNull(componentAnnotation);
    }

    @Test
    void testConstructorDependencyInjection() {
        // Verify constructor accepts all required dependencies
        assertNotNull(scheduler);
        // Dependencies are injected via @InjectMocks - tested implicitly through other tests
    }

    @Test
    void testRetentionDaysConfigurationDefault() {
        // Given - create a new scheduler without setting retention days
        CacheCleanupScheduler newScheduler = new CacheCleanupScheduler(codTokenRepo, imgTokenRepo, hvwStatusRepo);
        
        // When - access the default value via reflection
        Object retentionDaysValue = ReflectionTestUtils.getField(newScheduler, "retentionDays");
        
        // Then - should be 0 (since @Value annotation default is not applied in unit tests)
        assertEquals(0L, retentionDaysValue);
    }

    @Test
    void testAllCleanupMethods_UseSameRetentionPeriod() {
        // Given
        ReflectionTestUtils.setField(scheduler, "retentionDays", CUSTOM_RETENTION_DAYS);

        // When
        scheduler.cleanupOldTokens();
        scheduler.cleanupOldTokensImg();
        scheduler.cleanupOldHvwStatus();

        // Then - all methods should use the same retention period
        ArgumentCaptor<LocalDateTime> codTokenCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
        ArgumentCaptor<LocalDateTime> imgTokenCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
        ArgumentCaptor<LocalDateTime> hvwStatusCaptor = ArgumentCaptor.forClass(LocalDateTime.class);

        verify(codTokenRepo).deleteByTimeCreateBefore(codTokenCaptor.capture());
        verify(imgTokenRepo).deleteByTimeCreateBefore(imgTokenCaptor.capture());
        verify(hvwStatusRepo).deleteByTimeCreateBefore(hvwStatusCaptor.capture());

        // All cutoff times should be approximately the same (within 1 second)
        LocalDateTime codTokenCutoff = codTokenCaptor.getValue();
        LocalDateTime imgTokenCutoff = imgTokenCaptor.getValue();
        LocalDateTime hvwStatusCutoff = hvwStatusCaptor.getValue();

        assertTrue(ChronoUnit.SECONDS.between(codTokenCutoff, imgTokenCutoff) < 1);
        assertTrue(ChronoUnit.SECONDS.between(imgTokenCutoff, hvwStatusCutoff) < 1);
    }
}
