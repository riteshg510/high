package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CoverSheetOverrideDTOTest {

    private CoverSheetOverrideDTO dto;

    @BeforeEach
    void setup() {
        dto = new CoverSheetOverrideDTO();
    }

    @Test
    void sequence_shouldSetAndGetCorrectly() {
        // Given
        Integer sequence = 5;

        // When
        dto.setSequence(sequence);

        // Then
        assertEquals(sequence, dto.getSequence());
    }

    @Test
    void sequence_shouldHandleNullValue() {
        // Given
        dto.setSequence(null);

        // When & Then
        assertNull(dto.getSequence());
    }

    @Test
    void sequence_shouldHandleBoundaryValues() {
        // Given & When & Then
        dto.setSequence(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, dto.getSequence());

        dto.setSequence(Integer.MIN_VALUE);
        assertEquals(Integer.MIN_VALUE, dto.getSequence());

        dto.setSequence(0);
        assertEquals(0, dto.getSequence());

        dto.setSequence(1);
        assertEquals(1, dto.getSequence());
    }

    @Test
    void inheritance_shouldExtendCoverSheetDTO() {
        // Then
        assertTrue(dto instanceof CoverSheetDTO);
        assertInstanceOf(CoverSheetDTO.class, dto);
    }

    @Test
    void inheritance_shouldInheritAllParentFields() {
        // Given - Set inherited fields from CoverSheetDTO
        Integer application = 100;
        String name = "OVERRIDE";
        String description = "Override Description";
        String active = "Y";

        // When
        dto.setApplication(application);
        dto.setName(name);
        dto.setDescription(description);
        dto.setActive(active);
        dto.setSequence(3);

        // Then - Should have access to both inherited and own fields
        assertEquals(application, dto.getApplication());
        assertEquals(name, dto.getName());
        assertEquals(description, dto.getDescription());
        assertEquals(active, dto.getActive());
        assertEquals(3, dto.getSequence());
    }

    @Test
    void inheritance_shouldInheritParentBehavior() {
        // Given - Test inherited null-safe behavior from CoverSheetDTO
        dto.setDescription(null);
        dto.setActive(null);
        dto.setSequence(null);

        // When & Then - Should inherit parent's null handling behavior
        assertEquals("", dto.getDescription()); // Parent returns empty string for null
        assertEquals("", dto.getActive()); // Parent returns empty string for null
        assertNull(dto.getSequence()); // Own field, returns null
    }

    @Test
    void inheritance_shouldInheritParentTrimmingBehavior() {
        // Given - Test inherited trimming behavior from CoverSheetDTO
        String descriptionWithSpaces = "  Override Description  ";
        String activeWithSpaces = "  Y  ";

        // When
        dto.setDescription(descriptionWithSpaces);
        dto.setActive(activeWithSpaces);

        // Then - Should inherit parent's trimming behavior
        assertEquals("Override Description", dto.getDescription());
        assertEquals("Y", dto.getActive());
    }

    @Test
    void inheritance_shouldInheritAllParentStringFields() {
        // Given - Set all inherited string fields
        dto.setName("OVERRIDE");
        dto.setDescription("Description");
        dto.setSb1("SB1");
        dto.setEb1("EB1");
        dto.setEb2("EB2");
        dto.setEb3("EB3");
        dto.setTitle("Title");
        dto.setStitle1("Subtitle1");
        dto.setStitle2("Subtitle2");
        dto.setUnit("UNIT");
        dto.setRcode("RC001");
        dto.setTemplate("TEMPLATE");
        dto.setActive("Y");
        dto.setEnvironment("TEST");

        // When & Then - All inherited fields should be accessible
        assertEquals("OVERRIDE", dto.getName());
        assertEquals("Description", dto.getDescription());
        assertEquals("SB1", dto.getSb1());
        assertEquals("EB1", dto.getEb1());
        assertEquals("EB2", dto.getEb2());
        assertEquals("EB3", dto.getEb3());
        assertEquals("Title", dto.getTitle());
        assertEquals("Subtitle1", dto.getStitle1());
        assertEquals("Subtitle2", dto.getStitle2());
        assertEquals("UNIT", dto.getUnit());
        assertEquals("RC001", dto.getRcode());
        assertEquals("TEMPLATE", dto.getTemplate());
        assertEquals("Y", dto.getActive());
        assertEquals("TEST", dto.getEnvironment());
    }

    @Test
    void dto_shouldCreateCompleteOverrideObject() {
        // Given - Create a complete override object with all fields
        Integer application = 200;
        String name = "OVERRIDE_SHEET";
        String description = "Complete Override";
        String template = "OVERRIDE_TEMPLATE";
        String active = "Y";
        Integer sequence = 10;

        // When
        dto.setApplication(application);
        dto.setName(name);
        dto.setDescription(description);
        dto.setTemplate(template);
        dto.setActive(active);
        dto.setSequence(sequence);

        // Then
        assertEquals(application, dto.getApplication());
        assertEquals(name, dto.getName());
        assertEquals(description, dto.getDescription());
        assertEquals(template, dto.getTemplate());
        assertEquals(active, dto.getActive());
        assertEquals(sequence, dto.getSequence());
    }

    @Test
    void dto_shouldCreateWithDefaultConstructor() {
        // When
        CoverSheetOverrideDTO newDto = new CoverSheetOverrideDTO();

        // Then - Should have defaults from parent and null sequence
        assertNull(newDto.getApplication());
        assertNull(newDto.getSequence());

        // These should return empty string from parent
        assertEquals("", newDto.getDescription());
        assertEquals("", newDto.getActive());
        assertEquals("", newDto.getTemplate());
    }

    @Test
    void sequence_shouldBeIndependentFromParentFields() {
        // Given
        dto.setApplication(1);
        dto.setName("TEST");
        dto.setSequence(5);

        // When - Modify parent fields
        dto.setApplication(2);
        dto.setName("MODIFIED");

        // Then - Sequence should remain unchanged
        assertEquals(5, dto.getSequence());
        assertEquals(2, dto.getApplication());
        assertEquals("MODIFIED", dto.getName());
    }

    @Test
    void sequence_shouldHandleTypicalOverrideScenarios() {
        // Test sequence values commonly used in overrides
        Integer[] typicalSequences = {1, 2, 3, 5, 10, 99, 100};

        for (Integer seq : typicalSequences) {
            // When
            dto.setSequence(seq);

            // Then
            assertEquals(seq, dto.getSequence());
        }
    }

    @Test
    void inheritance_shouldPreserveParentValidationAnnotations() {
        // The override DTO should inherit all validation annotations from parent
        // This test verifies the inheritance relationship exists
        
        // Given - Create override with data that would be validated by parent annotations
        dto.setApplication(1);
        dto.setName("VALID"); // @Size(max = 10) from parent
        dto.setDescription("Valid description under 40 chars"); // @Size(max = 40) from parent
        dto.setActive("Y"); // @ValidActiveType from parent
        dto.setSequence(1);

        // When & Then - Verify all fields are set correctly
        assertEquals(1, dto.getApplication());
        assertEquals("VALID", dto.getName());
        assertEquals("Valid description under 40 chars", dto.getDescription());
        assertEquals("Y", dto.getActive());
        assertEquals(1, dto.getSequence());
    }

    @Test
    void inheritance_shouldHandleParentNullPointerExceptionFields() {
        // Test that the override DTO inherits the NPE behavior from name field
        
        // Given
        dto.setName(null);
        dto.setSequence(1);
        
        // But sequence should work fine
        assertEquals(1, dto.getSequence());
    }

    @Test
    void polymorphism_shouldWorkAsCoverSheetDTO() {
        // Given - Treat as parent type
        CoverSheetDTO parentRef = new CoverSheetOverrideDTO();

        // When - Set parent fields through parent reference
        parentRef.setApplication(300);
        parentRef.setName("POLY");
        parentRef.setDescription("Polymorphic test");

        // Then - Should work through parent interface
        assertEquals(300, parentRef.getApplication());
        assertEquals("POLY", parentRef.getName());
        assertEquals("Polymorphic test", parentRef.getDescription());

        // And casting back should give access to sequence
        CoverSheetOverrideDTO childRef = (CoverSheetOverrideDTO) parentRef;
        childRef.setSequence(99);
        assertEquals(99, childRef.getSequence());
    }

    @Test
    void inheritance_shouldMaintainFieldIndependence() {
        // Given
        dto.setApplication(1);
        dto.setSequence(1);

        // When - Create another instance to verify independence
        CoverSheetOverrideDTO dto2 = new CoverSheetOverrideDTO();
        dto2.setApplication(2);
        dto2.setSequence(2);

        // Then - Instances should be independent
        assertEquals(1, dto.getApplication());
        assertEquals(1, dto.getSequence());
        assertEquals(2, dto2.getApplication());
        assertEquals(2, dto2.getSequence());
    }

    @Test
    void sequence_shouldSupportOverrideWorkflow() {
        // Test typical override workflow sequence values
        
        // Initial override
        dto.setSequence(1);
        assertEquals(1, dto.getSequence());

        // Second override
        dto.setSequence(2);
        assertEquals(2, dto.getSequence());

        // Reset to original (sequence 0 might indicate original)
        dto.setSequence(0);
        assertEquals(0, dto.getSequence());

        // Clear override (null might indicate no override)
        dto.setSequence(null);
        assertNull(dto.getSequence());
    }
}