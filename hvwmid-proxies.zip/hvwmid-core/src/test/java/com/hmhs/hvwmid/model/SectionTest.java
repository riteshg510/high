package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SectionTest {

    private Section section;

    // Setup method to initialize Section object before each test
    @BeforeEach
    void setUp() {
        section = new Section();
    }

    @Test
    void testGetAndSetLayoutType() {
        // Test set and get for 'layoutType' field
        String testLayoutType = "section";
        section.setLayoutType(testLayoutType);
        assertEquals(testLayoutType, section.getLayoutType(), "The layoutType should match the set value");
    }

    @Test
    void testGetAndSetCollapsible() {
        // Test set and get for 'collapsible' field
        section.setCollapsible(true);
        assertTrue(section.isCollapsible(), "The collapsible value should be true");
    }

    @Test
    void testGetAndSetDefaultCollapsed() {
        // Test set and get for 'defaultCollapsed' field
        section.setDefaultCollapsed(true);
        assertTrue(section.isDefaultCollapsed(), "The defaultCollapsed value should be true");
    }

    @Test
    void testGetAndSetId() {
        // Test set and get for 'id' field
        String testId = "12345";
        section.setId(testId);
        assertEquals(testId, section.getId(), "The id should match the set value");
    }

    @Test
    void testGetAndSetSid() {
        // Test set and get for 'sid' field
        String testSid = "sid123";
        section.setSid(testSid);
        assertEquals(testSid, section.getSid(), "The sid should match the set value");
    }

    @Test
    void testGetAndSetName() {
        // Test set and get for 'name' field
        String testName = "Test Section";
        section.setName(testName);
        assertEquals(testName, section.getName(), "The name should match the set value");
    }


    @Test
    void testDefaultValues() {
        // Verify default values for the class fields
        assertEquals("section", section.getLayoutType(), "The default layoutType should be 'section'");
        assertFalse(section.isCollapsible(), "The default collapsible value should be false");
        assertFalse(section.isDefaultCollapsed(), "The default defaultCollapsed value should be false");
    }
}
