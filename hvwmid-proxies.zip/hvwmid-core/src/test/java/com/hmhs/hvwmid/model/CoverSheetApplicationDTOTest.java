package com.hmhs.hvwmid.model;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CoverSheetApplicationDTOTest {

    private CoverSheetApplicationDTO dto;
    private T117ImgCoverDept department;

    @BeforeEach
    void setup() {
        dto = new CoverSheetApplicationDTO();
        
        department = new T117ImgCoverDept();
        department.setDeptId(1);
        department.setDescription("Test Department");
        department.setMaintGroup("MAINT-GROUP");
        department.setPrintGroup("PRINT-GROUP");
    }

    @Test
    void application_shouldSetAndGetCorrectly() {
        // Given
        Integer applicationId = 123;

        // When
        dto.setApplication(applicationId);

        // Then
        assertEquals(applicationId, dto.getApplication());
    }

    @Test
    void application_shouldHandleNullValue() {
        // Given
        dto.setApplication(null);

        // When & Then
        assertNull(dto.getApplication());
    }

    @Test
    void description_shouldTrimWhitespace() {
        // Given
        String descriptionWithSpaces = "  Test Description  ";

        // When
        dto.setDescription(descriptionWithSpaces);

        // Then
        assertEquals("Test Description", dto.getDescription());
    }

    @Test
    void description_shouldHandleEmptyString() {
        // Given
        dto.setDescription("");

        // When & Then
        assertEquals("", dto.getDescription());
    }

    @Test
    void description_shouldHandleStringWithOnlySpaces() {
        // Given
        dto.setDescription("   ");

        // When & Then
        assertEquals("", dto.getDescription());
    }

    @Test
    void description_shouldThrowNullPointerExceptionWhenNull() {
        // Given
        dto.setDescription(null);

        // When & Then
        assertEquals("", dto.getDescription());
    }

    @Test
    void sequence_shouldSetAndGetCorrectly() {
        // Given
        Integer sequence = 5;

        // When
        dto.setSequence(sequence);

        // Then
        assertEquals(sequence, dto.getSequence());
    }

    @Test
    void sequence_shouldHandleNullValue() {
        // Given
        dto.setSequence(null);

        // When & Then
        assertNull(dto.getSequence());
    }

    @Test
    void department_shouldSetAndGetCorrectly() {
        // When
        dto.setDeptId(department);

        // Then
        assertEquals(department, dto.getDeptId());
        assertEquals(1, dto.getDeptId().getDeptId());
        assertEquals("Test Department", dto.getDeptId().getDescription());
    }

    @Test
    void department_shouldHandleNullValue() {
        // Given
        dto.setDeptId(null);

        // When & Then
        assertNull(dto.getDeptId());
    }

    @Test
    void active_shouldTrimWhitespace() {
        // Given
        String activeWithSpaces = "  Y  ";

        // When
        dto.setActive(activeWithSpaces);

        // Then
        assertEquals("Y", dto.getActive());
    }

    @Test
    void active_shouldHandleEmptyString() {
        // Given
        dto.setActive("");

        // When & Then
        assertEquals("", dto.getActive());
    }

    @Test
    void active_shouldHandleStringWithOnlySpaces() {
        // Given
        dto.setActive("   ");

        // When & Then
        assertEquals("", dto.getActive());
    }

    @Test
    void active_shouldThrowNullPointerExceptionWhenNull() {
        // Given
        dto.setActive(null);

        // When & Then
        assertEquals("N", dto.getActive());
    }

    @Test
    void applId_shouldTrimWhitespace() {
        // Given
        String applIdWithSpaces = "  APP01  ";

        // When
        dto.setApplId(applIdWithSpaces);

        // Then
        assertEquals("APP01", dto.getApplId());
    }

    @Test
    void applId_shouldHandleEmptyString() {
        // Given
        dto.setApplId("");

        // When & Then
        assertEquals("", dto.getApplId());
    }

    @Test
    void applId_shouldHandleStringWithOnlySpaces() {
        // Given
        dto.setApplId("     ");

        // When & Then
        assertEquals("", dto.getApplId());
    }

    @Test
    void applId_shouldThrowNullPointerExceptionWhenNull() {
        // Given
        dto.setApplId(null);

        // When & Then
        assertEquals("", dto.getApplId());
    }

    @Test
    void dto_shouldHandleCompleteObjectCreation() {
        // Given
        Integer applicationId = 100;
        String description = "Complete Test Application";
        Integer sequence = 1;
        String active = "Y";
        String applId = "CTA01";

        // When
        dto.setApplication(applicationId);
        dto.setDescription(description);
        dto.setSequence(sequence);
        dto.setDeptId(department);
        dto.setActive(active);
        dto.setApplId(applId);

        // Then
        assertEquals(applicationId, dto.getApplication());
        assertEquals(description, dto.getDescription());
        assertEquals(sequence, dto.getSequence());
        assertEquals(department, dto.getDeptId());
        assertEquals(active, dto.getActive());
        assertEquals(applId, dto.getApplId());
    }

    @Test
    void dto_shouldHandleCompleteObjectWithWhitespace() {
        // Given - All string fields have leading/trailing whitespace
        String descriptionWithSpaces = "  Test Description  ";
        String activeWithSpaces = "  Y  ";
        String applIdWithSpaces = "  APP01  ";

        // When
        dto.setDescription(descriptionWithSpaces);
        dto.setActive(activeWithSpaces);
        dto.setApplId(applIdWithSpaces);

        // Then - All getters should return trimmed values
        assertEquals("Test Description", dto.getDescription());
        assertEquals("Y", dto.getActive());
        assertEquals("APP01", dto.getApplId());
    }

    @Test
    void dto_shouldCreateWithDefaultConstructor() {
        // When
        CoverSheetApplicationDTO newDto = new CoverSheetApplicationDTO();

        // Then - All fields should be null by default
        assertNull(newDto.getApplication());
        assertNull(newDto.getSequence());
        assertNull(newDto.getDeptId());

    }

    @Test
    void dto_shouldHandleMethodNamingInconsistency() {
        // Note: The getter method is named getDeptId() but setter is setDeptId()
        // This is inconsistent but we test the actual behavior

        // When
        dto.setDeptId(department);

        // Then
        assertEquals(department, dto.getDeptId());
        assertSame(department, dto.getDeptId()); // Should be the same object reference
    }

    @Test
    void dto_shouldPreserveObjectReferences() {
        // Given
        T117ImgCoverDept originalDepartment = new T117ImgCoverDept();
        originalDepartment.setDeptId(99);

        // When
        dto.setDeptId(originalDepartment);

        // Then
        assertSame(originalDepartment, dto.getDeptId());
        
        // Modifying the original should affect the DTO's reference
        originalDepartment.setDeptId(100);
        assertEquals(100, dto.getDeptId().getDeptId());
    }

    @Test
    void dto_shouldHandleBoundaryValues() {
        // Given - Test boundary values for Integer fields
        dto.setApplication(Integer.MAX_VALUE);
        dto.setSequence(Integer.MIN_VALUE);

        // When & Then
        assertEquals(Integer.MAX_VALUE, dto.getApplication());
        assertEquals(Integer.MIN_VALUE, dto.getSequence());
    }

    @Test
    void dto_shouldHandleSpecialCharactersInStrings() {
        // Given
        String descriptionWithSpecialChars = "  Test!@#$%^&*()Description  ";
        String activeWithSpecialChars = "  Y!  ";
        String applIdWithSpecialChars = "  APP@1  ";

        // When
        dto.setDescription(descriptionWithSpecialChars);
        dto.setActive(activeWithSpecialChars);
        dto.setApplId(applIdWithSpecialChars);

        // Then
        assertEquals("Test!@#$%^&*()Description", dto.getDescription());
        assertEquals("Y!", dto.getActive());
        assertEquals("APP@1", dto.getApplId());
    }

    @Test
    void dto_shouldHandleUnicodeCharacters() {
        // Given
        String descriptionWithUnicode = "  Tëst Dëscriptïön  ";
        String applIdWithUnicode = "  AÞÞ01  ";

        // When
        dto.setDescription(descriptionWithUnicode);
        dto.setApplId(applIdWithUnicode);

        // Then
        assertEquals("Tëst Dëscriptïön", dto.getDescription());
        assertEquals("AÞÞ01", dto.getApplId());
    }
}