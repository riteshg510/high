package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for GenerateIMIRequest model
 */
class GenerateIMIRequestTest {

    private GenerateIMIRequest request;

    @BeforeEach
    void setUp() {
        request = new GenerateIMIRequest();
    }

    @Test
    void testGetSetExcelId() {
        // Arrange
        Integer excelId = 12345;

        // Act
        request.setExcelId(excelId);

        // Assert
        assertEquals(excelId, request.getExcelId());
    }

    @Test
    void testGetSetFileIdMappings() {
        // Arrange
        List<GenerateIMIRequest.FileIdMapping> mappings = new ArrayList<>();
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();
        mapping.setFileId(123);
        mapping.setExcelFileName("test.pdf");
        mappings.add(mapping);

        // Act
        request.setFileIdMappings(mappings);

        // Assert
        assertEquals(mappings, request.getFileIdMappings());
        assertEquals(1, request.getFileIdMappings().size());
        assertEquals(Integer.valueOf(123), request.getFileIdMappings().get(0).getFileId());
        assertEquals("test.pdf", request.getFileIdMappings().get(0).getExcelFileName());
    }

    @Test
    void testGetSetMappings() {
        // Arrange
        List<GenerateIMIRequest.SegmentMapping> mappings = new ArrayList<>();
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();
        mapping.setSegmentName("FID");
        mapping.setType("U");
        mapping.setValue("");
        mappings.add(mapping);

        // Act
        request.setMappings(mappings);

        // Assert
        assertEquals(mappings, request.getMappings());
        assertEquals(1, request.getMappings().size());
        assertEquals("FID", request.getMappings().get(0).getSegmentName());
    }

    @Test
    void testGetSetOutputConfig() {
        // Arrange
        GenerateIMIRequest.OutputConfig config = new GenerateIMIRequest.OutputConfig();
        config.setDocumentsPerIMI(50);
        config.setFilePriority(90);

        // Act
        request.setOutputConfig(config);

        // Assert
        assertEquals(config, request.getOutputConfig());
        assertEquals(Integer.valueOf(50), request.getOutputConfig().getDocumentsPerIMI());
        assertEquals(Integer.valueOf(90), request.getOutputConfig().getFilePriority());
    }

    @Test
    void testSerializableImplementation() {
        // Assert that the class implements Serializable
        assertTrue(request instanceof java.io.Serializable);
    }

    @Test
    void testCompleteRequestSetup() {
        // Arrange
        Integer excelId = 12345;
        
        List<GenerateIMIRequest.FileIdMapping> fileMappings = Arrays.asList(
            createFileMapping(100, "document1.pdf"),
            createFileMapping(101, "document2.tif")
        );
        
        List<GenerateIMIRequest.SegmentMapping> segmentMappings = Arrays.asList(
            createSegmentMapping("FID", "U", ""),
            createSegmentMapping("DPK", "M", "FileName"),
            createSegmentMapping("IMG", "C", "IMAGE_DATA")
        );
        
        GenerateIMIRequest.OutputConfig outputConfig = new GenerateIMIRequest.OutputConfig();
        outputConfig.setDocumentsPerIMI(25);
        outputConfig.setFilePriority(99);

        // Act
        request.setExcelId(excelId);
        request.setFileIdMappings(fileMappings);
        request.setMappings(segmentMappings);
        request.setOutputConfig(outputConfig);

        // Assert
        assertEquals(excelId, request.getExcelId());
        assertEquals(2, request.getFileIdMappings().size());
        assertEquals(3, request.getMappings().size());
        assertNotNull(request.getOutputConfig());
    }

    @Test
    void testDefaultConstructor() {
        // Act
        GenerateIMIRequest newRequest = new GenerateIMIRequest();

        // Assert
        assertNull(newRequest.getExcelId());
        assertNull(newRequest.getFileIdMappings());
        assertNull(newRequest.getMappings());
        assertNull(newRequest.getOutputConfig());
    }

    // Helper methods
    private GenerateIMIRequest.FileIdMapping createFileMapping(Integer fileId, String fileName) {
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();
        mapping.setFileId(fileId);
        mapping.setExcelFileName(fileName);
        return mapping;
    }

    private GenerateIMIRequest.SegmentMapping createSegmentMapping(String name, String type, String value) {
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();
        mapping.setSegmentName(name);
        mapping.setType(type);
        mapping.setValue(value);
        return mapping;
    }

    // Tests for nested FileIdMapping class
    @Test
    void testFileIdMappingGetSetFileId() {
        // Arrange
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();
        Integer fileId = 123;

        // Act
        mapping.setFileId(fileId);

        // Assert
        assertEquals(fileId, mapping.getFileId());
    }

    @Test
    void testFileIdMappingGetSetExcelFileName() {
        // Arrange
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();
        String fileName = "test-document.pdf";

        // Act
        mapping.setExcelFileName(fileName);

        // Assert
        assertEquals(fileName, mapping.getExcelFileName());
    }

    @Test
    void testFileIdMappingSerializable() {
        // Arrange
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();

        // Assert
        assertTrue(mapping instanceof java.io.Serializable);
    }

    @Test
    void testFileIdMappingDefaultConstructor() {
        // Act
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();

        // Assert
        assertNull(mapping.getFileId());
        assertNull(mapping.getExcelFileName());
    }

    // Tests for nested SegmentMapping class
    @Test
    void testSegmentMappingGetSetSegmentName() {
        // Arrange
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();
        String segmentName = "FID";

        // Act
        mapping.setSegmentName(segmentName);

        // Assert
        assertEquals(segmentName, mapping.getSegmentName());
    }

    @Test
    void testSegmentMappingGetSetType() {
        // Arrange
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();
        String type = "M";

        // Act
        mapping.setType(type);

        // Assert
        assertEquals(type, mapping.getType());
    }

    @Test
    void testSegmentMappingGetSetValue() {
        // Arrange
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();
        String value = "ColumnName";

        // Act
        mapping.setValue(value);

        // Assert
        assertEquals(value, mapping.getValue());
    }

    @Test
    void testSegmentMappingSerializable() {
        // Arrange
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();

        // Assert
        assertTrue(mapping instanceof java.io.Serializable);
    }

    @Test
    void testSegmentMappingDefaultConstructor() {
        // Act
        GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();

        // Assert
        assertNull(mapping.getSegmentName());
        assertNull(mapping.getType());
        assertNull(mapping.getValue());
    }

    @Test
    void testSegmentMappingWithDifferentTypes() {
        // Test all segment types
        String[] types = {"U", "M", "C"};
        String[] values = {"", "ColumnName", "CONSTANT_VALUE"};

        for (int i = 0; i < types.length; i++) {
            GenerateIMIRequest.SegmentMapping mapping = new GenerateIMIRequest.SegmentMapping();
            mapping.setSegmentName("TEST" + i);
            mapping.setType(types[i]);
            mapping.setValue(values[i]);

            assertEquals("TEST" + i, mapping.getSegmentName());
            assertEquals(types[i], mapping.getType());
            assertEquals(values[i], mapping.getValue());
        }
    }

    // Tests for nested OutputConfig class
    @Test
    void testOutputConfigGetSetDocumentsPerIMI() {
        // Arrange
        GenerateIMIRequest.OutputConfig config = new GenerateIMIRequest.OutputConfig();
        Integer documentsPerIMI = 50;

        // Act
        config.setDocumentsPerIMI(documentsPerIMI);

        // Assert
        assertEquals(documentsPerIMI, config.getDocumentsPerIMI());
    }

    @Test
    void testOutputConfigGetSetFilePriority() {
        // Arrange
        GenerateIMIRequest.OutputConfig config = new GenerateIMIRequest.OutputConfig();
        Integer filePriority = 90;

        // Act
        config.setFilePriority(filePriority);

        // Assert
        assertEquals(filePriority, config.getFilePriority());
    }

    @Test
    void testOutputConfigDefaultValues() {
        // Act
        GenerateIMIRequest.OutputConfig config = new GenerateIMIRequest.OutputConfig();

        // Assert - Test default values
        assertEquals(Integer.valueOf(25), config.getDocumentsPerIMI());
        assertEquals(Integer.valueOf(99), config.getFilePriority());
    }

    @Test
    void testOutputConfigSerializable() {
        // Arrange
        GenerateIMIRequest.OutputConfig config = new GenerateIMIRequest.OutputConfig();

        // Assert
        assertTrue(config instanceof java.io.Serializable);
    }

    @Test
    void testOutputConfigBoundaryValues() {
        // Arrange
        GenerateIMIRequest.OutputConfig config = new GenerateIMIRequest.OutputConfig();

        // Test minimum values
        config.setDocumentsPerIMI(1);
        config.setFilePriority(1);
        assertEquals(Integer.valueOf(1), config.getDocumentsPerIMI());
        assertEquals(Integer.valueOf(1), config.getFilePriority());

        // Test maximum values
        config.setDocumentsPerIMI(2000);
        config.setFilePriority(100);
        assertEquals(Integer.valueOf(2000), config.getDocumentsPerIMI());
        assertEquals(Integer.valueOf(100), config.getFilePriority());
    }
}