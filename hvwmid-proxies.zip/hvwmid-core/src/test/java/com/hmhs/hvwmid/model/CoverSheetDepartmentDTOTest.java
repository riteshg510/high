package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CoverSheetDepartmentDTOTest {

    private CoverSheetDepartmentDTO dto;
    private List<CoverSheetApplicationDTO> sampleApplications;

    @BeforeEach
    void setup() {
        dto = new CoverSheetDepartmentDTO();
        
        // Setup sample applications list
        CoverSheetApplicationDTO app1 = new CoverSheetApplicationDTO();
        app1.setApplication(1);
        app1.setDescription("Application 1");
        app1.setActive("Y");
        
        CoverSheetApplicationDTO app2 = new CoverSheetApplicationDTO();
        app2.setApplication(2);
        app2.setDescription("Application 2");
        app2.setActive("N");
        
        sampleApplications = Arrays.asList(app1, app2);
    }

    @Test
    void deptId_shouldSetAndGetCorrectly() {
        // Given
        Integer deptId = 123;

        // When
        dto.setDeptId(deptId);

        // Then
        assertEquals(deptId, dto.getDeptId());
    }

    @Test
    void deptId_shouldHandleNullValue() {
        // Given
        dto.setDeptId(null);

        // When & Then
        assertNull(dto.getDeptId());
    }

    @Test
    void deptId_shouldHandleBoundaryValues() {
        // Given
        dto.setDeptId(Integer.MAX_VALUE);

        // When & Then
        assertEquals(Integer.MAX_VALUE, dto.getDeptId());

        // Given
        dto.setDeptId(Integer.MIN_VALUE);

        // When & Then
        assertEquals(Integer.MIN_VALUE, dto.getDeptId());
    }

    @Test
    void description_shouldSetAndGetCorrectly() {
        // Given
        String description = "Test Department Description";

        // When
        dto.setDescription(description);

        // Then
        assertEquals(description, dto.getDescription());
    }

    @Test
    void description_shouldHandleNullValue() {
        // Given
        dto.setDescription(null);

        // When & Then
        assertNull(dto.getDescription());
    }

    @Test
    void description_shouldHandleEmptyString() {
        // Given
        dto.setDescription("");

        // When & Then
        assertEquals("", dto.getDescription());
    }

    @Test
    void description_shouldPreserveWhitespace() {
        // Given - Note: Unlike CoverSheetApplicationDTO, this class doesn't trim whitespace
        String descriptionWithSpaces = "  Test Description  ";

        // When
        dto.setDescription(descriptionWithSpaces);

        // Then
        assertEquals("  Test Description  ", dto.getDescription());
    }

    @Test
    void maintGroup_shouldSetAndGetCorrectly() {
        // Given
        String maintGroup = "MAINT-GROUP-1";

        // When
        dto.setMaintGroup(maintGroup);

        // Then
        assertEquals(maintGroup, dto.getMaintGroup());
    }

    @Test
    void maintGroup_shouldHandleNullValue() {
        // Given
        dto.setMaintGroup(null);

        // When & Then
        assertNull(dto.getMaintGroup());
    }

    @Test
    void maintGroup_shouldHandleEmptyString() {
        // Given
        dto.setMaintGroup("");

        // When & Then
        assertEquals("", dto.getMaintGroup());
    }

    @Test
    void printGroup_shouldSetAndGetCorrectly() {
        // Given
        String printGroup = "PRINT-GROUP-1";

        // When
        dto.setPrintGroup(printGroup);

        // Then
        assertEquals(printGroup, dto.getPrintGroup());
    }

    @Test
    void printGroup_shouldHandleNullValue() {
        // Given
        dto.setPrintGroup(null);

        // When & Then
        assertNull(dto.getPrintGroup());
    }

    @Test
    void printGroup_shouldHandleEmptyString() {
        // Given
        dto.setPrintGroup("");

        // When & Then
        assertEquals("", dto.getPrintGroup());
    }

    @Test
    void departments_shouldSetAndGetCorrectly() {
        // When
        dto.setDepartments(sampleApplications);

        // Then
        assertEquals(sampleApplications, dto.getDepartments());
        assertEquals(2, dto.getDepartments().size());
        assertEquals(1, dto.getDepartments().get(0).getApplication());
        assertEquals(2, dto.getDepartments().get(1).getApplication());
    }

    @Test
    void departments_shouldHandleNullValue() {
        // Given
        dto.setDepartments(null);

        // When & Then
        assertNull(dto.getDepartments());
    }

    @Test
    void departments_shouldHandleEmptyList() {
        // Given
        List<CoverSheetApplicationDTO> emptyList = new ArrayList<>();

        // When
        dto.setDepartments(emptyList);

        // Then
        assertEquals(emptyList, dto.getDepartments());
        assertEquals(0, dto.getDepartments().size());
    }

    @Test
    void departments_shouldPreserveListReference() {
        // Given
        List<CoverSheetApplicationDTO> originalList = new ArrayList<>(sampleApplications);

        // When
        dto.setDepartments(originalList);

        // Then
        assertSame(originalList, dto.getDepartments());
        
        // Modifying the original list should affect the DTO's reference
        CoverSheetApplicationDTO newApp = new CoverSheetApplicationDTO();
        newApp.setApplication(3);
        originalList.add(newApp);
        
        assertEquals(3, dto.getDepartments().size());
        assertEquals(3, dto.getDepartments().get(2).getApplication());
    }

    @Test
    void canMaintain_shouldHaveDefaultValueFalse() {
        // Given - Fresh DTO instance
        CoverSheetDepartmentDTO newDto = new CoverSheetDepartmentDTO();

        // When & Then
        assertEquals(false, newDto.getCanMaintain());
        assertFalse(newDto.getCanMaintain());
    }

    @Test
    void canMaintain_shouldSetAndGetCorrectly() {
        // Given
        dto.setCanMaintain(true);

        // When & Then
        assertEquals(true, dto.getCanMaintain());
        assertTrue(dto.getCanMaintain());

        // Given
        dto.setCanMaintain(false);

        // When & Then
        assertEquals(false, dto.getCanMaintain());
        assertFalse(dto.getCanMaintain());
    }

    @Test
    void canMaintain_shouldHandleNullValue() {
        // Given
        dto.setCanMaintain(null);

        // When & Then
        assertNull(dto.getCanMaintain());
    }

    @Test
    void dto_shouldHandleCompleteObjectCreation() {
        // Given
        Integer deptId = 100;
        String description = "Complete Test Department";
        String maintGroup = "MAINT-GROUP";
        String printGroup = "PRINT-GROUP";
        Boolean canMaintain = true;

        // When
        dto.setDeptId(deptId);
        dto.setDescription(description);
        dto.setMaintGroup(maintGroup);
        dto.setPrintGroup(printGroup);
        dto.setDepartments(sampleApplications);
        dto.setCanMaintain(canMaintain);

        // Then
        assertEquals(deptId, dto.getDeptId());
        assertEquals(description, dto.getDescription());
        assertEquals(maintGroup, dto.getMaintGroup());
        assertEquals(printGroup, dto.getPrintGroup());
        assertEquals(sampleApplications, dto.getDepartments());
        assertEquals(canMaintain, dto.getCanMaintain());
    }

    @Test
    void dto_shouldCreateWithDefaultConstructor() {
        // When
        CoverSheetDepartmentDTO newDto = new CoverSheetDepartmentDTO();

        // Then - Most fields should be null by default, except canMaintain
        assertNull(newDto.getDeptId());
        assertNull(newDto.getDescription());
        assertNull(newDto.getMaintGroup());
        assertNull(newDto.getPrintGroup());
        assertNull(newDto.getDepartments());
        assertEquals(false, newDto.getCanMaintain()); // Has default value
    }

    @Test
    void dto_shouldHandleSpecialCharactersInStrings() {
        // Given
        String descriptionWithSpecialChars = "Test!@#$%^&*()Department";
        String maintGroupWithSpecialChars = "MAINT@GROUP#1";
        String printGroupWithSpecialChars = "PRINT$GROUP%1";

        // When
        dto.setDescription(descriptionWithSpecialChars);
        dto.setMaintGroup(maintGroupWithSpecialChars);
        dto.setPrintGroup(printGroupWithSpecialChars);

        // Then
        assertEquals(descriptionWithSpecialChars, dto.getDescription());
        assertEquals(maintGroupWithSpecialChars, dto.getMaintGroup());
        assertEquals(printGroupWithSpecialChars, dto.getPrintGroup());
    }

    @Test
    void dto_shouldHandleUnicodeCharacters() {
        // Given
        String descriptionWithUnicode = "Tëst Dëpartmënt";
        String maintGroupWithUnicode = "MÄÏNT-GRØUP";
        String printGroupWithUnicode = "PRÏNT-GRØUP";

        // When
        dto.setDescription(descriptionWithUnicode);
        dto.setMaintGroup(maintGroupWithUnicode);
        dto.setPrintGroup(printGroupWithUnicode);

        // Then
        assertEquals(descriptionWithUnicode, dto.getDescription());
        assertEquals(maintGroupWithUnicode, dto.getMaintGroup());
        assertEquals(printGroupWithUnicode, dto.getPrintGroup());
    }

    @Test
    void dto_shouldHandleVeryLongStrings() {
        // Given
        String longDescription = "A".repeat(1000);
        String longMaintGroup = "MAINT-" + "X".repeat(100);
        String longPrintGroup = "PRINT-" + "Y".repeat(100);

        // When
        dto.setDescription(longDescription);
        dto.setMaintGroup(longMaintGroup);
        dto.setPrintGroup(longPrintGroup);

        // Then
        assertEquals(longDescription, dto.getDescription());
        assertEquals(longMaintGroup, dto.getMaintGroup());
        assertEquals(longPrintGroup, dto.getPrintGroup());
        assertEquals(1000, dto.getDescription().length());
    }

    @Test
    void dto_shouldHandleLargeApplicationsList() {
        // Given
        List<CoverSheetApplicationDTO> largeList = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            CoverSheetApplicationDTO app = new CoverSheetApplicationDTO();
            app.setApplication(i);
            app.setDescription("App " + i);
            largeList.add(app);
        }

        // When
        dto.setDepartments(largeList);

        // Then
        assertEquals(1000, dto.getDepartments().size());
        assertEquals(0, dto.getDepartments().get(0).getApplication());
        assertEquals(999, dto.getDepartments().get(999).getApplication());
    }

    @Test
    void dto_shouldMaintainIndependenceFromApplicationObjects() {
        // Given
        CoverSheetApplicationDTO app = new CoverSheetApplicationDTO();
        app.setApplication(1);
        app.setDescription("Original Description");
        List<CoverSheetApplicationDTO> appList = Arrays.asList(app);

        // When
        dto.setDepartments(appList);

        // Then
        assertEquals("Original Description", dto.getDepartments().get(0).getDescription());

        // Modifying the original application object should affect the DTO's reference
        app.setDescription("Modified Description");
        assertEquals("Modified Description", dto.getDepartments().get(0).getDescription());
    }

    @Test
    void dto_shouldHandleBooleanEdgeCases() {
        // Test Boolean.TRUE
        dto.setCanMaintain(Boolean.TRUE);
        assertEquals(Boolean.TRUE, dto.getCanMaintain());
        assertTrue(dto.getCanMaintain());

        // Test Boolean.FALSE
        dto.setCanMaintain(Boolean.FALSE);
        assertEquals(Boolean.FALSE, dto.getCanMaintain());
        assertFalse(dto.getCanMaintain());

        // Test primitive boolean conversion
        dto.setCanMaintain(true);
        assertEquals(Boolean.TRUE, dto.getCanMaintain());

        dto.setCanMaintain(false);
        assertEquals(Boolean.FALSE, dto.getCanMaintain());
    }
}