package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CoverSheetObjectDTOTest {

    private CoverSheetObjectDTO dto;

    @BeforeEach
    void setup() {
        // Note: CoverSheetObjectDTO requires constructor parameters, no default constructor
    }

    @Test
    void constructor_shouldCreateObjectWithAllFields() {
        // Given
        String objName = "INVOICE";
        String objType = "TEMPLATE";
        String mimeType = "application/pdf";
        String objData = "PDF content data";

        // When
        dto = new CoverSheetObjectDTO(objName, objType, mimeType, objData);

        // Then
        assertEquals(objName, dto.getObjName());
        assertEquals(objType, dto.getObjType());
        assertEquals(mimeType, dto.getMimeType());
        assertEquals(objData, dto.getObjData());
    }

    @Test
    void constructor_shouldHandleNullValues() {
        // When
        dto = new CoverSheetObjectDTO(null, null, null, null);

        // Then
        assertNull(dto.getObjName());
        assertNull(dto.getObjType());
        assertEquals("", dto.getMimeType());
        assertNull(dto.getObjData());
    }

    @Test
    void objName_shouldSetAndGetCorrectly() {
        // Given
        dto = new CoverSheetObjectDTO("INITIAL", "TYPE", "text/plain", "data");
        String newObjName = "UPDATED";

        // When
        dto.setObjName(newObjName);

        // Then
        assertEquals(newObjName, dto.getObjName());
    }

    @Test
    void objName_shouldHandleNullValue() {
        // Given
        dto = new CoverSheetObjectDTO("INITIAL", "TYPE", "text/plain", "data");

        // When
        dto.setObjName(null);

        // Then
        assertNull(dto.getObjName());
    }

    @Test
    void objName_shouldHandleEmptyString() {
        // Given
        dto = new CoverSheetObjectDTO("INITIAL", "TYPE", "text/plain", "data");

        // When
        dto.setObjName("");

        // Then
        assertEquals("", dto.getObjName());
    }

    @Test
    void objType_shouldSetAndGetCorrectly() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "INITIAL", "text/plain", "data");
        String newObjType = "UPDATED";

        // When
        dto.setObjType(newObjType);

        // Then
        assertEquals(newObjType, dto.getObjType());
    }

    @Test
    void objType_shouldHandleNullValue() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "INITIAL", "text/plain", "data");

        // When
        dto.setObjType(null);

        // Then
        assertNull(dto.getObjType());
    }

    @Test
    void mimeType_shouldSetAndGetCorrectly() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "TYPE", "text/plain", "data");
        String newMimeType = "application/json";

        // When
        dto.setMimeType(newMimeType);

        // Then
        assertEquals(newMimeType, dto.getMimeType());
    }

    @Test
    void mimeType_shouldHandleNullValue() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "TYPE", "text/plain", "data");

        // When
        dto.setMimeType(null);

        // Then
        assertEquals("", dto.getMimeType());
    }

    @Test
    void objData_shouldSetAndGetCorrectly() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "TYPE", "text/plain", "initial");
        String newObjData = "updated data content";

        // When
        dto.setObjData(newObjData);

        // Then
        assertEquals(newObjData, dto.getObjData());
    }

    @Test
    void objData_shouldHandleNullValue() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "TYPE", "text/plain", "initial");

        // When
        dto.setObjData(null);

        // Then
        assertNull(dto.getObjData());
    }

    @Test
    void objData_shouldHandleLargeContent() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "TYPE", "text/plain", "initial");
        String largeData = "X".repeat(10000);

        // When
        dto.setObjData(largeData);

        // Then
        assertEquals(largeData, dto.getObjData());
        assertEquals(10000, dto.getObjData().length());
    }

    @Test
    void constructor_shouldHandleTypicalTemplateScenarios() {
        // Test HTML template
        dto = new CoverSheetObjectDTO("FORM1", "TEMPLATE", "text/html", "<html><body>Template</body></html>");
        assertEquals("FORM1", dto.getObjName());
        assertEquals("TEMPLATE", dto.getObjType());
        assertEquals("text/html", dto.getMimeType());
        assertTrue(dto.getObjData().contains("<html>"));

        // Test PDF template
        dto = new CoverSheetObjectDTO("INVOICE", "TEMPLATE", "application/pdf", "PDF binary data");
        assertEquals("INVOICE", dto.getObjName());
        assertEquals("TEMPLATE", dto.getObjType());
        assertEquals("application/pdf", dto.getMimeType());
        assertEquals("PDF binary data", dto.getObjData());

        // Test JavaScript template
        dto = new CoverSheetObjectDTO("SCRIPT", "TEMPLATE", "application/javascript", "function test() {}");
        assertEquals("SCRIPT", dto.getObjName());
        assertEquals("TEMPLATE", dto.getObjType());
        assertEquals("application/javascript", dto.getMimeType());
        assertEquals("function test() {}", dto.getObjData());
    }

    @Test
    void fields_shouldHandleSpecialCharacters() {
        // Given
        String objName = "OBJ!@#";
        String objType = "TYPE$%^";
        String mimeType = "text/plain; charset=UTF-8";
        String objData = "Data with special chars: !@#$%^&*()";

        // When
        dto = new CoverSheetObjectDTO(objName, objType, mimeType, objData);

        // Then
        assertEquals(objName, dto.getObjName());
        assertEquals(objType, dto.getObjType());
        assertEquals(mimeType, dto.getMimeType());
        assertEquals(objData, dto.getObjData());
    }

    @Test
    void fields_shouldHandleUnicodeCharacters() {
        // Given
        String objName = "ÖBJ_Tëst";
        String objType = "TŸPÉ";
        String mimeType = "text/plain; charset=UTF-8";
        String objData = "Üñîçødë data: 测试内容";

        // When
        dto = new CoverSheetObjectDTO(objName, objType, mimeType, objData);

        // Then
        assertEquals(objName, dto.getObjName());
        assertEquals(objType, dto.getObjType());
        assertEquals(mimeType, dto.getMimeType());
        assertEquals(objData, dto.getObjData());
    }

    @Test
    void fields_shouldHandleWhitespaceValues() {
        // Given
        String objName = "  SPACED  ";
        String objType = "  TYPE  ";
        String mimeType = "  text/plain  ";
        String objData = "  Data with spaces  ";

        // When
        dto = new CoverSheetObjectDTO(objName, objType, mimeType, objData);

        // Then - Fields should preserve whitespace (no trimming)
        assertEquals("  SPACED  ", dto.getObjName());
        assertEquals("  TYPE  ", dto.getObjType());
        assertEquals("  text/plain  ", dto.getMimeType());
        assertEquals("  Data with spaces  ", dto.getObjData());
    }

    @Test
    void objData_shouldHandleVariousContentTypes() {
        // Test JSON data
        dto = new CoverSheetObjectDTO("CONFIG", "TEMPLATE", "application/json", "{\"key\": \"value\"}");
        assertEquals("{\"key\": \"value\"}", dto.getObjData());

        // Test XML data
        dto.setObjData("<?xml version=\"1.0\"?><root><item>test</item></root>");
        assertEquals("<?xml version=\"1.0\"?><root><item>test</item></root>", dto.getObjData());

        // Test CSS data
        dto.setObjData("body { margin: 0; padding: 0; }");
        assertEquals("body { margin: 0; padding: 0; }", dto.getObjData());

        // Test Base64 encoded data
        dto.setObjData("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgA...");
        assertTrue(dto.getObjData().startsWith("data:image/png;base64,"));
    }

    @Test
    void constructor_shouldHandleEmptyStrings() {
        // When
        dto = new CoverSheetObjectDTO("", "", "", "");

        // Then
        assertEquals("", dto.getObjName());
        assertEquals("", dto.getObjType());
        assertEquals("", dto.getMimeType());
        assertEquals("", dto.getObjData());
    }

    @Test
    void setters_shouldAllowFieldModification() {
        // Given
        dto = new CoverSheetObjectDTO("ORIGINAL", "ORIGINAL", "text/plain", "original");

        // When
        dto.setObjName("MODIFIED");
        dto.setObjType("MODIFIED");
        dto.setMimeType("application/json");
        dto.setObjData("modified data");

        // Then
        assertEquals("MODIFIED", dto.getObjName());
        assertEquals("MODIFIED", dto.getObjType());
        assertEquals("application/json", dto.getMimeType());
        assertEquals("modified data", dto.getObjData());
    }

    @Test
    void constructor_shouldHandleMaxLengthScenarios() {
        // Given - Test with maximum expected lengths based on validation annotations
        String maxObjName = "A".repeat(10); // @Size(max = 10)
        String maxObjType = "B".repeat(10); // @Size(max = 10)
        String longMimeType = "text/plain; charset=UTF-8; boundary=something-long";
        String longObjData = "X".repeat(100000);

        // When
        dto = new CoverSheetObjectDTO(maxObjName, maxObjType, longMimeType, longObjData);

        // Then
        assertEquals(10, dto.getObjName().length());
        assertEquals(10, dto.getObjType().length());
        assertEquals(maxObjName, dto.getObjName());
        assertEquals(maxObjType, dto.getObjType());
        assertEquals(longMimeType, dto.getMimeType());
        assertEquals(100000, dto.getObjData().length());
    }

    @Test
    void constructor_shouldHandleTypicalValidationConstraints() {
        // Test valid scenarios that would pass validation
        String[] validNames = {"INVOICE", "FORM1", "TEMPLATE", "A", "1234567890"};
        String[] validTypes = {"TEMPLATE", "FORM", "OBJECT", "TYPE", "1234567890"};
        String[] validMimeTypes = {"text/html", "application/pdf", "text/plain", "application/json"};

        for (String name : validNames) {
            for (String type : validTypes) {
                for (String mimeType : validMimeTypes) {
                    // When
                    dto = new CoverSheetObjectDTO(name, type, mimeType, "test data");

                    // Then
                    assertEquals(name, dto.getObjName());
                    assertEquals(type, dto.getObjType());
                    assertEquals(mimeType, dto.getMimeType());
                    assertEquals("test data", dto.getObjData());
                }
            }
        }
    }

    @Test
    void fields_shouldMaintainIndependence() {
        // Given
        dto = new CoverSheetObjectDTO("NAME", "TYPE", "text/plain", "data");

        // When - Modify each field independently
        dto.setObjName("NEW_NAME");
        assertEquals("NEW_NAME", dto.getObjName());
        assertEquals("TYPE", dto.getObjType()); // Others unchanged

        dto.setObjType("NEW_TYPE");
        assertEquals("NEW_NAME", dto.getObjName()); // Previous change preserved
        assertEquals("NEW_TYPE", dto.getObjType());

        dto.setMimeType("application/json");
        assertEquals("NEW_NAME", dto.getObjName());
        assertEquals("NEW_TYPE", dto.getObjType());
        assertEquals("application/json", dto.getMimeType());

        dto.setObjData("new data");
        assertEquals("NEW_NAME", dto.getObjName());
        assertEquals("NEW_TYPE", dto.getObjType());
        assertEquals("application/json", dto.getMimeType());
        assertEquals("new data", dto.getObjData());
    }
}