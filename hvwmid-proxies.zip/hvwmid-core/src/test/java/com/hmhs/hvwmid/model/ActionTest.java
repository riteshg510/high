package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ActionTest {

    private Action action;

    // Setup method to initialize Action object before each test
    @BeforeEach
    void setUp() {
        action = new Action();
    }

    @Test
    void testGetAndSetActionName() {
        // Test set and get for 'actionName' field
        String testActionName = "Test Action";
        action.setActionName(testActionName);
        assertEquals(testActionName, action.getActionName(), "The actionName should match the set value");
    }

    @Test
    void testGetAndSetActionIcon() {
        // Test set and get for 'actionIcon' field
        String testActionIcon = "icon-test";
        action.setActionIcon(testActionIcon);
        assertEquals(testActionIcon, action.getActionIcon(), "The actionIcon should match the set value");
    }

    @Test
    void testGetAndSetActionType() {
        // Test set and get for 'actionType' field
        String testActionType = "button";
        action.setActionType(testActionType);
        assertEquals(testActionType, action.getActionType(), "The actionType should match the set value");
    }

    @Test
    void testGetAndSetApiUrl() {
        // Test set and get for 'apiUrl' field
        String testApiUrl = "https://api.example.com";
        action.setApiUrl(testApiUrl);
        assertEquals(testApiUrl, action.getApiUrl(), "The apiUrl should match the set value");
    }

    @Test
    void testGetAndSetLabel() {
        // Test set and get for 'label' field
        String testLabel = "Submit";
        action.setLabel(testLabel);
        assertEquals(testLabel, action.getLabel(), "The label should match the set value");
    }

    @Test
    void testGetAndSetNavigateUrl() {
        // Test set and get for 'navigateUrl' field
        String testNavigateUrl = "https://www.example.com";
        action.setNavigateUrl(testNavigateUrl);
        assertEquals(testNavigateUrl, action.getNavigateUrl(), "The navigateUrl should match the set value");
    }

    @Test
    void testGetAndSetVariant() {
        // Test set and get for 'variant' field
        String testVariant = "primary";
        action.setVariant(testVariant);
        assertEquals(testVariant, action.getVariant(), "The variant should match the set value");
    }

    @Test
    void testGetAndSetTableId() {
        // Test set and get for 'tableId' field
        String testTableId = "table123";
        action.setTableId(testTableId);
        assertEquals(testTableId, action.getTableId(), "The tableId should match the set value");
    }

    @Test
    void testDefaultValues() {
        // Verify default values for the class fields
        assertNull(action.getActionName(), "The default actionName should be null");
        assertNull(action.getActionIcon(), "The default actionIcon should be null");
        assertNull(action.getActionType(), "The default actionType should be null");
        assertNull(action.getApiUrl(), "The default apiUrl should be null");
        assertNull(action.getLabel(), "The default label should be null");
        assertNull(action.getNavigateUrl(), "The default navigateUrl should be null");
        assertNull(action.getVariant(), "The default variant should be null");
        assertNull(action.getTableId(), "The default tableId should be null");
    }
}
