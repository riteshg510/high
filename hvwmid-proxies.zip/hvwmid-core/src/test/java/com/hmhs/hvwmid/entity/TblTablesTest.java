package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TblTablesTest {

    private TblTables tblTables;

    @BeforeEach
    void setUp() {
        tblTables = new TblTables();
    }

    @Test
    void testSetAndGetTableId() {
        String tableId = "table123";
        tblTables.setTableId(tableId);
        assertEquals(tableId.toUpperCase(), tblTables.getTableId(), "TableId should be converted to uppercase.");
    }

    @Test
    void testSetAndGetMultipleSort() {
        Short multipleSort = 5;
        tblTables.setMultipleSort(multipleSort);
        assertEquals(multipleSort, tblTables.getMultipleSort(), "MultipleSort value should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetResizeColumns() {
        Short resizeColumns = 10;
        tblTables.setResizeColumns(resizeColumns);
        assertEquals(resizeColumns, tblTables.getResizeColumns(), "ResizeColumns value should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetTableName() {
        String tableName = "Test Table";
        tblTables.setTableName(tableName);
        assertEquals(tableName, tblTables.getTableName(), "TableName should be correctly set and retrieved.");
    }

    @Test
    void testTableIdUpperCaseLogic() {
        String tableId = "TABLE123";
        tblTables.setTableId(tableId);
        assertEquals(tableId, tblTables.getTableId(), "TableId should remain the same if it's already uppercase.");
    }
}
