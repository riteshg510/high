package com.hmhs.hvwmid.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.xml.crypto.dsig.TransformService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ReportServiceTest {

    @InjectMocks
    private ReportService reportService;

    @Mock
    private RestClientUtil restClientUtil;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private TransformService transformService;

    @Mock
    private CmodFolderService cmodFolderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    public String buildErrorResponse(HVWException exception) {
        return "Error Code: " + exception.getReturnCode() + ", Message: " + exception.getMessage() + ", Service: " + exception.getService();
    }

    @Test
    void testGetAllReportsDataWithDynamicActions_externalServiceError() {
        String authToken = "dummyAuthToken";
        String selector = "someSelector";

        ResponseEntity<Map> failedResponse = mock(ResponseEntity.class);
        when(failedResponse.getStatusCode()).thenReturn(HttpStatus.SERVICE_UNAVAILABLE);
        when(failedResponse.getBody()).thenReturn(null);
        when(restClientUtil.postRequest(anyString(), eq(authToken), isNull())).thenReturn(failedResponse);

        String result = reportService.getAllReportsDataWithDynamicActions(selector, authToken);

        assertTrue(result.contains("503"));
    }


    // Test for getCmodFolderData
    @Test
    void getCmodFolderData() throws Exception {
        // Prepare mock response
        String mockResponse = "{\"folderData\":\"data\"}";
        when(cmodFolderService.getCmodFolderData(anyString(), anyString(), anyString())).thenReturn(mockResponse);

        // Call the method
        String result = reportService.getCmodFolderData("folderId", "help", "auth-token");

        // Assert the result
        assertEquals(mockResponse, result);
    }

    @Test
    void getCmodFolderData_shouldThrowHVWException() throws IOException {
        // Simulate an exception being thrown by CmodFolderService
        when(cmodFolderService.getCmodFolderData(anyString(), anyString(), anyString()))
                .thenThrow(new HVWException(503, "Error retrieving CMOD folder data", "CMOD"));

        // Call the method and assert exception
        HVWException exception = assertThrows(HVWException.class, () -> {
            reportService.getCmodFolderData("folderId", "help", "auth-token");
        });

        assertEquals(503, exception.getReturnCode());
        assertEquals("Error retrieving CMOD folder data", exception.getMessage());
    }

    @Test
    void testGetAllReportsDataWithDynamicActions_Success() throws Exception {
        Map<String, Object> mockResponse = new HashMap<>();
        mockResponse.put("reportArchiveFolderListing", List.of(
                Map.of("odFolderName", "Folder1", "odFolderDesc", "Description1"),
                Map.of("odFolderName", "Folder2", "odFolderDesc", "Description2")
        ));

        ResponseEntity<Map> responseEntity = mock(ResponseEntity.class);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
        when(responseEntity.getBody()).thenReturn(mockResponse);
        when(restClientUtil.postRequest(anyString(), anyString(), any())).thenReturn(responseEntity);

        String selector = "MYREPORTS";
        String authToken = "dummyToken";

        // Call the method
        String result = reportService.getAllReportsDataWithDynamicActions(selector, authToken);

        // Validate the result
        assertNotNull(result);
    }

    // Test for getAllReportsDataWithDynamicActions - when the response status is not 2xx
    @Test
    void testGetAllReportsDataWithDynamicActions_Failure() throws Exception {
        // Simulate an error response
        ResponseEntity<Map> responseEntity = mock(ResponseEntity.class);
        when(responseEntity.getStatusCode()).thenReturn(HttpStatus.SERVICE_UNAVAILABLE);
        when(responseEntity.getBody()).thenReturn(new HashMap<>());
        when(restClientUtil.postRequest(anyString(), anyString(), any())).thenReturn(responseEntity);

        String selector = "MYREPORTS";
        String authToken = "dummyToken";

        // Call the method and verify it handles error responses
        String result = reportService.getAllReportsDataWithDynamicActions(selector, authToken);

        assertNotNull(result);
        assertTrue(result.contains("error"));
    }

    // Test for transformServiceResponse - when the response is valid
    @Test
    void testTransformServiceResponse() {
        Map<String, Object> mockResponse = new HashMap<>();
        Map<String, Object> report = new HashMap<>();
        report.put("odFolderName", "Folder1");
        report.put("odFolderDesc", "Description of Folder1");
        mockResponse.put("reportArchiveFolderListing", List.of(report));

        String selector = "MYREPORTS";

        // Call the method
        List<Map<String, Object>> result = reportService.transformServiceResponse(mockResponse, selector);

        // Validate the transformation
        assertNotNull(result);
        assertEquals(1, result.size());
        
        assertEquals("CMODFolder1", result.get(0).get("id"));
        assertTrue(result.get(0).containsKey("actionFolderNameId"));
        assertTrue(result.get(0).containsKey("folderDescriptionId"));
    }

    // Test for createActionArray - when selector is "MYREPORTS"
    @Test
    void testCreateActionArray_MyReports() {
        String folderName = "Folder1";
        String selector = "MYREPORTS";

        // Call the method
        List<Map<String, String>> result = reportService.createActionArray(folderName, selector);

        // Validate the result
        assertNotNull(result);
        assertEquals(2, result.size());
        Map<String, String> action = result.get(1);
        assertEquals("dynamicAction", action.get("action"));
    }

    // Test for createActionArray - when selector is not "MYREPORTS"
    @Test
    void testCreateActionArray_NotMyReports() {
        String folderName = "Folder2";
        String selector = "OTHER_SELECTOR";

        // Call the method
        List<Map<String, String>> result = reportService.createActionArray(folderName, selector);

        // Validate the result
        assertNotNull(result);
        assertEquals(2, result.size());
        Map<String, String> action = result.get(1);
        assertEquals("dynamicAction", action.get("action"));
        assertEquals("add", action.get("actionIcon"));
    }

}
