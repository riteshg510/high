package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class WorkstationServiceTest {

    @InjectMocks
    private WorkstationService workstationService;

    @Mock
    private RestClientUtil restClientUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        reset(restClientUtil);
        // Set the workstation URL using reflection to avoid @Value dependency
        try {
            java.lang.reflect.Field workstationUrlField = WorkstationService.class.getDeclaredField("workstationUrl");
            workstationUrlField.setAccessible(true);
            workstationUrlField.set(workstationService, "http://test-api/workstation");
        } catch (Exception e) {
            fail("Failed to set workstationUrl field: " + e.getMessage());
        }
    }


    @Test
    void testGetWorkstationList_NullResponse() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        when(restClientUtil.postRequest(anyString(), anyString(), anyMap())).thenReturn(null);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            NullPointerException thrown = assertThrows(NullPointerException.class, () -> {
                workstationService.getWorkstationList(otherFields, "mockAuth");
            });

            assertNotNull(thrown);
        }
    }


    @Test
    void testBuildRequestBody_AllFields() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "TERMINAL01");
        otherFields.put("ipAddressMask", "192.168.*.*");

        // Use reflection to test private method
        Method buildRequestBodyMethod = WorkstationService.class.getDeclaredMethod("buildRequestBody", Map.class, String.class);
        buildRequestBodyMethod.setAccessible(true);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("testToken")).thenReturn("testUser");

            @SuppressWarnings("unchecked")
            Map<String, Object> result = (Map<String, Object>) buildRequestBodyMethod.invoke(workstationService, otherFields, "testToken");

            assertEquals("37", result.get("requestLength"));
            assertEquals("L", result.get("function"));
            assertEquals("testUser", result.get("initiatingUserId"));
            assertEquals("TERMINAL01", result.get("workstationIDMask"));
            assertEquals("192.168.*.*", result.get("ipAddressMask"));
        }
    }

    @Test
    void testNormalizeField_ValidValues() throws Exception {
        // Use reflection to test private method
        Method normalizeFieldMethod = WorkstationService.class.getDeclaredMethod("normalizeField", String.class);
        normalizeFieldMethod.setAccessible(true);

        assertEquals("test", normalizeFieldMethod.invoke(workstationService, "  test  "));
        assertEquals("value", normalizeFieldMethod.invoke(workstationService, "value"));
        assertNull(normalizeFieldMethod.invoke(workstationService, ""));
        assertNull(normalizeFieldMethod.invoke(workstationService, "   "));
        assertNull(normalizeFieldMethod.invoke(workstationService, (String) null));
    }

    @Test
    void testGetWorkstationList_HVWUtilsException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenThrow(new RuntimeException("JWT parsing failed"));

            RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
                workstationService.getWorkstationList(otherFields, "mockAuth");
            });

            assertEquals("JWT parsing failed", thrown.getMessage());
        }
    }

    @Test
    void testBuildRequestBody_EmptyFields() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        Method buildRequestBodyMethod = WorkstationService.class.getDeclaredMethod("buildRequestBody", Map.class, String.class);
        buildRequestBodyMethod.setAccessible(true);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("testToken")).thenReturn("testUser");

            @SuppressWarnings("unchecked")
            Map<String, Object> result = (Map<String, Object>) buildRequestBodyMethod.invoke(workstationService, otherFields, "testToken");

            assertEquals("37", result.get("requestLength"));
            assertEquals("L", result.get("function")); // Default function
            assertEquals("testUser", result.get("initiatingUserId"));
            assertEquals("%", result.get("workstationIDMask")); // Default mask
            assertEquals("%", result.get("ipAddressMask")); // Default mask
        }
    }

    @Test
    void testBuildRequestBody_WithCustomFunction() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("function", "A");
        otherFields.put("workstationIDMask", "TERM001");

        Method buildRequestBodyMethod = WorkstationService.class.getDeclaredMethod("buildRequestBody", Map.class, String.class);
        buildRequestBodyMethod.setAccessible(true);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("testToken")).thenReturn("adminUser");

            @SuppressWarnings("unchecked")
            Map<String, Object> result = (Map<String, Object>) buildRequestBodyMethod.invoke(workstationService, otherFields, "testToken");

            assertEquals("37", result.get("requestLength"));
            assertEquals("A", result.get("function"));
            assertEquals("adminUser", result.get("initiatingUserId"));
            assertEquals("TERM001", result.get("workstationIDMask"));
            assertEquals("%", result.get("ipAddressMask"));
        }
    }

    @Test
    void testBuildRequestBody_NullFields() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", null);
        otherFields.put("ipAddressMask", null);

        Method buildRequestBodyMethod = WorkstationService.class.getDeclaredMethod("buildRequestBody", Map.class, String.class);
        buildRequestBodyMethod.setAccessible(true);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("testToken")).thenReturn("testUser");

            @SuppressWarnings("unchecked")
            Map<String, Object> result = (Map<String, Object>) buildRequestBodyMethod.invoke(workstationService, otherFields, "testToken");

            assertEquals("%", result.get("workstationIDMask"));
            assertEquals("%", result.get("ipAddressMask"));
        }
    }

    @Test
    void testBuildRequestBody_EmptyStringFields() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "");
        otherFields.put("ipAddressMask", "   ");

        Method buildRequestBodyMethod = WorkstationService.class.getDeclaredMethod("buildRequestBody", Map.class, String.class);
        buildRequestBodyMethod.setAccessible(true);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("testToken")).thenReturn("testUser");

            @SuppressWarnings("unchecked")
            Map<String, Object> result = (Map<String, Object>) buildRequestBodyMethod.invoke(workstationService, otherFields, "testToken");

            assertEquals("%", result.get("workstationIDMask"));
            assertEquals("%", result.get("ipAddressMask"));
        }
    }

    @Test
    void testNormalizeField_EdgeCases() throws Exception {
        Method normalizeFieldMethod = WorkstationService.class.getDeclaredMethod("normalizeField", String.class);
        normalizeFieldMethod.setAccessible(true);

        assertEquals("a", normalizeFieldMethod.invoke(workstationService, "a"));
        assertEquals("multiple words", normalizeFieldMethod.invoke(workstationService, " multiple words "));
        assertEquals("tab\ttest", normalizeFieldMethod.invoke(workstationService, "\ttab\ttest\t"));
        assertEquals("newline\ntest", normalizeFieldMethod.invoke(workstationService, "\nnewline\ntest\n"));
        assertNull(normalizeFieldMethod.invoke(workstationService, "\t\n\r "));
    }

    @Test
    void testConstructor() {
        WorkstationService service = new WorkstationService(restClientUtil);
        assertNotNull(service);
    }
}