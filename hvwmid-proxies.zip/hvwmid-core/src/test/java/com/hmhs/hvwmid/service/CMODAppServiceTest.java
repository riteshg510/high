package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.Odscrt;
import com.hmhs.hvwmid.entity.T222APRM;
import com.hmhs.hvwmid.repository.OdscrtRepository;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CMODAppServiceTest {

    @Mock
    private OdscrtRepository odscrtRepository;

    @Mock
    private T222APRMRepository aprmRepository;

    @Mock
    private UploadActionService uploadActionService;

    @InjectMocks
    private CMODAppService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetApplicationChoices_returnsExpectedList() {
        Odscrt rec1 = new Odscrt();
        rec1.setForeignRid("RID123");
        rec1.setAgName("Group1");
        rec1.setAppName("App1");

        Odscrt rec2 = new Odscrt();
        rec2.setForeignRid("RID124");
        rec2.setAgName("Group1");
        rec2.setAppName("App2");

        Odscrt rec3 = new Odscrt();
        rec3.setForeignRid("RID123");
        rec3.setAgName("Group1");
        rec3.setAppName("App1"); // Duplicate

        when(odscrtRepository.findAll()).thenReturn(Arrays.asList(rec1, rec2, rec3));

        List<Map<String, String>> result = service.getApplicationChoices();

        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(map -> "Group1 - App1".equals(map.get("displayName"))));
        assertTrue(result.stream().anyMatch(map -> "Group1 - App2".equals(map.get("displayName"))));
    }

    @Test
    void testGetAPRMApplicationChoices_returnsExpectedList() {
        T222APRM record1 = new T222APRM();
        record1.setParmId("1");
        record1.setParmKey("KEY1");
        record1.setParmData("Data1");

        T222APRM record2 = new T222APRM();
        record2.setParmId("2L");
        record2.setParmKey("KEY2");
        record2.setParmData(null);

        T222APRM record3 = new T222APRM();
        record3.setParmId("3L");
        record3.setParmKey("KEY1");
        record3.setParmData("Data1"); // Duplicate

        when(aprmRepository.findAll()).thenReturn(Arrays.asList(record1, record2, record3));

        List<Map<String, String>> result = service.getAPRMApplicationChoices();

        assertEquals(2, result.size());
        assertTrue(result.stream().anyMatch(map -> map.get("displayName").contains("KEY1")));
        assertTrue(result.stream().anyMatch(map -> map.get("displayName").contains("KEY2")));
    }

    @Test
    void testGetApplicationChoicesForFolder_returnsExpectedWhenMatchFound() {
        T222APRM parm = new T222APRM();
        parm.setParmId("1L");
        parm.setParmKey("RID123");
        parm.setParmData("FolderX");

        Odscrt odscrt = new Odscrt();
        odscrt.setForeignRid("RID123");
        odscrt.setAgName("Grp");
        odscrt.setAppName("App");

        when(aprmRepository.findByParmIdAndParmData("FolderX")).thenReturn(List.of(parm));
        when(odscrtRepository.findByForeignRid("RID123")).thenReturn(List.of(odscrt));

        List<Map<String, String>> result = service.getApplicationChoicesForFolder("FolderX");

        assertEquals(1, result.size());
        assertEquals("Grp - App", result.get(0).get("displayName"));
    }


    @Test
    void testNormalizeFolderName_removesPrefixes() throws Exception {
        Method method = CMODAppService.class.getDeclaredMethod("normalizeFolderName", String.class);
        method.setAccessible(true);
        String normalized = (String) method.invoke(service, "CMODUPLOADFolderX");

        assertEquals("FolderX", normalized);
    }
}
