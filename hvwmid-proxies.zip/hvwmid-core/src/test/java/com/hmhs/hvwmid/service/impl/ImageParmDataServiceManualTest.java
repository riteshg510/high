package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.service.impl.ImageParmDataServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

/**
 * Manual test to verify the ImageParmDataService implementation.
 * This is a simplified test to verify basic functionality.
 */
@ExtendWith(MockitoExtension.class)
public class ImageParmDataServiceManualTest {

    @Mock
    private T222APRMRepository t222APRMRepository;

    @InjectMocks
    private ImageParmDataServiceImpl imageParmDataService;

    @Test
    public void testBasicFunctionality() {
        // Setup test data
        Map<String, String> hvwbaseData = new HashMap<>();
        hvwbaseData.put("TEST_KEY", "TEST_VALUE");
        
        Map<String, String> cmbaseData = new HashMap<>();
        cmbaseData.put("CMOD_KEY", "CMOD_VALUE");
        
        Map<String, String> codbaseData = new HashMap<>();
        codbaseData.put("COD_KEY", "COD_VALUE");
        
        Map<String, String> cmfldmapData = new HashMap<>();
        cmfldmapData.put("FIELD_KEY", "FOLDER_VALUE");
        
        Map<String, Map<String, String>> additionalData = new HashMap<>();
        Map<String, String> userExData = new HashMap<>();
        userExData.put("USER_KEY", "USER_VALUE");
        additionalData.put(HVWConstants.CMUSEREX, userExData);

        // Mock repository calls
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(hvwbaseData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE)).thenReturn(cmbaseData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CODBASE)).thenReturn(codbaseData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMFLDMAP)).thenReturn(cmfldmapData);
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalData);

        // Initialize the service
        imageParmDataService.refreshParmData();

        // Test basic functionality
        String hvwbaseResult = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY", "DEFAULT");
        assertEquals("TEST_VALUE", hvwbaseResult);

        String cmbaseResult = imageParmDataService.getParmDataByKeyByCmodbase("CMOD_KEY", "DEFAULT");
        assertEquals("CMOD_VALUE", cmbaseResult);

        String codbaseResult = imageParmDataService.getParmDataByKeyByCODBase("COD_KEY", "DEFAULT");
        assertEquals("COD_VALUE", codbaseResult);

        String cmfldmapResult = imageParmDataService.getParmDataByKeyByCmodfld("FIELD_KEY", "DEFAULT");
        assertEquals("FOLDER_VALUE", cmfldmapResult);

        String userResult = imageParmDataService.getParmData(HVWConstants.CMUSEREX, "USER_KEY");
        assertEquals("USER_VALUE", userResult);

        // Test maps
        Map<String, String> hvwbaseMap = imageParmDataService.getParmDataMap(HVWConstants.HVWBASE);
        assertNotNull(hvwbaseMap);
        assertEquals("TEST_VALUE", hvwbaseMap.get("TEST_KEY"));

        // Test bidirectional mapping
        String folderResult = imageParmDataService.getParmKeyByParmDataByCmodfld("FOLDER_VALUE", "DEFAULT");
        assertEquals("FIELD_KEY", folderResult);

        // Test default values
        String defaultResult = imageParmDataService.getParmDataByKeyByHvwbase("NON_EXISTENT", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);

        String nullResult = imageParmDataService.getParmDataByKeyByHvwbase("NON_EXISTENT");
        assertNull(nullResult);

        System.out.println("All tests passed successfully!");
    }
}