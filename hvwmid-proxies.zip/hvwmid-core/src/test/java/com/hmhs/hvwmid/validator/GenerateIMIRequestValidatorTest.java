package com.hmhs.hvwmid.validator;

import com.hmhs.hvwmid.model.GenerateIMIRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class GenerateIMIRequestValidatorTest {

    private GenerateIMIRequestValidator validator;

    @BeforeEach
    void setUp() {
        validator = new GenerateIMIRequestValidator();
    }

    // Helper method to create valid request
    private GenerateIMIRequest createValidRequest() {
        GenerateIMIRequest request = new GenerateIMIRequest();
        request.setExcelId(123);
        
        // File mappings
        List<GenerateIMIRequest.FileIdMapping> fileMappings = new ArrayList<>();
        GenerateIMIRequest.FileIdMapping fileMapping = new GenerateIMIRequest.FileIdMapping();
        fileMapping.setFileId(124);
        fileMapping.setExcelFileName("document1.pdf");
        fileMappings.add(fileMapping);
        request.setFileIdMappings(fileMappings);
        
        // Segment mappings (all required segments)
        List<GenerateIMIRequest.SegmentMapping> segmentMappings = new ArrayList<>();
        
        // FID segment
        GenerateIMIRequest.SegmentMapping fidMapping = new GenerateIMIRequest.SegmentMapping();
        fidMapping.setSegmentName("FID");
        fidMapping.setType("U");
        fidMapping.setValue("");
        segmentMappings.add(fidMapping);
        
        // DPK segment
        GenerateIMIRequest.SegmentMapping dpkMapping = new GenerateIMIRequest.SegmentMapping();
        dpkMapping.setSegmentName("DPK");
        dpkMapping.setType("M");
        dpkMapping.setValue("FileName");
        segmentMappings.add(dpkMapping);
        
        // IMG segment
        GenerateIMIRequest.SegmentMapping imgMapping = new GenerateIMIRequest.SegmentMapping();
        imgMapping.setSegmentName("IMG");
        imgMapping.setType("C");
        imgMapping.setValue("IMAGE_DATA");
        segmentMappings.add(imgMapping);
        
        // BOD segment
        GenerateIMIRequest.SegmentMapping bodMapping = new GenerateIMIRequest.SegmentMapping();
        bodMapping.setSegmentName("BOD");
        bodMapping.setType("U");
        bodMapping.setValue("");
        segmentMappings.add(bodMapping);
        
        // EOD segment
        GenerateIMIRequest.SegmentMapping eodMapping = new GenerateIMIRequest.SegmentMapping();
        eodMapping.setSegmentName("EOD");
        eodMapping.setType("U");
        eodMapping.setValue("");
        segmentMappings.add(eodMapping);
        
        request.setMappings(segmentMappings);
        
        // Output config
        GenerateIMIRequest.OutputConfig outputConfig = new GenerateIMIRequest.OutputConfig();
        outputConfig.setDocumentsPerIMI(25);
        outputConfig.setFilePriority(99);
        request.setOutputConfig(outputConfig);
        
        return request;
    }

    @Test
    void testValidRequest_ShouldPass() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertTrue(result.isValid());
        assertTrue(result.getErrors().isEmpty());
        assertNull(result.getErrorMessage());
    }

    @Test
    void testNullRequest_ShouldFail() {
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(null);
        
        // Assert
        assertFalse(result.isValid());
        assertEquals(1, result.getErrors().size());
        assertEquals("Request cannot be null", result.getErrors().get(0));
    }

    @Test
    void testNullExcelId_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setExcelId(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("excelId is required and cannot be null"));
    }

    @Test
    void testZeroExcelId_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setExcelId(0);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("excelId must be a positive integer"));
    }

    @Test
    void testNegativeExcelId_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setExcelId(-1);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("excelId must be a positive integer"));
    }

    @Test
    void testNullFileIdMappings_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setFileIdMappings(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings must contain at least one entry"));
    }

    @Test
    void testEmptyFileIdMappings_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setFileIdMappings(new ArrayList<>());
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings must contain at least one entry"));
    }

    @Test
    void testNullFileIdMapping_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        List<GenerateIMIRequest.FileIdMapping> mappings = new ArrayList<>();
        mappings.add(null);
        request.setFileIdMappings(mappings);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings[0] cannot be null"));
    }

    @Test
    void testNullFileId_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getFileIdMappings().get(0).setFileId(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings[0].fileId is required and cannot be null"));
    }

    @Test
    void testZeroFileId_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getFileIdMappings().get(0).setFileId(0);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings[0].fileId must be a positive integer"));
    }

    @Test
    void testNullExcelFileName_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getFileIdMappings().get(0).setExcelFileName(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings[0].excelFileName is required and cannot be empty"));
    }

    @Test
    void testEmptyExcelFileName_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getFileIdMappings().get(0).setExcelFileName("");
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings[0].excelFileName is required and cannot be empty"));
    }

    @Test
    void testWhitespaceExcelFileName_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getFileIdMappings().get(0).setExcelFileName("   ");
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("fileIdMappings[0].excelFileName is required and cannot be empty"));
    }

    @Test
    void testMissingRequiredSegment_FID_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        // Remove FID segment
        request.getMappings().removeIf(mapping -> "FID".equals(mapping.getSegmentName()));
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("Required segment 'FID' is missing from mappings"));
    }

    @Test
    void testMissingAllRequiredSegments_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setMappings(new ArrayList<>());
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("Required segment 'FID' is missing from mappings"));
        assertTrue(result.getErrors().contains("Required segment 'DPK' is missing from mappings"));
        assertTrue(result.getErrors().contains("Required segment 'IMG' is missing from mappings"));
        assertTrue(result.getErrors().contains("Required segment 'BOD' is missing from mappings"));
        assertTrue(result.getErrors().contains("Required segment 'EOD' is missing from mappings"));
    }

    @Test
    void testNullSegmentMapping_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getMappings().add(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("cannot be null")));
    }

    @Test
    void testNullSegmentName_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        GenerateIMIRequest.SegmentMapping invalidMapping = new GenerateIMIRequest.SegmentMapping();
        invalidMapping.setSegmentName(null);
        invalidMapping.setType("U");
        invalidMapping.setValue("");
        request.getMappings().add(invalidMapping);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("segmentName is required and cannot be empty")));
    }

    @Test
    void testEmptySegmentName_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        GenerateIMIRequest.SegmentMapping invalidMapping = new GenerateIMIRequest.SegmentMapping();
        invalidMapping.setSegmentName("");
        invalidMapping.setType("U");
        invalidMapping.setValue("");
        request.getMappings().add(invalidMapping);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("segmentName is required and cannot be empty")));
    }

    @Test
    void testInvalidSegmentType_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getMappings().get(0).setType("X");
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> 
            error.contains("type must be one of: U (Unique), M (Mapped), C (Constant)")));
    }

    @Test
    void testNullSegmentType_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getMappings().get(0).setType(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> error.contains("type is required and cannot be empty")));
    }

    @Test
    void testEmptyValueForMappedType_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        // Find DPK mapping (type M) and set empty value
        request.getMappings().stream()
            .filter(mapping -> "DPK".equals(mapping.getSegmentName()))
            .findFirst()
            .ifPresent(mapping -> mapping.setValue(""));
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> 
            error.contains("value is required and cannot be empty when type is 'M'")));
    }

    @Test
    void testEmptyValueForConstantType_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        // Find IMG mapping (type C) and set empty value
        request.getMappings().stream()
            .filter(mapping -> "IMG".equals(mapping.getSegmentName()))
            .findFirst()
            .ifPresent(mapping -> mapping.setValue(""));
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().stream().anyMatch(error -> 
            error.contains("value is required and cannot be empty when type is 'C'")));
    }

    @Test
    void testDuplicateSegmentNames_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        // Add duplicate FID segment
        GenerateIMIRequest.SegmentMapping duplicateMapping = new GenerateIMIRequest.SegmentMapping();
        duplicateMapping.setSegmentName("FID");
        duplicateMapping.setType("C");
        duplicateMapping.setValue("DUPLICATE");
        request.getMappings().add(duplicateMapping);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("Duplicate segment name 'FID' found in mappings"));
    }

    @Test
    void testInvalidDocumentsPerIMI_TooLow_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setDocumentsPerIMI(0);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("outputConfig.documentsPerIMI must be between 1 and 2000"));
    }

    @Test
    void testInvalidDocumentsPerIMI_TooHigh_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setDocumentsPerIMI(2001);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("outputConfig.documentsPerIMI must be between 1 and 2000"));
    }

    @Test
    void testInvalidFilePriority_TooLow_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setFilePriority(0);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("outputConfig.filePriority must be between 1 and 100"));
    }

    @Test
    void testInvalidFilePriority_TooHigh_ShouldFail() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getOutputConfig().setFilePriority(101);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        assertTrue(result.getErrors().contains("outputConfig.filePriority must be between 1 and 100"));
    }

    @Test
    void testNullOutputConfig_ShouldPass() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setOutputConfig(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertTrue(result.isValid()); // Null config should be allowed (defaults will be used)
    }

    @Test
    void testValidationResultErrorMessage() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setExcelId(null);
        request.setFileIdMappings(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertFalse(result.isValid());
        String errorMessage = result.getErrorMessage();
        assertNotNull(errorMessage);
        assertTrue(errorMessage.contains("excelId is required and cannot be null"));
        assertTrue(errorMessage.contains("fileIdMappings must contain at least one entry"));
    }

    @Test
    void testValidationResultToErrorResponse() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.setExcelId(null);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        Map<String, Object> errorResponse = result.toErrorResponse();
        
        // Assert
        assertNotNull(errorResponse);
        assertTrue(errorResponse.containsKey("error"));
        
        @SuppressWarnings("unchecked")
        Map<String, Object> error = (Map<String, Object>) errorResponse.get("error");
        assertEquals(400, error.get("code"));
        assertEquals("Validation failed", error.get("message"));
        assertTrue(error.containsKey("details"));
        
        @SuppressWarnings("unchecked")
        List<String> details = (List<String>) error.get("details");
        assertTrue(details.contains("excelId is required and cannot be null"));
    }

    @Test
    void testCaseInsensitiveSegmentTypes() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getMappings().get(0).setType("u"); // lowercase
        request.getMappings().get(1).setType("M"); // uppercase
        request.getMappings().get(2).setType("c"); // lowercase
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertTrue(result.isValid()); // Should pass - validator handles case insensitive
    }

    @Test
    void testWhitespaceInSegmentType_ShouldPass() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        request.getMappings().get(0).setType(" U ");
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertTrue(result.isValid()); // Should pass - validator trims whitespace
    }

    @Test
    void testMultipleFileIdMappings_ShouldPass() {
        // Arrange
        GenerateIMIRequest request = createValidRequest();
        
        GenerateIMIRequest.FileIdMapping secondMapping = new GenerateIMIRequest.FileIdMapping();
        secondMapping.setFileId(125);
        secondMapping.setExcelFileName("document2.pdf");
        request.getFileIdMappings().add(secondMapping);
        
        // Act
        GenerateIMIRequestValidator.ValidationResult result = validator.validate(request);
        
        // Assert
        assertTrue(result.isValid());
    }
}