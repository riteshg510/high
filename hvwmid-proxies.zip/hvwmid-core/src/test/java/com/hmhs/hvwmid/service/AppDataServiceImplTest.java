package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.ImageData;
import com.hmhs.hvwmid.entity.TblActions;
import com.hmhs.hvwmid.entity.TblCabinets;
import com.hmhs.hvwmid.entity.TblColumns;
import com.hmhs.hvwmid.entity.TblDepartment;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblLdapCabinets;
import com.hmhs.hvwmid.entity.TblPickListItems;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblSections;
import com.hmhs.hvwmid.entity.TblTables;
import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.repository.ActionsRepository;
import com.hmhs.hvwmid.repository.CabinetsRepository;
import com.hmhs.hvwmid.repository.ChoiceItemsRepository;
import com.hmhs.hvwmid.repository.DepartmentRepository;
import com.hmhs.hvwmid.repository.FormsRepository;
import com.hmhs.hvwmid.repository.ImageDataRepository;
import com.hmhs.hvwmid.repository.LdapCabinetsRepository;
import com.hmhs.hvwmid.repository.SectionDetailsRepository;
import com.hmhs.hvwmid.repository.SectionsRepository;
import com.hmhs.hvwmid.repository.TblColumnsRepository;
import com.hmhs.hvwmid.repository.TblTablesRepository;
import com.hmhs.hvwmid.repository.TemplateDataRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AppDataServiceImplTest {

    @InjectMocks
    private AppDataServiceImpl service;

    @Mock
    private ActionsRepository actionsRepo;
    @Mock
    private ChoiceItemsRepository pickRepo;
    @Mock
    private CabinetsRepository cabinetsRepo;
    @Mock
    private DepartmentRepository departmentRepo;
    @Mock
    private FormsRepository formsRepo;
    @Mock
    private LdapCabinetsRepository ldapCabinetsRepo;
    @Mock
    private SectionDetailsRepository sectionDetailsRepo;
    @Mock
    private SectionsRepository secRepo;
    @Mock
    private TblColumnsRepository tblColumnRepo;
    @Mock
    private TblTablesRepository tblTableRepo;
    @Mock
    private TemplateDataRepository templetDataRepo;
    @Mock
    private ImageDataRepository imageDataRepo;

    @Test
    void getActionsByFormId() {
        when(actionsRepo.getActionsByFormIdOrderByActionOrderAsc("fid"))
                .thenReturn(Collections.singletonList(new TblActions()));
        assertEquals(1, service.getActionsByFormId("fid").size());
    }

    @Test
    void getCabinetsByCabinetIds() {
        when(cabinetsRepo.getCabinetsByCabinetIdIn(anyList()))
                .thenReturn(List.of(new TblCabinets()));
        assertFalse(service.getCabinetsByCabinetIds(List.of("id")).isEmpty());
    }

    @Test
    void getCabinetsByCabinetsNames() {
        when(cabinetsRepo.getCabinetsByCabinetNameIn(anyList()))
                .thenReturn(List.of(new TblCabinets()));
        assertEquals(1, service.getCabinetsByCabinetsNames(List.of("cab")).size());
    }

    @Test
    void getCabinetsByDepartmentId() {
        when(cabinetsRepo.getCabinetsByDepartmentIdOrderByCabinetNameAsc("dep"))
                .thenReturn(List.of(new TblCabinets()));
        assertEquals(1, service.getCabinetsByDepartmentId("dep").size());
    }

    @Test
    void getDepartmentIdsByUserCabinetIds() {
        when(cabinetsRepo.getDepartmentIdsByUserCabinets(anyList()))
                .thenReturn(List.of("d1"));
        assertTrue(service.getDepartmentIdsByUserCabinetIds(List.of("c1")).contains("d1"));
    }

    @Test
    void findAllDepartment() {
        when(departmentRepo.findAllByOrderByDepartmentNameAsc())
                .thenReturn(List.of(new TblDepartment()));
        assertEquals(1, service.findAllDepartment().size());
    }

    @Test
    void getCabinetsNamesByGroupName() {
        when(ldapCabinetsRepo.getCabinetsByLdapGroupName("grp"))
                .thenReturn(List.of(new TblLdapCabinets()));
        assertEquals(1, service.getCabinetsNamesByGroupName("grp").size());
    }

    @Test
    void getForm() {
        TblForms form = new TblForms();
        when(formsRepo.getFormByFormId("fid")).thenReturn(form);
        assertEquals(form, service.getForm("fid"));
    }

    @Test
    void getFormIdByFileName() {
        when(formsRepo.getFormIdByFileName("file"))
                .thenReturn(List.of(new TblForms()));
        assertFalse(service.getFormIdByFileName("file").isEmpty());
    }

    @Test
    void testGetPickList() {
        when(pickRepo.getChoiceItemsByPickListIdAndDependentKeyOrderByIdAsc("pl", "dkey"))
                .thenReturn(List.of(new TblPickListItems()));
        assertEquals(1, service.getPickList("pl", "dkey").size());
    }

    @Test
    void getSectionDetailsBySectionId() {
        when(sectionDetailsRepo.getSectionDetailsBySectionIdOrderByColumnNumberAscFieldOrderAsc("sec"))
                .thenReturn(List.of(new TblSectionDetails()));
        assertEquals(1, service.getSectionDetailsBySectionId("sec").size());
    }

    @Test
    void getChildList() {
        when(sectionDetailsRepo.getDependentFieldNames("sec", "field"))
                .thenReturn(List.of("child1"));
        assertEquals("child1", service.getChildList("sec", "field").get(0));
    }

    @Test
    void getSections() {
        when(secRepo.getSectionsByFormId("fid"))
                .thenReturn(List.of(new TblSections()));
        assertEquals(1, service.getSections("fid").size());
    }

    @Test
    void getSectionsByParentSectionId() {
        when(secRepo.getSectionDataByParentSectionIdAndFormIdOrderByParentColumnNumberAsc("psid", "fid"))
                .thenReturn(List.of(new TblSections()));
        assertEquals(1, service.getSectionsByParentSectionId("psid", "fid").size());
    }

    @Test
    void getColumns() {
        when(tblColumnRepo.getColumnsByTableIdOrderByColumnsOrderAsc("tid"))
                .thenReturn(List.of(new TblColumns()));
        assertEquals(1, service.getColumns("tid").size());
    }

    @Test
    void getTableByTableId() {
        TblTables table = new TblTables();
        when(tblTableRepo.getTableByTableId("tid")).thenReturn(table);
        assertEquals(table, service.getTableByTableId("tid"));
    }

    @Test
    void getTempletByName() {
        when(templetDataRepo.getTempletByTemplateName("tpl"))
                .thenReturn(List.of(new TblTemplates()));
        assertEquals(1, service.getTempletByName("tpl").size());
    }

    @Test
    void getImageDataFilename() {
        ImageData image = new ImageData();
        when(imageDataRepo.getImageDataById(1L)).thenReturn(image);
        assertEquals(image, service.getImageDataFilename("1"));
    }

    @Test
    void findAll() {
        Page<ImageData> page = mock(Page.class);
        when(imageDataRepo.findAll(any(Pageable.class))).thenReturn(page);
        assertEquals(page, service.findAll(Pageable.unpaged()));
    }

    @Test
    void findByFormDescriptionContaining() {
        Page<ImageData> page = mock(Page.class);
        when(imageDataRepo.findByFormDescriptionContaining(eq("desc"), any(Pageable.class))).thenReturn(page);
        assertEquals(page, service.findByFormDescriptionContaining("desc", Pageable.unpaged()));
    }
}
