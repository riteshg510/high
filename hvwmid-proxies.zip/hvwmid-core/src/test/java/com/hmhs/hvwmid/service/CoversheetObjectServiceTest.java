package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.exception.ResourceNotFoundException;
import com.hmhs.hvwmid.model.CoverSheetObjectDTO;
import com.hmhs.hvwmid.repository.T117ImgCoverObjectRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CoversheetObjectServiceTest {

    @InjectMocks
    private CoversheetObjectServiceImpl coversheetObjectService;

    @Mock
    private T117ImgCoverObjectRepository templateRepository;

    private T117ImgCoverObject mockTemplate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockTemplate = new T117ImgCoverObject();
        mockTemplate.setObjName("TestObj");
        mockTemplate.setObjType("TEMPLATE");
        mockTemplate.setMimeType("application/pdf");
        mockTemplate.setObjData("sample data content");
        mockTemplate.setActive("Y");
    }

    @Test
    void getTemplates_ReturnsAllTemplates() {
        // Arrange
        T117ImgCoverObject template2 = new T117ImgCoverObject();
        template2.setObjName("TestObj2");
        template2.setObjType("FORM");
        template2.setMimeType("text/html");
        template2.setObjData("another data content");
        template2.setActive("Y");

        List<T117ImgCoverObject> expectedTemplates = Arrays.asList(mockTemplate, template2);
        when(templateRepository.findAllTemplates()).thenReturn(expectedTemplates);

        // Act
        List<T117ImgCoverObject> result = coversheetObjectService.getTemplates();

        // Assert
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedTemplates, result);
        verify(templateRepository, times(1)).findAllTemplates();
    }

    @Test
    void getTemplates_ReturnsEmptyList_WhenNoTemplates() {
        // Arrange
        when(templateRepository.findAllTemplates()).thenReturn(Arrays.asList());

        // Act
        List<T117ImgCoverObject> result = coversheetObjectService.getTemplates();

        // Assert
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(templateRepository, times(1)).findAllTemplates();
    }

    @Test
    void getTemplateData_ReturnsTemplateData_WhenTemplateExists() {
        // Arrange
        String templateName = "TestObj";
        when(templateRepository.findByNameIgnoreCase(templateName)).thenReturn(Optional.of(mockTemplate));

        // Act
        String result = coversheetObjectService.getTemplateData(templateName);

        // Assert
        assertNotNull(result);
        assertEquals("sample data content", result);
        verify(templateRepository, times(1)).findByNameIgnoreCase(templateName);
    }

    @Test
    void getTemplateData_ThrowsResourceNotFoundException_WhenTemplateNotFound() {
        // Arrange
        String templateName = "NonExistentTemplate";
        when(templateRepository.findByNameIgnoreCase(templateName)).thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            coversheetObjectService.getTemplateData(templateName);
        });

        assertEquals("Template not found: " + templateName, exception.getMessage());
        verify(templateRepository, times(1)).findByNameIgnoreCase(templateName);
    }

    @Test
    void getTemplateData_IsCaseInsensitive() {
        // Arrange
        String templateName = "testobj";
        when(templateRepository.findByNameIgnoreCase(templateName)).thenReturn(Optional.of(mockTemplate));

        // Act
        String result = coversheetObjectService.getTemplateData(templateName);

        // Assert
        assertNotNull(result);
        assertEquals("sample data content", result);
        verify(templateRepository, times(1)).findByNameIgnoreCase(templateName);
    }

    @Test
    void getTemplateByNameAndType_ReturnsDTO_WhenTemplateExists() {
        // Arrange
        String templateName = "TestObj";
        String templateType = "TEMPLATE";
        
        T117ImgCoverObject templateWithSpaces = new T117ImgCoverObject();
        templateWithSpaces.setObjName("  TestObj  ");
        templateWithSpaces.setObjType("  TEMPLATE  ");
        templateWithSpaces.setMimeType("application/pdf");
        templateWithSpaces.setObjData("sample data content");
        templateWithSpaces.setActive("Y");
        
        when(templateRepository.findByNameAndTypeIgnoreCase(templateName, templateType))
                .thenReturn(Optional.of(templateWithSpaces));

        // Act
        CoverSheetObjectDTO result = coversheetObjectService.getTemplateByNameAndType(templateName, templateType);

        // Assert
        assertNotNull(result);
        assertEquals("TestObj", result.getObjName());
        assertEquals("TEMPLATE", result.getObjType());
        assertEquals("application/pdf", result.getMimeType());
        assertEquals("sample data content", result.getObjData());
        verify(templateRepository, times(1)).findByNameAndTypeIgnoreCase(templateName, templateType);
    }

    @Test
    void getTemplateByNameAndType_ThrowsResourceNotFoundException_WhenTemplateNotFound() {
        // Arrange
        String templateName = "NonExistentTemplate";
        String templateType = "TEMPLATE";
        when(templateRepository.findByNameAndTypeIgnoreCase(templateName, templateType))
                .thenReturn(Optional.empty());

        // Act & Assert
        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            coversheetObjectService.getTemplateByNameAndType(templateName, templateType);
        });

        assertEquals("Template not found: " + templateName + " of type: " + templateType, exception.getMessage());
        verify(templateRepository, times(1)).findByNameAndTypeIgnoreCase(templateName, templateType);
    }

    @Test
    void getTemplateByNameAndType_IsCaseInsensitive() {
        // Arrange
        String templateName = "testobj";
        String templateType = "template";
        when(templateRepository.findByNameAndTypeIgnoreCase(templateName, templateType))
                .thenReturn(Optional.of(mockTemplate));

        // Act
        CoverSheetObjectDTO result = coversheetObjectService.getTemplateByNameAndType(templateName, templateType);

        // Assert
        assertNotNull(result);
        assertEquals("TestObj", result.getObjName());
        assertEquals("TEMPLATE", result.getObjType());
        assertEquals("application/pdf", result.getMimeType());
        assertEquals("sample data content", result.getObjData());
        verify(templateRepository, times(1)).findByNameAndTypeIgnoreCase(templateName, templateType);
    }

    @Test
    void getTemplateByNameAndType_TrimsWhitespaceInDTO() {
        // Arrange
        String templateName = "TestObj";
        String templateType = "TEMPLATE";
        
        T117ImgCoverObject templateWithWhitespace = new T117ImgCoverObject();
        templateWithWhitespace.setObjName("   TestObj   ");
        templateWithWhitespace.setObjType("   TEMPLATE   ");
        templateWithWhitespace.setMimeType("application/pdf");
        templateWithWhitespace.setObjData("sample data content");
        templateWithWhitespace.setActive("Y");
        
        when(templateRepository.findByNameAndTypeIgnoreCase(templateName, templateType))
                .thenReturn(Optional.of(templateWithWhitespace));

        // Act
        CoverSheetObjectDTO result = coversheetObjectService.getTemplateByNameAndType(templateName, templateType);

        // Assert
        assertNotNull(result);
        assertEquals("TestObj", result.getObjName());
        assertEquals("TEMPLATE", result.getObjType());
        assertEquals("application/pdf", result.getMimeType());
        assertEquals("sample data content", result.getObjData());
    }
}