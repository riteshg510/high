package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TblHelpPagesTest {

    private TblHelpPages tblHelpPage;

    @BeforeEach
    void setUp() {
        tblHelpPage = new TblHelpPages();
    }

    @Test
    void testSetAndGetOdFolderName() {
        // Test setting and getting OdFolderName
        String odFolderName = "Folder1";
        tblHelpPage.setOdFolderName(odFolderName);
        assertEquals(odFolderName, tblHelpPage.getOdFolderName(), "OdFolderName should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetOdFolderNameWithNull() {
        // Test setting and getting OdFolderName with null value
        tblHelpPage.setOdFolderName(null);
        assertNull(tblHelpPage.getOdFolderName(), "OdFolderName should be null.");
    }

    @Test
    void testSetAndGetFormId() {
        // Test setting and getting formId
        String formId = "form123";
        tblHelpPage.setFormId(formId);
        assertEquals(formId, tblHelpPage.getFormId(), "FormId should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetFormIdWithNull() {
        // Test setting and getting formId with null value
        tblHelpPage.setFormId(null);
        assertNull(tblHelpPage.getFormId(), "FormId should be null.");
    }
}
