package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class TblLdapCabinetsTest {

    private TblLdapCabinets tblLdapCabinet;

    @BeforeEach
    void setUp() {
        tblLdapCabinet = new TblLdapCabinets();
    }

    @Test
    void testSetAndGetLdapId() {
        // Test setting and getting ldapId
        String ldapId = "ldap123";
        tblLdapCabinet.setLdapId(ldapId);
        assertEquals(ldapId, tblLdapCabinet.getLdapId(), "LdapId should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetLdapIdWithNull() {
        // Test setting and getting ldapId with null value
        tblLdapCabinet.setLdapId(null);
        assertNull(tblLdapCabinet.getLdapId(), "LdapId should be null.");
    }

    @Test
    void testSetAndGetCabinetId() {
        // Test setting and getting cabinetId
        String cabinetId = "cab123";
        tblLdapCabinet.setCabinetId(cabinetId);
        assertEquals(cabinetId, tblLdapCabinet.getCabinetId(), "CabinetId should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetCabinetIdWithNull() {
        // Test setting and getting cabinetId with null value
        tblLdapCabinet.setCabinetId(null);
        assertNull(tblLdapCabinet.getCabinetId(), "CabinetId should be null.");
    }

    @Test
    void testSetAndGetCabinetName() {
        // Test setting and getting cabinetName
        String cabinetName = "Test Cabinet";
        tblLdapCabinet.setCabinetName(cabinetName);
        assertEquals(cabinetName, tblLdapCabinet.getCabinetName(), "CabinetName should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetCabinetNameWithNull() {
        // Test setting and getting cabinetName with null value
        tblLdapCabinet.setCabinetName(null);
        assertNull(tblLdapCabinet.getCabinetName(), "CabinetName should be null.");
    }

    @Test
    void testSetAndGetLdapGroupName() {
        // Test setting and getting ldapGroupName
        String ldapGroupName = "group123";
        tblLdapCabinet.setLdapGroupName(ldapGroupName);
        assertEquals(ldapGroupName, tblLdapCabinet.getLdapGroupName(), "LdapGroupName should be correctly set and retrieved.");
    }

    @Test
    void testSetAndGetLdapGroupNameWithNull() {
        // Test setting and getting ldapGroupName with null value
        tblLdapCabinet.setLdapGroupName(null);
        assertNull(tblLdapCabinet.getLdapGroupName(), "LdapGroupName should be null.");
    }
}
