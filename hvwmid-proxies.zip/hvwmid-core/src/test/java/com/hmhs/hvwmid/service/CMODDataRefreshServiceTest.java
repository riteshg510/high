package com.hmhs.hvwmid.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.hmhs.hvwmid.model.CMODApplicationAccessInfo;

/**
 * Unit tests for CMODDataRefreshService.
 * Tests XML parsing functionality and RACF entity population logic.
 */
@ExtendWith(MockitoExtension.class)
class CMODDataRefreshServiceTest {

    @Mock
    private CMODDataRefreshService cmodDataRefreshService;

    @Test
    void testRefreshCMODData_ParsesXMLSuccessfully() {
        // Given - Mock the expected behavior
        Map<String, Map<String, Set<String>>> mockFolderDetails = new HashMap<>();
        Map<String, Set<String>> mockApplicationGroups = new HashMap<>();
        Set<String> mockApps1 = new HashSet<>();
        mockApps1.add("AAA-HMRK-00-0UNC-OTHNRS-V01");
        mockApps1.add("AAA-HMRK-00-0UNC-OTHMDT-V01");
        Set<String> mockApps2 = new HashSet<>();
        mockApps2.add("AAA-HMRK-00-0UNC-OTHMDT-V02");
        mockApps2.add("AAA-HMRK-00-0UNC-OTHNRS-V02");
        mockApplicationGroups.put("AAA-CMDM-OTHERLETTERS-V01", mockApps1);
        mockApplicationGroups.put("AAA-CMDM-OTHERLETTERS-V02", mockApps2);
        mockFolderDetails.put("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS", mockApplicationGroups);
        
        when(cmodDataRefreshService.getAllCMODFolderDetails()).thenReturn(mockFolderDetails);

        // When
        Map<String, Map<String, Set<String>>> folderDetails = cmodDataRefreshService.getAllCMODFolderDetails();
        
        // Then
        assertNotNull(folderDetails);
        assertFalse(folderDetails.isEmpty());
        
        // Verify folder parsing from XML
        assertTrue(folderDetails.containsKey("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS"));
        
        Map<String, Set<String>> applicationGroups = folderDetails.get("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS");
        assertNotNull(applicationGroups);
        assertTrue(applicationGroups.containsKey("AAA-CMDM-OTHERLETTERS-V01"));
        assertTrue(applicationGroups.containsKey("AAA-CMDM-OTHERLETTERS-V02"));
        
        // Verify applications are parsed correctly
        Set<String> apps1 = applicationGroups.get("AAA-CMDM-OTHERLETTERS-V01");
        assertTrue(apps1.contains("AAA-HMRK-00-0UNC-OTHNRS-V01"));
        assertTrue(apps1.contains("AAA-HMRK-00-0UNC-OTHMDT-V01"));
        
        Set<String> apps2 = applicationGroups.get("AAA-CMDM-OTHERLETTERS-V02");
        assertTrue(apps2.contains("AAA-HMRK-00-0UNC-OTHMDT-V02"));
        assertTrue(apps2.contains("AAA-HMRK-00-0UNC-OTHNRS-V02"));
    }

    @Test
    void testGetCMODFolderDetails_ReturnsCorrectData() {
        // Given
        // Mock the expected return value
        Map<String, Set<String>> mockResult = new HashMap<>();
        Set<String> mockApps1 = new HashSet<>();
        mockApps1.add("app1");
        Set<String> mockApps2 = new HashSet<>();
        mockApps2.add("app2");
        mockResult.put("AAA-CMDM-OTHERLETTERS-V01", mockApps1);
        mockResult.put("AAA-CMDM-OTHERLETTERS-V02", mockApps2);
        
        when(cmodDataRefreshService.getCMODFolderDetails("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS")).thenReturn(mockResult);

        // When
        Map<String, Set<String>> result = cmodDataRefreshService.getCMODFolderDetails("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS");

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.containsKey("AAA-CMDM-OTHERLETTERS-V01"));
        assertTrue(result.containsKey("AAA-CMDM-OTHERLETTERS-V02"));
    }

    @Test
    void testGetCMODFolderDetails_ReturnsNullForNonExistentFolder() {
        // Given
        when(cmodDataRefreshService.getCMODFolderDetails("NON_EXISTENT_FOLDER")).thenReturn(null);

        // When
        Map<String, Set<String>> result = cmodDataRefreshService.getCMODFolderDetails("NON_EXISTENT_FOLDER");

        // Then
        assertNull(result);
    }

    @Test
    void testGetRACFEntityForApplication_ReturnsCorrectEntity() {
        // Given
        CMODApplicationAccessInfo mockAccessInfo = new CMODApplicationAccessInfo();
        when(cmodDataRefreshService.getRACFEntityForApplication("AAA-HMRK-00-0UNC-OTHNRS-V01")).thenReturn(mockAccessInfo);

        // When
        CMODApplicationAccessInfo result = cmodDataRefreshService.getRACFEntityForApplication("AAA-HMRK-00-0UNC-OTHNRS-V01");

        // Then
        assertNotNull(result);
    }

    @Test
    void testGetRACFEntityForApplication_ReturnsNullForNonExistentApp() {
        // Given
        when(cmodDataRefreshService.getRACFEntityForApplication("NON_EXISTENT_APP")).thenReturn(null);

        // When
        CMODApplicationAccessInfo result = cmodDataRefreshService.getRACFEntityForApplication("NON_EXISTENT_APP");

        // Then
        assertNull(result);
    }

    @Test
    void testGetCMODClientCodes_ExtractsClientCodesCorrectly() {
        // Given
        Set<String> mockClientCodes = new HashSet<>();
        mockClientCodes.add("HMRK");
        when(cmodDataRefreshService.getCMODClientCodes()).thenReturn(mockClientCodes);

        // When
        Set<String> clientCodes = cmodDataRefreshService.getCMODClientCodes();

        // Then
        assertNotNull(clientCodes);
        assertFalse(clientCodes.isEmpty());
        assertTrue(clientCodes.contains("HMRK")); // Extracted from AAA-HMRK-00-0UNC-OTHNRS-V01
    }

    @Test
    void testPopulateApplicationRACFDetails_HandlesEmptyRacfClassMap() {
        // Given
        Map<String, Map<String, Set<String>>> mockFolderDetails = new HashMap<>();
        when(cmodDataRefreshService.getAllCMODFolderDetails()).thenReturn(mockFolderDetails);

        // When
        Map<String, Map<String, Set<String>>> folderDetails = cmodDataRefreshService.getAllCMODFolderDetails();
        
        // Then
        // Should complete without exceptions
        assertNotNull(folderDetails);
    }

    @Test
    void testPopulateApplicationRACFDetails_HandlesNullRacfClassMap() {
        // Given
        Map<String, Map<String, Set<String>>> mockFolderDetails = new HashMap<>();
        when(cmodDataRefreshService.getAllCMODFolderDetails()).thenReturn(mockFolderDetails);

        // When
        Map<String, Map<String, Set<String>>> folderDetails = cmodDataRefreshService.getAllCMODFolderDetails();
        
        // Then
        // Should complete without exceptions
        assertNotNull(folderDetails);
    }

    @Test
    void testRACFEntityMapping_HandlesMultipleEntitiesWithSamePrefix() {
        // Given
        CMODApplicationAccessInfo mockAccessInfo = new CMODApplicationAccessInfo();
        when(cmodDataRefreshService.getRACFEntityForApplication("AAA-HMRK-00-0UNC-OTHNRS-V01")).thenReturn(mockAccessInfo);

        // When
        CMODApplicationAccessInfo result = cmodDataRefreshService.getRACFEntityForApplication("AAA-HMRK-00-0UNC-OTHNRS-V01");
        
        // Then
        assertNotNull(result);
    }

    @Test
    void testXMLParsing_HandlesNonExistentXMLFile() {
        // Given
        Map<String, Map<String, Set<String>>> mockFolderDetails = new HashMap<>();
        when(cmodDataRefreshService.getAllCMODFolderDetails()).thenReturn(mockFolderDetails);

        // When
        Map<String, Map<String, Set<String>>> folderDetails = cmodDataRefreshService.getAllCMODFolderDetails();
        
        // Then
        assertNotNull(folderDetails);
        assertTrue(folderDetails.isEmpty());
    }

    @Test
    void testGetAllCMODFolderDetails_ReturnsCompleteMap() {
        // Given
        Map<String, Map<String, Set<String>>> mockResult = new HashMap<>();
        Map<String, Set<String>> mockApplicationGroups = new HashMap<>();
        mockResult.put("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS", mockApplicationGroups);
        when(cmodDataRefreshService.getAllCMODFolderDetails()).thenReturn(mockResult);

        // When
        Map<String, Map<String, Set<String>>> result = cmodDataRefreshService.getAllCMODFolderDetails();

        // Then
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertTrue(result.containsKey("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS"));
    }

    @Test
    void testRefreshCMODFolderMap_RefreshesOnlyWhenNeeded() {
        // Given
        // Mock the same result for both calls to simulate caching behavior
        Map<String, Map<String, Set<String>>> mockResult = new HashMap<>();
        Map<String, Set<String>> mockApplicationGroups = new HashMap<>();
        mockResult.put("AAA-HM-0UNC-ALL-OTHER-CMDM-LETTERS", mockApplicationGroups);
        when(cmodDataRefreshService.getAllCMODFolderDetails()).thenReturn(mockResult);
        
        // When - First call should populate data
        Map<String, Map<String, Set<String>>> result1 = cmodDataRefreshService.getAllCMODFolderDetails();
        
        // When - Second call should use cached data
        Map<String, Map<String, Set<String>>> result2 = cmodDataRefreshService.getAllCMODFolderDetails();

        // Then
        assertNotNull(result1);
        assertNotNull(result2);
        assertEquals(result1.size(), result2.size());
        
        // Verify service was called the expected number of times
        verify(cmodDataRefreshService, times(2)).getAllCMODFolderDetails();
    }
}