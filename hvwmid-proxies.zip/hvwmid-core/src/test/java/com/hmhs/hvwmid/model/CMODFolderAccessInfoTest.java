package com.hmhs.hvwmid.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for CMODFolderAccessInfo DTO.
 * Tests DTO serialization, validation, and constructor behavior.
 */
class CMODFolderAccessInfoTest {

    @Test
    void testDefaultConstructor() {
        // Act
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();

        // Assert
        assertNotNull(info);
        assertNull(info.getFolderName());
        assertNull(info.getApplications());
        assertFalse(info.isEmpty()); // Default value is false
    }

    @Test
    void testParameterizedConstructorWithApplications() {
        // Arrange
        String folderName = "TEST_FOLDER";
        List<CMODApplicationAccessInfo> applications = createTestApplications();

        // Act
        CMODFolderAccessInfo info = new CMODFolderAccessInfo(folderName, applications);

        // Assert
        assertNotNull(info);
        assertEquals(folderName, info.getFolderName());
        assertEquals(applications, info.getApplications());
        assertFalse(info.isEmpty()); // Should be false when applications exist
        assertEquals(2, info.getApplications().size());
    }

    @Test
    void testParameterizedConstructorWithEmptyApplications() {
        // Arrange
        String folderName = "EMPTY_FOLDER";
        List<CMODApplicationAccessInfo> emptyApplications = new ArrayList<>();

        // Act
        CMODFolderAccessInfo info = new CMODFolderAccessInfo(folderName, emptyApplications);

        // Assert
        assertNotNull(info);
        assertEquals(folderName, info.getFolderName());
        assertEquals(emptyApplications, info.getApplications());
        assertTrue(info.isEmpty()); // Should be true when applications list is empty
    }

    @Test
    void testParameterizedConstructorWithNullApplications() {
        // Arrange
        String folderName = "NULL_APPS_FOLDER";

        // Act
        CMODFolderAccessInfo info = new CMODFolderAccessInfo(folderName, null);

        // Assert
        assertNotNull(info);
        assertEquals(folderName, info.getFolderName());
        assertNull(info.getApplications());
        assertTrue(info.isEmpty()); // Should be true when applications is null
    }

    @Test
    void testSettersAndGetters() {
        // Arrange
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();
        String folderName = "DYNAMIC_FOLDER";
        List<CMODApplicationAccessInfo> applications = createTestApplications();

        // Act
        info.setFolderName(folderName);
        info.setApplications(applications);

        // Assert
        assertEquals(folderName, info.getFolderName());
        assertEquals(applications, info.getApplications());
        assertFalse(info.isEmpty()); // isEmpty should be updated automatically
    }

    @Test
    void testSetApplicationsUpdatesIsEmpty() {
        // Arrange
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();

        // Test setting non-empty applications
        List<CMODApplicationAccessInfo> applications = createTestApplications();
        info.setApplications(applications);
        assertFalse(info.isEmpty());

        // Test setting empty applications
        info.setApplications(new ArrayList<>());
        assertTrue(info.isEmpty());

        // Test setting null applications
        info.setApplications(null);
        assertTrue(info.isEmpty());
    }

    @Test
    void testManualIsEmptyControl() {
        // Arrange
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();
        info.setApplications(createTestApplications()); // Set non-empty applications

        // Act - Manually override isEmpty
        info.setEmpty(true);

        // Assert
        assertTrue(info.isEmpty()); // Manual override should work
        assertNotNull(info.getApplications()); // Applications should still exist
        assertFalse(info.getApplications().isEmpty()); // Applications list is not actually empty
    }

    @Test
    void testFolderNameHandling() {
        // Arrange
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();

        // Test null folder name
        info.setFolderName(null);
        assertNull(info.getFolderName());

        // Test empty folder name
        info.setFolderName("");
        assertEquals("", info.getFolderName());

        // Test normal folder name
        info.setFolderName("MY_FOLDER");
        assertEquals("MY_FOLDER", info.getFolderName());

        // Test folder name with special characters
        info.setFolderName("FOLDER_WITH_SPECIAL-CHARS_123");
        assertEquals("FOLDER_WITH_SPECIAL-CHARS_123", info.getFolderName());
    }

    @Test
    void testApplicationsListModification() {
        // Arrange
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();
        List<CMODApplicationAccessInfo> applications = new ArrayList<>(createTestApplications());
        info.setApplications(applications);

        // Act - Modify the applications list
        CMODApplicationAccessInfo newApp = new CMODApplicationAccessInfo();
        newApp.setApplicationName("NEW_APP");
        applications.add(newApp);

        // Assert - The modification should be reflected
        assertEquals(3, info.getApplications().size());
        assertTrue(info.getApplications().contains(newApp));
        assertFalse(info.isEmpty());
    }

    @Test
    void testIsEmptyLogicConsistency() {
        // Arrange
        CMODFolderAccessInfo info = new CMODFolderAccessInfo();

        // Test 1: Start with null applications
        info.setApplications(null);
        assertTrue(info.isEmpty());

        // Test 2: Set empty list
        info.setApplications(new ArrayList<>());
        assertTrue(info.isEmpty());

        // Test 3: Add one application
        List<CMODApplicationAccessInfo> oneApp = new ArrayList<>();
        oneApp.add(new CMODApplicationAccessInfo("SINGLE_APP", Set.of("V1"), true, false));
        info.setApplications(oneApp);
        assertFalse(info.isEmpty());

        // Test 4: Clear the list (make it empty)
        oneApp.clear();
        info.setApplications(oneApp);
        assertTrue(info.isEmpty());
    }

    /**
     * Helper method to create test applications for testing.
     */
    private List<CMODApplicationAccessInfo> createTestApplications() {
        List<CMODApplicationAccessInfo> applications = new ArrayList<>();

        CMODApplicationAccessInfo app1 = new CMODApplicationAccessInfo();
        app1.setApplicationName("TEST_APP_1");
        app1.setApplicationVersions(Set.of("TEST_APP_1-HMRK-V1"));
        app1.setUserAccess(true);
        app1.setClientEmployeeSecurity(false);

        CMODApplicationAccessInfo app2 = new CMODApplicationAccessInfo();
        app2.setApplicationName("TEST_APP_2");
        app2.setApplicationVersions(Set.of("TEST_APP_2-NDAK-V1", "TEST_APP_2-NDAK-V2"));
        app2.setUserAccess(false);
        app2.setClientEmployeeSecurity(true);

        applications.add(app1);
        applications.add(app2);

        return applications;
    }
}