package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ImageDataModelTest {

    private ImageDataModel imageDataModel;

    // Setup method to initialize ImageDataModel object before each test
    @BeforeEach
    void setUp() {
        imageDataModel = new ImageDataModel();
    }

    @Test
    void testGetAndSetApplid() {
        // Test set and get for 'applid' field
        String testApplid = "APP123";
        imageDataModel.setApplid(testApplid);
        assertEquals(testApplid, imageDataModel.getApplid(), "The applid should match the set value");
    }

    @Test
    void testGetAndSetEnddate() {
        // Test set and get for 'enddate' field
        Date testEnddate = new Date();
        imageDataModel.setEnddate(testEnddate);
        assertEquals(testEnddate, imageDataModel.getEnddate(), "The enddate should match the set value");
    }

    @Test
    void testGetAndSetFiletab() {
        // Test set and get for 'filetab' field
        String testFiletab = "file1";
        imageDataModel.setFiletab(testFiletab);
        assertEquals(testFiletab, imageDataModel.getFiletab(), "The filetab should match the set value");
    }

    @Test
    void testGetAndSetFoldid() {
        // Test set and get for 'foldid' field
        String testFoldid = "FOLD123";
        imageDataModel.setFoldid(testFoldid);
        assertEquals(testFoldid, imageDataModel.getFoldid(), "The foldid should match the set value");
    }

    @Test
    void testGetAndSetShowdeleted() {
        // Test set and get for 'showdeleted' field
        Boolean testShowdeleted = true;
        imageDataModel.setShowdeleted(testShowdeleted);
        assertEquals(testShowdeleted, imageDataModel.getShowdeleted(), "The showdeleted should match the set value");
    }

    @Test
    void testGetAndSetStartdate() {
        // Test set and get for 'startdate' field
        Date testStartdate = new Date();
        imageDataModel.setStartdate(testStartdate);
        assertEquals(testStartdate, imageDataModel.getStartdate(), "The startdate should match the set value");
    }

    @Test
    void testDefaultValues() {
        // Verify default values for the class fields
        assertNull(imageDataModel.getApplid(), "The default applid should be null");
        assertNull(imageDataModel.getEnddate(), "The default enddate should be null");
        assertNull(imageDataModel.getFiletab(), "The default filetab should be null");
        assertNull(imageDataModel.getFoldid(), "The default foldid should be null");
        assertNull(imageDataModel.getShowdeleted(), "The default showdeleted should be null");
        assertNull(imageDataModel.getStartdate(), "The default startdate should be null");
    }
}
