package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class T222CodCmodExtAGPIdTest {

    @Test
    void testNoArgsConstructorAndSetters() {
        T222CodCmodExtAGPId id = new T222CodCmodExtAGPId();

        id.setCmodApplicationGroup("APP_GRP_01");
        id.setCmodUserGroupName("USER_GRP_A");

        assertEquals("APP_GRP_01", id.getCmodApplicationGroup());
        assertEquals("USER_GRP_A", id.getCmodUserGroupName());
    }

    @Test
    void testAllArgsConstructor() {
        T222CodCmodExtAGPId id = new T222CodCmodExtAGPId("APP_GRP_02", "USER_GRP_B");

        assertEquals("APP_GRP_02", id.getCmodApplicationGroup());
        assertEquals("USER_GRP_B", id.getCmodUserGroupName());
    }

    @Test
    void testEqualsAndHashCode() {
        T222CodCmodExtAGPId id1 = new T222CodCmodExtAGPId("APP1", "USER1");
        T222CodCmodExtAGPId id2 = new T222CodCmodExtAGPId("APP1", "USER1");
        T222CodCmodExtAGPId id3 = new T222CodCmodExtAGPId("APP2", "USER2");

        assertEquals(id1, id2);
        assertEquals(id1.hashCode(), id2.hashCode());

        assertNotEquals(id1, id3);
        assertNotEquals(id1.hashCode(), id3.hashCode());
    }

    @Test
    void testEqualsWithNullAndDifferentClass() {
        T222CodCmodExtAGPId id = new T222CodCmodExtAGPId("APP", "USER");

        assertNotEquals(id, null);
        assertNotEquals(id, "some string");
    }
}
