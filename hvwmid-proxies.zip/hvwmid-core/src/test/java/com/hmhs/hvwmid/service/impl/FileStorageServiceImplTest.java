package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.entity.TblImgObject;
import com.hmhs.hvwmid.entity.TblImgObjectId;
import com.hmhs.hvwmid.entity.TblImgToken;
import com.hmhs.hvwmid.model.FileStorageResult;
import com.hmhs.hvwmid.repository.ImgTokenRepository;
import com.hmhs.hvwmid.repository.TblImgObjectRepository;
import com.hmhs.hvwmid.service.GenericUDFService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for FileStorageServiceImpl
 */
@ExtendWith(MockitoExtension.class)
class FileStorageServiceImplTest {

    @Mock
    private TblImgObjectRepository imgObjectRepository;

    @Mock
    private ImgTokenRepository imgTokenRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private GenericUDFService seqGen;

    @InjectMocks
    private FileStorageServiceImpl fileStorageService;

    private static final String TEST_USER_ID = "testuser";
    private static final String TEST_DOCUMENT_TYPE = "PDF";
    private static final Integer TEST_REQUEST_ID = 12345;

    @BeforeEach
    void setUp() {
        // Use MockedConstruction to mock the GenericUDFService constructor
        try (MockedConstruction<GenericUDFService> mockedGenericUDF = mockConstruction(GenericUDFService.class,
                (mock, context) -> {
                    when(mock.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
                })) {
            fileStorageService = new FileStorageServiceImpl(imgObjectRepository, imgTokenRepository, jdbcTemplate);
        }
        
        // Manually set the seqGen mock
        try {
            java.lang.reflect.Field field = FileStorageServiceImpl.class.getDeclaredField("seqGen");
            field.setAccessible(true);
            field.set(fileStorageService, seqGen);
        } catch (Exception e) {
            // Handle reflection error
        }
    }

    // Tests for storeFile method
    @Test
    void storeFile_SmallFile_ShouldStoreSingleChunk() throws Exception {
        // Arrange
        String fileName = "test.pdf";
        String fileContent = "Small test file content";
        MockMultipartFile mockFile = new MockMultipartFile(
            "file", fileName, "application/pdf", fileContent.getBytes()
        );

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE);

        // Assert
        assertNotNull(result);
        assertEquals(TEST_REQUEST_ID, result.getRequestId());
        assertEquals(fileName, result.getFileName());
        assertEquals(TEST_DOCUMENT_TYPE, result.getDocumentType());
        assertEquals(fileContent.length(), result.getDocumentSize());
        assertEquals(0, result.getDocumentPages());
        assertEquals(TEST_USER_ID, result.getUserId());
        assertEquals("UPLOADED", result.getStatus());
        assertNotNull(result.getTimeCreated());

        // Verify token was saved
        ArgumentCaptor<TblImgToken> tokenCaptor = ArgumentCaptor.forClass(TblImgToken.class);
        verify(imgTokenRepository).save(tokenCaptor.capture());
        TblImgToken savedToken = tokenCaptor.getValue();
        assertEquals(TEST_REQUEST_ID, savedToken.getRequestId());
        assertEquals(TEST_USER_ID.toUpperCase(), savedToken.getUserId());
        assertEquals(TEST_DOCUMENT_TYPE.toUpperCase(), savedToken.getDocumentType());
        assertEquals(fileContent.length(), savedToken.getDocumentSize());
        assertEquals("UPLOADED", savedToken.getDocCnvStatus());

        // Verify chunks were saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        assertEquals(1, savedChunks.size());
        
        TblImgObject chunk = savedChunks.get(0);
        assertEquals(TEST_REQUEST_ID, chunk.getId().getRequestId());
        assertEquals(0, chunk.getId().getSequenceNo());
        assertArrayEquals(fileContent.getBytes(), chunk.getObjectSegment());
    }

    @Test
    void storeFile_LargeFile_ShouldStoreMultipleChunks() throws Exception {
        // Arrange
        String fileName = "large.pdf";
        // Create content larger than CHUNK_SIZE (31691 bytes)
        byte[] largeContent = new byte[70000]; // ~70KB
        Arrays.fill(largeContent, (byte) 'A');
        
        MockMultipartFile mockFile = new MockMultipartFile(
            "file", fileName, "application/pdf", largeContent
        );

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE);

        // Assert
        assertNotNull(result);
        assertEquals(TEST_REQUEST_ID, result.getRequestId());
        assertEquals(fileName, result.getFileName());
        assertEquals(largeContent.length, result.getDocumentSize());

        // Verify multiple chunks were saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        
        // Should create 3 chunks: 31691 + 31691 + 6618 = 70000
        assertEquals(3, savedChunks.size());
        
        // Verify sequence numbers
        assertEquals(0, savedChunks.get(0).getId().getSequenceNo());
        assertEquals(1, savedChunks.get(1).getId().getSequenceNo());
        assertEquals(2, savedChunks.get(2).getId().getSequenceNo());
        
        // Verify chunk sizes
        assertEquals(31691, savedChunks.get(0).getObjectSegment().length);
        assertEquals(31691, savedChunks.get(1).getObjectSegment().length);
        assertEquals(6618, savedChunks.get(2).getObjectSegment().length); // Remaining bytes
    }

    @Test
    void storeFile_EmptyFile_ShouldCreateTokenWithoutChunks() throws Exception {
        // Arrange
        String fileName = "empty.txt";
        MockMultipartFile mockFile = new MockMultipartFile(
            "file", fileName, "text/plain", new byte[0]
        );

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE);

        // Assert
        assertNotNull(result);
        assertEquals(0, result.getDocumentSize());

        // Verify no chunks were saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        assertEquals(0, savedChunks.size());
    }

    @Test
    void storeFile_IOException_ShouldThrowException() throws Exception {
        // Arrange
        MultipartFile mockFile = mock(MultipartFile.class);
        when(mockFile.getOriginalFilename()).thenReturn("test.pdf");
        when(mockFile.getSize()).thenReturn(100L);
        when(mockFile.getInputStream()).thenThrow(new IOException("Stream error"));
        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));

        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> 
            fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE)
        );
        
        assertTrue(exception.getMessage().contains("Failed to store file"));
        assertTrue(exception.getCause() instanceof IOException);
    }

    @Test
    void storeFile_RepositoryError_ShouldThrowException() throws Exception {
        // Arrange
        MockMultipartFile mockFile = new MockMultipartFile(
            "file", "test.pdf", "application/pdf", "content".getBytes()
        );

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class)))
            .thenThrow(new RuntimeException("Database error"));

        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> 
            fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE)
        );
        
        assertTrue(exception.getMessage().contains("Failed to store file"));
    }

    // Tests for storeFileContent method
    @Test
    void storeFileContent_SmallContent_ShouldStoreSingleChunk() throws Exception {
        // Arrange
        String fileName = "test-content.txt";
        String content = "Test file content";
        byte[] contentBytes = content.getBytes();

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFileContent(
            contentBytes, fileName, TEST_USER_ID, TEST_DOCUMENT_TYPE
        );

        // Assert
        assertNotNull(result);
        assertEquals(TEST_REQUEST_ID, result.getRequestId());
        assertEquals(fileName, result.getFileName());
        assertEquals(TEST_DOCUMENT_TYPE, result.getDocumentType());
        assertEquals(contentBytes.length, result.getDocumentSize());
        assertEquals(TEST_USER_ID, result.getUserId());
        assertEquals("UPLOADED", result.getStatus());

        // Verify chunks were saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        assertEquals(1, savedChunks.size());
        
        TblImgObject chunk = savedChunks.get(0);
        assertEquals(TEST_REQUEST_ID, chunk.getId().getRequestId());
        assertEquals(0, chunk.getId().getSequenceNo());
        assertArrayEquals(contentBytes, chunk.getObjectSegment());
    }

    @Test
    void storeFileContent_LargeContent_ShouldStoreMultipleChunks() throws Exception {
        // Arrange
        String fileName = "large-content.bin";
        byte[] largeContent = new byte[100000]; // 100KB
        Arrays.fill(largeContent, (byte) 'B');

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFileContent(
            largeContent, fileName, TEST_USER_ID, TEST_DOCUMENT_TYPE
        );

        // Assert
        assertNotNull(result);
        assertEquals(largeContent.length, result.getDocumentSize());

        // Verify multiple chunks were saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        
        // Should create 4 chunks: 31691 + 31691 + 31691 + 4927 = 100000
        assertEquals(4, savedChunks.size());
        
        // Verify chunk sizes
        assertEquals(31691, savedChunks.get(0).getObjectSegment().length);
        assertEquals(31691, savedChunks.get(1).getObjectSegment().length);
        assertEquals(31691, savedChunks.get(2).getObjectSegment().length);
        assertEquals(4927, savedChunks.get(3).getObjectSegment().length);
    }

    @Test
    void storeFileContent_RepositoryError_ShouldThrowException() throws Exception {
        // Arrange
        byte[] content = "test content".getBytes();
        String fileName = "test.txt";

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class)))
            .thenThrow(new RuntimeException("Database error"));

        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> 
            fileStorageService.storeFileContent(content, fileName, TEST_USER_ID, TEST_DOCUMENT_TYPE)
        );
        
        assertTrue(exception.getMessage().contains("Failed to store file content"));
    }

    // Tests for getFileMetadata method
    @Test
    void getFileMetadata_ExistingFile_ShouldReturnMetadata() {
        // Arrange
        LocalDateTime timeCreated = LocalDateTime.now();
        TblImgToken token = new TblImgToken();
        token.setRequestId(TEST_REQUEST_ID);
        token.setUserId(TEST_USER_ID.toUpperCase() + "  "); // Test trimming
        token.setDocumentType(TEST_DOCUMENT_TYPE.toUpperCase() + "  "); // Test trimming
        token.setDocumentSize(1024);
        token.setDocumentPages(1);
        token.setTimeCreate(timeCreated);
        token.setDocCnvStatus("UPLOADED  "); // Test trimming

        when(imgTokenRepository.findById(TEST_REQUEST_ID)).thenReturn(Optional.of(token));

        // Act
        FileStorageResult result = fileStorageService.getFileMetadata(TEST_REQUEST_ID);

        // Assert
        assertNotNull(result);
        assertEquals(TEST_REQUEST_ID, result.getRequestId());
        assertEquals("", result.getFileName()); // Not stored in token
        assertEquals(TEST_DOCUMENT_TYPE.toUpperCase(), result.getDocumentType());
        assertEquals(1024, result.getDocumentSize());
        assertEquals(1, result.getDocumentPages());
        assertEquals(TEST_USER_ID.toUpperCase(), result.getUserId());
        assertEquals(timeCreated, result.getTimeCreated());
        assertEquals("UPLOADED", result.getStatus());
    }

    @Test
    void getFileMetadata_NonExistentFile_ShouldReturnNull() {
        // Arrange
        when(imgTokenRepository.findById(TEST_REQUEST_ID)).thenReturn(Optional.empty());

        // Act
        FileStorageResult result = fileStorageService.getFileMetadata(TEST_REQUEST_ID);

        // Assert
        assertNull(result);
    }

    // Tests for validateAccess method
    @Test
    void validateAccess_ValidUser_ShouldReturnTrue() {
        // Arrange
        TblImgToken token = new TblImgToken();
        token.setUserId(TEST_USER_ID.toUpperCase() + "  "); // Test trimming

        when(imgTokenRepository.findById(TEST_REQUEST_ID)).thenReturn(Optional.of(token));

        // Act
        boolean result = fileStorageService.validateAccess(TEST_REQUEST_ID, TEST_USER_ID);

        // Assert
        assertTrue(result);
    }

    @Test
    void validateAccess_InvalidUser_ShouldReturnFalse() {
        // Arrange
        TblImgToken token = new TblImgToken();
        token.setUserId("OTHERUSER");

        when(imgTokenRepository.findById(TEST_REQUEST_ID)).thenReturn(Optional.of(token));

        // Act
        boolean result = fileStorageService.validateAccess(TEST_REQUEST_ID, TEST_USER_ID);

        // Assert
        assertFalse(result);
    }

    @Test
    void validateAccess_NonExistentFile_ShouldReturnFalse() {
        // Arrange
        when(imgTokenRepository.findById(TEST_REQUEST_ID)).thenReturn(Optional.empty());

        // Act
        boolean result = fileStorageService.validateAccess(TEST_REQUEST_ID, TEST_USER_ID);

        // Assert
        assertFalse(result);
    }

    @Test
    void validateAccess_CaseInsensitive_ShouldReturnTrue() {
        // Arrange
        TblImgToken token = new TblImgToken();
        token.setUserId("TESTUSER");

        when(imgTokenRepository.findById(TEST_REQUEST_ID)).thenReturn(Optional.of(token));

        // Act
        boolean result = fileStorageService.validateAccess(TEST_REQUEST_ID, "testuser");

        // Assert
        assertTrue(result);
    }

    // Tests for deleteFile method
    @Test
    void deleteFile_ExistingFile_ShouldDeleteSuccessfully() throws Exception {
        // Arrange
        when(imgTokenRepository.existsById(TEST_REQUEST_ID)).thenReturn(true);
        doNothing().when(imgTokenRepository).deleteById(TEST_REQUEST_ID);

        // Act
        assertDoesNotThrow(() -> fileStorageService.deleteFile(TEST_REQUEST_ID));

        // Assert
        verify(imgTokenRepository).existsById(TEST_REQUEST_ID);
        verify(imgTokenRepository).deleteById(TEST_REQUEST_ID);
    }

    @Test
    void deleteFile_NonExistentFile_ShouldNotAttemptDeletion() throws Exception {
        // Arrange
        when(imgTokenRepository.existsById(TEST_REQUEST_ID)).thenReturn(false);

        // Act
        assertDoesNotThrow(() -> fileStorageService.deleteFile(TEST_REQUEST_ID));

        // Assert
        verify(imgTokenRepository).existsById(TEST_REQUEST_ID);
        verify(imgTokenRepository, never()).deleteById(anyInt());
    }

    @Test
    void deleteFile_RepositoryError_ShouldThrowException() {
        // Arrange
        when(imgTokenRepository.existsById(TEST_REQUEST_ID)).thenReturn(true);
        doThrow(new RuntimeException("Database error")).when(imgTokenRepository).deleteById(TEST_REQUEST_ID);

        // Act & Assert
        Exception exception = assertThrows(Exception.class, () -> 
            fileStorageService.deleteFile(TEST_REQUEST_ID)
        );
        
        assertTrue(exception.getMessage().contains("Failed to delete file"));
    }

    // Edge case tests
    @Test
    void storeFile_NullFilename_ShouldHandleGracefully() throws Exception {
        // Arrange
        MockMultipartFile mockFile = new MockMultipartFile(
            "file", null, "application/pdf", "content".getBytes()
        );

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE);

        // Assert
        assertNotNull(result);
        // When filename is null, getOriginalFilename() returns null but the service may store it as empty string
        assertTrue(result.getFileName() == null || result.getFileName().isEmpty());
    }

    @Test
    void storeFile_ExactChunkSize_ShouldStoreSingleChunk() throws Exception {
        // Arrange
        String fileName = "exact-chunk.bin";
        byte[] exactChunkContent = new byte[31691]; // Exactly CHUNK_SIZE
        Arrays.fill(exactChunkContent, (byte) 'X');
        
        MockMultipartFile mockFile = new MockMultipartFile(
            "file", fileName, "application/octet-stream", exactChunkContent
        );

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFile(mockFile, TEST_USER_ID, TEST_DOCUMENT_TYPE);

        // Assert
        assertNotNull(result);
        assertEquals(31691, result.getDocumentSize());

        // Verify exactly one chunk was saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        assertEquals(1, savedChunks.size());
        assertEquals(31691, savedChunks.get(0).getObjectSegment().length);
    }

    @Test
    void storeFileContent_EmptyContent_ShouldCreateTokenWithoutChunks() throws Exception {
        // Arrange
        String fileName = "empty-content.txt";
        byte[] emptyContent = new byte[0];

        when(seqGen.generateRequestId()).thenReturn(TEST_REQUEST_ID.toString());
        when(imgTokenRepository.save(any(TblImgToken.class))).thenAnswer(i -> i.getArgument(0));
        when(imgObjectRepository.saveAll(anyList())).thenAnswer(i -> i.getArgument(0));

        // Act
        FileStorageResult result = fileStorageService.storeFileContent(
            emptyContent, fileName, TEST_USER_ID, TEST_DOCUMENT_TYPE
        );

        // Assert
        assertNotNull(result);
        assertEquals(0, result.getDocumentSize());

        // Verify no chunks were saved
        ArgumentCaptor<List<TblImgObject>> chunksCaptor = ArgumentCaptor.forClass(List.class);
        verify(imgObjectRepository).saveAll(chunksCaptor.capture());
        List<TblImgObject> savedChunks = chunksCaptor.getValue();
        assertEquals(0, savedChunks.size());
    }
}