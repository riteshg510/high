package com.hmhs.hvwmid;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CoreModuleTests {
    @Test
    void test() {
        Assertions.assertTrue(true);
    }
}
