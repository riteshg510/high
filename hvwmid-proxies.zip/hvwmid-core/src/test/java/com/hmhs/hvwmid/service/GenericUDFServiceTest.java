package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.entity.TblImgObject;
import com.hmhs.hvwmid.repository.GenericUDFDao;
import com.hmhs.hvwmid.repository.TblImgObjectRepository;
import com.hmhs.hvwmid.utils.HVWUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.DataInputStream;
import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GenericUDFServiceTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private TblImgObjectRepository imgObjectRepository;

    @Mock
    private LoggerService loggerService;

    @Mock
    private GenericUDFDao udfDao;

    @InjectMocks
    private GenericUDFService service = new GenericUDFService(jdbcTemplate, "DB2222056A_UDF");

    @BeforeEach
    void setUp() throws Exception {
        // Inject parmDataMapByCmodbase
        Field mapField = GenericUDFService.class.getDeclaredField("parmDataMapByCmodbase");
        mapField.setAccessible(true);
        mapField.set(service, Map.of("someKey", "value123"));

        // Inject udfDao manually
        Field daoField = GenericUDFService.class.getDeclaredField("udfDao");
        daoField.setAccessible(true);
        daoField.set(service, udfDao);
    }

    @Test
    void testGenerateRequestId_returnsStringFromDB() {
        when(udfDao.getSequenceNumber()).thenReturn("REQ123");
        String result = service.generateRequestId();
        assertEquals("REQ123", result);
    }

    @Test
    void testGenerateRequestId_withEnv_returnsIntegerFromDB() {
        try (MockedStatic<HVWUtils> utilsMock = mockStatic(HVWUtils.class)) {
            utilsMock.when(() -> HVWUtils.getCollection("DEV")).thenReturn("DEV_COLL");
            when(udfDao.getSequenceNumber("DEV_COLL")).thenReturn(456789);
            int result = service.generateRequestId("DEV");
            assertEquals(456789, result);
        }
    }

    @Test
    void testGetParmDataByKeyByCmodbase_foundInMap() {
        String result = service.getParmDataByKeyByCmodbase("someKey", "defaultVal");
        assertEquals("value123", result);
    }

    @Test
    void testGetParmDataByKeyByCmodbase_notInMap_returnsDefault() {
        String result = service.getParmDataByKeyByCmodbase("unknownKey", "fallbackVal");
        assertEquals("fallbackVal", result);
    }

    @Test
    void testCommitT222ImgToken_persistsObject() {
        DataInputStream dummyStream = mock(DataInputStream.class); // not used in this impl
        when(imgObjectRepository.save(any(TblImgObject.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        TblImgObject saved = service.commitT222ImgToken(1001, 55, dummyStream);
        assertNotNull(saved);
//        assertEquals(1001, saved.getRequestId());
//        assertEquals(55, saved.getSequenceNo());
        assertNotNull(saved.getTimeCreate());
        assertArrayEquals(new byte[]{0x1A, 0x2B}, saved.getObjectSegment());
    }
}
