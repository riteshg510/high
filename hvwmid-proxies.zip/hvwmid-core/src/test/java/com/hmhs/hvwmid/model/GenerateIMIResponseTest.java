package com.hmhs.hvwmid.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for GenerateIMIResponse model
 */
class GenerateIMIResponseTest {

    private GenerateIMIResponse response;

    @BeforeEach
    void setUp() {
        response = new GenerateIMIResponse();
    }

    @Test
    void testGetSetGeneratedFiles() {
        // Arrange
        List<GenerateIMIResponse.GeneratedFile> files = new ArrayList<>();
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        file.setImiFileId(123);
        file.setImiFileName("test.imi");
        file.setDocumentCount(25);
        file.setStatus("SUCCESS");
        files.add(file);

        // Act
        response.setGeneratedFiles(files);

        // Assert
        assertEquals(files, response.getGeneratedFiles());
        assertEquals(1, response.getGeneratedFiles().size());
        assertEquals(Integer.valueOf(123), response.getGeneratedFiles().get(0).getImiFileId());
        assertEquals("test.imi", response.getGeneratedFiles().get(0).getImiFileName());
    }

    @Test
    void testGetSetOutputExcelId() {
        // Arrange
        Integer outputExcelId = 456;

        // Act
        response.setOutputExcelId(outputExcelId);

        // Assert
        assertEquals(outputExcelId, response.getOutputExcelId());
    }

    @Test
    void testGetSetSummary() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        summary.setTotalRows(100);
        summary.setSuccessful(95);
        summary.setFailed(3);
        summary.setWarnings(2);

        // Act
        response.setSummary(summary);

        // Assert
        assertEquals(summary, response.getSummary());
        assertEquals(Integer.valueOf(100), response.getSummary().getTotalRows());
        assertEquals(Integer.valueOf(95), response.getSummary().getSuccessful());
    }

    @Test
    void testGetSetMessage() {
        // Arrange
        String message = "Successfully generated 2 IMI files with 95 documents";

        // Act
        response.setMessage(message);

        // Assert
        assertEquals(message, response.getMessage());
    }

    @Test
    void testSerializableImplementation() {
        // Assert that the class implements Serializable
        assertTrue(response instanceof java.io.Serializable);
    }

    @Test
    void testCompleteResponseSetup() {
        // Arrange
        List<GenerateIMIResponse.GeneratedFile> files = Arrays.asList(
            createGeneratedFile(123, "batch1.imi", 25, "SUCCESS"),
            createGeneratedFile(124, "batch2.imi", 20, "SUCCESS")
        );
        
        GenerateIMIResponse.Summary summary = createSummary(100, 95, 3, 2);
        Integer outputExcelId = 456;
        String message = "Processing completed successfully";

        // Act
        response.setGeneratedFiles(files);
        response.setSummary(summary);
        response.setOutputExcelId(outputExcelId);
        response.setMessage(message);

        // Assert
        assertEquals(2, response.getGeneratedFiles().size());
        assertNotNull(response.getSummary());
        assertEquals(outputExcelId, response.getOutputExcelId());
        assertEquals(message, response.getMessage());
    }

    @Test
    void testDefaultConstructor() {
        // Act
        GenerateIMIResponse newResponse = new GenerateIMIResponse();

        // Assert
        assertNull(newResponse.getGeneratedFiles());
        assertNull(newResponse.getOutputExcelId());
        assertNull(newResponse.getSummary());
        assertNull(newResponse.getMessage());
    }

    // Helper methods
    private GenerateIMIResponse.GeneratedFile createGeneratedFile(Integer id, String fileName, Integer count, String status) {
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        file.setImiFileId(id);
        file.setImiFileName(fileName);
        file.setDocumentCount(count);
        file.setStatus(status);
        return file;
    }

    private GenerateIMIResponse.Summary createSummary(Integer total, Integer successful, Integer failed, Integer warnings) {
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        summary.setTotalRows(total);
        summary.setSuccessful(successful);
        summary.setFailed(failed);
        summary.setWarnings(warnings);
        return summary;
    }

    // Tests for nested GeneratedFile class
    @Test
    void testGeneratedFileGetSetImiFileId() {
        // Arrange
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        Integer imiFileId = 123;

        // Act
        file.setImiFileId(imiFileId);

        // Assert
        assertEquals(imiFileId, file.getImiFileId());
    }

    @Test
    void testGeneratedFileGetSetImiFileName() {
        // Arrange
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        String fileName = "batch_001.imi";

        // Act
        file.setImiFileName(fileName);

        // Assert
        assertEquals(fileName, file.getImiFileName());
    }

    @Test
    void testGeneratedFileGetSetDocumentCount() {
        // Arrange
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        Integer documentCount = 25;

        // Act
        file.setDocumentCount(documentCount);

        // Assert
        assertEquals(documentCount, file.getDocumentCount());
    }

    @Test
    void testGeneratedFileGetSetStatus() {
        // Arrange
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        String status = "SUCCESS";

        // Act
        file.setStatus(status);

        // Assert
        assertEquals(status, file.getStatus());
    }

    @Test
    void testGeneratedFileSerializable() {
        // Arrange
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();

        // Assert
        assertTrue(file instanceof java.io.Serializable);
    }

    @Test
    void testGeneratedFileDefaultConstructor() {
        // Act
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();

        // Assert
        assertNull(file.getImiFileId());
        assertNull(file.getImiFileName());
        assertNull(file.getDocumentCount());
        assertNull(file.getStatus());
    }

    @Test
    void testGeneratedFileWithDifferentStatuses() {
        // Test different status values
        String[] statuses = {"SUCCESS", "FAILED", "WARNING", "PARTIAL"};

        for (String status : statuses) {
            GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
            file.setStatus(status);
            assertEquals(status, file.getStatus());
        }
    }

    @Test
    void testGeneratedFileCompleteSetup() {
        // Arrange
        GenerateIMIResponse.GeneratedFile file = new GenerateIMIResponse.GeneratedFile();
        Integer id = 999;
        String fileName = "complete_test.imi";
        Integer count = 50;
        String status = "SUCCESS";

        // Act
        file.setImiFileId(id);
        file.setImiFileName(fileName);
        file.setDocumentCount(count);
        file.setStatus(status);

        // Assert
        assertEquals(id, file.getImiFileId());
        assertEquals(fileName, file.getImiFileName());
        assertEquals(count, file.getDocumentCount());
        assertEquals(status, file.getStatus());
    }

    // Tests for nested Summary class
    @Test
    void testSummaryGetSetTotalRows() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        Integer totalRows = 100;

        // Act
        summary.setTotalRows(totalRows);

        // Assert
        assertEquals(totalRows, summary.getTotalRows());
    }

    @Test
    void testSummaryGetSetSuccessful() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        Integer successful = 95;

        // Act
        summary.setSuccessful(successful);

        // Assert
        assertEquals(successful, summary.getSuccessful());
    }

    @Test
    void testSummaryGetSetFailed() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        Integer failed = 3;

        // Act
        summary.setFailed(failed);

        // Assert
        assertEquals(failed, summary.getFailed());
    }

    @Test
    void testSummaryGetSetWarnings() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        Integer warnings = 2;

        // Act
        summary.setWarnings(warnings);

        // Assert
        assertEquals(warnings, summary.getWarnings());
    }

    @Test
    void testSummarySerializable() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();

        // Assert
        assertTrue(summary instanceof java.io.Serializable);
    }

    @Test
    void testSummaryDefaultConstructor() {
        // Act
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();

        // Assert
        assertNull(summary.getTotalRows());
        assertNull(summary.getSuccessful());
        assertNull(summary.getFailed());
        assertNull(summary.getWarnings());
    }

    @Test
    void testSummaryCompleteSetup() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        Integer total = 1000;
        Integer successful = 950;
        Integer failed = 30;
        Integer warnings = 20;

        // Act
        summary.setTotalRows(total);
        summary.setSuccessful(successful);
        summary.setFailed(failed);
        summary.setWarnings(warnings);

        // Assert
        assertEquals(total, summary.getTotalRows());
        assertEquals(successful, summary.getSuccessful());
        assertEquals(failed, summary.getFailed());
        assertEquals(warnings, summary.getWarnings());
    }

    @Test
    void testSummaryCalculations() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        summary.setTotalRows(100);
        summary.setSuccessful(85);
        summary.setFailed(10);
        summary.setWarnings(5);

        // Assert - Test that numbers make sense
        assertTrue(summary.getSuccessful() + summary.getFailed() <= summary.getTotalRows());
        assertTrue(summary.getSuccessful() >= 0);
        assertTrue(summary.getFailed() >= 0);
        assertTrue(summary.getWarnings() >= 0);
    }

    @Test
    void testSummaryZeroValues() {
        // Arrange
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();

        // Act
        summary.setTotalRows(0);
        summary.setSuccessful(0);
        summary.setFailed(0);
        summary.setWarnings(0);

        // Assert
        assertEquals(Integer.valueOf(0), summary.getTotalRows());
        assertEquals(Integer.valueOf(0), summary.getSuccessful());
        assertEquals(Integer.valueOf(0), summary.getFailed());
        assertEquals(Integer.valueOf(0), summary.getWarnings());
    }

    @Test
    void testResponseWithEmptyGeneratedFiles() {
        // Arrange
        List<GenerateIMIResponse.GeneratedFile> emptyFiles = new ArrayList<>();

        // Act
        response.setGeneratedFiles(emptyFiles);

        // Assert
        assertNotNull(response.getGeneratedFiles());
        assertTrue(response.getGeneratedFiles().isEmpty());
        assertEquals(0, response.getGeneratedFiles().size());
    }

    @Test
    void testResponseWithMultipleGeneratedFiles() {
        // Arrange
        List<GenerateIMIResponse.GeneratedFile> files = Arrays.asList(
            createGeneratedFile(1, "file1.imi", 25, "SUCCESS"),
            createGeneratedFile(2, "file2.imi", 30, "SUCCESS"),
            createGeneratedFile(3, "file3.imi", 15, "WARNING"),
            createGeneratedFile(4, "file4.imi", 0, "FAILED")
        );

        // Act
        response.setGeneratedFiles(files);

        // Assert
        assertEquals(4, response.getGeneratedFiles().size());
        assertEquals("SUCCESS", response.getGeneratedFiles().get(0).getStatus());
        assertEquals("WARNING", response.getGeneratedFiles().get(2).getStatus());
        assertEquals("FAILED", response.getGeneratedFiles().get(3).getStatus());
    }
}