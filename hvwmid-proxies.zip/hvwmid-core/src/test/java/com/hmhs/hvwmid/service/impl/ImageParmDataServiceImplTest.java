package com.hmhs.hvwmid.service.impl;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.repository.T222APRMRepository;
import com.hmhs.hvwmid.service.ImageParmDataService;
import com.hmhs.hvwmid.service.VCodReportSecurityExitService;
import org.apache.commons.collections4.BidiMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ImageParmDataServiceImplTest {

    @Mock
    private T222APRMRepository t222APRMRepository;

    @Mock
    private VCodReportSecurityExitService vCodReportSecurityExitService;

    @InjectMocks
    private ImageParmDataServiceImpl imageParmDataService;

    private Map<String, String> hvwbaseTestData;
    private Map<String, String> cmbaseTestData;
    private Map<String, String> codbaseTestData;
    private Map<String, String> cmfldmapTestData;
    private Map<String, Map<String, String>> additionalParmMapsTestData;

    @BeforeEach
    void setUp() {
        // Set up test data
        hvwbaseTestData = new HashMap<>();
        hvwbaseTestData.put("TEST_KEY_1", "TEST_VALUE_1");
        hvwbaseTestData.put("TEST_KEY_2", "TEST_VALUE_2");

        cmbaseTestData = new HashMap<>();
        cmbaseTestData.put("CMOD_KEY_1", "CMOD_VALUE_1");
        cmbaseTestData.put("CMOD_KEY_2", "CMOD_VALUE_2");

        codbaseTestData = new HashMap<>();
        codbaseTestData.put("COD_KEY_1", "COD_VALUE_1");
        codbaseTestData.put("COD_KEY_2", "COD_VALUE_2");

        cmfldmapTestData = new HashMap<>();
        cmfldmapTestData.put("FIELD_1", "FOLDER_1");
        cmfldmapTestData.put("FIELD_2", "FOLDER_2");

        additionalParmMapsTestData = new HashMap<>();
        Map<String, String> cmuserexData = new HashMap<>();
        cmuserexData.put("USER_KEY_1", "USER_VALUE_1");
        additionalParmMapsTestData.put(HVWConstants.CMUSEREX, cmuserexData);

        // Set up default lenient mocks for all parameter types to avoid strict stubbing issues
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.HVWBASE))).thenReturn(hvwbaseTestData);
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.CMBASE))).thenReturn(cmbaseTestData);
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.CODBASE))).thenReturn(codbaseTestData);
        lenient().when(t222APRMRepository.getParmDataAsMap(eq(HVWConstants.CMFLDMAP))).thenReturn(cmfldmapTestData);
        lenient().when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalParmMapsTestData);
        
        // Mock VCodReportSecurityExitService
        Map<String, Map<String, String>> securityExitTestData = new HashMap<>();
        Map<String, String> appData = new HashMap<>();
        appData.put("Index", "TEST_INDEX");
        appData.put("BpdId", "TEST_BPD_ID");
        securityExitTestData.put("TEST_APP", appData);
        try {
            lenient().when(vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication()).thenReturn(securityExitTestData);
        } catch (Exception e) {
            // Handle SQLException in test setup
        }
    }

    @Test
    void testRefreshParmData() {
        // Mock repository responses
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(hvwbaseTestData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE)).thenReturn(cmbaseTestData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CODBASE)).thenReturn(codbaseTestData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMFLDMAP)).thenReturn(cmfldmapTestData);
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalParmMapsTestData);
        
        try {
            when(vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication()).thenReturn(new HashMap<>());
        } catch (Exception e) {
            // Handle SQLException in test
        }

        // Execute refresh
        imageParmDataService.refreshParmData();

        // Verify repository calls
        verify(t222APRMRepository).getParmDataAsMap(HVWConstants.HVWBASE);
        verify(t222APRMRepository).getParmDataAsMap(HVWConstants.CMBASE);
        verify(t222APRMRepository).getParmDataAsMap(HVWConstants.CODBASE);
        verify(t222APRMRepository).getParmDataAsMap(HVWConstants.CMFLDMAP);
        verify(t222APRMRepository).getParmDataMapsGroupedByParmId(anyList());
    }

    @Test
    void testGetParmDataByKeyByHvwbase() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
        assertEquals("TEST_VALUE_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByHvwbase("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);

        // Test null key
        String nullResult = imageParmDataService.getParmDataByKeyByHvwbase(null, "DEFAULT");
        assertEquals("DEFAULT", nullResult);
    }

    @Test
    void testGetParmDataByKeyByHvwbaseWithoutDefault() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1");
        assertEquals("TEST_VALUE_1", result);

        // Test non-existing key
        String nullResult = imageParmDataService.getParmDataByKeyByHvwbase("NON_EXISTING_KEY");
        assertNull(nullResult);
    }

    @Test
    void testGetParmDataByKeyByCmodbase() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByCmodbase("CMOD_KEY_1", "DEFAULT");
        assertEquals("CMOD_VALUE_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByCmodbase("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetParmDataByKeyByCODBase() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByCODBase("COD_KEY_1", "DEFAULT");
        assertEquals("COD_VALUE_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByCODBase("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetParmDataByKeyByCmodfld() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing key
        String result = imageParmDataService.getParmDataByKeyByCmodfld("FIELD_1", "DEFAULT");
        assertEquals("FOLDER_1", result);

        // Test non-existing key
        String defaultResult = imageParmDataService.getParmDataByKeyByCmodfld("NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetCmodfldMap() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test bidirectional map
        BidiMap<String, String> result = imageParmDataService.getCmodfldMap();
        assertNotNull(result);
        assertEquals("FOLDER_1", result.get("FIELD_1"));
        assertEquals("FIELD_1", result.getKey("FOLDER_1"));
    }

    @Test
    void testGetParmKeyByParmDataByCmodfld() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing value
        String result = imageParmDataService.getParmKeyByParmDataByCmodfld("FOLDER_1", "DEFAULT");
        assertEquals("FIELD_1", result);

        // Test non-existing value
        String defaultResult = imageParmDataService.getParmKeyByParmDataByCmodfld("NON_EXISTING_VALUE", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testGetParmData() {
        // Mock repository response
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalParmMapsTestData);

        // Initialize service
        imageParmDataService.refreshParmData();

        // Test existing parm ID and key
        String result = imageParmDataService.getParmData(HVWConstants.CMUSEREX, "USER_KEY_1");
        assertEquals("USER_VALUE_1", result);

        // Test non-existing parm ID
        String nullResult = imageParmDataService.getParmData("NON_EXISTING_PARM_ID", "USER_KEY_1");
        assertNull(nullResult);

        // Test null parameters
        String nullParmIdResult = imageParmDataService.getParmData(null, "USER_KEY_1");
        assertNull(nullParmIdResult);

        String nullKeyResult = imageParmDataService.getParmData(HVWConstants.CMUSEREX, null);
        assertNull(nullKeyResult);
    }

    @Test
    void testGetParmDataMap() {
        // Mock repository responses
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(hvwbaseTestData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE)).thenReturn(cmbaseTestData);
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CODBASE)).thenReturn(codbaseTestData);
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalParmMapsTestData);

        // Initialize service
        imageParmDataService.refreshParmData();

        // Test HVWBASE
        Map<String, String> hvwbaseResult = imageParmDataService.getParmDataMap(HVWConstants.HVWBASE);
        assertNotNull(hvwbaseResult);
        assertEquals(hvwbaseTestData.size(), hvwbaseResult.size());
        assertEquals("TEST_VALUE_1", hvwbaseResult.get("TEST_KEY_1"));

        // Test CMBASE
        Map<String, String> cmbaseResult = imageParmDataService.getParmDataMap(HVWConstants.CMBASE);
        assertNotNull(cmbaseResult);
        assertEquals(cmbaseTestData.size(), cmbaseResult.size());
        assertEquals("CMOD_VALUE_1", cmbaseResult.get("CMOD_KEY_1"));

        // Test CODBASE
        Map<String, String> codbaseResult = imageParmDataService.getParmDataMap(HVWConstants.CODBASE);
        assertNotNull(codbaseResult);
        assertEquals(codbaseTestData.size(), codbaseResult.size());
        assertEquals("COD_VALUE_1", codbaseResult.get("COD_KEY_1"));

        // Test additional parm ID
        Map<String, String> cmuserexResult = imageParmDataService.getParmDataMap(HVWConstants.CMUSEREX);
        assertNotNull(cmuserexResult);
        assertEquals("USER_VALUE_1", cmuserexResult.get("USER_KEY_1"));

        // Test non-existing parm ID
        Map<String, String> nullResult = imageParmDataService.getParmDataMap("NON_EXISTING_PARM_ID");
        assertNull(nullResult);

        // Test null parm ID
        Map<String, String> nullParmIdResult = imageParmDataService.getParmDataMap(null);
        assertNull(nullParmIdResult);
    }

    @Test
    void testGetParmDataByKey() {
        // Mock repository response
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(additionalParmMapsTestData);

        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with default value
        String result = imageParmDataService.getParmDataByKey(HVWConstants.CMUSEREX, "USER_KEY_1", "DEFAULT");
        assertEquals("USER_VALUE_1", result);

        String defaultResult = imageParmDataService.getParmDataByKey(HVWConstants.CMUSEREX, "NON_EXISTING_KEY", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);

        // Test without default value
        String emptyResult = imageParmDataService.getParmDataByKey(HVWConstants.CMUSEREX, "NON_EXISTING_KEY");
        assertEquals("", emptyResult);
    }

    @Test
    void testGetParmDataMapBySecuredClntEmpSec() {
        // Mock empty secured client employee security data
        when(t222APRMRepository.getParmDataAsMap(any())).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(new HashMap<>());
        
        try {
            when(vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication()).thenReturn(new HashMap<>());
        } catch (Exception e) {
            // Handle SQLException in test
        }

        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null application
        Map<String, String> nullResult = imageParmDataService.getParmDataMapBySecuredClntEmpSec(null);
        assertNotNull(nullResult);
        assertTrue(nullResult.isEmpty());

        // Test with non-existing application
        Map<String, String> emptyResult = imageParmDataService.getParmDataMapBySecuredClntEmpSec("NON_EXISTING_APP");
        assertNotNull(emptyResult);
        assertTrue(emptyResult.isEmpty());
    }

    @Test
    void testGetSecuredClntEmpSecMap() {
        // Mock empty secured client employee security data
        when(t222APRMRepository.getParmDataAsMap(any())).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(new HashMap<>());
        
        try {
            when(vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication()).thenReturn(new HashMap<>());
        } catch (Exception e) {
            // Handle SQLException in test
        }

        // Initialize service
        imageParmDataService.refreshParmData();

        // Test getting the complete map
        Map<String, Map<String, String>> result = imageParmDataService.getSecuredClntEmpSecMap();
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetParmKeyByParmDataByODCMODField() {
        // Mock empty data
        when(t222APRMRepository.getParmDataAsMap(any())).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(new HashMap<>());
        
        try {
            when(vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication()).thenReturn(new HashMap<>());
        } catch (Exception e) {
            // Handle SQLException in test
        }

        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null parm key
        String nullResult = imageParmDataService.getParmKeyByParmDataByODCMODField(null, "folder", "DEFAULT");
        assertEquals("DEFAULT", nullResult);

        // Test with non-existing parm key
        String defaultResult = imageParmDataService.getParmKeyByParmDataByODCMODField("NON_EXISTING_KEY", "folder", "DEFAULT");
        assertEquals("DEFAULT", defaultResult);
    }

    @Test
    void testRefreshParmDataHandlesException() {
        // Mock repository to throw exception
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenThrow(new RuntimeException("Database error"));

        // Test that exception is properly wrapped
        assertThrows(RuntimeException.class, () -> imageParmDataService.refreshParmData());
    }

    @Test
    void testInitializeParmDataIsCalledOnPostConstruct() {
        // This tests the @PostConstruct annotation functionality
        // Since @PostConstruct is called automatically during bean initialization,
        // we verify that the data is loaded when service is created
        
        // Create a new instance to test initialization
        ImageParmDataServiceImpl newService = new ImageParmDataServiceImpl(t222APRMRepository,vCodReportSecurityExitService);
        
        // Call the initialization method directly to simulate @PostConstruct
        newService.initializeParmData();
        
        // Verify that repository was called during initialization
        verify(t222APRMRepository, atLeastOnce()).getParmDataAsMap(any());
    }

    @Test
    void testGetParmDataByKeyWithNullParams() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null parmId
        String nullParmIdResult = imageParmDataService.getParmDataByKey(null, "key", "DEFAULT");
        assertEquals("DEFAULT", nullParmIdResult);

        // Test with null parmKey
        String nullKeyResult = imageParmDataService.getParmDataByKey(HVWConstants.CMUSEREX, null, "DEFAULT");
        assertEquals("DEFAULT", nullKeyResult);

        // Test with both null
        String bothNullResult = imageParmDataService.getParmDataByKey(null, null, "DEFAULT");
        assertEquals("DEFAULT", bothNullResult);
    }

    @Test
    void testGetParmDataByKeyByCmodfldWithNullKey() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null key
        String nullResult = imageParmDataService.getParmDataByKeyByCmodfld(null, "DEFAULT");
        assertEquals("DEFAULT", nullResult);
    }

    @Test
    void testGetParmDataByKeyByCmodbaseWithNullKey() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null key
        String nullResult = imageParmDataService.getParmDataByKeyByCmodbase(null, "DEFAULT");
        assertEquals("DEFAULT", nullResult);
    }

    @Test
    void testGetParmDataByKeyByCODBaseWithNullKey() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null key
        String nullResult = imageParmDataService.getParmDataByKeyByCODBase(null, "DEFAULT");
        assertEquals("DEFAULT", nullResult);
    }

    @Test
    void testGetParmKeyByParmDataByCmodfldWithNullValue() {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test with null value
        String nullResult = imageParmDataService.getParmKeyByParmDataByCmodfld(null, "DEFAULT");
        assertEquals("DEFAULT", nullResult);
    }

    @Test
    void testConcurrentAccess() throws InterruptedException {
        // Initialize service
        imageParmDataService.refreshParmData();

        // Test concurrent access to parameter data
        List<Thread> threads = new ArrayList<>();
        List<String> results = Collections.synchronizedList(new ArrayList<>());

        // Create multiple threads accessing the service simultaneously
        for (int i = 0; i < 10; i++) {
            Thread thread = new Thread(() -> {
                String result = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
                results.add(result);
            });
            threads.add(thread);
            thread.start();
        }

        // Wait for all threads to complete
        for (Thread thread : threads) {
            thread.join();
        }

        // Verify all threads got the correct result
        assertEquals(10, results.size());
        for (String result : results) {
            assertEquals("TEST_VALUE_1", result);
        }
    }

    @Test
    void testCacheEvictionOnRefresh() {
        // Initialize service first time
        imageParmDataService.refreshParmData();

        // Get a value
        String firstResult = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
        assertEquals("TEST_VALUE_1", firstResult);

        // Update test data
        Map<String, String> updatedHvwbaseData = new HashMap<>();
        updatedHvwbaseData.put("TEST_KEY_1", "UPDATED_VALUE_1");
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(updatedHvwbaseData);

        // Refresh data
        imageParmDataService.refreshParmData();

        // Verify cache was evicted and new value is returned
        String updatedResult = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
        assertEquals("UPDATED_VALUE_1", updatedResult);
    }

    @Test
    void testODCMODFieldMappingWithFolderSpaceReplacement() {
        // Create test data for ODCMOD field mapping
        Map<String, Map<String, String>> testODCMODMap = new HashMap<>();
        Map<String, String> fieldMap = new HashMap<>();
        fieldMap.put("TEST_FOLDER", "FOLDER_VALUE");
        fieldMap.put("TEST_FOLDER_WITH_SPACES", "SPACED_VALUE");
        fieldMap.put("OD_STANDARD_FIELD", "STANDARD_VALUE");
        testODCMODMap.put("TEST_FIELD", fieldMap);

        // Use reflection to set the private field for testing
        try {
            java.lang.reflect.Field field = ImageParmDataServiceImpl.class.getDeclaredField("parmDataMapByODCMODFieldMap");
            field.setAccessible(true);
            field.set(imageParmDataService, testODCMODMap);
        } catch (Exception e) {
            fail("Failed to set test data via reflection: " + e.getMessage());
        }

        // Test folder name with spaces (should be replaced with underscores)
        String result = imageParmDataService.getParmKeyByParmDataByODCMODField("TEST_FIELD", "TEST FOLDER WITH SPACES", "DEFAULT");
        assertEquals("SPACED_VALUE", result);

        // Test exact folder name match
        String exactResult = imageParmDataService.getParmKeyByParmDataByODCMODField("TEST_FIELD", "TEST_FOLDER", "DEFAULT");
        assertEquals("FOLDER_VALUE", exactResult);

        // Test fallback to standard field when folder not found
        String fallbackResult = imageParmDataService.getParmKeyByParmDataByODCMODField("TEST_FIELD", "NON_EXISTING_FOLDER", "DEFAULT");
        assertEquals("STANDARD_VALUE", fallbackResult);

        // Test with null folder name (should fallback to standard field)
        String nullFolderResult = imageParmDataService.getParmKeyByParmDataByODCMODField("TEST_FIELD", null, "DEFAULT");
        assertEquals("STANDARD_VALUE", nullFolderResult);

        // Test with empty folder name (should fallback to standard field)
        String emptyFolderResult = imageParmDataService.getParmKeyByParmDataByODCMODField("TEST_FIELD", "", "DEFAULT");
        assertEquals("STANDARD_VALUE", emptyFolderResult);
    }

    @Test
    void testDataIntegrityAfterMultipleRefreshes() {
        // Initial refresh
        imageParmDataService.refreshParmData();
        
        String initialValue = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
        assertEquals("TEST_VALUE_1", initialValue);

        // Multiple refreshes
        for (int i = 0; i < 5; i++) {
            imageParmDataService.refreshParmData();
        }

        // Verify data integrity is maintained
        String finalValue = imageParmDataService.getParmDataByKeyByHvwbase("TEST_KEY_1", "DEFAULT");
        assertEquals("TEST_VALUE_1", finalValue);

        // Verify repository was called multiple times
        verify(t222APRMRepository, atLeast(5)).getParmDataAsMap(HVWConstants.HVWBASE);
    }

    @Test
    void testEmptyParameterMaps() {
        // Mock repository to return empty maps
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMBASE)).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CODBASE)).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.CMFLDMAP)).thenReturn(new HashMap<>());
        when(t222APRMRepository.getParmDataMapsGroupedByParmId(anyList())).thenReturn(new HashMap<>());
        
        try {
            when(vCodReportSecurityExitService.getCmodIndexBpdIdByCmodApplication()).thenReturn(new HashMap<>());
        } catch (Exception e) {
            // Handle SQLException in test
        }

        // This should not throw an exception
        assertDoesNotThrow(() -> imageParmDataService.refreshParmData());

        // Verify that empty maps are handled gracefully
        String result = imageParmDataService.getParmDataByKeyByHvwbase("ANY_KEY", "DEFAULT");
        assertEquals("DEFAULT", result);
    }

    @Test
    void testNullHandlingInRefresh() {
        // Test that the service properly throws exception when repository returns null
        // Clear any previous lenient stubbing to avoid conflicts
        reset(t222APRMRepository);
        
        // Mock repository to return null for HVWBASE - this should cause an exception
        when(t222APRMRepository.getParmDataAsMap(HVWConstants.HVWBASE)).thenReturn(null);

        // This should throw an exception as the current implementation doesn't handle null maps
        assertThrows(RuntimeException.class, () -> imageParmDataService.refreshParmData());
    }
}