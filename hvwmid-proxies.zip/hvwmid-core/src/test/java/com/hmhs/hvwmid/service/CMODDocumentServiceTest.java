package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.exceptions.HVWException;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CMODDocumentServiceTest {

    private final CMODDocumentService service = new CMODDocumentService();

    @Test
    void prepareBasePayload_shouldReturnMapWithCorrectValues() {
        String docToken = "token123";
        String folder = "folderABC";

        Map<String, Object> payload = service.prepareBasePayload(docToken, folder);

        assertEquals(2, payload.size());
        assertEquals("token123", payload.get("documentToken"));
        assertEquals("folderABC", payload.get("odFolder"));
    }

    @Test
    void validateDocumentToken_shouldPassWhenValid() {
        assertDoesNotThrow(() -> service.validateDocumentToken("validToken"));
    }

    @Test
    void validateDocumentToken_shouldThrowExceptionWhenNull() {
        HVWException ex = assertThrows(HVWException.class, () -> service.validateDocumentToken(null));
        assertEquals("Document token cannot be null or empty", ex.getMessage());
    }

    @Test
    void validateDocumentToken_shouldThrowExceptionWhenEmpty() {
        HVWException ex = assertThrows(HVWException.class, () -> service.validateDocumentToken("   "));
        assertEquals("Document token cannot be null or empty", ex.getMessage());
    }

    @Test
    void validateFolder_shouldPassWhenValid() {
        assertDoesNotThrow(() -> service.validateFolder("folderName"));
    }

    @Test
    void validateFolder_shouldThrowExceptionWhenNull() {
        HVWException ex = assertThrows(HVWException.class, () -> service.validateFolder(null));
        assertEquals("Folder cannot be null or empty", ex.getMessage());
    }

    @Test
    void validateFolder_shouldThrowExceptionWhenEmpty() {
        HVWException ex = assertThrows(HVWException.class, () -> service.validateFolder(" "));
        assertEquals("Folder cannot be null or empty", ex.getMessage());
    }
}
