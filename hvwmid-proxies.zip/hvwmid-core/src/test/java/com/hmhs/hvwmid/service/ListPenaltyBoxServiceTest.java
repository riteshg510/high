package com.hmhs.hvwmid.service;

import com.hmhs.hvwmid.utils.RestClientUtil;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(SpringExtension.class)
class ListPenaltyBoxServiceTest {
    @InjectMocks
    private ListPenaltyBoxService listPenaltyBoxService;

    @Mock
    private RestClientUtil restClientUtil;

    private static final String BPDID_FIELD = "bpdid";

    @Test
    void testFilterReturnsExpectedResult() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> imageIndexValueListing = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> values = new ArrayList<>();

        Map<String, Object> value1 = new HashMap<>();
        value1.put("userID", "user456");
        value1.put("endTime", "2025-08-21T16:30:00Z");
        value1.put("startTime", "2025-08-21T16:00:00Z");
        value1.put("description", "Late submission:: user456.s");

        Map<String, Object> value2 = new HashMap<>();
        value2.put("userID", "user789");
        value2.put("endTime", "2025-08-21T17:00:00Z");
        value2.put("startTime", "2025-08-21T16:15:00Z");
        value2.put("description", "Unauthorized access");

        values.add(value1);
        values.add(value2);

        results.put("row", values);
        imageIndexValueListing.put("results", results);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(imageIndexValueListing, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listPenaltyBoxService.getAll(otherFields, "token");

        List<Map> expected = new ArrayList<>();
        Map<String, String> expectedEntry = new HashMap<>();
        expectedEntry.put("audit", "user456.s");
        expectedEntry.put("description", "Late submission");
        expectedEntry.put("startTime", "2025-08-21T16:00:00Z");
        expectedEntry.put("endTime", "2025-08-21T16:30:00Z");
        expectedEntry.put("userId", "user456");
        expected.add(expectedEntry);
        expectedEntry = new HashMap<>();
        expectedEntry.put("audit", "");
        expectedEntry.put("description", "Unauthorized access");
        expectedEntry.put("startTime", "2025-08-21T16:15:00Z");
        expectedEntry.put("endTime", "2025-08-21T17:00:00Z");
        expectedEntry.put("userId", "user789");
        expected.add(expectedEntry);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
    }

    @Test
    void testFilterWithEmptyResponse() {
        Map<String, String> otherFields = new HashMap<>();
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listPenaltyBoxService.getAll(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }

    @Test
    void testFilterDoesNotHaveAllProperties() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("bpdid", "123");

        // Mock response structure
        Map<String, Object> responseMap = new HashMap<>();
        Map<String, Object> imagePenaltyBox = new HashMap<>();
        Map<String, Object> segmentData = new HashMap<>();
        Map<String, Object> results = new HashMap<>();
        List<Map<String, Object>> values = new ArrayList<>();

        results.put("row", values);
        segmentData.put("results", results);
        imagePenaltyBox.put("segmentData", segmentData);
        responseMap.put("imagePenaltyBoxListing", imagePenaltyBox);

        ResponseEntity<Map> mockResponse = new ResponseEntity<>(responseMap, HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        //no Applidcd
        ResponseEntity<Object> result = listPenaltyBoxService.getAll(otherFields, "token");

        List<Map> expected = new ArrayList<>();

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());


        //No Results
        results.clear();
        result = listPenaltyBoxService.add(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No Results
        segmentData.clear();
        result = listPenaltyBoxService.delete(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No penaltybox
        imagePenaltyBox.clear();
        result = listPenaltyBoxService.extend(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());
        //No nothing
        responseMap.clear();
        result = listPenaltyBoxService.reset(otherFields, "token");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expected, result.getBody());

    }

    @Test
    void testFilterGenerateDifferentExtraHeaders() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put(BPDID_FIELD, "   "); // blank value
        ResponseEntity<Map> mockResponse = new ResponseEntity<>(new HashMap<>(), HttpStatus.OK);

        Mockito.when(restClientUtil.postRequest(anyString(), anyString(), anyMap(), anyMap()))
                .thenReturn(mockResponse);

        ResponseEntity<Object> result = listPenaltyBoxService.getAll(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());

        otherFields.put(BPDID_FIELD, "abc"); // not blank value
        result = listPenaltyBoxService.getAll(otherFields, "token");

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(Collections.emptyList(), result.getBody());
    }
}