package com.hmhs.hvwmid.entity;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TblPickListItemsTest {

    @Test
    void testIdSetterAndGetter() {
        TblPickListItems item = new TblPickListItems();
        item.setId(123L);
        assertEquals(123L, item.getId());
    }

    @Test
    void testDependentKeySetterAndGetter() {
        TblPickListItems item = new TblPickListItems();
        item.setDependentKey("dependent_value");
        assertEquals("dependent_value", item.getDependentKey());
    }

    @Test
    void testDisplayNameSetterAndGetter() {
        TblPickListItems item = new TblPickListItems();
        item.setDisplayName("Display Name");
        assertEquals("Display Name", item.getDisplayName());
    }

    @Test
    void testKeySetterAndGetter() {
        TblPickListItems item = new TblPickListItems();
        item.setKey("key_value");
        assertEquals("key_value", item.getKey());
    }

    @Test
    void testPickListIdSetterAndGetter() {
        TblPickListItems item = new TblPickListItems();
        item.setPickListId("PL123456");
        assertEquals("PL123456", item.getPickListId());
    }
}
