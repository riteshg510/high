package com.hmhs.hvwmid;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class MainModuleTests {
    @Test
    void test() {
        Assertions.assertTrue(true);
    }
    @Test
    void test2() {
        Assertions.assertTrue(true);
    }
}
