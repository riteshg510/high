package com.hmhs.hvwmid.validations;

import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ActiveTypeValidatorTest {
    private final ActiveTypeValidator validator = new ActiveTypeValidator();
    private final ConstraintValidatorContext context = null;

    @Test
    void testValidActiveTypes() {
        assertTrue(validator.isValid("Y", context));
        assertTrue(validator.isValid("N", context));
    }

    @Test
    void testInvalidActiveType() {
        assertFalse(validator.isValid("A", context));
        assertFalse(validator.isValid("y", context));
        assertFalse(validator.isValid("n", context));
        assertFalse(validator.isValid("", context));
    }

    @Test
    void testNullValue() {
        assertTrue(validator.isValid(null, context));
    }
}

// Annotation usage test (mock)
class ValidActiveTypeUsageTest {
    @ValidActiveType
    String activeType;

    @Test
    void testAnnotationPresent() throws NoSuchFieldException {
        assertNotNull(this.getClass().getDeclaredField("activeType").getAnnotation(ValidActiveType.class));
    }
}
