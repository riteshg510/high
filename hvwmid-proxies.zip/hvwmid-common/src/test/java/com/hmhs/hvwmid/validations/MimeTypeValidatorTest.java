package com.hmhs.hvwmid.validations;

import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MimeTypeValidatorTest {
    private final MimeTypeValidator validator = new MimeTypeValidator();
    private final ConstraintValidatorContext context = null; // Not used in isValid

    @Test
    void testValidMimeTypes() {
        assertTrue(validator.isValid("application/pdf", context));
        assertTrue(validator.isValid("text/html", context));
        assertTrue(validator.isValid("application/x-javascript", context));
    }

    @Test
    void testInvalidMimeType() {
        assertFalse(validator.isValid("image/png", context));
        assertFalse(validator.isValid("application/json", context));
    }

    @Test
    void testNullValue() {
        assertTrue(validator.isValid(null, context));
    }
}

// Annotation usage test (mock)
class ValidMimeTypeUsageTest {
    @ValidMimeType
    String mimeType;

    @Test
    void testAnnotationPresent() throws NoSuchFieldException {
        assertNotNull(this.getClass().getDeclaredField("mimeType").getAnnotation(ValidMimeType.class));
    }
}
