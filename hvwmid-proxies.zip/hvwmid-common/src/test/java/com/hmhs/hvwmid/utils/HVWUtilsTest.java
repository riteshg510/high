package com.hmhs.hvwmid.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

class HVWUtilsTest {

	private static final String NOSERVICE_ENV = "Noservice";

	@BeforeEach
	void resetEnvironment() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("default");
	}

	@Test
	void testHasText() {
		assertTrue(HVWUtils.hasText("something"));
		assertFalse(HVWUtils.hasText(""));
		assertFalse(HVWUtils.hasText("   "));
		assertFalse(HVWUtils.hasText(null));
	}

	@Test
	void testStringToInt() {
		assertEquals(10, HVWUtils.stringToInt("10", 0));
		assertEquals(-1, HVWUtils.stringToInt("notanumber", -1));
		assertEquals(0, HVWUtils.stringToInt(null, 0));
	}

	@Test
	void testRemoveBearer() {
		assertEquals("token", HVWUtils.removeBearer("Bearer token"));
		assertEquals("tokenX", HVWUtils.removeBearer("Bearer tokenX"));
		assertNull(HVWUtils.removeBearer(null));
		assertEquals("", HVWUtils.removeBearer(""));
	}

	@Test
	void testGetUserIdFromJWT_NoserviceNullToken() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Noservice");

		String userId = HVWUtils.getUserIdFromJWT(null);
		assertEquals("liduser", userId);
	}

	@Test
	void testGetUserIdFromJWT_NoserviceEmptyToken() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Noservice");

		String userId = HVWUtils.getUserIdFromJWT("");
		assertEquals("liduser", userId);
	}

	@Test
	void testGetUserIdFromJWT_ExpiredToken() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("prod");

		String fakeToken = "fake.token.here";

		String userId = HVWUtils.getUserIdFromJWT(fakeToken);
		assertEquals("", userId);
	}

	@Test
	void testGetUserIdFromJWT_ValidUidClaim() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("prod");

		assertEquals("", HVWUtils.getUserIdFromJWT(null));
	}

	@Test
	void testGetCollection_ValidEnvironment() {
		assertEquals("TST1", HVWUtils.getCollection("TENV1"));
		assertEquals("PBS", HVWUtils.getCollection("PENV"));
	}

	@Test
	void testGetCollection_InvalidEnvironment() {
		assertEquals("PBS", HVWUtils.getCollection("UNKNOWN"));
		assertEquals("PBS", HVWUtils.getCollection(null));
	}

	@Test
	void testGetDevGroupsList() {
		List<String> groups = HVWUtils.getDevGroupsList();

		assertNotNull(groups, "The groups list should not be null");

		assertFalse(groups.isEmpty(), "The groups list should not be empty");

		// Instead of hardcoding, compare with the actual list returned by the method
		List<String> expected = HVWUtils.getDevGroupsList();
		assertEquals(expected, groups, "The groups list should exactly match the expected list");
	}

	@Test
	void testGetUserGroups_NoserviceEnv_ReturnsDevGroups() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Noservice");
		List<String> groups = HVWUtils.getUserGroups("anyToken");
		assertEquals(HVWUtils.getDevGroupsList(), groups);
	}

	@Test
	void testgetUserGroupsValidTokenReturnsGroups() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token.here";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token.here")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);

			// Simulate the raw string from the token
			String rawGroupString = "Group1, Group2, Group3";
			when(claim.asString()).thenReturn(rawGroupString);

			List<String> expectedGroups = List.of("Group1", "Group2", "Group3");
			List<String> actualGroups = HVWUtils.getUserGroups(token);

			assertEquals(expectedGroups, actualGroups);
		}
	}

	@Test
	void testgetUserGroups_ExpiredToken_ReturnsEmptyList() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer expired.token";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Calendar pastDate = Calendar.getInstance();
			pastDate.add(Calendar.HOUR, -1); // 1 hour ago

			jwtMock.when(() -> JWT.decode("expired.token")).thenReturn(decodedJWT);
			when(decodedJWT.getExpiresAt()).thenReturn(pastDate.getTime());

			List<String> groups = HVWUtils.getUserGroups(token);
			assertTrue(groups.isEmpty());
		}
	}

	@Test
	void testgetUserGroups_NullOrEmptyToken_ReturnsEmptyList() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		assertTrue(HVWUtils.getUserGroups(null).isEmpty());
		assertTrue(HVWUtils.getUserGroups("").isEmpty());
	}

	@Test
	void testHasPhiAccess_ValidGroup_ReturnsTrue() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";
		String groupName = "IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT,OTHER-GROUP");

			boolean result = HVWUtils.hasPhiAccess(token, groupName);
			assertTrue(result);
		}
	}

	@Test
	void testHasPhiAccess_InvalidGroup_ReturnsFalse() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";
		String groupName = "NON-EXISTENT-GROUP";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT,OTHER-GROUP");

			boolean result = HVWUtils.hasPhiAccess(token, groupName);
			assertFalse(result);
		}
	}

	@Test
	void testHasPhiAccess_CommaSeparatedGroups_AnyMatchReturnsTrue() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";
		String groupNames = "NON-EXISTENT-GROUP, IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT, ANOTHER-GROUP";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT,OTHER-GROUP");

			boolean result = HVWUtils.hasPhiAccess(token, groupNames);
			assertTrue(result);
		}
	}

	@Test
	void testHasPhiAccess_CommaSeparatedGroups_NoMatchReturnsFalse() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";
		String groupNames = "GROUP_A, GROUP_B, GROUP_C";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("IMI-ACTIVITYTRKSECURE-BCBSMN-30701-INT,OTHER-GROUP");

			boolean result = HVWUtils.hasPhiAccess(token, groupNames);
			assertFalse(result);
		}
	}

	@Test
	void testHasPhiAccess_NullOrEmptyInputs_ReturnsFalse() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		assertFalse(HVWUtils.hasPhiAccess(null, "GROUP"));
		assertFalse(HVWUtils.hasPhiAccess("", "GROUP"));
		assertFalse(HVWUtils.hasPhiAccess("token", null));
		assertFalse(HVWUtils.hasPhiAccess("token", ""));
	}

	@Test
	void testHasPhiAccess_NoGroups_ReturnsFalse() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";
		String groupName = "SOME-GROUP";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("");

			boolean result = HVWUtils.hasPhiAccess(token, groupName);
			assertFalse(result);
		}
	}

	@Test
	void testBuildNAICMap_ValidGroups_ReturnsCorrectMap() {
		List<String> userGroups = List.of("IMI-ACTIVITYTRK-BCBSMN-30701-INT", "IMI-ACTIVITYTRK-HMRK-54771-INT",
				"OTHER-GROUP");

		Map<String, String> result = HVWUtils.buildNAICMap(userGroups);

		assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals("30701", result.get("BCBSMN"));
		assertEquals("54771", result.get("HMRK"));
		assertFalse(result.containsKey("OTHER"));
	}

	@Test
	void testBuildNAICMap_InvalidGroupFormat_ReturnsEmptyMap() {
		List<String> userGroups = List.of("IMI-ACTIVITYTRK-INVALID-FORMAT", "OTHER-GROUP");

		Map<String, String> result = HVWUtils.buildNAICMap(userGroups);

		assertNotNull(result);
		assertTrue(result.isEmpty());
	}

	@Test
	void testBuildNAICMap_NullOrEmptyInput_ReturnsEmptyMap() {
		Map<String, String> result1 = HVWUtils.buildNAICMap(null);
		Map<String, String> result2 = HVWUtils.buildNAICMap(new ArrayList<>());

		assertNotNull(result1);
		assertNotNull(result2);
		assertTrue(result1.isEmpty());
		assertTrue(result2.isEmpty());
	}

	@Test
	void testBuildNAICMap_UpdateGroup_ExcludedFromMap() {
		List<String> userGroups = List.of("IMI-ACTIVITYTRK-UPDATE-INT", "IMI-ACTIVITYTRK-BCBSMN-30701-INT");

		Map<String, String> result = HVWUtils.buildNAICMap(userGroups);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals("30701", result.get("BCBSMN"));
	}

	@Test
	void testExtractBpdIds_ValidRmaGroups_ReturnsBpdIdsMap() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment(NOSERVICE_ENV);

		// In Noservice environment, getUserGroups returns dev groups list
		// The dev groups list contains "RMA-HMRK-IMAGE-PA-1-INT" which has 6 parts:
		// RMA, HMRK, IMAGE, PA, 1, INT - so BPD ID should be "1" and clientDesc should be "HMRK-PA"
		String token = "Bearer valid.token";

		Map<String, String> result = HVWUtils.extractBpdIds(token);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertTrue(result.containsKey("1")); // BPD ID from "RMA-HMRK-IMAGE-PA-1-INT"
		assertEquals("HMRK-PA", result.get("1")); // Client description: clientName-state
	}

	@Test
	void testExtractBpdIds_InvalidRmaGroupFormat_ReturnsEmptyMap() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("RMA-INVALID-FORMAT,OTHER-GROUP");

			Map<String, String> result = HVWUtils.extractBpdIds(token);

			assertNotNull(result);
			assertTrue(result.isEmpty());
		}
	}

	@Test
	void testExtractBpdIds_NoRmaGroups_ReturnsEmptyMap() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("OTHER-GROUP,ANOTHER-GROUP");

			Map<String, String> result = HVWUtils.extractBpdIds(token);

			assertNotNull(result);
			assertTrue(result.isEmpty());
		}
	}

	@Test
	void testExtractBpdIds_MultipleValidRmaGroups_ReturnsCorrectMap() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("RMA-BCBS-IMAGE-ND-12345-INT,RMA-IBC-IMAGE-PA-67890-INT,OTHER-GROUP");

			Map<String, String> result = HVWUtils.extractBpdIds(token);

			assertNotNull(result);
			assertEquals(2, result.size());
			assertTrue(result.containsKey("12345"));
			assertEquals("BCBS-ND", result.get("12345"));
			assertTrue(result.containsKey("67890"));
			assertEquals("IBC-PA", result.get("67890"));
		}
	}

	@Test
	void testExtractBpdIds_DuplicateBpdIds_OnlyKeepsFirst() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer valid.token";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			DecodedJWT decodedJWT = mock(DecodedJWT.class);
			Claim claim = mock(Claim.class);

			jwtMock.when(() -> JWT.decode("valid.token")).thenReturn(decodedJWT);
			when(decodedJWT.getClaim("ismemberof")).thenReturn(claim);
			when(claim.asString()).thenReturn("RMA-BCBS-IMAGE-ND-12345-INT,RMA-HMRK-IMAGE-MA-12345-INT");

			Map<String, String> result = HVWUtils.extractBpdIds(token);

			assertNotNull(result);
			assertEquals(1, result.size());
			assertTrue(result.containsKey("12345"));
			assertEquals("BCBS-ND", result.get("12345")); // First occurrence should be kept
		}
	}

	@Test
	void testExtractBpdIds_NullOrEmptyToken_ReturnsEmptyMap() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		Map<String, String> result1 = HVWUtils.extractBpdIds(null);
		Map<String, String> result2 = HVWUtils.extractBpdIds("");

		assertNotNull(result1);
		assertNotNull(result2);
		assertTrue(result1.isEmpty());
		assertTrue(result2.isEmpty());
	}

	@Test
	void testGetUserGroups_DecodeThrowsException_ReturnsEmptyList() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("Prod");

		String token = "Bearer invalid.token";

		try (MockedStatic<JWT> jwtMock = Mockito.mockStatic(JWT.class)) {
			jwtMock.when(() -> JWT.decode("invalid.token")).thenThrow(new RuntimeException("Invalid token"));

			List<String> groups = HVWUtils.getUserGroups(token);
			assertTrue(groups.isEmpty());
		}
	}

	@Test
	void testConvertTransmitFileStatusCd_ValidCodes_ReturnsDescriptions() {
		assertEquals("Accepted", HVWUtils.convertTransmitFileStatusCd("A"));
		assertEquals("Rejected", HVWUtils.convertTransmitFileStatusCd("R"));
		assertEquals("Completed", HVWUtils.convertTransmitFileStatusCd("C"));
	}

	@Test
	void testConvertTransmitFileStatusCd_InvalidCode_ReturnsOriginalCode() {
		assertEquals("X", HVWUtils.convertTransmitFileStatusCd("X"));
		assertEquals("INVALID", HVWUtils.convertTransmitFileStatusCd("INVALID"));
	}

	@Test
	void testConvertTransmitFileStatusCd_NullOrEmpty_ReturnsOriginal() {
		assertNull(HVWUtils.convertTransmitFileStatusCd(null));
		assertEquals("", HVWUtils.convertTransmitFileStatusCd(""));
	}

	@Test
	void testConvertProcessFileStatusCd_ValidCodes_ReturnsDescriptions() {
		assertEquals("Validation (Ready for)", HVWUtils.convertProcessFileStatusCd("V"));
		assertEquals("Acknowledge (Ready for)", HVWUtils.convertProcessFileStatusCd("K"));
		assertEquals("Transformation (Ready for)", HVWUtils.convertProcessFileStatusCd("T"));
		assertEquals("Finalization (Ready for)", HVWUtils.convertProcessFileStatusCd("F"));
		assertEquals("Error", HVWUtils.convertProcessFileStatusCd("E"));
		assertEquals("Completed", HVWUtils.convertProcessFileStatusCd("C"));
	}

	@Test
	void testConvertProcessFileStatusCd_InvalidCode_ReturnsOriginalCode() {
		assertEquals("X", HVWUtils.convertProcessFileStatusCd("X"));
		assertEquals("INVALID", HVWUtils.convertProcessFileStatusCd("INVALID"));
	}

	@Test
	void testConvertDocumentStatusCd_ValidCodes_ReturnsDescriptions() {
		assertEquals("Accepted", HVWUtils.convertDocumentStatusCd("A"));
		assertEquals("Batch Capture (Ready for)", HVWUtils.convertDocumentStatusCd("X"));
		assertEquals("Image Store (Ready for)", HVWUtils.convertDocumentStatusCd("I"));
		assertEquals("Non-claim OCR (Ready for)", HVWUtils.convertDocumentStatusCd("L"));
		assertEquals("CMOD (Ready for)", HVWUtils.convertDocumentStatusCd("P"));
		assertEquals("Claim OCR (Ready for)", HVWUtils.convertDocumentStatusCd("O"));
		assertEquals("Claim OCR Completed", HVWUtils.convertDocumentStatusCd("J"));
		assertEquals("Stored", HVWUtils.convertDocumentStatusCd("S"));
		assertEquals("CMOD Stored", HVWUtils.convertDocumentStatusCd("M"));
		assertEquals("Original Completed", HVWUtils.convertDocumentStatusCd("Y"));
		assertEquals("Finalization (Ready for)", HVWUtils.convertDocumentStatusCd("F"));
		assertEquals("Error", HVWUtils.convertDocumentStatusCd("E"));
		assertEquals("Rejected", HVWUtils.convertDocumentStatusCd("R"));
	}

	@Test
	void testConvertDocumentStatusCd_InvalidCode_ReturnsOriginalCode() {
		assertEquals("Z", HVWUtils.convertDocumentStatusCd("Z"));
		assertEquals("INVALID", HVWUtils.convertDocumentStatusCd("INVALID"));
	}

	@Test
	void testGetHostname_ValidEnvironment_ReturnsHostname() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("TENV1");

		// This test assumes IMIHostName enum has TENV1 defined
		// If not, it will return DEFAULT_HOSTNAME
		String result = HVWUtils.getHostname();
		assertNotNull(result);
	}

	@Test
	void testGetHostname_InvalidEnvironment_ReturnsDefaultHostname() {
		HVWUtils hvwUtils = new HVWUtils();
		hvwUtils.setEnvironment("INVALID_ENV");

		String result = HVWUtils.getHostname();
		assertEquals("HOSTNAME", result);
	}

	@Test
	void testConcatenateStrings_ValidInputs_ReturnsConcatenatedString() {
		String result = HVWUtils.concatenateStrings("Hello", " ", "World", "!");
		assertEquals("Hello World!", result);
	}

	@Test
	void testConcatenateStrings_EmptyInputs_ReturnsEmptyString() {
		String result = HVWUtils.concatenateStrings();
		assertEquals("", result);
	}

	@Test
	void testConcatenateStrings_NullInputs_ReturnsConcatenatedString() {
		String result = HVWUtils.concatenateStrings("Hello", null, "World");
		assertEquals("HellonullWorld", result);
	}

	@Test
	void testCreateMfTimeStamp_ReturnsValidTimestamp() {
		String timestamp = HVWUtils.createMfTimeStamp();

		assertNotNull(timestamp);
		assertEquals(17, timestamp.length()); // yyyyMMddHHmmssSSS format
		assertTrue(timestamp.matches("\\d{17}")); // All digits
	}

	@Test
	void testGetDescription_ValidEnumClass_ReturnsDescription() {
		String result = HVWUtils.getDescription(HVWUtils.TransmitFileStatusCd.class, "A");
		assertEquals("Accepted", result);
	}

	@Test
	void testGetDescription_InvalidValue_ReturnsInvalidMessage() {
		String result = HVWUtils.getDescription(HVWUtils.TransmitFileStatusCd.class, "INVALID");
		assertEquals("Invalid value for TransmitFileStatusCd", result);
	}

}
