package com.hmhs.hvwmid.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class InterchangeFileTest {

    @TempDir
    Path tempDir;

    private String testFilePath;
    private String testBinaryFilePath;

    @BeforeEach
    void setUp() {
        testFilePath = tempDir.resolve("test.imi").toString();
        testBinaryFilePath = tempDir.resolve("testBinary.imi").toString();
    }

    @Test
    void testConstructorWithFilePath() throws IOException {
        // Act & Assert - Should not throw exception
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath)) {
            assertNotNull(imiFile);
            assertTrue(imiFile.isUseBinaryFormat()); // Default should be binary
        }
    }

    @Test
    void testConstructorWithBinaryFormat() throws IOException {
        // Act & Assert
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath, true)) {
            assertNotNull(imiFile);
            assertTrue(imiFile.isUseBinaryFormat());
        }
    }

    @Test
    void testConstructorWithTextFormat() throws IOException {
        // Act & Assert
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath, false)) {
            assertNotNull(imiFile);
            assertFalse(imiFile.isUseBinaryFormat());
        }
    }

    @Test
    void testGetFilePath() throws IOException {
        // Act
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath)) {
            // Assert
            assertEquals(testFilePath, imiFile.getFilePath());
        }
    }

    @Test
    void testWriteSegmentTextFormat() throws IOException {
        // Arrange
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath, false)) {
            // Act
            imiFile.writeSegment("HDR", "12345");
            imiFile.writeSegment("FID", "test-file-id");
            imiFile.writeSegment("IMG", "image-data");
        }
        
        // Assert
        String content = Files.readString(Path.of(testFilePath), StandardCharsets.UTF_8);
        String[] lines = content.split("\n");
        
        assertEquals("HDR|12345", lines[0]);
        assertEquals("FID|test-file-id", lines[1]);
        assertEquals("IMG|image-data", lines[2]);
    }

    @Test
    void testWriteSegmentTextFormatWithNullValue() throws IOException {
        // Arrange
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath, false)) {
            // Act
            imiFile.writeSegment("HDR", null);
        }
        
        // Assert
        String content = Files.readString(Path.of(testFilePath), StandardCharsets.UTF_8);
        assertEquals("HDR|", content.trim());
    }

    @Test
    void testWriteSegmentBinaryFormat() throws IOException {
        // Arrange
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeSegment("HDR", "12345");
            imiFile.writeSegment("FID", "test-file-id");
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        assertTrue(content.length > 0);
        
        // Verify binary format structure for first segment (HDR)
        // 4 bytes length + 3 bytes segment ID + data
        int expectedLength1 = 7 + "12345".length();
        assertEquals(expectedLength1, 
            ((content[0] & 0xFF) << 24) | ((content[1] & 0xFF) << 16) | 
            ((content[2] & 0xFF) << 8) | (content[3] & 0xFF));
        
        // Verify segment ID
        assertEquals("HDR", new String(content, 4, 3, StandardCharsets.US_ASCII));
        
        // Verify data
        assertEquals("12345", new String(content, 7, 5, StandardCharsets.UTF_8));
    }

    @Test
    void testWriteBinarySegment() throws IOException {
        // Arrange
        byte[] testData = "Binary test data".getBytes(StandardCharsets.UTF_8);
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeBinarySegment("IMG", testData);
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        
        // Verify length (4 bytes)
        int expectedLength = 7 + testData.length;
        int actualLength = ((content[0] & 0xFF) << 24) | ((content[1] & 0xFF) << 16) | 
                          ((content[2] & 0xFF) << 8) | (content[3] & 0xFF);
        assertEquals(expectedLength, actualLength);
        
        // Verify segment ID (3 bytes)
        assertEquals("IMG", new String(content, 4, 3, StandardCharsets.US_ASCII));
        
        // Verify data
        byte[] actualData = new byte[testData.length];
        System.arraycopy(content, 7, actualData, 0, testData.length);
        assertArrayEquals(testData, actualData);
    }

    @Test
    void testWriteBinarySegmentWithNullData() throws IOException {
        // Arrange
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeBinarySegment("IMG", null);
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        
        // Length should be 7 (header only, no data)
        int actualLength = ((content[0] & 0xFF) << 24) | ((content[1] & 0xFF) << 16) | 
                          ((content[2] & 0xFF) << 8) | (content[3] & 0xFF);
        assertEquals(7, actualLength);
        assertEquals(7, content.length);
    }

    @Test
    void testWriteBinarySegmentInvalidSegmentType() throws IOException {
        // Arrange
        byte[] testData = "test".getBytes();
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act & Assert - Invalid segment type (not 3 characters)
            assertThrows(IllegalArgumentException.class, () -> {
                imiFile.writeBinarySegment("TOOLONG", testData);
            });
            
            assertThrows(IllegalArgumentException.class, () -> {
                imiFile.writeBinarySegment("AB", testData);
            });
            
            assertThrows(IllegalArgumentException.class, () -> {
                imiFile.writeBinarySegment(null, testData);
            });
        }
    }

    @Test
    void testWriteBinarySegmentInTextMode() throws IOException {
        // Arrange
        byte[] testData = "test".getBytes();
        
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath, false)) {
            // Act & Assert
            assertThrows(IllegalStateException.class, () -> {
                imiFile.writeBinarySegment("IMG", testData);
            });
        }
    }

    @Test
    void testWriteFileSegmentWithFile() throws IOException {
        // Arrange
        Path sourceFile = tempDir.resolve("source.txt");
        String fileContent = "This is test file content for embedding";
        Files.writeString(sourceFile, fileContent, StandardCharsets.UTF_8);
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeFileSegment("IMG", sourceFile.toFile());
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        
        // Verify segment structure
        byte[] expectedData = fileContent.getBytes(StandardCharsets.UTF_8);
        int expectedLength = 7 + expectedData.length;
        int actualLength = ((content[0] & 0xFF) << 24) | ((content[1] & 0xFF) << 16) | 
                          ((content[2] & 0xFF) << 8) | (content[3] & 0xFF);
        assertEquals(expectedLength, actualLength);
        
        // Verify segment ID
        assertEquals("IMG", new String(content, 4, 3, StandardCharsets.US_ASCII));
        
        // Verify embedded file content
        byte[] actualData = new byte[expectedData.length];
        System.arraycopy(content, 7, actualData, 0, expectedData.length);
        assertArrayEquals(expectedData, actualData);
    }

    @Test
    void testWriteFileSegmentWithNonExistentFile() throws IOException {
        // Arrange
        File nonExistentFile = new File(tempDir.resolve("nonexistent.txt").toString());
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act & Assert
            assertThrows(FileNotFoundException.class, () -> {
                imiFile.writeFileSegment("IMG", nonExistentFile);
            });
        }
    }

    @Test
    void testWriteFileSegmentWithInputStream() throws IOException {
        // Arrange
        String fileContent = "Stream content for testing";
        byte[] contentBytes = fileContent.getBytes(StandardCharsets.UTF_8);
        ByteArrayInputStream inputStream = new ByteArrayInputStream(contentBytes);
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeFileSegment("IMG", inputStream, contentBytes.length);
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        
        // Verify segment structure
        int expectedLength = 7 + contentBytes.length;
        int actualLength = ((content[0] & 0xFF) << 24) | ((content[1] & 0xFF) << 16) | 
                          ((content[2] & 0xFF) << 8) | (content[3] & 0xFF);
        assertEquals(expectedLength, actualLength);
        
        // Verify segment ID
        assertEquals("IMG", new String(content, 4, 3, StandardCharsets.US_ASCII));
        
        // Verify embedded content
        byte[] actualData = new byte[contentBytes.length];
        System.arraycopy(content, 7, actualData, 0, contentBytes.length);
        assertArrayEquals(contentBytes, actualData);
    }

    @Test
    void testWriteFileSegmentWithInputStreamSizeMismatch() throws IOException {
        // Arrange
        String fileContent = "Stream content";
        byte[] contentBytes = fileContent.getBytes(StandardCharsets.UTF_8);
        ByteArrayInputStream inputStream = new ByteArrayInputStream(contentBytes);
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act & Assert - Wrong size provided
            assertThrows(IOException.class, () -> {
                imiFile.writeFileSegment("IMG", inputStream, contentBytes.length + 10);
            });
        }
    }

    @Test
    void testWriteFileSegmentWithInputStreamTooLargeSize() throws IOException {
        // Arrange
        ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act & Assert - File too large for IMI segment
            assertThrows(IllegalArgumentException.class, () -> {
                imiFile.writeFileSegment("IMG", inputStream, Integer.MAX_VALUE);
            });
        }
    }

    @Test
    void testComplexIMIFileGeneration() throws IOException {
        // Arrange
        String naicCode = "12345";
        String fileId = "2024-01-15-12:34:56";
        String docId = "DOC_001";
        
        // Create test image content
        byte[] imageContent = "FAKE_PDF_CONTENT".getBytes(StandardCharsets.UTF_8);
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act - Generate a complete IMI file
            imiFile.writeSegment("HDR", naicCode);
            imiFile.writeSegment("FID", fileId);
            imiFile.writeSegment("BOD", docId);
            imiFile.writeSegment("DPK", "BATCH001");
            imiFile.writeBinarySegment("IMG", imageContent);
            imiFile.writeSegment("EOD", docId);
            imiFile.writeSegment("TRL", "000001");
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        assertTrue(content.length > 0);
        
        // Verify the file contains all expected segments by checking for segment IDs
        String contentAsString = new String(content, StandardCharsets.ISO_8859_1);
        assertTrue(contentAsString.contains("HDR"));
        assertTrue(contentAsString.contains("FID"));
        assertTrue(contentAsString.contains("BOD"));
        assertTrue(contentAsString.contains("DPK"));
        assertTrue(contentAsString.contains("IMG"));
        assertTrue(contentAsString.contains("EOD"));
        assertTrue(contentAsString.contains("TRL"));
        
        // Verify binary content is embedded
        assertTrue(contentAsString.contains("FAKE_PDF_CONTENT"));
    }

    @Test
    void testMixedBinaryAndTextSegments() throws IOException {
        // Arrange
        byte[] binaryData = {0x00, 0x01, 0x02, (byte)0xFF, (byte)0xFE};
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act - Mix text segments and binary segments
            imiFile.writeSegment("HDR", "header-text");
            imiFile.writeBinarySegment("IMG", binaryData);
            imiFile.writeSegment("TRL", "trailer-text");
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        assertTrue(content.length > 0);
        
        // Should contain both text data and binary data
        boolean foundBinaryData = false;
        for (int i = 0; i < content.length - binaryData.length; i++) {
            boolean matches = true;
            for (int j = 0; j < binaryData.length; j++) {
                if (content[i + j] != binaryData[j]) {
                    matches = false;
                    break;
                }
            }
            if (matches) {
                foundBinaryData = true;
                break;
            }
        }
        assertTrue(foundBinaryData, "Binary data should be embedded in the file");
    }

    @Test
    void testLargeBinarySegment() throws IOException {
        // Arrange
        byte[] largeData = new byte[64 * 1024]; // 64KB
        for (int i = 0; i < largeData.length; i++) {
            largeData[i] = (byte) (i % 256);
        }
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeBinarySegment("IMG", largeData);
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        
        // Verify length
        int expectedLength = 7 + largeData.length;
        int actualLength = ((content[0] & 0xFF) << 24) | ((content[1] & 0xFF) << 16) | 
                          ((content[2] & 0xFF) << 8) | (content[3] & 0xFF);
        assertEquals(expectedLength, actualLength);
        
        // Verify some of the data (first and last few bytes)
        assertEquals(largeData[0], content[7]);
        assertEquals(largeData[largeData.length - 1], content[content.length - 1]);
    }

    @Test
    void testCloseFile() throws IOException {
        // Arrange
        InterchangeFile imiFile = new InterchangeFile(testFilePath);
        imiFile.writeSegment("HDR", "test");
        
        // Act
        imiFile.close();
        
        // Assert - Should not throw exception and file should be readable
        assertTrue(Files.exists(Path.of(testFilePath)));
        String content = Files.readString(Path.of(testFilePath), StandardCharsets.UTF_8);
        assertTrue(content.contains("HDR"));
    }

    @Test
    void testAutoCloseable() throws IOException {
        // Arrange & Act - Use try-with-resources
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath)) {
            imiFile.writeSegment("HDR", "test");
        } // Should auto-close here
        
        // Assert
        assertTrue(Files.exists(Path.of(testFilePath)));
        String content = Files.readString(Path.of(testFilePath), StandardCharsets.UTF_8);
        assertTrue(content.contains("HDR"));
    }

    @Test
    void testEmptySegmentValues() throws IOException {
        // Arrange
        try (InterchangeFile imiFile = new InterchangeFile(testFilePath, false)) {
            // Act
            imiFile.writeSegment("HDR", "");
            imiFile.writeSegment("FID", "   "); // whitespace
            imiFile.writeSegment("IMG", null);
        }
        
        // Assert
        String content = Files.readString(Path.of(testFilePath), StandardCharsets.UTF_8);
        String[] lines = content.split("\n");
        
        assertEquals("HDR|", lines[0]);
        assertEquals("FID|   ", lines[1]);
        assertEquals("IMG|", lines[2]);
    }

    @Test
    void testSpecialCharactersInSegments() throws IOException {
        // Arrange
        String specialText = "Special chars: äöü 中文 🚀 \n\t\r";
        
        try (InterchangeFile imiFile = new InterchangeFile(testBinaryFilePath, true)) {
            // Act
            imiFile.writeSegment("HDR", specialText);
        }
        
        // Assert
        byte[] content = Files.readAllBytes(Path.of(testBinaryFilePath));
        
        // Skip header (4 bytes length + 3 bytes segment ID)
        byte[] textBytes = new byte[content.length - 7];
        System.arraycopy(content, 7, textBytes, 0, textBytes.length);
        String actualText = new String(textBytes, StandardCharsets.UTF_8);
        
        assertEquals(specialText, actualText);
    }
}