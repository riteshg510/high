package com.hmhs.hvwmid.validations;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Set;

public class ActiveTypeValidator implements ConstraintValidator<ValidActiveType, String> {

    private static final Set<String> ALLOWED_ACTIVE_TYPES = Set.of(
            "Y",
            "N"
    );

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value == null || ALLOWED_ACTIVE_TYPES.contains(value);
    }
}
