package com.hmhs.hvwmid.constants;

//globals.java
import java.io.*;
import java.util.ResourceBundle;

public class ImgGlobals2 {

	private String _filename;
	public static String hostName = "https://HOSTNAME.highmark.com/IMIAPIWeb/activityTracking/";
	public static String highviewAppId = "apphvw";
	public static String defaultFile = "index.jsp:index.html";
	public static String profilePath = "";
	public static String pagePath = "";
	public static String cachePath = "";
	public static String cacheUrl = "/imgcache/";
	// public static String urlRoot=new String("/"); //default url root
	public static String fileRoot = "/html/";
	public static int sessionTimeout = 60; // minutes to timeout
	public static int sessionFlush = 5; // minutes to scan sessions
	public static int cacheFlush = 15; // seconds to purge cache files
	public static String ipaddr = "";
	public static String host = "cpuf";
	public static int hostPort = 3002; // test system
	public static String transaction = "PIZ1";
	public static boolean debug = true;
	public static boolean localEnvironment = false;
	public static boolean bypassLogin = false;
	public static boolean callOAM = false;
	public static boolean useRemoteUser = false;
	public static String adminPwd = "imgweb";
	public static boolean tiff2pdf = true;
	public static String odExceptions = "";
	public static String regions = "";
	public static String connections = "";
	public static String envs = "";
	public static String imgConnect = "";
	public static String odConnect = "";
	public static String codeTableGetUrl = "http://oas01.highmark.com/iws/cover.getcodetable?a_objname=";
	public static String codeTableEditUrl = "http://oas01.highmark.com/iws/cover.editcodetablea?a_objname=";
	public static String machineID = "";
	public static String machineIDvariable = "";
	public static String wsDefaultUserid = "";

	public static String csdServletApplIds = "";
	public static String ummServletApplIds = "";
	public static String hostAuthenticationGroups = "";
	public static String fileCabinetOnDemandListing = "";

	public static String hvGroupNamePrefix = "HVW-LISTING";
	public static String IMIGroupNamePrefix = "IMI-ACTIVITYTRK";
	public static String hvwAdminGroup = "HVW-ADMINISTRATION-INT";
	public static String hvwAdminNonRestrictedGroup = "HVW-ADMINISTRATION-NONRESTRICTED-INT";
	public static String PARMID_HVW_IMI = "HVWIMI";
	public static String PARMID_HVW_IMG = "HVWIMG";
	public static String PARMID_HVW_CST = "HVWCST";

	public static String coverSheetGroupPrefix = "HVW-COVERSHEET";
	public static String coverSheetMaintGroupsuffix = "MAINT-INT";
	public static String coverSheetPrintGroupsuffix = "PRINT-INT";
	public static String pdfMimeType = "application/pdf";

	public static String retrieveCoverSheet = "coversheet";
	public static String retrieveOverride = "override";
	public static String actionURL = "/hvwwebWeb/ImgSessionMgr";

	public static String trustedReferrerHeader = "";
	public static String[] trustedReferrerHeaders = null;

	public static String REGEX_ACTION = "";
	public static String REGEX_ADDWORK = "";
	public static String REGEX_ADMINPWD = "";
	public static String REGEX_ADMINPWD1 = "";
	public static String REGEX_ADMINPWD2 = "";
	public static String REGEX_APPLIDCD = "";
	public static String REGEX_ASGNEMPL = "";
	public static String REGEX_AUDIT = "";
	public static String REGEX_AUTOSHOW = "";
	public static String REGEX_BARCODE = "";
	public static String REGEX_BEGINDATE = "";
	public static String REGEX_BPDID = "";
	public static String REGEX_BYPASSLOGIN = "";
	public static String REGEX_CACHEFLUSH = "";
	public static String REGEX_CACHEPATH = "";
	public static String REGEX_CACHEURL = "";
	public static String REGEX_CALLDIRSMART = "";
	public static String REGEX_CALLNTLM = "";
	public static String REGEX_CALLOAM = "";
	public static String REGEX_CDTYPE = "";
	public static String REGEX_CDVERSION = "";
	public static String REGEX_CLEN = "";
	public static String REGEX_CODETABLEDITURL = "";
	public static String REGEX_CODETABLEURL = "";
	public static String REGEX_COLLECTION = "";
	public static String REGEX_CONFIGFILENAME = "";
	public static String REGEX_CONNECTIONS = "";
	public static String REGEX_CONTENTTYPE = "";
	public static String REGEX_CONTINUE = "";
	public static String REGEX_CRTESITE = "";
	public static String REGEX_CSTACTIVE = "";
	public static String REGEX_CSDAPPLIDS = "";
	public static String REGEX_COVERSHEETDESC;
	public static String REGEX_UMMAPPLIDS = "";
	public static String REGEX_DEBUG = "";
	public static String REGEX_LOCALENVIRONMENT = "";
	public static String REGEX_DEFAULTFILE = "";
	public static String REGEX_DESCMASK = "";
	public static String REGEX_DESCRIPTION = "";
	public static String REGEX_DISPLACEMENT = "";
	public static String REGEX_DOCID = "";
	public static String REGEX_DOCTKN = "";
	public static String REGEX_DOWNLOAD = "";
	public static String REGEX_DROP = "";
	public static String REGEX_EDMPAGEPARAMETER = "";
	public static String REGEX_ENDDATE = "";
	public static String REGEX_ENV = "";
	public static String REGEX_ENVS = "";
	public static String REGEX_ERRTEMPLATE = "";
	public static String REGEX_EYPTSNDXOPRTRPARAMETER = "";
	public static String REGEX_FIELD = "";
	public static String REGEX_FIELDVALUE = "";
	public static String REGEX_FILENAME = "";
	public static String REGEX_FILEROOT = "";
	public static String REGEX_FILETAB = "";
	public static String REGEX_FILETAB_ENDDATE = "";
	public static String REGEX_FILETAB_STARTDATE = "";
	public static String REGEX_FLDRID = "";
	public static String REGEX_FLEN = "";
	public static String REGEX_FOLDER = "";
	public static String REGEX_FOLDERCOUNT = "";
	public static String REGEX_FOLDID = "";
	public static String REGEX_FOLDTKN = "";
	public static String REGEX_FORMNUM = "";
	public static String REGEX_FRAME = "";
	public static String REGEX_FUNCTION = "";
	public static String REGEX_GROUP = "";
	public static String REGEX_HEADING = "";
	public static String REGEX_HOLDDATE = "";
	public static String REGEX_HOLDTIME = "";
	public static String REGEX_HOST = "";
	public static String REGEX_HOSTAUTHENTICATIONGROUP = "";
	public static String REGEX_HOSTPORT = "";
	public static String REGEX_IMAGEKEY = "";
	public static String REGEX_IMAGETITLE = "";
	public static String REGEX_IMGB2BGUI = "";
	public static String REGEX_IMGCONNECT = "";
	public static String REGEX_INIT = "";
	public static String REGEX_INDXTYPE = "";
	public static String REGEX_IPADDR = "";
	public static String REGEX_LIMITCOUNT = "";
	public static String REGEX_LISTALL = "";
	public static String REGEX_LIST15INDPARAMETER = "";
	public static String REGEX_LOAD = "";
	public static String REGEX_MACHINEIDVARIABLE = "";
	public static String REGEX_MASK = "";
	public static String REGEX_MINUTES = "";
	public static String REGEX_MISC = "";
	public static String REGEX_MODE = "";
	public static String REGEX_NAME = "";
	public static String REGEX_NAMEMASK = "";
	public static String REGEX_NEWFORMNUM = "";
	public static String REGEX_NEWOBJDESC = "";
	public static String REGEX_NEWPASS1 = "";
	public static String REGEX_NEWPASS2 = "";
	public static String REGEX_NEWSPAGE = "";
	public static String REGEX_NEXTACTION = "";
	public static String REGEX_NEXTACTIONNAME = "";
	public static String REGEX_NEXTACTIONTARGET = "";
	public static String REGEX_OBJDESC = "";
	public static String REGEX_OBJNAME = "";
	public static String REGEX_OBJTIME = "";
	public static String REGEX_ODCONNECT = "";
	public static String REGEX_ODEXCEPTIONS = "";
	public static String REGEX_ODM = "";
	public static String REGEX_ODMAX1 = "";
	public static String REGEX_ODMAX2 = "";
	public static String REGEX_ODPOOL1 = "";
	public static String REGEX_ODPOOL2 = "";
	public static String REGEX_ODTRAN1 = "";
	public static String REGEX_ODTRAN2 = "";
	public static String REGEX_PAGEPATH = "";
	public static String REGEX_PASSWORD = "";
	public static String REGEX_PATH = "";
	public static String REGEX_PCONTINUE = "";
	public static String REGEX_PREFIX = "";
	public static String REGEX_PROFILEPATH = "";
	public static String REGEX_RCODE = "";
	// public static String REGEX_REFERER = "";
	public static String REGEX_REGION = "";
	public static String REGEX_REGIONS = "";
	public static String REGEX_REMOTEIP = "";
	public static String REGEX_RUNIT = "";
	public static String REGEX_SESSIONFLUSH = "";
	public static String REGEX_SESSIONID = "";
	public static String REGEX_SESSIONTIMEOUT = "";
	public static String REGEX_SHOWDELETED = "";
	public static String REGEX_SHOWTYPE = "";
	public static String REGEX_SIGNEDON = "";
	public static String REGEX_SRCHOP = "";
	public static String REGEX_STAGE = "";
	public static String REGEX_TASK = "";
	public static String REGEX_TEMPLATE = "";
	public static String REGEX_TEMPLATE1 = "";
	public static String REGEX_TEMPLATEURL = "";
	public static String REGEX_TIFF2PDF = "";
	// public static String REGEX_TOKEN = "";
	public static String REGEX_TRANID = "";
	public static String REGEX_TRANSACTION = "";
	public static String REGEX_TRUSTEDREFERRERHEADER = "";
	public static String REGEX_UNIQUECHARS = "";
	public static String REGEX_UNIT = "";
	public static String REGEX_UPDATETEMPLATE = "";
	public static String REGEX_URL = "";
	public static String REGEX_URLROOT = "";
	public static String REGEX_USEREMOTEUSER = "";
	public static String REGEX_USERID = "";
	public static String REGEX_USERSTAT = "";
	public static String REGEX_WKSTATID = "";
	public static String REGEX_WSDEFAULTUSERID = "";
	public static String REGEX_NUMERIC = "";
	public static String REGEX_ALPHANUMERIC = "";
	public static String REGEX_DPK = "";
	public static String REGEX_OPTIONALIMISEGVALUE = "";
	public static String REGEX_BOOLEAN = "";
	public static String REGEX_DATE = "";
	public static String REGEX_FOLDTYPE = "";
	public static String REGEX_ALPHANUMERICSYMBOLS = "";

	// public static String useridRegex = "";
	// public static String PASSWORDEXPRESSION = "";
	// public static String ALPHANUMSPUNDERSCMINUSAMPERSADOT = "";
	// public static String ALPHANUMSPDOT = "";
	// public static String ALPHANUMSPUNDERSCMINUS = "";
	// public static String NUMSLASH = "";
	// public static String ALPHANUMSPUNDERSCMINUSFBSLASH = "";
	// public static String ALPHASPLESSGREATHANCOLONEXCLAMMINUS = "";
	// public static String NUMSDOTEQUALCOLON = "";
	// public static String ALPHANUMSPPLUSMINUS = "";
	// public static String ALPHANUMSPDOTEQUALMINUSPLUS = "";
	// public static String ALPHANUMSPPERCENT = "";
	// public static String URLEXPRESSION = "";
	// public static String EDMEXPRESSION = "";
	// public static String ALPHANUMSPUNDERSMPEEQUFBSLAH = "";

	public static String[] fileRoots = null;
	public static String[] pagePaths = null;
	public static String[] defaultFiles = null;

	// private static Properties _propfile=new Properties();
	private static ResourceBundle _rb;
	private static boolean _loaded = false;

	private ImgGlobals2(String filename) {
		this._filename = filename;
	}

	private static void parsePaths() {
		fileRoots = fileRoot.split(":");
		pagePaths = pagePath.split(":");
		defaultFiles = defaultFile.split(":");
		trustedReferrerHeaders = trustedReferrerHeader.split("|");
	}

	private static void load() {

		_rb.clearCache();
		_rb = ResourceBundle.getBundle("imgGlobals");

		defaultFile = getString("defaultFile", defaultFile);
		profilePath = getString("profilePath", profilePath);
		pagePath = getString("pagePath", pagePath);
		cachePath = getString("cachePath", cachePath);
		cacheUrl = getString("cacheUrl", cacheUrl);
		// urlRoot=getString("urlRoot",urlRoot);
		fileRoot = getString("fileRoot", fileRoot);
		sessionTimeout = getInt("sessionTimeout", sessionTimeout);
		sessionFlush = getInt("sessionFlush", sessionFlush);
		cacheFlush = getInt("cacheFlush", cacheFlush);
		ipaddr = getString("ipaddr", ipaddr);
		host = getString("host", host);
		hostPort = getInt("hostPort", hostPort);
		transaction = getString("transaction", transaction);
		adminPwd = getString("adminPwd", adminPwd);
		odExceptions = getString("odExceptions", odExceptions);
		regions = getString("regions", regions);
		connections = getString("connections", connections);
		envs = getString("envs", envs);
		imgConnect = getString("imgConnect", imgConnect);
		odConnect = getString("odConnect", odConnect);
		codeTableGetUrl = getString("codeTableGetUrl", codeTableGetUrl);
		codeTableEditUrl = getString("codeTableEditUrl", codeTableEditUrl);
		debug = getBool("debug", debug);
		localEnvironment = getBool("localEnvironment", localEnvironment);
		bypassLogin = getBool("bypassLogin", bypassLogin);
		tiff2pdf = getBool("tiff2pdf", tiff2pdf);
		useRemoteUser = getBool("useRemoteUser", useRemoteUser);
		callOAM = getBool("callOAM", callOAM);
		machineIDvariable = getString("machineIDvariable", machineIDvariable);
		wsDefaultUserid = getString("wsDefaultUserid", wsDefaultUserid);
		csdServletApplIds = getString("csdServletApplIds", csdServletApplIds);
		ummServletApplIds = getString("ummServletApplIds", ummServletApplIds);
		hostAuthenticationGroups = getString("hostAuthenticationGroup", hostAuthenticationGroups);
		fileCabinetOnDemandListing = getString("fileCabinetOnDemandListing", fileCabinetOnDemandListing);
		trustedReferrerHeader = getString("trustedReferrerHeader", trustedReferrerHeader);
		REGEX_ACTION = getString("REGEX_ACTION", REGEX_ACTION);
		REGEX_ADDWORK = getString("REGEX_ADDWORK", REGEX_ADDWORK);
		REGEX_ADMINPWD = getString("REGEX_ADMINPWD", REGEX_ADMINPWD);
		REGEX_ADMINPWD1 = getString("REGEX_ADMINPWD1", REGEX_ADMINPWD1);
		REGEX_ADMINPWD2 = getString("REGEX_ADMINPWD2", REGEX_ADMINPWD2);
		REGEX_APPLIDCD = getString("REGEX_APPLIDCD", REGEX_APPLIDCD);
		REGEX_ASGNEMPL = getString("REGEX_ASGNEMPL", REGEX_ASGNEMPL);
		REGEX_AUDIT = getString("REGEX_AUDIT", REGEX_AUDIT);
		REGEX_AUTOSHOW = getString("REGEX_AUTOSHOW", REGEX_AUTOSHOW);
		REGEX_BARCODE = getString("REGEX_BARCODE", REGEX_BARCODE);
		REGEX_BEGINDATE = getString("REGEX_BEGINDATE", REGEX_BEGINDATE);
		REGEX_BPDID = getString("REGEX_BPDID", REGEX_BPDID);
		REGEX_BYPASSLOGIN = getString("REGEX_BYPASSLOGIN", REGEX_BYPASSLOGIN);
		REGEX_CACHEFLUSH = getString("REGEX_CACHEFLUSH", REGEX_CACHEFLUSH);
		REGEX_CACHEPATH = getString("REGEX_CACHEPATH", REGEX_CACHEPATH);
		REGEX_CACHEURL = getString("REGEX_CACHEURL", REGEX_CACHEURL);
		REGEX_CALLDIRSMART = getString("REGEX_CALLDIRSMART", REGEX_CALLDIRSMART);
		REGEX_CALLNTLM = getString("REGEX_CALLNTLM", REGEX_CALLNTLM);
		REGEX_CALLOAM = getString("REGEX_CALLOAM", REGEX_CALLOAM);
		REGEX_CDTYPE = getString("REGEX_CDTYPE", REGEX_CDTYPE);
		REGEX_CDVERSION = getString("REGEX_CDVERSION", REGEX_CDVERSION);
		REGEX_CODETABLEDITURL = getString("REGEX_CODETABLEDITURL", REGEX_CODETABLEDITURL);
		REGEX_CODETABLEURL = getString("REGEX_CODETABLEURL", REGEX_CODETABLEURL);
		REGEX_COLLECTION = getString("REGEX_COLLECTION", REGEX_COLLECTION);
		REGEX_CONFIGFILENAME = getString("REGEX_CONFIGFILENAME", REGEX_CONFIGFILENAME);
		REGEX_CONNECTIONS = getString("REGEX_CONNECTIONS", REGEX_CONNECTIONS);
		REGEX_CONTENTTYPE = getString("REGEX_CONTENTTYPE", REGEX_CONTENTTYPE);
		REGEX_CONTINUE = getString("REGEX_CONTINUE", REGEX_CONTINUE);
		REGEX_CLEN = getString("REGEX_CLEN", REGEX_CLEN);
		REGEX_CRTESITE = getString("REGEX_CRTESITE", REGEX_CRTESITE);
		REGEX_CSDAPPLIDS = getString("REGEX_CSDAPPLIDS", REGEX_CSDAPPLIDS);
		REGEX_CSTACTIVE = getString("REGEX_CSTACTIVE", REGEX_CSTACTIVE);
		REGEX_COVERSHEETDESC = getString("REGEX_COVERSHEETDESC", REGEX_COVERSHEETDESC);
		REGEX_UMMAPPLIDS = getString("REGEX_UMMAPPLIDS", REGEX_UMMAPPLIDS);
		REGEX_DEBUG = getString("REGEX_DEBUG", REGEX_DEBUG);
		REGEX_LOCALENVIRONMENT = getString("REGEX_LOCALENVIRONMENT", REGEX_LOCALENVIRONMENT);
		REGEX_DEFAULTFILE = getString("REGEX_DEFAULTFILE", REGEX_DEFAULTFILE);
		REGEX_DESCMASK = getString("REGEX_DESCMASK", REGEX_DESCMASK);
		REGEX_DESCRIPTION = getString("REGEX_DESCRIPTION", REGEX_DESCRIPTION);
		REGEX_DISPLACEMENT = getString("REGEX_DISPLACEMENT", REGEX_DISPLACEMENT);
		REGEX_DOCID = getString("REGEX_DOCID", REGEX_DOCID);
		REGEX_DOCTKN = getString("REGEX_DOCTKN", REGEX_DOCTKN);
		REGEX_DOWNLOAD = getString("REGEX_DOWNLOAD", REGEX_DOWNLOAD);
		REGEX_DROP = getString("REGEX_DROP", REGEX_DROP);
		REGEX_EDMPAGEPARAMETER = getString("REGEX_EDMPAGEPARAMETER", REGEX_EDMPAGEPARAMETER);
		REGEX_ENDDATE = getString("REGEX_ENDDATE", REGEX_ENDDATE);
		REGEX_ENV = getString("REGEX_ENV", REGEX_ENV);
		REGEX_ENVS = getString("REGEX_ENVS", REGEX_ENVS);
		REGEX_ERRTEMPLATE = getString("REGEX_ERRTEMPLATE", REGEX_ERRTEMPLATE);
		REGEX_EYPTSNDXOPRTRPARAMETER = getString("REGEX_EYPTSNDXOPRTRPARAMETER", REGEX_EYPTSNDXOPRTRPARAMETER);
		REGEX_FIELD = getString("REGEX_FIELD", REGEX_FIELD);
		REGEX_FIELDVALUE = getString("REGEX_FIELDVALUE", REGEX_FIELDVALUE);
		REGEX_FILENAME = getString("REGEX_FILENAME", REGEX_FILENAME);
		REGEX_FILEROOT = getString("REGEX_FILEROOT", REGEX_FILEROOT);
		REGEX_FILETAB = getString("REGEX_FILETAB", REGEX_FILETAB);
		REGEX_FILETAB_ENDDATE = getString("REGEX_FILETAB_ENDDATE", REGEX_FILETAB_ENDDATE);
		REGEX_FILETAB_STARTDATE = getString("REGEX_FILETAB_STARTDATE", REGEX_FILETAB_STARTDATE);
		REGEX_FLDRID = getString("REGEX_FLDRID", REGEX_FLDRID);
		REGEX_FLEN = getString("REGEX_FLEN", REGEX_CONTINUE);
		REGEX_FOLDER = getString("REGEX_FOLDER", REGEX_FOLDER);
		REGEX_FOLDERCOUNT = getString("REGEX_FOLDERCOUNT", REGEX_FOLDERCOUNT);
		REGEX_FOLDID = getString("REGEX_FOLDID", REGEX_FOLDID);
		REGEX_FOLDTKN = getString("REGEX_FOLDTKN", REGEX_FOLDTKN);
		REGEX_FORMNUM = getString("REGEX_FORMNUM", REGEX_FORMNUM);
		REGEX_FRAME = getString("REGEX_FRAME", REGEX_FRAME);
		REGEX_FUNCTION = getString("REGEX_FUNCTION", REGEX_FUNCTION);
		REGEX_GROUP = getString("REGEX_GROUP", REGEX_GROUP);
		REGEX_HEADING = getString("REGEX_HEADING", REGEX_HEADING);
		REGEX_HOLDDATE = getString("REGEX_HOLDDATE", REGEX_HOLDDATE);
		REGEX_HOLDTIME = getString("REGEX_HOLDTIME", REGEX_HOLDTIME);
		REGEX_HOST = getString("REGEX_HOST", REGEX_HOST);
		REGEX_HOSTAUTHENTICATIONGROUP = getString("REGEX_HOSTAUTHENTICATIONGROUP", REGEX_HOSTAUTHENTICATIONGROUP);
		REGEX_HOSTPORT = getString("REGEX_HOSTPORT", REGEX_HOSTPORT);
		REGEX_IMAGEKEY = getString("REGEX_IMAGEKEY", REGEX_IMAGEKEY);
		REGEX_IMAGETITLE = getString("REGEX_IMAGETITLE", REGEX_IMAGETITLE);
		REGEX_IMGB2BGUI = getString("REGEX_IMGB2BGUI", REGEX_IMGB2BGUI);
		REGEX_IMGCONNECT = getString("REGEX_IMGCONNECT", REGEX_IMGCONNECT);
		REGEX_INIT = getString("REGEX_INIT", REGEX_INIT);
		REGEX_INDXTYPE = getString("REGEX_INDXTYPE", REGEX_INDXTYPE);
		REGEX_IPADDR = getString("REGEX_IPADDR", REGEX_IPADDR);
		REGEX_LIMITCOUNT = getString("REGEX_LIMITCOUNT", REGEX_LIMITCOUNT);
		REGEX_LISTALL = getString("REGEX_LISTALL", REGEX_LISTALL);
		REGEX_LIST15INDPARAMETER = getString("REGEX_LIST15INDPARAMETER", REGEX_LIST15INDPARAMETER);
		REGEX_LOAD = getString("REGEX_LOAD", REGEX_LOAD);
		REGEX_MACHINEIDVARIABLE = getString("REGEX_MACHINEIDVARIABLE", REGEX_MACHINEIDVARIABLE);
		REGEX_MASK = getString("REGEX_MASK", REGEX_MASK);
		REGEX_MINUTES = getString("REGEX_MINUTES", REGEX_MINUTES);
		REGEX_MISC = getString("REGEX_MISC", REGEX_MISC);
		REGEX_MODE = getString("REGEX_MODE", REGEX_MODE);
		REGEX_NAME = getString("REGEX_NAME", REGEX_NAME);
		REGEX_NAMEMASK = getString("REGEX_NAMEMASK", REGEX_NAMEMASK);
		REGEX_NEWFORMNUM = getString("REGEX_NEWFORMNUM", REGEX_NEWFORMNUM);
		REGEX_NEWOBJDESC = getString("REGEX_NEWOBJDESC", REGEX_NEWOBJDESC);
		REGEX_NEWPASS1 = getString("REGEX_NEWPASS1", REGEX_NEWPASS1);
		REGEX_NEWPASS2 = getString("REGEX_NEWPASS2", REGEX_NEWPASS2);
		REGEX_NEWSPAGE = getString("REGEX_NEWSPAGE", REGEX_NEWSPAGE);
		REGEX_NEXTACTION = getString("REGEX_NEXTACTION", REGEX_NEXTACTION);
		REGEX_NEXTACTIONNAME = getString("REGEX_NEXTACTIONNAME", REGEX_NEXTACTIONNAME);
		REGEX_NEXTACTIONTARGET = getString("REGEX_NEXTACTIONTARGET", REGEX_NEXTACTIONTARGET);
		REGEX_OBJDESC = getString("REGEX_OBJDESC", REGEX_OBJDESC);
		REGEX_OBJNAME = getString("REGEX_OBJNAME", REGEX_OBJNAME);
		REGEX_OBJTIME = getString("REGEX_OBJTIME", REGEX_OBJTIME);
		REGEX_ODCONNECT = getString("REGEX_ODCONNECT", REGEX_ODCONNECT);
		REGEX_ODEXCEPTIONS = getString("REGEX_ODEXCEPTIONS", REGEX_ODEXCEPTIONS);
		REGEX_ODM = getString("REGEX_ODM", REGEX_ODM);
		REGEX_ODMAX1 = getString("REGEX_ODMAX1", REGEX_ODMAX1);
		REGEX_ODMAX2 = getString("REGEX_ODMAX2", REGEX_ODMAX2);
		REGEX_ODPOOL1 = getString("REGEX_ODPOOL1", REGEX_ODPOOL1);
		REGEX_ODPOOL2 = getString("REGEX_ODPOOL2", REGEX_ODPOOL2);
		REGEX_ODTRAN1 = getString("REGEX_ODTRAN1", REGEX_ODTRAN1);
		REGEX_ODTRAN2 = getString("REGEX_ODTRAN2", REGEX_ODTRAN2);
		REGEX_PAGEPATH = getString("REGEX_PAGEPATH", REGEX_PAGEPATH);
		REGEX_PASSWORD = getString("REGEX_PASSWORD", REGEX_PASSWORD);
		REGEX_PATH = getString("REGEX_PATH", REGEX_PATH);
		REGEX_PCONTINUE = getString("REGEX_PCONTINUE", REGEX_PCONTINUE);
		REGEX_PREFIX = getString("REGEX_PREFIX", REGEX_PREFIX);
		REGEX_PROFILEPATH = getString("REGEX_PROFILEPATH", REGEX_PROFILEPATH);
		REGEX_RCODE = getString("REGEX_RCODE", REGEX_RCODE);
		REGEX_REGION = getString("REGEX_REGION", REGEX_REGION);
		REGEX_REGIONS = getString("REGEX_REGIONS", REGEX_REGIONS);
		REGEX_REMOTEIP = getString("REGEX_REMOTEIP", REGEX_REMOTEIP);
		REGEX_RUNIT = getString("REGEX_RUNIT", REGEX_RUNIT);
		REGEX_SESSIONFLUSH = getString("REGEX_SESSIONFLUSH", REGEX_SESSIONFLUSH);
		REGEX_SESSIONID = getString("REGEX_SESSIONID", REGEX_SESSIONID);
		REGEX_SESSIONTIMEOUT = getString("REGEX_SESSIONTIMEOUT", REGEX_SESSIONTIMEOUT);
		REGEX_SHOWDELETED = getString("REGEX_SHOWDELETED", REGEX_SHOWDELETED);
		REGEX_SHOWTYPE = getString("REGEX_SHOWTYPE", REGEX_SHOWTYPE);
		REGEX_SIGNEDON = getString("REGEX_SIGNEDON", REGEX_SIGNEDON);
		REGEX_SRCHOP = getString("REGEX_SRCHOP", REGEX_SRCHOP);
		REGEX_STAGE = getString("REGEX_STAGE", REGEX_STAGE);
		REGEX_TASK = getString("REGEX_TASK", REGEX_TASK);
		REGEX_TEMPLATE = getString("REGEX_TEMPLATE", REGEX_TEMPLATE);
		REGEX_TEMPLATE1 = getString("REGEX_TEMPLATE1", REGEX_TEMPLATE1);
		REGEX_TEMPLATEURL = getString("REGEX_TEMPLATEURL", REGEX_TEMPLATEURL);
		REGEX_TIFF2PDF = getString("REGEX_TIFF2PDF", REGEX_TIFF2PDF);
		REGEX_TRANID = getString("REGEX_TRANID", REGEX_TRANID);
		REGEX_TRANSACTION = getString("REGEX_TRANSACTION", REGEX_TRANSACTION);
		REGEX_TRUSTEDREFERRERHEADER = getString("REGEX_TRUSTEDREFERRERHEADER", REGEX_TRUSTEDREFERRERHEADER);
		REGEX_UNIQUECHARS = getString("REGEX_UNIQUECHARS", REGEX_UNIQUECHARS);
		REGEX_UNIT = getString("REGEX_UNIT", REGEX_UNIT);
		REGEX_UPDATETEMPLATE = getString("REGEX_UPDATETEMPLATE", REGEX_UPDATETEMPLATE);
		REGEX_URL = getString("REGEX_URL", REGEX_URL);
		REGEX_URLROOT = getString("REGEX_URLROOT", REGEX_URLROOT);
		REGEX_USEREMOTEUSER = getString("REGEX_USEREMOTEUSER", REGEX_USEREMOTEUSER);
		REGEX_USERID = getString("REGEX_USERID", REGEX_USERID);
		REGEX_USERSTAT = getString("REGEX_USERSTAT", REGEX_USERSTAT);
		REGEX_WKSTATID = getString("REGEX_WKSTATID", REGEX_WKSTATID);
		REGEX_WSDEFAULTUSERID = getString("REGEX_WSDEFAULTUSERID", REGEX_WSDEFAULTUSERID);
		REGEX_NUMERIC = getString("REGEX_NUMERIC", REGEX_NUMERIC);
		REGEX_ALPHANUMERIC = getString("REGEX_ALPHANUMERIC", REGEX_ALPHANUMERIC);
		REGEX_DPK = getString("REGEX_DPK", REGEX_DPK);
		REGEX_OPTIONALIMISEGVALUE = getString("REGEX_OPTIONALIMISEGVALUE", REGEX_OPTIONALIMISEGVALUE);
		REGEX_BOOLEAN = getString("REGEX_BOOLEAN", REGEX_BOOLEAN);
		REGEX_DATE = getString("REGEX_DATE", REGEX_DATE);
		REGEX_FOLDTYPE = getString("REGEX_FOLDTYPE", REGEX_FOLDTYPE);
		REGEX_ALPHANUMERICSYMBOLS = getString("REGEX_ALPHANUMERICSYMBOLS", REGEX_ALPHANUMERICSYMBOLS);

	}

	private static int getInt(String key, int defaultValue) {
		return Integer.parseInt(getString(key, String.valueOf(defaultValue)));
	}

	private static boolean getBool(String key, boolean defaultValue) {
		return Boolean.parseBoolean(getString(key, String.valueOf(defaultValue)));
	}

	private static String getString(String key, String defaultValue) {
		try {
			return _rb.getString(key);
		} catch (Exception e) {
			System.err.println("ImgGlobals2: defaulting value for key " + key + " to " + defaultValue);
			return defaultValue;
		}
	}

	private void save() {
		try {
			FileOutputStream fileOut = new FileOutputStream(_filename);
			ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
			objectOut.writeObject(this);
			objectOut.close();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	/**
	 * This method will return true if the input text is not empty otherwise it will
	 * return false
	 * 
	 * @param input input string
	 * @return boolean
	 */
	public static boolean hasText(String input) {
		if (input != null && input.trim().length() > 0) {
			return true;
		}
		return false;

	}

	/**
	 * This method will return true if the number is greater than 0
	 * 
	 * @param number
	 * @return
	 */
	public static boolean hasNumber(long number) {
		if (number != 0) {
			return true;
		}
		return false;
	}

}// class
