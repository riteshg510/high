package com.hmhs.hvwmid.utils;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

/**
 *  Utils class for ImgGlobals2
 *  
 *
 */
public class ImgGlobals2Utils {
	
	private static final Set<String> integerListFields = Set.of("applIdCdQuery");
	

	 /**
     * Dynamically sets a property on a Java bean.
     *
     * @param bean      The bean object
     * @param propName  The name of the property to set
     * @param propValue The string value to be converted and set
     */
    public static void setPropertyVals(Object bean, String propName, String propValue) {
        if (bean == null || propName == null) return;

        BeanWrapper wrapper = new BeanWrapperImpl(bean);
        Class<?> propertyType = wrapper.getPropertyType(propName);

        if (propertyType == null) {
            System.err.println("Property not found: " + propName);
            return;
        }

        try {
            if (propertyType == Long.class || propertyType == long.class) {
                wrapper.setPropertyValue(propName, Long.valueOf(propValue));
            } else if (propertyType == Boolean.class || propertyType == boolean.class) {
                wrapper.setPropertyValue(propName, Boolean.valueOf(propValue));
            } else if (propertyType == List.class) {
                if (integerListFields.contains(propName)) {
                    // Convert comma-separated string to List<Integer>
                    List<Integer> intList = Arrays.stream(propValue.split(","))
                            .map(String::trim)
                            .filter(s -> !s.isEmpty())
                            .map(Integer::valueOf)
                            .collect(Collectors.toList());
                    wrapper.setPropertyValue(propName, intList);
                } else {
                    // Convert comma-separated string to List<String>
                    List<String> strList = Arrays.stream(propValue.split(","))
                            .map(String::trim)
                            .collect(Collectors.toList());
                    wrapper.setPropertyValue(propName, strList);
                }
            } else {
                // Default: treat as string
                wrapper.setPropertyValue(propName, propValue);
            }
        } catch (Exception e) {
            System.err.println("Failed to set property '" + propName + "' with value '" + propValue + "'");
            e.printStackTrace();
        }
    }
	
	
	/**
	 * This method will get the property values of the bean
	 * 
	 * @param bean
	 * @param propName
	 * @return
	 * @throws Exception
	 */
    public static Object getPropertyVal(Object bean, String propName) {
        if (bean == null || propName == null) {
            return null;
        }

        try {
            BeanWrapper wrapper = new BeanWrapperImpl(bean);
            return wrapper.getPropertyValue(propName);
        } catch (Exception e) {
            System.err.println("Failed to get property '" + propName + "' from bean: " + e.getMessage());
            return null;
        }
    }
}
