package com.hmhs.hvwmid.constants;

/**
 * Constant class for ImgGlobals2
 *
 */
public class ImgGlobals2Constants {
	
	public enum SearchReqMapping{
		XMIT_FILE_ID("transmitFileIdQuery","transmitFileIdDisplay","transmitFileId","Transmit File ID","na", "TF"),
		XMIT_FILE_NAME("transmitFileNameQuery","transmitFileNameDisplay","transmitFileName","Transmit File Name","transmitFileNameSearchOperator", "TF"),
		XMIT_FILE_STATUS_CODE("transmitFileStatusCdQuery","transmitFileStatusCdDisplay","transmitFileStatusCd","Transmit File Status Code","transmitFileStatusCdSearchOperator", "TF"),
		IMI_FILE_ID("imiFileIdQuery","imiFileIdDisplay","imiFileId","IMI File ID","na", "PF"),
		PLAN_FILE_ID("planFileIdQuery","planFileIdDisplay","planFileId","Plan File ID","planFileIdSearchOperator", "PF"),
		PROCESS_FILE_NAME("processFileNameQuery","processFileNameDisplay","processFileName","Process File Name","processFileNameSearchOperator", "PF"),
		PROCESS_FILE_STATUS_CODE("processFileStatusCdQuery","processFileStatusCdDisplay","processFileStatusCd","Process File Status Code","processFileStatusCdSearchOperator", "PF"),
		PROCESS_FILE_REASON_CODE("processFileReasonCdQuery","processFileReasonCdDisplay","processFileReasonCdDesc","Process File Reason Code", "processFileReasonCdSearchOperator","PF"),
		TIME_ACK("timeAckQuery","timeAckDisplay","timeAck","Process File Acknowledgement Time","timeAckSearchOperator","PF"),
		IMI_DOCUMENT_ID("imiDocumentIdQuery","imiDocumentIdDisplay","imiDocumentId","IMI Document ID","na", "DT"),
		PLAN_DCN("planDCNQuery","planDCNDisplay","planDCN","Plan DCN","planDCNSearchOperator", "DT"),
		DPK("dpkQuery","dpkDisplay","dpk","DPK","dpkSearchOperator", "DT"),
		INITIAL_PROCESS_DCN("initialProcessDCNQuery","initialProcessDCNDisplay","initialProcessDCN","Initial Process DCN","initialProcessDCNSearchOperator", "DT"),
		FINAL_PROCESS_DCN("finalProcessDCNQuery","finalProcessDCNDisplay","finalProcessDCN","Final Process DCN","finalProcessDCNSearchOperator", "DT"),
		DOCUMENT_STATUS_CODE("documentStatusCdQuery","documentStatusCdDisplay","documentStatusCd","Document Status Code","documentStatusCdSearchOperator", "DT"),
		DOCUMENT_REASON_CODE("documentReasonCdQuery","documentReasonCdDisplay","documentReasonCdDesc","Document Reason Code","documentReasonCdSearchOperator","DT"),
		TIME_UPDATE("timeUpdateQuery","timeUpdateDisplay","timeUpdate","Document Status TimeStamp","timeUpdateSearchOperator","DT"),
		APPLIDCD("applIdCdQuery","applIdCdDisplay","applIdCd","Appl Id","na", "DT"),
		CAPTURE_ITEM_ID("captureItemIdQuery","captureItemIdDisplay","captureItemId","Capture Item ID","na", "DT");
		
		private String queryField;
		private String displayField;
		private String outputField;
		private String columnHeader;
		private String searchStringField;
		private String alias;
		
		public String getQueryField(){
			return queryField;
		}
		public String getDisplayField(){
			return displayField;
		}
		public String getOutputField(){
			return outputField;
		}
		public String getColumnHeader(){
			return columnHeader;
		}
		public String getSearchStringField(){
			return searchStringField;
		}
		public String getAlias(){
			return alias;
		}
		
		private SearchReqMapping(String queryField, String displayField, String outputField, String columnHeader, String searchStringField, String alias){
			this.queryField = queryField;
			this.displayField = displayField;
			this.outputField = outputField;
			this.columnHeader = columnHeader;
			this.searchStringField = searchStringField;
			this.alias = alias;
		}
	}
	
	public enum IMIHostName{
		PENV("apps"),
		TENV1("appstenv1"),
		TENV2("appstenv2"),
		TENV3("appstenv3"),
		TENV4("appstenv4"),
		TENV5("appstenv5"),
		TENV6("appstenv6"),
		TENV7("appstenv7"),
		TENVA("appstenva"),
		TENVB("appstenvb"),
		TENVC("appstenvc"),
		TENVD("appstenvd"),
		TENVE("appstenve");
		
		private String hostName;
		
		public String getHostName(){
			return hostName;
		}
		
		private IMIHostName(String hostName){
			this.hostName = hostName;
		}
	}
	
	public enum SearchOperator{
		EXACT("="),
		LIKE("LIKE"),
		NOT("!=");
		
		private String searchOperator;
		
		private SearchOperator(String searchOperator){
			this.searchOperator = searchOperator;
		}
		
		public String getSearchOperator(){
			return searchOperator;
		}
	}
	
	/**
	 * 
	 * @author lid5dja
	 *
	 * defaults the environment when no session exists based on hostname of url
	 * 
	 */
	public enum HVWEnvironment {
		APPS("penv"),
		APPSTENV1("tenv1"),
		APPSTENV2("tenv2"),
		APPSTENV3("tenv3"),
		APPSTENV4("tenv4"),
		APPSTENV5("tenv5"),
		APPSTENV6("tenv6"),
		APPSTENV7("tenv7"),
		APPSTENVA("tenva"),
		APPSTENVB("tenvb"),
		APPSTENVC("tenvc"),
		APPSTENVD("tenvd"),
		APPSTENVE("tenve"),
		HIGHVIEW("penv"),
		HIGHVIEWTEST("tenv1");

		private String hostName;

		public synchronized String getValue() {
			if (hostName==null)
				return "penv";
			if (hostName.trim()=="")
				return "penv";
			return hostName;
		}

		public static HVWEnvironment getValueOfEnv(String name) {
			try {
				for (HVWEnvironment e : values()) {
					if (name==null)
						return HIGHVIEW;
					if (name.trim().equalsIgnoreCase(""))
						return HIGHVIEW;
					if (name.trim().equalsIgnoreCase("highview"))
						return HIGHVIEW;
					if (name.trim().equalsIgnoreCase("highviewtest"))
						return HIGHVIEWTEST;
					if (e.toString().equalsIgnoreCase(name)) 
						return e;
				}
			} catch (Exception e) {
				return HIGHVIEW;
			}
			return HIGHVIEW;
		}
	
		private HVWEnvironment(String hostName){
			this.hostName = hostName;
		}
	}
	
	 // lookup by fieldName
    public static String getHeaderByFieldName(String fieldName) {
    	SearchReqMapping[] reqPropMapping = SearchReqMapping.values();
        for (SearchReqMapping c : reqPropMapping) {
            if (c.getOutputField().equalsIgnoreCase(fieldName)) {
                return c.getColumnHeader();
            }
        }
        return fieldName; // fallback: just use field name if not found
    }

}
