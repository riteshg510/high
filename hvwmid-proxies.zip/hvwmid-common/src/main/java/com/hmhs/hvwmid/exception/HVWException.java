package com.hmhs.hvwmid.exception;

/**
 * Class that represents exception that occurs in Highview application.
 * 
 * @author lidlipc
 *
 */
public class HVWException extends Exception {
	private static final long serialVersionUID = 1L;

	public HVWException() {
		super();
	}

	/**
	 * @param message
	 */
	public HVWException(String message) {
		super(message);
	}
}
