package com.hmhs.hvwmid.exception;

public class ValidateRequest {

	private static final String PARAMETERVALUELOG = "<= parameter value =>";
	private static final String CMODFOLDERNAME = "cmodFolderName";

	public static String ACTION = "action";
	public static String ADDWORK = "addwork";
	public static String ADMINPWD = "adminpwd";
	public static String ADMINPWD1 = "adminpwd1";
	public static String ADMINPWD2 = "adminpwd2";
	public static String APPLIDCD = "applidcd";
	public static String ASGNEMPL = "asgnempl";
	public static String AUDIT = "audit";
	public static String AUTOSHOW = "autoshow";
	public static String BEGINDATE = "begindate";
	public static String BPDID = "bpdid";
	public static String BYPASSLOGIN = "bypasslogin";
	public static String CACHEFLUSH = "cacheflush";
	public static String CACHEPATH = "cachepath";
	public static String CACHEURL = "cacheurl";
	public static String CALLDIRSMART = "calldirsmart";
	public static String CALLNTLM = "callntlm";
	public static String CALLOAM = "calloam";
	public static String CDTYPE = "cdtype";
	public static String CDVERSION = "cdversion";
	public static String CLEN = "clen";
	public static String CODETABLEDITURL = "codetableediturl";
	public static String CODETABLEURL = "codetablegeturl";
	public static String COLLECTION = "collection";
	public static String CONFIGFILENAME = "configfilename";
	public static String CONNECTIONS = "connections";
	public static String CONTENTTYPE = "contenttype";
	public static String CONTINUE = "continue";
	public static String CRTESITE = "crtesite";
	public static String CSDAPPLIDS = "csdApplIds";
	public static String UMMAPPLIDS = "ummApplIds";
	public static String DEBUG = "debug";
	public static String DEFAULTFILE = "defaultfile";
	public static String DESCMASK = "descmask";
	public static String DESCRIPTION = "description";
	public static String DISPLACEMENT = "displacement";
	public static String DOCID = "docid";
	public static String DOCTKN = "doctkn";
	public static String DOWNLOAD = "download";
	public static String DROP = "drop";
	public static String ENDDATE = "enddate";
	public static String ENV = "env";
	public static String ENVS = "envs";
	public static String ERRTEMPLATE = "errtemplate";
	public static String FIELD = "field";
	public static String FILENAME = "filename";
	public static String FILEROOT = "fileroot";
	public static String FILETAB = "filetab";
	public static String FILETAB_ENDDATE = "enddate";
	public static String FILETAB_STARTDATE = "startdate";
	public static String FLEN = "flen";
	public static String FLDRID = "fldrid";
	public static String FOLDER = "folder";
	public static String FOLDERCOPY = "foldercopy";
	public static String FOLDERMOVE = "foldermove";
	public static String FOLDERCOUNT = "foldercount";
	public static String FOLDID = "foldid";
	public static String FOLDTKN = "foldtkn";
	public static String FORMNUM = "formnum";
	public static String FRAME = "frame";
	public static String FUNCTION = "function";
	public static String GROUP = "group";
	public static String HEADING = "heading";
	public static String HOLDDATE = "holddate";
	public static String HOLDTIME = "holdtime";
	public static String HOST = "host";
	public static String HOSTAUTHENTICATIONGROUP = "hostAuthenticationGroup";
	public static String HOSTPORT = "hostport";
	public static String INDXTYPE = "indxtype";
	public static String IMAGEKEY = "imagekey";
	public static String IMAGETITLE = "imagetitle";
	public static String IMGB2BGUI = "ImgB2BGui";
	public static String IMGCONNECT = "imgconnect";
	public static String INIT = "init";
	public static String IPADDR = "ipaddr";
	public static String LIMITCOUNT = "limitcount";
	public static String LISTALL = "listall";
	public static String LOAD = "load";
	public static String MACHINEIDVARIABLE = "machineIDvariable";
	public static String MASK = "mask";
	public static String MINUTES = "minutes";
	public static String MISC = "misc";
	public static String MODE = "mode";
	public static String NAME = "name";
	public static String NAMEMASK = "namemask";
	public static String NEWFORMNUM = "newformnum";
	public static String NEWOBJDESC = "newobjdesc";
	public static String NEWPASS1 = "newpass1";
	public static String NEWPASS2 = "newpass2";
	public static String NEWSPAGE = "newspage";
	public static String NEXTACTION = "nextaction";
	public static String NEXTACTIONNAME = "nextactionname";
	public static String NEXTACTIONTARGET = "nextactiontarget";
	public static String OBJDESC = "objdesc";
	public static String OBJNAME = "objname";
	public static String OBJTIME = "objtime";
	public static String ODCONNECT = "odconnect";
	public static String ODEXCEPTIONS = "odexceptions";
	public static String ODM = "odm";
	public static String ODMAX1 = "odmax1";
	public static String ODMAX2 = "odmax2";
	public static String ODPOOL1 = "odpool1";
	public static String ODPOOL2 = "odpool2";
	public static String ODTRAN1 = "odtran1";
	public static String ODTRAN2 = "odtran2";
	public static String PAGEPATH = "pagepath";
	public static String PASSWORD = "password";
	public static String PATH = "path";
	public static String PCONTINUE = "continue";
	public static String PREFIX = "prefix";
	public static String PROFILEPATH = "profilepath";
	public static String RCODE = "rcode";
	public static String REGION = "region";
	public static String REGIONS = "regions";
	public static String REMOTEIP = "remoteip";
	public static String RUNIT = "runit";
	public static String SESSIONFLUSH = "sessionflush";
	public static String SESSIONID = "sessionid";
	public static String SESSIONTIMEOUT = "sessiontimeout";
	public static String SHOWDELETED = "showdeleted";
	public static String SHOWTYPE = "showtype";
	public static String SIGNEDON = "signedon";
	public static String SRCHOP = "srchop";
	public static String STAGE = "stage";
	public static String TASK = "task";
	public static String TEMPLATE = "template";
	public static String TEMPLATE1 = "template";
	public static String TEMPLATEURL = "templateurl";
	public static String TIFF2PDF = "tiff2pdf";
	public static String TRANID = "tranid";
	public static String TRANSACTION = "transaction";
	public static String TRUSTEDREFERRERHEADER = "trustedReferrerHeader";
	public static String UNIQUECHARS = "uniquechars";
	public static String UNIT = "unit";
	public static String UPDATETEMPLATE = "updatetemplate";
	public static String URL = "url";
	public static String URLROOT = "urlroot";
	public static String USEREMOTEUSER = "useremoteuser";
	public static String USERID = "userid";
	public static String USERSTAT = "userstat";
	public static String WKSTATID = "wkstatid";
	public static String WSDEFAULTUSERID = "wsdefaultuserid";

	public ValidateRequest() {
	}

	/**
	 * This method will validate the IMI Generator UI fields on click of Select
	 * Inputs
	 * 
	 * @param request
	 * @param errorMessage
	 * @return
	 */
	// public boolean validateIMIGenSelectFile(HttpServletRequest request,
	// StringBuilder errorMessage) {
	// boolean valid = true;
	// Set<String> errorSet = new HashSet<>();
	// if (!validateParameter(request, errorSet, "inputFileTxt", "REGEX_FILENAME",
	// ImgGlobals2.REGEX_FILENAME)) {
	// valid = false;
	// }
	// if (!validateParameter(request, errorSet, "documentCountTxt",
	// "REGEX_NUMERIC", ImgGlobals2.REGEX_NUMERIC)) {
	// valid = false;
	// }
	// if (!validateParameter(request, errorSet, "filePriorityTxt", "REGEX_NUMERIC",
	// ImgGlobals2.REGEX_NUMERIC)) {
	// valid = false;
	// }
	// if (!validateParameter(request, errorSet, "naicCodeTxt",
	// "REGEX_ALPHANUMERIC",
	// ImgGlobals2.REGEX_ALPHANUMERIC)) {
	// valid = false;
	// }
	// if (!validateParameter(request, errorSet, "outputDirTxt", "REGEX_FILENAME",
	// ImgGlobals2.REGEX_FILENAME)) {
	// valid = false;
	// }
	// if (!valid) {
	// errorMessage.append("Please enter valid Fields:" + errorSet);
	// }
	// return valid;
	// }

	//
	//
	// /**
	// * updateAppl This method will validate the IMI Generator UI fields on click
	// of
	// * Create IMI
	// *
	// * @param request
	// * @param errorMessage
	// * @return
	// */
	// public boolean validateCreateIMI(HttpServletRequest request, StringBuilder
	// errorMessage) {
	// boolean valid = true;
	// Set<String> errorSet = new HashSet<>();
	// if (!validateParameter(request, errorSet, "dpkTxtConstant", "REGEX_DPK",
	// ImgGlobals2.REGEX_DPK)) {
	// valid = false;
	// }
	// if (!valid) {
	// errorMessage.append("Please enter valid Fields:" + errorSet);
	// }
	// return valid;
	// }
	//
	//
	//
	// /**
	// * This method will validate fields in the request
	// *
	// * @param request
	// * @param errorMessage
	// * @param parameterNm
	// * @return
	// */
	// public boolean validateParameter(HttpServletRequest request, Set<String>
	// errorMessage, String parameterNm,
	// String regexNm, String regex) {
	// boolean valid = true;
	// String paramValue = request.getParameter(parameterNm);
	// if (paramValue != null && paramValue.trim().length() > 0 &&
	// !paramValue.matches(regex)) {
	// errorMessage.add(parameterNm);
	// valid = false;
	// ImgLog.writeToLog(Level.ERROR, regexNm + " Validation failed for parameter
	// name =>" + parameterNm
	// + PARAMETERVALUELOG + paramValue + "<=");
	// }
	// return valid;
	// }

}
