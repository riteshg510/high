package com.hmhs.hvwmid.validations;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = MimeTypeValidator.class)
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidMimeType {
    String message() default "Invalid MIME type";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}