package com.hmhs.hvwmid.utils;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

/**
 * Utility class for creating IMI interchange files
 * Supports both text and binary segment formats
 * Implements AutoCloseable for proper resource management
 */
public class InterchangeFile implements AutoCloseable {
    private final DataOutputStream outputStream;
    private final String filePath;
    private boolean useBinaryFormat = true;

    /**
     * Creates a new InterchangeFile for the specified file path
     * @param filePath path to the output file
     * @throws IOException if file cannot be created
     */
    public InterchangeFile(String filePath) throws IOException {
        this.filePath = filePath;
        this.outputStream = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(filePath)));
    }
    
    /**
     * Creates a new InterchangeFile with specified format
     * @param filePath path to the output file
     * @param useBinaryFormat true for binary format, false for text format
     * @throws IOException if file cannot be created
     */
    public InterchangeFile(String filePath, boolean useBinaryFormat) throws IOException {
        this(filePath);
        this.useBinaryFormat = useBinaryFormat;
    }

    /**
     * Writes a text segment to the IMI file
     * @param segmentType type of segment (e.g., HDR, FID, IMG)
     * @param value value for the segment
     * @throws IOException if writing fails
     */
    public void writeSegment(String segmentType, String value) throws IOException {
        if (value == null) {
            value = "";
        }
        
        if (useBinaryFormat) {
            writeBinarySegment(segmentType, value.getBytes(StandardCharsets.UTF_8));
        } else {
            // Legacy text format
            byte[] segmentBytes = (segmentType + "|" + value + "\n").getBytes(StandardCharsets.UTF_8);
            outputStream.write(segmentBytes);
        }
    }
    
    /**
     * Writes a binary segment to the IMI file (e.g., for embedding files)
     * @param segmentType type of segment (e.g., IMG for images/PDFs)
     * @param data binary data for the segment
     * @throws IOException if writing fails
     */
    public void writeBinarySegment(String segmentType, byte[] data) throws IOException {
        if (!useBinaryFormat) {
            throw new IllegalStateException("Cannot write binary segment in text format mode");
        }
        
        if (segmentType == null || segmentType.length() != 3) {
            throw new IllegalArgumentException("Segment type must be exactly 3 characters");
        }
        
        if (data == null) {
            data = new byte[0];
        }
        
        // Binary format: 4 bytes length + 3 bytes segment ID + data
        int totalLength = 7 + data.length; // 4 bytes for length + 3 bytes for segment ID + data
        
        // Write 4-byte length in big-endian format
        ByteBuffer lengthBuffer = ByteBuffer.allocate(4);
        lengthBuffer.order(ByteOrder.BIG_ENDIAN);
        lengthBuffer.putInt(totalLength);
        outputStream.write(lengthBuffer.array());
        
        // Write 3-byte segment ID
        outputStream.write(segmentType.getBytes(StandardCharsets.US_ASCII), 0, 3);
        
        // Write segment data
        outputStream.write(data);
    }
    
    /**
     * Writes a file as a binary segment (typically for IMG segments)
     * @param segmentType type of segment (e.g., "IMG")
     * @param file file to embed in the segment
     * @throws IOException if reading file or writing fails
     */
    public void writeFileSegment(String segmentType, File file) throws IOException {
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + file.getAbsolutePath());
        }
        
        // Read file content
        byte[] fileContent = new byte[(int) file.length()];
        try (FileInputStream fis = new FileInputStream(file)) {
            int bytesRead = fis.read(fileContent);
            if (bytesRead != fileContent.length) {
                throw new IOException("Failed to read complete file: " + file.getName());
            }
        }
        
        writeBinarySegment(segmentType, fileContent);
    }
    
    /**
     * Writes a file as a binary segment using InputStream (for streaming large files)
     * @param segmentType type of segment (e.g., "IMG")
     * @param inputStream stream containing file data
     * @param fileSize size of the file
     * @throws IOException if reading stream or writing fails
     */
    public void writeFileSegment(String segmentType, InputStream inputStream, long fileSize) throws IOException {
        if (fileSize > Integer.MAX_VALUE - 7) {
            throw new IllegalArgumentException("File size too large for IMI segment: " + fileSize);
        }
        
        // Write header first
        int totalLength = 7 + (int) fileSize;
        ByteBuffer lengthBuffer = ByteBuffer.allocate(4);
        lengthBuffer.order(ByteOrder.BIG_ENDIAN);
        lengthBuffer.putInt(totalLength);
        outputStream.write(lengthBuffer.array());
        outputStream.write(segmentType.getBytes(StandardCharsets.US_ASCII), 0, 3);
        
        // Stream file content
        byte[] buffer = new byte[8192];
        int bytesRead;
        long totalBytesRead = 0;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, bytesRead);
            totalBytesRead += bytesRead;
        }
        
        if (totalBytesRead != fileSize) {
            throw new IOException("File size mismatch. Expected: " + fileSize + ", Read: " + totalBytesRead);
        }
    }

    /**
     * Flushes and closes the output stream
     * @throws IOException if closing fails
     */
    @Override
    public void close() throws IOException {
        if (outputStream != null) {
            outputStream.flush();
            outputStream.close();
        }
    }
    
    /**
     * Gets the file path of this IMI file
     * @return the file path
     */
    public String getFilePath() {
        return filePath;
    }
    
    /**
     * Checks if using binary format
     * @return true if binary format, false if text format
     */
    public boolean isUseBinaryFormat() {
        return useBinaryFormat;
    }
}
