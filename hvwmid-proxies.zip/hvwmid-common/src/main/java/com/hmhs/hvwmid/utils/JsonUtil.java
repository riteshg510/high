package com.hmhs.hvwmid.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;

public class JsonUtil {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static <T> T readJsonFromStream(InputStream inputStream, Class<T> valueType) throws IOException {
        return mapper.readValue(inputStream, valueType);
    }

    public static String toPrettyJson(Object object) throws IOException {
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
    }
}