package com.hmhs.hvwmid.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Component
public class RestClientUtil {
    @Value("${app.environment:default}")
    private String environment;

    @Value("${app.backend.server}")
    private String backendServer;

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Logger logger = LogManager.getLogger(RestClientUtil.class);

    private final RestTemplate restTemplate;

    public RestClientUtil() {
        this.restTemplate = new RestTemplate();
    }

    public RestClientUtil(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    private void saveCodRequestIdToThreadContext(HttpHeaders headers) {
        if (headers != null) {
            String codReqId = headers.getFirst("COD_REQUEST_ID");
            if (codReqId != null) {
                ThreadContext.put("COD_REQUEST_ID", codReqId);
            }
        }
    }

    public ResponseEntity<Map> postRequest(
            final String url,
            final String authToken,
            final Map<String, Object> body,
            final Map<String, String> extraHeaders) {

        if ("Noservice".equalsIgnoreCase(environment)) {
            logger.debug("Calling with dummy response");
            return getDummyResponse(url);
        }

        try {
            logger.debug("Making request to URL: {}", url);
            logger.debug("Request headers: Authorization: Bearer *****, Content-Type: {}", MediaType.APPLICATION_JSON);
            if (body != null) {
                logger.debug("Request body: {}", objectMapper.writeValueAsString(body));
            } else {
                logger.debug("Request body: null");
            }
        } catch (final Exception e) {
            logger.warn("Failed to log request body: {}", e.getMessage());
        }

        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (authToken != null && !authToken.isEmpty()) {
            headers.setBearerAuth(authToken);
            headers.set("x-highmark-jwt", removeBearer(authToken));
        }
        headers.set("x-hmhs-test-backend", backendServer);

        if (extraHeaders != null) {
            extraHeaders.forEach(headers::set);
        }

        final HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, entity, Map.class);
            saveCodRequestIdToThreadContext(response.getHeaders());
            return response;
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            saveCodRequestIdToThreadContext(e.getResponseHeaders());
            return handleHttpException(e);
        }
    }


    public ResponseEntity<Map> postRequest(final String url, final String authToken, final Map<String, Object> body) {
        if ("Noservice".equalsIgnoreCase(environment)) {
            logger.debug("Calling with dummy response");
            return getDummyResponse(url);
        }

        // Log request details for debugging
        try {
            logger.debug("Making request to URL: {}", url);
            logger.debug("Request headers: Authorization: Bearer *****, Content-Type: {}", MediaType.APPLICATION_JSON);
            if (body != null) {
                logger.debug("Request body: {}", objectMapper.writeValueAsString(body));
            } else {
                logger.debug("Request body: null");
            }
        } catch (final Exception e) {
            logger.warn("Failed to log request body: {}", e.getMessage());
        }

        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (authToken != null && !authToken.isEmpty()) {
            headers.setBearerAuth(authToken);
            headers.set("x-highmark-jwt", removeBearer(authToken));
        }
        headers.set("x-hmhs-test-backend", backendServer);

        final HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, entity, Map.class);
            saveCodRequestIdToThreadContext(response.getHeaders());
            return response;
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            saveCodRequestIdToThreadContext(e.getResponseHeaders());
            return handleHttpException(e);
        }
    }

    public ResponseEntity<ByteArrayResource> postRequestForBinary(final String url, final String authToken,
            final Map<String, Object> body) {
        if ("Noservice".equalsIgnoreCase(environment)) {
            logger.debug("Calling with dummy response for binary request");

            byte[] mockContent = new byte[0];

            ByteArrayResource mockResource = new ByteArrayResource(mockContent);

            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.setContentType(MediaType.APPLICATION_PDF);
            responseHeaders.setContentDispositionFormData("attachment", "mocked-file.pdf");
            responseHeaders.setContentLength(mockContent.length);

            return new ResponseEntity<>(mockResource, responseHeaders, HttpStatus.OK);
        }

        // Log request details for debugging
        try {
            logger.debug("Making binary request to URL: {}", url);
            logger.debug("Request headers: Authorization: Bearer *****, Content-Type: {}", MediaType.APPLICATION_JSON);
            if (body != null) {
                logger.debug("Request body: {}", objectMapper.writeValueAsString(body));
            } else {
                logger.debug("Request body: null");
            }
        } catch (final Exception e) {
            logger.warn("Failed to log request body: {}", e.getMessage());
        }

        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (authToken != null && !authToken.isEmpty()) {
            headers.setBearerAuth(authToken);
            headers.set("x-highmark-jwt", removeBearer(authToken));
        }

        final HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        try {
            final ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.POST, entity, byte[].class);
            saveCodRequestIdToThreadContext(response.getHeaders());
            final ByteArrayResource resource = new ByteArrayResource(response.getBody());

            final HttpHeaders responseHeaders = new HttpHeaders();

            // Get the content type from the response, default to application/octet-stream
            // if not specified
            MediaType contentType = response.getHeaders().getContentType();
            if (contentType == null) {
                contentType = MediaType.APPLICATION_OCTET_STREAM;
            }
            responseHeaders.setContentType(contentType);

            // Set content disposition to attachment with filename if available
            final String filename = getFilenameFromHeaders(response.getHeaders());
            if (filename != null) {
                responseHeaders.setContentDispositionFormData("attachment", filename);
            }

            // Log document size if available
            final String documentSize = response.getHeaders().getFirst("documentSize");
            if (documentSize != null) {
                logger.debug("Document size from header: {} bytes", documentSize);
            }
            logger.debug("Actual response body size: {} bytes", response.getBody().length);

            responseHeaders.setContentLength(resource.contentLength());

            return new ResponseEntity<>(resource, responseHeaders, response.getStatusCode());
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            saveCodRequestIdToThreadContext(e.getResponseHeaders());
            // For binary requests, convert HTTP exceptions to empty responses with
            // appropriate status codes
            logger.error("HTTP error during binary request: {} - {}", e.getStatusCode(), e.getStatusText());

            // Try to extract error details from the response
            final String errorMessage = e.getResponseBodyAsString();
            logger.debug("Error response body: {}", errorMessage);

            // Create empty response with the same status code
            final HttpHeaders errorHeaders = new HttpHeaders();
            errorHeaders.setContentType(MediaType.APPLICATION_JSON);

            // Create an empty resource
            final ByteArrayResource emptyResource = new ByteArrayResource(new byte[0]);

            return new ResponseEntity<>(emptyResource, errorHeaders, e.getStatusCode());
        }
    }

    private String getFilenameFromHeaders(final HttpHeaders headers) {
        final String contentDisposition = headers.getFirst(HttpHeaders.CONTENT_DISPOSITION);
        if (contentDisposition != null) {
            // Split on filename= and take the last part
            final String[] parts = contentDisposition.split("filename=");
            if (parts.length > 1) {
                // Remove any quotes and trim
                final String filename = parts[1].replaceAll("^[\"']|[\"']$", "").trim();
                logger.debug("Extracted filename from Content-Disposition: {}", filename);
                return filename;
            }
        }
        logger.warn("No filename found in Content-Disposition header");
        return null;
    }

    /**
     * Handle HTTP exceptions by parsing the JSON error response body
     * 
     * @param e The HTTP exception
     * @return A ResponseEntity with the parsed error response
     */
    ResponseEntity<Map> handleHttpException(final HttpStatusCodeException e) {
        logger.error("HTTP error occurred: {} - {}", e.getStatusCode(), e.getResponseBodyAsString());

        try {
            // Try to parse the response body
            String responseBody = e.getResponseBodyAsString();

            // Check if it contains our standard error format
            if (responseBody.contains("serviceMessage") &&
                    (responseBody.contains("returnCode") || responseBody.contains("returnCodeDescription"))) {

                // Clean up escaped quotes
                responseBody = responseBody.replace("\\\"", "\"");

                // Remove surrounding quotes if present
                if (responseBody.startsWith("\"") && responseBody.endsWith("\"")) {
                    responseBody = responseBody.substring(1, responseBody.length() - 1);
                }

                try {
                    // Try to parse as a Map
                    final Map errorMap = objectMapper.readValue(responseBody, Map.class);
                    return new ResponseEntity<>(errorMap, e.getStatusCode());
                } catch (final Exception ex) {
                    logger.debug("Failed to parse error response as Map: {}", ex.getMessage());
                }
            }

            // Fallback: construct a simple error response with the same format
            final Map<String, Object> errorResponse = new HashMap<>();
            final Map<String, Object> serviceMessage = new HashMap<>();

            // Extract OAuth token errors
            if (responseBody.contains("Expired OAuth token")) {
                serviceMessage.put("returnCode", 30);
                serviceMessage.put("returnCodeDescription", "Authentication token expired. Please log in again.");
            } else {
                serviceMessage.put("returnCode", e.getRawStatusCode());
                serviceMessage.put("returnCodeDescription", responseBody);
            }

            errorResponse.put("serviceMessage", serviceMessage);
            errorResponse.put("status", "error");
            errorResponse.put("message", serviceMessage.get("returnCodeDescription"));

            return new ResponseEntity<>(errorResponse, e.getStatusCode());

        } catch (final Exception ex) {
            // If all parsing fails, return a simple error response
            logger.error("Failed to parse error response: {}", ex.getMessage());
            final Map<String, Object> errorResponse = new HashMap<>();
            final Map<String, Object> serviceMessage = new HashMap<>();
            serviceMessage.put("returnCode", e.getRawStatusCode());
            serviceMessage.put("returnCodeDescription", "Error calling external service: " + e.getMessage());
            errorResponse.put("serviceMessage", serviceMessage);
            errorResponse.put("status", "error");
            errorResponse.put("message", serviceMessage.get("returnCodeDescription"));

            return new ResponseEntity<>(errorResponse, e.getStatusCode());
        }
    }

    public static String removeBearer(final String token) {
        if (token != null && token.startsWith("Bearer ")) {
            return token.substring(7); // Remove "Bearer " (length = 7)
        }
        return token; // Return as-is if "Bearer " is not present
    }

    private ResponseEntity<Map> getDummyResponse(final String url) {
        try {
            final String[] parts = url.split("/");
            final int length = parts.length;
            final String endpoint = (length >= 2) ? parts[length - 2] + "_" + parts[length - 1] : parts[length - 1];

            final String fileName = endpoint + ".json";
            final File file = new ClassPathResource("data/" + fileName).getFile();
            logger.debug(file.getAbsolutePath());
            final Map dummyResponse = objectMapper.readValue(file, Map.class);
            return new ResponseEntity<>(dummyResponse, HttpStatus.OK);
        } catch (final IOException e) {
            logger.error(e.getMessage());
            return new ResponseEntity<>(Map.of("error", "Dummy response not found"), HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Posts a multipart request containing both JSON data and a file
     * 
     * @param url           The URL to post to
     * @param authToken     The authorization token
     * @param multipartData The multipart data containing the JSON and file parts
     * @return A ResponseEntity with the response body as a Map
     */
    public ResponseEntity<Map> postMultipartRequest(final String url, final String authToken,
            final org.springframework.util.MultiValueMap<String, Object> multipartData) {
        if ("Noservice".equalsIgnoreCase(environment)) {
            logger.debug("Calling with dummy response for multipart request");
            return getDummyResponse(url);
        }

        // Log request details for debugging
        logger.debug("Making multipart request to URL: {}", url);
        logger.debug("Request headers: Authorization: Bearer *****, Content-Type: {}", MediaType.MULTIPART_FORM_DATA);

        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        if (authToken != null && !authToken.isEmpty()) {
            headers.setBearerAuth(removeBearer(authToken));
            headers.set("x-highmark-jwt", removeBearer(authToken));
        }
        headers.set("x-hmhs-test-backend", backendServer);

        final HttpEntity<org.springframework.util.MultiValueMap<String, Object>> entity = new HttpEntity<>(
                multipartData, headers);

        try {
            ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.POST, entity, Map.class);
            saveCodRequestIdToThreadContext(response.getHeaders());
            return response;
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            saveCodRequestIdToThreadContext(e.getResponseHeaders());
            return handleHttpException(e);
        }
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public void setBackendServer(String backendServer) {
        this.backendServer = backendServer;
    }
	
	/**
     * Posts a request to IMI (Image Management Interface) service with JSON content type
     * 
     * @param url           The URL to post to
     * @param authToken     The authorization token
     * @param userId        The user ID for the request
     * @param requestBody   The request body object (will be converted to JSON)
     * @param responseType  The class type for response deserialization
     * @return A ResponseEntity with the response body of the specified type
     */
    public <T> ResponseEntity<T>  postIMIRequest(final String url, final String authToken, 
            final Object requestBody, final Class<T> responseType) {
        if ("Noservice".equalsIgnoreCase(environment)) {
            logger.debug("Calling with dummy response for IMI request");
            return null;
        }

        // Log request details for debugging
        try {
            logger.debug("Making IMI request to URL: {}", url);
            logger.debug("Request headers: Authorization: Bearer *****, Content-Type: {}", MediaType.APPLICATION_JSON);
            if (requestBody != null) {
                logger.debug("Request body: {}", objectMapper.writeValueAsString(requestBody));
            } else {
                logger.debug("Request body: null");
            }
        } catch (final Exception e) {
            logger.warn("Failed to log request body: {}", e.getMessage());
        }

        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(java.util.Arrays.asList(MediaType.APPLICATION_JSON));
        if (authToken != null && !authToken.isEmpty()) {
            headers.setBearerAuth(authToken);
            headers.set("x-highmark-jwt", removeBearer(authToken));
        }
        
        headers.set("x-hmhs-test-backend", backendServer);

        final HttpEntity<Object> entity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<T> response = restTemplate.exchange(url, HttpMethod.POST, entity, responseType);
            saveCodRequestIdToThreadContext(response.getHeaders());
            return response;
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            saveCodRequestIdToThreadContext(e.getResponseHeaders());
            return handleIMIHttpException(e, responseType);
        }
    }

    /**
     * Handle HTTP exceptions for IMI requests by using the existing handleHttpException method
     * 
     * @param e The HTTP exception
     * @param responseType The expected response type
     * @return A ResponseEntity with error details
     */
    private <T> ResponseEntity<T> handleIMIHttpException(final HttpStatusCodeException e, final Class<T> responseType) {
        logger.error("HTTP error during IMI request: {} - {}", e.getStatusCode(), e.getStatusText());

        try {
            // Use the existing handleHttpException method to get the error response
            ResponseEntity<Map> errorResponse = handleHttpException(e);
            
            // Convert the Map response to the expected type using ObjectMapper
            if (errorResponse.getBody() != null) {
                T typedResponse = objectMapper.convertValue(errorResponse.getBody(), responseType);
                return new ResponseEntity<>(typedResponse, errorResponse.getStatusCode());
            } else {
                // If no body, return null with the status code
                return new ResponseEntity<>(null, errorResponse.getStatusCode());
            }

        } catch (final Exception ex) {
            logger.error("Failed to handle IMI error response: {}", ex.getMessage());
            return new ResponseEntity<>(null, e.getStatusCode());
        }
    }
    
    /**
     * Makes a GET request to the specified URL
     * 
     * @param url       The URL to make the GET request to
     * @param authToken The authorization token (optional)
     * @return A ResponseEntity with the response body as a Map
     */
    public <T> ResponseEntity<T> getRequest(final String url, final String authToken, final Class<T> responseType) {
       
        // Log request details for debugging
        try {
            logger.debug("Making GET request to URL: {}", url);
            logger.debug("Request headers: Authorization: Bearer *****");
        } catch (final Exception e) {
            logger.warn("Failed to log GET request details: {}", e.getMessage());
        }

        final HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(java.util.Arrays.asList(MediaType.APPLICATION_JSON));
        if (authToken != null && !authToken.isEmpty()) {
            headers.setBearerAuth(authToken);
            headers.set("x-highmark-jwt", removeBearer(authToken));
        }
        headers.set("x-hmhs-test-backend", backendServer);

        final HttpEntity<Void> entity = new HttpEntity<>(headers);

        try {
            ResponseEntity<T> response = restTemplate.exchange(url, HttpMethod.GET, entity, responseType);
            return response;
        } catch (HttpClientErrorException | HttpServerErrorException e) {
        	 return handleIMIHttpException(e, responseType);
        }
    }
}