package com.hmhs.hvwmid.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.constants.ImgGlobals2Constants.IMIHostName;

@Component
public class HVWUtils {

	private static Logger logger = LogManager.getLogger();
	 private static final String DEFAULT_HOSTNAME = "HOSTNAME";

	private static String environment;

	@Value("${app.environment:default}")
	public void setEnvironment(String env) {
		environment = env;
	}
	private static String fileCabinetOnDemandListing;

    @Value("${app.file-cabinet-on-demand-listing:}")
    public void setFileCabinetOnDemandListing(String value) {
        fileCabinetOnDemandListing = value;
    }


	private static final String RMAGROUPNAMEPREFIX = "RMA-";

	public static List<String> getDevGroupsList() {
		return List.of("HVW-ADMINISTRATION-INT", "HVW-COVERSHEET-GATEWAY-MEDICAID-MAINT-INT",
				"IMI-ACTIVITYTRK-HMRK-54771-INT", "RPIC-READ ONLY-INT", "COD-ADMINISTRATION-INT", "TENVE-USERS-INT",
				"HVW-LISTING-BCBSND-INT", "IMAGE-INTRANET-WEBSERVICES-INT", "IMG-ADMINISTRATION-INT",
				"HVW-LISTING-IBC-INT", "HM Employee-INT", "IMI-ADMINISTRATION-INT", "RMA-HMRK-IMAGE-PA-1-INT",
				"IMI-ACTIVITYTRK-UPDATE-INT", "HM User-INT", "HVW-COVERSHEET-COMMON-PRINT-INT",
				"HVW-COVERSHEET-HIGHMARK-PRINT-INT", "HVW-LISTING-HMRK-INT", "HVW-ADMINISTRATION-NONRESTRICTED-INT",
				"HVW-LISTING-BCBSMN-INT", "HVW-LISTING-BCBSWY-INT", "HVW-CODEBASE-INT",
				"HVW-COVERSHEET-HIGHMARK-MAINT-INT", "DR-01 0-DYN, DR-02 IN-DYN", "HVW-LISTING-MEDICARE-INT");
	}

	public enum SCHEMANAMES {
		TENV1("DB2TEST", "TST1"), TENV2("DB2TST2", "TST2"), TENV3("DB2TST3", "TST3"), TENV4("DB2TST4", "TST4"),
		TENV5("DB2TST5", "TST5"), TENV6("DB2TST6", "TST6"), TENV7("DB2TST7", "TST7"), TENVA("DB2TSTA", "TSTA"),
		TENVB("DB2TSTB", "TSTB"), TENVC("DB2TSTC", "TSTC"), TENVD("DB2TSTD", "TSTD"), TENVE("DB2TSTE", "TSTE"),
		PENV("DB2PROD", "PBS"), LOCAL("DB2INST1", "DB2INST1");

		private String schemaName;
		private String collectionName;

		SCHEMANAMES(String schemaName, String collectionName) {
			this.schemaName = schemaName;
			this.collectionName = collectionName;
		}

		public String getSchemaName() {
			return schemaName;
		}

		public String getCollectionName() {
			return collectionName;
		}
	}

	/**
	 * This method will return true if the input text is not empty otherwise it will
	 * return false
	 * 
	 * @param input input string
	 * @return boolean
	 */
	public static boolean hasText(String input) {
		return (input != null && input.trim().length() > 0);
	}

	/**
	 * This method is used to parse String value to int data.
	 * 
	 * @param data
	 * @param defaultValue
	 * @return int value
	 */
	public static int stringToInt(String data, int defaultValue) {
		int parsedValue = defaultValue;
		try {
			parsedValue = Integer.parseInt(data);
		} catch (Exception e) {
			logger.fatal(() -> "Error in parsing String =>" + data + "<= .", e);
		}
		return parsedValue;
	}

	public static String removeBearer(String token) {
		if (token != null && token.startsWith("Bearer ")) {
			return token.substring(7); // Remove "Bearer " (length = 7)
		}
		return token; // Return as-is if "Bearer " is not present
	}

	public static String getUserIdFromJWT(String authToken) {

		// Check if we're in Noservice mode based on environment variable
		boolean isNoserviceEnv = isIsNoserviceEnv();

		// When in Noservice mode and token is null/empty, return default user
		if (isNoserviceEnv && (authToken == null || authToken.isEmpty())) {
			logger.debug("Using default local user ID in Noservice mode (null token)");
			return HVWConstants.UID;
		}

		// Try to parse the token if present
		try {
			if (authToken != null && !authToken.isEmpty()) {
				String tokenValue = removeBearer(authToken);
				DecodedJWT jwt = JWT.decode(tokenValue);

				// Check token expiration
				Date expireDate = jwt.getExpiresAt();
				if (expireDate != null && expireDate.before(Calendar.getInstance().getTime())) {
					logger.log(Level.ERROR, () -> "getUserIdFromJWT, JWT token already expired =>" + expireDate + "<=");
					if (!isNoserviceEnv) {
						return "";
					}
				} else {
					// Prefer uid if present and non-empty
					String uid = jwt.getClaim("uid").asString();
					if (uid != null && !uid.isEmpty()) {
						logger.log(Level.DEBUG, () -> "Userid retrieved from JWT claim 'uid': " + uid);
						return uid;
					}
					// If no uid, try appid
					String appId = jwt.getClaim("appid").asString();
					if (appId != null && !appId.isEmpty()) {
						logger.log(Level.DEBUG, () -> "AppId retrieved from JWT claim 'appid': " + appId);
						return appId;
					}
					// Fallback to subject if neither present
					String subject = jwt.getSubject();
					if (subject != null && !subject.isEmpty()) {
						logger.log(Level.DEBUG, () -> "Subject retrieved from JWT: " + subject);
						return subject;
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error parsing JWT token: {}", e.getMessage());
		}

		// If we're in Noservice mode, return a default user instead of failing
		if (isNoserviceEnv) {
			logger.debug("Using default local user ID in Noservice mode (token parsing failed)");
			return HVWConstants.UID;
		}

		return "";
	}

	public static boolean isIsNoserviceEnv() {
		return "Noservice".equalsIgnoreCase(environment);
	}

	public static Map<String, String> extractBpdIds(String authToken) {
		List<String> userGroups = getUserGroups(authToken);
		Map<String, String> accessMap = new HashMap<>();
		if (userGroups != null && !userGroups.isEmpty()) {
			for (String group : userGroups) {
				if (group.startsWith(RMAGROUPNAMEPREFIX)) {				
					String[] groupString = group.split("-");
					if (groupString.length == 6) {
						String clientName = groupString[1];
						String state = groupString[3];
						String bpdId = groupString[4];
						String clientDesc = clientName + "-" + state;
						if (!accessMap.containsKey(bpdId)) {
							accessMap.put(bpdId, clientDesc);
						}
					}
				}
			}
			if (accessMap.isEmpty()) {
				logger.warn("User does not have access to the Records Manager groups. Request access to the Records Manager groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->RMA Groups");
			}
		}

		return accessMap;
	}

	/**
	 * This method will return the user groups from the JWT token, in ismemberof
	 * separated by comma
	 *
	 * @param authToken
	 * @return List of user groups
	 */
	public static List<String> getUserGroups(String authToken) {
        List<String> groups = new ArrayList<>();
        List<String> companyCodes = new ArrayList<>();

        try {
            boolean isNoserviceEnv = "Noservice".equalsIgnoreCase(environment);
            if (isNoserviceEnv) {
                logger.info("Environment is 'Noservice'. Returning dev group list.");
                return getDevGroupsList();
            }


            if (authToken != null && !authToken.isEmpty()) {
				String tokenValue = removeBearer(authToken);
				DecodedJWT jwt = JWT.decode(tokenValue);

				Date expireDate = jwt.getExpiresAt();
				if (expireDate != null && expireDate.before(Calendar.getInstance().getTime())) {
					logger.log(Level.ERROR,
							() -> "getUserGroups, JWT token already expired =>" + expireDate + "<=");
				
					return List.of();
				}
             

                String rawGroupsStr = jwt.getClaim("ismemberof").asString();
                if (rawGroupsStr != null && !rawGroupsStr.isEmpty()) {
                    groups.addAll(List.of(rawGroupsStr.split(",\\s*")));
                    logger.debug("Extracted user groups from JWT: {}", groups);
                }

                String companyCodeStr = jwt.getClaim("companycode").asString();
                if (companyCodeStr != null && !companyCodeStr.isEmpty()) {
                    companyCodes.addAll(List.of(companyCodeStr.split(",\\s*")));
                    logger.debug("Extracted company codes from JWT: {}", companyCodes);
                }
            

            Map<String, String> companyCodeGroupMap = new HashMap<>();
            if (fileCabinetOnDemandListing != null && !fileCabinetOnDemandListing.isEmpty()) {
                String[] entries = fileCabinetOnDemandListing.split(";|\\\n");
                for (String entry : entries) {
                    String[] parts = entry.trim().split(",");
                    if (parts.length == 2) {
                        companyCodeGroupMap.put(parts[0].trim(), parts[1].trim());
                    }
                }
                logger.debug("Parsed company code to group mapping: {}", companyCodeGroupMap);
            }

            for (String code : companyCodes) {
                String group = companyCodeGroupMap.get(code);
                if (group != null && !groups.contains(group)) {
                    groups.add(group);
                }
            }
		}
        } catch (Exception ex) {
            logger.error("Error while extracting user groups from JWT token", ex);
        }

        return groups;
    }

	/**
	 * This method will return the schema corresponding to the environment.
	 * 
	 * @param environment
	 * @return
	 */
	public static String getCollection(String environment) {
		try {
			SCHEMANAMES schema = SCHEMANAMES.valueOf(environment.toUpperCase());
			return schema.getCollectionName();
		} catch (Exception ex) {
			return SCHEMANAMES.PENV.getCollectionName();
		}
	}
	


	/**
	 * Creates a timestamp in the format yyyyMMddHHmmssSSS
	 * 
	 * @return formatted timestamp string
	 */
	public static String createMfTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		return sdf.format(new Date());
	}

	// Transmit File Status Codes
	public enum TransmitFileStatusCd {
		A("Accepted"), R("Rejected"), C("Completed");

		private String statusDesc;

		private TransmitFileStatusCd(String statusDesc) {
			this.statusDesc = statusDesc;
		}

		public String getStatusDesc() {
			return statusDesc;
		}
	}

	// Process File Status Codes
	public enum ProcessFileStatusCd {
		V("Validation (Ready for)"), K("Acknowledge (Ready for)"), T("Transformation (Ready for)"),
		F("Finalization (Ready for)"), E("Error"), C("Completed");

		private String statusDesc;

		private ProcessFileStatusCd(String statusDesc) {
			this.statusDesc = statusDesc;
		}

		public String getStatusDesc() {
			return statusDesc;
		}
	}

	// Document Status Codes
	public enum DocumentStatusCd {
		A("Accepted"), X("Batch Capture (Ready for)"), I("Image Store (Ready for)"), L("Non-claim OCR (Ready for)"),
		P("CMOD (Ready for)"), O("Claim OCR (Ready for)"), J("Claim OCR Completed"), S("Stored"), M("CMOD Stored"),
		Y("Original Completed"), F("Finalization (Ready for)"), E("Error"), R("Rejected");

		private String statusDesc;

		private DocumentStatusCd(String statusDesc) {
			this.statusDesc = statusDesc;
		}

		public String getStatusDesc() {
			return statusDesc;
		}
	}

	public static Map<String, String> buildNAICMap(List<String> userGroups) {
		Map<String, String> naicMap = new HashMap<>();

		if (userGroups != null && !userGroups.isEmpty()) {
			for (String group : userGroups) {
				if (group.startsWith(HVWConstants.IMIGROUPNAMEPREFIX)) {
					String[] groupString = group.split("-");
					if (groupString.length == 5) {
						String naicName = groupString[2];
						String naicValue = groupString[3];
						naicMap.put(naicName, naicValue);
					} else if (!"IMI-ACTIVITYTRK-UPDATE-INT".equals(group)) {
						logger.debug("IMI Group =>{}<= is not in the format IMI-ACTIVITYTRK-name-naic-INT", group);
					}
				}
			}

			if (!naicMap.isEmpty()) {
				naicMap = naicMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).collect(Collectors.toMap(
						Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue, LinkedHashMap::new));
			}
		}

		return naicMap;
	}

	/**
	 * This method will concatenate the strings
	 * 
	 * @param messages
	 * @return
	 */
	public static String concatenateStrings(String... messages) {
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < messages.length; i++) {
			builder.append(messages[i]);
		}
		return builder.toString();
	}

	/**
	 * Converts TransmitFileStatusCd code to its description using HVWUtils enum
	 * 
	 * @param statusCode The status code (e.g., "A", "R", "C")
	 * @return The status description or the original code if not found
	 */
	public static String convertTransmitFileStatusCd(String statusCode) {
		if (hasText(statusCode)) {
			try {
				TransmitFileStatusCd status = TransmitFileStatusCd.valueOf(statusCode);
				return status.getStatusDesc();
			} catch (IllegalArgumentException e) {
				logger.debug("Unknown TransmitFileStatusCd: {}", statusCode);
				return statusCode; // Return original code if not found in enum
			}
		}
		return statusCode;
	}

	/**
	 * Converts ProcessFileStatusCd code to its description using HVWUtils enum
	 * 
	 * @param statusCode The status code (e.g., "V", "K", "T", "F", "E", "C")
	 * @return The status description or the original code if not found
	 */
	public static String convertProcessFileStatusCd(String statusCode) {
		if (hasText(statusCode)) {
			try {
				ProcessFileStatusCd status = ProcessFileStatusCd.valueOf(statusCode);
				return status.getStatusDesc();
			} catch (IllegalArgumentException e) {
				logger.debug("Unknown ProcessFileStatusCd: {}", statusCode);
				return statusCode; // Return original code if not found in enum
			}
		}
		return statusCode;
	}

	/**
	 * Converts DocumentStatusCd code to its description using HVWUtils enum
	 * 
	 * @param statusCode The status code (e.g., "A", "X", "I", "L", "P", "O", "J",
	 *                   "S", "M", "Y", "F", "E", "R")
	 * @return The status description or the original code if not found
	 */
	public static String convertDocumentStatusCd(String statusCode) {
		if (hasText(statusCode)) {
			try {
				DocumentStatusCd status = DocumentStatusCd.valueOf(statusCode);
				return status.getStatusDesc();
			} catch (IllegalArgumentException e) {
				logger.debug("Unknown ProcessFileStatusCd: {}", statusCode);
				return statusCode; // Return original code if not found in enum
			}
		}
		return statusCode;
	}

	public static <T extends Enum<T>> String getDescription(Class<T> enumClass, String value) {
		try {
			T enumConstant = Enum.valueOf(enumClass, value.toUpperCase());

			// Use reflection to call getDescription() if it exists
			try {
				return (String) enumClass.getMethod("getStatusDesc").invoke(enumConstant);
			} catch (NoSuchMethodException e) {
				return enumConstant.name(); // fallback if no getDescription() method
			}

		} catch (IllegalArgumentException e) {
			return "Invalid value for " + enumClass.getSimpleName();
		} catch (Exception e) {
			throw new RuntimeException("Error reading description from " + enumClass.getSimpleName(), e);
		}
	}

	/**
	 * Gets the hostname based on the current environment.
	 *
	 */
	public static String getHostname() {
		try {
			IMIHostName hostName = IMIHostName.valueOf(environment.toUpperCase());
			return hostName.getHostName();
		} catch (Exception ex) {
			logger.error("Error getting hostname for environment: {}", environment, ex);
			return DEFAULT_HOSTNAME;
		}
	}
	
	/**
	 * Checks if the user has a segment data access based on LDAP group.
	 * 
	 * @param authToken The OAuth token containing user group information
	 * @param groupName The LDAP group name to check for (case-sensitive)
	 * @return true if the user has the specified group, false otherwise
	 */
	public static boolean hasPhiAccess(String authToken, String groupName) {
		if (!hasText(authToken) || !hasText(groupName)) {
			logger.debug("Invalid input parameters: authToken or groupName is null/empty");
			return false;
		}

		try {
			List<String> userGroups = getUserGroups(authToken);
			if (userGroups == null || userGroups.isEmpty()) {
				logger.debug("No LDAP groups found for user");
				return false;
			}

			// Support comma-separated list of required groups in groupName
			String[] requiredGroups = groupName.split(",\\s*");
			for (String required : requiredGroups) {
				if (hasText(required) && userGroups.contains(required.trim())) {
					return true;
				}
			}
			return false;
		} catch (Exception e) {
			logger.error("Error checking LDAP group '{}' for user: {}", groupName, e.getMessage(), e);
			return false;
		}
	}

}
