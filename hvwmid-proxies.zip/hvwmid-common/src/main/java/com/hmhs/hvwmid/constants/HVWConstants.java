package com.hmhs.hvwmid.constants;

/**
 * @author Ramanjaneyulu Manam on Feb 6, 2025
 */
public class HVWConstants {



	private HVWConstants() {
	}
	public static final String REQUEST_ID = "RequestId";
	public static final String AUTHORIZATION = "authorization";
	public static final String ERRPROREQ = "Error processing request: ";
	public static final String ACT = "action";
	public static final String DOWNLOAD = "download";
	public static final String CMODACT = "Action";
	public static final String STRING = "string";
	public static final String YMD = "YYYYMMDD";
	public static final String YYMD = "yyyy-MM-dd";
	public static final String YYMMDD = "yyyy-MM-DD";
	public static final String FLAG = "boolean";
	public static final String DELETE = "delete";
	public static final String ACTYPE = "actionType";
	public static final String TEMPLATE = "template";
	public static final String SINGLECABINET = "pages/single-cabinet/";
	public static final String CABINETSCAN = "pages/cabinets-scan/";
	public static final String WORKFLOW = "pages/workflow/";
	public static final String SINGLEREPORT = "pages/single-report/CMOD";
	public static final String CMODFOLDERNAME = "name";
	public static final String CMBASE = "CMBASE";
	public static final String PARMIDFORAPPLIST = "CMFLDSTK";
	public static final String AUTH_HEADER = "x-highmark-jwt";

	public static final String HVWBASE = "HVWBASE";
	public static final String HVWLOGIN = "HVWLOGIN";
	public static final String RMPOLTYP = "RMPOLTYP";
	public static final String HVWMPCFG = "HVWMPCFG";
	public static final String CODBASE = "CODBASE";
	public static final String CMFLDMAP = "CMFLDMAP";
	public static final String CMUSEREX = "CMUSEREX";
	public static final String CMSARA = "CMSARA";
	public static final String CMAPPCD = "CMAPPCD";
	public static final String CMIDXRM = "CMIDXRM";
	public static final String ODCMFDMP = "ODCMFDMP";
	public static final String CODTSENV = "CODTSENV";
	public static final String HVWCOMM = "HVWCOMM";
	public static final String HVWOAUTH = "HVWOAUTH";
	// Hold for local use
	public static final String UID = "liduser";
	
	// IMI Constants
	public static final String SPACE = " ";
	public static final String PARMID_HVW_IMI = "HVWIMI";
	public static final String PARMKEY_ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT = "ACTIVITYTRACKING_RETRIEVE_RESULTSCOUNT";
	public static final int WSCONNECTTIMEOUT = 30;
	public static final int WSREADTIMEOUT = 30;
	public static final String IMIGROUPNAMEPREFIX = "IMI-ACTIVITYTRK-";
	public static final String PARMID_HVW_IMICOM = "IMICOMM";
	public static final String PARMKEY_IMICOM_CMOD_DATE_THRESHOLD = "CMOD_SEARCH_LINK_DATE";

	// Hold for local use ImageData
	public static final String FID = "foldid";
	public static final String FNAME = "FolderName";
	public static final String IMGNAME = "ImageName";
	public static final String PRBUEOB = "PRIVATE BUSINESS EOBS";
	public static final String ACTID = "ActionId";
	public static final String OPIMG = "Open Image";

	public static final String CMOD_ARSXML_COD_DIRECTORY = "/n01/data/cod/PENV/arsxml";
	public static final String CMOD_PRODUCT_DTS_TRIAGE = "CMOD_PRODUCT_DTS_TRIAGE";
	public static final String CMOD_ARSXML_DIRECTORY = "/n01/data/cod/PENV/codarsxml";
	public static final String MAINFRAME_FOLDERAGAPP_EXPORT_FILENAME = "FLDR-PERMS-EXPORT.xml";
}
