package com.hmhs.hvwmid.validations;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Set;

public class MimeTypeValidator implements ConstraintValidator<ValidMimeType, String> {

    private static final Set<String> ALLOWED_MIME_TYPES = Set.of(
            "application/pdf",
            "text/html",
            "application/x-javascript"
    );

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value == null || ALLOWED_MIME_TYPES.contains(value);
    }
}