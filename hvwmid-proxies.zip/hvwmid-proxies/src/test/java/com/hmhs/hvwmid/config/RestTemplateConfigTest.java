package com.hmhs.hvwmid.config;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = RestTemplateConfig.class)
@Import(RestTemplateConfig.class)
class RestTemplateConfigTest {

    @Autowired
    private RestTemplate restTemplate;

    @Test
    void restTemplate_isCreatedAndUsesSimpleClientHttpRequestFactory() {
        assertNotNull(restTemplate, "RestTemplate should not be null");

        assertInstanceOf(SimpleClientHttpRequestFactory.class, restTemplate.getRequestFactory(), "RestTemplate should use SimpleClientHttpRequestFactory");
    }
}
