package com.hmhs.hvwmid.config;

import org.apache.http.client.config.RequestConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.retry.support.RetryTemplate;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class HttpConnectionConfigTest {

    private HttpConnectionConfig config;

    @BeforeEach
    public void setUp() {
        config = new HttpConnectionConfig();
        config.setSocketTimeout(5000);
        config.setUser("test-user");
        config.setPass("test-pass");
        config.setUrl("https://example.com");
    }

    @Test
    void testRequestConfigValues() throws Exception {
        Method method = HttpConnectionConfig.class.getDeclaredMethod("requestConfig");
        method.setAccessible(true);
        RequestConfig requestConfig = (RequestConfig) method.invoke(config);

        assertEquals(5000, requestConfig.getSocketTimeout());
        assertTrue(requestConfig.isRedirectsEnabled());
        assertTrue(requestConfig.isRelativeRedirectsAllowed());
    }

    @Test
    void testRetryTemplateConfiguration() {
        RetryTemplate retryTemplate = config.retryTemplate();
        assertNotNull(retryTemplate);
    }

    @Test
    void testHttpClientBuildsSuccessfully() throws Exception {
        Method method = HttpConnectionConfig.class.getDeclaredMethod("httpClient");
        method.setAccessible(true);

        assertDoesNotThrow(() -> {
            method.invoke(config);
        });
    }

    @Test
    void testSocketTimeoutGetterSetter() {
        HttpConnectionConfig config = new HttpConnectionConfig();
        config.setSocketTimeout(3000);
        assertEquals(3000, config.getSocketTimeout());
    }

    @Test
    void testUserGetterSetter() {
        HttpConnectionConfig config = new HttpConnectionConfig();
        config.setUser("myUser");
        assertEquals("myUser", config.getUser());
    }

    @Test
    void testPassGetterSetter() {
        HttpConnectionConfig config = new HttpConnectionConfig();
        config.setPass("myPass");
        assertEquals("myPass", config.getPass());
    }

    @Test
    void testUrlGetterSetter() {
        HttpConnectionConfig config = new HttpConnectionConfig();
        config.setUrl("https://test.com");
        assertEquals("https://test.com", config.getUrl());
    }
}
