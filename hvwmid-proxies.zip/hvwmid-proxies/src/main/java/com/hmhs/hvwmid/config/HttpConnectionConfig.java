package com.hmhs.hvwmid.config;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;
import javax.validation.constraints.NotNull;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

//@Configuration
@ConfigurationProperties("http")
@EnableRetry
public class HttpConnectionConfig {

  public static final String HTTPS = "https://";

  //@Autowired public CredentialsConfig credentialsConfig;

  @Autowired
  @Qualifier("customMapper")
  private ObjectMapper objectMapper;

  @NotNull private int socketTimeout;

  @NotNull private String user;

  @NotNull private String pass;

  @NotNull private String url;

  private RequestConfig requestConfig() {
    RequestConfig.Builder requestConfig = RequestConfig.custom();
    requestConfig.setSocketTimeout(socketTimeout); // in milliseconds
    requestConfig.setRedirectsEnabled(true); // explicity call out based on use case
    requestConfig.setRelativeRedirectsAllowed(true); // explicity call out based on use case

    return requestConfig.build();
  }

  private CloseableHttpClient httpClient() throws KeyManagementException, NoSuchAlgorithmException {
    SSLContext sslContext = SSLContexts.custom().build();
    SSLConnectionSocketFactory sslConnectionSocketFactory =
        new SSLConnectionSocketFactory(
            sslContext,
            new String[] {"TLSv1.2"}, // our openshift only supports 1.2
            null,
            SSLConnectionSocketFactory.getDefaultHostnameVerifier());
    Registry<ConnectionSocketFactory> socketFactoryRegistry =
        RegistryBuilder.<ConnectionSocketFactory>create()
            .register("https", sslConnectionSocketFactory)
            .build();
    return HttpClients.custom()
        .setConnectionManager(connManager(socketFactoryRegistry))
        .setDefaultRequestConfig(requestConfig())
        .setSSLSocketFactory(sslConnectionSocketFactory)
        .disableAutomaticRetries()//set this if managing your own retries (via Spring's RetryTemplate)
        .build();
  }

  private org.apache.http.impl.conn.PoolingHttpClientConnectionManager connManager(
      Registry<ConnectionSocketFactory> socketFactoryRegistry) {
    org.apache.http.impl.conn.PoolingHttpClientConnectionManager connManager =
        new org.apache.http.impl.conn.PoolingHttpClientConnectionManager(socketFactoryRegistry);
    // TODO:  inject these values from application.yml
    connManager.setMaxTotal(100);
    connManager.setDefaultMaxPerRoute(100);
    connManager.setValidateAfterInactivity(30000);
    return connManager;
  }

//  @Bean(name = "sampleRequestFactory")
//  public ClientHttpRequestFactory sampleRequestFactory()
//      throws KeyManagementException, NoSuchAlgorithmException {
//    return new HttpComponentsClientHttpRequestFactory(httpClient());
//  }

//  @Bean(name = "sampleRestTemplate")
//  public RestTemplate sampleRestTemplate() throws Exception {
//    return new RestTemplateBuilder()
//        .requestFactory(
//            () -> {
//              try {
//                return sampleRequestFactory();
//              } catch (KeyManagementException | NoSuchAlgorithmException e) {
//                return null;
//              }
//            })
//        .messageConverters(new MappingJackson2HttpMessageConverter(objectMapper))
//        .basicAuthentication(
//            user, pass) // preemptively assign the basic authorization credentials here, places
//        // header as
//        // well
//        .build();
//  }

  @Bean(name = "sampleRetry")
  public RetryTemplate retryTemplate() {
    SimpleRetryPolicy policy = new SimpleRetryPolicy();
    policy.setMaxAttempts(3);

    ExponentialBackOffPolicy backOff = new ExponentialBackOffPolicy();
    backOff.setInitialInterval(45000);
    backOff.setMultiplier(1.1);
    backOff.setMaxInterval(420000);

    RetryTemplate template = new RetryTemplate();
    template.setRetryPolicy(policy);
    template.setBackOffPolicy(backOff);

    return template;
  }

  public int getSocketTimeout() {
    return socketTimeout;
  }

  public void setSocketTimeout(int socketTimeout) {
    this.socketTimeout = socketTimeout;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  public String getPass() {
    return pass;
  }

  public void setPass(String pass) {
    this.pass = pass;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }
}
