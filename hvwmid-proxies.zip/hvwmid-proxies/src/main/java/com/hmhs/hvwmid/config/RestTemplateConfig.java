package com.hmhs.hvwmid.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import java.security.SecureRandom;

@Configuration
public class RestTemplateConfig {

    @Bean
    public RestTemplate restTemplate() {
        try {
            // Create a secure SSLContext using TLSv1.2 and default trust managers.
            SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null, null, new SecureRandom());

            // Set the default SSLSocketFactory and HostnameVerifier to use the secure context.
            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier(HttpsURLConnection.getDefaultHostnameVerifier());

            // Create a RestTemplate that uses the default HTTP request factory (which relies on HttpsURLConnection)
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            return new RestTemplate(requestFactory);

        } catch (Exception e) {
            throw new RuntimeException("Failed to configure RestTemplate with proper certificate validation", e);
        }
    }
}
