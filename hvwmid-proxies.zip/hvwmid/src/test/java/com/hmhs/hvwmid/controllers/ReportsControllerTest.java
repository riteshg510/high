package com.hmhs.hvwmid.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.IndexListingService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.ReportService;
import com.hmhs.hvwmid.service.UserReportService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

class ReportsControllerTest {

    @InjectMocks
    private ReportsController reportsController;

    @Mock
    private AppDataService appDataService;

    @Mock
    private ReportService reportService;

    @Mock
    private UserReportService userReportService;

    @Mock
    private IndexListingService indexListingService;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(request.getRequestURI()).thenReturn("/mock");
    }

    @Test
    void testGetMyReportsForm_success() {
        String authToken = "mockToken";
        int requestId = 100;
        String expectedJson = "{\"form\": \"my reports\"}";

        TblTemplates mockTemplate = new TblTemplates();
        mockTemplate.setContent(expectedJson.getBytes(StandardCharsets.UTF_8));

        when(appDataService.getTempletByName("MyReportsForm")).thenReturn(List.of(mockTemplate));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            ResponseEntity<String> response = reportsController.getMyReportsForm(requestId, authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(expectedJson, response.getBody());
        }
    }

    @Test
    void testGetMyReportsForm_serviceThrowsException() {
        String authToken = "badToken";
        int requestId = 200;

        when(appDataService.getTempletByName("MyReportsForm")).thenThrow(new RuntimeException("Database error"));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            ResponseEntity<String> response = reportsController.getMyReportsForm(requestId, authToken);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    /* 
    @Test
    void testUserReportsTableDefinition_dynamicResponse_success() {
        String authToken = "validToken";
        int requestId = 123;
        String dynamicJson = """
        {
            "columns": [
                { "id": "actions", "name": "Action", "type": "string" },
                { "id": "cmodAction", "name": "CMOD Action", "type": "actions" }
            ]
        }
        """;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            when(reportService.getReportsTableDefinition()).thenReturn(dynamicJson);

            ResponseEntity<String> response = reportsController.userReportsTableDefinition(requestId, authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertNotNull(response.getBody());
            assertTrue(response.getBody().contains("\"columns\""), "Expected 'columns' key not found in response body");
            assertTrue(response.getBody().contains("\"id\": \"actions\""));
        }
    }*/
    @Test
void testUserReportsTableDefinition_dynamicResponse_success() {
    String authToken = "validToken";
    int requestId = 123;
    
    TblTemplates mockTemplate = new TblTemplates();
    when(appDataService.getTempletByName("UserReportsTableDefinition")).thenReturn(List.of(mockTemplate));
    try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
        mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

        // Updated to match the new implementation of userReportsTableDefinition
        when(appDataService.getTempletByName("AllReportsTable")).thenReturn(List.of());

        ResponseEntity<String> response = reportsController.userReportsTableDefinition(requestId, authToken);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
     
    }
}

    @Test
    void testGetMyReportsTableData_success() {
        String authToken = "validToken";
        int requestId = 100;
        String userId = "mockUser".toUpperCase();
        String rawReportData = "{\"serviceMessage\": {\"returnCode\": 0}, \"data\": []}";
        String filteredData = rawReportData;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(reportService.getAllReportsDataWithDynamicActions("MYREPORTS", authToken)).thenReturn(rawReportData);
            when(userReportService.filterJsonByDb(userId, rawReportData)).thenReturn(filteredData);

            ResponseEntity<Object> response = reportsController.getMyReportsTableData(authToken, requestId);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody() instanceof String);
            assertTrue(((String) response.getBody()).contains("\"returnCode\": 0"));
        }
    }



    @Test
    void testGetMyReportsTableData_exceptionThrown() {
        String authToken = "validToken";
        int requestId = 102;
        String userId = "mockUser";

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(reportService.getAllReportsDataWithDynamicActions("MYREPORTS", authToken))
                    .thenThrow(new RuntimeException("Simulated failure"));

            ResponseEntity<Object> response = reportsController.getMyReportsTableData(authToken, requestId);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }


    @Test
    void testRemoveReportFromMyReport_success() {
        String authToken = "validToken";
        String reportId = "report123";
        int requestId = 999;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            ResponseEntity<Object> response = reportsController.removeFavoritesReport(reportId, authToken, requestId);

            assertEquals(HttpStatus.OK, response.getStatusCode());

            Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
            assertEquals("Success", ((Map<?, ?>) responseBody.get("serviceMessage")).get("returnCodeDescription"));
            assertEquals("Report removed from My Reports", responseBody.get("message"));

            verify(userReportService).removeFromMyReport("mockUser".toUpperCase(), reportId);
        }
    }


    @Test
    void testRemoveReportFromMyReport_unauthenticated() {
        String authToken = "invalidToken";
        String reportId = "report123";
        int requestId = 888;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(null);

            ResponseEntity<Object> response = reportsController.removeFavoritesReport(reportId, authToken, requestId);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());

            Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
            assertEquals("Authentication required. Missing or invalid token.", ((Map<?, ?>) responseBody.get("serviceMessage")).get("returnCodeDescription"));
        }
    }

    @Test
    void testRemoveReportFromMyReport_exceptionThrown() {
        String authToken = "validToken";
        String reportId = "report456";
        int requestId = 777;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            doThrow(new RuntimeException("Simulated failure"))
                    .when(userReportService).removeFromMyReport("mockUser".toUpperCase(), reportId);

            ResponseEntity<Object> response = reportsController.removeFavoritesReport(reportId, authToken, requestId);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());

            Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
            assertEquals("Error removing folder: Simulated failure", ((Map<?, ?>) responseBody.get("serviceMessage")).get("returnCodeDescription"));
        }
    }

    @Test
    void testAddToMyReport_success() {
        String authToken = "validToken";
        String reportId = "R101";
        int requestId = 1001;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            // Act
            ResponseEntity<Object> response = reportsController.addFavoritesReport(reportId, authToken, requestId);

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());

            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertEquals("Success", ((Map<?, ?>) body.get("serviceMessage")).get("returnCodeDescription"));
            assertEquals("Folder added to My Reports", body.get("message"));

            verify(userReportService).saveUserReport("mockUser".toUpperCase(), reportId);
        }
    }
    @Test
    void testAddToMyReport_unauthenticated() {
        String authToken = "invalidToken";
        String reportId = "R202";
        int requestId = 1002;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(null);

            ResponseEntity<Object> response = reportsController.addFavoritesReport(reportId, authToken, requestId);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());

            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertEquals("Authentication required. Missing or invalid token.",
                    ((Map<?, ?>) body.get("serviceMessage")).get("returnCodeDescription"));
        }
    }
    @Test
    void testAddToMyReport_serviceException() {
        String authToken = "validToken";
        String reportId = "R303";
        int requestId = 1003;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            doThrow(new RuntimeException("Simulated DB failure"))
                    .when(userReportService).saveUserReport("mockUser".toUpperCase(), reportId);

            ResponseEntity<Object> response = reportsController.addFavoritesReport(reportId, authToken, requestId);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());

            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertEquals("Error adding folder: Simulated DB failure",
                    ((Map<?, ?>) body.get("serviceMessage")).get("returnCodeDescription"));
        }
    }

    @Test
    void testGetAllReportsForm_success() {
        String authToken = "Bearer token123";
        int requestId = 101;
        String expectedJson = "{\"form\": \"all reports form\"}";

        TblTemplates mockTemplate = mock(TblTemplates.class);
        when(mockTemplate.getContent()).thenReturn(expectedJson.getBytes(StandardCharsets.UTF_8));
        List<TblTemplates> templates = List.of(mockTemplate);

        when(appDataService.getTempletByName("AllReportsForm")).thenReturn(templates);

        try (MockedStatic<HVWUtils> staticMock = mockStatic(HVWUtils.class)) {
            staticMock.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("user123");

            ResponseEntity<String> response = reportsController.getAllReportsForm(requestId, authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(expectedJson, response.getBody());
        }
    }
    @Test
    void testGetAllReportsForm_exceptionThrown() {
        String authToken = "Bearer token123";
        int requestId = 102;

        when(appDataService.getTempletByName("AllReportsForm")).thenThrow(new RuntimeException("DB error"));

        try (MockedStatic<HVWUtils> staticMock = mockStatic(HVWUtils.class)) {
            staticMock.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userXYZ");

            ResponseEntity<String> response = reportsController.getAllReportsForm(requestId, authToken);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }


    @Test
    void testGetAllReportsTableData_success() {
        String authToken = "validToken";
        int requestId = 100;
        String userId = "mockUser";
        String responseJson = "{\"serviceMessage\": {\"returnCode\": 0}, \"data\": [\"report1\"]}";

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {

            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);


            when(reportService.getAllReportsDataWithDynamicActions("ALLREPORTS", authToken))
                    .thenReturn(responseJson);


            ResponseEntity<Object> response = reportsController.getAllReportsTableData(authToken, requestId);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody().toString().contains("\"returnCode\": 0"));
        }
    }


    @Test
    void testGetAllReportsTableData_missingUserId() {
        String authToken = "invalidToken";
        int requestId = 200;
        String responseJson = "{\"serviceMessage\": {\"returnCode\": 0}, \"data\": []}";

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(null);

            when(reportService.getAllReportsDataWithDynamicActions("ALLREPORTS", authToken))
                    .thenReturn(responseJson);

            ResponseEntity<Object> response = reportsController.getAllReportsTableData(authToken, requestId);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody().toString().contains("\"returnCode\": 0"));
        }
    }

    @Test
    void testGetAllReportsTableData_serviceThrowsException() {
        String authToken = "validToken";
        int requestId = 300;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userXYZ");

            when(reportService.getAllReportsDataWithDynamicActions("ALLREPORTS", authToken))
                    .thenThrow(new RuntimeException("Simulated service failure"));

            ResponseEntity<Object> response = reportsController.getAllReportsTableData(authToken, requestId);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }


    @Test
    void testProcessReportResponse_success() {
        String json = """
        {
            "serviceMessage": {
                "returnCode": 0
            },
            "data": ["mockedResult"]
        }
    """;

        ResponseEntity<Object> response = reportsController.processReportResponse(json, 1, "userA");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(json.trim(), response.getBody().toString().trim());
    }
    @Test
    void testProcessReportResponse_unauthorized() {
        String json = """
        {
            "serviceMessage": {
                "returnCode": 401
            }
        }
    """;

        ResponseEntity<Object> response = reportsController.processReportResponse(json, 2, "userB");

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals(json.trim(), response.getBody().toString().trim());
    }
    @Test
    void testProcessReportResponse_unknownError() {
        String json = """
        {
            "serviceMessage": {
                "returnCode": 999
            }
        }
    """;

        ResponseEntity<Object> response = reportsController.processReportResponse(json, 3, "userC");

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
    }
    @Test
    void testProcessReportResponse_invalidJson() {
        String badJson = """
                  {
                  "invalidJson": "true this will break"
                }
                """;

        ResponseEntity<Object> response = reportsController.processReportResponse(badJson, 4, "userD");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(badJson, response.getBody());
    }


    @Test
    void testGetAllReportsTable_returnsJsonDefinition() {

        Integer requestId = 101;
        String authToken = "authTokenABC";
        String userId = "testUser".toUpperCase();
        String expectedJson = "{\"columns\":[{\"name\":\"Report\"}]}";

        TblTemplates mockTemplate = new TblTemplates();
        mockTemplate.setContent(expectedJson.getBytes(StandardCharsets.UTF_8));
        List<TblTemplates> mockTemplateList = Collections.singletonList(mockTemplate);

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(appDataService.getTempletByName("AllReportsTable")).thenReturn(mockTemplateList);
            when(request.getRequestURI()).thenReturn("/all/get-tabledefinition");


            ResponseEntity<String> response = reportsController.getAllReportsTable(requestId, authToken);


            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(expectedJson, response.getBody());
 
        }
    } 
}
