package com.hmhs.hvwmid.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.CMODApplicationAccessInfo;
import com.hmhs.hvwmid.model.CMODSARAPathInfo;
import com.hmhs.hvwmid.model.CMODSecurityAccessResponse;
import com.hmhs.hvwmid.service.CMODSecurityService;
import com.hmhs.hvwmid.utils.HVWUtils;

/**
 * Unit tests for CMODSecurityController.
 * Tests the REST endpoint and error handling for CMOD security access functionality.
 */
class CMODSecurityControllerTest {

    @InjectMocks
    private CMODSecurityController cmodSecurityController;

    @Mock
    private CMODSecurityService cmodSecurityService;

    private MockedStatic<HVWUtils> hvwUtilsMock;

    private static final String VALID_JWT = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJURVNUVVNFUiIsIm5hbWUiOiJUZXN0IFVzZXIiLCJpYXQiOjE1MTYyMzkwMjJ9.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
    private static final String TEST_USER_ID = "TESTUSER";
    private static final Integer TEST_REQUEST_ID = 12345;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        hvwUtilsMock = mockStatic(HVWUtils.class);
        hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(VALID_JWT))
                   .thenReturn(TEST_USER_ID);
    }

    @AfterEach
    void tearDown() {
        if (hvwUtilsMock != null) {
            hvwUtilsMock.close();
        }
    }

    @Test
    void testGetCMODSecurityAccess_Success() throws Exception {
        // Arrange
        CMODSecurityAccessResponse mockResponse = createMockResponse(false);
        
        when(cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, ""))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<CMODSecurityAccessResponse> response = cmodSecurityController
            .getCMODSecurityAccess("", VALID_JWT, TEST_REQUEST_ID);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(false, response.getBody().isHasError());
        assertEquals("HMRK, NDAK", response.getBody().getUserGroups());
        assertEquals("Test Triage Info", response.getBody().getTriageInfo());
        assertEquals(false, response.getBody().isCmodFolderNavigation());
        assertNotNull(response.getBody().getFolderAccessMap());
        assertNotNull(response.getBody().getSaraPathInfo());
    }

    @Test
    void testGetCMODSecurityAccess_WithFolderName() throws Exception {
        // Arrange
        String folderName = "TEST_FOLDER";
        CMODSecurityAccessResponse mockResponse = createMockResponse(false);
        // Note: The controller sets cmodFolderNavigation=true when folderName is not empty
        
        when(cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, folderName))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<CMODSecurityAccessResponse> response = cmodSecurityController
            .getCMODSecurityAccess(folderName, VALID_JWT, TEST_REQUEST_ID);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isCmodFolderNavigation()); // Controller sets this to true
    }

    @Test  
    void testGetCMODSecurityAccess_WithError() throws Exception {
        // Arrange
        CMODSecurityAccessResponse mockResponse = createMockResponse(true);
        mockResponse.setErrorMessage("You do not have access to any CMOD applications.");
        
        when(cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, ""))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<CMODSecurityAccessResponse> response = cmodSecurityController
            .getCMODSecurityAccess("", VALID_JWT, TEST_REQUEST_ID);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isHasError());
        assertEquals("You do not have access to any CMOD applications.", response.getBody().getErrorMessage());
    }

    @Test
    void testGetCMODSecurityAccess_HVWException() throws Exception {
        // Arrange
        HVWException hvwException = new HVWException(500, "Service error", "CMODSecurityService");
        
        when(cmodSecurityService.getCMODSecurityAccess(anyString(), anyString()))
            .thenThrow(hvwException);

        // Act & Assert
        try {
            cmodSecurityController.getCMODSecurityAccess("", VALID_JWT, TEST_REQUEST_ID);
        } catch (HVWException e) {
            assertEquals("Service error", e.getMessage());
            assertEquals(500, e.getReturnCode());
        }
    }

    @Test
    void testGetCMODSecurityAccess_UnexpectedException() throws Exception {
        // Arrange
        when(cmodSecurityService.getCMODSecurityAccess(anyString(), anyString()))
            .thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        try {
            cmodSecurityController.getCMODSecurityAccess("", VALID_JWT, TEST_REQUEST_ID);
        } catch (HVWException e) {
            assertTrue(e.getMessage().contains("Failed to retrieve CMOD security access"));
            assertEquals(500, e.getReturnCode());
        }
    }

    @Test
    void testGetCMODSecurityAccess_WithoutRequestId() throws Exception {
        // Arrange
        CMODSecurityAccessResponse mockResponse = createMockResponse(false);
        
        when(cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, ""))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<CMODSecurityAccessResponse> response = cmodSecurityController
            .getCMODSecurityAccess("", VALID_JWT, null);

        // Assert - Should still work without requestId (it's optional)
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(false, response.getBody().isHasError());
    }

    @Test
    void testGetCMODSecurityAccess_EmptyFolderNameParameter() throws Exception {
        // Arrange
        CMODSecurityAccessResponse mockResponse = createMockResponse(false);
        
        when(cmodSecurityService.getCMODSecurityAccess(TEST_USER_ID, ""))
            .thenReturn(mockResponse);

        // Act
        ResponseEntity<CMODSecurityAccessResponse> response = cmodSecurityController
            .getCMODSecurityAccess("", VALID_JWT, TEST_REQUEST_ID);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(false, response.getBody().isCmodFolderNavigation());
    }

    /**
     * Helper method to create a mock CMODSecurityAccessResponse for testing.
     */
    private CMODSecurityAccessResponse createMockResponse(boolean hasError) {
        if (hasError) {
            return new CMODSecurityAccessResponse("Test error message");
        }

        // Create mock folder access map
        Map<String, Map<String, CMODApplicationAccessInfo>> folderAccessMap = new HashMap<>();
        Map<String, CMODApplicationAccessInfo> applicationMap = new HashMap<>();
        
        CMODApplicationAccessInfo appInfo = new CMODApplicationAccessInfo();
        appInfo.setApplicationName("TEST_APP");
        appInfo.setUserAccess(true);
        appInfo.setAcf2String("TEST_ACF2");
        appInfo.setVpieApplication("TEST_VPIE");
        appInfo.setVpieRoleDescription("Test Role");
        appInfo.setApplicationVersions(Set.of("TEST_APP-HMRK-V1"));
        
        applicationMap.put("TEST_ACF2", appInfo);
        folderAccessMap.put("TEST_FOLDER", applicationMap);

        // Create mock missing RACF map
        Map<String, Set<String>> missingRACFMap = new HashMap<>();

        // Create mock SARA path info
        CMODSARAPathInfo saraPathInfo = new CMODSARAPathInfo();
        saraPathInfo.setRootPath("/test/root");
        saraPathInfo.setHighviewPaths(Map.of("HIGHVIEW_PATH", "/highview/test"));
        saraPathInfo.setRenoPaths(Map.of("RENO_PATH", "/reno/test"));

        return new CMODSecurityAccessResponse(
            folderAccessMap,
            missingRACFMap,
            saraPathInfo,
            "HMRK, NDAK",
            "Test Triage Info"
        );
    }
}