package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.model.*;
import com.hmhs.hvwmid.repository.ImageCachingRepository;
import com.hmhs.hvwmid.service.FileStorageService;
import com.hmhs.hvwmid.service.IMIFileGeneratorService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.validator.GenerateIMIRequestValidator;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for IMIGeneratorController
 */
@ExtendWith(MockitoExtension.class)
class IMIGeneratorControllerTest {

    @InjectMocks
    private IMIGeneratorController imiGeneratorController;

    @Mock
    private IMIFileGeneratorService imiFileGeneratorService;

    @Mock
    private FileStorageService fileStorageService;

    @Mock
    private ImageCachingRepository imageCachingRepository;

    @Mock
    private LoggerService loggerService;

    @Mock
    private GenerateIMIRequestValidator requestValidator;

    @Mock
    private HttpServletRequest request;


    private static final String VALID_TOKEN = "Bearer valid.jwt.token";
    private static final String INVALID_TOKEN = "Bearer invalid.token";
    private static final Integer REQUEST_ID = 12345;
    private static final String USER_ID = "testuser";

    @BeforeEach
    void setUp() {
        lenient().when(request.getRequestURI()).thenReturn("/test-uri");
    }

    // Tests for /segments endpoint
    @Test
    void getSegments_ValidRequest_ShouldReturnSegments() throws Exception {
        // Arrange
        Map<String, String> expectedSegments = Map.of(
            "FID", "File ID segment",
            "DPK", "Document Processing Key",
            "IMG", "Image segment"
        );

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.getStringParmData("IMISEG")).thenReturn(expectedSegments);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.getSegments(VALID_TOKEN, REQUEST_ID);

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(expectedSegments, response.getBody());
            verify(imiFileGeneratorService).getStringParmData("IMISEG");
        }
    }

    @Test
    void getSegments_InvalidToken_ShouldReturn401() throws Exception {
        // Arrange
        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(INVALID_TOKEN)).thenReturn(null);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.getSegments(INVALID_TOKEN, REQUEST_ID);

            // Assert
            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
            Map<String, Object> errorBody = (Map<String, Object>) response.getBody();
            Map<String, Object> serviceMessage = (Map<String, Object>) errorBody.get("serviceMessage");
            assertEquals(401, serviceMessage.get("returnCode"));
            assertTrue(serviceMessage.get("returnCodeDescription").toString().contains("Authentication required"));
            verifyNoInteractions(imiFileGeneratorService);
        }
    }

    @Test
    void getSegments_EmptySegments_ShouldReturn404() throws Exception {
        // Arrange
        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.getStringParmData("IMISEG")).thenReturn(Collections.emptyMap());

            // Act
            ResponseEntity<Object> response = imiGeneratorController.getSegments(VALID_TOKEN, REQUEST_ID);

            // Assert
            assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
            Map<String, Object> errorBody = (Map<String, Object>) response.getBody();
            Map<String, Object> serviceMessage = (Map<String, Object>) errorBody.get("serviceMessage");
            assertEquals(404, serviceMessage.get("returnCode"));
            assertTrue(serviceMessage.get("returnCodeDescription").toString().contains("No segments data found"));
        }
    }

    @Test
    void getSegments_ServiceException_ShouldReturn500() throws Exception {
        // Arrange
        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.getStringParmData("IMGSEG"))
                .thenThrow(new RuntimeException("Database error"));

            // Act
            ResponseEntity<Object> response = imiGeneratorController.getSegments(VALID_TOKEN, REQUEST_ID);

            // Assert
            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    // Tests for /upload-excel endpoint
    @Test
    void uploadExcel_ValidRequest_ShouldReturnSuccess() throws Exception {
        // Arrange
        MockMultipartFile excelFile = new MockMultipartFile(
            "inputFile33", "test.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "Excel content".getBytes()
        );

        ExcelUploadResponse expectedResponse = new ExcelUploadResponse();
        expectedResponse.setExcelId(123);
        expectedResponse.setExcelName("test.xlsx");
        expectedResponse.setColumnHeaders(Arrays.asList("FileName", "DPK", "DTR"));
        expectedResponse.setDistinctFilenames(Arrays.asList("doc1.pdf", "doc2.tif"));

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.uploadExcelFile(any(), eq(25), eq(99), eq(USER_ID)))
                .thenReturn(expectedResponse);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadExcel(
                VALID_TOKEN, REQUEST_ID, excelFile, 25, 99);

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());
            ExcelUploadResponse actualResponse = (ExcelUploadResponse) response.getBody();
            assertEquals(123, actualResponse.getExcelId());
            assertEquals("test.xlsx", actualResponse.getExcelName());
            assertEquals(3, actualResponse.getColumnHeaders().size());
            assertEquals(2, actualResponse.getDistinctFilenames().size());

            verify(imiFileGeneratorService).uploadExcelFile(any(), eq(25), eq(99), eq(USER_ID));
            verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), 
                anyString(), anyString(), anyString(), anyString(), anyString());
        }
    }

    @Test
    void uploadExcel_InvalidToken_ShouldReturn401() throws Exception {
        // Arrange
        MockMultipartFile excelFile = new MockMultipartFile(
            "inputFile33", "test.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "Excel content".getBytes()
        );

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(INVALID_TOKEN)).thenReturn(null);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadExcel(
                INVALID_TOKEN, REQUEST_ID, excelFile, null, 99);

            // Assert
            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
            Map<String, Object> errorBody = (Map<String, Object>) response.getBody();
            Map<String, Object> serviceMessage = (Map<String, Object>) errorBody.get("serviceMessage");
            assertEquals(401, serviceMessage.get("returnCode"));

            verifyNoInteractions(imiFileGeneratorService);
        }
    }

    @Test
    void uploadExcel_ValidationError_ShouldReturn400() throws Exception {
        // Arrange
        MockMultipartFile excelFile = new MockMultipartFile(
            "inputFile33", "test.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "Excel content".getBytes()
        );

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.uploadExcelFile(any(), anyInt(), anyInt(), anyString()))
                .thenThrow(new IllegalArgumentException("Invalid file format"));

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadExcel(
                VALID_TOKEN, REQUEST_ID, excelFile, 25, 99);

            // Assert
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            Map<String, Object> errorBody = (Map<String, Object>) response.getBody();
            Map<String, Object> serviceMessage = (Map<String, Object>) errorBody.get("serviceMessage");
            assertEquals(400, serviceMessage.get("returnCode"));
            assertTrue(serviceMessage.get("returnCodeDescription").toString().contains("Invalid file format"));
        }
    }

    @Test
    void uploadExcel_DefaultDocumentCount_ShouldUseDefault() throws Exception {
        // Arrange
        MockMultipartFile excelFile = new MockMultipartFile(
            "inputFile33", "test.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "Excel content".getBytes()
        );

        ExcelUploadResponse expectedResponse = new ExcelUploadResponse();
        expectedResponse.setExcelId(123);
        expectedResponse.setExcelName("test.xlsx");
        expectedResponse.setColumnHeaders(Arrays.asList("FileName", "DPK", "DTR"));
        expectedResponse.setDistinctFilenames(Arrays.asList("doc1.pdf", "doc2.tif"));

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.uploadExcelFile(any(), eq(25), eq(99), eq(USER_ID)))
                .thenReturn(expectedResponse);

            // Act - Pass 25 explicitly since we're bypassing Spring's parameter processing
            ResponseEntity<Object> response = imiGeneratorController.uploadExcel(
                VALID_TOKEN, REQUEST_ID, excelFile, 25, 99);

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());
            verify(imiFileGeneratorService).uploadExcelFile(any(), eq(25), eq(99), eq(USER_ID));
        }
    }

    // Tests for /upload-image endpoint
    @Test
    void uploadImage_ValidRequest_ShouldReturnSuccess() throws Exception {
        // Arrange
        MockMultipartFile imageFile = new MockMultipartFile(
            "imageFile", "test.pdf", "application/pdf", "PDF content".getBytes()
        );

        List<String> validFilenames = Arrays.asList("test.pdf", "document.tif");
        FileStorageResult storageResult = new FileStorageResult();
        storageResult.setRequestId(456);
        storageResult.setFileName("test.pdf");

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.getDistinctFilenamesFromExcel(123, USER_ID))
                .thenReturn(validFilenames);
            when(fileStorageService.storeFile(any(), eq(USER_ID), eq("PDF")))
                .thenReturn(storageResult);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadImage(
                VALID_TOKEN, REQUEST_ID, imageFile, 123, "test.pdf");

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());
            ImageUploadResponse actualResponse = (ImageUploadResponse) response.getBody();
            assertEquals(456, actualResponse.getRequestId());
            assertEquals("test.pdf", actualResponse.getFilename());
            assertEquals("success", actualResponse.getStatus());

            verify(imiFileGeneratorService).getDistinctFilenamesFromExcel(123, USER_ID);
            verify(fileStorageService).storeFile(any(), eq(USER_ID), eq("PDF"));
        }
    }

    @Test
    void uploadImage_InvalidFilename_ShouldReturn400() throws Exception {
        // Arrange
        MockMultipartFile imageFile = new MockMultipartFile(
            "imageFile", "test.pdf", "application/pdf", "PDF content".getBytes()
        );

        List<String> validFilenames = Arrays.asList("other.pdf", "document.tif");

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.getDistinctFilenamesFromExcel(123, USER_ID))
                .thenReturn(validFilenames);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadImage(
                VALID_TOKEN, REQUEST_ID, imageFile, 123, "invalid.pdf");

            // Assert
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            Map<String, Object> errorBody = (Map<String, Object>) response.getBody();
            Map<String, Object> serviceMessage = (Map<String, Object>) errorBody.get("serviceMessage");
            assertEquals(400, serviceMessage.get("returnCode"));
            assertTrue(serviceMessage.get("returnCodeDescription").toString().contains("not found in Excel file"));

            verify(imiFileGeneratorService).getDistinctFilenamesFromExcel(123, USER_ID);
            verifyNoInteractions(fileStorageService);
        }
    }

    @Test
    void uploadImage_EmptyFile_ShouldReturn400() throws Exception {
        // Arrange
        MockMultipartFile emptyFile = new MockMultipartFile(
            "imageFile", "test.pdf", "application/pdf", new byte[0]
        );

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadImage(
                VALID_TOKEN, REQUEST_ID, emptyFile, 123, "test.pdf");

            // Assert
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            verifyNoInteractions(imiFileGeneratorService);
            verifyNoInteractions(fileStorageService);
        }
    }

    @Test
    void uploadImage_SecurityException_ShouldReturn403() throws Exception {
        // Arrange
        MockMultipartFile imageFile = new MockMultipartFile(
            "imageFile", "test.pdf", "application/pdf", "PDF content".getBytes()
        );

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(imiFileGeneratorService.getDistinctFilenamesFromExcel(123, USER_ID))
                .thenThrow(new SecurityException("Access denied"));

            // Act
            ResponseEntity<Object> response = imiGeneratorController.uploadImage(
                VALID_TOKEN, REQUEST_ID, imageFile, 123, "test.pdf");

            // Assert
            assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        }
    }

    // Tests for /download/{requestId} endpoint
    @Test
    void downloadFile_ValidRequest_ShouldReturnFile() throws Exception {
        // Arrange
        Integer fileRequestId = 789;
        FileStorageResult metadata = new FileStorageResult();
        metadata.setRequestId(fileRequestId);
        metadata.setFileName("test.xlsx");
        metadata.setDocumentType("XLSX");
        metadata.setDocumentSize(1024);
        metadata.setTimeCreated(LocalDateTime.of(2024, 1, 15, 10, 30, 0));

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(fileStorageService.getFileMetadata(fileRequestId)).thenReturn(metadata);
            when(fileStorageService.validateAccess(fileRequestId, USER_ID)).thenReturn(true);

            // Act
            ResponseEntity<StreamingResponseBody> response = imiGeneratorController.downloadFile(
                VALID_TOKEN, REQUEST_ID, fileRequestId, "test.pdf");

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", 
                response.getHeaders().getContentType().toString());
            assertTrue(response.getHeaders().getContentDisposition().toString().contains("attachment"));
            assertEquals("1024", response.getHeaders().getFirst("Content-Length"));
            assertNotNull(response.getBody());

            verify(fileStorageService).getFileMetadata(fileRequestId);
            verify(fileStorageService).validateAccess(fileRequestId, USER_ID);
        }
    }

    @Test
    void downloadFile_FileNotFound_ShouldReturn404() throws Exception {
        // Arrange
        Integer fileRequestId = 789;

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(fileStorageService.getFileMetadata(fileRequestId)).thenReturn(null);

            // Act
            ResponseEntity<StreamingResponseBody> response = imiGeneratorController.downloadFile(
                VALID_TOKEN, REQUEST_ID, fileRequestId, "test.pdf");

            // Assert
            assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());

            verify(fileStorageService).getFileMetadata(fileRequestId);
            verify(fileStorageService, never()).validateAccess(anyInt(), anyString());
        }
    }

    @Test
    void downloadFile_AccessDenied_ShouldReturn403() throws Exception {
        // Arrange
        Integer fileRequestId = 789;
        FileStorageResult metadata = new FileStorageResult();
        metadata.setRequestId(fileRequestId);
        metadata.setDocumentType("XLSX");
        metadata.setTimeCreated(LocalDateTime.now());

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(fileStorageService.getFileMetadata(fileRequestId)).thenReturn(metadata);
            when(fileStorageService.validateAccess(fileRequestId, USER_ID)).thenReturn(false);

            // Act
            ResponseEntity<StreamingResponseBody> response = imiGeneratorController.downloadFile(
                VALID_TOKEN, REQUEST_ID, fileRequestId, "test.pdf");

            // Assert
            assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());

            verify(fileStorageService).validateAccess(fileRequestId, USER_ID);
        }
    }

    // Tests for /generate-imi endpoint
    @Test
    void generateIMIFiles_ValidRequest_ShouldReturnSuccess() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidGenerateIMIRequest();
        GenerateIMIResponse expectedResponse = createValidGenerateIMIResponse();
        
        GenerateIMIRequestValidator.ValidationResult validationResult = 
            new GenerateIMIRequestValidator.ValidationResult();

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(requestValidator.validate(any(GenerateIMIRequest.class))).thenReturn(validationResult);
            when(imiFileGeneratorService.generateIMIFiles(any(GenerateIMIRequest.class), eq(USER_ID)))
                .thenReturn(expectedResponse);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.generateIMIFiles(
                VALID_TOKEN, REQUEST_ID, request);

            // Assert
            assertEquals(HttpStatus.OK, response.getStatusCode());
            GenerateIMIResponse actualResponse = (GenerateIMIResponse) response.getBody();
            assertEquals(2, actualResponse.getGeneratedFiles().size());
            assertEquals(456, actualResponse.getOutputExcelId());
            assertEquals(100, actualResponse.getSummary().getTotalRows());
            assertEquals(95, actualResponse.getSummary().getSuccessful());
            assertEquals(5, actualResponse.getSummary().getFailed());

            verify(requestValidator).validate(any(GenerateIMIRequest.class));
            verify(imiFileGeneratorService).generateIMIFiles(any(GenerateIMIRequest.class), eq(USER_ID));
        }
    }

    @Test
    void generateIMIFiles_ValidationFailure_ShouldReturn400() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidGenerateIMIRequest();
        GenerateIMIRequestValidator.ValidationResult validationResult = 
            new GenerateIMIRequestValidator.ValidationResult();
        validationResult.addError("Excel ID is required");

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(requestValidator.validate(any(GenerateIMIRequest.class))).thenReturn(validationResult);

            // Act
            ResponseEntity<Object> response = imiGeneratorController.generateIMIFiles(
                VALID_TOKEN, REQUEST_ID, request);

            // Assert
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }

    @Test
    void generateIMIFiles_SecurityException_ShouldReturn403() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidGenerateIMIRequest();
        GenerateIMIRequestValidator.ValidationResult validationResult = 
            new GenerateIMIRequestValidator.ValidationResult();

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(requestValidator.validate(any(GenerateIMIRequest.class))).thenReturn(validationResult);
            when(imiFileGeneratorService.generateIMIFiles(any(GenerateIMIRequest.class), eq(USER_ID)))
                .thenThrow(new SecurityException("Access denied to Excel file"));

            // Act
            ResponseEntity<Object> response = imiGeneratorController.generateIMIFiles(
                VALID_TOKEN, REQUEST_ID, request);

            // Assert
            assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        }
    }

    @Test
    void generateIMIFiles_ServiceException_ShouldReturn500() throws Exception {
        // Arrange
        GenerateIMIRequest request = createValidGenerateIMIRequest();
        GenerateIMIRequestValidator.ValidationResult validationResult = 
            new GenerateIMIRequestValidator.ValidationResult();

        try (MockedStatic<HVWUtils> hvwUtils = mockStatic(HVWUtils.class)) {
            hvwUtils.when(() -> HVWUtils.getUserIdFromJWT(VALID_TOKEN)).thenReturn(USER_ID);
            when(requestValidator.validate(any(GenerateIMIRequest.class))).thenReturn(validationResult);
            when(imiFileGeneratorService.generateIMIFiles(any(GenerateIMIRequest.class), eq(USER_ID)))
                .thenThrow(new RuntimeException("Database connection failed"));

            // Act
            ResponseEntity<Object> response = imiGeneratorController.generateIMIFiles(
                VALID_TOKEN, REQUEST_ID, request);

            // Assert
            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    // Test missing headers
    @Test
    void allEndpoints_MissingAuthHeader_ShouldReturn400() throws Exception {
        // Test segments endpoint - passing null for auth header
        ResponseEntity<Object> segmentResponse = imiGeneratorController.getSegments(null, REQUEST_ID);
        assertEquals(HttpStatus.UNAUTHORIZED, segmentResponse.getStatusCode());
        Map<String, Object> segmentErrorBody = (Map<String, Object>) segmentResponse.getBody();
        Map<String, Object> segmentServiceMessage = (Map<String, Object>) segmentErrorBody.get("serviceMessage");
        assertEquals(401, segmentServiceMessage.get("returnCode"));
        assertTrue(segmentServiceMessage.get("returnCodeDescription").toString().contains("Authentication required"));

        // Test generate-imi endpoint - passing null for auth header
        GenerateIMIRequest request = createValidGenerateIMIRequest();
        ResponseEntity<Object> generateResponse = imiGeneratorController.generateIMIFiles(null, REQUEST_ID, request);
        assertEquals(HttpStatus.UNAUTHORIZED, generateResponse.getStatusCode());
        Map<String, Object> generateErrorBody = (Map<String, Object>) generateResponse.getBody();
        Map<String, Object> generateServiceMessage = (Map<String, Object>) generateErrorBody.get("serviceMessage");
        assertEquals(401, generateServiceMessage.get("returnCode"));
        assertTrue(generateServiceMessage.get("returnCodeDescription").toString().contains("Authentication required"));
    }

    @Test
    void allEndpoints_MissingRequestIdHeader_ShouldReturn400() throws Exception {
        // Test segments endpoint - passing null for request ID
        ResponseEntity<Object> segmentResponse = imiGeneratorController.getSegments(VALID_TOKEN, null);
        assertEquals(HttpStatus.UNAUTHORIZED, segmentResponse.getStatusCode());
        Map<String, Object> segmentErrorBody = (Map<String, Object>) segmentResponse.getBody();
        Map<String, Object> segmentServiceMessage = (Map<String, Object>) segmentErrorBody.get("serviceMessage");
        assertEquals(401, segmentServiceMessage.get("returnCode"));
        assertTrue(segmentServiceMessage.get("returnCodeDescription").toString().contains("Authentication required"));
    }

    // Helper methods
    private GenerateIMIRequest createValidGenerateIMIRequest() {
        GenerateIMIRequest request = new GenerateIMIRequest();
        request.setExcelId(123);

        // File mappings
        GenerateIMIRequest.FileIdMapping mapping = new GenerateIMIRequest.FileIdMapping();
        mapping.setFileId(456);
        mapping.setExcelFileName("test.pdf");
        request.setFileIdMappings(Arrays.asList(mapping));

        // Segment mappings
        GenerateIMIRequest.SegmentMapping segmentMapping = new GenerateIMIRequest.SegmentMapping();
        segmentMapping.setSegmentName("FID");
        segmentMapping.setType("U");
        segmentMapping.setValue("");
        request.setMappings(Arrays.asList(segmentMapping));

        // Output config
        GenerateIMIRequest.OutputConfig outputConfig = new GenerateIMIRequest.OutputConfig();
        outputConfig.setDocumentsPerIMI(25);
        outputConfig.setFilePriority(99);
        request.setOutputConfig(outputConfig);

        return request;
    }

    private GenerateIMIResponse createValidGenerateIMIResponse() {
        GenerateIMIResponse response = new GenerateIMIResponse();

        // Generated files
        List<GenerateIMIResponse.GeneratedFile> files = new ArrayList<>();
        GenerateIMIResponse.GeneratedFile file1 = new GenerateIMIResponse.GeneratedFile();
        file1.setImiFileId(789);
        file1.setImiFileName("batch1.imi");
        file1.setDocumentCount(50);
        file1.setStatus("SUCCESS");
        
        GenerateIMIResponse.GeneratedFile file2 = new GenerateIMIResponse.GeneratedFile();
        file2.setImiFileId(790);
        file2.setImiFileName("batch2.imi");
        file2.setDocumentCount(45);
        file2.setStatus("SUCCESS");
        
        files.add(file1);
        files.add(file2);
        response.setGeneratedFiles(files);

        // Summary
        GenerateIMIResponse.Summary summary = new GenerateIMIResponse.Summary();
        summary.setTotalRows(100);
        summary.setSuccessful(95);
        summary.setFailed(5);
        summary.setWarnings(0);
        response.setSummary(summary);

        response.setOutputExcelId(456);
        response.setMessage("Successfully generated 2 IMI files");

        return response;
    }
}