package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblPickListItems;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.layouts.LayoutsAndActions;
import com.hmhs.hvwmid.model.ApiSection;
import com.hmhs.hvwmid.model.Form;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.model.TableDefinition;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.CustomPostService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.ReportService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.view.RedirectView;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.contains;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE;

class AppDataControllerTest {

    @InjectMocks
    AppDataController controller;


    @Mock
    private AppDataService service;

    @Mock
    ReportService reportService;

    @Mock
    LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @Mock
    private CustomPostService cpService;

    @Mock
    private LayoutsAndActions layoutsActions;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(request.getRequestURI()).thenReturn("/mock");
        controller.loginUser = "user123";
        controller.appPath = "/mock";
    }

    @Test
    void testGetMainMenu_success() {
        String authToken = "validToken";
        int requestId = 100;
        String json = "{\"menu\": [\"Home\", \"Reports\"]}";

        TblTemplates template = new TblTemplates();
        template.setContent(json.getBytes(StandardCharsets.UTF_8));

        when(service.getTempletByName("AppMainMenu")).thenReturn(List.of(template));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("user123");

            ResponseEntity<String> response = controller.getMainMenu(authToken, requestId);

            assertEquals(OK, response.getStatusCode());
            assertEquals(json, response.getBody());
        }
    }

    @Test
    void testGetMainMenu_userIdMissing() {
        String authToken = "invalidToken";
        int requestId = 101;
        String json = "{\"menu\": [\"Settings\"]}";

        TblTemplates template = new TblTemplates();
        template.setContent(json.getBytes(StandardCharsets.UTF_8));

        when(service.getTempletByName("AppMainMenu")).thenReturn(List.of(template));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(null);

            ResponseEntity<String> response = controller.getMainMenu(authToken, requestId);

            assertEquals(OK, response.getStatusCode());
            assertEquals(json, response.getBody());
        }
    }

    @Test
    void testGetMainMenu_exceptionThrown() {
        String authToken = "token";
        int requestId = 102;

        when(service.getTempletByName("AppMainMenu"))
                .thenThrow(new RuntimeException("Database error"));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userX");

            ResponseEntity<String> response = controller.getMainMenu(authToken, requestId);

            assertEquals(SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    @Test
    void testGetPickListByPickListId_success() throws Exception {
        String authToken = "auth-token";
        Integer requestId = 123;
        String pickListId = "picklist-1";

        // mock HVWUtils.getUserIdFromJWT
        try (MockedStatic<HVWUtils> mocked = Mockito.mockStatic(HVWUtils.class)) {
            mocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("testUser");

            TblPickListItems item = mock(TblPickListItems.class);
            when(item.getDisplayName()).thenReturn("displayName");
            when(item.getDependentKey()).thenReturn("parentKey");
            when(item.getKey()).thenReturn("key");

            when(service.getPickList(pickListId)).thenReturn(List.of(item));

            ResponseEntity<List<PickListItems>> response = controller.getPickListByPickListId(pickListId, requestId, authToken);

            assertEquals(OK, response.getStatusCode());
            List<PickListItems> body = response.getBody();
            assertNotNull(body);
            assertEquals(1, body.size());
            assertEquals("displayName", body.get(0).getDisplayName());
            assertEquals("parentKey", body.get(0).getParentKey());
            assertEquals("key", body.get(0).getKey());

            verify(service).getPickList(pickListId);
        }
    }

    @Test
    void testGetPickListByPickListId_exception() throws Exception {
        String authToken = "auth-token";
        Integer requestId = 123;
        String pickListId = "picklist-1";

        try (MockedStatic<HVWUtils> mocked = Mockito.mockStatic(HVWUtils.class)) {
            mocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("testUser");

            when(service.getPickList(pickListId)).thenThrow(new RuntimeException("fail"));

            ResponseEntity<List<PickListItems>> response = controller.getPickListByPickListId(pickListId, requestId, authToken);

            assertEquals(OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertTrue(response.getBody().isEmpty());

            verify(service).getPickList(pickListId);
            verify(loggerService).log(eq("ERROR"), eq(requestId), eq(0), eq(0), eq("testUser"), eq("getPickListByPickListId"),
                    eq("/mock"), eq("503"), contains("fail"));
        }
    }

    @Test
    void testGetPickListByIdAndKey_success() {
        String authToken = "auth-token";
        Integer requestId = 11;
        String pickListId = "plid";
        String parentKey = "parent";

        try (MockedStatic<HVWUtils> mocked = Mockito.mockStatic(HVWUtils.class)) {
            mocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userX");

            TblPickListItems item = mock(TblPickListItems.class);
            when(item.getDisplayName()).thenReturn("name");
            when(item.getDependentKey()).thenReturn("depKey");
            when(item.getKey()).thenReturn("keyVal");

            when(service.getPickList(pickListId, parentKey)).thenReturn(List.of(item));

            ResponseEntity<List<PickListItems>> response = controller.getPickListByIdAndKey(pickListId, parentKey, requestId, authToken);

            assertEquals(OK, response.getStatusCode());
            assertEquals(1, response.getBody().size());
            assertEquals("name", response.getBody().get(0).getDisplayName());

            verify(service).getPickList(pickListId, parentKey);
        }
    }

    @Test
    void testGetPickListByIdAndKeyTwo_success() {
        String authToken = "auth-token";
        Integer requestId = 22;
        String pickListId = "plid2";
        String parentKey1 = "p1";
        String parentKey2 = "p2";

        try (MockedStatic<HVWUtils> mocked = Mockito.mockStatic(HVWUtils.class)) {
            mocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userY");

            TblPickListItems item = mock(TblPickListItems.class);
            when(item.getDisplayName()).thenReturn("name2");
            when(item.getDependentKey()).thenReturn("depKey2");
            when(item.getKey()).thenReturn("keyVal2");

            when(service.getPickList(pickListId, parentKey1 + "," + parentKey2)).thenReturn(List.of(item));

            ResponseEntity<List<PickListItems>> response = controller.getPickListByIdAndKeyTwo(pickListId, parentKey1, parentKey2, requestId, authToken);

            assertEquals(OK, response.getStatusCode());
            assertEquals(1, response.getBody().size());
            assertEquals("name2", response.getBody().get(0).getDisplayName());

            verify(service).getPickList(pickListId, parentKey1 + "," + parentKey2);
        }
    }

    @Test
    void testGetPickListByIdKeyThree_success() {
        String authToken = "auth-token";
        Integer requestId = 33;
        String pickListId = "plid3";
        String p1 = "a";
        String p2 = "b";
        String p3 = "c";

        try (MockedStatic<HVWUtils> mocked = Mockito.mockStatic(HVWUtils.class)) {
            mocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userZ");

            TblPickListItems item = mock(TblPickListItems.class);
            when(item.getDisplayName()).thenReturn("name3");
            when(item.getDependentKey()).thenReturn("depKey3");
            when(item.getKey()).thenReturn("keyVal3");

            when(service.getPickList(pickListId, p1 + "," + p2 + "," + p3)).thenReturn(List.of(item));

            ResponseEntity<List<PickListItems>> response = controller.getPickListByIdKeyThree(pickListId, p1, p2, p3, requestId, authToken);

            assertEquals(OK, response.getStatusCode());
            assertEquals(1, response.getBody().size());
            assertEquals("name3", response.getBody().get(0).getDisplayName());

            verify(service).getPickList(pickListId, p1 + "," + p2 + "," + p3);
        }
    }

    @Test
    void testGetLookupValues_success() {
        String authToken = "auth-token";
        Integer requestId = 44;
        String fieldId = "fid";
        String lookupValue = "val";

        try (MockedStatic<HVWUtils> mocked = Mockito.mockStatic(HVWUtils.class)) {
            mocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userLookup");

            when(cpService.getLookupValues(fieldId, lookupValue)).thenReturn(List.of("val1", "val2"));

            ResponseEntity<List<PickListItems>> response = controller.getLookupValues(fieldId, lookupValue, requestId, authToken);

            assertEquals(OK, response.getStatusCode());
            assertEquals(2, response.getBody().size());
            assertEquals("val1", response.getBody().get(0).getDisplayName());

            verify(cpService).getLookupValues(fieldId, lookupValue);
        }
    }

    @Test
    void testRedirectToSearch_withoutTemplateParam() {
        Map<String, String> queryParams = Map.of("param1", "value1");

        Object result = controller.redirectToSearch(queryParams);

        assertNull(result);
    }

    @Test
    void testGetActionsForFormId_CMOD_success() throws Exception {
        String fid = "CMOD123";
        String authToken = "validToken";
        Integer requestId = 42;

        ApiSection apiSection = mock(ApiSection.class);
        TblSectionDetails sectionDetail = new TblSectionDetails();
        sectionDetail.setHtmlContent("html-content".getBytes(StandardCharsets.UTF_8));
        when(apiSection.getHtmlContentByFolderName(fid)).thenReturn(List.of(sectionDetail));

        when(reportService.getCmodFolderData(eq(fid), anyString(), eq(authToken))).thenReturn("responseData");

        ResponseEntity<Object> response = controller.getActionsForFormId(fid, authToken, requestId);

        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());
        assertEquals("responseData", response.getBody());
    }

    @Test
    void testGetActionsForFormId_CMOD_sectionDetailsNull() throws Exception {
        String fid = "CMOD123";
        String authToken = "token";
        Integer requestId = 1;

        controller.loginUser = "userX";


        when(reportService.getCmodFolderData(eq(fid), eq(""), eq(authToken))).thenReturn("emptyHelpResponse");

        ResponseEntity<Object> response = controller.getActionsForFormId(fid, authToken, requestId);

        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());
        assertEquals("emptyHelpResponse", response.getBody());
    }

    @Test
    void testGetActionsForFormId_nonCMOD_success() throws Exception {
        String fid = "NONCMOD1";
        String authToken = "token";
        Integer requestId = 10;

        TblForms tblForm = new TblForms();
        tblForm.setFormName("FormName");
        tblForm.setType("FormType");

        Form form = new Form();

        when(service.getForm(fid)).thenReturn(tblForm);
        when(layoutsActions.getLayoutAndActions(fid)).thenReturn(form);

        ResponseEntity<Object> response = controller.getActionsForFormId(fid, authToken, requestId);

        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        Form returnedForm = (Form) response.getBody();
        assertEquals("FormName", returnedForm.getFormName());
        assertEquals("FormType", returnedForm.getType());
    }

    @Test
    void testGetActionsForFormId_HVWExceptionThrown() throws Exception {
        String fid = "NONCMOD2";
        String authToken = "token";
        Integer requestId = 5;

        when(layoutsActions.getLayoutAndActions(fid)).thenThrow(new HVWException("Custom HVW error"));

        ResponseEntity<Object> response = controller.getActionsForFormId(fid, authToken, requestId);

        assertNotNull(response);
        assertTrue(response.getStatusCode().is4xxClientError() || response.getStatusCode().is5xxServerError());
    }

    @Test
    void testGetActionsForFormId_GeneralExceptionThrown() throws Exception {
        String fid = "NONCMOD3";
        String authToken = "token";
        Integer requestId = 7;

        when(layoutsActions.getLayoutAndActions(fid)).thenThrow(new RuntimeException("General error"));

        ResponseEntity<Object> response = controller.getActionsForFormId(fid, authToken, requestId);

        assertNotNull(response);
        assertEquals(503, response.getStatusCodeValue());
    }

    @Test
    void testGetTableDefinition_tokenThrowsException() {
        String tableId = "TBL002";
        String authToken = "badToken";
        Integer requestId = 77;

        try (MockedStatic<HVWUtils> hvwUtilsMocked = mockStatic(HVWUtils.class)) {
            hvwUtilsMocked.when(() -> HVWUtils.getUserIdFromJWT(authToken))
                    .thenThrow(new RuntimeException("Token fail"));

            ResponseEntity<TableDefinition> response = controller.getTableDefinition(tableId, requestId, authToken);

            assertEquals(SERVICE_UNAVAILABLE, response.getStatusCode());
            assertNotNull(response.getBody());
        }
    }

//    @Test
//    void testGetTableDefinition_apiSectionThrowsException() {
//        String tableId = "TBL003";
//        String authToken = "validToken";
//        Integer requestId = 99;
//
//        ApiSection apiSpy = spy(new ApiSection());
//        apiSpy.setService(service);
//
//        try (MockedStatic<HVWUtils> hvwUtilsMocked = mockStatic(HVWUtils.class)) {
//            hvwUtilsMocked.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("user123");
//
//            doThrow(new RuntimeException("DB failure"))
//                    .when(apiSpy).getTableDefinition(any(), eq(tableId));
//
//            ResponseEntity<TableDefinition> response = new AppDataController() {{
//                this.service = AppDataControllerTest.this.service;
//                this.loggerService = AppDataControllerTest.this.loggerService;
//                this.request = AppDataControllerTest.this.request;
//                this.loginUser = "user123";
//            }}.getTableDefinition(tableId, requestId, authToken);
//
//            assertEquals(SERVICE_UNAVAILABLE, response.getStatusCode());
//            assertNotNull(response.getBody());
//        }
//    }

    @Test
    void testImgSessionMgrRedirect_actionListobj2a_templateRedirect_returnsUrl() {
        AppDataController controller = new AppDataController();
        controller.appPath = "/mock";
        // Inject mock service
        try {
            var serviceField = AppDataController.class.getDeclaredField("service");
            serviceField.setAccessible(true);
            serviceField.set(controller, service);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Map<String, String> queryParams = Map.of(
                "template", "testfile.txt",
                "foo", "bar",
                "action", "listobj2a"
        );
        TblForms form = new TblForms();
        form.setFormId("FORM123");
        when(service.getFormIdByFileName("testfile")).thenReturn(List.of(form));
        Object result = controller.redirectToSearch(queryParams);
        assertNotNull(result);

        assertInstanceOf(RedirectView.class, result);

        String url = ((RedirectView) result).getUrl();
        assertNotNull(url);
        assertTrue(url.contains("pages/search/FORM123"), "Expected URL to contain pages/search/FORM123, but got: " + url);

        assertTrue(url.contains("foo=bar"));
    }

    @Test
    void testImgSessionMgrRedirect_actionListrptCMOD_withDateAndFields() {
        AppDataController controller = new AppDataController();
        controller.appPath = "/mock";
        Map<String, String> queryParams = Map.of(
                "action", "listrptCMOD",
                "cmodFolderName", "TestFolder",
                "begindate", "02/06/2022",
                "enddate", "02/08/2022",
                "TRACKING_ID", "INTR-2635_Membersearchrules_File-685",
                "field6", "TRACKING_ID",
                "foo", "bar"
        );
        Object result = controller.redirectToSearch(queryParams);
        assertNotNull(result);
        assertTrue(result instanceof Map);
        String url = (String) ((Map<?, ?>) result).get("url");
        assertTrue(url.startsWith("/pages/single-report/CMODTestFolder"));
        // Dates should be formatted as yyyy-MM-dd
        assertTrue(url.contains("begindate=2022-02-06"));
        assertTrue(url.contains("enddate=2022-02-08"));
        // field6 should resolve to value of TRACKING_ID
        assertTrue(url.contains("field6=INTR-2635_Membersearchrules_File-685"));
        // Should not contain foo, bar, or TRACKING_ID as a param
        assertFalse(url.contains("foo="));
        assertFalse(url.contains("bar"));
        assertFalse(url.contains("TRACKING_ID="));
        assertFalse(url.contains("cmodFolderName="));
    }

    @Test
    void testImgSessionMgrRedirect_actionListrptCMOD_withShortYear() {
        AppDataController controller = new AppDataController();
        controller.appPath = "/mock";
        Map<String, String> queryParams = Map.of(
                "action", "listrptCMOD",
                "cmodFolderName", "TestFolder",
                "begindate", "02/06/22",
                "enddate", "02/08/22"
        );
        Object result = controller.redirectToSearch(queryParams);
        assertNotNull(result);
        String url = (String) ((Map<?, ?>) result).get("url");
        assertTrue(url.startsWith("/pages/single-report/CMODTestFolder"));
        assertTrue(url.contains("begindate=2022-02-06"));
        assertTrue(url.contains("enddate=2022-02-08"));
        assertFalse(url.contains("cmodFolderName="));
    }

    @Test
    void testImgSessionMgrRedirect_actionListrptCMOD_onlyDates() {
        AppDataController controller = new AppDataController();
        controller.appPath = "/mock";
        Map<String, String> queryParams = Map.of(
                "action", "listrptCMOD",
                "cmodFolderName", "TestFolder",
                "begindate", "12/31/2023",
                "enddate", "01/01/2024"
        );
        Object result = controller.redirectToSearch(queryParams);
        assertNotNull(result);
        String url = (String) ((Map<?, ?>) result).get("url");
        assertTrue(url.startsWith("/pages/single-report/CMODTestFolder"));
        assertTrue(url.contains("begindate=2023-12-31"));
        assertTrue(url.contains("enddate=2024-01-01"));
        assertFalse(url.contains("cmodFolderName="));
    }

    @Test
    void testImgSessionMgrRedirect_actionListrptCMOD_fieldsWithoutValueAreIgnored() {
        AppDataController controller = new AppDataController();
        controller.appPath = "/mock";
        Map<String, String> queryParams = Map.of(
                "action", "listrptCMOD",
                "cmodFolderName", "TestFolder",
                "field1", "SOME_FIELD",
                "foo", "bar"
        );
        Object result = controller.redirectToSearch(queryParams);
        assertNotNull(result);
        String url = (String) ((Map<?, ?>) result).get("url");
        // field1 should not be present since SOME_FIELD is not in params
        assertFalse(url.contains("field1="));
        assertFalse(url.contains("foo="));
        assertFalse(url.contains("bar"));
        assertFalse(url.contains("cmodFolderName="));
    }


    @Test
    void testGetEdmMainMenu_Success() {
        TblTemplates template = new TblTemplates();
        template.setContent("menu data".getBytes(StandardCharsets.UTF_8));

        when(service.getTempletByName("EdmMainMenu"))
                .thenReturn(Collections.singletonList(template));

        try (MockedStatic<HVWUtils> hvwUtilsMock = Mockito.mockStatic(HVWUtils.class)) {
            hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT("valid-token"))
                    .thenReturn("testUser");

            ResponseEntity<String> response = controller.getEdmMainMenu("valid-token", 123);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("menu data", response.getBody());
        }
    }

    @Test
    void testGetEdmMainMenu_InvalidToken() {
        when(service.getTempletByName("EdmMainMenu"))
                .thenReturn(Collections.emptyList());

        try (MockedStatic<HVWUtils> hvwUtilsMock = Mockito.mockStatic(HVWUtils.class)) {
            hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT("bad-token"))
                    .thenReturn(null);

            ResponseEntity<String> response = controller.getEdmMainMenu("bad-token", 456);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    @Test
    void testGetEdmMainMenu_ExceptionThrown() {
        when(service.getTempletByName("EdmMainMenu"))
                .thenThrow(new RuntimeException("Database error"));

        try (MockedStatic<HVWUtils> hvwUtilsMock = Mockito.mockStatic(HVWUtils.class)) {
            hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT("valid-token"))
                    .thenReturn("testUser");

            ResponseEntity<String> response = controller.getEdmMainMenu("valid-token", 789);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    @Test
    void testGetIoMainMenu_Success() {
        TblTemplates template = new TblTemplates();
        template.setContent("io menu data".getBytes(StandardCharsets.UTF_8));

        when(service.getTempletByName("ImageOptionsMainMenu"))
                .thenReturn(Collections.singletonList(template));

        try (MockedStatic<HVWUtils> hvwUtilsMock = Mockito.mockStatic(HVWUtils.class)) {
            hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT("valid-token"))
                    .thenReturn("testUser");

            ResponseEntity<String> response = controller.getIoMainMenu("valid-token", 1001);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("io menu data", response.getBody());
        }
    }

    @Test
    void testGetIoMainMenu_InvalidToken() {
        when(service.getTempletByName("ImageOptionsMainMenu"))
                .thenReturn(Collections.emptyList());

        try (MockedStatic<HVWUtils> hvwUtilsMock = Mockito.mockStatic(HVWUtils.class)) {
            hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT("bad-token"))
                    .thenReturn(null);

            ResponseEntity<String> response = controller.getIoMainMenu("bad-token", 1002);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    @Test
    void testGetIoMainMenu_ExceptionThrown() {
        when(service.getTempletByName("ImageOptionsMainMenu"))
                .thenThrow(new RuntimeException("DB fail"));

        try (MockedStatic<HVWUtils> hvwUtilsMock = Mockito.mockStatic(HVWUtils.class)) {
            hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT("valid-token"))
                    .thenReturn("testUser");

            ResponseEntity<String> response = controller.getIoMainMenu("valid-token", 1003);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

}