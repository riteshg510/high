package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.controllers.ListApplIdsController;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListApplIdsService;
import com.hmhs.hvwmid.service.LoggerService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class ListApplIdsControllerTest {

    @InjectMocks
    private ListApplIdsController listApplIdsController;

    @Mock
    private ListApplIdsService service;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @Test
    void testFilter_Success() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.filter(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listApplIdsController.filter(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).filter(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }


}