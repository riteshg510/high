package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListPenaltyBoxService;
import com.hmhs.hvwmid.service.LoggerService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class ListPenaltyBoxControllerTest {

    @InjectMocks
    private ListPenaltyBoxController listPenaltyBoxController;

    @Mock
    private ListPenaltyBoxService service;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @Test
    void testFilter_getAllSuccess() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.getAll(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listPenaltyBoxController.getAll(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).getAll(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }

    @Test
    void testFilter_addSuccess() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.add(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listPenaltyBoxController.create(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).add(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }

    @Test
    void testFilter_deleteSuccess() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.delete(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listPenaltyBoxController.delete(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).delete(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }

    @Test
    void testFilter_extendSuccess() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.extend(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listPenaltyBoxController.extend(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).extend(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }

    @Test
    void testFilter_resetSuccess() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.reset(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listPenaltyBoxController.reset(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).reset(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }
}