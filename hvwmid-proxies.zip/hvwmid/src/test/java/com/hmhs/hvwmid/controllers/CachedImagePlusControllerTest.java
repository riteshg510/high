package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.TblImgToken;
import com.hmhs.hvwmid.service.ImageCachingService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CachedImagePlusControllerTest {

    @Mock
    private ImageCachingService imageCachingService;

    @InjectMocks
    private CachedImagePlusController controller;

    private static final String AUTH_TOKEN = "Bearer testToken";

    private MockedStatic<HVWUtils> mockedHVWUtils;

    @Mock
    private HttpServletRequest request;

    @Mock
    private LoggerService loggerService;



    @BeforeEach
    void setUp() {
        mockedHVWUtils = Mockito.mockStatic(HVWUtils.class);
        ReflectionTestUtils.setField(controller, "request", request);

        doNothing().when(loggerService).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
        ReflectionTestUtils.setField(controller, "loggerService", loggerService);
    }

    @AfterEach
    void tearDown() {
        mockedHVWUtils.close();
    }

    @Test
    void testGetDocumentStream_successPdf() {
        Integer requestId = 123;
        TblImgToken tokenEntity = new TblImgToken();
        tokenEntity.setUserId("user123");
        tokenEntity.setDocumentToken("doc123");
        tokenEntity.setDocumentType("PDF");

        mockedHVWUtils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn("user123");

        when(imageCachingService.getDocumentToken(requestId)).thenReturn(tokenEntity);
        when(imageCachingService.streamDocument(requestId)).thenReturn(outputStream -> {});

        // Simulate query param authToken
        ResponseEntity<StreamingResponseBody> response = controller.getDocumentStream(requestId, null, AUTH_TOKEN, null);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(MediaType.APPLICATION_PDF, response.getHeaders().getContentType());
        assertTrue(response.getHeaders().getContentDisposition().toString().contains(".pdf"));
    }

    @Test
    void testGetDocumentStream_unauthorized() {
        Integer requestId = 456;
        TblImgToken tokenEntity = new TblImgToken();
        tokenEntity.setUserId("user123");
        tokenEntity.setDocumentToken("doc456");
        tokenEntity.setDocumentType("PDF");

        mockedHVWUtils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn("unauthorizedUser");

        when(imageCachingService.getDocumentToken(requestId)).thenReturn(tokenEntity);

        ResponseEntity<StreamingResponseBody> response = controller.getDocumentStream(requestId, null, AUTH_TOKEN, null);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    void testGetDocumentStream_notFound() {
        Integer requestId = 789;
        TblImgToken tokenEntity = new TblImgToken();
        tokenEntity.setUserId("user123");
        tokenEntity.setDocumentToken("doc789");
        tokenEntity.setDocumentType("XML");

        mockedHVWUtils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn("user123");

        when(imageCachingService.getDocumentToken(requestId)).thenReturn(tokenEntity);
        when(imageCachingService.streamDocument(requestId)).thenReturn(null);

        ResponseEntity<StreamingResponseBody> response = controller.getDocumentStream(requestId, null, AUTH_TOKEN, null);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    void testGetCodTokenBeforeUpload_success() {
        Integer requestId = 321;
        TblImgToken tokenResult = new TblImgToken();
        tokenResult.setUserId("user123");
        tokenResult.setDocumentToken("uploadToken");

        mockedHVWUtils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn("user123");
        when(imageCachingService.saveToken("user123", AUTH_TOKEN, "")).thenReturn(tokenResult);

        // Simulate header injection for authToken and requestId
        ResponseEntity<Object> response = controller.getCodTokenBeforeUpload(AUTH_TOKEN, requestId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof Map);

        Map<String, Object> body = (Map<String, Object>) response.getBody();
        assertTrue(body.containsKey("cacheRequestId"));
        assertTrue(body.containsKey("uploadUrl"));
        assertTrue(body.containsKey("backendServer"));
    }

    @Test
    void testGetCodTokenBeforeUpload_internalServerError() {
        Integer requestId = 999;

        mockedHVWUtils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn("user123");
        when(imageCachingService.saveToken(any(), any(), any())).thenThrow(new RuntimeException("Test error"));

        // Simulate header injection for authToken and requestId
        ResponseEntity<Object> response = controller.getCodTokenBeforeUpload(AUTH_TOKEN, requestId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());
    }
}
