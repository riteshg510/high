package com.hmhs.hvwmid.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hmhs.hvwmid.model.*;
import com.hmhs.hvwmid.model.IMISearchData.BaseMessage;
import com.hmhs.hvwmid.model.IMISearchData.ServiceMessage;
import com.hmhs.hvwmid.service.*;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import java.util.*;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class IMIControllerTest {

    private static final String AUTH_TOKEN = "valid.jwt.token";
    private static final String MOCK_USER = "testUser";
    private static final Integer REQUEST_ID = 123;
    private static final String NAIC1 = "NAIC1";
    private static final String VALUE1 = "Value1";
    private static final String NAIC2 = "NAIC2";
    private static final String VALUE2 = "Value2";
    private static final String SERVICE_ERROR = "Service error";
    private static final String SEARCH = "search";
    private static final String STATUS = "status";

    private IMIController imiController;
    
    @Mock
    private IMIActivityTrackingService imiActivityTrackingService;
    
    @Mock
    private IMIGeneratorService imiGeneratorService;
    
    @Mock
    private IMIUpdateService imiUpdateService;
    
    @Mock
    private LoggerService loggerService;
    
    @Mock
    private AppDataService appDataService;
    
    @Mock
    private HttpServletRequest request;

    @BeforeEach
    void setup() {
    	lenient().when(request.getRequestURI()).thenReturn("/mock-uri");

        imiController = new IMIController();
        setField(imiController, "imiActivityTrackingService", imiActivityTrackingService);
        setField(imiController, "imiGeneratorService", imiGeneratorService);
        setField(imiController, "imiUpdateService", imiUpdateService);
        setField(imiController, "loggerService", loggerService);
        setField(imiController, "service", appDataService);
        setField(imiController, "request", request);
        
        // Reset the loginUser field to ensure clean state
        setField(imiController, "loginUser", "LIDUSER");
    }

    private void setField(Object target, String fieldName, Object value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set field: " + fieldName, e);
        }
    }

    private void setupSuccessfulAuthMock(MockedStatic<HVWUtils> utils) {
        // Mock the environment check to return true (noservice mode)
        utils.when(() -> HVWUtils.isIsNoserviceEnv()).thenReturn(true);
        
        // Mock the JWT method to ALWAYS return our test user, regardless of input
        utils.when(() -> HVWUtils.getUserIdFromJWT(any())).thenReturn(MOCK_USER);
        utils.when(() -> HVWUtils.getUserIdFromJWT(anyString())).thenReturn(MOCK_USER);
        utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(MOCK_USER);
        utils.when(() -> HVWUtils.getUserIdFromJWT(eq(AUTH_TOKEN))).thenReturn(MOCK_USER);
        utils.when(() -> HVWUtils.getUserIdFromJWT(isNull())).thenReturn(MOCK_USER);
    }


    @Test
    void testImiOnLoadSuccess() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            IMISearchData mockSearchData = new IMISearchData();
            Map<String, String> naicMap = new HashMap<>();
            naicMap.put(NAIC1, VALUE1);
            naicMap.put(NAIC2, VALUE2);
            mockSearchData.setNaicMap(naicMap);

            when(imiActivityTrackingService.imiOnLoad(AUTH_TOKEN)).thenReturn(mockSearchData);

            ResponseEntity<Object> response = imiController.imiOnLoad(AUTH_TOKEN, REQUEST_ID);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertTrue(response.getBody() instanceof List);
        }
    }

    @Test
    void testImiOnLoadUnauthorized() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(null);

            ResponseEntity<Object> response = imiController.imiOnLoad(AUTH_TOKEN, REQUEST_ID);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiOnLoadEmptyUser() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn("");

            ResponseEntity<Object> response = imiController.imiOnLoad(AUTH_TOKEN, REQUEST_ID);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiOnLoadServiceError() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            IMISearchData mockSearchData = new IMISearchData();
            BaseMessage errorMessage = new BaseMessage();
            errorMessage.setReturnCodeDescription("Access denied");
            mockSearchData.setBaseMessage(errorMessage);

            when(imiActivityTrackingService.imiOnLoad(AUTH_TOKEN)).thenReturn(mockSearchData);

            ResponseEntity<Object> response = imiController.imiOnLoad(AUTH_TOKEN, REQUEST_ID);

            assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        }
    }

    @Test
    void testImiOnLoadException() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            when(imiActivityTrackingService.imiOnLoad(AUTH_TOKEN)).thenThrow(new RuntimeException(SERVICE_ERROR));

            ResponseEntity<Object> response = imiController.imiOnLoad(AUTH_TOKEN, REQUEST_ID);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @Test
    void testImiRetrieveSuccess() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();
            Object mockResult = new Object();

            when(imiActivityTrackingService.imiRetrieve(anyString(), any(IMIUISearchRequest.class), 
                    anyString(), anyString(), anyString(), anyString())).thenReturn(mockResult);

            ResponseEntity<Object> response = imiController.imiRetrieve(AUTH_TOKEN, REQUEST_ID, SEARCH, 
                    "0", "20", searchRequest);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(mockResult, response.getBody());
        }
    }

    @Test
    void testImiRetrieveUnauthorized() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(null);

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();

            ResponseEntity<Object> response = imiController.imiRetrieve(AUTH_TOKEN, REQUEST_ID, SEARCH, 
                    "0", "20", searchRequest);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiRetrieveException() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            when(imiActivityTrackingService.imiRetrieve(anyString(), any(IMIUISearchRequest.class), 
                    anyString(), anyString(), anyString(), anyString()))
                    .thenThrow(new RuntimeException(SERVICE_ERROR));

            IMIUISearchRequest searchRequest = new IMIUISearchRequest();

            ResponseEntity<Object> response = imiController.imiRetrieve(AUTH_TOKEN, REQUEST_ID, SEARCH, 
                    "0", "20", searchRequest);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @Test
    void testRetrievePhiDataSuccess() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, Object> mockPhiData = new HashMap<>();
            mockPhiData.put(STATUS, "success");
            mockPhiData.put("phiData", "test data");

            // Mock the service method with any parameters since we can't predict the exact loginUser value
            when(imiActivityTrackingService.retrieveSegmentData(anyString(), anyString(), anyInt()))
                    .thenReturn(mockPhiData);

            ResponseEntity<Object> response = imiController.retrievePhiData(AUTH_TOKEN, REQUEST_ID, 123);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("test data", response.getBody());
        }
    }

    @Test
    void testRetrievePhiDataUnauthorized() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(null);

            ResponseEntity<Object> response = imiController.retrievePhiData(AUTH_TOKEN, REQUEST_ID, 123);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testRetrievePhiDataInvalidDocumentId() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            ResponseEntity<Object> response = imiController.retrievePhiData(AUTH_TOKEN, REQUEST_ID, 0);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }

    @Test
    void testRetrievePhiDataForbidden() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, Object> mockPhiData = new HashMap<>();
            mockPhiData.put(STATUS, "forbidden");
            mockPhiData.put("error", "Access denied");

            when(imiActivityTrackingService.retrieveSegmentData(anyString(), anyString(), anyInt()))
                    .thenReturn(mockPhiData);

            ResponseEntity<Object> response = imiController.retrievePhiData(AUTH_TOKEN, REQUEST_ID, 123);

            assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        }
    }

    @Test
    void testRetrievePhiDataException() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            when(imiActivityTrackingService.retrieveSegmentData(anyString(), anyString(), anyInt()))
                    .thenThrow(new RuntimeException(SERVICE_ERROR));

            ResponseEntity<Object> response = imiController.retrievePhiData(AUTH_TOKEN, REQUEST_ID, 123);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @Test
    void testImiUpdateRetrieveSuccess() throws JsonProcessingException {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            when(imiUpdateService.imionLoadUpdate(anyString())).thenReturn(true);
            Map<String, Object> map = new HashMap<>();
            IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();
            retrieveRequest.setField("TF");
            retrieveRequest.setFieldQuery("123");

            IMISearchData mockSearchData = new IMISearchData();
            ServiceMessage serviceMessage = new ServiceMessage();
            serviceMessage.setReturnCode(0);
            mockSearchData.setServiceMessage(serviceMessage);
            mockSearchData.setSearchResultsList(new ArrayList<>()); // Add empty list to avoid null pointer

            when(imiUpdateService.imiUpdateRetrieve(anyString(), anyString(), anyString(), anyString()))
                    .thenReturn(mockSearchData);
            when(imiUpdateService.convertToTableFormat(any(List.class), any(IMIUpdateRetrieveRequest.class)))
                    .thenReturn(map);         
            ResponseEntity<Object> response = imiController.imiUpdateRetrieve(AUTH_TOKEN, REQUEST_ID, retrieveRequest);
            assertEquals(HttpStatus.OK, response.getStatusCode());
        }
    }

    @Test
    void testImiUpdateRetrieveUnauthorized() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(null);

            IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();

            ResponseEntity<Object> response = imiController.imiUpdateRetrieve(AUTH_TOKEN, REQUEST_ID, retrieveRequest);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiUpdateRetrieveNoAccess() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            lenient().when(request.getRequestURI()).thenReturn("/mock-uri");

            IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();

            ResponseEntity<Object> response = imiController.imiUpdateRetrieve(AUTH_TOKEN, REQUEST_ID, retrieveRequest);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiUpdateRetrieveException() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            when(imiUpdateService.imionLoadUpdate(AUTH_TOKEN)).thenReturn(true);
            when(imiUpdateService.imiUpdateRetrieve(anyString(), anyString(), anyString(), anyString()))
                    .thenThrow(new RuntimeException(SERVICE_ERROR));

            IMIUpdateRetrieveRequest retrieveRequest = new IMIUpdateRetrieveRequest();

            ResponseEntity<Object> response = imiController.imiUpdateRetrieve(AUTH_TOKEN, REQUEST_ID, retrieveRequest);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @SuppressWarnings("unchecked")
	@Test
    void testImiUpdateSuccess() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put("id", "123");
            inputRequest.put(STATUS, "updated");

            IMIUpdateData mockUpdateData = new IMIUpdateData();
            mockUpdateData.setResponseMessage("Update successful");

            when(imiUpdateService.imiUpdate(anyString(), anyString(), any(Map.class)))
                    .thenReturn(mockUpdateData);

            ResponseEntity<Object> response = imiController.imiUpdate(AUTH_TOKEN, REQUEST_ID, inputRequest);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(mockUpdateData, response.getBody());
        }
    }

    @Test
    void testImiUpdateUnauthorized() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(null);

            Map<String, Object> inputRequest = new HashMap<>();

            ResponseEntity<Object> response = imiController.imiUpdate(AUTH_TOKEN, REQUEST_ID, inputRequest);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiUpdateEmptyRequest() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, Object> inputRequest = new HashMap<>();

            ResponseEntity<Object> response = imiController.imiUpdate(AUTH_TOKEN, REQUEST_ID, inputRequest);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }

    @Test
    void testImiUpdateNullRequest() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            ResponseEntity<Object> response = imiController.imiUpdate(AUTH_TOKEN, REQUEST_ID, null);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }

    @SuppressWarnings("unchecked")
	@Test
    void testImiUpdateException() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);
            
            // Mock the service to throw an exception
            when(imiUpdateService.imiUpdate(anyString(), anyString(), any(Map.class)))
                    .thenThrow(new RuntimeException(SERVICE_ERROR));

            Map<String, Object> inputRequest = new HashMap<>();
            inputRequest.put("id", "123");

            ResponseEntity<Object> response = imiController.imiUpdate(AUTH_TOKEN, REQUEST_ID, inputRequest);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @Test
    void testTransformNaicMapToPickListItems() {
        Map<String, String> naicMap = new HashMap<>();
        naicMap.put(NAIC1, VALUE1);
        naicMap.put(NAIC2, VALUE2);

        try {
            java.lang.reflect.Method method = IMIController.class.getDeclaredMethod("transformNaicMapToPickListItems", Map.class);
            method.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<PickListItems> result = (List<PickListItems>) method.invoke(imiController, naicMap);

            assertNotNull(result);
            assertEquals(2, result.size());
            
            // Check that both items are present (order-independent)
            boolean foundNAIC1 = false;
            boolean foundNAIC2 = false;
            
            for (PickListItems item : result) {
                if (NAIC1.equals(item.getDisplayName()) && VALUE1.equals(item.getKey())) {
                    foundNAIC1 = true;
                } else if (NAIC2.equals(item.getDisplayName()) && VALUE2.equals(item.getKey())) {
                    foundNAIC2 = true;
                }
            }
            
            assertTrue(foundNAIC1, "NAIC1 item not found in result");
            assertTrue(foundNAIC2, "NAIC2 item not found in result");
        } catch (Exception e) {
            fail("Failed to invoke private method: " + e.getMessage());
        }
    }

    @Test
    void testStoreRequestId() {
        try {
            java.lang.reflect.Method method = IMIController.class.getDeclaredMethod("storeRequestId", Integer.class);
            method.setAccessible(true);
            method.invoke(imiController, REQUEST_ID);
        } catch (Exception e) {
            fail("Failed to invoke private method: " + e.getMessage());
        }
    }

    @Test
    void testStoreRequestIdNull() {
        try {
            java.lang.reflect.Method method = IMIController.class.getDeclaredMethod("storeRequestId", Integer.class);
            method.setAccessible(true);
            method.invoke(imiController, (Integer) null);
        } catch (Exception e) {
            fail("Failed to invoke private method: " + e.getMessage());
        }
    }

    @Test
    void testImiCMODSearchSuccess() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, String> params = new HashMap<>();
            params.put("imiDocumentId", "123");
            params.put("extra", "x");

            when(imiActivityTrackingService.constructCMODSearchUrl(eq(123), anyMap())).thenReturn("http://test/url");

            ResponseEntity<Object> response = imiController.imiCMODSearch(AUTH_TOKEN, REQUEST_ID, params);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody() instanceof Map);
            @SuppressWarnings("unchecked")
            Map<String, String> body = (Map<String, String>) response.getBody();
            assertEquals("http://test/url", body.get("url"));
        }
    }

    @Test
    void testImiCMODSearchUnauthorized() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(null);

            Map<String, String> params = new HashMap<>();
            params.put("imiDocumentId", "123");

            ResponseEntity<Object> response = imiController.imiCMODSearch(AUTH_TOKEN, REQUEST_ID, params);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        }
    }

    @Test
    void testImiCMODSearchMissingParam() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, String> params = new HashMap<>();

            ResponseEntity<Object> response = imiController.imiCMODSearch(AUTH_TOKEN, REQUEST_ID, params);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        }
    }

    @Test
    void testImiCMODSearchInvalidDocId() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, String> params = new HashMap<>();
            params.put("imiDocumentId", "abc");

            ResponseEntity<Object> response = imiController.imiCMODSearch(AUTH_TOKEN, REQUEST_ID, params);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @Test
    void testImiCMODSearchException() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            setupSuccessfulAuthMock(utils);

            Map<String, String> params = new HashMap<>();
            params.put("imiDocumentId", "123");

            when(imiActivityTrackingService.constructCMODSearchUrl(eq(123), anyMap()))
                    .thenThrow(new RuntimeException(SERVICE_ERROR));

            ResponseEntity<Object> response = imiController.imiCMODSearch(AUTH_TOKEN, REQUEST_ID, params);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        }
    }

    @Test
    void testStaticMockWorking() {
        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.isIsNoserviceEnv()).thenReturn(true);
            utils.when(() -> HVWUtils.getUserIdFromJWT(AUTH_TOKEN)).thenReturn(MOCK_USER);
            
            // Test the mocks directly
            boolean isNoservice = HVWUtils.isIsNoserviceEnv();
            String user = HVWUtils.getUserIdFromJWT(AUTH_TOKEN);
                     
            assertTrue(isNoservice, "Noservice mock should return true");
            assertEquals(MOCK_USER, user, "User mock should return MOCK_USER");
        }
    }
}