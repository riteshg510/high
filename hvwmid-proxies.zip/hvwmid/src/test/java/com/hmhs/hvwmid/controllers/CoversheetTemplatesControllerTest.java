package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.model.CoverSheetObjectDTO;
import com.hmhs.hvwmid.model.CoverSheetOverrideDTO;
import com.hmhs.hvwmid.model.CoversheetFileResult;
import com.hmhs.hvwmid.service.CoversheetObjectServiceImpl;
import com.hmhs.hvwmid.service.CoversheetService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CoversheetTemplatesControllerTest {

    @Mock
    private CoversheetService coversheetService;

    @Mock
    private CoversheetObjectServiceImpl coversheetObjectService;
    @Mock
    private  LoggerService loggerService;
    @Mock
    private  HttpServletRequest request;

    @InjectMocks
    private CoversheetTemplatesController controller;

    private CoverSheetObjectDTO sampleObjectDTO;
    private T117ImgCoverObject sampleTemplate;
    private CoversheetFileResult sampleFileResult;
    private List<String> adminGroups;
    private List<String> nonAdminGroups;

    @BeforeEach
    void setup() {
        // Setup sample object DTO
        sampleObjectDTO = new CoverSheetObjectDTO("INVOICE", "TEMPLATE", "application/pdf", "Sample PDF content");

        // Setup sample template entity
        sampleTemplate = new T117ImgCoverObject();
        sampleTemplate.setObjName("INVOICE");
        sampleTemplate.setObjType("TEMPLATE");
        sampleTemplate.setMimeType("application/pdf");
        sampleTemplate.setObjData("Sample PDF content");
        sampleTemplate.setActive("Y");

        // Setup file result
        byte[] sampleData = "Sample file content".getBytes();
        sampleFileResult = new CoversheetFileResult(sampleData, "application/pdf", "invoice.pdf");

        // Setup user groups
        adminGroups = Arrays.asList("HVW-ADMINISTRATION-INT", "OTHER-GROUP");
        nonAdminGroups = Arrays.asList("USER-GROUP", "OTHER-GROUP");
    }

    @Test
    void displayCoverSheet_shouldReturnPdfFileWithCorrectHeaders() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        int applicationId = 1;
        int sequence = 0;
        String coversheetName = "invoice";
        boolean override = false;

        when(coversheetService.getCoverSheet(applicationId, sequence, coversheetName, override))
                .thenReturn(sampleFileResult);

        // When
        ResponseEntity<byte[]> result = controller.displayCoverSheet(applicationId, sequence, coversheetName, authToken,1);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(MediaType.APPLICATION_PDF, result.getHeaders().getContentType());
        assertEquals(sampleFileResult.getData().length, result.getHeaders().getContentLength());
        assertArrayEquals(sampleFileResult.getData(), result.getBody());

        verify(coversheetService).getCoverSheet(applicationId, sequence, coversheetName, override);
    }

    @Test
    void displayCoverSheet_shouldReturnHtmlFileWithCorrectHeaders() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoversheetFileResult htmlResult = new CoversheetFileResult(
                "<html>content</html>".getBytes(),
                "text/html",
                "template.html"
        );

        when(coversheetService.getCoverSheet(1, 0, "template", false)).thenReturn(htmlResult);

        // When
        ResponseEntity<byte[]> result = controller.displayCoverSheet(1, 0, "template", authToken,1);

        // Then
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(MediaType.TEXT_HTML, result.getHeaders().getContentType());
    }

    @Test
    void displayCoverSheet_shouldReturnTextPlainForJavaScript() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoversheetFileResult jsResult = new CoversheetFileResult(
                "function test() {}".getBytes(),
                "application/javascript",
                "script.js"
        );

        when(coversheetService.getCoverSheet(1, 0, "script", false)).thenReturn(jsResult);

        // When
        ResponseEntity<byte[]> result = controller.displayCoverSheet(1, 0, "script", authToken, 1);

        // Then
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(MediaType.TEXT_PLAIN, result.getHeaders().getContentType());
    }

    @Test
    void displayCoverSheet_shouldReturnOctetStreamForUnknownType() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoversheetFileResult unknownResult = new CoversheetFileResult(
                "binary data".getBytes(),
                "application/unknown",
                "data.bin"
        );

        when(coversheetService.getCoverSheet(1, 0, "data", false)).thenReturn(unknownResult);

        // When
        ResponseEntity<byte[]> result = controller.displayCoverSheet(1, 0, "data", authToken,1);

        // Then
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(MediaType.APPLICATION_OCTET_STREAM, result.getHeaders().getContentType());
    }

    @Test
    void displayCoverSheet_shouldHandleOverrideSequence() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        int sequence = 5; // > 0 means override
        boolean expectedOverride = true;

        when(coversheetService.getCoverSheet(1, sequence, "template", expectedOverride))
                .thenReturn(sampleFileResult);

        // When
        ResponseEntity<byte[]> result = controller.displayCoverSheet(1, sequence, "template", authToken, 1);

        // Then
        assertEquals(HttpStatus.OK, result.getStatusCode());
        verify(coversheetService).getCoverSheet(1, sequence, "template", expectedOverride);
    }

    @Test
    void getTemplateWithMetadata_shouldReturnTemplateDTO() {
        // Given
        String objectName = "INVOICE";
        String objectType = "TEMPLATE";

        when(coversheetObjectService.getTemplateByNameAndType(objectName, objectType))
                .thenReturn(sampleObjectDTO);

        // When
        ResponseEntity<CoverSheetObjectDTO> result = controller.getTemplateWithMetadata(objectName, objectType, "",1);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(sampleObjectDTO, result.getBody());
        assertEquals("INVOICE", result.getBody().getObjName());
        assertEquals("TEMPLATE", result.getBody().getObjType());
        assertEquals("application/pdf", result.getBody().getMimeType());

        verify(coversheetObjectService).getTemplateByNameAndType(objectName, objectType);
    }

    @Test
    void uploadTemplateObject_shouldUploadSuccessfullyForAdminUser() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "template.pdf",
                "application/pdf",
                "PDF content".getBytes(StandardCharsets.UTF_8)
        );

        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("invoice", "template", "application/pdf", null);

        T117ImgCoverObject savedTemplate = new T117ImgCoverObject();
        savedTemplate.setObjName("INVOICE");
        savedTemplate.setObjType("TEMPLATE");
        savedTemplate.setMimeType("application/pdf");
        savedTemplate.setObjData("PDF content");
        savedTemplate.setActive("Y");

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);
            when(coversheetService.saveNewCoverSheetTemplate(any(T117ImgCoverObject.class)))
                    .thenReturn(savedTemplate);

            // When
            ResponseEntity<Object> result = controller.uploadTemplateObject(file, authToken, dto);

            // Then
            assertEquals(HttpStatus.OK, result.getStatusCode());
            assertTrue(result.getBody() instanceof Map);

            @SuppressWarnings("unchecked")
            Map<String, String> responseBody = (Map<String, String>) result.getBody();
            assertEquals("Cover object uploaded successfully", responseBody.get("message"));
        }

        verify(coversheetService).saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));
    }

    @Test
    void uploadTemplateObject_shouldReturnForbiddenForNonAdminUser() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "template.pdf",
                "application/pdf",
                "PDF content".getBytes()
        );

        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("invoice", "template", "application/pdf", null);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(nonAdminGroups);

            // When
            ResponseEntity<Object> result = controller.uploadTemplateObject(file, authToken, dto);

            // Then
            assertEquals(HttpStatus.FORBIDDEN, result.getStatusCode());
            assertTrue(result.getBody() instanceof Map);
            @SuppressWarnings("unchecked")
            Map<String, String> responseBody = (Map<String, String>) result.getBody();
            assertEquals("You do not have permission to upload templates", responseBody.get("error"));
        }

        verify(coversheetService, never()).saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));
    }

    @Test
    void uploadTemplateObject_shouldHandleException() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "template.pdf",
                "application/pdf",
                "PDF content".getBytes()
        );

        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("invoice", "template", "application/pdf", null);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);
            doThrow(new RuntimeException("Database error")).when(coversheetService)
                    .saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));

            // When
            ResponseEntity<Object> result = controller.uploadTemplateObject(file, authToken, dto);

            // Then
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
            assertTrue(result.getBody() instanceof Map);
            @SuppressWarnings("unchecked")
            Map<String, String> responseBody = (Map<String, String>) result.getBody();
            assertEquals("Upload failed", responseBody.get("error"));
            assertEquals("Database error", responseBody.get("details"));
        }
    }

    @Test
    void uploadTemplateObject_shouldConvertToUpperCase() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "template.pdf",
                "application/pdf",
                "PDF content".getBytes()
        );

        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("invoice", "template", "application/pdf", null);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);

            // When
            controller.uploadTemplateObject(file, authToken, dto);

            // Then
            verify(coversheetService).saveNewCoverSheetTemplate(argThat(template -> 
                "INVOICE".equals(template.getObjName()) && 
                "TEMPLATE".equals(template.getObjType()) &&
                "Y".equals(template.getActive())
            ));
        }
    }

    @Test
    void createTemplate_shouldCreateSuccessfullyForAdminUser() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("form", "template", "text/html", "<html>content</html>");
        T117ImgCoverObject savedTemplate = new T117ImgCoverObject();
        savedTemplate.setObjName("FORM");
        savedTemplate.setObjType("TEMPLATE");
        savedTemplate.setMimeType("text/html");
        savedTemplate.setObjData("<html>content</html>");
        savedTemplate.setActive("Y");

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);
            when(coversheetService.saveNewCoverSheetTemplate(any(T117ImgCoverObject.class))).thenReturn(savedTemplate);

            // When
            ResponseEntity<Object> result = controller.createTemplate(dto, authToken);

            // Then
            assertEquals(HttpStatus.OK, result.getStatusCode());
            assertEquals(savedTemplate, result.getBody());
        }

        verify(coversheetService).saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));
    }


    @Test
    void createTemplate_shouldReturnForbiddenForNonAdminUser() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("form", "template", "text/html", "<html>content</html>");

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(nonAdminGroups);

            // When
            ResponseEntity<Object> result = controller.createTemplate(dto, authToken);

            // Then
            assertEquals(HttpStatus.FORBIDDEN, result.getStatusCode());
            assertTrue(result.getBody() instanceof Map);
            @SuppressWarnings("unchecked")
            Map<String, String> responseBody = (Map<String, String>) result.getBody();
            assertEquals("You do not have permission to upload templates", responseBody.get("error"));
        }

        verify(coversheetService, never()).saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));
    }

    @Test
    void createTemplate_shouldHandleException() throws IOException {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetObjectDTO dto = new CoverSheetObjectDTO("form", "template", "text/html", "<html>content</html>");

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);
            doThrow(new RuntimeException("Validation error")).when(coversheetService)
                    .saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));

            // When
            ResponseEntity<Object> result = controller.createTemplate(dto, authToken);

            // Then
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
            assertTrue(result.getBody() instanceof Map);
            @SuppressWarnings("unchecked")
            Map<String, String> responseBody = (Map<String, String>) result.getBody();
            assertEquals("Upload failed", responseBody.get("error"));
            assertEquals("Validation error", responseBody.get("details"));
        }
    }

    @Test
    void getAllTemplateNames_shouldReturnListOfTemplateMetadata() {
        // Given
        T117ImgCoverObject template1 = new T117ImgCoverObject();
        template1.setObjName("INVOICE ");
        template1.setObjType("TEMPLATE ");
        template1.setMimeType("application/pdf ");

        T117ImgCoverObject template2 = new T117ImgCoverObject();
        template2.setObjName("FORM ");
        template2.setObjType("TEMPLATE ");
        template2.setMimeType("text/html ");

        List<T117ImgCoverObject> templates = Arrays.asList(template1, template2);

        when(coversheetObjectService.getTemplates()).thenReturn(templates);

        // When
        List<CoverSheetObjectDTO> result = controller.getAllTemplateNames("");

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        
        assertEquals("INVOICE", result.get(0).getObjName());
        assertEquals("TEMPLATE", result.get(0).getObjType());
        assertEquals("application/pdf", result.get(0).getMimeType());
        assertEquals("", result.get(0).getObjData()); // Should be empty for metadata only

        assertEquals("FORM", result.get(1).getObjName());
        assertEquals("TEMPLATE", result.get(1).getObjType());
        assertEquals("text/html", result.get(1).getMimeType());

        verify(coversheetObjectService).getTemplates();
    }

    @Test
    void getAllTemplateNames_shouldReturnEmptyListWhenNoTemplates() {
        // Given
        when(coversheetObjectService.getTemplates()).thenReturn(Arrays.asList());

        // When
        List<CoverSheetObjectDTO> result = controller.getAllTemplateNames("");

        // Then
        assertNotNull(result);
        assertEquals(0, result.size());

        verify(coversheetObjectService).getTemplates();
    }

    @Test
    void getCoversheetsByTemplateName_shouldReturnCoversheetsForAdminUser() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        String templateName = "INVOICE";
        
        CoverSheetOverrideDTO override1 = new CoverSheetOverrideDTO();
        override1.setTemplate("INVOICE");
        
        CoverSheetOverrideDTO override2 = new CoverSheetOverrideDTO();
        override2.setTemplate("INVOICE");
        
        List<CoverSheetOverrideDTO> expectedOverrides = Arrays.asList(override1, override2);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);
            when(coversheetService.getAllCoversheetsAndOverridesByTemplateName(templateName))
                    .thenReturn(expectedOverrides);

            // When
            ResponseEntity<List<CoverSheetOverrideDTO>> result = 
                    controller.getCoversheetsByTemplateName(templateName, authToken);

            // Then
            assertEquals(HttpStatus.OK, result.getStatusCode());
            assertNotNull(result.getBody());
            assertEquals(2, result.getBody().size());
            assertEquals("INVOICE", result.getBody().get(0).getTemplate());
        }

        verify(coversheetService).getAllCoversheetsAndOverridesByTemplateName(templateName);
    }

    @Test
    void getCoversheetsByTemplateName_shouldReturnForbiddenForNonAdminUser() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        String templateName = "INVOICE";

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(nonAdminGroups);

            // When
            ResponseEntity<List<CoverSheetOverrideDTO>> result = 
                    controller.getCoversheetsByTemplateName(templateName, authToken);

            // Then
            assertEquals(HttpStatus.FORBIDDEN, result.getStatusCode());
            assertNull(result.getBody());
        }

        verify(coversheetService, never()).getAllCoversheetsAndOverridesByTemplateName(anyString());
    }

    @Test
    void chkTemplateMaintAccess_shouldReturnTrueForAdminUser() {
        // Given
        String authToken = "Bearer valid-jwt-token";

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);

            // When - Using reflection to test private method through public method
            boolean result = controller.getCoversheetsByTemplateName("test", authToken)
                    .getStatusCode() != HttpStatus.FORBIDDEN;

            // Then
            assertTrue(result);
        }
    }

    @Test
    void chkTemplateMaintAccess_shouldReturnFalseForNonAdminUser() {
        // Given
        String authToken = "Bearer valid-jwt-token";

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(nonAdminGroups);

            // When - Using reflection to test private method through public method
            boolean result = controller.getCoversheetsByTemplateName("test", authToken)
                    .getStatusCode() != HttpStatus.FORBIDDEN;

            // Then
            assertFalse(result);
        }
    }

    @Test
    void chkTemplateMaintAccess_shouldBeCaseInsensitive() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> lowerCaseAdminGroups = Arrays.asList("hvw-administration-int", "OTHER-GROUP");

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(lowerCaseAdminGroups);

            // When - Using reflection to test private method through public method
            boolean result = controller.getCoversheetsByTemplateName("test", authToken)
                    .getStatusCode() != HttpStatus.FORBIDDEN;

            // Then
            assertTrue(result);
        }
    }

    @Test
    void displayCoverSheet_shouldUseDefaultParametersWhenNotProvided() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        // Using default values: applicationId=0, sequence=0, coversheetName=""

        when(coversheetService.getCoverSheet(0, 0, "", false)).thenReturn(sampleFileResult);

        // When
        ResponseEntity<byte[]> result = controller.displayCoverSheet(0, 0, "", authToken, 1);

        // Then
        assertEquals(HttpStatus.OK, result.getStatusCode());
        verify(coversheetService).getCoverSheet(0, 0, "", false);
    }

    @Test
    void editTemplate_success() throws IOException {
        String authToken = "valid-token";

        CoversheetTemplatesController spyController = Mockito.spy(controller);
        Mockito.doReturn(true).when(spyController).chkTemplateMaintAccess(authToken);

        ResponseEntity<Object> response = spyController.editTemplate(sampleObjectDTO, authToken);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(((Map<?, ?>)response.getBody()).containsKey("message"));
        verify(coversheetService).saveNewCoverSheetTemplate(any(T117ImgCoverObject.class));
    }

    @Test
    void editTemplate_unauthorized() throws IOException {
        String authToken = "invalid-token";

        CoversheetTemplatesController spyController = Mockito.spy(controller);
        Mockito.doReturn(false).when(spyController).chkTemplateMaintAccess(authToken);

        ResponseEntity<Object> response = spyController.editTemplate(sampleObjectDTO, authToken);

        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        Map<?, ?> body = (Map<?, ?>) response.getBody();
        assertEquals("You do not have permission to upload templates", body.get("error"));

        verify(coversheetService, never()).saveNewCoverSheetTemplate(any());
    }

    @Test
    void editTemplate_exceptionDuringSave() throws IOException {
        String authToken = "valid-token";

        CoversheetTemplatesController spyController = Mockito.spy(controller);
        Mockito.doReturn(true).when(spyController).chkTemplateMaintAccess(authToken);


        Mockito.doThrow(new RuntimeException("DB error"))
                .when(coversheetService).saveNewCoverSheetTemplate(any());


        ResponseEntity<Object> response = spyController.editTemplate(sampleObjectDTO, authToken);


        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        Map<?, ?> body = (Map<?, ?>) response.getBody();
        assertEquals("Upload failed", body.get("error"));
        assertEquals("DB error", body.get("details"));
    }


}