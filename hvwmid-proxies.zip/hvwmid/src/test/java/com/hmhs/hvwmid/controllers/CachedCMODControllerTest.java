package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.service.CMODDownloadService;
import com.hmhs.hvwmid.service.CodCachingService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CachedCMODControllerTest {

    @InjectMocks
    private CachedCMODController cachedCMODController;

    @Mock
    private CodCachingService codCachingService;

    @Mock
    private CMODDownloadService cmodDownloadService;

    @Mock
    private StreamingResponseBody responseBody;

    @Mock
    private LoggerService loggerService;


    @Mock
    private TblCodToken tblCodToken;

    @Mock
    private HttpServletRequest request;


    @BeforeEach
    void setUp() {
        when(request.getRequestURI()).thenReturn("/mock-uri");
        ReflectionTestUtils.setField(cachedCMODController, "request", request);

        ReflectionTestUtils.setField(cachedCMODController, "loggerService", loggerService);

    }

    @Test
    void testGetDocumentStream_SuccessfulDownload_PDF() {
        int requestId = 123;
        String authToken = "mockToken";
        String userId = "user123";

        TblCodToken tblCodToken = new TblCodToken();
        tblCodToken.setUserId(userId);
        tblCodToken.setDocumentToken("doc123");
        tblCodToken.setDocumentType("PDF");

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(codCachingService.getDocumentToken(requestId, authToken)).thenReturn(tblCodToken);
            when(codCachingService.streamDocument(requestId)).thenReturn(responseBody);

            // Test with only header (legacy)
            ResponseEntity<StreamingResponseBody> response = cachedCMODController.getDocumentStream(requestId, null, null, authToken);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(MediaType.APPLICATION_PDF, response.getHeaders().getContentType());
            ContentDisposition disposition = response.getHeaders().getContentDisposition();
            assertEquals("inline", disposition.getType());
            assertEquals("inline", disposition.getName());
            String filename = disposition.getFilename();
            assertNotNull(filename);
            assertTrue(filename.matches("doc123_\\d{2}-\\d{2}-\\d{4}\\.\\d{2}\\.\\d{2}\\.\\d{2}\\.pdf"), "Filename should match pattern with timestamp, but was: " + filename);
            assertEquals(responseBody, response.getBody());

            // Test with filename param
            ResponseEntity<StreamingResponseBody> responseWithFilename = cachedCMODController.getDocumentStream(requestId, "customname", null, authToken);
            assertEquals(HttpStatus.OK, responseWithFilename.getStatusCode());
            assertEquals(MediaType.APPLICATION_PDF, responseWithFilename.getHeaders().getContentType());
            ContentDisposition disposition2 = responseWithFilename.getHeaders().getContentDisposition();
            assertEquals("inline", disposition2.getType());
            assertEquals("inline", disposition2.getName());
            String filename2 = disposition2.getFilename();
            assertNotNull(filename2);
            assertTrue(filename2.matches("customname_\\d{2}-\\d{2}-\\d{4}\\.\\d{2}\\.\\d{2}\\.\\d{2}\\.pdf"), "Filename should match pattern with timestamp, but was: " + filename2);
            assertEquals(responseBody, responseWithFilename.getBody());

            // Test with authToken as param (header null)
            ResponseEntity<StreamingResponseBody> responseWithParamToken = cachedCMODController.getDocumentStream(requestId, null, authToken, null);
            assertEquals(HttpStatus.OK, responseWithParamToken.getStatusCode());
            assertEquals(MediaType.APPLICATION_PDF, responseWithParamToken.getHeaders().getContentType());
            ContentDisposition disposition3 = responseWithParamToken.getHeaders().getContentDisposition();
            assertEquals("inline", disposition3.getType());
            assertEquals("inline", disposition3.getName());
            String filename3 = disposition3.getFilename();
            assertNotNull(filename3);
            assertTrue(filename3.matches("doc123_\\d{2}-\\d{2}-\\d{4}\\.\\d{2}\\.\\d{2}\\.\\d{2}\\.pdf"), "Filename should match pattern with timestamp, but was: " + filename3);
            assertEquals(responseBody, responseWithParamToken.getBody());
        }
    }

    @Test
    void testGetDocumentStream_SuccessfulDownload_CustomType_Attachment() {
        int requestId = 124;
        String authToken = "mockToken";
        String userId = "user123";

        TblCodToken tblCodToken = new TblCodToken();
        tblCodToken.setUserId(userId);
        tblCodToken.setDocumentToken("doc124");
        tblCodToken.setDocumentType("XYZ"); // Not browser-viewable

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(codCachingService.getDocumentToken(requestId, authToken)).thenReturn(tblCodToken);
            when(codCachingService.streamDocument(requestId)).thenReturn(responseBody);

            ResponseEntity<StreamingResponseBody> response = cachedCMODController.getDocumentStream(requestId, null, null, authToken);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(MediaType.APPLICATION_OCTET_STREAM, response.getHeaders().getContentType());
            ContentDisposition disposition = response.getHeaders().getContentDisposition();
            assertEquals("attachment", disposition.getType());
            assertEquals("attachment", disposition.getName());
            String filename = disposition.getFilename();
            assertNotNull(filename);
            assertTrue(filename.matches("doc124_\\d{2}-\\d{2}-\\d{4}\\.\\d{2}\\.\\d{2}\\.\\d{2}\\.xyz"), "Filename should match pattern with timestamp, but was: " + filename);
            assertEquals(responseBody, response.getBody());
        }
    }

    @Test
    void testGetDocumentStream_UnauthorizedUser() {
        int requestId = 123;
        String authToken = "mockToken";
        String loggedInUser = "unauthorizedUser";

        TblCodToken tblCodToken = new TblCodToken();
        tblCodToken.setUserId("ownerUser");
        tblCodToken.setDocumentToken("doc456");
        tblCodToken.setDocumentType("TXT");

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(loggedInUser);
            when(codCachingService.getDocumentToken(requestId, authToken)).thenReturn(tblCodToken);

            ResponseEntity<StreamingResponseBody> response = cachedCMODController.getDocumentStream(requestId, null, null, authToken);
            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
            assertNull(response.getBody());
        }
    }

    @Test
    void testGetDocumentStream_DocumentNotFound() {
        int requestId = 123;
        String authToken = "mockToken";
        String userId = "user123";

        TblCodToken tblCodToken = new TblCodToken();
        tblCodToken.setUserId(userId);
        tblCodToken.setDocumentToken("doc789");
        tblCodToken.setDocumentType("PDF");

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);
            when(codCachingService.getDocumentToken(requestId, authToken)).thenReturn(tblCodToken);
            when(codCachingService.streamDocument(requestId)).thenReturn(null);

            ResponseEntity<StreamingResponseBody> response = cachedCMODController.getDocumentStream(requestId, null, null, authToken);
            assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
            assertNull(response.getBody());
        }
    }

    @Test
    void testGetDocumentStream_ExceptionHandling() {
        int requestId = 123;
        String authToken = "mockToken";

        when(codCachingService.getDocumentToken(anyInt(), anyString())).thenThrow(new RuntimeException("Internal error"));

        ResponseEntity<StreamingResponseBody> response = cachedCMODController.getDocumentStream(requestId, null, null, authToken);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }


    @Test
    void testGetCodTokenBeforeUpload_Success() {

        String authToken = "mockToken";
        int requestId = 123;
        String loginUser = "user123";

        String uploadUrl = "https://upload.server.com";
        String backend = "server-42";


        ReflectionTestUtils.setField(cachedCMODController, "cmodUploadUrl", uploadUrl);
        ReflectionTestUtils.setField(cachedCMODController, "backendServer", backend);

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(loginUser);

            when(codCachingService.saveToken(loginUser, authToken, "")).thenReturn(tblCodToken);


            ResponseEntity<Object> response = cachedCMODController.getCodTokenBeforeUpload(authToken, requestId);


            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertInstanceOf(Map.class, response.getBody());


            Object body = response.getBody();
            assertInstanceOf(Map.class, body);

            @SuppressWarnings("unchecked")
            Map<String, Object> responseBody = (Map<String, Object>) body;
            assertEquals(tblCodToken, responseBody.get("cacheRequestId"));
            assertEquals(uploadUrl, responseBody.get("uploadUrl"));
            assertEquals(backend, responseBody.get("backendServer"));
        }
    }

    @Test
    void testGetCodTokenBeforeUpload_ExceptionHandling() {
        String authToken = "mockToken";
        int requestId = 123;

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(null);

            ResponseEntity<Object> response = cachedCMODController.getCodTokenBeforeUpload(authToken, requestId);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
        }
    }


    @Test
    void testGetDocumentRequestID_translateTypeNull() {

        String documentToken = "docToken";
        String odFolder = "folder1";
        String translateType = null;
        String authToken = "auth123";

        Map<String, Integer> requestIdMap = Map.of("REQUEST_ID", 111);

        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("user1");

            when(cmodDownloadService.getDocumentRequestId(documentToken, odFolder, authToken, translateType))
                    .thenReturn(requestIdMap);
            when(codCachingService.getDocumentToken(111, authToken)).thenReturn(tblCodToken);

            ResponseEntity<TblCodToken> response = cachedCMODController.getDocumentRequestID(
                    documentToken, odFolder, translateType, authToken, 1);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(tblCodToken, response.getBody());
        }
    }

    @Test
    void testGetDocumentRequestID_translateTypeTOPDF() {
        String documentToken = "docToken";
        String odFolder = "folder1";
        String translateType = "TOPDF";
        String authToken = "auth123";
        String loginUser = "verylongusername";

        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(loginUser);

            // Now controller calls getTokenByStatusAndType
            when(codCachingService.getTokenByStatusAndType("verylongus", documentToken, translateType,authToken))
                .thenReturn(tblCodToken);

            ResponseEntity<TblCodToken> response = cachedCMODController.getDocumentRequestID(
                documentToken, odFolder, translateType, authToken, 1);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(tblCodToken, response.getBody());
        }
    }

    @Test
    void testGetDocumentRequestID_securityException() {

        String documentToken = "docToken";
        String odFolder = "folder1";
        String translateType = "TOPDF";
        String authToken = "auth123";

        Map<String, Integer> requestIdMap = Map.of("REQUEST_ID", 222);

        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenThrow(new SecurityException("unauthorized"));

            when(cmodDownloadService.getDocumentRequestId(documentToken, odFolder, authToken, translateType))
                    .thenReturn(requestIdMap);
            when(codCachingService.getDocumentToken(222, authToken)).thenReturn(tblCodToken);

            ResponseEntity<TblCodToken> response = cachedCMODController.getDocumentRequestID(
                    documentToken, odFolder, translateType, authToken, 1);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(tblCodToken, response.getBody());
        }
    }

    @Test
    void testGetDocumentRequestID_userIdEmpty_returns401() {

        String documentToken = "docToken";
        String odFolder = "folder1";
        String translateType = "TOPDF";
        String authToken = "auth123";

        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("");


            ResponseEntity<TblCodToken> response = cachedCMODController.getDocumentRequestID(
                    documentToken, odFolder, translateType, authToken, 1);


            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
            assertNull(response.getBody());
        }
    }

    @Test
    void testGetDocumentRequestID_genericException_returns404() {
        String documentToken = "docToken";
        String odFolder = "folder1";
        String translateType = "PDF";
        String authToken = "auth123";

        try (MockedStatic<HVWUtils> utils = Mockito.mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken))
                    .thenReturn(null);

            ResponseEntity<TblCodToken> response = cachedCMODController.getDocumentRequestID(
                    documentToken, odFolder, translateType, authToken, 1);

            assertNotNull(response);
            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode(), "Expected 401");
            assertNull(response.getBody(), "Expected response body to be null on error");
        }
    }

}
