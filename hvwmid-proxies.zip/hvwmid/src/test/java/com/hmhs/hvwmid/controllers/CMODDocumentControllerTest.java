package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.UserSession;
import com.hmhs.hvwmid.service.*;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class CMODDocumentControllerTest {

    @InjectMocks
    CMODDocumentController controller;

    @Mock
    CMODUpdateService updateService;

    @Mock
    CMODDeleteService deleteService;

    @Mock
    CMODDownloadService downloadService;

    @Mock
    CMODAppService appService;

    @Mock
    UserSession usrSec;

    @Mock
    IndexListingService indexListingService;

    @Mock
    LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(request.getRequestURI()).thenReturn("/mock");

        doNothing().when(loggerService).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());

    }


    @Test
    void testUpdateDocument_success() {
        Map<String, Object> request = new HashMap<>();
        request.put("documentToken", "doc123");

        when(updateService.updateDocument(eq(request), anyString()))
                .thenReturn(Map.of("status", "updated"));

        when(usrSec.getRequestId()).thenReturn(100);
        when(usrSec.getUserId()).thenReturn("userX");

        ResponseEntity<Object> response = controller.updateDocument(request, "Bearer abc", 1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("updated"));
    }


    @Test
    void testUpdateDocument_GenericException() {
        Map<String, Object> request = new HashMap<>();
        request.put("documentToken", "docXYZ");

        when(updateService.updateDocument(any(), any()))
                .thenThrow(new RuntimeException("Unexpected error"));

        when(usrSec.getRequestId()).thenReturn(102);
        when(usrSec.getUserId()).thenReturn("userZ");

        ResponseEntity<Object> response = controller.updateDocument(request, "Bearer token", 2);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
    }

    @Test
    void testUpdateDocument_HVWException() {
        Map<String, Object> request = new HashMap<>();
        request.put("documentToken", "docError");

        HVWException hvwException = new HVWException("Document not found");
        lenient().when(deleteService.deleteDocument(anyString(), anyString(), anyString())).thenThrow(new RuntimeException("Unexpected error"));
        lenient().when(usrSec.getRequestId()).thenReturn(200);
        when(updateService.updateDocument(any(), any())).thenThrow(hvwException);
        when(usrSec.getRequestId()).thenReturn(101);
        when(usrSec.getUserId()).thenReturn("userY");

        try (MockedStatic<HVWException> mockedStatic = Mockito.mockStatic(HVWException.class)) {
            mockedStatic
                    .when(() -> HVWException.createErrorResponseEntity(hvwException))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Document not found"));

            ResponseEntity<Object> response = controller.updateDocument(request, "Bearer def", 3);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertTrue(response.getBody().toString().contains("Document not found"));
        }
    }



    @Test
    void testDeleteDocument_success() {
        String token = "doc123";
        String folder = "folderABC";
        String auth = "Bearer xyz";

        Map<String, Object> expectedResponse = Map.of("status", "deleted");

        when(deleteService.deleteDocument(token, folder, auth))
                .thenReturn(expectedResponse);

        when(usrSec.getRequestId()).thenReturn(111);
        when(usrSec.getUserId()).thenReturn("user123");

        ResponseEntity<Object> response = controller.deleteDocument(token, folder, auth, 3);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("deleted"));
    }

    @Test
    void testDeleteDocument_GenericException() {
        String token = "doc999";
        String folder = "someFolder";
        String auth = "Bearer token";

        when(deleteService.deleteDocument(any(), any(), any()))
                .thenThrow(new RuntimeException("Unexpected failure"));

        when(usrSec.getRequestId()).thenReturn(113);
        when(usrSec.getUserId()).thenReturn("user789");

        ResponseEntity<Object> response = controller.deleteDocument(token, folder, auth, 4);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("Error deleting document"));
    }

    @Test
    void testDeleteDocument_HVWException() {
        String token = "docErr";
        String folder = "folderErr";
        String auth = "Bearer abc";

        HVWException hvwException = new HVWException("Invalid document token");

        when(deleteService.deleteDocument(any(), any(), any()))
                .thenThrow(hvwException);

        when(usrSec.getRequestId()).thenReturn(112);
        when(usrSec.getUserId()).thenReturn("user456");

        try (MockedStatic<HVWException> mockedStatic = Mockito.mockStatic(HVWException.class)) {
            mockedStatic.when(() -> HVWException.createErrorResponseEntity(hvwException))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid document token"));

            ResponseEntity<Object> response = controller.deleteDocument(token, folder, auth, 5);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertTrue(response.getBody().toString().contains("Invalid document token"));
        }
    }

    @Test
    void testUndeleteDocument_success() {
        String token = "doc123";
        String folder = "folderABC";
        String auth = "Bearer xyz";

        Map<String, Object> expectedResponse = Map.of("status", "undeleted");

        when(deleteService.undeleteDocument(token, folder, auth))
                .thenReturn(expectedResponse);

        when(usrSec.getRequestId()).thenReturn(114);
        when(usrSec.getUserId()).thenReturn("user124");

        ResponseEntity<Object> response = controller.undeleteDocument(token, folder, auth, 6);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("undeleted"));
    }

    @Test
    void testUndeleteDocument_GenericException() {
        String token = "doc999";
        String folder = "someFolder";
        String auth = "Bearer token";

        when(deleteService.undeleteDocument(any(), any(), any()))
                .thenThrow(new RuntimeException("Unexpected failure"));

        when(usrSec.getRequestId()).thenReturn(115);
        when(usrSec.getUserId()).thenReturn("user790");

        ResponseEntity<Object> response = controller.undeleteDocument(token, folder, auth, 7);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("Error undeleting document"));
    }

    @Test
    void testUndeleteDocument_HVWException() {
        String token = "docErr";
        String folder = "folderErr";
        String auth = "Bearer abc";

        HVWException hvwException = new HVWException("Invalid document token");

        when(deleteService.undeleteDocument(any(), any(), any()))
                .thenThrow(hvwException);

        when(usrSec.getRequestId()).thenReturn(116);
        when(usrSec.getUserId()).thenReturn("user457");

        try (MockedStatic<HVWException> mockedStatic = Mockito.mockStatic(HVWException.class)) {
            mockedStatic.when(() -> HVWException.createErrorResponseEntity(hvwException))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid document token"));

            ResponseEntity<Object> response = controller.undeleteDocument(token, folder, auth, 8);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertTrue(response.getBody().toString().contains("Invalid document token"));
        }
    }

    @Test
    void testGetApplicationChoices_success() {
        List<Map<String, String>> appList = List.of(Map.of("key", "app1", "displayName", "Application One"));

        when(appService.getCombinedApplicationChoices()).thenReturn(appList);
        when(usrSec.getRequestId()).thenReturn(123);
        when(usrSec.getUserId()).thenReturn("testUser");

        ResponseEntity<Object> response = controller.getApplicationChoices("Bearer abc", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        String body = response.getBody().toString();
        assertTrue(body.contains("applications"));
        assertTrue(body.contains("Application One"));
        assertTrue(body.contains("returnCodeDescription"));
    }



    @Test
    void testGetApplicationChoices_GenericException() {
        when(appService.getCombinedApplicationChoices()).thenThrow(new RuntimeException("Database down"));
        when(usrSec.getRequestId()).thenReturn(789);
        when(usrSec.getUserId()).thenReturn("userX");

        ResponseEntity<Object> response = controller.getApplicationChoices("Bearer xyz", 789);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("Error retrieving application choices"));
    }


    @Test
    void testGetApplicationChoices_HVWException() {
        HVWException hvwException = new HVWException("Invalid request");

        when(appService.getCombinedApplicationChoices()).thenThrow(hvwException);
        when(usrSec.getRequestId()).thenReturn(777);
        when(usrSec.getUserId()).thenReturn("userZ");

        try (MockedStatic<HVWException> mockedStatic = Mockito.mockStatic(HVWException.class)) {
            mockedStatic.when(() -> HVWException.createErrorResponseEntity(hvwException))
                    .thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid request"));

            ResponseEntity<Object> response = controller.getApplicationChoices("Bearer token", 777);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertTrue(response.getBody().toString().contains("Invalid request"));
        }
    }

    @Test
    void testGetCmodResultData_success() throws IOException {
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("param1", "value1");

        Map<String, Object> serviceResponse = new HashMap<>();
        serviceResponse.put("data", "some result");

        when(indexListingService.processReportData(eq(requestParams), anyString()))
                .thenReturn(serviceResponse);

        when(request.getRequestURI()).thenReturn("/indexes/search-folder");

        ResponseEntity<Object> response = controller.getCmodResultData(
                requestParams,
                "Bearer token123",
                null,
                1001
        );

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("some result"));
    }

    @Test
    void testGetCmodResultData_errorWithReturnCode() throws IOException {
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("param1", "value1");

        Map<String, Object> serviceMessage = new HashMap<>();
        serviceMessage.put("returnCode", 400);

        Map<String, Object> serviceResponse = new HashMap<>();
        serviceResponse.put("serviceMessage", serviceMessage);

        when(indexListingService.processReportData(eq(requestParams), anyString()))
                .thenReturn(serviceResponse);

        when(request.getRequestURI()).thenReturn("/indexes/search-folder");

        ResponseEntity<Object> response = controller.getCmodResultData(
                requestParams,
                "Bearer token123",
                null,
                1002
        );

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("serviceMessage"));
    }


    @Test
    void testGetCmodResultData_exceptionThrown() throws IOException {
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("param1", "value1");

        when(indexListingService.processReportData(any(), any()))
                .thenThrow(new RuntimeException("Simulated failure"));

        when(request.getRequestURI()).thenReturn("/indexes/search-folder");

        ResponseEntity<Object> response = controller.getCmodResultData(
                requestParams,
                "Bearer tokenXYZ",
                null,
                1003
        );

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertTrue(response.getBody().toString().contains("Simulated failure"));
    }




}
