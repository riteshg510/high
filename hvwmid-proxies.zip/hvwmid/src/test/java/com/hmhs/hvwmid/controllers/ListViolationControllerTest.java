package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListIdxValService;
import com.hmhs.hvwmid.service.ListViolationService;
import com.hmhs.hvwmid.service.LoggerService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class ListViolationControllerTest {

    @InjectMocks
    private ListViolationController listViolationController;

    @Mock
    private ListViolationService service;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @Test
    void testFilter_Success() throws HVWException {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        List<Map<String, String>> expectedList = List.of(Map.of("key", "value"));
        ResponseEntity<Object> expectedResponse = new ResponseEntity<>(expectedList, HttpStatus.OK);

        when(service.filter(anyMap(), anyString())).thenReturn(expectedResponse);
        when(request.getRequestURI()).thenReturn("uri");

        ResponseEntity<Object> response = listViolationController.filter(otherFields, "token", 123);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedList, response.getBody());
        verify(service).filter(anyMap(), anyString());
        verify(loggerService, atLeastOnce()).log(anyString(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
    }


}