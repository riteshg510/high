package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.WorkstationService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class WorkstationControllerTest {

    @InjectMocks
    private WorkstationController workstationController;

    @Mock
    private WorkstationService workstationService;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        when(request.getRequestURI()).thenReturn("/api/workstation/list");

        java.lang.reflect.Field requestField = WorkstationController.class.getDeclaredField("request");
        requestField.setAccessible(true);
        requestField.set(workstationController, request);

        java.lang.reflect.Field loggerServiceField = WorkstationController.class.getDeclaredField("loggerService");
        loggerServiceField.setAccessible(true);
        loggerServiceField.set(workstationController, loggerService);
    }

    @Test
    void testListWorkstations_Success() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "WRKST001");
        otherFields.put("ipAddressMask", "192.168.1.*");

        Map<String, Object> mockWorkstationData = new HashMap<>();
        mockWorkstationData.put("totalCount", 3);
        mockWorkstationData.put("activeCount", 2);
        mockWorkstationData.put("inactiveCount", 1);
        mockWorkstationData.put("workstationListing", Map.of(
                "results", Map.of(
                        "rowCount", "3",
                        "rows", List.of(
                                Map.of("terminalID", "WRKST001", "workstationStatus", "ACTIVE"),
                                Map.of("terminalID", "WRKST002", "workstationStatus", "ACTIVE"),
                                Map.of("terminalID", "WRKST003", "workstationStatus", "INACTIVE")
                        )
                )
        ));

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok(mockWorkstationData);

        when(workstationService.getWorkstationList(anyMap(), anyString())).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 123);

            assertEquals(expectedResponse, response);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            verify(workstationService).getWorkstationList(anyMap(), eq("mockAuth"));

            // Verify undefined values are removed from otherFields
            assertTrue(otherFields.entrySet().stream().noneMatch(entry -> "undefined".equals(entry.getValue())));

            verify(loggerService, times(2)).log(
                    anyString(),
                    eq(123),
                    anyInt(),
                    anyInt(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString()
            );
        }
    }

    @Test
    void testListWorkstations_Success_WithUndefinedValues() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "WRKST001");
        otherFields.put("ipAddressMask", "undefined");
        otherFields.put("validParam", "value");

        Map<String, Object> mockWorkstationData = new HashMap<>();
        mockWorkstationData.put("totalCount", 1);

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok(mockWorkstationData);

        when(workstationService.getWorkstationList(anyMap(), anyString())).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 456);

            assertEquals(expectedResponse, response);
            assertEquals(HttpStatus.OK, response.getStatusCode());

            // Verify undefined values are removed
            assertFalse(otherFields.containsKey("ipAddressMask") && "undefined".equals(otherFields.get("ipAddressMask")));
            assertTrue(otherFields.containsKey("validParam"));

            verify(workstationService).getWorkstationList(anyMap(), eq("mockAuth"));
        }
    }

    @Test
    void testListWorkstations_HVWException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "INVALID");

        HVWException hvwException = new HVWException("Workstation API error");
        when(workstationService.getWorkstationList(anyMap(), anyString())).thenThrow(hvwException);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class);
             MockedStatic<HVWException> hvwUtilities = mockStatic(HVWException.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> errorResponse = ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body("Workstation API error");
            hvwUtilities.when(() -> HVWException.createErrorResponseEntity(any(HVWException.class)))
                    .thenReturn(errorResponse);

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 789);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("Workstation API error", response.getBody());

            verify(workstationService).getWorkstationList(anyMap(), eq("mockAuth"));
            verify(loggerService, atLeastOnce()).log(
                    eq("ERROR"),
                    eq(789),
                    anyInt(),
                    anyInt(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString()
            );
        }
    }

    @Test
    void testListWorkstations_GenericException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "TEST");

        RuntimeException genericException = new RuntimeException("Service unavailable");
        when(workstationService.getWorkstationList(anyMap(), anyString())).thenThrow(genericException);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 999);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("SERVICE_UNAVAILABLE", response.getBody());

            verify(workstationService).getWorkstationList(anyMap(), eq("mockAuth"));
            verify(loggerService, atLeastOnce()).log(
                    eq("ERROR"),
                    eq(999),
                    anyInt(),
                    anyInt(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString()
            );
        }
    }

    @Test
    void testListWorkstations_EmptyFields() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        Map<String, Object> mockWorkstationData = new HashMap<>();
        mockWorkstationData.put("totalCount", 0);
        mockWorkstationData.put("workstationListing", Map.of("results", Map.of("rows", List.of())));

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok(mockWorkstationData);

        when(workstationService.getWorkstationList(anyMap(), anyString())).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 111);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());

            verify(workstationService).getWorkstationList(anyMap(), eq("mockAuth"));
        }
    }

    @Test
    void testListWorkstations_HVWException_NullMessage() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        HVWException hvwException = new HVWException((String) null);
        when(workstationService.getWorkstationList(anyMap(), anyString())).thenThrow(hvwException);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class);
             MockedStatic<HVWException> hvwUtilities = mockStatic(HVWException.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> errorResponse = ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body("Unknown error");
            hvwUtilities.when(() -> HVWException.createErrorResponseEntity(any(HVWException.class)))
                    .thenReturn(errorResponse);

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 222);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());

            verify(loggerService, atLeastOnce()).log(
                    eq("ERROR"),
                    eq(222),
                    anyInt(),
                    anyInt(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    isNull()
            );
        }
    }

    @Test
    void testListWorkstations_HVWException_LongMessage() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        String longMessage = "This is a very long error message that exceeds 250 characters. ".repeat(10);
        HVWException hvwException = new HVWException(longMessage);
        when(workstationService.getWorkstationList(anyMap(), anyString())).thenThrow(hvwException);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class);
             MockedStatic<HVWException> hvwUtilities = mockStatic(HVWException.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> errorResponse = ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body(longMessage.substring(0, 250));
            hvwUtilities.when(() -> HVWException.createErrorResponseEntity(any(HVWException.class)))
                    .thenReturn(errorResponse);

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 333);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());

            verify(loggerService, atLeastOnce()).log(
                    eq("ERROR"),
                    eq(333),
                    anyInt(),
                    anyInt(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    eq(longMessage.substring(0, 250))
            );
        }
    }

    @Test
    void testListWorkstations_GenericException_LongMessage() throws Exception {
        Map<String, String> otherFields = new HashMap<>();

        String longMessage = "Generic error message that is very long. ".repeat(10);
        RuntimeException genericException = new RuntimeException(longMessage);
        when(workstationService.getWorkstationList(anyMap(), anyString())).thenThrow(genericException);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, "mockAuth", 444);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("SERVICE_UNAVAILABLE", response.getBody());

            verify(loggerService, atLeastOnce()).log(
                    eq("ERROR"),
                    eq(444),
                    anyInt(),
                    anyInt(),
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    eq(longMessage.substring(0, 250))
            );
        }
    }

    @Test
    void testListWorkstations_OptionalAuthToken() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workstationIDMask", "TEST");

        Map<String, Object> mockWorkstationData = new HashMap<>();
        mockWorkstationData.put("totalCount", 1);

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok(mockWorkstationData);

        when(workstationService.getWorkstationList(anyMap(), isNull())).thenReturn(expectedResponse);

        ResponseEntity<Object> response = workstationController.listWorkstations(otherFields, null, 555);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(workstationService).getWorkstationList(anyMap(), isNull());

        // When authToken is null, getUserIdFromJWT should not be called
    }

    @Test
    void testStoreRequestId_NullRequestId() {
        // Test private method through reflection to achieve higher coverage
        try {
            java.lang.reflect.Method storeRequestIdMethod = WorkstationController.class.getDeclaredMethod("storeRequestId", Integer.class);
            storeRequestIdMethod.setAccessible(true);

            // This should not throw exception
            storeRequestIdMethod.invoke(workstationController, (Integer) null);

            assertTrue(true); // If we reach here, no exception was thrown
        } catch (Exception e) {
            fail("storeRequestId should handle null requestId gracefully");
        }
    }

    @Test
    void testStoreRequestId_ValidRequestId() {
        // Test private method through reflection to achieve higher coverage
        try {
            java.lang.reflect.Method storeRequestIdMethod = WorkstationController.class.getDeclaredMethod("storeRequestId", Integer.class);
            storeRequestIdMethod.setAccessible(true);

            // This should not throw exception
            storeRequestIdMethod.invoke(workstationController, 12345);

            assertTrue(true); // If we reach here, no exception was thrown
        } catch (Exception e) {
            fail("storeRequestId should handle valid requestId gracefully");
        }
    }
}