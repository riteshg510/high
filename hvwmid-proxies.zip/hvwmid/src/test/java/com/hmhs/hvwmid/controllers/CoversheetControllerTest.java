package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.T117ImgCoverSheetId;
import com.hmhs.hvwmid.entity.T117ImgCoverSheetOverrideId;
import com.hmhs.hvwmid.model.CoverSheetDTO;
import com.hmhs.hvwmid.model.CoverSheetOverrideDTO;
import com.hmhs.hvwmid.service.CoversheetObjectServiceImpl;
import com.hmhs.hvwmid.service.CoversheetService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CoversheetControllerTest {

    @Mock
    private CoversheetService coversheetService;

    @Mock
    private CoversheetObjectServiceImpl coversheetObjectService;

    @InjectMocks
    private CoversheetController controller;

    private CoverSheetDTO sampleCoversheet;
    private CoverSheetOverrideDTO sampleOverride;
    private T117ImgCoverSheetId sampleCoversheetId;
    private T117ImgCoverSheetOverrideId sampleOverrideId;
    private List<String> userGroups;

    @Mock
    private HttpServletRequest request;

    @Mock
    private LoggerService loggerService;

    @BeforeEach
    void setup() {
        // Setup sample coversheet
        sampleCoversheet = new CoverSheetDTO();
        sampleCoversheet.setApplication(1);
        sampleCoversheet.setName("INVOICE");
        sampleCoversheet.setDescription("Invoice Coversheet");
        sampleCoversheet.setSb1("SB1");
        sampleCoversheet.setEb1("EB1");
        sampleCoversheet.setEb2("EB2");
        sampleCoversheet.setEb3("EB3");
        sampleCoversheet.setTitle("Invoice Title");
        sampleCoversheet.setStitle1("Subtitle 1");
        sampleCoversheet.setStitle2("Subtitle 2");
        sampleCoversheet.setUnit("UNIT1");
        sampleCoversheet.setRcode("RC001");
        sampleCoversheet.setTemplate("TEMPLATE1");
        sampleCoversheet.setActive("Y");
        sampleCoversheet.setEnvironment("TEST");

        // Setup sample override
        sampleOverride = new CoverSheetOverrideDTO();
        sampleOverride.setApplication(1);
        sampleOverride.setName("INVOICE");
        sampleOverride.setSequence(1);
        sampleOverride.setTemplate("TEMPLATE1");
        sampleOverride.setActive("Y");

        // Setup ID objects
        sampleCoversheetId = new T117ImgCoverSheetId();
        sampleCoversheetId.setApplication(1);
        sampleCoversheetId.setName("INVOICE");

        sampleOverrideId = new T117ImgCoverSheetOverrideId();
        sampleOverrideId.setApplication(1);
        sampleOverrideId.setName("INVOICE");
        sampleOverrideId.setSequence(1);

        // Setup user groups
        userGroups = Arrays.asList("USER-GROUP", "ADMIN-GROUP", "COVERSHEET-GROUP");

        ReflectionTestUtils.setField(controller, "request", request);
        ReflectionTestUtils.setField(controller, "loggerService", loggerService);
    }

    @Test
    void getCoversheetByApplicationId_shouldReturnCoversheetsForApplication() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        Integer applicationId = 1;
        List<CoverSheetDTO> expectedCoversheets = Arrays.asList(sampleCoversheet);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getCoversheetByApplicationId(applicationId)).thenReturn(expectedCoversheets);

            // When
            List<CoverSheetDTO> result = controller.getCoversheetByApplicationId(applicationId, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals(1, result.get(0).getApplication());
            assertEquals("INVOICE", result.get(0).getName());
            assertEquals("Invoice Coversheet", result.get(0).getDescription());
        }

        verify(coversheetService).getCoversheetByApplicationId(applicationId);
    }

    @Test
    void getCoversheetByApplicationId_shouldHandleEmptyResult() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        Integer applicationId = 999;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getCoversheetByApplicationId(applicationId)).thenReturn(Arrays.asList());

            // When
            List<CoverSheetDTO> result = controller.getCoversheetByApplicationId(applicationId, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(0, result.size());
        }

        verify(coversheetService).getCoversheetByApplicationId(applicationId);
    }

    @Test
    void getCoversheetByApplicationIdAndName_shouldReturnSpecificCoversheet() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        Integer applicationId = 1;
        String coversheetName = "INVOICE";

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getCoversheetByApplicationIdAndName(applicationId, coversheetName))
                    .thenReturn(sampleCoversheet);

            // When
            CoverSheetDTO result = controller.getCoversheetByApplicationIdAndName(applicationId, coversheetName, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.getApplication());
            assertEquals("INVOICE", result.getName());
            assertEquals("Invoice Coversheet", result.getDescription());
            assertEquals("Y", result.getActive());
        }

        verify(coversheetService).getCoversheetByApplicationIdAndName(applicationId, coversheetName);
    }

    @Test
    void getAllCoversheets_shouldReturnAllCoversheetsActiveOnly() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        boolean activeOnly = true;
        List<CoverSheetDTO> expectedCoversheets = Arrays.asList(sampleCoversheet);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllCoverSheets(activeOnly)).thenReturn(expectedCoversheets);

            // When
            List<CoverSheetDTO> result = controller.getAllCoversheets(activeOnly, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals("Y", result.get(0).getActive());
        }

        verify(coversheetService).getAllCoverSheets(activeOnly);
    }

    @Test
    void getAllCoversheets_shouldReturnAllCoversheetsIncludeInactive() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        boolean activeOnly = false;
        
        CoverSheetDTO inactiveCoversheet = new CoverSheetDTO();
        inactiveCoversheet.setApplication(2);
        inactiveCoversheet.setName("INACTIVE");
        inactiveCoversheet.setActive("N");
        
        List<CoverSheetDTO> expectedCoversheets = Arrays.asList(sampleCoversheet, inactiveCoversheet);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllCoverSheets(activeOnly)).thenReturn(expectedCoversheets);

            // When
            List<CoverSheetDTO> result = controller.getAllCoversheets(activeOnly, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(2, result.size());
            assertEquals("Y", result.get(0).getActive());
            assertEquals("N", result.get(1).getActive());
        }

        verify(coversheetService).getAllCoverSheets(activeOnly);
    }

    @Test
    void getAllCoversheets_shouldUseDefaultActiveOnlyParameter() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        boolean defaultActiveOnly = false; // Default from @RequestParam

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllCoverSheets(defaultActiveOnly)).thenReturn(Arrays.asList(sampleCoversheet));

            // When
            List<CoverSheetDTO> result = controller.getAllCoversheets(defaultActiveOnly, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
        }

        verify(coversheetService).getAllCoverSheets(defaultActiveOnly);
    }

    @Test
    void createCoversheet_shouldCreateAndReturnCoversheet() {
        // Given
        when(coversheetService.saveCoverSheet(any(CoverSheetDTO.class))).thenReturn(sampleCoversheet);

        // When
        CoverSheetDTO result = controller.createCoversheet(sampleCoversheet,"", 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getApplication());
        assertEquals("INVOICE", result.getName());
        assertEquals("Invoice Coversheet", result.getDescription());

        verify(coversheetService).saveCoverSheet(any(CoverSheetDTO.class));
    }

    @Test
    void updateCoversheet_shouldUpdateAndReturnCoversheet() {
        // Given
        CoverSheetDTO updatedCoversheet = new CoverSheetDTO();
        updatedCoversheet.setApplication(1);
        updatedCoversheet.setName("INVOICE");
        updatedCoversheet.setDescription("Updated Invoice Coversheet");
        updatedCoversheet.setActive("Y");

        when(coversheetService.updateCoverSheet(any(CoverSheetDTO.class))).thenReturn(updatedCoversheet);

        // When
        CoverSheetDTO result = controller.updateCoversheet(updatedCoversheet,"", 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getApplication());
        assertEquals("INVOICE", result.getName());
        assertEquals("Updated Invoice Coversheet", result.getDescription());

        verify(coversheetService).updateCoverSheet(any(CoverSheetDTO.class));
    }

    @Test
    void deleteCoversheet_shouldSoftDeleteAndReturnNoContent() {
        // Given
        doNothing().when(coversheetService).deleteCoverSheet(any(T117ImgCoverSheetId.class));

        // When
        ResponseEntity<Void> result = controller.deleteCoversheet(sampleCoversheetId, 1);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());

        verify(coversheetService).deleteCoverSheet(any(T117ImgCoverSheetId.class));
    }

    @Test
    void getAllOverridesByApplicationId_shouldReturnOverridesForApplication() {
        // Given
        Integer applicationId = 1;
        List<CoverSheetOverrideDTO> expectedOverrides = Arrays.asList(sampleOverride);

        when(coversheetService.getAllOverridesByApplicationId(applicationId)).thenReturn(expectedOverrides);

        // When
        List<CoverSheetOverrideDTO> result = controller.getAllOverridesByApplicationId(applicationId, 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getApplication());
        assertEquals("INVOICE", result.get(0).getName());
        assertEquals(1, result.get(0).getSequence());

        verify(coversheetService).getAllOverridesByApplicationId(applicationId);
    }

    @Test
    void getAllOverridesByApplicationId_shouldHandleEmptyResult() {
        // Given
        Integer applicationId = 999;

        when(coversheetService.getAllOverridesByApplicationId(applicationId)).thenReturn(Arrays.asList());

        // When
        List<CoverSheetOverrideDTO> result = controller.getAllOverridesByApplicationId(applicationId, 1);

        // Then
        assertNotNull(result);
        assertEquals(0, result.size());

        verify(coversheetService).getAllOverridesByApplicationId(applicationId);
    }

    @Test
    void getOverridesListByApplicationIdAndName_shouldReturnOverrideList() {
        // Given
        Integer applicationId = 1;
        String coversheetName = "INVOICE";
        List<CoverSheetOverrideDTO> expectedOverrides = Arrays.asList(sampleOverride);

        when(coversheetService.getCoversheetOverrideListByApplicationIdAndName(applicationId, coversheetName))
                .thenReturn(expectedOverrides);

        // When
        List<CoverSheetOverrideDTO> result = controller.getOverridesListByApplicationIdAndName(applicationId, coversheetName, 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getApplication());
        assertEquals("INVOICE", result.get(0).getName());

        verify(coversheetService).getCoversheetOverrideListByApplicationIdAndName(applicationId, coversheetName);
    }

    @Test
    void getOverridesByApplicationIdAndName_shouldReturnSpecificOverride() {
        // Given
        Integer applicationId = 1;
        String coversheetName = "INVOICE";
        Integer sequence = 1;

        when(coversheetService.getCoversheetOverrideByApplicationIdAndName(applicationId, coversheetName, sequence))
                .thenReturn(sampleOverride);

        // When
        CoverSheetOverrideDTO result = controller.getOverridesByApplicationIdAndName(applicationId, coversheetName, sequence, 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getApplication());
        assertEquals("INVOICE", result.getName());
        assertEquals(1, result.getSequence());
        assertEquals("TEMPLATE1", result.getTemplate());

        verify(coversheetService).getCoversheetOverrideByApplicationIdAndName(applicationId, coversheetName, sequence);
    }

    @Test
    void createOverride_shouldCreateAndReturnOverride() {
        // Given
        when(coversheetService.createNewOveride(any(CoverSheetOverrideDTO.class))).thenReturn(sampleOverride);

        // When
        CoverSheetOverrideDTO result = controller.createOverride(sampleOverride, 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getApplication());
        assertEquals("INVOICE", result.getName());
        assertEquals(1, result.getSequence());

        verify(coversheetService).createNewOveride(any(CoverSheetOverrideDTO.class));
    }

    @Test
    void updateOverride_shouldUpdateAndReturnOverride() {
        // Given
        CoverSheetOverrideDTO updatedOverride = new CoverSheetOverrideDTO();
        updatedOverride.setApplication(1);
        updatedOverride.setName("INVOICE");
        updatedOverride.setSequence(1);
        updatedOverride.setTemplate("UPDATED_TEMPLATE");
        updatedOverride.setActive("Y");

        when(coversheetService.updateOverride(any(CoverSheetOverrideDTO.class))).thenReturn(updatedOverride);

        // When
        CoverSheetOverrideDTO result = controller.updateOverride(updatedOverride, 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getApplication());
        assertEquals("INVOICE", result.getName());
        assertEquals("UPDATED_TEMPLATE", result.getTemplate());

        verify(coversheetService).updateOverride(any(CoverSheetOverrideDTO.class));
    }

    @Test
    void deleteOverride_shouldSoftDeleteAndReturnNoContent() {
        // Given
        doNothing().when(coversheetService).deleteOverride(any(T117ImgCoverSheetOverrideId.class));

        // When
        ResponseEntity<Void> result = controller.deleteOverride(sampleOverrideId, 1);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());

        verify(coversheetService).deleteOverride(any(T117ImgCoverSheetOverrideId.class));
    }

    @Test
    void getCoversheetByApplicationId_shouldHandleNullAuthToken() {
        // Given
        String authToken = null;
        Integer applicationId = 1;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Arrays.asList());
            when(coversheetService.getCoversheetByApplicationId(applicationId)).thenReturn(Arrays.asList(sampleCoversheet));

            // When
            List<CoverSheetDTO> result = controller.getCoversheetByApplicationId(applicationId, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
        }

        verify(coversheetService).getCoversheetByApplicationId(applicationId);
    }

    @Test
    void getCoversheetByApplicationIdAndName_shouldHandleNullAuthToken() {
        // Given
        String authToken = null;
        Integer applicationId = 1;
        String coversheetName = "INVOICE";

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Arrays.asList());
            when(coversheetService.getCoversheetByApplicationIdAndName(applicationId, coversheetName))
                    .thenReturn(sampleCoversheet);

            // When
            CoverSheetDTO result = controller.getCoversheetByApplicationIdAndName(applicationId, coversheetName, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.getApplication());
        }

        verify(coversheetService).getCoversheetByApplicationIdAndName(applicationId, coversheetName);
    }

    @Test
    void getAllCoversheets_shouldHandleNullAuthToken() {
        // Given
        String authToken = null;
        boolean activeOnly = false;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Arrays.asList());
            when(coversheetService.getAllCoverSheets(activeOnly)).thenReturn(Arrays.asList(sampleCoversheet));

            // When
            List<CoverSheetDTO> result = controller.getAllCoversheets(activeOnly, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
        }

        verify(coversheetService).getAllCoverSheets(activeOnly);
    }

    @Test
    void coversheetDTO_shouldHandleNullValuesGracefully() {
        // Given
        CoverSheetDTO coversheetWithNulls = new CoverSheetDTO();
        coversheetWithNulls.setApplication(1);
        coversheetWithNulls.setName("TEST");
        // All other fields are null

        // When/Then - should not throw exceptions when accessing null fields
        assertEquals("", coversheetWithNulls.getDescription());
        assertEquals("", coversheetWithNulls.getSb1());
        assertEquals("", coversheetWithNulls.getEb1());
        assertEquals("", coversheetWithNulls.getEb2());
        assertEquals("", coversheetWithNulls.getEb3());
        assertEquals("", coversheetWithNulls.getTitle());
        assertEquals("", coversheetWithNulls.getStitle1());
        assertEquals("", coversheetWithNulls.getStitle2());
        assertEquals("", coversheetWithNulls.getUnit());
        assertEquals("", coversheetWithNulls.getRcode());
        assertEquals("", coversheetWithNulls.getTemplate());
        assertEquals("", coversheetWithNulls.getActive());
        assertEquals("", coversheetWithNulls.getEnvironment());
    }

    @Test
    void idClasses_shouldHaveCorrectEqualsAndHashCode() {
        // Test T117ImgCoverSheetId
        T117ImgCoverSheetId id1 = new T117ImgCoverSheetId();
        id1.setApplication(1);
        id1.setName("TEST");

        T117ImgCoverSheetId id2 = new T117ImgCoverSheetId();
        id2.setApplication(1);
        id2.setName("TEST");

        T117ImgCoverSheetId id3 = new T117ImgCoverSheetId();
        id3.setApplication(2);
        id3.setName("TEST");

        assertEquals(id1, id2);
        assertNotEquals(id1, id3);
        assertEquals(id1.hashCode(), id2.hashCode());

        // Test T117ImgCoverSheetOverrideId
        T117ImgCoverSheetOverrideId overrideId1 = new T117ImgCoverSheetOverrideId();
        overrideId1.setApplication(1);
        overrideId1.setName("TEST");
        overrideId1.setSequence(1);

        T117ImgCoverSheetOverrideId overrideId2 = new T117ImgCoverSheetOverrideId();
        overrideId2.setApplication(1);
        overrideId2.setName("TEST");
        overrideId2.setSequence(1);

        T117ImgCoverSheetOverrideId overrideId3 = new T117ImgCoverSheetOverrideId();
        overrideId3.setApplication(1);
        overrideId3.setName("TEST");
        overrideId3.setSequence(2);

        assertEquals(overrideId1, overrideId2);
        assertNotEquals(overrideId1, overrideId3);
        assertEquals(overrideId1.hashCode(), overrideId2.hashCode());
    }
}