package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.model.CoverSheetApplicationDTO;
import com.hmhs.hvwmid.model.CoverSheetDepartmentDTO;
import com.hmhs.hvwmid.service.CoversheetService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CoversheetApplicationControllerTest {

    @Mock
    private CoversheetService coversheetService;

    @InjectMocks
    private CoversheetApplicationController controller;

    private CoverSheetApplicationDTO sampleApplication;
    private CoverSheetDepartmentDTO sampleDepartment;
    private T117ImgCoverDept department;
    private List<String> userGroups;

    @Mock
    private HttpServletRequest request;

    @Mock
    private LoggerService loggerService;



    @BeforeEach
    void setup() {
        // Setup department entity
        department = new T117ImgCoverDept();
        department.setDeptId(1);
        department.setDescription("Test Department");
        department.setMaintGroup("HVW-COVERSHEET-TEST-MAINT");
        department.setPrintGroup("HVW-COVERSHEET-TEST-PRINT");

        // Setup sample application
        sampleApplication = new CoverSheetApplicationDTO();
        sampleApplication.setApplication(1);
        sampleApplication.setDescription("Test Application");
        sampleApplication.setSequence(1);
        sampleApplication.setDeptId(department);
        sampleApplication.setActive("Y");
        sampleApplication.setApplId("APP01");

        // Setup sample department DTO
        sampleDepartment = new CoverSheetDepartmentDTO();
        sampleDepartment.setDeptId(1);
        sampleDepartment.setDescription("Test Department");
        sampleDepartment.setMaintGroup("HVW-COVERSHEET-TEST-MAINT");
        sampleDepartment.setPrintGroup("HVW-COVERSHEET-TEST-PRINT");
        sampleDepartment.setCanMaintain(true);
        sampleDepartment.setDepartments(Arrays.asList(sampleApplication));

        // Setup user groups
        userGroups = Arrays.asList(
                "HVW-COVERSHEET-GROUP-1",
                "HVW-ADMINISTRATION-INT",
                "USER-GROUP"
        );
        ReflectionTestUtils.setField(controller, "request", request);
        ReflectionTestUtils.setField(controller, "loggerService", loggerService);
    }

    @Test
    void getAllApplications_shouldReturnApplicationsGroupedByDepartment() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        boolean showInactive = false;
        List<CoverSheetDepartmentDTO> expectedDepartments = Arrays.asList(sampleDepartment);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllApplications(showInactive, userGroups)).thenReturn(expectedDepartments);

            // When
            List<CoverSheetDepartmentDTO> result = controller.getAllApplications(showInactive, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals(1, result.get(0).getDeptId());
            assertEquals("Test Department", result.get(0).getDescription());
            assertTrue(result.get(0).getCanMaintain());
            assertEquals(1, result.get(0).getDepartments().size());
        }

        verify(coversheetService).getAllApplications(showInactive, userGroups);
    }

    @Test
    void getAllApplications_shouldHandleShowInactiveParameter() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        boolean showInactive = true;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllApplications(showInactive, userGroups)).thenReturn(Arrays.asList());

            // When
            List<CoverSheetDepartmentDTO> result = controller.getAllApplications(showInactive, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(0, result.size());
        }

        verify(coversheetService).getAllApplications(showInactive, userGroups);
    }

    @Test
    void getAllApplications_shouldUseDefaultShowInactiveWhenNotProvided() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        boolean defaultShowInactive = false; // Default value from @RequestParam

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllApplications(defaultShowInactive, userGroups)).thenReturn(Arrays.asList(sampleDepartment));

            // When
            List<CoverSheetDepartmentDTO> result = controller.getAllApplications(defaultShowInactive, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
        }

        verify(coversheetService).getAllApplications(defaultShowInactive, userGroups);
    }

    @Test
    void getAllApplicationsForDepartment_shouldReturnApplicationsForSpecificDepartment() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        Integer departmentId = 1;
        List<CoverSheetApplicationDTO> expectedApplications = Arrays.asList(sampleApplication);

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getAllApplicationsByDepartment(departmentId, userGroups)).thenReturn(expectedApplications);

            // When
            List<CoverSheetApplicationDTO> result = controller.getAllApplicationsForDepartment(departmentId, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals(1, result.get(0).getApplication());
            assertEquals("Test Application", result.get(0).getDescription());
            assertEquals("Y", result.get(0).getActive());
        }

        verify(coversheetService).getAllApplicationsByDepartment(departmentId, userGroups);
    }

    @Test
    void getApplicationById_shouldReturnSpecificApplication() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        Integer applicationId = 1;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetService.getApplicationsById(applicationId, userGroups)).thenReturn(sampleApplication);

            // When
            CoverSheetApplicationDTO result = controller.getApplicationById(applicationId, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.getApplication());
            assertEquals("Test Application", result.getDescription());
            assertEquals(1, result.getSequence());
            assertEquals("Y", result.getActive());
            assertEquals("APP01", result.getApplId());
        }

        verify(coversheetService).getApplicationsById(applicationId, userGroups);
    }

    @Test
    void createApplication_shouldCreateNewApplicationWithGeneratedId() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetApplicationDTO newApplication = new CoverSheetApplicationDTO();
        newApplication.setApplication(null); // No ID provided
        newApplication.setDescription("New Application");
        newApplication.setDeptId(department);
        newApplication.setActive("Y");
        newApplication.setApplId("NEW01");

        CoverSheetApplicationDTO savedApplication = new CoverSheetApplicationDTO();
        savedApplication.setApplication(100); // Generated ID
        savedApplication.setDescription("New Application");
        savedApplication.setSequence(1); // Set by controller
        savedApplication.setDeptId(department);
        savedApplication.setActive("Y");
        savedApplication.setApplId("NEW01");

        when(coversheetService.getCoverApplSequence()).thenReturn(100);
        when(coversheetService.saveApplication(any(CoverSheetApplicationDTO.class))).thenReturn(savedApplication);

        // When
        CoverSheetApplicationDTO result = controller.createApplication(newApplication, authToken, 1);

        // Then
        assertNotNull(result);
        assertEquals(100, result.getApplication());
        assertEquals("New Application", result.getDescription());
        assertEquals(1, result.getSequence());

        verify(coversheetService).getCoverApplSequence();
        verify(coversheetService).saveApplication(any(CoverSheetApplicationDTO.class));
    }

    @Test
    void createApplication_shouldCreateNewApplicationWithZeroId() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetApplicationDTO newApplication = new CoverSheetApplicationDTO();
        newApplication.setApplication(0); // Zero ID provided
        newApplication.setDescription("New Application");
        newApplication.setDeptId(department);
        newApplication.setActive("Y");
        newApplication.setApplId("NEW01");

        when(coversheetService.getCoverApplSequence()).thenReturn(100);
        when(coversheetService.saveApplication(any(CoverSheetApplicationDTO.class))).thenReturn(sampleApplication);

        // When
        CoverSheetApplicationDTO result = controller.createApplication(newApplication, authToken, 1);

        // Then
        assertNotNull(result);
        verify(coversheetService).getCoverApplSequence();
        verify(coversheetService).saveApplication(any(CoverSheetApplicationDTO.class));
    }

    @Test
    void createApplication_shouldCreateApplicationWithExistingId() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetApplicationDTO applicationWithId = new CoverSheetApplicationDTO();
        applicationWithId.setApplication(5); // Existing ID
        applicationWithId.setDescription("Existing Application");
        applicationWithId.setDeptId(department);
        applicationWithId.setActive("Y");
        applicationWithId.setApplId("EXT01");

        when(coversheetService.saveApplication(any(CoverSheetApplicationDTO.class))).thenReturn(applicationWithId);

        // When
        CoverSheetApplicationDTO result = controller.createApplication(applicationWithId, authToken, 1);

        // Then
        assertNotNull(result);
        assertEquals(5, result.getApplication());

        // Should not generate new sequence when ID exists
        verify(coversheetService, never()).getCoverApplSequence();
        verify(coversheetService).saveApplication(any(CoverSheetApplicationDTO.class));
    }

    @Test
    void updateApplication_shouldUpdateExistingApplication() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        CoverSheetApplicationDTO updatedApplication = new CoverSheetApplicationDTO();
        updatedApplication.setApplication(1);
        updatedApplication.setDescription("Updated Application");
        updatedApplication.setSequence(2);
        updatedApplication.setDeptId(department);
        updatedApplication.setActive("N");
        updatedApplication.setApplId("UPD01");

        when(coversheetService.saveApplication(any(CoverSheetApplicationDTO.class))).thenReturn(updatedApplication);

        // When
        CoverSheetApplicationDTO result = controller.updateApplication(updatedApplication, authToken, 1);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getApplication());
        assertEquals("Updated Application", result.getDescription());
        assertEquals(2, result.getSequence());
        assertEquals("N", result.getActive());

        verify(coversheetService).saveApplication(any(CoverSheetApplicationDTO.class));
    }

    @Test
    void deleteApplication_shouldSoftDeleteApplication() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        Integer applicationId = 1;

        doNothing().when(coversheetService).deleteApplication(anyInt());

        // When
        ResponseEntity<Void> result = controller.deleteApplication(applicationId, authToken, 1);

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());

        verify(coversheetService).deleteApplication(applicationId);
    }

    @Test
    void chkTemplateMaintAccess_shouldReturnTrueWhenUserHasAdminGroup() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> adminGroups = Arrays.asList(
                "HVW-ADMINISTRATION-INT",
                "OTHER-GROUP"
        );

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(adminGroups);

            // When
            boolean result = controller.chkTemplateMaintAccess(authToken);

            // Then
            assertTrue(result);
        }
    }

    @Test
    void chkTemplateMaintAccess_shouldReturnFalseWhenUserDoesNotHaveAdminGroup() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> nonAdminGroups = Arrays.asList(
                "HVW-USER-GROUP",
                "OTHER-GROUP"
        );

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(nonAdminGroups);

            // When
            boolean result = controller.chkTemplateMaintAccess(authToken);

            // Then
            assertFalse(result);
        }
    }

    @Test
    void chkTemplateMaintAccess_shouldBeCaseInsensitive() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> mixedCaseGroups = Arrays.asList(
                "hvw-administration-int", // lowercase version
                "OTHER-GROUP"
        );

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(mixedCaseGroups);

            // When
            boolean result = controller.chkTemplateMaintAccess(authToken);

            // Then
            assertTrue(result);
        }
    }

    @Test
    void chkTemplateMaintAccess_shouldHandleEmptyGroups() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> emptyGroups = Arrays.asList();

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(emptyGroups);

            // When
            boolean result = controller.chkTemplateMaintAccess(authToken);

            // Then
            assertFalse(result);
        }
    }

    @Test
    void chkTemplateMaintAccess_shouldHandleNullAuthToken() {
        // Given
        String authToken = null;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Arrays.asList());

            // When
            boolean result = controller.chkTemplateMaintAccess(authToken);

            // Then
            assertFalse(result);
        }
    }

    @Test
    void controller_shouldHaveCorrectHvwAdminGroup() {
        // Test the static field value
        assertEquals("HVW-ADMINISTRATION-INT", CoversheetApplicationController.hvwAdminGroup);
    }

    @Test
    void getAllApplications_shouldHandleNullAuthToken() {
        // Given
        String authToken = null;
        boolean showInactive = false;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Arrays.asList());
            when(coversheetService.getAllApplications(showInactive, Arrays.asList())).thenReturn(Arrays.asList());

            // When
            List<CoverSheetDepartmentDTO> result = controller.getAllApplications(showInactive, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(0, result.size());
        }

        verify(coversheetService).getAllApplications(showInactive, Arrays.asList());
    }

    @Test
    void getAllApplicationsForDepartment_shouldHandleNullAuthToken() {
        // Given
        String authToken = null;
        Integer departmentId = 1;

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(Arrays.asList());
            when(coversheetService.getAllApplicationsByDepartment(departmentId, Arrays.asList())).thenReturn(Arrays.asList());

            // When
            List<CoverSheetApplicationDTO> result = controller.getAllApplicationsForDepartment(departmentId, authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(0, result.size());
        }

        verify(coversheetService).getAllApplicationsByDepartment(departmentId, Arrays.asList());
    }
}