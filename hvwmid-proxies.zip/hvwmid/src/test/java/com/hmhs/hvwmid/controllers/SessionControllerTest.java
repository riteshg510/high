package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.service.HvwDataRefresh;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SessionControllerTest {


    @Mock
    private HttpServletRequest request;

    @Mock
    private LoggerService loggerService;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private HvwDataRefresh hvwDataRefresh;

    @InjectMocks
    private SessionController sessionController;

    @Test
    void testGetSession_successful() {

        String authToken = "validAuthToken";
        String expectedUserId = "testUser";
        int generatedRequestId = 1234;


        try (MockedStatic<HVWUtils> mockedUtils = mockStatic(HVWUtils.class)) {
            mockedUtils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(expectedUserId);


            SessionController controllerSpy = Mockito.spy(sessionController);
            doReturn(generatedRequestId).when(controllerSpy).genReqIdAndCommitStatus();

            ResponseEntity<Map<String, Integer>> response = controllerSpy.getSession(authToken);


            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(Map.of("requestId", generatedRequestId), response.getBody());
        }
    }

    @Test
    void testGetSession_jwtThrowsException_logsError() {
        String authToken = "badToken";
        String exceptionMessage = "Invalid token";

        try (MockedStatic<HVWUtils> mockedUtils = mockStatic(HVWUtils.class)) {
            mockedUtils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenThrow(new RuntimeException(exceptionMessage));

            when(request.getRequestURI()).thenReturn("/get-session");

            ResponseEntity<Map<String, Integer>> response = sessionController.getSession(authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(Map.of("requestId", 0), response.getBody());

            verify(loggerService).log(
                    "INFO",
                    0,
                    0,
                    0,
                    "",
                    "getSession() ",
                    "/get-session",
                    "200",
                    "START - getSession()"
            );
        }
    }


    @Test
    void testGenReqIdAndCommitStatus_returnsExpectedId() {

        String expectedEnv = "QA";
        int expectedRequestId = 12345;

        when(hvwDataRefresh.getParmDataByKeyByCmodbase("DEFAULT_ENV", null)).thenReturn(expectedEnv);
        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class))).thenReturn(expectedRequestId);

        int actualRequestId = sessionController.genReqIdAndCommitStatus();

        assertEquals(expectedRequestId, actualRequestId);
    }

}
