package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.layouts.CabinetsAndActions;
import com.hmhs.hvwmid.model.Cabinets;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.UserCabinetService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.argThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

class CabinetsControllerTest {

    private CabinetsController cabinetsController;
    private AppDataService appDataService;
    private UserCabinetService userCabinetService;
    private LoggerService loggerService;
    private HttpServletRequest httpServletRequest;

    private final String authToken = "valid.jwt.token";
    private final String mockUser = "testUser";
    private final String documentToken = "mock.docToken";
    private final Integer requestId = 123;
    private final String AUTH_HEADER = "Authorization";

    private CabinetsAndActions cabinetsActions;

    @Autowired
    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        appDataService = mock(AppDataService.class);
        userCabinetService = mock(UserCabinetService.class);
        loggerService = mock(LoggerService.class);
        httpServletRequest = mock(HttpServletRequest.class);
        cabinetsActions = mock(CabinetsAndActions.class);

        when(httpServletRequest.getRequestURI()).thenReturn("/mock-uri");

        cabinetsController = new CabinetsController();
        cabinetsController.service = appDataService;
        cabinetsController.userCabinetService = userCabinetService;
        cabinetsController.loggerService = loggerService;
        cabinetsController.request = httpServletRequest;
        cabinetsController.cabinetsActions = cabinetsActions;
    }

    @Test
    void testGetMyCabinetsForm_Success() {
        TblTemplates template = new TblTemplates();
        template.setContent("{\"mock\":\"form\"}".getBytes(StandardCharsets.UTF_8));

        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);
            when(appDataService.getTempletByName("MyCabinetsForm")).thenReturn(List.of(template));

            ResponseEntity<String> response = cabinetsController.getUserCabinetsForm(1, authToken);
            assertEquals(200, response.getStatusCodeValue());
            assertEquals("{\"mock\":\"form\"}", response.getBody());
        }
    }

    @Test
    void testAddCabinetToMyCabinets_Success() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);

            ResponseEntity<Object> response = cabinetsController.addFavoritesCabinet("CAB123", authToken, 101);
            assertEquals(200, response.getStatusCodeValue());

            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertTrue(body.containsKey("message"));
            assertEquals("Cabinet added to My Cabinets", body.get("message"));
        }
    }

    @Test
    void testRemoveCabinetFromMyCabinets_Success() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);

            ResponseEntity<Object> response = cabinetsController.removeFavoritesCabinet("CAB999", authToken, 99);
            assertEquals(200, response.getStatusCodeValue());

            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertTrue(body.containsKey("message"));
            assertEquals("Cabinet removed from My Cabinets", body.get("message"));
        }
    }

    @Test
    void testRemoveCabinetFromMyCabinets_Unauthorized() {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(null); // Simulate missing user

            ResponseEntity<Object> response = cabinetsController.removeFavoritesCabinet("CAB999", authToken, 100);

            assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertNotNull(body);

            assertEquals("Authentication required. Missing or invalid token.", body.get("message"));
        }
    }

    @Test
    void testRemoveCabinetFromMyCabinets_Exception() throws Exception {
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);
            doThrow(new RuntimeException("DB down")).when(userCabinetService).removeCabinetForUser(anyString(),
                    anyString());

            ResponseEntity<Object> response = cabinetsController.removeFavoritesCabinet("CAB999", authToken, 101);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            Map<String, Object> body = (Map<String, Object>) response.getBody();
            assertNotNull(body);

            assertTrue(body.get("message").toString().contains("DB down"));
        }
    }

    @Test
    void testGetMyCabinetsTable_success() {
        String authToken = "validToken";
        int requestId = 100;
        String expectedJson = "{\"columns\": [\"name\", \"location\"]}"; // This is the expected JSON response.

        TblTemplates mockTemplate = new TblTemplates();
        mockTemplate.setContent(expectedJson.getBytes(StandardCharsets.UTF_8));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            // Simulating that the template is found and returned correctly
            when(appDataService.getTempletByName("MyCabinetsTable")).thenReturn(List.of(mockTemplate));

            // Call the controller method
            ResponseEntity<String> response = cabinetsController.getUserCabinetsTable(requestId, authToken);

            // Assertions to check the correctness of the response
            assertEquals(HttpStatus.OK, response.getStatusCode()); // Check if the status is OK
            assertEquals(expectedJson, response.getBody()); // Check if the response body matches the expected JSON
        }
    }

    @Test
    void testGetMyCabinetsTable_exceptionThrown() {
        String authToken = "validToken";
        int requestId = 200;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("mockUser");

            // Simulating an exception when fetching the template
            when(appDataService.getTempletByName("MyCabinetsTable"))
                    .thenThrow(new RuntimeException("Database failure"));

            // Call the controller method
            ResponseEntity<String> response = cabinetsController.getUserCabinetsTable(requestId, authToken);

            // Assertions to check if the error response is correct
            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode()); // Check if the status is error
            assertEquals("", response.getBody()); // Since there's an error, expect an empty body as the response
        }
    }

    @Test
    void testGetAllCabinetsForm_success() {
        String authToken = "validToken";
        int requestId = 123;
        String expectedJson = "{\"form\": \"all cabinets\"}";

        TblTemplates template = new TblTemplates();
        template.setContent(expectedJson.getBytes(StandardCharsets.UTF_8));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("user123");

            when(appDataService.getTempletByName("AllCabinetsForm")).thenReturn(List.of(template));

            ResponseEntity<String> response = cabinetsController.getAllCabinetsForm(requestId, authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(expectedJson, response.getBody());
        }
    }

    @Test
    void testGetAllCabinetsForm_exception() {
        String authToken = "validToken";
        int requestId = 456;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("user456");

            when(appDataService.getTempletByName("AllCabinetsForm"))
                    .thenThrow(new RuntimeException("Database is down"));

            ResponseEntity<String> response = cabinetsController.getAllCabinetsForm(requestId, authToken);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    @Test
    void testGetAllCabinetsTable_success() {
        String authToken = "validToken";
        int requestId = 123;
        String expectedJson = "{\"columns\": [\"name\", \"location\"]}";

        TblTemplates template = new TblTemplates();
        template.setContent(expectedJson.getBytes(StandardCharsets.UTF_8));

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userABC");

            when(appDataService.getTempletByName("AllCabinetsTable")).thenReturn(List.of(template));

            ResponseEntity<String> response = cabinetsController.getAllCabinetsTable(requestId, authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(expectedJson, response.getBody());
        }
    }

    @Test
    void testGetAllCabinetsTable_exception() {
        String authToken = "validToken";
        int requestId = 456;

        try (MockedStatic<HVWUtils> mockedStatic = mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn("userXYZ");

            when(appDataService.getTempletByName("AllCabinetsTable"))
                    .thenThrow(new RuntimeException("DB error occurred"));

            ResponseEntity<String> response = cabinetsController.getAllCabinetsTable(requestId, authToken);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("", response.getBody());
        }
    }

    @Test
    void testGetMyCabinetsTableData_returnsCabinetsList() {
        String authToken = "mockedAuthToken";
        Integer requestId = 123;
        String userId = "user123";

        List<Cabinets> mockCabinetList = new ArrayList<>();
        Cabinets cabinet1 = new Cabinets();
        mockCabinetList.add(cabinet1);

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(cabinetsActions.getUserCabinetsAndActions(userCabinetService, authToken)).thenReturn(mockCabinetList);
            when(httpServletRequest.getRequestURI()).thenReturn("/favorites/get-tabledata");

            ResponseEntity<List<Cabinets>> response = cabinetsController.getMyCabinetsTableData(authToken, requestId);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals(1, response.getBody().size());
            assertSame(cabinet1, response.getBody().get(0));
        }
    }

    @Test
    void testGetAllCabinetsTableData_returnsCabinetsList() {

        Integer requestId = 456;
        String authToken = "authToken456";
        String userId = "userXYZ";

        List<Cabinets> mockCabinetsList = new ArrayList<>();
        Cabinets cabinet = new Cabinets();
        mockCabinetsList.add(cabinet);

        try (MockedStatic<HVWUtils> mockedStatic = Mockito.mockStatic(HVWUtils.class)) {
            mockedStatic.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(userId);

            when(cabinetsActions.getCabinetsAndActionsByGroup(authToken)).thenReturn(mockCabinetsList);
            when(httpServletRequest.getRequestURI()).thenReturn("/all/get-tabledata");

            ResponseEntity<List<Cabinets>> response = cabinetsController.getAllCabinetsTableData(requestId, authToken);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals(1, response.getBody().size());
            assertSame(cabinet, response.getBody().get(0));
            verify(loggerService).log(
                    eq("INFO"),
                    eq(456),
                    eq(0),
                    eq(0),
                    eq("userXYZ"),
                    eq("getAllCabinetsTableData()"),
                    eq("/all/get-tabledata"),
                    eq("200"),
                    eq("END - getAllCabinetsTableData()"));

        }
    }

    @Test
    void testUpdateCabinetsTable_returnsUpdatedMessage() {

        String cabinetId = "cab123";
        String expectedResponse = "Updated cabinet date";

        when(cabinetsActions.updateCabinetsTableDate(cabinetId)).thenReturn(expectedResponse);

        ResponseEntity<String> response = cabinetsController.updateCabinetsTable(cabinetId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedResponse, response.getBody());

    }

    @Test
    void testGetCabTableDefinition_success() {
        Map<String, String> otherFields = Map.of("key", "value");
        String tableId = "12345678901234567890123456789012";
        Integer requestId = 42;
        String authToken = "mockToken";

        // Mock TableDefinition and service
        com.hmhs.hvwmid.model.TableDefinition expectedDef = new com.hmhs.hvwmid.model.TableDefinition();
        // Mock ApiSection via partial mocking if needed, but here we let the real
        // method run and mock service calls
        com.hmhs.hvwmid.entity.TblTables mockTbl = mock(com.hmhs.hvwmid.entity.TblTables.class);
        when(appDataService.getTableByTableId(tableId)).thenReturn(mockTbl);
        // Mock columns for the table
        when(appDataService.getColumns(anyString())).thenReturn(List.of());

        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);
            when(httpServletRequest.getRequestURI()).thenReturn("/cabinet/tabledef");

            ResponseEntity<com.hmhs.hvwmid.model.TableDefinition> response = cabinetsController
                    .getCabTableDefinition(otherFields, tableId, requestId, authToken);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            verify(loggerService).log(eq("INFO"), eq(requestId), eq(0), eq(0), Mockito.anyString(),
                    eq("getCabTableDefinition()"), eq("/cabinet/tabledef"), eq(""),
                    eq("START - getCabTableDefinition()"));
            verify(loggerService).log(eq("INFO"), eq(requestId), eq(0), eq(0), Mockito.anyString(),
                    eq("getCabTableDefinition()"), eq("/cabinet/tabledef"), eq("200"),
                    eq("END - getCabTableDefinition()"));
        }
    }

    @Test
    void testGetCabTableDefinition_exception() {
        Map<String, String> otherFields = Map.of("key", "value");
        String tableId = "12345678901234567890123456789012";
        Integer requestId = 99;
        String authToken = "mockToken";

        when(appDataService.getTableByTableId(tableId)).thenThrow(new RuntimeException("DB error"));
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);
            when(httpServletRequest.getRequestURI()).thenReturn("/cabinet/tabledef");

            ResponseEntity<com.hmhs.hvwmid.model.TableDefinition> response = cabinetsController
                    .getCabTableDefinition(otherFields, tableId, requestId, authToken);
            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertNotNull(response.getBody());
        }
    }

    @Test
    void testGetCabTableDefinition_emptyTableId() {
        Map<String, String> otherFields = Map.of();
        String tableId = "";
        Integer requestId = 1;
        String authToken = "mockToken";

        // No table found, should return empty TableDefinition
        when(appDataService.getTableByTableId(tableId)).thenReturn(null);
        try (MockedStatic<HVWUtils> utils = mockStatic(HVWUtils.class)) {
            utils.when(() -> HVWUtils.getUserIdFromJWT(authToken)).thenReturn(mockUser);
            when(httpServletRequest.getRequestURI()).thenReturn("/cabinet/tabledef");

            ResponseEntity<com.hmhs.hvwmid.model.TableDefinition> response = cabinetsController
                    .getCabTableDefinition(otherFields, tableId, requestId, authToken);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
        }
    }

    @Test
    void testWorkflowDrop_success() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workflowId", "WF123");
        otherFields.put("status", "active");
        otherFields.put("extra", "undefined"); // Should be removed

        ResponseEntity<Object> mockResponse = ResponseEntity.ok("Dropped");
        when(cabinetsActions.dropWorkflow(anyMap(), eq(authToken))).thenReturn(mockResponse);

        ResponseEntity<Object> response = cabinetsController.workflowDrop(otherFields, documentToken, requestId,
                authToken);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Dropped", response.getBody());
        assertFalse(otherFields.containsValue("undefined")); // Ensure cleanup
    }

    @Test
    void testWorkflowReroute_success() {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("workflowId", "WF456");
        otherFields.put("routeTo", "userA");
        otherFields.put("temp", "undefined"); // Should be removed

        ResponseEntity<Object> mockResponse = ResponseEntity.ok("Rerouted");
        when(cabinetsActions.reRouteWorkflow(anyMap(), eq(authToken))).thenReturn(mockResponse);

        ResponseEntity<Object> response = cabinetsController.workflowReroute(otherFields, documentToken, requestId,
                authToken);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Rerouted", response.getBody());
        assertFalse(otherFields.containsValue("undefined")); // Ensure cleanup
    }

}
