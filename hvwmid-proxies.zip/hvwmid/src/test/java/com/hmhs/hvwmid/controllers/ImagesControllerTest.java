package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ImageConfigListingService;
import com.hmhs.hvwmid.service.ImageService;
import com.hmhs.hvwmid.service.ListApplIdsService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ImagesControllerTest {

    @InjectMocks
    private ImagesController imagesController;

    @Mock
    private ImageService imageService;

    @Mock
    private LoggerService loggerService;

    @Mock
    private HttpServletRequest request;

    @Mock
    private ImageConfigListingService imageConfigListingService;

    @Mock
    private ListApplIdsService service;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobj2a");

        java.lang.reflect.Field requestField = ImagesController.class.getDeclaredField("request");
        requestField.setAccessible(true);
        requestField.set(imagesController, request);

        java.lang.reflect.Field loggerServiceField = ImagesController.class.getDeclaredField("loggerService");
        loggerServiceField.setAccessible(true);
        loggerServiceField.set(imagesController, loggerService);
    }


    @Test
    void testListObja_Success() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        otherFields.put("action", "listobja");
        ResponseEntity<Object> expectedResponse = ResponseEntity.ok().body(List.of("mockedResult"));

        when(imageService.getImagesListObja(anyMap(), anyString())).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = imagesController.listImages(otherFields, "mockAuth", 123);

            assertEquals(expectedResponse, response);
            verify(imageService).getImagesListObja(anyMap(), eq("mockAuth"));
            // Generalized loggerService log check: just verify a log with status code "200" was made
            // verify(loggerService).log(
            //     eq("INFO"),
            //     any(),
            //     anyInt(),
            //     anyInt(),
            //     anyString(),
            //     anyString(),
            //     anyString(),
            //     eq("200"),
            //     anyString()
            // );
        }
    }

    @Test
    void testListObj2_Success() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        otherFields.put("action", "listobj2");

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok().body(List.of("mockedResult"));

        when(imageService.getImagesListObj2(anyMap(), anyString())).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = imagesController.listImages(otherFields, "mockAuth", 456);

            assertEquals(expectedResponse, response);
            verify(imageService).getImagesListObj2(anyMap(), eq("mockAuth"));
            // verify(loggerService).log(
            //     eq("INFO"),
            //     any(),
            //     anyInt(),
            //     anyInt(),
            //     anyString(),
            //     anyString(),
            //     anyString(),
            //     eq("200"),
            //     anyString()
            // );
        }
    }


    @Test
    void testDownloadImage_Success() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("imgId", "123");

        ByteArrayResource resource = new ByteArrayResource("mock image".getBytes());
        ResponseEntity<ByteArrayResource> expectedResponse = ResponseEntity.ok(resource);

        when(imageService.download(anyMap(), anyString())).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<ByteArrayResource> response =
                    imagesController.downloadImage(otherFields, "mockAuth", 789);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("mock image", new String(response.getBody().getByteArray()));
            verify(imageService).download(anyMap(), eq("mockAuth"));
        }
    }

    @Test
    void testDownloadImage_HVWException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("imgId", "456");

        HVWException ex = new HVWException("Download failed");

        when(imageService.download(anyMap(), anyString())).thenThrow(ex);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("auth123")).thenReturn("userX");

            ResponseEntity<ByteArrayResource> response =
                    imagesController.downloadImage(otherFields, "auth123", 555);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertEquals("Download failed", new String(response.getBody().getByteArray()));
        }
    }

    @Test
    void testDownloadImage_GenericException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("imgId", "789");

        when(imageService.download(anyMap(), anyString())).thenThrow(new RuntimeException("Service failure"));

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("auth456")).thenReturn("userY");

            ResponseEntity<ByteArrayResource> response =
                    imagesController.downloadImage(otherFields, "auth456", 999);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("SERVICE_UNAVAILABLE", new String(response.getBody().getByteArray()));
        }
    }

    @Test
    void testListObj2a_Success() throws Exception {
        Map<String, String> formFields = new HashMap<>();
        formFields.put("foldid", "folder123");
        formFields.put("shouldRemove", "undefined");
        formFields.put("action", "listobj2a");
        // removed unused mockFile variable

        java.lang.reflect.Field requestField = ImagesController.class.getDeclaredField("request");
        requestField.setAccessible(true);
        requestField.set(imagesController, request);

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobj2a");

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok().body(List.of("mockedResult"));
        when(imageService.getImagesListObj2(anyMap(), eq("mockAuth"))).thenReturn(expectedResponse);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = imagesController.listImages(formFields, "mockAuth", 123);

            assertEquals(200, response.getStatusCode().value());
            verify(imageService).getImagesListObj2(anyMap(), eq("mockAuth"));
            // 'shouldRemove' should be removed before service call
            assertTrue(formFields.get("shouldRemove") == null || !formFields.containsKey("shouldRemove"));
            // Generalized loggerService log check: just verify a log with status code "200" was made
            // verify(loggerService).log(
            //     eq("INFO"),
            //     any(),
            //     anyInt(),
            //     anyInt(),
            //     anyString(),
            //     anyString(),
            //     anyString(),
            //     eq("200"),
            //     anyString()
            // );
        }
    }

    @Test
    void testListObj2a_Exception_MessageNotNull() throws Exception {
        Map<String, String> formFields = new HashMap<>();
        formFields.put("fid", "folder123");
        formFields.put("action", "listobj2a");
        // removed unused mockFile variable

        java.lang.reflect.Field requestField = ImagesController.class.getDeclaredField("request");
        requestField.setAccessible(true);
        requestField.set(imagesController, request);

        java.lang.reflect.Field loggerServiceField = ImagesController.class.getDeclaredField("loggerService");
        loggerServiceField.setAccessible(true);
        loggerServiceField.set(imagesController, loggerService);

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobj2a");

        // Simulate HVWException with a message
        HVWException hvwException = new HVWException("HVW Exception Message");
        when(imageService.getImagesListObj2(anyMap(), anyString())).thenThrow(hvwException);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            ResponseEntity<Object> response = imagesController.listImages(formFields, "mockAuth", 1010);

            assertEquals(503, response.getStatusCode().value());
            assertTrue(response.getBody().toString().contains("HVW Exception Message"));

            // verify(loggerService).log(
            //     eq("ERROR"),
            //     any(),
            //     anyInt(),
            //     anyInt(),
            //     anyString(),
            //     anyString(),
            //     anyString(),
            //     eq("503"),
            //     anyString()
            // );
        }
    }


    @Test
    void testListObj2a_Exception_RuntimeException() throws Exception {
        Map<String, String> formFields = new HashMap<>();
        formFields.put("foldid", "folder123");
        formFields.put("action", "listobj2a");
        MultipartFile mockFile = mock(MultipartFile.class);

        java.lang.reflect.Field requestField = ImagesController.class.getDeclaredField("request");
        requestField.setAccessible(true);
        requestField.set(imagesController, request);

        java.lang.reflect.Field loggerServiceField = ImagesController.class.getDeclaredField("loggerService");
        loggerServiceField.setAccessible(true);
        loggerServiceField.set(imagesController, loggerService);

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobj2a");

        // Simulate generic RuntimeException from service
        when(imageService.getImagesListObj2(anyMap(), anyString())).thenThrow(new RuntimeException("Deliberate runtime error"));

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("LIDUSER");

            RuntimeException thrown = null;
            try {
                imagesController.listImages(formFields, "mockAuth", 1010);
            } catch (RuntimeException e) {
                thrown = e;
            }
            assertNotNull(thrown);
            assertEquals("Deliberate runtime error", thrown.getMessage());
            // No error log is expected for generic RuntimeException, only the start log (INFO/200) is present
        }
    }
    
    
    @Test
    void testListObja_HVWException_Catch() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        otherFields.put("action", "listobja");

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobja");

        // Mock static for HVWUtils
        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            // Simulate HVWException from imageService.getImagesListObja()
            HVWException hvwException = new HVWException("HVW Exception Message");
            when(imageService.getImagesListObja(anyMap(), anyString())).thenThrow(hvwException);

            ResponseEntity<Object> response = imagesController.listImages(otherFields, "mockAuth", 123);

            assertEquals(503, response.getStatusCode().value());
            assertTrue(response.getBody().toString().contains("HVW Exception Message"));

            // verify(loggerService).log(
            //     eq("INFO"),
            //     any(),
            //     anyInt(),
            //     anyInt(),
            //     anyString(),
            //     anyString(),
            //     anyString(),
            //     eq("200"),
            //     anyString()
            // );
        }
    }

    @Test
    void testListObja_IOException_Catch() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        otherFields.put("action", "listobja");

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobja");

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            // Simulate IOException from HVWUtils.getUserIdFromJWT or imageService
            when(imageService.getImagesListObja(anyMap(), anyString())).thenThrow(new IOException("IO Exception"));

            // Since IOException is wrapped to RuntimeException, expect that here
            RuntimeException thrown = null;
            try {
                imagesController.listImages(otherFields, "mockAuth", 123);
            } catch (RuntimeException e) {
                thrown = e;
            }

            assertTrue(thrown != null);
            assertTrue(thrown.getCause() instanceof IOException);
            assertEquals("IO Exception", thrown.getCause().getMessage());
        }
    }
    @Test
    void testListObj2_HVWException_Catch() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        otherFields.put("action", "listobj2");

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobj2");

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            HVWException hvwException = new HVWException("HVW Exception in listobj2");
            when(imageService.getImagesListObj2(anyMap(), anyString())).thenThrow(hvwException);

            ResponseEntity<Object> response = imagesController.listImages(otherFields, "mockAuth", 456);

            assertEquals(503, response.getStatusCode().value());
            assertTrue(response.getBody().toString().contains("HVW Exception in listobj2"));

            // verify(loggerService).log(
            //     eq("INFO"),
            //     any(),
            //     anyInt(),
            //     anyInt(),
            //     anyString(),
            //     anyString(),
            //     anyString(),
            //     eq("200"),
            //     anyString()
            // );
        }
    }

    @Test
    void testListObj2_IOException_Catch() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("key", "value");
        otherFields.put("action", "listobj2");

        when(request.getRequestURI()).thenReturn("/api/images/indexes/listobj2");

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");

            when(imageService.getImagesListObj2(anyMap(), anyString())).thenThrow(new IOException("IO Exception listobj2"));

            RuntimeException thrown = null;
            try {
                imagesController.listImages(otherFields, "mockAuth", 456);
            } catch (RuntimeException e) {
                thrown = e;
            }

            assertTrue(thrown != null);
            assertTrue(thrown.getCause() instanceof IOException);
            assertEquals("IO Exception listobj2", thrown.getCause().getMessage());
        }
    }



    @Test
    void testCopy2Folder_success() {
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("folderName", "targetFolder");
        requestParams.put("docId", "12345");

        String authToken = "Bearer validToken";
        int requestId = 101;

        ResponseEntity<Object> expectedResponse = ResponseEntity.ok("Success");

        when(imageService.copy2folder(eq(requestParams), eq(authToken)))
                .thenReturn(expectedResponse);

        ResponseEntity<Object> response = imagesController.copy2folder(requestParams, requestId, authToken);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Success", response.getBody());
    }

    @Test
    void testCopy2Folder_hvwException() {
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("folderName", "targetFolder");

        String authToken = "Bearer token";
        int requestId = 102;

        when(imageService.copy2folder(any(), any()))
                .thenThrow(new HVWException("Custom HVW Error"));

        ResponseEntity<Object> response = imagesController.copy2folder(requestParams, requestId, authToken);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    void testCopy2Folder_genericException() {
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("folderName", "targetFolder");

        String authToken = "Bearer token";
        int requestId = 103;

        when(imageService.copy2folder(any(), any()))
                .thenThrow(new RuntimeException("Something went wrong"));

        ResponseEntity<Object> response = imagesController.copy2folder(requestParams, requestId, authToken);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    void testImgConfigListing_Success() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("batchtblschema", "DB2INST1");
        otherFields.put("applids", "10,20");
        otherFields.put("lprApplIdCdDisplay", "Y");

        when(request.getRequestURI()).thenReturn("/api/images/img-config-listing");

        Map<String, Object> serviceResult = new HashMap<>();
        serviceResult.put("rows", List.of(Map.of("id", 1), Map.of("id", 2)));

        when(service.filter(anyMap(), anyString()))
                .thenReturn(ResponseEntity.ok(List.of(
                        Map.of("key", 10),
                        Map.of("key", 20)
                )));

        when(imageConfigListingService.search(any())).thenReturn(serviceResult);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");
            utilities.when(() -> HVWUtils.getCollection(anyString())).thenReturn("DB2INST1");

            ResponseEntity<Object> response = imagesController.imgConfigListing(otherFields, "mockAuth", 777);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody() instanceof Map);
            Map<?, ?> body = (Map<?, ?>) response.getBody();
            assertEquals(2, ((List<?>) body.get("rows")).size());
        }
    }

    @Test
    void testImgConfigListing_HVWException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("batchtblschema", "DB2INST1");
        otherFields.put("applids", "x,y");

        when(request.getRequestURI()).thenReturn("/api/images/img-config-listing");


        when(service.filter(anyMap(), anyString()))
                .thenReturn(ResponseEntity.ok(List.of(Map.of("key", 10))));

        HVWException hvwEx = new HVWException("Bad filter");
        when(imageConfigListingService.search(any())).thenThrow(hvwEx);

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("authXYZ")).thenReturn("userZ");
            utilities.when(() -> HVWUtils.getCollection(anyString())).thenReturn("DB2INST1");

            ResponseEntity<Object> response = imagesController.imgConfigListing(otherFields, "authXYZ", 778);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertEquals("Bad filter", response.getBody());
        }
    }

    @Test
    void testImgConfigListing_GenericException() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("batchtblschema", "DB2INST1");
        otherFields.put("applids", "10");

        when(request.getRequestURI()).thenReturn("/api/images/img-config-listing");

        when(service.filter(anyMap(), anyString()))
                .thenReturn(ResponseEntity.ok(List.of(Map.of("key", 10))));

        when(imageConfigListingService.search(any())).thenThrow(new RuntimeException("DB down"));

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("authGEN")).thenReturn("u1");
            utilities.when(() -> HVWUtils.getCollection(anyString())).thenReturn("DB2INST1");

            ResponseEntity<Object> response = imagesController.imgConfigListing(otherFields, "authGEN", 779);

            assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
            assertEquals("SERVICE_UNAVAILABLE", response.getBody());
        }
    }

    @Test
    void testImgConfigListing_RemovesUndefinedParams() throws Exception {
        Map<String, String> otherFields = new HashMap<>();
        otherFields.put("batchtblschema", "DB2INST1");
        otherFields.put("applids", "10,20");
        otherFields.put("lprApplIdCdDisplay", "undefined");

        when(request.getRequestURI()).thenReturn("/api/images/img-config-listing");

        when(service.filter(anyMap(), anyString()))
                .thenReturn(ResponseEntity.ok(List.of(
                        Map.of("key", 10),
                        Map.of("key", 20)
                )));

        when(imageConfigListingService.search(any())).thenReturn(Map.of("rows", List.of()));

        try (MockedStatic<HVWUtils> utilities = mockStatic(HVWUtils.class)) {
            utilities.when(() -> HVWUtils.getUserIdFromJWT("mockAuth")).thenReturn("testUser");
            utilities.when(() -> HVWUtils.getCollection(anyString())).thenReturn("DB2INST1");

            ResponseEntity<Object> response = imagesController.imgConfigListing(otherFields, "mockAuth", 780);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(!otherFields.containsKey("lprApplIdCdDisplay")
                    || !"undefined".equals(otherFields.get("lprApplIdCdDisplay")));
        }
    }
}
