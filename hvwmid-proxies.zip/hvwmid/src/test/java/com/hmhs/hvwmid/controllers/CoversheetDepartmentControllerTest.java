package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.service.CoversheetDepartmentService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CoversheetDepartmentControllerTest {

    @Mock
    private CoversheetDepartmentService coversheetDepartmentService;

    @InjectMocks
    private CoversheetDepartmentController controller;

    private T117ImgCoverDept sampleDepartment;
    private List<T117ImgCoverDept> departmentList;

    @Mock
    private HttpServletRequest request;

    @Mock
    private LoggerService loggerService;

    @BeforeEach
    void setup() {
        // Setup sample department data
        sampleDepartment = new T117ImgCoverDept();
        sampleDepartment.setDeptId(1);
        sampleDepartment.setDescription("Test Department");
        sampleDepartment.setMaintGroup("HVW-COVERSHEET-TEST-MAINT");
        sampleDepartment.setPrintGroup("HVW-COVERSHEET-TEST-PRINT");

        T117ImgCoverDept department2 = new T117ImgCoverDept();
        department2.setDeptId(2);
        department2.setDescription("Another Department");
        department2.setMaintGroup("HVW-COVERSHEET-ANOTHER-MAINT");
        department2.setPrintGroup("HVW-COVERSHEET-ANOTHER-PRINT");

        departmentList = Arrays.asList(sampleDepartment, department2);

        ReflectionTestUtils.setField(controller, "request", request);
        ReflectionTestUtils.setField(controller, "loggerService", loggerService);
    }

    @Test
    void getAllDepartments_shouldReturnListOfDepartments() {
        // Given
        when(coversheetDepartmentService.getAllDepartments()).thenReturn(departmentList);

        // When
        List<T117ImgCoverDept> result = controller.getAllDepartments(1,"");

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getDeptId());
        assertEquals("Test Department", result.get(0).getDescription());
        assertEquals("HVW-COVERSHEET-TEST-MAINT", result.get(0).getMaintGroup());
        assertEquals("HVW-COVERSHEET-TEST-PRINT", result.get(0).getPrintGroup());
        
        verify(coversheetDepartmentService).getAllDepartments();
    }

    @Test
    void getAllDepartments_shouldReturnEmptyListWhenNoDepartments() {
        // Given
        when(coversheetDepartmentService.getAllDepartments()).thenReturn(Arrays.asList());

        // When
        List<T117ImgCoverDept> result = controller.getAllDepartments(1,"");

        // Then
        assertNotNull(result);
        assertEquals(0, result.size());
        verify(coversheetDepartmentService).getAllDepartments();
    }

    @Test
    void getDepartmentById_shouldReturnDepartment() {
        // Given
        when(coversheetDepartmentService.getDepartmentById(1)).thenReturn(sampleDepartment);

        // When
        T117ImgCoverDept result = controller.getDepartmentById(1, 1, "");

        // Then
        assertNotNull(result);
        assertEquals(1, result.getDeptId());
        assertEquals("Test Department", result.getDescription());
        assertEquals("HVW-COVERSHEET-TEST-MAINT", result.getMaintGroup());
        assertEquals("HVW-COVERSHEET-TEST-PRINT", result.getPrintGroup());
        
        verify(coversheetDepartmentService).getDepartmentById(1);
    }

    @Test
    void createDepartment_shouldCreateAndReturnDepartment() {
        // Given
        when(coversheetDepartmentService.saveDepartment(any(T117ImgCoverDept.class)))
                .thenReturn(sampleDepartment);

        // When
        T117ImgCoverDept result = controller.createDepartment(sampleDepartment, 1,"");

        // Then
        assertNotNull(result);
        assertEquals(1, result.getDeptId());
        assertEquals("Test Department", result.getDescription());
        assertEquals("HVW-COVERSHEET-TEST-MAINT", result.getMaintGroup());
        assertEquals("HVW-COVERSHEET-TEST-PRINT", result.getPrintGroup());
        
        verify(coversheetDepartmentService).saveDepartment(any(T117ImgCoverDept.class));
    }

    @Test
    void updateDepartment_shouldUpdateAndReturnDepartment() {
        // Given
        T117ImgCoverDept updatedDepartment = new T117ImgCoverDept();
        updatedDepartment.setDeptId(1);
        updatedDepartment.setDescription("Updated Department");
        updatedDepartment.setMaintGroup("HVW-COVERSHEET-UPDATED-MAINT");
        updatedDepartment.setPrintGroup("HVW-COVERSHEET-UPDATED-PRINT");

        when(coversheetDepartmentService.saveDepartment(any(T117ImgCoverDept.class)))
                .thenReturn(updatedDepartment);

        // When
        T117ImgCoverDept result = controller.updateDepartment(updatedDepartment, 1, "");

        // Then
        assertNotNull(result);
        assertEquals(1, result.getDeptId());
        assertEquals("Updated Department", result.getDescription());
        assertEquals("HVW-COVERSHEET-UPDATED-MAINT", result.getMaintGroup());
        assertEquals("HVW-COVERSHEET-UPDATED-PRINT", result.getPrintGroup());
        
        verify(coversheetDepartmentService).saveDepartment(any(T117ImgCoverDept.class));
    }

    @Test
    void deleteDepartment_shouldDeleteAndReturnNoContent() {
        // Given
        doNothing().when(coversheetDepartmentService).deleteDepartment(anyInt());

        // When
        ResponseEntity<Void> result = controller.deleteDepartment(1, 1, "");

        // Then
        assertNotNull(result);
        assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());
        verify(coversheetDepartmentService).deleteDepartment(1);
    }

    @Test
    void getGroups_shouldReturnFilteredUserGroups() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> userGroups = Arrays.asList(
                "HVW-COVERSHEET-GROUP-1",
                "HVW-COVERSHEET-GROUP-2",
                "OTHER-GROUP-NOT-COVERSHEET",
                "HVW-COVERSHEET-GROUP-3"
        );
        List<String> maintenanceGroups = Arrays.asList("HVW-COVERSHEET-GROUP-1");

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetDepartmentService.getAllMaintananceGroups()).thenReturn(maintenanceGroups);

            // When
            List<String> result = controller.getGroups(authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(2, result.size());
            assertTrue(result.contains("HVW-COVERSHEET-GROUP-2"));
            assertTrue(result.contains("HVW-COVERSHEET-GROUP-3"));
            assertFalse(result.contains("OTHER-GROUP-NOT-COVERSHEET"));
            assertFalse(result.contains("HVW-COVERSHEET-GROUP-1")); // filtered out as maintenance group
        }

        verify(coversheetDepartmentService).getAllMaintananceGroups();
    }

    @Test
    void getGroups_shouldReturnEmptyListWhenNoValidGroups() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> userGroups = Arrays.asList(
                "OTHER-GROUP-1",
                "ANOTHER-GROUP-2",
                "NOT-COVERSHEET-GROUP"
        );
        List<String> maintenanceGroups = Arrays.asList();

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetDepartmentService.getAllMaintananceGroups()).thenReturn(maintenanceGroups);

            // When
            List<String> result = controller.getGroups(authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(0, result.size());
        }
    }

    @Test
    void getGroups_shouldHandleNullAuthToken() {
        // Given
        List<String> emptyGroups = Arrays.asList();

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(null)).thenReturn(emptyGroups);
            when(coversheetDepartmentService.getAllMaintananceGroups()).thenReturn(Arrays.asList());

            // When
            List<String> result = controller.getGroups(null, 1);

            // Then
            assertNotNull(result);
            assertEquals(0, result.size());
        }
    }

    @Test
    void getGroups_shouldFilterOutMaintenanceGroups() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> userGroups = Arrays.asList(
                "HVW-COVERSHEET-ADMIN-GROUP",
                "HVW-COVERSHEET-USER-GROUP",
                "HVW-COVERSHEET-MAINTENANCE-GROUP"
        );
        List<String> maintenanceGroups = Arrays.asList(
                "HVW-COVERSHEET-ADMIN-GROUP",
                "HVW-COVERSHEET-MAINTENANCE-GROUP"
        );

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetDepartmentService.getAllMaintananceGroups()).thenReturn(maintenanceGroups);

            // When
            List<String> result = controller.getGroups(authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(1, result.size());
            assertEquals("HVW-COVERSHEET-USER-GROUP", result.get(0));
        }
    }

    @Test
    void getGroups_shouldOnlyIncludeGroupsWithCoversheetPrefix() {
        // Given
        String authToken = "Bearer valid-jwt-token";
        List<String> userGroups = Arrays.asList(
                "HVW-COVERSHEET-VALID-GROUP",
                "HVW-ADMIN-GROUP",
                "OTHER-COVERSHEET-GROUP",
                "HVW-COVERSHEET-ANOTHER-VALID"
        );
        List<String> maintenanceGroups = Arrays.asList();

        try (MockedStatic<HVWUtils> mockedHVWUtils = Mockito.mockStatic(HVWUtils.class)) {
            mockedHVWUtils.when(() -> HVWUtils.getUserGroups(authToken)).thenReturn(userGroups);
            when(coversheetDepartmentService.getAllMaintananceGroups()).thenReturn(maintenanceGroups);

            // When
            List<String> result = controller.getGroups(authToken, 1);

            // Then
            assertNotNull(result);
            assertEquals(2, result.size());
            assertTrue(result.contains("HVW-COVERSHEET-VALID-GROUP"));
            assertTrue(result.contains("HVW-COVERSHEET-ANOTHER-VALID"));
            assertFalse(result.contains("HVW-ADMIN-GROUP"));
            assertFalse(result.contains("OTHER-COVERSHEET-GROUP"));
        }
    }

    @Test
    void controller_shouldHaveCorrectGroupPrefix() {
        // Test the static field value
        assertEquals("HVW-COVERSHEET", CoversheetDepartmentController.groupPrefix);
    }
}