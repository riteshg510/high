package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.dto.PolicyResponse;
import com.hmhs.hvwmid.dto.PolicyWithHoldDTO;
import com.hmhs.hvwmid.entity.T222ImgRmaPolicy;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.mapper.PolicyMapper;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.PolicyImportService;
import com.hmhs.hvwmid.service.PolicyService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
 
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.*;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PolicyControllerTest {

	// Test constants
	private static final String TEST_USER = "testuser";
	private static final String TEST_POLICY_ID = "POL123";
	private static final String TEST_POLICY_DESCRIPTION = "Test Policy";
	private static final String TEST_POLICY_TYPE = "TYPE1";
	private static final String TEST_PROGRAM_NAME = "TEST_PROG";
	private static final String TEST_DATE = "2024-01-01";
	private static final String TEST_EXCEL_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	private static final String TEST_EXCEL_FILENAME = "test.xlsx";
	private static final String TEST_EXCEL_CONTENT = "test content";

	@Mock
	private PolicyService policyService;

	@Mock
	private LoggerService loggerService;

	@Mock
	private HttpServletRequest request;

	@Mock
	private PolicyImportService policyImportService;

	@InjectMocks
	private PolicyController policyController;

	private T222ImgRmaPolicy testPolicy;
	private Map<String, String> testPolicyFields;
	private List<PickListItems> testClientIds;
	private String testAuthToken;
	private Integer testRequestId;

	@BeforeEach
	void setUp() {
		// Setup test policy entity
		testPolicy = new T222ImgRmaPolicy();
		testPolicy.setPolicyCode(12345);
		testPolicy.setBpdId(1001);
		testPolicy.setPolicyId(TEST_POLICY_ID);
		testPolicy.setPolicyIdType(TEST_POLICY_TYPE);
		testPolicy.setPolicyDescription(TEST_POLICY_DESCRIPTION);
		testPolicy.setPolicyDays(30);
		testPolicy.setPolicyEditFlag("Y");
		testPolicy.setPolicyEditPgmName(TEST_PROGRAM_NAME);
		testPolicy.setModUser(TEST_USER);
		testPolicy.setModDate(LocalDateTime.now());

		// Setup test policy fields map
		testPolicyFields = new HashMap<>();
		testPolicyFields.put("bpdId", "1001");
		testPolicyFields.put("policyId", TEST_POLICY_ID);
		testPolicyFields.put("policyIdType", TEST_POLICY_TYPE);
		testPolicyFields.put("policyDescription", TEST_POLICY_DESCRIPTION);
		testPolicyFields.put("policyDays", "30");
		testPolicyFields.put("policyEditFlag", "Y");
		testPolicyFields.put("policyEditPgmName", TEST_PROGRAM_NAME);

		// Setup test client IDs
		testClientIds = Arrays.asList(createPickListItem("1001", "1001", 0L), createPickListItem("1002", "1002", 1L));

		testAuthToken = "Bearer test-token";
		testRequestId = 12345;

	}

	private PickListItems createPickListItem(String key, String displayName, Long id) {
		PickListItems item = new PickListItems();
		item.setKey(key);
		item.setDisplayName(displayName);
		item.setId(id);
		item.setParentKey("");
		return item;
	}

	@Test
	void testGetClientIdsSuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.isIsNoserviceEnv()).thenReturn(false);
			hvwUtilsMock.when(() -> HVWUtils.extractBpdIds(testAuthToken)).thenReturn(new HashMap<>());
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.getNoServiceClientIds()).thenReturn(testClientIds);

			// When
			ResponseEntity<Object> response = policyController.getClientIds(testRequestId, testAuthToken);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			assertTrue(response.getBody() instanceof List);
			@SuppressWarnings("unchecked")
			List<PickListItems> result = (List<PickListItems>) response.getBody();
			assertEquals(2, result.size());
			verify(policyService).getNoServiceClientIds();
		}
	}

	@Test
	void testGetClientIdsWithBpdIds() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Map<String, String> bpdIds = new HashMap<>();
			bpdIds.put("1001", "CLIENT1-PA");
			bpdIds.put("1002", "CLIENT2-NY");

			hvwUtilsMock.when(() -> HVWUtils.isIsNoserviceEnv()).thenReturn(false);
			hvwUtilsMock.when(() -> HVWUtils.extractBpdIds(testAuthToken)).thenReturn(bpdIds);
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.transformMapToPickListItems(bpdIds)).thenReturn(testClientIds);

			// When
			ResponseEntity<Object> response = policyController.getClientIds(testRequestId, testAuthToken);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).transformMapToPickListItems(bpdIds);
		}
	}

	@Test
	void testGetClientIdsUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.getClientIds(testRequestId, testAuthToken);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
			assertTrue(response.getBody() instanceof Map);
		}
	}

	@Test
	void testListPoliciesSuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Object[] mockRow = { "12345", TEST_POLICY_ID, TEST_POLICY_DESCRIPTION, TEST_POLICY_TYPE, 30, "Y",
					TEST_PROGRAM_NAME, TEST_DATE, TEST_USER, "2024-01-01 10:00:00", 1001, "HOLD1", "HOLD123",
					"Hold Description", "Y", "HOLD_PROG", TEST_USER, TEST_DATE, "2024-01-31" };
			PolicyWithHoldDTO mockPolicyWithHold = new PolicyWithHoldDTO(mockRow);
			Page<PolicyWithHoldDTO> mockPage = new PageImpl<>(Arrays.asList(mockPolicyWithHold), PageRequest.of(0, 10),
					1);
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.listPolicies(testPolicyFields)).thenReturn(mockPage);

			// When
			ResponseEntity<Object> response = policyController.listPolicies(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).listPolicies(testPolicyFields);
		}
	}

	@Test
	void testListPoliciesUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.listPolicies(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testListPoliciesHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.listPolicies(testPolicyFields)).thenThrow(new HVWException("Test error"));

			// When
			ResponseEntity<Object> response = policyController.listPolicies(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
			assertTrue(response.getBody() instanceof ByteArrayResource);
		}
	}

	@Test
	void testCreatePolicySuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.createPolicy(testPolicyFields, TEST_USER)).thenReturn(testPolicy);

			// When
			ResponseEntity<Object> response = policyController.createPolicy(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).createPolicy(testPolicyFields, TEST_USER);
		}
	}

	@Test
	void testCreatePolicyUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.createPolicy(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testCreatePolicyHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.createPolicy(testPolicyFields, TEST_USER))
					.thenThrow(new HVWException("Validation error"));

			// When
			ResponseEntity<Object> response = policyController.createPolicy(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testUpdatePolicySuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.updatePolicy(testPolicyFields, TEST_USER)).thenReturn(testPolicy);

			// When
			ResponseEntity<Object> response = policyController.updatePolicy(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).updatePolicy(testPolicyFields, TEST_USER);
		}
	}

	@Test
	void testUpdatePolicyUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.updatePolicy(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testUpdatePolicyHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.updatePolicy(testPolicyFields, TEST_USER)).thenThrow(new HVWException("Update error"));

			// When
			ResponseEntity<Object> response = policyController.updatePolicy(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testGetByPolicyCodeSuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class);
				MockedStatic<PolicyMapper> policyMapperMock = mockStatic(PolicyMapper.class)) {
			// Given
			Integer policyCode = 12345;
			PolicyResponse mockResponse = new PolicyResponse();
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.getByPolicyCode(policyCode)).thenReturn(testPolicy);
			policyMapperMock.when(() -> PolicyMapper.toResponse(testPolicy)).thenReturn(mockResponse);

			// When
			ResponseEntity<Object> response = policyController.getByPolicyCode(policyCode, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).getByPolicyCode(policyCode);
		}
	}

	@Test
	void testGetByPolicyCodeUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Integer policyCode = 12345;
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.getByPolicyCode(policyCode, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testGetByPolicyCodeHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Integer policyCode = 12345;
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.getByPolicyCode(policyCode)).thenThrow(new HVWException("Policy not found"));

			// When
			ResponseEntity<Object> response = policyController.getByPolicyCode(policyCode, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testDeleteByPolicyCodeSuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Integer policyCode = 12345;
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);

			// When
			ResponseEntity<Object> response = policyController.deleteByPolicyCode(policyCode, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).delete(policyCode);
		}
	}

	@Test
	void testDeleteByPolicyCodeUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Integer policyCode = 12345;
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.deleteByPolicyCode(policyCode, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testDeleteByPolicyCodeHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			Integer policyCode = 12345;
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			doThrow(new HVWException("Delete error")).when(policyService).delete(policyCode);

			// When
			ResponseEntity<Object> response = policyController.deleteByPolicyCode(policyCode, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testValidatePolicyExcelSuccess() throws IOException {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			MockMultipartFile file = new MockMultipartFile("file", TEST_EXCEL_FILENAME, TEST_EXCEL_CONTENT_TYPE,
					TEST_EXCEL_CONTENT.getBytes());
			Map<String, List<String>> validationResult = new HashMap<>();
			validationResult.put("errors", Arrays.asList("Error 1", "Error 2"));

			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyImportService.validatePolicySheet(any(InputStream.class))).thenReturn(validationResult);

			// When
			ResponseEntity<Object> response = policyController.validatePolicyExcel(file, testAuthToken, testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyImportService).validatePolicySheet(any(InputStream.class));
		}
	}

	@Test
	void testValidatePolicyExcelUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			MockMultipartFile file = new MockMultipartFile("file", TEST_EXCEL_FILENAME, TEST_EXCEL_CONTENT_TYPE,
					TEST_EXCEL_CONTENT.getBytes());
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.validatePolicyExcel(file, testAuthToken, testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testValidatePolicyExcelHvwException() throws IOException {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			MockMultipartFile file = new MockMultipartFile("file", TEST_EXCEL_FILENAME, TEST_EXCEL_CONTENT_TYPE,
					TEST_EXCEL_CONTENT.getBytes());
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyImportService.validatePolicySheet(any(InputStream.class)))
					.thenThrow(new HVWException("Validation error"));

			// When
			ResponseEntity<Object> response = policyController.validatePolicyExcel(file, testAuthToken, testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testImportPolicyExcelSuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			MockMultipartFile file = new MockMultipartFile("file", TEST_EXCEL_FILENAME, TEST_EXCEL_CONTENT_TYPE,
					TEST_EXCEL_CONTENT.getBytes());
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);

			// When
			ResponseEntity<Object> response = policyController.importPolicyExcel(file, testAuthToken, testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyImportService).importPolicyExcel(any(InputStream.class), eq(TEST_USER));
		}
	}

	@Test
	void testImportPolicyExcelUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			MockMultipartFile file = new MockMultipartFile("file", TEST_EXCEL_FILENAME, TEST_EXCEL_CONTENT_TYPE,
					TEST_EXCEL_CONTENT.getBytes());
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.importPolicyExcel(file, testAuthToken, testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testImportPolicyExcelHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			MockMultipartFile file = new MockMultipartFile("file", TEST_EXCEL_FILENAME, TEST_EXCEL_CONTENT_TYPE,
					TEST_EXCEL_CONTENT.getBytes());
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			doThrow(new HVWException("Import error")).when(policyImportService)
					.importPolicyExcel(any(InputStream.class), eq(TEST_USER));

			// When
			ResponseEntity<Object> response = policyController.importPolicyExcel(file, testAuthToken, testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testGetPolicyTypeIdsSuccess() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			List<String> policyTypeKeys = Arrays.asList("t1", "t2", "t3");
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.getPolicyTypeKeys()).thenReturn(policyTypeKeys);

			// When
			ResponseEntity<Object> response = policyController.getPolicyTypeIds(testRequestId, testAuthToken);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.OK, response.getStatusCode());
			verify(policyService).getPolicyTypeKeys();
		}
	}

	@Test
	void testGetPolicyTypeIdsUnauthorized() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn("");

			// When
			ResponseEntity<Object> response = policyController.getPolicyTypeIds(testRequestId, testAuthToken);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		}
	}

	@Test
	void testGetPolicyTypeIdsHvwException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.getPolicyTypeKeys()).thenThrow(new HVWException("Service error"));

			// When
			ResponseEntity<Object> response = policyController.getPolicyTypeIds(testRequestId, testAuthToken);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		}
	}

	@Test
	void testUnexpectedException() {
		try (MockedStatic<HVWUtils> hvwUtilsMock = mockStatic(HVWUtils.class)) {
			// Given
			hvwUtilsMock.when(() -> HVWUtils.getUserIdFromJWT(testAuthToken)).thenReturn(TEST_USER);
			when(policyService.listPolicies(testPolicyFields)).thenThrow(new RuntimeException("Unexpected error"));

			// When
			ResponseEntity<Object> response = policyController.listPolicies(testPolicyFields, testAuthToken,
					testRequestId);

			// Then
			assertNotNull(response);
			assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
			assertTrue(response.getBody() instanceof ByteArrayResource);
		}
	}
}
