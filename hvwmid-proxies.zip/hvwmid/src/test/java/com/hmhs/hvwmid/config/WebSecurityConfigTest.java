package com.hmhs.hvwmid.config;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WebSecurityConfigTest {

    private final WebSecurityConfig config = new WebSecurityConfig();



    @Test
    void corsConfigurationSource_shouldContainExpectedOriginsAndMethods() {
        CorsConfigurationSource source = config.corsConfigurationSource();
        MockHttpServletRequest request = new MockHttpServletRequest();


        CorsConfiguration corsConfig = source.getCorsConfiguration(request);


        assertNotNull(corsConfig);
        assertTrue(corsConfig.getAllowedOriginPatterns().contains("http://localhost:4200"));
        assertTrue(corsConfig.getAllowedMethods().containsAll(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")));
        assertEquals(List.of("*"), corsConfig.getAllowedHeaders());
        assertTrue(corsConfig.getAllowCredentials());
    }
}