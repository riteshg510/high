package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.model.CoverSheetApplicationDTO;
import com.hmhs.hvwmid.model.CoverSheetDepartmentDTO;
import com.hmhs.hvwmid.service.CoversheetService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.constants.HVWConstants;
import jakarta.validation.Valid;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * CoversheetApplicationController handles coversheet application management operations.
 * 
 * This controller provides REST endpoints for application management including:
 * - Application CRUD operations with department grouping
 * - Application retrieval by department ID and individual ID
 * - Soft delete operations for applications
 * - Template maintenance access control
 * 
 * All operations include comprehensive audit logging using LoggerService.
 * Uses ThreadContext for request tracking across the application.
 * 
 * @author Generated
 * @version 1.0
 * @since 2024
 */
@RestController
@RequestMapping("${controller.path.coversheet}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CoversheetApplicationController {

    @Autowired
    private HttpServletRequest request;

    private static final Logger logger = LogManager.getLogger(CoversheetApplicationController.class);
    public static String hvwAdminGroup = "HVW-ADMINISTRATION-INT";

    // Hold for local use
    private String loginUser = HVWConstants.UID;

    @Autowired
    LoggerService loggerService;

    final private CoversheetService coversheetService;

    public CoversheetApplicationController(CoversheetService coversheetService) {
        this.coversheetService = coversheetService;
    }

    // Utility method to store requestId in ThreadContext for logging and downstream usage
    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }


    /**
     * Get all applications grouped by department with optional inactive filtering.
     * 
     * @param showInactive Whether to include inactive applications
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return List of CoverSheetDepartmentDTO objects with applications
     */
    @GetMapping("/applications")
    public List<CoverSheetDepartmentDTO> getAllApplications(@RequestParam(defaultValue = "false") boolean showInactive,
                                                            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getAllApplications()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllApplications() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getAllApplications()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        List<CoverSheetDepartmentDTO> result = coversheetService.getAllApplications(showInactive, groups);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllApplications() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getAllApplications()");
        logger.info("END - getAllApplications()");
        return result;
    }


    /**
     * Get all applications for a specific department.
     * 
     * @param departmentId The department ID to filter applications
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return List of CoverSheetApplicationDTO objects
     */
    @GetMapping("/applications/department/{departmentId}")
    public List<CoverSheetApplicationDTO> getAllApplicationsForDepartment(@PathVariable Integer departmentId,
                                                            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getAllApplicationsForDepartment()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllApplicationsForDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getAllApplicationsForDepartment()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        List<CoverSheetApplicationDTO> result = coversheetService.getAllApplicationsByDepartment(departmentId, groups);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllApplicationsForDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getAllApplicationsForDepartment()");
        logger.info("END - getAllApplicationsForDepartment()");
        return result;
    }


    /**
     * Get application by ID.
     * 
     * @param id The application ID
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return CoverSheetApplicationDTO object
     */
    @GetMapping("/applications/{id}")
    public CoverSheetApplicationDTO getApplicationById(@PathVariable Integer id,
                                                       @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                       @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getApplicationById()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getApplicationById() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getApplicationById()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        CoverSheetApplicationDTO result = coversheetService.getApplicationsById(id, groups);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getApplicationById() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getApplicationById()");
        logger.info("END - getApplicationById()");
        return result;
    }



    /**
     * Create a new application with automatic sequence generation if needed.
     * 
     * @param appl The application data to create
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return Created CoverSheetApplicationDTO object
     */
    @PostMapping("/applications")
    public CoverSheetApplicationDTO createApplication(@Valid @RequestBody CoverSheetApplicationDTO appl,
                                                      @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                      @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - createApplication()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createApplication() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - createApplication()");
        logger.info("Creating new application: {}", appl.getDescription());
        logger.debug(appl.toString());
        // if application ID is null or empty, generate a new sequence number
        if (appl.getApplication() == null || appl.getApplication() <= 0) {
            appl.setApplication(coversheetService.getCoverApplSequence());
            appl.setSequence(1);
        }
        CoverSheetApplicationDTO result = coversheetService.saveApplication(appl);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createApplication() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - createApplication()");
        logger.info("END - createApplication()");
        return result;
    }

    /**
     * Update an existing application.
     * 
     * @param appl The application data to update
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return Updated CoverSheetApplicationDTO object
     */
    @PutMapping("/applications")
    public CoverSheetApplicationDTO updateApplication(@Valid @RequestBody CoverSheetApplicationDTO appl,
                                                      @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                      @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - updateApplication()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateApplication() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - updateApplication()");
        logger.info("Updating application: {}", appl.getDescription());
        logger.debug(appl.toString());
        CoverSheetApplicationDTO result = coversheetService.saveApplication(appl);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateApplication() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - updateApplication()");
        logger.info("END - updateApplication()");
        return result;
    }

    /**
     * Soft delete an application by setting it as inactive.
     * 
     * @param id The application ID to delete
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return ResponseEntity with no content
     */
    @DeleteMapping("/applications/{id}")
    public ResponseEntity<Void> deleteApplication(@PathVariable Integer id,
                                                  @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                  @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - deleteApplication()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteApplication() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - deleteApplication()");
        logger.info("Deleting application with ID: {}", id);
        coversheetService.deleteApplication(id);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteApplication() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - deleteApplication()");
        logger.info("END - deleteApplication()");
        return ResponseEntity.noContent().build();
    }


    /**
     * This method checks if the user belongs to Highview Admin Groups for Coversheet template Maintenance.
     * 
     * @param authToken The authorization token
     * @return The admin group name if user belongs to it, null otherwise
     */
    private String getTemplateMaintGroups(String authToken) {
        List<String> userGroups = HVWUtils.getUserGroups(authToken);
        String templateGroup = null;
        for (String group : userGroups) {
            if (group.trim().equalsIgnoreCase(hvwAdminGroup)) {
                templateGroup = group;
                logger.debug("User is part of the Highview Admin group => User Group: " + group);
            }
        }
        return templateGroup;
    }

    /**
     * Check if user has template maintenance access.
     * 
     * @param authToken The authorization token
     * @return true if user has template maintenance access, false otherwise
     */
    public boolean chkTemplateMaintAccess(String authToken){
        String templateMaintGroup = getTemplateMaintGroups(authToken);
        return (templateMaintGroup != null);
    }



}
