package com.hmhs.hvwmid.controllers;

import static com.hmhs.hvwmid.controllers.CoversheetApplicationController.hvwAdminGroup;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.T117ImgCoverObject;
import com.hmhs.hvwmid.model.CoverSheetObjectDTO;
import com.hmhs.hvwmid.model.CoverSheetOverrideDTO;
import com.hmhs.hvwmid.model.CoversheetFileResult;
import com.hmhs.hvwmid.service.CoversheetObjectServiceImpl;
import com.hmhs.hvwmid.service.CoversheetService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("${controller.path.coversheet}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CoversheetTemplatesController {

    private static final Logger logger = LogManager.getLogger(CoversheetTemplatesController.class);
    final private CoversheetService coversheetService;
    final private CoversheetObjectServiceImpl coversheetObjectService;

    private final LoggerService loggerService;
    private final HttpServletRequest request;

    public CoversheetTemplatesController(CoversheetService coversheetService,
            CoversheetObjectServiceImpl coversheetObjectService, HttpServletRequest request,
            LoggerService loggerService) {
        this.coversheetService = coversheetService;
        this.coversheetObjectService = coversheetObjectService;
        this.request = request;
        this.loggerService = loggerService;
    }

    @GetMapping("/template/download")
    public ResponseEntity<byte[]> displayCoverSheet(@RequestParam(defaultValue = "0") int applicationId,
            @RequestParam(defaultValue = "0") int sequence,
            @RequestParam(defaultValue = "") String coversheetName,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = false) final Integer requestId) {
        boolean templateAccess = true;
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - displayCoverSheet()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllDepartments() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - displayCoverSheet()");

        if (!templateAccess) {
            return ResponseEntity.status(403).build();
        }

        boolean override = sequence > 0;

        CoversheetFileResult result = coversheetService.getCoverSheet(applicationId, sequence, coversheetName,
                override);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(result.getMimeType()));
        headers.setContentLength(result.getData().length);
        if (result.getMimeType().contains("pdf")) {
            headers.setContentType(MediaType.APPLICATION_PDF);
        } else if (result.getMimeType().contains("html") || result.getMimeType().contains("xml")) {
            headers.setContentType(MediaType.TEXT_HTML);
        } else if (result.getMimeType().contains("javascript") || result.getMimeType().contains("js")) {
            headers.setContentType(MediaType.TEXT_PLAIN);
        } else {
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        }

        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllDepartments() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getAllDepartments()");
        logger.info("END - displayCoverSheet()");
        return ResponseEntity.ok().headers(headers).body(result.getData());
    }

    @GetMapping("/template/metadata")
    public ResponseEntity<CoverSheetObjectDTO> getTemplateWithMetadata(@RequestParam(required = true) String objectName,
            @RequestParam(required = true) String objectType,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = false) final Integer requestId) {
        boolean templateAccess = true;

        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getTemplateWithMetadata()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllDepartments() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getTemplateWithMetadata()");

        if (!templateAccess) {
            logger.error("Unauthorized access attempt to template: {} of type: {}", objectName, objectType);
            return ResponseEntity.status(403).build();
        }

        CoverSheetObjectDTO result = coversheetObjectService.getTemplateByNameAndType(objectName, objectType);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllDepartments() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getTemplateWithMetadata()");
        logger.info("END - getTemplateWithMetadata()");

        return ResponseEntity.ok().body(result);
    }

    @PostMapping(value = "/template/upload-binary", consumes = "multipart/form-data")
    public ResponseEntity<Object> uploadTemplateObject(
            @RequestPart("file") MultipartFile file,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @Valid CoverSheetObjectDTO coverSheetObjectDTO) throws IOException {

        try {

            if (chkTemplateMaintAccess(authToken) == false) {
                logger.error("Unauthorized access attempt to upload template object");
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(Map.of("error", "You do not have permission to upload templates"));
            }

            String objName = coverSheetObjectDTO.getObjName().toUpperCase();
            String fileContent = new String(file.getBytes(), StandardCharsets.UTF_8);

            T117ImgCoverObject template = new T117ImgCoverObject();
            template.setObjName(objName.trim().toUpperCase());
            template.setObjType(coverSheetObjectDTO.getObjType().trim().toUpperCase());
            template.setMimeType(coverSheetObjectDTO.getMimeType());
            template.setObjData(fileContent);
            template.setActive("Y");
            coversheetService.saveNewCoverSheetTemplate(template);
            return ResponseEntity.ok(Map.of("message", "Cover object uploaded successfully"));

        } catch (Exception e) {
            logger.error("Error uploading template object: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Upload failed", "details", e.getMessage()));
        }
    }

    @PutMapping(value = "/template/metadata")
    public ResponseEntity<Object> editTemplate(
            @Valid @RequestBody CoverSheetObjectDTO coverSheetObjectDTO,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken)
            throws IOException {

        if (chkTemplateMaintAccess(authToken) == false) {
            logger.error("Unauthorized access attempt to create template object");
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "You do not have permission to upload templates"));
        }

        try {
            T117ImgCoverObject template = new T117ImgCoverObject();
            template.setObjName(coverSheetObjectDTO.getObjName().trim().toUpperCase());
            template.setObjType(coverSheetObjectDTO.getObjType().trim().toUpperCase());
            template.setMimeType(coverSheetObjectDTO.getMimeType());
            template.setObjData(coverSheetObjectDTO.getObjData());
            template.setActive("Y");
            coversheetService.saveNewCoverSheetTemplate(template);
            return ResponseEntity.ok(Map.of("message", "Cover object uploaded successfully"));

        } catch (Exception e) {
            logger.error("Error creating template: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Upload failed", "details", e.getMessage()));
        }
    }

    @PostMapping(value = "/template/metadata")
    public ResponseEntity<Object> createTemplate(
            @Valid @RequestBody CoverSheetObjectDTO coverSheetObjectDTO,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken)
            throws IOException {

        if (chkTemplateMaintAccess(authToken) == false) {
            logger.error("Unauthorized access attempt to create template object");
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(Map.of("error", "You do not have permission to upload templates"));
        }

        try {
            T117ImgCoverObject template = new T117ImgCoverObject();
            template.setObjName(coverSheetObjectDTO.getObjName().trim().toUpperCase());
            template.setObjType(coverSheetObjectDTO.getObjType().trim().toUpperCase());
            template.setMimeType(coverSheetObjectDTO.getMimeType());
            template.setObjData(coverSheetObjectDTO.getObjData());
            template.setActive("Y");
            return ResponseEntity.ok().body(coversheetService.saveNewCoverSheetTemplate(template));

        } catch (Exception e) {
            logger.error("Error creating template: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Upload failed", "details", e.getMessage()));
        }
    }

    @GetMapping("/template")
    public List<CoverSheetObjectDTO> getAllTemplateNames(
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

        List<CoverSheetObjectDTO> templates = new ArrayList<>();
        List<T117ImgCoverObject> templateObjects = coversheetObjectService.getTemplates();
        for (T117ImgCoverObject template : templateObjects) {
            CoverSheetObjectDTO dto = new CoverSheetObjectDTO(
                    template.getObjName().trim(),
                    template.getObjType().trim(),
                    template.getMimeType().trim(),
                    "");
            templates.add(dto);
        }
        return templates;
    }

    /**
     * This method checks if the Highview Admin Groups for Coversheet template
     * Maintenance
     * 
     * @param authToken
     * @return boolean - weather user belongs to Highview Admin Group
     */
    boolean chkTemplateMaintAccess(String authToken) {
        List<String> userGroups = HVWUtils.getUserGroups(authToken);
        for (String group : userGroups) {
            if (group.trim().equalsIgnoreCase(hvwAdminGroup)) {
                logger.debug("User is part of the Highview Admin group => User Group: {}", group);
                return true;
            }
        }
        return false;
    }

    /**
     * Method to get all the coversheets/overrides using the selected/clicked
     * Template Name
     * 
     * @input String TEMPLATE NAME
     * @param authToken
     * @output List of CoverSheetOverrideDTO
     */
    @GetMapping(value = "/template/{templateName}/coversheets", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<CoverSheetOverrideDTO>> getCoversheetsByTemplateName(
            @PathVariable String templateName,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

        boolean access = chkTemplateMaintAccess(authToken);
        if (!access) {
            logger.error("Unauthorized access attempt to get coversheets by template name: {}", templateName);
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(null);
        }

        List<CoverSheetOverrideDTO> coversheets = coversheetService
                .getAllCoversheetsAndOverridesByTemplateName(templateName);
        return ResponseEntity.ok().body(coversheets);

    }

}
