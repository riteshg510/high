package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListIdxValService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * ImagesController handles image-related operations.
 * Provides endpoints for image listing, viewing, downloading, and copying.
 */
@RestController
@RequestMapping("${controller.path.image}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ListIdxValController {

	private HttpServletRequest request;
	private static final Logger logger = LogManager.getLogger(ListIdxValController.class);
	private final ListIdxValService service;
	private String loginUser = HVWConstants.UID;
	private LoggerService loggerService;

	public ListIdxValController(ListIdxValService service,LoggerService loggerService, HttpServletRequest request) {
		this.service = service;
        this.request = request;
        this.loggerService = loggerService;
	}

	// Utility method to store requestId in ThreadContext for logging and downstream usage
    private void storeRequestId(Integer requestId) {
        org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
    }

	@GetMapping("/listidxval")
	public ResponseEntity<Object> filter(
			@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = false) final Integer requestId) throws HVWException {
		storeRequestId(requestId);
		logger.info("START - filter listidxval()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "filter() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - filter()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        for (Map.Entry<String, String> entry : otherFields.entrySet()) {
            logger.debug("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
        try{
            otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
            logger.debug("Applidcd " +otherFields.get("Applidcd"));
            logger.debug("IndexType "+otherFields.get("IndexType"));
            logger.debug("UniqueCharacters "+otherFields.get("UniqueCharacters"));
            logger.debug("Mask "+otherFields.get("Mask"));

            ResponseEntity<Object> response = service.filter(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "filter() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - filter()");
            logger.info("END - filter listidxval()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "filter()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - filter()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
	}

}
