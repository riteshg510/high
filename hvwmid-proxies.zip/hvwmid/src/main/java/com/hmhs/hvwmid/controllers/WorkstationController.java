package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.WorkstationService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * WorkstationController handles workstation-related operations.
 * Provides endpoints for workstation listing and management.
 */
@RestController
@RequestMapping("${controller.path.workstation}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class WorkstationController {

    private static final Logger logger = LogManager.getLogger(WorkstationController.class);
    private final WorkstationService workstationService;
    private final HttpServletRequest request;
    private final LoggerService loggerService;
    private String loginUser = HVWConstants.UID;

    public WorkstationController(WorkstationService workstationService, HttpServletRequest request, LoggerService loggerService) {
        this.workstationService = workstationService;
        this.request = request;
        this.loggerService = loggerService;
    }

    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }

    /**
     * Endpoint to retrieve workstation listing based on provided parameters.
     * Supports filtering by workstation ID mask and IP address mask.
     *
     * @param otherFields The request parameters for workstation filtering
     * @param authToken   JWT authentication token
     * @param requestId   Request ID for logging and tracking
     * @return ResponseEntity containing workstation data or error response
     * @throws HVWException if an error occurs during processing
     */
    @PostMapping("/list")
    public ResponseEntity<Object> listWorkstations(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {

        storeRequestId(requestId);
        logger.info("START - listWorkstations()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "listWorkstations() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - listWorkstations()");

        try {
            loginUser = HVWUtils.getUserIdFromJWT(authToken);
            otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

            ResponseEntity<Object> response = workstationService.getWorkstationList(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "listWorkstations() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - listWorkstations()");
            logger.info("END - listWorkstations()");
            return response;

        } catch (final HVWException e) {
            logger.error("Error in workstation data result processing: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "listWorkstations()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage() != null && e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - listWorkstations()");
            return HVWException.createErrorResponseEntity(e);
        } catch (final Exception e) {
            logger.error("Unexpected error while retrieving workstation data", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "listWorkstations()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage() != null && e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - listWorkstations()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("SERVICE_UNAVAILABLE");
        }
    }
}