package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListIdxValService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.PimgWSService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * ImagesController handles image-related operations.
 * Provides endpoints for image listing, viewing, downloading, and copying.
 */
@RestController
@RequestMapping("${controller.path.workstation}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class PimgWSController {

	private HttpServletRequest request;
	private static final Logger logger = LogManager.getLogger(PimgWSController.class);
	private final PimgWSService service;
	private String loginUser = HVWConstants.UID;
	private LoggerService loggerService;

	public PimgWSController(PimgWSService service, LoggerService loggerService, HttpServletRequest request) {
		this.service = service;
        this.request = request;
        this.loggerService = loggerService;
	}

	// Utility method to store requestId in ThreadContext for logging and downstream usage
    private void storeRequestId(Integer requestId) {
        org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
    }

	@PostMapping("/pimgws")
	public ResponseEntity<Object> execute(
			@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = false) final Integer requestId) throws HVWException {
		storeRequestId(requestId);
		logger.info("START - execute pimgws()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "filter() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - pimgws execute()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        try{
            otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
            logger.debug("function " +otherFields.get("function"));
            logger.debug("workstation "+otherFields.get("workstation"));
            logger.debug("ipaddress "+otherFields.get("ipaddress"));

            ResponseEntity<Object> response = service.filter(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "filter() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - pimgws execute()");
            logger.info("END - pimgws execute()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "execute()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - pimgws execute()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
	}

}
