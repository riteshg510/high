package com.hmhs.hvwmid.controllers;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.ExcelUploadResponse;
import com.hmhs.hvwmid.model.FileStorageResult;
import com.hmhs.hvwmid.model.GenerateIMIRequest;
import com.hmhs.hvwmid.model.GenerateIMIResponse;
import com.hmhs.hvwmid.model.ImageUploadResponse;
import com.hmhs.hvwmid.repository.ImageCachingRepository;
import com.hmhs.hvwmid.service.FileStorageService;
import com.hmhs.hvwmid.service.IMIFileGeneratorService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.validator.GenerateIMIRequestValidator;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(value = { "${controller.path.imigen}" })
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class IMIGeneratorController {

	private static final Logger logger = LoggerFactory.getLogger(IMIGeneratorController.class);
	private static final String PARM_ID_IMGSEG = "IMISEG";
	private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	private final IMIFileGeneratorService imiFileGeneratorService;
	private final FileStorageService fileStorageService;
	private final ImageCachingRepository imageCachingRepository;
	private final LoggerService loggerService;
	private final GenerateIMIRequestValidator requestValidator;
	private final HttpServletRequest request;

	public IMIGeneratorController(IMIFileGeneratorService imiFileGeneratorService,
	                            FileStorageService fileStorageService,
	                            ImageCachingRepository imageCachingRepository,
	                            LoggerService loggerService,
	                            GenerateIMIRequestValidator requestValidator,
	                            HttpServletRequest request) {
		this.imiFileGeneratorService = imiFileGeneratorService;
		this.fileStorageService = fileStorageService;
		this.imageCachingRepository = imageCachingRepository;
		this.loggerService = loggerService;
		this.requestValidator = requestValidator;
		this.request = request;
	}

	/**
	 * Endpoint to retrieve IMI segments data
	 * 
	 * @param authToken The authorization token for user authentication (required)
	 * @param requestId Unique identifier for request tracking and logging (required)
	 * @return ResponseEntity containing the segments map or error message
	 */
	@GetMapping("/segments")
	public ResponseEntity<Object> getSegments(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		
		try {
			String loginUser = HVWUtils.getUserIdFromJWT(authToken);
			
			if (loginUser == null || loginUser.isEmpty()) {
				logger.error("Authentication required. Missing or invalid token for request: {}", requestId);
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}
			
			logger.debug("Received segments request for user: {} with requestId: {}", loginUser, requestId);
			
			Map<String, String> segmentsMap = imiFileGeneratorService.getStringParmData(PARM_ID_IMGSEG);
			
			if (segmentsMap.isEmpty()) {
				logger.warn("No segments found for PARM_ID: {} for user: {}", PARM_ID_IMGSEG, loginUser);
				return createErrorResponse(404, "No segments data found.");
			}
			
			logger.info("Successfully retrieved {} segments for user: {}", segmentsMap.size(), loginUser);
			return ResponseEntity.ok(segmentsMap);
			
		} catch (Exception e) {
			logger.error("Error retrieving segments for requestId {}: {}", requestId, e.getMessage(), e);
			return createErrorResponse(500, "Error retrieving segments: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to upload Excel file for IMI generation
	 * 
	 * @param authToken The authorization token for user authentication (required)
	 * @param requestId Unique identifier for request tracking and logging (required)
	 * @param inputFile Excel file to upload (.xls or .xlsx)
	 * @param documentCount Documents per IMI (1-2000, default 25)
	 * @param filePriority File priority (1-100)
	 * @return ResponseEntity containing Excel ID, name, headers, and distinct filenames
	 */
	@PostMapping(path = "/upload-excel",
			consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Object> uploadExcel(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestParam(value = "inputFile", required = true) MultipartFile inputFile,
			@RequestParam(value= "documentCount", required = false, defaultValue = "25") Integer documentCount,
			@RequestParam(value = "filePriority", required = true) Integer filePriority) {
		
		String loginUser = null;
		
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			
			if (loginUser == null || loginUser.isEmpty()) {
				logger.error("Authentication required. Missing or invalid token for request: {}", requestId);
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-excel", 
				                request.getRequestURI(), "401", 
				                "Authentication required. Missing or invalid token.");
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}
			
			logger.debug("Received Excel upload request from user: {} with requestId: {}", loginUser, requestId);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "/upload-excel", 
			                request.getRequestURI(), "", 
			                "START - Upload Excel file");
			
			// Upload and process Excel file
			ExcelUploadResponse response = imiFileGeneratorService.uploadExcelFile(
				inputFile, documentCount, filePriority, loginUser);
			
			loggerService.log("INFO", requestId, 0, 0, loginUser, "/upload-excel", 
			                request.getRequestURI(), "200", 
			                String.format("Excel uploaded successfully. Excel ID: %d, Columns: %d, Distinct files: %d", 
			                            response.getExcelId(), 
			                            response.getColumnHeaders().size(), 
			                            response.getDistinctFilenames().size()));
			
			logger.info("Excel file uploaded successfully with ID {} for user: {}", response.getExcelId(), loginUser);
			return ResponseEntity.ok(response);
			
		} catch (IllegalArgumentException e) {
			logger.error("Validation error for Excel upload request from user {}: {}", loginUser, e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-excel", 
			                request.getRequestURI(), "400", 
			                e.getMessage());
			return createErrorResponse(400, e.getMessage());
		} catch (Exception e) {
			logger.error("Error processing Excel upload for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-excel", 
			                request.getRequestURI(), "500", 
			                "Error uploading Excel: " + e.getMessage());
			return createErrorResponse(500, "Error uploading Excel file: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to upload image file for IMI generation
	 * 
	 * @param authToken The authorization token for user authentication (required)
	 * @param requestId Unique identifier for request tracking and logging (required)
	 * @param imageFile Image file to upload
	 * @param excelId Reference to uploaded Excel REQUEST_ID
	 * @param filename Name from distinct filenames list
	 * @return ResponseEntity containing image upload response
	 */
	@PostMapping(path = "/upload-image",
			consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Object> uploadImage(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestParam(value = "imageFile", required = true) MultipartFile imageFile,
			@RequestParam(value = "excelId", required = true) Integer excelId,
			@RequestParam(value = "filename", required = true) String filename) {
		
		String loginUser = null;
		
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			
			if (loginUser == null || loginUser.isEmpty()) {
				logger.error("Authentication required. Missing or invalid token for request: {}", requestId);
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-image", 
				                request.getRequestURI(), "401", 
				                "Authentication required. Missing or invalid token.");
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}
			
			logger.debug("Received image upload request from user: {} for Excel ID: {}", loginUser, excelId);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "/upload-image", 
			                request.getRequestURI(), "", 
			                String.format("START - Upload image file. Excel ID: %d, Filename: %s", excelId, filename));
			
			// Validate file
			if (imageFile == null || imageFile.isEmpty()) {
				throw new IllegalArgumentException("Please select an image file to upload");
			}
			
			// Get distinct filenames from the Excel file
			List<String> validFilenames = imiFileGeneratorService.getDistinctFilenamesFromExcel(excelId, loginUser);

			// Check if any valid filename contains the given filename (substring match, case-insensitive)
			boolean matchFound = validFilenames.stream()
					.filter(Objects::nonNull)
					.anyMatch(valid -> valid.toLowerCase().contains(filename.toLowerCase()));

			if (!matchFound) {
				String message = String.format(
						"Filename '%s' not found in Excel file. Valid filenames: %d",
						filename.toLowerCase(), validFilenames.size()
				);
				logger.warn("Invalid filename for user {}: {}", loginUser, message);
				loggerService.log("WARN", requestId, 0, 0, loginUser, "/upload-image",
						request.getRequestURI(), "400", message);
				throw new IllegalArgumentException(message);
			}
			
			// Determine document type from file extension
			String originalFilename = imageFile.getOriginalFilename();
			String documentType = "";
			if (originalFilename != null && originalFilename.contains(".")) {
				documentType = originalFilename.substring(originalFilename.lastIndexOf('.') + 1).toUpperCase();
			}
			if (documentType.isEmpty()) {
				documentType = "IMG"; // Default for images
			}
			
			// Store the image file
			FileStorageResult storageResult = fileStorageService.storeFile(imageFile, loginUser, documentType);
			
			// Create response
			ImageUploadResponse response = new ImageUploadResponse();
			response.setRequestId(storageResult.getRequestId());
			response.setFilename(filename);
			response.setStatus("success");
			response.setMessage(String.format("Image uploaded successfully. REQUEST_ID: %d", storageResult.getRequestId()));
			
			loggerService.log("INFO", requestId, 0, 0, loginUser, "/upload-image", 
			                request.getRequestURI(), "200", 
			                String.format("Image uploaded successfully. REQUEST_ID: %d, Filename: %s", 
			                            storageResult.getRequestId(), filename));
			
			logger.info("Image file uploaded successfully with REQUEST_ID {} for user: {}", 
			          storageResult.getRequestId(), loginUser);
			return ResponseEntity.ok(response);
			
		} catch (SecurityException e) {
			logger.error("Access denied for image upload by user {}: {}", loginUser, e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-image", 
			                request.getRequestURI(), "403", e.getMessage());
			return createErrorResponse(403, e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.error("Validation error for image upload by user {}: {}", loginUser, e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-image", 
			                request.getRequestURI(), "400", e.getMessage());
			return createErrorResponse(400, e.getMessage());
		} catch (Exception e) {
			logger.error("Error processing image upload for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "/upload-image", 
			                request.getRequestURI(), "500", 
			                "Error uploading image: " + e.getMessage());
			return createErrorResponse(500, "Error uploading image file: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to download file by REQUEST_ID
	 * 
	 * @param authToken The authorization token for user authentication (required)
	 * @param requestIdHeader Unique identifier for request tracking and logging (required)
	 * @param requestId The REQUEST_ID of the file to download
	 * @param externalFilename
	 * @return ResponseEntity with streaming file content
	 */
	@GetMapping("/download/{requestId}")
	public ResponseEntity<StreamingResponseBody> downloadFile(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestIdHeader,
			@PathVariable("requestId") final Integer requestId,
			@RequestParam(value = "filename", required = false) final String externalFilename) {
		
		String loginUser = null;
		
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			
			if (loginUser == null || loginUser.isEmpty()) {
				logger.error("Authentication required. Missing or invalid token for request: {}", requestIdHeader);
				loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/download", 
				                request.getRequestURI(), "401", 
				                "Authentication required. Missing or invalid token.");
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
			}
			
			logger.debug("Received download request from user: {} for REQUEST_ID: {}", loginUser, requestId);
			loggerService.log("INFO", requestIdHeader, 0, 0, loginUser, "/download", 
			                request.getRequestURI(), "", 
			                String.format("START - Download file with REQUEST_ID: %d", requestId));
			
			// Get file metadata from T222_IMG_TOKEN
			FileStorageResult metadata = fileStorageService.getFileMetadata(requestId);
			if (metadata == null) {
				logger.error("File not found with REQUEST_ID: {}", requestId);
				loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/download", 
				                request.getRequestURI(), "404", 
				                String.format("File not found with REQUEST_ID: %d", requestId));
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
			
			// Validate user access
			if (!fileStorageService.validateAccess(requestId, loginUser)) {
				logger.error("User {} does not have access to file with REQUEST_ID: {}", loginUser, requestId);
				loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/download",
				                request.getRequestURI(), "403",
				                String.format("Access denied to file with REQUEST_ID: %d", requestId));
				return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
			}
			
			// Determine file extension and MIME type based on DOCUMENT_TYPE
			String documentType = metadata.getDocumentType();
			String extension;
			MediaType contentType;
			
			if ("XLSX".equalsIgnoreCase(documentType)) {
				extension = ".xlsx";
				contentType = MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			} else if ("IMI".equalsIgnoreCase(documentType)) {
				extension = ".imi";
				contentType = MediaType.APPLICATION_OCTET_STREAM;
			} else {
				// Default for other types
				extension = "";
				contentType = MediaType.APPLICATION_OCTET_STREAM;
			}
			
			// Generate filename: {TYPE}_{USERNAME}_DATETIME_{REQUEST_ID}.extension
			String dateTime = metadata.getTimeCreated().format(DATE_TIME_FORMATTER);
			String filename = String.format("%s_%s_%s_%d%s", 
			                              documentType,
			                              loginUser.toUpperCase(),
			                              dateTime,
			                              requestId,
			                              extension);
			if(externalFilename != null && !externalFilename.isEmpty()) {
				filename = externalFilename;
			}
			
			// Create streaming response
			final Integer finalRequestIdHeader = requestIdHeader;
			final String finalLoginUser = loginUser;
			StreamingResponseBody responseBody = outputStream -> {
				try {
					imageCachingRepository.streamSegmentsByRequestId(requestId, outputStream);
					loggerService.log("INFO", finalRequestIdHeader, 0, 0, finalLoginUser, "/download", 
					                request.getRequestURI(), "200", 
					                String.format("Successfully streamed file with REQUEST_ID: %d", requestId));
				} catch (Exception e) {
					logger.error("Error streaming file with REQUEST_ID {}: {}", requestId, e.getMessage(), e);
					throw new IOException("Error streaming file: " + e.getMessage(), e);
				}
			};
			
			// Build response headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(contentType);
			headers.setContentDispositionFormData("attachment", filename);
			if (metadata.getDocumentSize() != null && metadata.getDocumentSize() > 0) {
				headers.setContentLength(metadata.getDocumentSize());
			}
			
			logger.info("Streaming file {} for user: {}", filename, loginUser);
			
			return ResponseEntity.ok()
					.headers(headers)
					.body(responseBody);
			
		} catch (Exception e) {
			logger.error("Error processing download request for REQUEST_ID {} by user {}: {}", 
			           requestId, loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/download", 
			                request.getRequestURI(), "500", 
			                "Error downloading file: " + e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	/**
	 * Endpoint to generate IMI files based on uploaded Excel and images
	 * 
	 * @param authToken The authorization token for user authentication (required)
	 * @param requestIdHeader Unique identifier for request tracking and logging (required)
	 * @param imiRequest The generate IMI request containing Excel ID, file mappings, and configuration
	 * @return ResponseEntity containing generated IMI files and summary
	 */
	@PostMapping(path = "/generate-imi",
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> generateIMIFiles(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestIdHeader,
			@RequestBody GenerateIMIRequest imiRequest) {
		
		String loginUser = null;
		
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			
			if (loginUser == null || loginUser.isEmpty()) {
				logger.error("Authentication required. Missing or invalid token for request: {}", requestIdHeader);
				loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
				                request.getRequestURI(), "401", 
				                "Authentication required. Missing or invalid token.");
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}
			
			logger.debug("Received generate IMI request from user: {} with requestId: {}", loginUser, requestIdHeader);
			loggerService.log("INFO", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
			                request.getRequestURI(), "", 
			                String.format("START - Generate IMI files. Excel ID: %d, File mappings: %d", 
			                            imiRequest.getExcelId(), 
			                            imiRequest.getFileIdMappings() != null ? imiRequest.getFileIdMappings().size() : 0));
			
			// Validate request
			GenerateIMIRequestValidator.ValidationResult validationResult = requestValidator.validate(imiRequest);
			if (!validationResult.isValid()) {
				logger.warn("Validation failed for IMI generation request from user {}: {}", 
				          loginUser, validationResult.getErrorMessage());
				loggerService.log("WARN", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
				                request.getRequestURI(), "400", 
				                "Validation failed: " + validationResult.getErrorMessage());
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationResult.toErrorResponse());
			}
			
			// Generate IMI files
			GenerateIMIResponse response = imiFileGeneratorService.generateIMIFiles(imiRequest, loginUser);
			
			loggerService.log("INFO", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
			                request.getRequestURI(), "200", 
			                String.format("IMI generation completed. Files: %d, Success: %d, Failed: %d", 
			                            response.getGeneratedFiles().size(), 
			                            response.getSummary().getSuccessful(), 
			                            response.getSummary().getFailed()));
			
			logger.info("IMI generation completed for user: {}. Generated {} files", 
			          loginUser, response.getGeneratedFiles().size());
			return ResponseEntity.ok(response);
			
		} catch (SecurityException e) {
			logger.error("Access denied for IMI generation by user {}: {}", loginUser, e.getMessage());
			loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
			                request.getRequestURI(), "403", e.getMessage());
			return createErrorResponse(403, e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.error("Validation error for IMI generation by user {}: {}", loginUser, e.getMessage());
			loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
			                request.getRequestURI(), "400", e.getMessage());
			return createErrorResponse(400, e.getMessage());
		} catch (Exception e) {
			logger.error("Error generating IMI files for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestIdHeader, 0, 0, loginUser, "/generate-imi", 
			                request.getRequestURI(), "500", 
			                "Error generating IMI files: " + e.getMessage());
			return createErrorResponse(500, "Error generating IMI files: " + e.getMessage());
		}
	}

	private ResponseEntity<Object> createErrorResponse(final int returnCode, final String description) {
		return HVWException.createErrorResponseEntity(returnCode, description);
	}



}