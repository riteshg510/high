package com.hmhs.hvwmid.controllers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.ReportService;
import com.hmhs.hvwmid.service.UserReportService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Ramanjaneyulu Manam on April 18, 2024
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(value = { "${controller.path.reports}" })
@RestController
public class ReportsController {

	@Autowired
	private HttpServletRequest request;

	private static final Logger logger = LogManager.getLogger(ReportsController.class);

	// Hold for local use
	private String loginUser = HVWConstants.UID.toUpperCase();

	// Constants
	private final String delete = HVWConstants.DELETE;
	private final String actionType = HVWConstants.ACTYPE;

	@Autowired
	private AppDataService service;

	@Autowired
	private ReportService reportService;

	@Autowired
	private UserReportService userReportService;

	@Autowired
	private LoggerService loggerService;

	/** START OF REPORTS **/

	/**
	 * Endpoint to fetch the "My Reports" form data.
	 *
	 * This method retrieves the "My Reports" form from the database, identified by
	 * the template name "MyReportsForm." The binary data stored in the database is
	 * converted into a UTF-8 JSON string and returned to the client. If the
	 * operation is successful, the data is logged with a status code of 200. In
	 * case of any errors, an error message is logged, and a response with an HTTP
	 * status code of 503 is returned.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the "My
	 *         Reports" form or an error response in case of failure.
	 */
	@GetMapping("/favorites/get-form")
	public ResponseEntity<String> getMyReportsForm(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);

		logger.info("START - getMyReportsForm()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getMyReportsForm()",
				request.getRequestURI(),"", "START - getMyReportsForm()");

		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("MyReportsForm");
			for (final TblTemplates tdata : tblFilterOptionData) {
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getMyReportsForm()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getMyReportsForm()");
			logger.info("END - getMyReportsForm()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception ex) {
			ex.printStackTrace();
			logger.error(ex.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getMyReportsForm()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
			logger.info("END - getMyReportsForm()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to fetch the JSON template for the "My Reports" table.
	 *
	 * This method retrieves the "My Reports" table template from the database,
	 * identified by the template name "MyReportsTable." The binary data stored
	 * in the database is converted into a UTF-8 JSON string and returned. On
	 * successful retrieval, a log entry with a status of 200 is recorded. If any
	 * errors occur during processing, a log entry is created, and a response with
	 * an HTTP status code of 503 is returned.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the
	 *         "My Reports" table template or an error response in case of failure.
	 */
	@GetMapping("/favorites/get-tabledefinition")
	public ResponseEntity<String> userReportsTableDefinition(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		logger.info("START - userReportsTableDefinition()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsTable()",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "START - getAllReportsTable()");

		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("AllReportsTable");
			
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			//response = reportService.getReportsTableDefinition();
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsTable()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllReportsTable()");
			logger.info("END - getAllReportsTable()");
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error in getAllReportsTableDefinition: {}", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllReportsTable()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - getAllReportsTable()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}

	}

	/**
	 * Endpoint to retrieve the list of cabinets and associated actions for each.
	 * 
	 * @param authToken Authorization token provided in the request header. This is
	 *                  used to extract the user ID for authentication and data
	 *                  filtering.
	 * @return A ResponseEntity containing the filtered reports data or an error
	 *         response in case of authentication failure or processing errors.
	 */

	@GetMapping("/favorites/get-tabledata")
	public ResponseEntity<Object> getMyReportsTableData(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		logger.info("START - getMyReportsTableData()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getMyReportsTableData()",
				request.getRequestURI(), "", "START - getMyReportsTableData()");
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "getMyReportsTableData()",
						request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
			}

			final String responseJson = userReportService.filterJsonByDb(loginUser.toUpperCase(),
					reportService.getAllReportsDataWithDynamicActions("MYREPORTS", authToken));

			// Parse the response to check for errors
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getMyReportsTableData()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getMyReportsTableData()");
			logger.info("END - getMyReportsTableData()");
			return processReportResponse(responseJson, requestId, loginUser);
		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error in My Reports data processing: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getMyReportsTableData()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - getMyReportsTableData()");
			return HVWException.createErrorResponseEntity(e);
		}
	}

	/**
	 * Endpoint to removes a specific report from the authenticated user's "My
	 * Reports" list.
	 * 
	 * This endpoint handles HTTP requests to /reports/my/remove/{id}. It expects a
	 * report ID as a path variable and a JWT token in the request header for user
	 * authentication. The report is removed from the user's saved reports
	 * collection, and a success response is returned.
	 * 
	 * Proper audit logging is performed at each step including authorization check,
	 * user activity, and any errors encountered.
	 *
	 * @param id        the unique identifier of the report to be removed from "My
	 *                  Reports"
	 * @param authToken the JWT token passed in the HVWConstants.AUTH_HEADER header; used for
	 *                  extracting user identity
	 * @return ResponseEntity<Object> containing:
	 * 
	 *         1. HTTP 200 and a success message if the report is successfully
	 *         removed.
	 *         2. HTTP 401 if the user is unauthenticated or token is invalid.
	 *         3. HTTP 503 if an error occurs.
	 * 
	 */
	@PostMapping("/favorites/remove/{id}")
	public ResponseEntity<Object> removeFavoritesReport(@PathVariable(value = "id") String id,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		loggerService.log("INFO", requestId, 0, 0, loginUser, "removeFavoritesReport()",
				request.getRequestURI(), "", "START -removeFavoritesReport()");

		try {
			// Get user ID from auth token
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "removeFavoritesReport()",
						request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}

			// Decode '__SLASH__' back to '/'
			String decodedId = id.replace("__SLASH__", "/");
			logger.info("Removing report from userId: {}", loginUser);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "removeFavoritesReport()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "Removing report " + decodedId + " from MyReport for userId:" + loginUser);
			userReportService.removeFromMyReport(loginUser.toUpperCase(), decodedId);

			// Return success response
			final Map<String, Object> successResponse = new HashMap<>();

			// Create service message with success code
			final Map<String, Object> serviceMessage = new HashMap<>();
			serviceMessage.put("returnCode", 0);
			serviceMessage.put("returnCodeDescription", "Success");
			successResponse.put("serviceMessage", serviceMessage);

			// Add success message and action type
			successResponse.put("message", "Report removed from My Reports");
			successResponse.put(actionType, delete);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "removeFavoritesReport()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - removeFavoritesReport()");
			logger.info("END -removeFavoritesReport()");
			return ResponseEntity.ok(successResponse);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error removing folder from My Reports: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "removeFavoritesReport()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END -removeFavoritesReport()");
			return createErrorResponse(HttpStatus.SERVICE_UNAVAILABLE.value(), "Error removing folder: " + e.getMessage());
		}
	}

	/**
	 * Adds a specific report to the authenticated user's "My Reports" collection.
	 * 
	 * This endpoint is accessible via /reports/my/add/{id}, where id represents
	 * the unique identifier of the report to be saved. The method expects an
	 * authorization token (JWT) in the request header, from which the user identity
	 * is extracted.
	 * 
	 * If authentication succeeds, the specified report is added to the user's saved
	 * reports. A standardized success response is returned. All operations are
	 * logged for audit and debugging purposes.
	 *
	 * @param id        the unique identifier of the report to be added to "My
	 *                  Reports"
	 * @param authToken the JWT token passed in the HVWConstants.AUTH_HEADER header; used for
	 *                  user authentication
	 * @return ResponseEntity<Object> containing:
	 * 
	 *         1. HTTP 200 and a success response if the report is added
	 *         successfully.
	 *         2. HTTP 401 if the user is unauthenticated or token is
	 *         missing/invalid.
	 *         3. HTTP 503 if an unexpected error occurs.
	 * 
	 */
	@PostMapping("/favorites/add/{id}")
	public ResponseEntity<Object> addFavoritesReport(@PathVariable(value = "id") String id,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		logger.info("START -addFavoritesReport()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "addFavoritesReport()",
				request.getRequestURI(),"", "START - addFavoritesReport()");
		try {
			// Get user ID from auth token
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("DEBUG", requestId, 0, 0, loginUser, "addFavoritesReport()",
						request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
				return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
			}

			// Decode '__SLASH__' back to '/'
			String decodedId = id.replace("__SLASH__", "/");
			logger.info("Adding report to userId: {}", loginUser);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "addFavoritesReport()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "Adding report " + decodedId + " to userId:" + loginUser);
			userReportService.saveUserReport(loginUser.toUpperCase(), decodedId);

			// Return success response
			final Map<String, Object> successResponse = new HashMap<>();

			// Create service message with success code
			final Map<String, Object> serviceMessage = new HashMap<>();
			serviceMessage.put("returnCode", 0);
			serviceMessage.put("returnCodeDescription", "Success");
			successResponse.put("serviceMessage", serviceMessage);

			// Add success message
			successResponse.put("message", "Folder added to My Reports");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "addFavoritesReport()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - addFavoritesReport()");
			logger.info("END - addFavoritesReport()");
			return ResponseEntity.ok(successResponse);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error adding folder to My Reports: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "addFavoritesReport()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(HttpStatus.SERVICE_UNAVAILABLE.value(), "Error adding folder: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to fetch the "All Reports" form data.
	 *
	 * This method retrieves the "All Reports" form from the database, identified by
	 * the template name "AllReportsForm". The content is converted from binary
	 * format into a UTF-8 JSON string and returned. On successful data retrieval,
	 * the form data is logged with a HTTP status of 200. In case of any errors
	 * during processing, a HTTP status code of 503 is returned, and the error
	 * details are logged for traceability.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the "All
	 *         Reports" form or an error response in case of failure.
	 */

	@GetMapping("/all/get-form")
	public ResponseEntity<String> getAllReportsForm(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		logger.info("START -getAllReportsForm()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsForm()",
				request.getRequestURI(), "", "START - getAllReportsForm()");
		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("AllReportsForm");
			for (final TblTemplates tdata : tblFilterOptionData) {
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsForm()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllReportsForm()");
			logger.info("END -getAllReportsForm()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception exc) {
			exc.printStackTrace();
			logger.error(exc.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllReportsForm()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (exc.getMessage().length() > 250) ? exc.getMessage().substring(0, 250) : exc.getMessage());
			logger.info("END -getAllReportsForm()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to fetch the JSON template for the "All Reports" table.
	 *
	 * This method retrieves the "All Reports" table template from the database,
	 * identified by the template name "AllReportsTable." The binary data stored
	 * in the database is converted into a UTF-8 JSON string and returned. On
	 * successful retrieval, a log entry with a status of 200 is recorded. If any
	 * errors occur during processing, a log entry is created, and a response with
	 * an HTTP status code of 503 is returned.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the
	 *         "All Reports" table template or an error response in case of failure.
	 */
	@GetMapping("/all/get-tabledefinition")
	public ResponseEntity<String> getAllReportsTable(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		logger.info("START -getAllReportsTable()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsTable()",
				request.getRequestURI(), "", "START - getAllReportsTable()");
		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("AllReportsTable");
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsTable()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllReportsTable()");
			logger.info("END -getAllReportsTable()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error in getAllReportsTableDefinition: {}", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllReportsTable()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END -getAllReportsTable()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * This endpoint is used to return a list of all reports and the list of actions
	 * available for each. It fetches data related to reports and performs user
	 * authentication based on the provided authorization token.
	 * 
	 * @param authToken The authorization token passed in the request header.
	 * @return A ResponseEntity containing either the list of report data with
	 *         actions, or an error response.
	 */
	@GetMapping("/all/get-tabledata")
	public ResponseEntity<Object> getAllReportsTableData(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		// Utility method to store requestId in ThreadContext for logging and downstream usage
		storeRequestId(requestId);
		logger.info("START -getAllReportsTableData()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsTableData()",
				request.getRequestURI(), "", "START - getAllReportsTableData()");
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllReportsTableData()",
						request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
				// return createErrorResponse(401, "Authentication required. Missing or invalid
				// token.");
			}
			// Get the JSON response from the service
			final String responseJson = reportService.getAllReportsDataWithDynamicActions("ALLREPORTS", authToken);

			// Parse the response to check for errors
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllReportsTableData()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllReportsTableData()");
			logger.info("END -getAllReportsTableData()");
			return processReportResponse(responseJson, requestId, loginUser);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error in All Reports Table data processing: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllReportsTableData()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END -getAllReportsTableData()");
			return HVWException.createErrorResponseEntity(e);
		}
	}

	/** END OF REPORTS **/

	/**
	 * Helper method to process report response JSON and determine appropriate HTTP
	 * status code
	 * 
	 * @param responseJson The JSON response string to process
	 * @param requestId
	 * @return ResponseEntity with appropriate status code based on response content
	 */
	ResponseEntity<Object> processReportResponse(final String responseJson, int requestId, String loginUser) {
		try {
			final ObjectMapper objectMapper = new ObjectMapper();
			final JsonNode rootNode = objectMapper.readTree(responseJson);

			// Only check for errors if root is a JSON object (not array)
			if (rootNode.isObject()) {
				final JsonNode serviceMessage = rootNode.get("serviceMessage");

				if (serviceMessage != null && serviceMessage.has("returnCode")) {
					int returnCode = serviceMessage.get("returnCode").asInt();

					if (returnCode != 0) {
						HttpStatus status = switch (returnCode) {
							case 400 -> HttpStatus.BAD_REQUEST;
							case 401 -> HttpStatus.UNAUTHORIZED;
							case 403 -> HttpStatus.FORBIDDEN;
							case 404 -> HttpStatus.NOT_FOUND;
							default -> HttpStatus.SERVICE_UNAVAILABLE;
						};

						loggerService.log("DEBUG", requestId, 0, 0, loginUser,
								"processReportResponse()", "", String.valueOf(returnCode), "serviceMessage");

						return ResponseEntity.status(status).body(responseJson);
					}
				}
			}

			// No error detected – return success
			return ResponseEntity.ok(responseJson);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error parsing report response JSON: {}", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "processReportResponse()", "",
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());

			// Return raw response (useful in case JSON is partially valid or unexpected)
			return HVWException.createErrorResponseEntity(e);

		}
	}

	/**
	 * Helper method to create standardized error responses
	 */
	private ResponseEntity<Object> createErrorResponse(final int returnCode, final String description) {
		return HVWException.createErrorResponseEntity(returnCode, description);
	}

	// Utility method to store requestId in ThreadContext for logging and downstream usage
	private void storeRequestId(Integer requestId) {
		if (requestId != null) {
			org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
		}
	}
}
