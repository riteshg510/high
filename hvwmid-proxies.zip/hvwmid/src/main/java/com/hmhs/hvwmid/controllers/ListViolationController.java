package com.hmhs.hvwmid.controllers;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListViolationService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * ImagesController handles image-related operations.
 * Provides endpoints for image listing, viewing, downloading, and copying.
 */
@RestController
@RequestMapping("${controller.path.image}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ListViolationController {

    private HttpServletRequest request;
    private static final Logger logger = LogManager.getLogger(ListViolationController.class);
    private final ListViolationService service;
    private String loginUser = HVWConstants.UID;
    private LoggerService loggerService;

    public ListViolationController(ListViolationService service, LoggerService loggerService,
            HttpServletRequest request) {
        this.service = service;
        this.request = request;
        this.loggerService = loggerService;
    }

    // Utility method to store requestId in ThreadContext for logging and downstream
    // usage
    private void storeRequestId(Integer requestId) {
        org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
    }

    @GetMapping("/listviolation")
    public ResponseEntity<Object> filter(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - listviolation()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "filter() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - filter()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

        try{
            ResponseEntity<Object> response = service.filter(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "filter() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - filter()");
            logger.info("END - listviolation()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "filter()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - filter()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

}
