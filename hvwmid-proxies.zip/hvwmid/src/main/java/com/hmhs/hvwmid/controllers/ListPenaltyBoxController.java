package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.ListPenaltyBoxService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * ImagesController handles image-related operations.
 * Provides endpoints for image listing, viewing, downloading, and copying.
 */
@RestController
@RequestMapping("${controller.path.image}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ListPenaltyBoxController {

    private HttpServletRequest request;
    private static final Logger logger = LogManager.getLogger(ListPenaltyBoxController.class);
    private final ListPenaltyBoxService service;
    private String loginUser = HVWConstants.UID;
    private LoggerService loggerService;

    public ListPenaltyBoxController(ListPenaltyBoxService service, LoggerService loggerService, HttpServletRequest request) {
        this.service = service;
        this.request = request;
        this.loggerService = loggerService;
    }

    // Utility method to store requestId in ThreadContext for logging and downstream usage
    private void storeRequestId(Integer requestId) {
        org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
    }

    @GetMapping("/listpenaltybox")
    public ResponseEntity<Object> getAll(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = false) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - get listpenaltybox()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAll() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getAll()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

        try{
            ResponseEntity<Object> response = service.getAll(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "getAll() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - getAll()");
            logger.info("END - get listpenaltybox()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAll()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - getAll()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PostMapping("/listpenaltybox")
    public ResponseEntity<Object> create(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - add listpenaltybox()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "create() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - create()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

        try{
            ResponseEntity<Object> response = service.add(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "create() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - create()");
            logger.info("END - add listpenaltybox()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "create()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - create()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @DeleteMapping("/listpenaltybox")
    public ResponseEntity<Object> delete(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - delete listpenaltybox()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "delete() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - delete()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

        try{
            ResponseEntity<Object> response = service.delete(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "delete() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - delete()");
            logger.info("END - delete listpenaltybox()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "delete()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - delete()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PutMapping("/listpenaltybox/reset")
    public ResponseEntity<Object> reset(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - reset listpenaltybox()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "reset() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - reset()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

        try{
            ResponseEntity<Object> response = service.reset(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "reset() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - reset()");
            logger.info("END - reset listpenaltybox()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "reset()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - reset()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

    @PutMapping("/listpenaltybox/extend")
    public ResponseEntity<Object> extend(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - extend listpenaltybox()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "extend() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - extend()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
        try{
            ResponseEntity<Object> response = service.extend(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "extend() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - extend()");
            logger.info("END - extend listpenaltybox()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "extend()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - extend()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }
}
