package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.mapper.HoldMapper;
import com.hmhs.hvwmid.service.HoldImportService;
import com.hmhs.hvwmid.service.HoldService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("${controller.path.hold}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class HoldController {
    private static final Logger logger = LogManager.getLogger(HoldController.class);
    private final LoggerService loggerService;
    private final HttpServletRequest request;
    private final HoldService holdService;
    private final HoldImportService holdImportService;

    private String loginUser = HVWConstants.UID;

    public HoldController(LoggerService loggerService, HttpServletRequest request, HoldService holdService, HoldImportService holdImportService) {
        this.loggerService = loggerService;
        this.request = request;
        this.holdService = holdService;
        this.holdImportService = holdImportService;
    }

    @GetMapping("/client-ids")
    public ResponseEntity<Object> getClientIds(
            @RequestHeader(value = "RequestId", required = true) final int requestId,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken) {
        logger.info("START - getClientIds()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getClientIds() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getClientIds()");
        try {
            loginUser = HVWUtils.getUserIdFromJWT(authToken);
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "getClientIds()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(holdService.getClientIds());
        } catch (final HVWException e) {
            logger.error("HVWException while listing client ids: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getClientIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getClientIds()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while listing client ids: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getClientIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getClientIds()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping("/list")
    public ResponseEntity<Object> listHolds(@RequestParam final Map<String, String> otherFields,
                                            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
                                            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        logger.info("START - listHolds()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "listHolds()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(holdService.listHolds(otherFields));
        } catch (final HVWException e) {
            logger.error("HVWException while listing holds: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "listHolds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - listHolds()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while listing holds: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "listHolds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - listHolds()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping()
    public ResponseEntity<Object> createHold(
            @RequestBody final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - createHold()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "createHold()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(holdService.createHold(otherFields, loginUser));
        } catch (final HVWException e) {
            logger.error("HVWException while creating hold: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "createHold()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - createHold()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while creating hold: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "createHold()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - createHold()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PutMapping()
    public ResponseEntity<Object> updateHold(
            @RequestBody final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - updateHold()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "updateHold()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(holdService.updateHold(otherFields, loginUser));
        } catch (final HVWException e) {
            logger.error("HVWException while updating hold: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "updateHold()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - updateHold()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while updating hold: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "updateHold()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - updateHold()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @GetMapping("/{holdCode}")
    public ResponseEntity<Object> getByHoldCode(
            @PathVariable("holdCode") final Integer holdCode,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - getByHoldCode()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "getByHoldCode()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(HoldMapper.toResponse(holdService.getByHoldCode(holdCode)));
        } catch (final HVWException e) {
            logger.error("HVWException while fetching hold: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getByHoldCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getByHoldCode()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while fetching hold: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getByHoldCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getByHoldCode()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @DeleteMapping("/{holdCode}")
    public ResponseEntity<Object> deleteByHoldCode(
            @PathVariable("holdCode") final Integer holdCode,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - deleteByHoldCode()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "deleteByHoldCode()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            holdService.delete(holdCode);
            return ResponseEntity.ok().build();
        } catch (final HVWException e) {
            logger.error("HVWException while deleting hold: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteByHoldCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - deleteByHoldCode()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while deleting hold: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteByHoldCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - deleteByHoldCode()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping("/validate")
    public ResponseEntity<Object> validateHoldsExcel(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - validateHoldsExcel()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "validateHoldsExcel()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }
            Map<String, List<String>> validationResult = holdImportService.validateHoldSheet(file.getInputStream());

            return ResponseEntity.ok(validationResult);
        } catch (final HVWException e) {
            logger.error("HVWException while validating holds file: ", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "validateHoldsExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - validateHoldsExcel()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while validating holds file: ", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "validateHoldsExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - validateHoldsExcel()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping("/import")
    public ResponseEntity<Object> importHoldsExcel(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - importHoldsExcel()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "importHoldsExcel()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }
            holdImportService.importHoldExcel(file.getInputStream(), loginUser);

            return ResponseEntity.ok().build();
        } catch (final HVWException e) {
            logger.error("HVWException while importing holds file: ", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "importHoldsExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - importHoldsExcel()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while importing holds file: ", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "importHoldsExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - importHoldsExcel()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    /**
     * Helper method to create standardized error responses
     */
    private ResponseEntity<Object> createErrorResponse(final int returnCode, final String description) {
        return HVWException.createErrorResponseEntity(returnCode, description);
    }
}
