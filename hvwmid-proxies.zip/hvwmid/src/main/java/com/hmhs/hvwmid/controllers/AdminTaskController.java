package com.hmhs.hvwmid.controllers;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.service.CMODDataRefreshService;
import com.hmhs.hvwmid.service.CacheCleanupScheduler;
import com.hmhs.hvwmid.service.ImageParmDataService;
import com.hmhs.hvwmid.service.SaveXMLService;

@RestController
@RequestMapping("${controller.path.common}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminTaskController {

    private static final Logger logger = LogManager.getLogger(AdminTaskController.class);

    private final SaveXMLService saveXMLService;
    private final ImageParmDataService imageParmDataService;
    private final CacheCleanupScheduler cacheCleanupScheduler;
    private final CMODDataRefreshService cmodDataRefreshService;

    public AdminTaskController(SaveXMLService saveXMLService, ImageParmDataService imageParmDataService,
            CacheCleanupScheduler cacheCleanupScheduler, CMODDataRefreshService cmodDataRefreshService) {
        this.saveXMLService = saveXMLService;
        this.imageParmDataService = imageParmDataService;
        this.cacheCleanupScheduler = cacheCleanupScheduler;
        this.cmodDataRefreshService = cmodDataRefreshService;
    }

    @PostMapping("/admin/export-xml")
    public ResponseEntity<Map<String, Object>> exportExtendedParmDataToXML() {

        try {
            saveXMLService.exportExtendedParmDataToXML();

            logger.info("AdminTaskController.exportExtendedParmDataToXML", "Successfully completed manual export");
            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Extended parameter data exported successfully"));

        } catch (RuntimeException e) {
            logger.error("Error during manual XML export for requestId: {}", e);
            logger.error("AdminTaskController.exportExtendedParmDataToXML",
                    "Error during manual export: " + e.getMessage());

            return ResponseEntity.status(503).body(Map.of(
                    "success", false,
                    "message", "Error during export: " + e.getMessage()));
        }
    }

    @PostMapping("/admin/refresh-parm-data")
    public ResponseEntity<Map<String, Object>> refreshParmData() {

        try {
            imageParmDataService.refreshParmData();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "Parameter data refreshed successfully"));

        } catch (Exception e) {
            logger.error("Error during parameter data refresh for requestId: {}", e);

            return ResponseEntity.internalServerError().body(Map.of(
                    "success", false,
                    "message", "Error during parameter refresh: " + e.getMessage()));
        }
    }

    @PostMapping("/admin/cleanup-cod-tokens")
    public ResponseEntity<Map<String, Object>> cleanupOldTokens() {

        try {
            cacheCleanupScheduler.cleanupOldTokens();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "COD tokens cleaned up successfully"));

        } catch (Exception e) {
            logger.error("Error during COD tokens cleanup for requestId", e);

            return ResponseEntity.internalServerError().body(Map.of(
                    "success", false,
                    "message", "Error during COD tokens cleanup: " + e.getMessage()));
        }
    }

    @PostMapping("/admin/cleanup-img-tokens")
    public ResponseEntity<Map<String, Object>> cleanupOldTokensImg() {

        try {
            cacheCleanupScheduler.cleanupOldTokensImg();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "IMG tokens cleaned up successfully"));

        } catch (Exception e) {
            logger.error("Error during IMG tokens cleanup", e);
            return ResponseEntity.internalServerError().body(Map.of(
                    "success", false,
                    "message", "Error during IMG tokens cleanup: " + e.getMessage()));
        }
    }

    @PostMapping("/admin/cleanup-hvw-status")
    public ResponseEntity<Map<String, Object>> cleanupOldHvwStatus() {

        try {
            cacheCleanupScheduler.cleanupOldHvwStatus();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "HVW status cleaned up successfully"));

        } catch (Exception e) {
            logger.error("Error during HVW status cleanup", e);
            return ResponseEntity.internalServerError().body(Map.of(
                    "success", false,
                    "message", "Error during HVW status cleanup: " + e.getMessage()));
        }
    }

    @PostMapping("/admin/cmodDataRefreshService")
    public ResponseEntity<Map<String, Object>> cmodDataRefreshService() {

        try {
            cmodDataRefreshService.refreshCMODData();

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "message", "CMODData refreshed successfully"));

        } catch (Exception e) {
            logger.error("Error during CMODData refresh", e);
            return ResponseEntity.internalServerError().body(Map.of(
                    "success", false,
                    "message", "Error during CMODData refresh: " + e.getMessage()));
        }
    }

}