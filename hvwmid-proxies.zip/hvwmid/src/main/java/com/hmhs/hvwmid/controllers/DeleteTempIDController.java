package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.service.DeleteTempIDService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * ImagesController handles image-related operations.
 * Provides endpoints for image listing, viewing, downloading, and copying.
 */
@RestController
@RequestMapping("${controller.path.image}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class DeleteTempIDController {

    private HttpServletRequest request;
    private static final Logger logger = LogManager.getLogger(DeleteTempIDController.class);
    private final DeleteTempIDService service;
    private String loginUser = HVWConstants.UID;
    private LoggerService loggerService;

    public DeleteTempIDController(DeleteTempIDService service, LoggerService loggerService,
                                  HttpServletRequest request) {
        this.service = service;
        this.request = request;
        this.loggerService = loggerService;
    }

    // Utility method to store requestId in ThreadContext for logging and downstream
    // usage
    private void storeRequestId(Integer requestId) {
        org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
    }

    @PostMapping("/deletetempid")
    public ResponseEntity<Object> delete(
            @RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
        storeRequestId(requestId);
        logger.info("START - deletetempid()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "delete() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - delete()");
        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
        try{
            ResponseEntity<Object> response = service.delete(otherFields, authToken);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "delete() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - delete()");
            logger.info("END - deletetempid()");
            return response;
        } catch (final Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "delete()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()), (ex.getMessage().length() > 250) ? ex.getMessage().substring(0, 250) : ex.getMessage());
            logger.info("END - delete()");
            return new ResponseEntity<>(ex.getMessage(), HttpStatus.SERVICE_UNAVAILABLE);
        }
    }

}
