package com.hmhs.hvwmid.controllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.CMODSecurityAccessResponse;
import com.hmhs.hvwmid.service.CMODSecurityService;
import com.hmhs.hvwmid.utils.HVWUtils;



/**
 * REST Controller for CMOD Security Access functionality.
 * Provides endpoints for retrieving user's CMOD security permissions and access
 * details.
 */
@RestController
@RequestMapping("${controller.path.reports}/security")
@CrossOrigin(exposedHeaders = { "Content-Disposition", "Content-Type" })
public class CMODSecurityController {

    private static final Logger logger = LogManager.getLogger(CMODSecurityController.class);

    private final CMODSecurityService cmodSecurityService;

    public CMODSecurityController(CMODSecurityService cmodSecurityService) {
        this.cmodSecurityService = cmodSecurityService;
    }

    /**
     * Retrieves CMOD security access information for the authenticated user.
     * 
     * @param authorization JWT token for user authentication
     * @param requestId     Request correlation ID for tracking
     * @return CMODSecurityAccessResponse containing user's folder permissions and
     *         access details
     * @throws HVWException if security access retrieval fails
     */
    @GetMapping("/cmod-access")
    public ResponseEntity<CMODSecurityAccessResponse> getCMODSecurityAccess(
            @RequestParam(required = false, defaultValue = "") String cmodFolderName,
            @RequestHeader(value = HVWConstants.AUTHORIZATION, required = true) String authorization,
            @RequestHeader(value = HVWConstants.REQUEST_ID, required = false) Integer requestId) {

        logger.info("CMOD Security Access request received for user");
        logger.info("Request ID: {}", requestId);

        try {
            // Extract user ID from JWT token
            String userId = HVWUtils.getUserIdFromJWT(authorization);

            // Set request correlation ID for logging
            if (requestId != null) {
                storeRequestId(requestId);
            }

            // Retrieve CMOD security access details
            CMODSecurityAccessResponse response = cmodSecurityService.getCMODSecurityAccess(userId, cmodFolderName);

            if (!cmodFolderName.isEmpty())
                response.setCmodFolderNavigation(true);

            logger.info("CMOD Security Access retrieved successfully for user: {}", userId);

            return ResponseEntity.ok(response);

        } catch (HVWException e) {
            logger.error("HVW Exception occurred while retrieving CMOD security access: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("Unexpected error occurred while retrieving CMOD security access", e);
            throw new HVWException(500, "Failed to retrieve CMOD security access: " + e.getMessage(),
                    "CMODSecurityController");
        }
    }

    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }
}