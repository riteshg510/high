package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.mapper.PolicyMapper;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.PolicyImportService;
import com.hmhs.hvwmid.service.PolicyService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("${controller.path.policy}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class PolicyController {
    private static final Logger logger = LogManager.getLogger(PolicyController.class);
    private final PolicyService policyService;
    private final LoggerService loggerService;
    private final HttpServletRequest request;
    private final PolicyImportService policyImportService;
    private String loginUser = HVWConstants.UID;

    public PolicyController(PolicyService policyService, LoggerService loggerService, HttpServletRequest request, PolicyImportService policyImportService) {
        this.policyService = policyService;
        this.loggerService = loggerService;
        this.request = request;
        this.policyImportService = policyImportService;
    }

    @GetMapping("/client-ids")
    public ResponseEntity<Object> getClientIds(
            @RequestHeader(value = "RequestId", required = true) final int requestId,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        logger.info("START - getClientIds()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getClientIds() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getClientIds()");
        try {
            loginUser = HVWUtils.getUserIdFromJWT(authToken);
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "getClientIds()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            if (HVWUtils.isIsNoserviceEnv()) {
                return ResponseEntity.ok(policyService.getNoServiceClientIds());
            }
            Map<String, String> bpdIds = HVWUtils.extractBpdIds(authToken);
            if (bpdIds.isEmpty()) {
                loggerService.log("INFO", requestId, 0, 0, loginUser, "getClientIds()", request.getRequestURI(),
                        String.valueOf(HttpStatus.OK.value()), "BPD IDs not found. Returning client ids.");
                return ResponseEntity.ok(policyService.getNoServiceClientIds());
            }
            loggerService.log("INFO", requestId, 0, 0, loginUser, "getClientIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "BPD IDs retrieed. ");
            return ResponseEntity.ok(policyService.transformMapToPickListItems(bpdIds));

        } catch (final HVWException e) {
            logger.error("HVWException while fetching client ids: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getClientIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getClientIds()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while fetching client ids: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getClientIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getClientIds()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @GetMapping("/policy-type-ids")
    public ResponseEntity<Object> getPolicyTypeIds(
            @RequestHeader(value = "RequestId", required = true) final int requestId,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        logger.info("START - getPolicyTypeIds()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getPolicyTypeIds() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getPolicyTypeIds()");
        try {
            loginUser = HVWUtils.getUserIdFromJWT(authToken);
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "getPolicyTypeIds()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(policyService.getPolicyTypeKeys());

        } catch (final HVWException e) {
            logger.error("HVWException while fetching client ids: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPolicyTypeIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getPolicyTypeIds()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while fetching client ids: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPolicyTypeIds()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getPolicyTypeIds()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }


    @PostMapping("/list")
    public ResponseEntity<Object> listPolicies(@RequestBody final Map<String, String> otherFields,
                                               @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                               @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        logger.info("START - listPolicies()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "listPolicies()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(policyService.listPolicies(otherFields));
        } catch (final HVWException e) {
            logger.error("HVWException while listing policies: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "listPolicies()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - listPolicies()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while listing policies: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "listPolicies()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - listPolicies()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping()
    public ResponseEntity<Object> createPolicy(
            @RequestBody final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - createPolicy()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "createPolicy()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(policyService.createPolicy(otherFields, loginUser));
        } catch (final HVWException e) {
            logger.error("HVWException while creating policy: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "createPolicy()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - createPolicy()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while creating policy: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "createPolicy()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - createPolicy()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PutMapping()
    public ResponseEntity<Object> updatePolicy(
            @RequestBody final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - updatePolicy()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {

            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "updatePolicy()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(policyService.updatePolicy(otherFields, loginUser));
        } catch (final HVWException e) {
            logger.error("HVWException while updating policy: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "updatePolicy()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - updatePolicy()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while updating policy: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "updatePolicy()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - updatePolicy()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @GetMapping("/{policyCode}")
    public ResponseEntity<Object> getByPolicyCode(
            @PathVariable Integer policyCode,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - getByPolicyCode()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);

        try {

            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "getByPolicyCode()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }

            return ResponseEntity.ok(PolicyMapper.toResponse(policyService.getByPolicyCode(policyCode)));
        } catch (final HVWException e) {
            logger.error("HVWException while fetching policy: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getByPolicyCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getByPolicyCode()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while fetching policy: ", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getByPolicyCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getByPolicyCode()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @DeleteMapping("/{policyCode}")
    public ResponseEntity<Object> deleteByPolicyCode(
            @PathVariable Integer policyCode,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - deleteByPolicyCode()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "deleteByPolicyCode()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }
            policyService.delete(policyCode);

            return ResponseEntity.ok().build();
        } catch (final HVWException e) {
            logger.error("HVWException while deleting policy code: ", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteByPolicyCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - deleteByPolicyCode()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while deleting policy code: ", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteByPolicyCode()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - deleteByPolicyCode()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping("/validate")
    public ResponseEntity<Object> validatePolicyExcel(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - validatePolicyExcel()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "validatePolicyExcel()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }
            Map<String, List<String>> validationResult = policyImportService.validatePolicySheet(file.getInputStream());

            return ResponseEntity.ok(validationResult);
        } catch (final HVWException e) {
            logger.error("HVWException while validating policy file: ", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "validatePolicyExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - validatePolicyExcel()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while validating policy file: ", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "validatePolicyExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - validatePolicyExcel()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    @PostMapping("/import")
    public ResponseEntity<Object> importPolicyExcel(
            @RequestParam("file") MultipartFile file,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId
    ) {
        logger.info("START - importPolicyExcel()");

        loginUser = HVWUtils.getUserIdFromJWT(authToken);
        try {
            if (loginUser == null || loginUser.isEmpty()) {
                loggerService.log("DEBUG", requestId, 0, 0, loginUser, "importPolicyExcel()",
                        request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()), "Authentication required. Missing or invalid token.");
                return createErrorResponse(HttpStatus.UNAUTHORIZED.value(), "Authentication required. Missing or invalid token.");
            }
            policyImportService.importPolicyExcel(file.getInputStream(), loginUser);

            return ResponseEntity.ok().build();
        } catch (final HVWException e) {
            logger.error("HVWException while importing policy file: ", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "importPolicyExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - importPolicyExcel()");
            return ResponseEntity.badRequest()
                    .body(new ByteArrayResource(e.getMessage().getBytes()));
        } catch (final Exception e) {
            logger.error("Unexpected error while importing policy file: ", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "importPolicyExcel()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - importPolicyExcel()");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).
                    body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
        }
    }

    /**
     * Helper method to create standardized error responses
     */
    private ResponseEntity<Object> createErrorResponse(final int returnCode, final String description) {
        return HVWException.createErrorResponseEntity(returnCode, description);
    }

}
