package com.hmhs.hvwmid.controllers;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.service.AppDataService;

import jakarta.servlet.http.HttpServletRequest;

/**
 * RedirectURLController handles URL-related operations.
 * It provides endpoints for redirecting specific URLs to target URLs based on
 * defined conditions.
 * 
 * @author Ramanjaneyulu Manam on Sep 11, 2025
 */
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class RedirectURLController {

    private static final Logger logger = LogManager.getLogger(RedirectURLController.class);

    @Autowired
    AppDataService service;

    @Autowired
    HttpServletRequest request;

    @Value("${form.showImage.id}")
    private String showImageFormId;

    @Value("${form.viewImage.id}")
    private String viewImageFormId;

    @Value("${form.viewImage.navigatePathIMG}")
    private String viewImageNavigatePath;

    /**
     * Handles image-related redirection requests from multiple URL mappings.
     * <p>
     * This method processes incoming query parameters to determine whether to
     * redirect
     * the user to a "view image" page or a "show image" page. If the
     * {@code foldtkn} parameter is missing, it attempts to derive it from the
     * {@code imagekey}.
     * If neither is available or valid, it redirects to the view page with a
     * default result. Otherwise, it redirects to the show image page with the
     * complete parameter
     * set.
     * </p>
     *
     * @param allParams a map of all query parameters passed in the request
     * @return a {@link RedirectView} pointing to either the view or show image page
     */
    @GetMapping({
            "/ImgUMM", "/servlet/ImgUMM", "/ImgUMM6", "/servlet/ImgUMM6",
            "/ImgCSDEmail", "/servlet/ImgCSDEmail", "/ImgSalesforce", "/servlet/ImgSalesforce",
            "/ImgB2BGui", "/servlet/ImgB2BGui", "/ImgExpenseRpt", "/servlet/ImgExpenseRpt"
    })
    public Object redirectToShowOrView(@RequestParam Map<String, String> allParams) {
        logger.info("Received request URI is: {}", request.getRequestURI());
        logger.info("Received redirect request with parameters: {}", allParams);

        // Remove undefined values
        allParams.entrySet().removeIf(e -> "undefined".equals(e.getValue()));
        logger.debug("Filtered parameters: {}", allParams);

        // Extract parameters
        String foldtkn = allParams.getOrDefault("foldtkn", "").trim();
        String imagekey = allParams.getOrDefault("imagekey", "").trim();

        logger.debug("foldtkn: '{}', imagekey: '{}'", foldtkn, imagekey);

        if (foldtkn.isEmpty()) {
            if (!imagekey.isEmpty() && imagekey.length() >= 30) {
                foldtkn = imagekey.substring(4, 30);
                allParams.put("foldtkn", foldtkn);
                logger.info("Derived foldtkn from imagekey: {}", foldtkn);
            } else {
                allParams.put("results", "true");
                StringBuilder viewUrl = new StringBuilder(viewImageNavigatePath + viewImageFormId + "?");
                viewUrl.append(buildQueryString(allParams));
                logger.warn("Missing foldtkn and invalid imagekey. Redirecting to view page: {}", viewUrl);
                // Return as JSON object
                return Map.of("url", viewUrl.toString());
            }
        }

        StringBuilder showUrl = new StringBuilder("pages/image-show/" + showImageFormId + "?");
        showUrl.append(buildQueryString(allParams));
        logger.info("Redirecting to show image page: {}", showUrl);
        // Return as JSON object
        return Map.of("url", showUrl.toString());
    }

    /**
     * Builds a URL-encoded query string from the provided parameter map.
     *
     * @param params the map of query parameters
     * @return a URL-encoded query string suitable for appending to a redirect URL
     */
    private String buildQueryString(Map<String, String> params) {
        String queryString = params.entrySet().stream()
                .map(entry -> entry.getKey() + "=" + entry.getValue())
                .collect(Collectors.joining("&"));
        logger.debug("Built query string: {}", queryString);
        return queryString;
    }

    /**
     * Handles redirection logic for the {@code /ImgSessionMgr} endpoint.
     * <p>
     * This method supports both traditional query parameters and a JSON-based
     * {@code queryParams} payload from newer frontends. Based on the presence and
     * values of parameters such as {@code action} and {@code template}, it
     * dynamically constructs redirect URLs for search pages or CMOD report views.
     * </p>
     *
     * <ul>
     * <li>If {@code queryParams} is present, it is parsed as a JSON object to
     * extract parameters.</li>
     * <li>If {@code template} is present and {@code action=listobj2a}, a form-based
     * redirect URL is constructed.</li>
     * <li>If {@code action=listrptCMOD}, a CMOD report URL is built using date
     * filters and field mappings.</li>
     * <li>If none of the above conditions are met, no redirect is performed and
     * {@code null} is returned.</li>
     * </ul>
     *
     * @param allParams a map of all query parameters received in the request,
     *                  including optional JSON payloads
     * @return a {@link RedirectView} for browser redirection, a {@link String} URL
     *         for JSON-based clients, or a {@link Map} containing a single report
     *         URL, depending on the request context
     */
    @GetMapping("/ImgSessionMgr")
    public Object redirectToSearch(@RequestParam Map<String, String> allParams) {
        logger.debug("/ImgSessionMgr called with params: {}", allParams);
        Map<String, String> queryParams = new java.util.HashMap<>();
        // Support new frontend: if 'queryParams' param is present, parse it as JSON
        if (allParams.containsKey("queryParams")) {
            try {
                String json = allParams.get("queryParams");
                logger.debug("Parsing queryParams JSON: {}", json);
                // Use Jackson ObjectMapper for parsing
                com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
                queryParams = mapper.readValue(json,
                        new com.fasterxml.jackson.core.type.TypeReference<java.util.HashMap<String, String>>() {
                        });
                logger.debug("Parsed queryParams: {}", queryParams);
            } catch (Exception e) {
                logger.error("Failed to parse queryParams JSON: {}", allParams.get("queryParams"), e);
            }
        } else {
            queryParams.putAll(allParams);
        }
        // Take urlAction before everything
        String urlAction = queryParams.getOrDefault("action", "");
        logger.debug("urlAction: {}", urlAction);
        // Template-based redirect, only if action=listobj2a
        final boolean redirect = queryParams.containsKey("template");
        final StringBuilder redirectUrl = new StringBuilder("/search");
        if (!queryParams.isEmpty() && redirect) {
            logger.debug("Template-based redirect triggered");
            redirectUrl.append("?");
            queryParams.forEach((key, value) -> {
                logger.debug("Processing param: {} = {}", key, value);
                if (key.equalsIgnoreCase("template")) {
                    final List<TblForms> form = service.getFormIdByFileName(value.replaceFirst("[.][^.]+$", ""));
                    logger.debug("Form lookup for template '{}': {}", value, form);
                    if (!form.isEmpty()) {
                        if (value.toLowerCase().contains("work"))
                            redirectUrl.replace(0, 7, HVWConstants.WORKFLOW + form.get(0).getFormId());
                        else if (value.toLowerCase().contains("scan"))
                            redirectUrl.replace(0, 7, HVWConstants.CABINETSCAN + form.get(0).getFormId());
                        else
                            redirectUrl.replace(0, 7, "pages/search/" + form.get(0).getFormId());
                    } else {
                        redirectUrl.append(key.replace("ImgSessionMgr?", "")).append("=").append(value).append("&");
                    }
                } else
                    redirectUrl.append(key).append("=").append(value).append("&");
            });
            // Remove the last "&"
            redirectUrl.setLength(redirectUrl.length() - 1);
            logger.debug("Final redirectUrl: {}", redirectUrl);
            // Return as JSON object
            return Map.of("url", redirectUrl.toString());
        }

        // Now check for listrptCMOD
        if ("listrptCMOD".equalsIgnoreCase(urlAction)) {
            logger.debug("listrptCMOD redirect triggered");
            String cmodFolderName = queryParams.getOrDefault("cmodFolderName", "");
            StringBuilder singleReportUrl = new StringBuilder("/" + HVWConstants.SINGLEREPORT);
            singleReportUrl.append(cmodFolderName);
            boolean first = true;
            // Prepare field mapping and filter
            Map<String, String> fieldMap = new java.util.HashMap<>();
            String begindate = null, enddate = null;
            for (Map.Entry<String, String> entry : queryParams.entrySet()) {
                String key = entry.getKey();
                String value = entry.getValue();
                logger.debug("Processing param: {} = {}", key, value);
                if ("cmodFolderName".equalsIgnoreCase(key) || "action".equalsIgnoreCase(key))
                    continue;
                if (key.equalsIgnoreCase("begindate")) {
                    begindate = formatDateToISO(value);
                    logger.debug("Parsed begindate: {}", begindate);
                    continue;
                }
                if (key.equalsIgnoreCase("enddate")) {
                    enddate = formatDateToISO(value);
                    logger.debug("Parsed enddate: {}", enddate);
                    continue;
                }
                if (key.toLowerCase().startsWith("field")) {
                    fieldMap.put(key, value);
                    logger.debug("Added to fieldMap: {} = {}", key, value);
                }
            }
            // Now resolve field values
            Map<String, String> resolvedFields = new java.util.HashMap<>();
            for (Map.Entry<String, String> fieldEntry : fieldMap.entrySet()) {
                String fieldKey = fieldEntry.getKey();
                String fieldName = fieldEntry.getValue();
                String fieldValue = queryParams.get(fieldName);
                logger.debug("Resolving field: {} (name: {}) = {}", fieldKey, fieldName, fieldValue);
                if (fieldValue != null) {
                    resolvedFields.put(fieldKey, fieldValue);
                }
            }
            // Build URL
            if (first && (begindate != null || enddate != null || !resolvedFields.isEmpty())) {
                singleReportUrl.append("?");
                first = false;
            }
            boolean added = false;
            if (begindate != null) {
                singleReportUrl.append("begindate=").append(begindate);
                added = true;
            }
            if (enddate != null) {
                if (added)
                    singleReportUrl.append("&");
                singleReportUrl.append("enddate=").append(enddate);
                added = true;
            }
            for (Map.Entry<String, String> resolved : resolvedFields.entrySet()) {
                if (added)
                    singleReportUrl.append("&");
                singleReportUrl.append(resolved.getKey()).append("=").append(resolved.getValue());
                added = true;
            }
            // Add action and autoshow if present
            if (queryParams.containsKey("action")) {
                if (added)
                    singleReportUrl.append("&");
                singleReportUrl.append("action=").append(queryParams.get("action"));
                added = true;
            }
            if (queryParams.containsKey("autoshow")) {
                if (added)
                    singleReportUrl.append("&");
                singleReportUrl.append("autoshow=").append(queryParams.get("autoshow"));
            }
            if (queryParams.containsKey("srchop")) {
                if (added)
                    singleReportUrl.append("&");
                singleReportUrl.append("srchop=").append(queryParams.get("srchop"));
            }
            logger.debug("Final singleReportUrl: {}", singleReportUrl);
            // Return as JSON object
            return Map.of("url", singleReportUrl.toString());
        }

        // Default: no redirect
        logger.debug("No redirect performed for /ImgSessionMgr");
        return null;
    }

    /**
     * Converts a date string from {@code mm/dd/yy} or {@code mm/dd/yyyy} format to
     * ISO format {@code yyyy-MM-dd}.
     * <p>
     * If the year is provided in two digits (e.g., {@code 23}), it is assumed to be
     * in the 21st century and prefixed with {@code 20}. If the input is
     * {@code null} or not in the expected format, the original string is returned
     * as a fallback.
     * </p>
     *
     * @param date the input date string in {@code mm/dd/yy} or {@code mm/dd/yyyy}
     *             format
     * @return the formatted date string in {@code yyyy-MM-dd} format, or the
     *         original input if parsing fails
     */
    private String formatDateToISO(String date) {
        if (date == null)
            return null;
        String[] parts = date.split("/");
        if (parts.length == 3) {
            String mm = parts[0];
            String dd = parts[1];
            String yyyy = parts[2];
            if (yyyy.length() == 2) {
                yyyy = "20" + yyyy;
            }
            return yyyy + "-" + String.format("%02d", Integer.parseInt(mm)) + "-"
                    + String.format("%02d", Integer.parseInt(dd));
        }
        // fallback: just return original
        return date;
    }

}
