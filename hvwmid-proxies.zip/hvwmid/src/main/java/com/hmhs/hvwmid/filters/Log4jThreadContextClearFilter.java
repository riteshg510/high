package com.hmhs.hvwmid.filters;

import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import org.springframework.stereotype.Component;
import java.io.IOException;

/**
 * Servlet filter to clear Log4j ThreadContext (MDC) after every request.
 * Prevents thread-local data leakage between requests in thread pools.
 */
@Component
public class Log4jThreadContextClearFilter implements Filter {
    private static final Logger logger = LogManager.getLogger(Log4jThreadContextClearFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        try {
            chain.doFilter(request, response);
        } finally {
            ThreadContext.clearAll();
            logger.debug("Log4j ThreadContext cleared for thread: {}", Thread.currentThread().getName());
        }
    }
}
