package com.hmhs.hvwmid.controllers;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.layouts.CabinetsAndActions;
import com.hmhs.hvwmid.model.ApiSection;
import com.hmhs.hvwmid.model.Cabinets;
import com.hmhs.hvwmid.model.TableDefinition;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.UserCabinetService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * CabinetsController handles cabinet-related operations.
 * Provides endpoints for cabinet management, favorites, and cabinet data
 * retrieval.
 *
 * @author Ramanjaneyulu Manam on April 18, 2024
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("${controller.path.cabinets}")
@RestController
public class CabinetsController {

	@Autowired
	HttpServletRequest request;

	@Autowired
	CabinetsAndActions cabinetsActions;

	private static final Logger logger = LogManager.getLogger(CabinetsController.class);

	// Hold for local use
	private String loginUser = HVWConstants.UID.toUpperCase();

	// Constants
	private final String delete = HVWConstants.DELETE;
	private final String actionType = HVWConstants.ACTYPE;

	@Autowired
	AppDataService service;

	@Autowired
	UserCabinetService userCabinetService;

	@Autowired
	LoggerService loggerService;

	/** START OF CABINETS **/

	/**
	 * Endpoint to fetch the "My Cabinets" form data.
	 *
	 * This method retrieves the "My Cabinets" form from the database, processes it,
	 * and returns the form content in JSON format. The form template is identified
	 * by its name, "MyCabinetsForm." Successful retrieval is logged, and in case of
	 * any errors during the process, they are logged and an appropriate response
	 * with HTTP status code is returned.
	 *
	 * @return ResponseEntity<String> containing the form content in JSON format
	 *         or an error response in case of failure.
	 */
	@GetMapping("/favorites/get-form")
	public ResponseEntity<String> getUserCabinetsForm(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

		storeRequestId(requestId);
		logger.info("START - getUserCabinetsForm()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getUserCabinetsForm()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getUserCabinetsForm()");
		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("MyCabinetsForm");
			for (final TblTemplates tdata : tblFilterOptionData) {
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getUserCabinetsForm()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getUserCabinetsForm()");
			logger.info("END - getUserCabinetsForm()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception en) {
			en.printStackTrace();
			logger.error(en.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getUserCabinetsForm()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(en.getMessage().length() > 250) ? en.getMessage().substring(0, 250) : en.getMessage());
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to fetch the JSON template for the "My Cabinets" table.
	 *
	 * This method retrieves the "My Cabinets" table template from the database
	 * identified by the template name "MyCabinetsTable." It converts the stored
	 * binary content into a UTF-8 JSON string and returns it. If the operation
	 * is successful, the table definition is returned with a HTTP status code of
	 * 200. In the event of any errors, a HTTP status code of 503 is returned,
	 * and the error details are logged for debugging purposes.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the
	 *         Cabinets table template or an error response in case of failure.
	 */
	@GetMapping("/favorites/get-tabledefinition")
	public ResponseEntity<String> getUserCabinetsTable(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

		storeRequestId(requestId);
		logger.info("START - getUserCabinetsTable()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getUserCabinetsTable()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getUserCabinetsTable()");
		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("MyCabinetsTable");
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getUserCabinetsTable()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getUserCabinetsTable()");
			logger.info("END - getUserCabinetsTable()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception et) {
			et.printStackTrace();
			logger.error(et.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getUserCabinetsTable()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(et.getMessage().length() > 250) ? et.getMessage().substring(0, 250) : et.getMessage());
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to retrieve a list of cabinets and their associated actions for the
	 * current user, utilizing an authorization token for user validation.
	 *
	 * This method fetches a list of the user's cabinets and the corresponding
	 * actions for each cabinet from the database. It uses the 'CabinetsAndActions'
	 * service to process and retrieve the required data. The authorization token is
	 * validated to ensure the request is associated with a valid user.
	 * On successful retrieval, the information is logged with a status code of 200.
	 * Any errors during the process are logged for debugging and traceability.
	 *
	 * @param authToken The authorization token for validating the user's identity
	 *                  (optional).
	 * @return ResponseEntity<List<Cabinets>> containing the list of cabinets and
	 *         their associated actions or an error response in case of failure.
	 */
	@GetMapping("/favorites/get-tabledata")
	public ResponseEntity<List<Cabinets>> getMyCabinetsTableData(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {

		storeRequestId(requestId);
		logger.info("START - getMyCabinetsTableData()");
		loggerService.log("INFO", requestId, 0, 0, loginUser.toUpperCase(), "getMyCabinetsTableData()",
				request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getMyCabinetsTableData()");
		List<Cabinets> myCabinets;
		cabinetsActions.setService(service);
		myCabinets = cabinetsActions.getUserCabinetsAndActions(userCabinetService, authToken);
		loggerService.log("INFO", requestId, 0, 0, HVWUtils.getUserIdFromJWT(authToken), "getMyCabinetsTableData()",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getMyCabinetsTableData()");
		logger.info("END - getMyCabinetsTableData()");
		return new ResponseEntity<>(myCabinets, HttpStatus.OK);
	}

	/**
	 * Endpoint to remove a cabinet from the user's "My Cabinets" list.
	 *
	 * This method removes a specific cabinet from the user's list using the cabinet
	 * ID. It validates the user identity through an authorization token. If the
	 * token is invalid or missing, an authentication error response is returned. On
	 * successful removal, a success message and relevant details are returned in
	 * JSON format. Errors encountered during the process are logged for debugging
	 * and traceability.
	 *
	 * @param id        The unique identifier of the cabinet to be removed.
	 * @param authToken The authorization token for validating the user's identity
	 *                  (optional).
	 * @return ResponseEntity<Object> containing the success response or an error
	 *         message if the operation fails.
	 */
	@PostMapping("/favorites/remove/{id}")
	public ResponseEntity<Object> removeFavoritesCabinet(@PathVariable(value = "id") final String id,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);
		logger.info("START - removeFavoritesCabinet()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "removeFavoritesCabinet()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - removeFavoritesCabinet");
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "removeFavoritesCabinet()",
						request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()),
						"END - removeFavoritesCabinet");
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}

			logger.info("Removing cabinet from userId: {}", loginUser);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "removeFavoritesCabinet()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()),
					"Removing cabinet " + id + " from My Cabinets, user " + loginUser);
			userCabinetService.removeCabinetForUser(loginUser.toUpperCase(), id);

			// Return success response
			final Map<String, Object> successResponse = new HashMap<>();

			// Create service message with success code
			final Map<String, Object> serviceMessage = new HashMap<>();
			serviceMessage.put("returnCode", 0);
			serviceMessage.put("returnCodeDescription", "Success");
			successResponse.put("serviceMessage", serviceMessage);

			// Add success message and action type
			successResponse.put("message", "Cabinet removed from My Cabinets");
			successResponse.put(actionType, delete);
			logger.info("END - removeFavoritesCabinet()");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "removeFavoritesCabinet()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - removeFavoritesCabinet()");
			return ResponseEntity.ok(successResponse);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error removing cabinet from My Cabinets: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "removeFavoritesCabinet()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(HttpStatus.SERVICE_UNAVAILABLE.value(),
					"Error removing cabinet: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to add a cabinet to the user's "My Cabinets" list.
	 *
	 * This method facilitates the addition of a specific cabinet to the user's "My
	 * Cabinets" list, identified by the cabinet ID. The user's identity is
	 * validated using the provided authorization token. If the token is invalid or
	 * missing, an authentication error response is returned. Upon successful
	 * addition, a success message and relevant details are returned in JSON format.
	 * Errors during the process are logged for debugging and traceability.
	 *
	 * @param id        The unique identifier of the cabinet to be added.
	 * @param authToken The authorization token used to validate the user's identity
	 *                  (optional).
	 * @return ResponseEntity<Object> containing a success response or an error
	 *         message if the operation fails.
	 */
	@PostMapping("/favorites/add/{id}")
	public ResponseEntity<Object> addFavoritesCabinet(@PathVariable(value = "id") final String id,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);
		logger.info("START - addFavoritesCabinet()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "addFavoritesCabinet()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - addFavoritesCabinet()");
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "addFavoritesCabinet()",
						request.getRequestURI(), String.valueOf(HttpStatus.UNAUTHORIZED.value()),
						"END - addFavoritesCabinet()");
				return createErrorResponse(401, "Authentication required. Missing or invalid token.");
			}

			logger.info("Adding cabinet to userId: {}", loginUser);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "addFavoritesCabinet()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()),
					"Adding cabinet " + id + " to MyCabinets, user " + loginUser);
			userCabinetService.addCabinetForUser(loginUser.toUpperCase(), id);

			// Return success response
			final Map<String, Object> successResponse = new HashMap<>();

			// Create service message with success code
			final Map<String, Object> serviceMessage = new HashMap<>();
			serviceMessage.put("returnCode", 0);
			serviceMessage.put("returnCodeDescription", "Success");
			successResponse.put("serviceMessage", serviceMessage);

			// Add success message
			successResponse.put("message", "Cabinet added to My Cabinets");
			logger.info("END - addFavoritesCabinet()");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "addFavoritesCabinet()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - addFavoritesCabinet()");
			return ResponseEntity.ok(successResponse);

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error("Error adding cabinet to My Cabinets: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "addFavoritesCabinet()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(HttpStatus.SERVICE_UNAVAILABLE.value(),
					"Error adding cabinet: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to fetch the "All Cabinets" form data.
	 *
	 * This method retrieves the "All Cabinets" form from the database, identified
	 * by the template name "AllCabinetsForm". The content is converted from binary
	 * format into a UTF-8 JSON string and returned. On successful data retrieval,
	 * the form data is logged with a HTTP status of 200. In case of any errors
	 * during processing, a HTTP status code of 503 is returned, and the error
	 * details are logged for traceability.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the "All
	 *         Cabinets" form or an error response in case of failure.
	 */
	@GetMapping("/all/get-form")
	public ResponseEntity<String> getAllCabinetsForm(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

		storeRequestId(requestId);
		logger.info("START - getAllCabinetsForm()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCabinetsForm()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getAllCabinetsForm()");
		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("AllCabinetsForm");
			for (final TblTemplates tdata : tblFilterOptionData) {
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);
			}
			logger.info("END - getAllCabinetsForm()");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCabinetsForm()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllCabinetsForm()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception exce) {
			exce.printStackTrace();
			logger.error(exce.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllCabinetsForm()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(exce.getMessage().length() > 250) ? exce.getMessage().substring(0, 250) : exce.getMessage());
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to fetch the JSON template for the "All Cabinets" table.
	 *
	 * This method retrieves the "All Cabinets" table template from the database,
	 * identified by the template name "AllCabinetsTable." The binary data stored
	 * in the database is converted into a UTF-8 JSON string and returned. On
	 * successful retrieval, a log entry with a status of 200 is recorded. If any
	 * errors occur during processing, a log entry is created, and a response with
	 * an HTTP status code of 503 is returned.
	 *
	 * @return ResponseEntity<String> containing the JSON representation of the
	 *         "All Cabinets" table template or an error response in case of
	 *         failure.
	 */
	@GetMapping("/all/get-tabledefinition")
	public ResponseEntity<String> getAllCabinetsTable(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {

		storeRequestId(requestId);
		logger.info("START - getAllCabinetsTable()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCabinetsTable()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getAllCabinetsTable()");
		String response = "";
		List<TblTemplates> tblFilterOptionData = null;
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			tblFilterOptionData = service.getTempletByName("AllCabinetsTable");
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCabinetsTable()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllCabinetsTable()");
			logger.info("END - getAllCabinetsTable()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception exp) {
			exp.printStackTrace();
			logger.error(exp.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getAllCabinetsTable()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(exp.getMessage().length() > 250) ? exp.getMessage().substring(0, 250) : exp.getMessage());
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to retrieve a list of all cabinets and their associated actions by
	 * user groups.
	 *
	 * This method fetches a comprehensive list of cabinets along with their
	 * respective actions from the database. It uses the 'CabinetsAndActions'
	 * service for processing and retrieving the data. The result is returned as a
	 * list in JSON format. On successful retrieval, an information log is
	 * generated with a status code of 200. If an error occurs during processing,
	 * appropriate logging is carried out to aid in debugging.
	 *
	 * @return ResponseEntity<List<Cabinets>> containing the list of all cabinets
	 *         and their associated actions or an error response in case of failure.
	 */
	@GetMapping("/all/get-tabledata")
	public ResponseEntity<List<Cabinets>> getAllCabinetsTableData(
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);
		logger.info("START - getAllCabinetsTableData()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCabinetsTableData()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getAllCabinetsTableData()");
		List<Cabinets> allCabinets;
		cabinetsActions.setService(service);
		allCabinets = cabinetsActions.getCabinetsAndActionsByGroup(authToken);
		loggerService.log("INFO", requestId, 0, 0, HVWUtils.getUserIdFromJWT(authToken), "getAllCabinetsTableData()",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getAllCabinetsTableData()");
		logger.info("END - getAllCabinetsTableData()");
		return new ResponseEntity<>(allCabinets, HttpStatus.OK);
	}

	/**
	 * Handles HTTP GET requests to update the date of LAST_USED_DATE for a cabinet
	 * entry in the database.
	 * 
	 * This method update LAST_USED_DATE for a cabinet when user click a cabinet
	 * action.
	 *
	 * @param id The unique identifier of the cabinet whose date needs to be
	 *           updated.
	 * @return ResponseEntity containing the update status message and HTTP status
	 *         code.
	 */
	@GetMapping("/updateDate/{id}")
	public ResponseEntity<String> updateCabinetsTable(@PathVariable(value = "id") final String id) {
		cabinetsActions.setService(service);
		logger.info("updateDate cabinet to cabinetId: {}", id);
		String response = cabinetsActions.updateCabinetsTableDate(id);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	/**
	 * This endpoint retrieves the definition of a table based on the provided table
	 * ID.
	 * It fetches the table definition from the service and returns it in the
	 * response. If an error occurs during the process, an error response is
	 * returned.
	 * 
	 * @param tableId The ID of the table whose definition is to be fetched.
	 * @return A ResponseEntity containing the TableDefinition object, or an error
	 *         response if an exception occurs.
	 */
	@PostMapping("/get-tabledefinition")
	public ResponseEntity<TableDefinition> getCabTableDefinition(
			@RequestParam final Map<String, String> otherFields,
			@RequestParam("tableId") final String tableId,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getCabTableDefinition()");

		loggerService.log("INFO", requestId, 0, 0, loginUser, "getCabTableDefinition()",
				request.getRequestURI(), "", "START - getCabTableDefinition()");

		TableDefinition response = new TableDefinition();
		final ApiSection aps = new ApiSection();
		aps.setService(service);
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			response = aps.getTableDefinition(response, tableId, otherFields);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getCabTableDefinition()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getCabTableDefinition()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception ect) {
			ect.printStackTrace();
			logger.error(ect.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getCabTableDefinition()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(ect.getMessage().length() > 250) ? ect.getMessage().substring(0, 250) : ect.getMessage());
			logger.info("END - getCabTableDefinition()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Handles HTTP POST requests to drop a workflow associated with a document.
	 * 
	 * <p>
	 * This endpoint is mapped to <code>/workflow/drop</code> and expects request
	 * parameters and headers to process the workflow drop operation. It performs
	 * logging, user authentication, sanitizes input fields, and delegates the drop
	 * operation to the <code>cabinetsActions</code> service.
	 * </p>
	 * 
	 * @param otherFields   A map of additional request parameters used in the
	 *                      workflow drop process. Entries with value "undefined"
	 *                      are removed before processing.
	 * @param documentToken A unique token identifying the document associated with
	 *                      the workflow. This is added to the
	 *                      <code>otherFields</code> map before invoking the
	 *                      service.
	 * @param requestId     A unique identifier for the request, used for logging
	 *                      and traceability.
	 * @param authToken     The JWT authentication token used to identify and
	 *                      authorize the user.
	 * 
	 * @return ResponseEntity<Object> containing the result of the workflow drop
	 *         operation.
	 *         The response is generated by the
	 *         <code>cabinetsActions.dropWorkflow</code> method.
	 *         <p>
	 *         Logging is performed at the start and end of the method execution to
	 *         capture request metadata and user context for auditing and debugging
	 *         purposes.
	 *         </p>
	 */
	@PostMapping("/workflow/drop")
	public ResponseEntity<Object> workflowDrop(
			@RequestParam Map<String, String> otherFields,
			@RequestParam("documentToken") final String documentToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);
		cabinetsActions.setService(service);
		logger.info("START - workflowDrop()");
		loginUser = HVWUtils.getUserIdFromJWT(authToken);
		loggerService.log("INFO", requestId, 0, 0, loginUser, "workflowDrop() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - workflowDrop()");
		otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
		otherFields.put("documentToken", documentToken);
		ResponseEntity<Object> response = (ResponseEntity<Object>) cabinetsActions.dropWorkflow(otherFields, authToken);
		loggerService.log("INFO", requestId, 0, 0, HVWUtils.getUserIdFromJWT(authToken), "getWorkflowDrop()",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - workflowDrop()");
		logger.info("END - getWorkflowDrop()");
		return response;
	}

	/**
	 * Handles HTTP POST requests to reroute a workflow associated with a specific
	 * document.
	 * 
	 * <p>
	 * This endpoint is mapped to <code>/workflow/reroute</code> and is used to
	 * reroute an existing
	 * workflow based on the provided parameters. It performs request logging, user
	 * authentication,
	 * input sanitization, and delegates the rerouting logic to the
	 * <code>cabinetsActions</code> service.
	 * </p>
	 * 
	 * @param otherFields   A map of additional request parameters relevant to the
	 *                      workflow rerouting.
	 *                      Entries with the value "undefined" are removed before
	 *                      processing.
	 * @param documentToken A unique token identifying the document whose workflow
	 *                      is to be rerouted.
	 *                      This token is added to the <code>otherFields</code> map.
	 * @param requestId     A unique identifier for the incoming request, used for
	 *                      logging and traceability.
	 * @param authToken     The JWT token used to authenticate and identify the user
	 *                      initiating the request.
	 * 
	 * @return ResponseEntity<Object> containing the result of the workflow reroute
	 *         operation.
	 *         The response is generated by the
	 *         <code>cabinetsActions.reRouteWorkflow</code> method.
	 * 
	 *         <p>
	 *         Extensive logging is performed at the start and end of the method to
	 *         capture request metadata,
	 *         user identity, and execution status for auditing and debugging
	 *         purposes.
	 *         </p>
	 */
	@PostMapping("/workflow/reroute")
	public ResponseEntity<Object> workflowReroute(
			@RequestParam Map<String, String> otherFields,
			@RequestParam("documentToken") final String documentToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);
		cabinetsActions.setService(service);
		logger.info("START - workflowReroute()");
		loginUser = HVWUtils.getUserIdFromJWT(authToken);
		loggerService.log("INFO", requestId, 0, 0, loginUser, "workflowReroute() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - workflowReroute()");
		otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
		otherFields.put("documentToken", documentToken);
		ResponseEntity<Object> response = cabinetsActions.reRouteWorkflow(otherFields, authToken);
		loggerService.log("INFO", requestId, 0, 0, HVWUtils.getUserIdFromJWT(authToken), "getWorkflowReroute",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - workflowReroute()");
		logger.info("END - workflowReroute()");
		return response;
	}

	/**
	 * Handles HTTP POST requests to retrieve the next unit of work for a user in
	 * the workflow system.
	 * <p>
	 * This method performs the following operations:
	 * <ul>
	 * <li>Stores the incoming request ID for tracking purposes.</li>
	 * <li>Initializes the service layer for cabinet actions.</li>
	 * <li>Extracts the user ID from the JWT authorization token.</li>
	 * <li>Logs the start of the workflow reroute operation.</li>
	 * <li>Sanitizes the input parameters by removing entries with "undefined"
	 * values.</li>
	 * <li>Delegates to {@code cabinetsActions.getNewWork()} to fetch the next work
	 * item.</li>
	 * <li>Logs the completion of the workflow reroute operation.</li>
	 * </ul>
	 *
	 * @param otherFields a map of additional request parameters used to determine
	 *                    the next work item
	 * @param requestId   a unique identifier for the request, used for logging and
	 *                    traceability
	 * @param authToken   the JWT token used to authenticate and identify the user
	 * @return a {@link ResponseEntity} containing the result of the workflow
	 *         operation
	 */

	@PostMapping("/workflow/getwork")
	public ResponseEntity<Object> getNextWork(
			@RequestParam Map<String, String> otherFields,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);
		cabinetsActions.setService(service);
		logger.info("START - getNextWork()");
		loginUser = HVWUtils.getUserIdFromJWT(authToken);
		loggerService.log("INFO", requestId, 0, 0, loginUser, "workflowReroute() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getNextWork()");
		otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
		ResponseEntity<Object> response = cabinetsActions.getNewWork(otherFields, authToken);
		loggerService.log("INFO", requestId, 0, 0, HVWUtils.getUserIdFromJWT(authToken), "getWorkflowReroute",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getNextWork()");
		logger.info("END - getNextWork()");
		return response;
	}

	/**
	 * Handles HTTP POST requests to add a new unit of work into the workflow
	 * system.
	 * <p>
	 * This method performs the following operations:
	 * <ul>
	 * <li>Stores the incoming request ID for traceability and logging.</li>
	 * <li>Initializes the cabinet service layer for workflow operations.</li>
	 * <li>Extracts the user ID from the JWT authorization token.</li>
	 * <li>Logs the start of the workflow reroute process.</li>
	 * <li>Sanitizes the input parameters by removing entries with "undefined"
	 * values.</li>
	 * <li>Delegates to {@code cabinetsActions.addNewWork()} to process and persist
	 * the new work item.</li>
	 * <li>Logs the completion of the workflow reroute process.</li>
	 * </ul>
	 *
	 * @param otherFields a map of additional request parameters used to define the
	 *                    new work item
	 * @param requestId   a unique identifier for the request, used for logging and
	 *                    tracking
	 * @param authToken   the JWT token used to authenticate and identify the user
	 * @return a {@link ResponseEntity} containing the result of the add work
	 *         operation
	 */
	@PostMapping("/workflow/addwork")
	public ResponseEntity<Object> addNewWork(
			@RequestParam Map<String, String> otherFields,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);
		cabinetsActions.setService(service);
		logger.info("START - addNewWork()");
		loginUser = HVWUtils.getUserIdFromJWT(authToken);
		loggerService.log("INFO", requestId, 0, 0, loginUser, "workflowReroute() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - addNewWork()");
		otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));
		ResponseEntity<Object> response = cabinetsActions.addNewWork(otherFields, authToken);
		loggerService.log("INFO", requestId, 0, 0, HVWUtils.getUserIdFromJWT(authToken), "getWorkflowReroute",
				request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - addNewWork()");
		logger.info("END - addNewWork()");
		return response;
	}

	/** END OF CABINETS **/

	/**
	 * Helper method to create standardized error responses
	 */
	private ResponseEntity<Object> createErrorResponse(final int returnCode, final String description) {
		return HVWException.createErrorResponseEntity(returnCode, description);
	}

	// Utility method to store requestId in ThreadContext for logging and downstream
	// usage
	private void storeRequestId(Integer requestId) {
		if (requestId != null) {
			org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
		}
	}
}
