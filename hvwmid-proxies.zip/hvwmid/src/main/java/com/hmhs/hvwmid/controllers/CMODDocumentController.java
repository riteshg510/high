package com.hmhs.hvwmid.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.UserSession;
import com.hmhs.hvwmid.service.CMODAppService;
import com.hmhs.hvwmid.service.CMODDeleteService;
import com.hmhs.hvwmid.service.CMODUpdateService;
import com.hmhs.hvwmid.service.IndexListingService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * CMODDocumentController handles CMOD document operations.
 * 
 * This controller provides REST endpoints for CMOD document management
 * including:
 * - Document upload operations with file handling
 * - Document update operations with index modifications
 * - Document deletion operations
 * - Document search and retrieval operations
 * - Application choice management for dropdown lists
 * 
 * All operations include comprehensive logging and error handling.
 * Uses LoggerService for audit logging and ThreadContext for request tracking.
 * 
 * @author Generated
 * @version 1.0
 * @since 2024
 */
@RestController
@RequestMapping("${controller.path.reports}")
@CrossOrigin(exposedHeaders = { "Content-Disposition", "Content-Type" })
public class CMODDocumentController {

    @Autowired
    private HttpServletRequest request;

    private static final Logger logger = LogManager.getLogger(CMODDocumentController.class);

    // Hold for local use
    private String loginUser = HVWConstants.UID;

    @Autowired
    private CMODUpdateService updateService;

    @Autowired
    private CMODDeleteService deleteService;

    @Autowired
    private CMODAppService appService;

    @Autowired
    private IndexListingService indexListingService;

    @Autowired
    LoggerService loggerService;

    UserSession usrSec = new UserSession();

    // Utility method to store requestId in ThreadContext for logging and downstream
    // usage
    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }

    /**
     * This endpoint handles the updating of a document. It receives a request body
     * with
     * document data and an optional authorization token. It processes the update by
     * invoking the update service and returns a response based on the success or
     * failure
     * of the update operation.
     * 
     * @param request   A map containing the document data to be updated. The
     *                  document token
     *                  is expected to be part of the request for identification.
     * @param authToken An optional authorization token used for user
     *                  authentication.
     * @return A ResponseEntity containing the result of the update operation.
     *         A success response or an error response in case of failure.
     */
    @PostMapping("/indexes/update")
    public ResponseEntity<Object> updateDocument(
            @RequestBody final Map<String, Object> requestMap,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - updateDocument()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateDocument() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - updateDocument()");
        logger.info("Received update request for document: {}", requestMap.get("documentToken"));
        try {
            final ResponseEntity<Object> response = ResponseEntity
                    .ok(updateService.updateDocument(requestMap, authToken));
            logger.info("Successfully processed update request for document: {}", requestMap.get("documentToken"));
            loggerService.log("INFO", requestId, 0, 0, loginUser, "updateDocument() ",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - updateDocument()");
            logger.info("END - updateDocument()");
            return response;
        } catch (final HVWException e) {
            logger.error("HVWException while updating document {}: {}", requestMap.get("documentToken"),
                    e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "updateDocument()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - updateDocument()");
            return HVWException.createErrorResponseEntity(e);
        } catch (final Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error while updating document {}: {}", requestMap.get("documentToken"),
                    e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "updateDocument()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - updateDocument()");
            return HVWException.createErrorResponseEntity(503, "Error updating document: " + e.getMessage(), "CMOD");
        }
    }

    /**
     * This endpoint handles the deletion of a document. It receives a document
     * token, folder information,
     * and an optional authorization token. It processes the deletion by invoking
     * the delete service and
     * returns a response based on the success or failure of the operation.
     * 
     * @param documentToken The token that uniquely identifies the document to be
     *                      deleted.
     * @param odFolder      The folder where the document resides, which is
     *                      necessary for the deletion process.
     * @param authToken     An optional authorization token used for user
     *                      authentication.
     * @return A ResponseEntity containing the result of the delete operation.
     *         A success response or an error response in case of failure.
     */
    @PostMapping("/tokens/delete")
    public ResponseEntity<Object> deleteDocument(
            @RequestParam("documentToken") final String documentToken,
            @RequestParam("odFolder") final String odFolder,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - deleteDocument()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteDocument() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - deleteDocument()");
        logger.info("Received delete request for document: {}", documentToken);
        try {
            final ResponseEntity<Object> response = ResponseEntity
                    .ok(deleteService.deleteDocument(documentToken, odFolder, authToken));
            logger.info("Successfully processed delete request for document: {}", documentToken);
            loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteDocument() ",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - deleteDocument()");
            logger.info("END - deleteDocument()");
            return response;
        } catch (final HVWException e) {
            logger.error("HVWException while deleting document {}: {}", documentToken, e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteDocument()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            return HVWException.createErrorResponseEntity(e);
        } catch (final Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error while deleting document {}: {}", documentToken,
                    e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteDocument()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - deleteDocument()");
            return HVWException.createErrorResponseEntity(503, "Error deleting document: " + e.getMessage(), "CMOD");
        }
    }

    /**
     * Undeletes a document by setting the DELETED field back to blank
     * 
     * @param documentToken The document token to undelete
     * @param odFolder The folder containing the document
     * @param authToken The authentication token for user authentication
     * @param requestId The unique request identifier for logging and tracking
     * @return A ResponseEntity containing the result of the undelete operation.
     *         A success response or an error response in case of failure.
     */
    @PostMapping("/tokens/undelete")
    public ResponseEntity<Object> undeleteDocument(
            @RequestParam("documentToken") final String documentToken,
            @RequestParam("odFolder") final String odFolder,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - undeleteDocument()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "undeleteDocument() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - undeleteDocument()");
        logger.info("Received undelete request for document: {}", documentToken);
        try {
            final ResponseEntity<Object> response = ResponseEntity
                    .ok(deleteService.undeleteDocument(documentToken, odFolder, authToken));
            logger.info("Successfully processed undelete request for document: {}", documentToken);
            loggerService.log("INFO", requestId, 0, 0, loginUser, "undeleteDocument() ",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - undeleteDocument()");
            logger.info("END - undeleteDocument()");
            return response;
        } catch (final HVWException e) {
            logger.error("HVWException while undeleting document {}: {}", documentToken, e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "undeleteDocument()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            return HVWException.createErrorResponseEntity(e);
        } catch (final Exception e) {
            e.printStackTrace();
            logger.error("Unexpected error while undeleting document {}: {}", documentToken,
                    e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "undeleteDocument()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - undeleteDocument()");
            return HVWException.createErrorResponseEntity(503, "Error undeleting document: " + e.getMessage(), "CMOD");
        }
    }

    /**
     * Retrieves application choices for dropdowns
     * 
     * @param authToken The authentication token
     * @return List of application choices with key and displayName
     */
    @GetMapping("/get-application")
    public ResponseEntity<Object> getApplicationChoices(
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getApplicationChoices()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getApplicationChoices() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getApplicationChoices()");
        logger.info("Received request for CMOD application choices");

        try {
            final List<Map<String, String>> choices = appService.getCombinedApplicationChoices();

            final Map<String, Object> response = new HashMap<>();
            response.put("applications", choices);
            response.put("count", choices.size());

            // Add success message
            final Map<String, Object> serviceMessage = new HashMap<>();
            serviceMessage.put("returnCode", 0);
            serviceMessage.put("returnCodeDescription", "Application choices retrieved successfully");
            response.put("serviceMessage", serviceMessage);

            logger.info("Retrieved {} application choices", choices.size());
            loggerService.log("INFO", requestId, 0, 0, loginUser, "getApplicationChoices() ",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - getApplicationChoices()");
            logger.info("END - getApplicationChoices()");
            return ResponseEntity.ok(response);

        } catch (final HVWException e) {
            logger.error("HVWException while retrieving application choices: {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getApplicationChoices()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.BAD_REQUEST.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getApplicationChoices()");
            return HVWException.createErrorResponseEntity(e);
        } catch (final Exception e) {
            logger.error("Unexpected error while retrieving application choices: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getApplicationChoices()",
                    request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getApplicationChoices()");
            return HVWException.createErrorResponseEntity(503,
                    "Error retrieving application choices: " + e.getMessage(), "CMOD");
        }
    }

    // CMOD RESULT START
    /**
     * This endpoint retrieves and processes CMOD result data based on the provided
     * parameters and an optional authentication token. It checks for errors in the
     * response and maps them to appropriate HTTP status codes. If the processing
     * is successful, it returns the result data in the response.
     * 
     * @param otherFields The request parameters that will be used for processing
     *                    the CMOD result.
     * @param authToken   The optional authentication token to identify the user.
     * @param file        An optional MultipartFile that can be sent with the
     *                    request.
     * @return A ResponseEntity containing the processed CMOD result data or an
     *         error message.
     */
    @PostMapping("/indexes/search-folder")
    public ResponseEntity<Object> getCmodResultData(@RequestParam final Map<String, String> otherFields,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestParam(value = "file", required = false) final MultipartFile file,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getCmodResultData()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getCmodResultData() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getCmodResultData()");
        try {
            logger.info("Start CMOD result");
            // Get user ID from auth token
            loginUser = HVWUtils.getUserIdFromJWT(authToken);
            otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

            // Process the report data and get the response
            final Map<String, Object> responseData = indexListingService.processReportData(otherFields, authToken);

            // Check if this is an error response
            if (responseData.containsKey("serviceMessage")) {
                final Map<String, Object> serviceMessage = (Map<String, Object>) responseData.get("serviceMessage");

                // If it has a non-zero return code, check if it's a special case or an error
                if (serviceMessage.containsKey("returnCode")) {
                    final int returnCode = ((Number) serviceMessage.get("returnCode")).intValue();
                    if (returnCode != 0) {
                        // Special handling for return code 20 - return { data: [], definition: null }
                        if (returnCode == 20) {
                            loggerService.log("INFO", requestId, 0, 0, loginUser,
                                    "getCmodResultData()", request.getRequestURI(), String.valueOf(returnCode),
                                    "Return code 20 - returning empty data with null definition");
                            logger.info("END - getCmodResultData() - Return code 20, returning empty data with null definition");
                            
                            Map<String, Object> body = new HashMap<>();
                            body.put("data", new ArrayList<>());
                            body.put("definition", null);
                            return ResponseEntity.ok(body);
                        }
                        
                        // Map common error codes to HTTP status codes
                        HttpStatus status;
                        switch (returnCode) {
                            case 400:
                                status = HttpStatus.BAD_REQUEST;
                                break;
                            case 401:
                                status = HttpStatus.UNAUTHORIZED;
                                break;
                            case 403:
                                status = HttpStatus.FORBIDDEN;
                                break;
                            case 404:
                                status = HttpStatus.NOT_FOUND;
                                break;
                            default:
                                // For other codes, use a generic server error status
                                status = HttpStatus.SERVICE_UNAVAILABLE;
                        }
                        loggerService.log("INFO", requestId, 0, 0, loginUser,
                                "getCmodResultData()", request.getRequestURI(), String.valueOf(returnCode),
                                "END - getCmodResultData()");
                        logger.info("END - getCmodResultData()");
                        return ResponseEntity.status(status).body(responseData);
                    }
                }
            }
            loggerService.log("INFO", requestId, 0, 0, loginUser, "getCmodResultData() ",
                    request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getCmodResultData()");

            // If we get here, it's a successful response
            return ResponseEntity.ok(responseData);

        } catch (final Exception e) {
            logger.error("Error in CMOD result processing: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getCmodResultData()", request.getRequestURI(),
                    String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
                    (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
            logger.info("END - getCmodResultData()");
            return HVWException.createErrorResponseEntity(e);
        }

    } // CMOD RESULT END
}