package com.hmhs.hvwmid.controllers;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblForms;
import com.hmhs.hvwmid.entity.TblPickListItems;
import com.hmhs.hvwmid.entity.TblSectionDetails;
import com.hmhs.hvwmid.entity.TblTemplates;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.layouts.LayoutsAndActions;
import com.hmhs.hvwmid.model.ApiSection;
import com.hmhs.hvwmid.model.Form;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.model.TableDefinition;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.CustomPostService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.service.ReportService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * @author Ramanjaneyulu Manam on Sep 18, 2024
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("${controller.path.common}")
@RestController
public class AppDataController {

	@Autowired
	HttpServletRequest request;

	@Autowired
	private LayoutsAndActions layoutsActions;

	@Value("${server.servlet.context-path}")
	String appPath;

	@Value("${app.environment:default}")
	private String environment;

	private static final Logger logger = LogManager.getLogger(AppDataController.class);

	// Hold for local use
	String loginUser = HVWConstants.UID;

	@Autowired
	AppDataService service;

	@Autowired
	private CustomPostService cpService;

	@Autowired
	ReportService reportService;

	@Autowired
	LoggerService loggerService;

	/**
	 * Endpoint to retrieve the list of main menu items.
	 *
	 * This endpoint processes an incoming request to return a JSON-formatted list
	 * of main menu options fetched from the database. Authentication is validated
	 * using the provided authorization token. If the token is invalid or missing,
	 * the service returns an authentication error. Each request is logged for
	 * traceability.
	 *
	 * @param authToken The authorization token for validating the user (optional).
	 * @param requestId A unique identifier for tracking the request (optional).
	 * @return ResponseEntity<String> containing the main menu data in JSON format
	 *         or an appropriate error message.
	 */
	@GetMapping("/get-mainmenu")
	public ResponseEntity<String> getMainMenu(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);

		logger.info("START - getMainMenu()");
		loggerService.log("INFO", requestId, 0, 0, "", "getMainMenu()", request.getRequestURI(),
				"", "START - getMainMenu()");

		logger.info("mainmenu is loading...");
		String response = "";
		logger.info("requestId is {}", requestId);
		List<TblTemplates> tblFilterOptionData = null;
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, "", "getMainMenu()", request.getRequestURI(),
						"401", "Authentication required. Missing or invalid token.");
			}

			tblFilterOptionData = service.getTempletByName("AppMainMenu");
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			logger.info("mainmenu is loaded.");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getMainMenu()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getMainMenu()");

			logger.info("END - getMainMenu()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception ext) {
			ext.printStackTrace();
			logger.error(ext.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getMainMenu()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(ext.getMessage().length() > 250) ? ext.getMessage().substring(0, 250) : ext.getMessage());

			logger.info("END - getMainMenu()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	@GetMapping("/get-edmMainMenu")
	public ResponseEntity<String> getEdmMainMenu(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);

		logger.info("START - getEdmMainMenu()");
		loggerService.log("INFO", requestId, 0, 0, "", "getEdmMainMenu()", request.getRequestURI(),
				"", "START - getEdmMainMenu()");

		logger.info("edmMainMenu is loading...");
		String response = "";
		logger.info("requestId is {}", requestId);
		List<TblTemplates> tblFilterOptionData = null;
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, "", "getEdmMainMenu()", request.getRequestURI(),
						"401", "Authentication required. Missing or invalid token.");
			}

			tblFilterOptionData = service.getTempletByName("EdmMainMenu");
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			logger.info("edmMainMenu is loaded.");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getEdmMainMenu()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getEdmMainMenu()");

			logger.info("END - getEdmMainMenu()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception ext) {
			ext.printStackTrace();
			logger.error(ext.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getEdmMainMenu()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(ext.getMessage().length() > 250) ? ext.getMessage().substring(0, 250) : ext.getMessage());

			logger.info("END - getEdmMainMenu()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	@GetMapping("/get-ioMainMenu")
	public ResponseEntity<String> getIoMainMenu(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);

		logger.info("START - getIoMainMenu()");
		loggerService.log("INFO", requestId, 0, 0, "", "getIoMainMenu()", request.getRequestURI(),
				"", "START - getIoMainMenu()");

		logger.info("mainmenu is loading...");
		String response = "";
		logger.info("requestId is {}", requestId);
		List<TblTemplates> tblFilterOptionData = null;
		try {
			// Get user ID from auth token instead of using constant
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, "", "getIoMainMenu()", request.getRequestURI(),
						"401", "Authentication required. Missing or invalid token.");
			}

			tblFilterOptionData = service.getTempletByName("ImageOptionsMainMenu");
			for (final TblTemplates tdata : tblFilterOptionData) {

				// To get the JSON Data from DB table Column of byte
				response = new String(tdata.getContent(), StandardCharsets.UTF_8);

			}
			logger.info("ioMainMenu is loaded.");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getIoMainMenu()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getIoMainMenu()");

			logger.info("END - getIoMainMenu()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception ext) {
			ext.printStackTrace();
			logger.error(ext.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getIoMainMenu()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(ext.getMessage().length() > 250) ? ext.getMessage().substring(0, 250) : ext.getMessage());

			logger.info("END - getIoMainMenu()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * Endpoint to retrieve actions or layout details for a specified form ID.
	 *
	 * This method processes requests to fetch data for a form based on its ID.
	 * It distinguishes between CMOD forms and cabinets forms, fetching the
	 * appropriate data from the database or service. The content is returned
	 * as JSON, allowing clients to render forms dynamically.
	 *
	 * If the form ID starts with "CMOD" it retrieves CMOD-specific folder data
	 * along with additional help content, if available. For cabinets forms, it
	 * fetches layout details, actions, and form metadata.
	 *
	 * All interactions are logged for traceability, including both successful and
	 * failed operations. Authentication and request ID are optional parameters but
	 * assist in validation and tracking the request lifecycle.
	 *
	 * @param "id"      of form, The unique identifier of the form to be processed.
	 * @param authToken The authorization token for validating the user (optional).
	 * @return ResponseEntity<Object> containing the form actions or layout details,
	 *         or an appropriate error message in case of failure.
	 */
	@GetMapping("/get-form/{id}")
	public ResponseEntity<Object> getActionsForFormId(@PathVariable(value = "id") String fid,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);
		logger.info("START - getActionsForFormId()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getActionsForFormId()",
				request.getRequestURI(), "", "START - getActionsForFormId()");
		logger.info("Getting formId {}", fid);

		try {
			if (fid.startsWith("CMOD")) {
				// Replace _SLASH_ with /
				fid = fid.replace("__SLASH__", "/");
				loginUser = HVWUtils.getUserIdFromJWT(authToken);
				ApiSection aps = new ApiSection();
				aps.setService(service);
				String sHelp = "";
				try {
					List<TblSectionDetails> sectionDetails = aps.getHtmlContentByFolderName(fid);
					if (sectionDetails.isEmpty()) {
						sectionDetails = aps.getHtmlContentByFolderName("DEFAULT");
					}
					if (!sectionDetails.isEmpty()) {
						sHelp = new String(sectionDetails.get(0).getHtmlContent(), StandardCharsets.UTF_8);
					}
				} catch (final Exception exce) {
					exce.printStackTrace();
					loggerService.log("ERROR", requestId, 0, 0, loginUser, "getActionsForFormId()",
							request.getRequestURI(),
							"503", (exce.getMessage().length() > 250) ? exce.getMessage().substring(0, 250)
									: exce.getMessage());
					sHelp = "";
				}
				// Process CMOD folder data - will throw an exception if fields can't be loaded
				return ResponseEntity.ok(reportService.getCmodFolderData(fid, sHelp.trim(), authToken));
			} else {
				// Handle non-CMOD forms
				layoutsActions.setService(service);
				final Form form = layoutsActions.getLayoutAndActions(fid);
				final TblForms forms = service.getForm(fid);
				form.setFormName(forms.getFormName());
				form.setType(forms.getType());
				loggerService.log("INFO", requestId, 0, 0, loginUser, "getActionsForFormId()",
						request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getActionsForFormId()");
				logger.info("END - getActionsForFormId()");
				return ResponseEntity.ok(form);
			}
		} catch (final HVWException e) {
			// Handle service errors by returning proper error response
			logger.error("Service error processing formId {}: {}", fid, e.getMessage());
			logger.info("END - getActionsForFormId()");
			return HVWException.createErrorResponseEntity(e);
		} catch (final Exception e) {
			e.printStackTrace();
			// Handle unexpected errors
			logger.error("Error processing formId {}: {}", fid, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getActionsForFormId()", request.getRequestURI(),
					"503", (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - getActionsForFormId()");
			return HVWException.createErrorResponseEntity(503,
					"Error processing form " + fid + ": " + e.getMessage(),
					"FormController");
		}
	}

	/**
	 * Endpoint to retrieve a list of picklist items based on the specified picklist
	 * ID.
	 *
	 * This method fetches and returns a list of picklist items in JSON format for
	 * the given picklist ID. If the picklist ID corresponds to valid data, the
	 * associated items are retrieved from the database and processed. In case
	 * of an error, appropriate logs are recorded.
	 *
	 * @param pickListId The unique identifier of the picklist whose items need to
	 *                   be fetched.
	 * @return ResponseEntity<List<PickListItems>> containing the list of picklist
	 *         items or an empty list in case no items are found or an error occurs.
	 */
	@GetMapping("/get-picklist/{id}")
	public ResponseEntity<List<PickListItems>> getPickListByPickListId(
			@PathVariable(value = "id") final String pickListId,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getPickListByPickListId()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByPickListId", request.getRequestURI(),
				"", "START - getPickListByPickListId()");

		List<PickListItems> pickList = new ArrayList<>();
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// list the Section Id's
			final List<TblPickListItems> choiceItems = service.getPickList(pickListId);
			if (!choiceItems.isEmpty()) {
				pickList = getPickList(choiceItems, requestId, loginUser);
			}
		} catch (final Exception ee) {
			logger.error(ee.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPickListByPickListId", request.getRequestURI(),
					"503", (ee.getMessage().length() > 250) ? ee.getMessage().substring(0, 250) : ee.getMessage());
		}

		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByPickListId", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "END - getPickListByPickListId()");
		logger.info("END - getPickListByPickListId()");
		return ResponseEntity.ok(pickList);
	}

	/**
	 * Endpoint to retrieve a list of picklist items based on a picklist ID and a
	 * parent key.
	 *
	 * This method processes a request to fetch picklist items from the database
	 * using a combination of a picklist ID and a parent key. If matching items
	 * are found, they are processed and returned as a list in JSON format. In
	 * case of an error, it logs the exception and provides an appropriate response.
	 *
	 * @param pickListId The unique identifier of the picklist to fetch.
	 * @param parentKey  The key associated with the parent entity to filter the
	 *                   picklist items.
	 * @return ResponseEntity<List<PickListItems>> containing the list of picklist
	 *         items or an empty list in case of no matching items or an error.
	 */
	@GetMapping("/get-picklist/{id}/{key1}")
	public ResponseEntity<List<PickListItems>> getPickListByIdAndKey(
			@PathVariable(value = "id") final String pickListId,
			@PathVariable(value = "key1") final String parentKey,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getPickListByIdAndKey()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByIdAndKey()", request.getRequestURI(),
				"", "START - getPickListByIdAndKey()");

		List<PickListItems> pickList = new ArrayList<>();
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// list the Section Id's
			final List<TblPickListItems> choiceItems = service.getPickList(pickListId, parentKey);
			if (!choiceItems.isEmpty()) {
				pickList = getPickList(choiceItems, requestId, loginUser);
			}
		} catch (final Exception ei) {
			logger.error(ei.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPickListByIdAndKey()", request.getRequestURI(),
					"503", (ei.getMessage().length() > 250) ? ei.getMessage().substring(0, 250) : ei.getMessage());
		}

		logger.info("END - getPickListByIdAndKey()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByIdAndKey()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "END - getPickListByIdAndKey()");
		return ResponseEntity.ok(pickList);
	}

	/**
	 * Endpoint to retrieve a list of picklist items based on a picklist ID and two
	 * parent keys.
	 *
	 * This method processes a request to fetch picklist items from the database
	 * using a combination of a picklist ID and two parent keys. These keys are
	 * used for filtering purposes. If matching items are found, they are processed
	 * and returned as a list in JSON format. Any errors during processing are
	 * logged for traceability.
	 *
	 * @param pickListId The unique identifier of the picklist to fetch.
	 * @param parentKey1 The first key associated with the parent entity for
	 *                   filtering the picklist items.
	 * @param parentKey2 The second key associated with the parent entity for
	 *                   filtering the picklist items.
	 * @return ResponseEntity<List<PickListItems>> containing the list of picklist
	 *         items or an empty list if no matching items are found or an error
	 *         occurs.
	 */
	@GetMapping("/get-picklist/{id}/{key1}/{key2}")
	public ResponseEntity<List<PickListItems>> getPickListByIdAndKeyTwo(
			@PathVariable(value = "id") final String pickListId,
			@PathVariable(value = "key1") final String parentKey1,
			@PathVariable(value = "key2") final String parentKey2,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getPickListByIdAndKeyTwo()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByIdAndKeyTwo", request.getRequestURI(),
				"", "START - getPickListByIdAndKeyTwo()");

		List<PickListItems> pickList = new ArrayList<>();
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// list the Section Id's
			final List<TblPickListItems> choiceItems = service.getPickList(pickListId, parentKey1 + "," + parentKey2);
			if (!choiceItems.isEmpty()) {
				pickList = getPickList(choiceItems, requestId, loginUser);
			}
		} catch (final Exception eci) {
			logger.error(eci.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPickListByIdAndKeyTwo", request.getRequestURI(),
					"503", (eci.getMessage().length() > 250) ? eci.getMessage().substring(0, 250) : eci.getMessage());
		}

		logger.info("END - getPickListByIdAndKeyTwo()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByIdAndKeyTwo", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "END - getPickListByIdAndKeyTwo()");
		return ResponseEntity.ok(pickList);
	}

	/**
	 * Endpoint to retrieve a list of picklist items based on a picklist ID and two
	 * parent keys.
	 *
	 * This method processes a request to fetch picklist items from the database
	 * using a combination of a picklist ID and two parent keys. These keys are
	 * used for filtering purposes. If matching items are found, they are processed
	 * and returned as a list in JSON format. Any errors during processing are
	 * logged for traceability.
	 *
	 * @param pickListId The unique identifier of the picklist to fetch.
	 * @param parentKey1 The first key associated with the parent entity for
	 *                   filtering the picklist items.
	 * @param parentKey2 The second key associated with the parent entity for
	 *                   filtering the picklist items.
	 * @return ResponseEntity<List<PickListItems>> containing the list of picklist
	 *         items or an empty list if no matching items are found or an error
	 *         occurs.
	 */
	@GetMapping("/get-picklist/{id}/{key1}/{key2}/{key3}")
	public ResponseEntity<List<PickListItems>> getPickListByIdKeyThree(
			@PathVariable(value = "id") final String pickListId,
			@PathVariable(value = "key1") final String parentKey1,
			@PathVariable(value = "key2") final String parentKey2,
			@PathVariable(value = "key3") final String parentKey3,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getPickListByIdKeyThree()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByIdKeyThree()", request.getRequestURI(),
				"", "START - getPickListByIdKeyThree()");

		List<PickListItems> pickList = new ArrayList<>();
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// list the Section Id's
			final List<TblPickListItems> choiceItems = service.getPickList(pickListId,
					parentKey1 + "," + parentKey2 + "," + parentKey3);
			if (!choiceItems.isEmpty()) {
				pickList = getPickList(choiceItems, requestId, loginUser);
			}
		} catch (final Exception ein) {
			logger.error(ein.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPickListByIdKeyThree()", request.getRequestURI(),
					"503", (ein.getMessage().length() > 250) ? ein.getMessage().substring(0, 250) : ein.getMessage());
		}
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getPickListByIdKeyThree()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "END - getPickListByIdKeyThree()");
		logger.info("END - getPickListByIdKeyThree()");
		return ResponseEntity.ok(pickList);
	}

	/**
	 * Endpoint to fetch a list of picklist items based on a field ID and a lookup
	 * value.
	 *
	 * This method retrieves picklist items from the database by using a field ID
	 * and a lookup value as filters. It processes the lookup values and returns
	 * the items in JSON format. If no matching items are found, an empty list is
	 * returned. Any errors encountered during processing are logged for debugging
	 * and traceability.
	 *
	 * @param fieldId     The unique identifier for the field to retrieve lookup
	 *                    values for.
	 * @param lookupValue The specific lookup value used for filtering the picklist
	 *                    items.
	 * @return ResponseEntity<List<PickListItems>> containing the list of picklist
	 *         items or an empty list in case of no matching results or an error.
	 */
	@GetMapping("/lookup/{fieldId}/{value}")
	public ResponseEntity<List<PickListItems>> getLookupValues(
			@PathVariable(value = "fieldId") final String fieldId,
			@PathVariable(value = "value") final String lookupValue,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getLookupValues()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getLookupValues()", request.getRequestURI(),
				"", "START - getLookupValues()");

		List<PickListItems> itemsList = new ArrayList<>();

		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// list the lookup Value's
			List<String> choiceItems = cpService.getLookupValues(fieldId, lookupValue);
			if ("Noservice".equalsIgnoreCase(environment)) {
				if (lookupValue.matches("\\d+"))
					choiceItems = List.of(lookupValue + "11", lookupValue + "12", lookupValue + "13",
							lookupValue + "14");
				else
					choiceItems = List.of(lookupValue + "ABC", lookupValue + "AAA", lookupValue + "BBB",
							lookupValue + "CCC");
			}
			logger.info("choiceItems are {}", choiceItems.size());
			if (!choiceItems.isEmpty()) {
				itemsList = getItemsList(choiceItems, requestId, loginUser);
			}
		} catch (final Exception en) {
			logger.error(en.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getLookupValues()", request.getRequestURI(),
					"503", (en.getMessage().length() > 250) ? en.getMessage().substring(0, 250) : en.getMessage());
		}

		logger.info("END - getLookupValues()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getLookupValues()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "END - getLookupValues()");

		return ResponseEntity.ok(itemsList);
	}

	/**
	 * This endpoint retrieves the definition of a table based on the provided table
	 * ID.
	 * It fetches the table definition from the service and returns it in the
	 * response. If an error occurs during the process, an error response is
	 * returned.
	 * 
	 * @param tableId The ID of the table whose definition is to be fetched.
	 * @return A ResponseEntity containing the TableDefinition object, or an error
	 *         response if an exception occurs.
	 */
	@GetMapping("/get-tabledefinition/{id}")
	public ResponseEntity<TableDefinition> getTableDefinition(
			@PathVariable(value = "id") final String tableId,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		storeRequestId(requestId);

		logger.info("START - getTableDefinition()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getTableDefinition()",
				request.getRequestURI(), "", "START - getTableDefinition()");

		TableDefinition response = new TableDefinition();
		final ApiSection aps = new ApiSection();
		aps.setService(service);
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			Map<String, String> otherFields = new HashMap<>();
			response = aps.getTableDefinition(response, tableId, otherFields);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getTableDefinition()",
					request.getRequestURI(), String.valueOf(HttpStatus.OK.value()), "END - getTableDefinition()");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (final Exception ect) {
			ect.printStackTrace();
			logger.error(ect.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getTableDefinition()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(ect.getMessage().length() > 250) ? ect.getMessage().substring(0, 250) : ect.getMessage());
			logger.info("END - getTableDefinition()");
			return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
		}
	}

	/**
	 * This endpoint handles redirection based on the query parameters passed in the
	 * request.
	 * If the "template" parameter is present, the method constructs a URL and
	 * redirects to a specific page. Otherwise, it returns null.
	 * 
	 * @param queryParams The map containing the query parameters from the request.
	 * @return A RedirectView object to redirect the user to the constructed URL, or
	 *         null if no redirection is necessary.
	 */
	@GetMapping("/ImgSessionMgr")
	public Object redirectToSearch(@RequestParam Map<String, String> allParams) {
		logger.debug("/ImgSessionMgr called with params: {}", allParams);
		Map<String, String> queryParams = new java.util.HashMap<>();
		boolean isJsonParmas = false;
		// Support new frontend: if 'queryParams' param is present, parse it as JSON
		if (allParams.containsKey("queryParams")) {
			try {
				isJsonParmas = true;
				String json = allParams.get("queryParams");
				logger.debug("Parsing queryParams JSON: {}", json);
				// Use Jackson ObjectMapper for parsing
				com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
				queryParams = mapper.readValue(json,
						new com.fasterxml.jackson.core.type.TypeReference<java.util.HashMap<String, String>>() {
						});
				logger.debug("Parsed queryParams: {}", queryParams);
			} catch (Exception e) {
				logger.error("Failed to parse queryParams JSON: {}", allParams.get("queryParams"), e);
			}
		} else {
			queryParams.putAll(allParams);
		}
		// Take urlAction before everything
		String urlAction = queryParams.getOrDefault("action", "");
		logger.debug("urlAction: {}", urlAction);
		// Template-based redirect, only if action=listobj2a
		final boolean redirect = queryParams.containsKey("template");
		final StringBuilder redirectUrl = new StringBuilder("/search");
		if (!queryParams.isEmpty() && redirect) {
			logger.debug("Template-based redirect triggered");
			redirectUrl.append("?");
			queryParams.forEach((key, value) -> {
				logger.debug("Processing param: {} = {}", key, value);
				if (key.equalsIgnoreCase("template")) {
					final List<TblForms> form = service.getFormIdByFileName(value.replaceFirst("[.][^.]+$", ""));
					logger.debug("Form lookup for template '{}': {}", value, form);
					if (!form.isEmpty()) {
						if (value.toLowerCase().contains("work"))
							redirectUrl.replace(0, 7, HVWConstants.WORKFLOW + form.get(0).getFormId());
						else if (value.toLowerCase().contains("scan"))
							redirectUrl.replace(0, 7, HVWConstants.CABINETSCAN + form.get(0).getFormId());
						else
							redirectUrl.replace(0, 7, "/pages/search/" + form.get(0).getFormId());
					} else {
						redirectUrl.append(key.replace("ImgSessionMgr?", "")).append("=").append(value).append("&");
					}
				} else
					redirectUrl.append(key).append("=").append(value).append("&");
			});
			// Remove the last "&"
			redirectUrl.setLength(redirectUrl.length() - 1);
			logger.debug("Final redirectUrl: {}", redirectUrl);
			// Return as JSON object
			if (isJsonParmas)
				return redirectUrl.toString();
			else
				return new RedirectView(redirectUrl.toString());
		}

		// Now check for listrptCMOD
		if ("listrptCMOD".equalsIgnoreCase(urlAction)) {
			logger.debug("listrptCMOD redirect triggered");
			String cmodFolderName = queryParams.getOrDefault("cmodFolderName", "");
			StringBuilder singleReportUrl = new StringBuilder("/" + HVWConstants.SINGLEREPORT);
			singleReportUrl.append(cmodFolderName);
			boolean first = true;
			// Prepare field mapping and filter
			Map<String, String> fieldMap = new java.util.HashMap<>();
			String begindate = null, enddate = null;
			for (Map.Entry<String, String> entry : queryParams.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				logger.debug("Processing param: {} = {}", key, value);
				if ("cmodFolderName".equalsIgnoreCase(key) || "action".equalsIgnoreCase(key))
					continue;
				if (key.equalsIgnoreCase("begindate")) {
					begindate = formatDateToISO(value);
					logger.debug("Parsed begindate: {}", begindate);
					continue;
				}
				if (key.equalsIgnoreCase("enddate")) {
					enddate = formatDateToISO(value);
					logger.debug("Parsed enddate: {}", enddate);
					continue;
				}
				if (key.toLowerCase().startsWith("field")) {
					fieldMap.put(key, value);
					logger.debug("Added to fieldMap: {} = {}", key, value);
				}
			}
			// Now resolve field values
			Map<String, String> resolvedFields = new java.util.HashMap<>();
			for (Map.Entry<String, String> fieldEntry : fieldMap.entrySet()) {
				String fieldKey = fieldEntry.getKey();
				String fieldName = fieldEntry.getValue();
				String fieldValue = queryParams.get(fieldName);
				logger.debug("Resolving field: {} (name: {}) = {}", fieldKey, fieldName, fieldValue);
				if (fieldValue != null) {
					resolvedFields.put(fieldKey, fieldValue);
				}
			}
			// Build URL
			if (first && (begindate != null || enddate != null || !resolvedFields.isEmpty())) {
				singleReportUrl.append("?");
				first = false;
			}
			boolean added = false;
			if (begindate != null) {
				singleReportUrl.append("begindate=").append(begindate);
				added = true;
			}
			if (enddate != null) {
				if (added)
					singleReportUrl.append("&");
				singleReportUrl.append("enddate=").append(enddate);
				added = true;
			}
			for (Map.Entry<String, String> resolved : resolvedFields.entrySet()) {
				if (added)
					singleReportUrl.append("&");
				singleReportUrl.append(resolved.getKey()).append("=").append(resolved.getValue());
				added = true;
			}
			// Add action and autoshow if present
			if (queryParams.containsKey("action")) {
				if (added)
					singleReportUrl.append("&");
				singleReportUrl.append("action=").append(queryParams.get("action"));
				added = true;
			}
			if (queryParams.containsKey("autoshow")) {
				if (added)
					singleReportUrl.append("&");
				singleReportUrl.append("autoshow=").append(queryParams.get("autoshow"));
			}
			if (queryParams.containsKey("srchop")) {
				if (added)
					singleReportUrl.append("&");
				singleReportUrl.append("srchop=").append(queryParams.get("srchop"));
			}
			logger.debug("Final singleReportUrl: {}", singleReportUrl);
			// Return as JSON object
			return Map.of("url", singleReportUrl.toString());
		}

		// Default: no redirect
		logger.debug("No redirect performed for /ImgSessionMgr");
		return null;
	}

	/**
	 * Utility method to store requestId in ThreadContext for logging and downstream
	 * usage
	 */
	private void storeRequestId(Integer requestId) {
		if (requestId != null) {
			ThreadContext.put("requestId", String.valueOf(requestId));
		}
	}

	/**
	 * Helper method to Converts a list of TblPickListItems to a list of
	 * PickListItems.
	 * 
	 * @param choiceItems - List of TblPickListItems objects to be converted.
	 * @param requestId   - ID of the current request for logging purposes.
	 * @param loginUser   - The username of the user performing this operation, used
	 *                    for logging.
	 * @return A List of PickListItems constructed from the input choiceItems.
	 */
	public List<PickListItems> getPickList(final List<TblPickListItems> choiceItems, int requestId,
			String loginUser) {
		final List<PickListItems> pickList = new ArrayList<>();
		try {
			PickListItems pItem = null;
			Long i = 0L;
			for (final TblPickListItems item : choiceItems) {
				pItem = new PickListItems();
				pItem.setDisplayName(item.getDisplayName());
				pItem.setParentKey(item.getDependentKey());
				pItem.setKey(item.getKey());
				pItem.setId(i++);
				pickList.add(pItem);
			}
		} catch (final Exception expn) {
			expn.printStackTrace();
			logger.error(expn.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getPickList()", request.getRequestURI(), "503",
					(expn.getMessage().length() > 250) ? expn.getMessage().substring(0, 250) : expn.getMessage());
		}
		return pickList;
	}

	/**
	 * This Helper method to takes a list of choice items (strings) and constructs a
	 * list of PickListItems, setting both the display name and key for each item.
	 * The resulting list is returned after processing all the items.
	 * 
	 * @param choiceItems A list of strings representing the items to be included in
	 *                    the pick list.
	 * @param requestId
	 * @return A list of PickListItems with the display name and key set to the item
	 *         strings.
	 */
	private List<PickListItems> getItemsList(final List<String> choiceItems, int requestId, String loginUser) {
		final List<PickListItems> itemsList = new ArrayList<>();

		try {
			PickListItems pItem = null;
			for (final String item : choiceItems) {
				pItem = new PickListItems();
				pItem.setDisplayName(item);
				pItem.setKey(item);
				itemsList.add(pItem);
			}

		} catch (final Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getItemsList()", request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
		}
		return itemsList;
	}

	// Helper to convert mm/dd/yy or mm/dd/yyyy to yyyy-MM-dd
	private String formatDateToISO(String date) {
		if (date == null)
			return null;
		String[] parts = date.split("/");
		if (parts.length == 3) {
			String mm = parts[0];
			String dd = parts[1];
			String yyyy = parts[2];
			if (yyyy.length() == 2) {
				yyyy = "20" + yyyy;
			}
			return yyyy + "-" + String.format("%02d", Integer.parseInt(mm)) + "-"
					+ String.format("%02d", Integer.parseInt(dd));
		}
		// fallback: just return original
		return date;
	}
}
