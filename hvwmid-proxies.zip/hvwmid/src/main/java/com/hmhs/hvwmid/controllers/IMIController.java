package com.hmhs.hvwmid.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.ThreadContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.IMISearchData;
import com.hmhs.hvwmid.model.IMIUISearchRequest;
import com.hmhs.hvwmid.model.IMIUpdateData;
import com.hmhs.hvwmid.model.IMIUpdateRequest;
import com.hmhs.hvwmid.model.IMIUpdateRetrieveRequest;
import com.hmhs.hvwmid.model.PickListItems;
import com.hmhs.hvwmid.service.AppDataService;
import com.hmhs.hvwmid.service.IMIActivityTrackingService;
import com.hmhs.hvwmid.service.IMIGeneratorService;
import com.hmhs.hvwmid.service.IMIUpdateService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(value = { "${controller.path.imi}" })
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class IMIController {

	private static final Logger logger = LoggerFactory.getLogger(IMIController.class);

	private static final String RETRIEVESEGMENTDATA = "/retrieve-segment-data";
	private static final String IMIACTIVITYTRACKING = "/imiactivitytracking";
	private static final String IMIONLOAD = "/imiOnLoad";
	private static final String IMI_UPDATE_RETRIEVE = "/imi-retrieveUpdate";
	private static final String IMI_UPDATE_REQUST = "/imi-updateRequest";
	private static final String IMI_CMOD_SEARCH = "/imiCMODSearch";
	private static final String AUTH_REQUIRED = "Authentication required. Missing or invalid token.";

	// Hold for local use
	private String loginUser = HVWConstants.UID.toUpperCase();

	@Autowired
	private IMIActivityTrackingService imiActivityTrackingService;

	@Autowired
	private LoggerService loggerService;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	AppDataService service;

	@Autowired
	IMIGeneratorService imiGeneratorService;

	@Autowired
	IMIUpdateService imiUpdateService;

	/**
	 * Endpoint to retrieve IMI on-load data including NAIC access map.
	 *
	 * This method processes an incoming request to return IMI on-load data
	 * including the NAIC access map based on user's LDAP groups. Authentication is
	 * validated using the provided authorization token. If the token is invalid or
	 * missing, the service returns an authentication error. Each request is logged
	 * for traceability.
	 *
	 * @param authToken The authorization token for validating the user (required).
	 * @param requestId A unique identifier for tracking the request (required).
	 * @return ResponseEntity<Object> containing the IMI on-load data or an
	 *         appropriate error message.
	 */
	@GetMapping("/imiOnLoad")
	public ResponseEntity<Object> imiOnLoad(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);
		List<PickListItems> pickList = new ArrayList<>();
		loggerService.log("INFO", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "",
				"START - IMIOnLoad()");
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "401",
						AUTH_REQUIRED);
				return createErrorResponse(401, AUTH_REQUIRED);
			}

			logger.debug("Received IMI On load request for user: {}", loginUser);

			IMISearchData searchData = imiActivityTrackingService.imiOnLoad(authToken);

			// Check if there's an error in the search data
			if (searchData.getBaseMessage() != null && searchData.getBaseMessage().getReturnCodeDescription() != null) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "403",
						searchData.getBaseMessage().getReturnCodeDescription());
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "403",
						searchData.getBaseMessage().getReturnCodeDescription());
				return createErrorResponse(403, searchData.getBaseMessage().getReturnCodeDescription());
			}

			if (searchData.getNaicMap() != null && !searchData.getNaicMap().isEmpty()) {
				pickList = transformNaicMapToPickListItems(searchData.getNaicMap());
				loggerService.log("INFO", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "200",
						"IMI on-load data fetched successfully. NAIC map size: " + searchData.getNaicMap().size());
			} else {
				loggerService.log("WARN", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "200",
						"No NAIC access found for user");
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "",
					"END - IMIOnLoad()");
			return ResponseEntity.ok(pickList);

		} catch (final Exception e) {
			logger.error("Error processing IMI on-load request for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, IMIONLOAD, request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(503, "Error processing IMI on-load request: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to retrieve IMI Activity Tracking search results with advanced
	 * pagination support.
	 * 
	 * This endpoint processes search requests for IMI (Image Management Interface)
	 * activity tracking data, supporting both initial searches and pagination
	 * navigation. It handles various search criteria including date ranges, file
	 * identifiers, status codes, and display field preferences. The endpoint
	 * implements advanced pagination logic using result set pointers for efficient
	 * data navigation.
	 * 
	 * @param authToken           The authorization token for user authentication
	 *                            (required). Must contain valid JWT with user
	 *                            information and LDAP groups.
	 * @param requestId           Unique identifier for request tracking and logging
	 *                            (required). Used for correlating logs across the
	 *                            application stack.
	 * @param imiAction           The action to perform (required). Valid values:
	 *                            1. Any string except
	 *                            "imiNextResults"/"imiPreviousResults" - Initial search
	 *                            2. "imiNextResults" - Navigate to next page
	 *                            3. "imiPreviousResults" - Navigate to previous
	 *                            page
	 * @param resultPointer       Result set pointer for pagination (optional,
	 *                            default: 0). Used with "imiNextResults" or
	 *                            "imiPreviousResults" actions to determine the
	 *                            starting position for data retrieval.
	 * @param imiRetrieveRowCount Number of rows to retrieve per page The system fetches this number + 1
	 *                            to determine if more pages exist.
	 * @param pageNumber          Current page number for pagination tracking
	 *                            (optional, default: 1). Used by frontend to track
	 *                            current page and enable/disable navigation
	 *                            buttons.
	 * @param imiuiSearchRequest  Search criteria and display preferences
	 *                            (required). Contains search parameters like date
	 *                            ranges, file IDs, status codes, and which columns
	 *                            should be displayed in the results.
	 * 
	 * @return ResponseEntity<Object> containing structured search results
	 *         with:
	 * 
	 * @throws Exception for any unexpected errors during processing
	 * 
	 * @see IMIUISearchRequest for search criteria structure
	 * @see IMIActivityTrackingService#imiRetrieve for business logic implementation
	 * 
	 * @since 1.0
	 * @author HighView Development Team
	 */
	@PostMapping("/retrieve-imiactivitytracking")
	public ResponseEntity<Object> imiRetrieve(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestHeader(value = "imiAction", required = true) final String imiAction,
			@RequestHeader(value = "resultPointer", required = false) final String resultPointer,
			@RequestHeader(value = "IMIRetrieveRowCount", required = false) final String imiRetrieveRowCount,
			@RequestBody IMIUISearchRequest imiuiSearchRequest) {
		try {
			loggerService.log("INFO", requestId, 0, 0, loginUser, IMIACTIVITYTRACKING, request.getRequestURI(), "",
					"START - Retrieve-IMIActivitytracking()");
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMIACTIVITYTRACKING, request.getRequestURI(),
						"401", AUTH_REQUIRED);
				return createErrorResponse(401, AUTH_REQUIRED);
			}
			logger.debug("Received IMI retrieve request for user: {}", loginUser);

			Object searchData = imiActivityTrackingService.imiRetrieve(loginUser, imiuiSearchRequest, authToken,
					imiAction, resultPointer, imiRetrieveRowCount);
			loggerService.log("INFO", requestId, 0, 0, loginUser, IMIACTIVITYTRACKING, request.getRequestURI(), "",
					"END - Retrieve-IMIActivitytracking()");
			return ResponseEntity.ok(searchData);
		} catch (Exception e) {
			logger.error("Error processing retrieve-imiactivitytracking request for user {}: {}", loginUser,
					e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, IMIACTIVITYTRACKING, request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(503, "Error processing retrieve-imiactivitytracking request: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to retrieve PHI (Protected Health Information) data for a specific
	 * IMI document.
	 * 
	 * This method processes an incoming request to retrieve PHI data for a specific
	 * IMI document. The user must have secure access permissions to view PHI data.
	 * Authentication is validated using the provided authorization token. If the
	 * token is invalid or missing, the service returns an authentication error.
	 * Each request is logged for traceability.
	 *
	 * @param authToken     The authorization token for validating the user
	 *                      (required).
	 * @param requestId     A unique identifier for tracking the request (required).
	 * @param imiDocumentId The IMI document ID to retrieve PHI data for (required).
	 * @return ResponseEntity<Object> containing the PHI data or an appropriate
	 *         error message.
	 */
	@GetMapping("/retrieve-segment-data/{id}")
	public ResponseEntity<Object> retrievePhiData(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@PathVariable(value = "id") final int imiDocumentId) {
		storeRequestId(requestId);
		try {
			loggerService.log("INFO", requestId, 0, 0, loginUser, "retrieve-segment-data()", request.getRequestURI(),
					"", "START - Retrieve-Segment-Data()");
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, RETRIEVESEGMENTDATA, request.getRequestURI(),
						"401", AUTH_REQUIRED);
				return createErrorResponse(401, AUTH_REQUIRED);
			}

			// Validate imiDocumentId
			if (imiDocumentId == 0) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, RETRIEVESEGMENTDATA, request.getRequestURI(),
						"400", "IMI Document ID is required for PHI data retrieval.");
				return createErrorResponse(400, "IMI Document ID is required for PHI data retrieval.");
			}
			logger.debug("Received PHI data retrieval request for user: {} and document: {}", loginUser, imiDocumentId);

			Map<String, Object> phiData = imiActivityTrackingService.retrieveSegmentData(loginUser, authToken,
					imiDocumentId);
			// Check response status and log accordingly
			String status = (String) phiData.get("status");
			if ("success".equals(status)) {
				loggerService.log("INFO", requestId, 0, 0, loginUser, RETRIEVESEGMENTDATA, request.getRequestURI(),
						"200", "PHI data retrieved successfully for document: " + imiDocumentId);
			} else if ("forbidden".equals(status)) {
				loggerService.log("WARN", requestId, 0, 0, loginUser, RETRIEVESEGMENTDATA, request.getRequestURI(),
						"403", "User does not have permission to access PHI data for document: " + imiDocumentId);
				return createErrorResponse(403, (String) phiData.get("error"));
			} else {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, RETRIEVESEGMENTDATA, request.getRequestURI(),
						"500", "Error retrieving PHI data for document: " + imiDocumentId);
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "retrieve-segment-data()", request.getRequestURI(),
					"", "END - Retrieve-Segment-Data()");
			return ResponseEntity.ok(phiData.get("phiData"));

		} catch (final Exception e) {
			logger.error("Error processing PHI data retrieval request for user {} and document {}: {}", loginUser,
					imiDocumentId, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, RETRIEVESEGMENTDATA, request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(503, "Error processing PHI data retrieval request: " + e.getMessage());
		}
	}

	/**
	 * Endpoint to retrieve IMI data for update operations. This endpoint searches
	 * for a specific IMI record by ID for update purposes.
	 * 
	 * @param authToken       The authorization token for user authentication
	 *                        (required). Must contain valid JWT with user
	 *                        information and LDAP groups.
	 * @param requestId       Unique identifier for request tracking and logging
	 *                        (required). Used for correlating logs across the
	 *                        application stack.
	 * @param retrieveRequest The IMI update retrieve request containing search
	 *                        parameters (required). Contains field type and ID
	 *                        value for searching.
	 * 
	 * @return ResponseEntity<Object> containing the search results with:
	 *         1. Search results list with IMI data
	 *         2. Field information for update operations
	 *         3. Error messages if search fails
	 * 
	 * @throws Exception for any unexpected errors during processing
	 * 
	 * @see IMIUpdateRetrieveRequest for request structure
	 * @see IMIUpdateService#imiUpdateRetrieve for business logic implementation
	 * 
	 * @since 1.0
	 * @author HighView Development Team
	 */
	@PostMapping("/imi-retrieveUpdate")
	public ResponseEntity<Object> imiUpdateRetrieve(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestBody IMIUpdateRetrieveRequest retrieveRequest) {
		storeRequestId(requestId);

		try {
			loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_UPDATE_RETRIEVE, request.getRequestURI(), "",
					"START - IMI-Update-Retrieve()");

			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_RETRIEVE, request.getRequestURI(),
						"401", AUTH_REQUIRED);
				return createErrorResponse(401, AUTH_REQUIRED);
			}

			if (!imiUpdateService.imionLoadUpdate(authToken)) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_RETRIEVE, request.getRequestURI(), "401",
						"User do not have access to the Update IMI groups. Request access to the IMI groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->IMI Groups->IMI-ACTIVITYTRK-UPDATE-INT");
				return createErrorResponse(401,
						"User do not have access to the Update IMI groups. Request access to the IMI groups in SARA under Business Applications->Highview Secured Images & OnDemand Applications->IMI Groups->IMI-ACTIVITYTRK-UPDATE-INT");
			}

			logger.debug("Received IMI update retrieve request for user: {} with field: {} and value: {}", loginUser,
					retrieveRequest.getField(), retrieveRequest.getFieldQuery());

			// Call the update service
			IMISearchData searchData = imiUpdateService.imiUpdateRetrieve(loginUser, authToken,
					retrieveRequest.getField(), retrieveRequest.getFieldQuery());

			// Log the response
			loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_UPDATE_RETRIEVE, request.getRequestURI(), "",
					"END - IMI-Update-Retrieve()");
			if (searchData != null && searchData.getServiceMessage() != null
					&& searchData.getServiceMessage().getReturnCode() == 0) {
				return ResponseEntity
						.ok(imiUpdateService.convertToTableFormat(searchData.getSearchResultsList(), retrieveRequest));
			} else {
				String errorMessage = searchData != null && searchData.getServiceMessage() != null
						? searchData.getServiceMessage().getReturnCodeDescription()
						: "IMI update retrieve failed";
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_RETRIEVE, request.getRequestURI(),
						"500", "IMI update retrieve failed: " + errorMessage);
			}

			return ResponseEntity.ok(searchData);

		} catch (final Exception e) {
			logger.error("Error processing IMI update retrieve request for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_RETRIEVE, request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(503, "Error processing IMI update retrieve request: " + e.getMessage());
		}

	}

	/**
	 * Endpoint to update IMI status codes for a specific record. This endpoint
	 * updates the status code of an IMI record based on the provided parameters.
	 * 
	 * @param authToken     The authorization token for user authentication
	 *                      (required). Must contain valid JWT with user information
	 *                      and LDAP groups.
	 * @param requestId     Unique identifier for request tracking and logging
	 *                      (required). Used for correlating logs across the
	 *                      application stack.
	 * @param updateRequest The IMI update request containing update parameters
	 *                      (required). Contains table flag, ID, and new status
	 *                      code.
	 * 
	 * @return ResponseEntity&lt;Object&gt; containing the update response with:
	 *         
	 *         1. Success message or error information
	 *         2. Update confirmation details
	 *         3. Status information
	 * 
	 * @throws Exception for any unexpected errors during processing
	 * 
	 * @see IMIUpdateRequest for request structure
	 * @see IMIUpdateService#imiUpdate for business logic implementation
	 * 
	 * @since 1.0
	 * @author HighView Development Team
	 */
	@PostMapping("/imi-updateRequest")
	public ResponseEntity<Object> imiUpdate(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestBody Map<String, Object> inputRequest) {

		storeRequestId(requestId);

		try {
			loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(), "",
					"START - IMI-Update()");

			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(),
						"401", AUTH_REQUIRED);
				return createErrorResponse(401, AUTH_REQUIRED);
			}

			// Validate update request
			if (inputRequest == null || inputRequest.size() == 0) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(),
						"400", "Update request is required.");
				return createErrorResponse(400, "Update request is required.");
			}

			// Call the update service
			IMIUpdateData updateData = imiUpdateService.imiUpdate(loginUser, authToken, inputRequest);

			// Log the response
			if (updateData != null && updateData.getResponseMessage() != null) {
				loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(), "200",
						"IMI update completed successfully. Message: " + updateData.getResponseMessage());
			} else {
				String errorMessage = updateData != null && updateData.getBaseMessage() != null
						? updateData.getBaseMessage().getReturnCodeDescription()
						: "Unknown error occurred";
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(),
						"500", "IMI update failed: " + errorMessage);
			}

			loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(), "",
					"END - IMI-Update()");

			return ResponseEntity.ok(updateData);

		} catch (final Exception e) {
			logger.error("Error processing IMI update request for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_UPDATE_REQUST, request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(503, "Error processing IMI update request: " + e.getMessage());
		}

	}

	/**
	 * Endpoint to construct CMOD search URL for a given document ID and parameters.
	 *
	 * This method processes a request to construct a CMOD search URL based on the
	 * provided document ID and additional parameters. Authentication is validated
	 * using the provided authorization token. The method returns a JSON response
	 * containing the constructed URL.
	 *
	 * @param authToken The authorization token for validating the user (required).
	 * @param requestId A unique identifier for tracking the request (required).
	 * @param parameters Map containing additional parameters for URL construction.
	 * @return ResponseEntity<Object> containing the constructed CMOD search URL or an
	 *         appropriate error message.
	 */
	@PostMapping(IMI_CMOD_SEARCH)
	public ResponseEntity<Object> imiCMODSearch(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId,
			@RequestBody Map<String, String> parameters) {
		
		storeRequestId(requestId);
		loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_CMOD_SEARCH, request.getRequestURI(), "",
				"START - imiCMODSearch()");
		
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			// Validate user ID
			if (loginUser == null || loginUser.isEmpty()) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_CMOD_SEARCH, request.getRequestURI(), "401",
						AUTH_REQUIRED);
				return createErrorResponse(401, AUTH_REQUIRED);
			}

			// Validate required parameters
			if (parameters == null || !parameters.containsKey("imiDocumentId")) {
				loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_CMOD_SEARCH, request.getRequestURI(), "400",
						"Missing required parameter: imiDocumentId");
				return createErrorResponse(400, "Missing required parameter: imiDocumentId");
			}
			// Construct CMOD search URL
			String constructedUrl = imiActivityTrackingService.constructCMODSearchUrl(Integer.parseInt(parameters.get("imiDocumentId")), parameters);

			// Create response
			Map<String, String> response = new java.util.HashMap<>();
			response.put("url", constructedUrl);

			loggerService.log("INFO", requestId, 0, 0, loginUser, IMI_CMOD_SEARCH, request.getRequestURI(), "200",
					"END - imiCMODSearch() - URL constructed successfully");

			return ResponseEntity.ok(response);

		} catch (final Exception e) {
			logger.error("Error processing CMOD search URL construction for user {}: {}", loginUser, e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, IMI_CMOD_SEARCH, request.getRequestURI(), "503",
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			return createErrorResponse(503, "Error processing CMOD search URL construction: " + e.getMessage());
		}
	}

	/**
	 * Helper method to create standardized error responses
	 */
	private ResponseEntity<Object> createErrorResponse(final int returnCode, final String description) {
		return HVWException.createErrorResponseEntity(returnCode, description);
	}

	/**
	 * Utility method to store requestId in ThreadContext for logging and downstream
	 * usage
	 */
	private void storeRequestId(Integer requestId) {
		if (requestId != null) {
			ThreadContext.put("requestId", String.valueOf(requestId));
		}
	}

	private List<PickListItems> transformNaicMapToPickListItems(Map<String, String> naicMap) {
		List<PickListItems> pickList = new ArrayList<>();
		long id = 0;
		for (Map.Entry<String, String> entry : naicMap.entrySet()) {
			PickListItems item = new PickListItems();
			item.setDisplayName(entry.getKey());
			item.setKey(entry.getValue());
			item.setId(id++);
			item.setParentKey("");
			pickList.add(item);
		}
		return pickList;
	}
}