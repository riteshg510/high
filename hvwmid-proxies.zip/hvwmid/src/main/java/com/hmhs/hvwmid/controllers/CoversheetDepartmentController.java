package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.entity.T117ImgCoverDept;
import com.hmhs.hvwmid.service.CoversheetDepartmentService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.constants.HVWConstants;
import jakarta.validation.Valid;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * CoversheetDepartmentController handles department management operations.
 * 
 * This controller provides REST endpoints for department management including:
 * - Department CRUD operations
 * - Department group filtering and access control
 * - User group management for coversheet access
 * 
 * All operations include comprehensive audit logging using LoggerService.
 * Uses ThreadContext for request tracking across the application.
 * 
 * @author Generated
 * @version 1.0
 * @since 2024
 */
@RestController
@RequestMapping("${controller.path.coversheet}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CoversheetDepartmentController {

    @Autowired
    private HttpServletRequest request;

    private static final Logger logger = LogManager.getLogger(CoversheetDepartmentController.class);
    public static String groupPrefix = "HVW-COVERSHEET";

    // Hold for local use
    private String loginUser = HVWConstants.UID;

    @Autowired
    LoggerService loggerService;

    final private CoversheetDepartmentService coversheetDepartmentService;

    public CoversheetDepartmentController(CoversheetDepartmentService coversheetDepartmentService) {
        this.coversheetDepartmentService = coversheetDepartmentService;
    }

    // Utility method to store requestId in ThreadContext for logging and downstream usage
    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }

    /**
     * Get all departments.
     * 
     * @param requestId The request ID for tracking
     * @return List of T117ImgCoverDept objects
     */
    @GetMapping("/departments")
    public List<T117ImgCoverDept> getAllDepartments(@RequestHeader(value = "RequestId", required = false) final Integer requestId,
                                                    @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getAllDepartments()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllDepartments() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getAllDepartments()");
        logger.info("Fetching all departments");
        List<T117ImgCoverDept> result = coversheetDepartmentService.getAllDepartments();
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllDepartments() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getAllDepartments()");
        logger.info("END - getAllDepartments()");
        return result;
    }

    /**
     * Get department by ID.
     * 
     * @param id The department ID
     * @param requestId The request ID for tracking
     * @return T117ImgCoverDept object
     */
    @GetMapping("/departments/{id}")
    public T117ImgCoverDept getDepartmentById(@PathVariable Integer id,
                                              @RequestHeader(value = "RequestId", required = false) final Integer requestId,
                                              @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getDepartmentById()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getDepartmentById() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getDepartmentById()");
        logger.info("Fetching department with ID: {}", id);
        T117ImgCoverDept result = coversheetDepartmentService.getDepartmentById(id);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getDepartmentById() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getDepartmentById()");
        logger.info("END - getDepartmentById()");
        return result;
    }

    /**
     * Create a new department.
     * 
     * @param department The department data to create
     * @param requestId The request ID for tracking
     * @return Created T117ImgCoverDept object
     */
    @PostMapping("/departments")
    public T117ImgCoverDept createDepartment(@Valid @RequestBody T117ImgCoverDept department,
                                             @RequestHeader(value = "RequestId", required = true) final Integer requestId,
                                             @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - createDepartment()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - createDepartment()");
        logger.info("Creating new department: {}", department.getDescription());
        T117ImgCoverDept result = coversheetDepartmentService.saveDepartment(department);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - createDepartment()");
        logger.info("END - createDepartment()");
        return result;
    }

    /**
     * Update an existing department.
     * 
     * @param department The department data to update
     * @param requestId The request ID for tracking
     * @return Updated T117ImgCoverDept object
     */
    @PutMapping("/departments")
    public T117ImgCoverDept updateDepartment(@Valid @RequestBody T117ImgCoverDept department,
                                             @RequestHeader(value = "RequestId", required = true) final Integer requestId,
                                             @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - updateDepartment()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - updateDepartment()");
        logger.info("Updating department: {}", department.getDescription());
        T117ImgCoverDept result = coversheetDepartmentService.saveDepartment(department);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - updateDepartment()");
        logger.info("END - updateDepartment()");
        return result;
    }

    /**
     * Delete a department.
     * 
     * @param id The department ID to delete
     * @param requestId The request ID for tracking
     * @return ResponseEntity with no content
     */
    @DeleteMapping("/departments/{id}")
    public ResponseEntity<Void> deleteDepartment(@PathVariable Integer id,
                                                 @RequestHeader(value = "RequestId", required = true) final Integer requestId,
                                                 @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - deleteDepartment()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - deleteDepartment()");
        logger.info("Deleting department with ID: {}", id);
        coversheetDepartmentService.deleteDepartment(id);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteDepartment() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - deleteDepartment()");
        logger.info("END - deleteDepartment()");
        return ResponseEntity.noContent().build();
    }

    /**
     * Get user groups filtered by department access and maintenance groups.
     * 
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return List of filtered group names
     */
    @GetMapping("/departments/groups")
    public List<String> getGroups(@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                  @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getGroups()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getGroups() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getGroups()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        // find only ones starting with groupPrefix
        List<String> filteredGroups = groups.stream()
                .filter(group -> group.startsWith(groupPrefix))
                .collect(Collectors.toList());
        logger.debug("User groups: {}", filteredGroups);
        List<String> mtgroups = coversheetDepartmentService.getAllMaintananceGroups();
        // return only those from filteredGroups that are not in the mtgroups
        List<String> result = filteredGroups.stream()
                .filter(group -> !mtgroups.contains(group))
                .collect(Collectors.toList());

        logger.debug("Filtered groups: {}", result);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getGroups() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getGroups()");
        logger.info("END - getGroups()");
        return result;
    }
}
