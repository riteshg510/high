package com.hmhs.hvwmid.controllers;

import java.util.List;
import java.util.Map;

import com.hmhs.hvwmid.service.WorkstationService;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate; 
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.service.GenericUDFService;
import com.hmhs.hvwmid.service.HvwDataRefresh;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * SessionController handles session management operations.
 * Provides endpoints for session creation and request ID generation.
 */
@RestController
@RequestMapping("${controller.path.common}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SessionController {

    private HttpServletRequest request;

    @Value("${db-logging-env}")
    private String dbLogginEnv;

    private static final Logger logger = LogManager.getLogger(SessionController.class);

    private JdbcTemplate jdbcTemplate;

    HvwDataRefresh hvwDataRefresh;

    @Autowired
    LoggerService loggerService;
    private final WorkstationService workstationService;

    public SessionController(HttpServletRequest request, WorkstationService workstationService, JdbcTemplate jdbcTemplate, HvwDataRefresh hvwDataRefresh, LoggerService loggerService) {
        this.workstationService = workstationService;
        this.request = request;
        this.jdbcTemplate = jdbcTemplate;
        this.hvwDataRefresh = hvwDataRefresh;
        this.loggerService = loggerService;
    }

    /**
	 * Creates a new session and returns a request ID.
	 * 
	 * @param authToken JWT authentication token from request header
	 * @return ResponseEntity containing a map with the generated request ID
	 */
	@PostMapping("/get-session")
	public ResponseEntity<Map<String, Integer>> getSession(@RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken) {
		Integer requestId = 0;
		String userId = "";
		logger.info("START - getSession()");
		loggerService.log("INFO", 0, 0, 0, userId, "getSession() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getSession()");
		try {
			userId = HVWUtils.getUserIdFromJWT(authToken);
			requestId = genReqIdAndCommitStatus();
		} catch (Exception e) {
			e.printStackTrace();
			loggerService.log("ERROR", 0, 0, 0, userId, "getSession()", request.getRequestURI(),
					String.valueOf(HttpStatus.UNAUTHORIZED.value()), (e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
		}

		loggerService.log("INFO", requestId, 0, 0, userId, "getSession() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "END - getSession()");
		logger.info("END - getSession()");
		return ResponseEntity.ok(Map.of("requestId", requestId));
	}

    /**
     * Generates a unique request ID and commits the status.
     * Uses a DB2 UDF to generate sequence numbers.
     * 
     * @return the generated request ID
     */
    public int genReqIdAndCommitStatus() {
        // Call DB2222056A_UDF for HVW sequence number
        String env = hvwDataRefresh.getParmDataByKeyByCmodbase("DEFAULT_ENV", dbLogginEnv);
        logger.log(Level.INFO, "Environment name retrieved from T222APARM is:" + env);
        // Pass the UDF name dynamically
        GenericUDFService udfService = new GenericUDFService(jdbcTemplate, "DB2222056A_UDF");
        return udfService.generateRequestId(env);
    }

    /**
     * Returns the IP address of the client (browser) that made the API call.
     * Logs user and auth info similar to getSession.
     */
    @RequestMapping("/clientip")
    public ResponseEntity<Map<String, Object>> getClientIpAddress(
            HttpServletRequest request,
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authToken,
            @RequestHeader(value = "RequestId", required = false) final Integer requestId) {

        String userId = "";
        try {
            userId = HVWUtils.getUserIdFromJWT(authToken);
        } catch (Exception e) {
            logger.warn("Failed to parse userId from JWT: {}", e.getMessage());
        }
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty()) {
            ip = request.getRemoteAddr();
        }
        logger.info("START - getClientIpAddress()");
        loggerService.log("INFO", requestId != null ? requestId : 0, 0, 0, userId, "getClientIpAddress() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getClientIpAddress()");

        logger.debug("Client-IP: {}", ip);
        loggerService.log("DEBUG", requestId != null ? requestId : 0, 0, 0, userId, "getClientIpAddress() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "Client-IP resolved: " + ip);

        Map<String, Object> info = workstationService.getWorkstationInformation(ip, authToken);
        logger.info("END - getClientIpAddress()");
        if(info.containsKey("workstationListing")) {
            Map<String, Object> workstationListing = (Map<String, Object>) info.get("workstationListing");
            if(workstationListing.containsKey("results")) {
                Map<String, Object> results = (Map<String, Object>) workstationListing.get("results");
                List<Map<String, Object>> rows = (List<Map<String, Object>>) results.get("rows");
                Map<String, Object> result = new java.util.HashMap<>();
                result.put("clientIp", ip);
                if(results.containsKey("rows") && results.get("rows") != null) {
                    result.put("workstation", rows.get(0).get("terminalID"));
                    result.put("region", rows.get(0).get("langID"));
                }
                logger.info("END - getWorkstationByClientIp()");
                return ResponseEntity.ok(result);
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Workstation not found for IP: " + ip) );
    }
}