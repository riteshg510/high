package com.hmhs.hvwmid.controllers;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.enums.ImageConfigListingReqMapping;
import com.hmhs.hvwmid.exceptions.HVWException;
import com.hmhs.hvwmid.model.ListingSearchRequest;
import com.hmhs.hvwmid.service.ImageConfigListingService;
import com.hmhs.hvwmid.service.ImageService;
import com.hmhs.hvwmid.service.ListApplIdsService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;

import jakarta.servlet.http.HttpServletRequest;

/**
 * ImagesController handles image-related operations.
 * Provides endpoints for image redirecting, listing, viewing, downloading, and
 * copying.
 */
@RestController
@RequestMapping("${controller.path.image}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ImagesController {

	@Autowired
	private HttpServletRequest request;

	private static final Logger logger = LogManager.getLogger(ImagesController.class);
	private final ImageService imageService;
	private final ListApplIdsService service;
	private final ImageConfigListingService imageConfigListingService;
	private String loginUser = HVWConstants.UID;

	@Autowired
	private LoggerService loggerService;

	@Value("${app.environment:default}")
	private String environment;

	@Value("${form.showImage.id}")
	private String showImageFormId;

	@Value("${form.viewImage.id}")
	private String viewImageFormId;

	@Value("${form.viewImage.navigatePathIMG}")
	private String viewImageNavigatePath;

	public ImagesController(ImageService imageService, ListApplIdsService service,
			ImageConfigListingService imageConfigListingService) {
		this.imageService = imageService;
		this.service = service;
		this.imageConfigListingService = imageConfigListingService;

	}

	// Utility method to store requestId in ThreadContext for logging and downstream
	// usage
	private void storeRequestId(Integer requestId) {
		if (requestId != null) {
			org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
		}
	}

	/**
	 * This endpoint retrieves a list of raw data in the form of a JSON string based
	 * on the provided form fields and an optional file. The list contains
	 * predefined data structures with placeholders for specific values, which are
	 * then converted into a JSON response. * Unified endpoint to retrieve image
	 * lists based on the 'action' property in otherFields.
	 * Supported actions: listobj, listobja, listobjb, listobjab, listobj2,
	 * listobj2a
	 * Example: { action: 'listobja', ...other params }
	 * 
	 * @param formFields The request parameters, typically used to extract form
	 *                   field values for further processing.
	 * @param file       An optional MultipartFile uploaded along with the request.
	 * @return A ResponseEntity containing the JSON string of the raw data, or an
	 *         error message if an exception occurs.
	 */
	@PostMapping({
			"/indexes/list-images",
			"/indexes/listobj",
			"/indexes/listobja",
			"/indexes/listobjb",
			"/indexes/listobjab",
			"/indexes/listobj2",
			"/indexes/listobj2a"
	})
	public ResponseEntity<Object> listImages(
			@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
		storeRequestId(requestId);
		logger.info("START - listImages() action={}", otherFields.get("action"));
		loggerService.log("INFO", requestId, 0, 0, loginUser, "listImages() ", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - listImages() action=" + otherFields.get("action"));
		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

			String action = otherFields.getOrDefault("action", "").toLowerCase();
			ResponseEntity<Object> response;
			switch (action) {
				case "listobj":
				case "listobja":
				case "listobjb":
				case "listobjab":
					response = imageService.getImagesListObja(otherFields, authToken);
					break;
				case "listobj2":
					response = imageService.getImagesListObj2(otherFields, authToken);
					break;
				case "listobj2a":
					response = imageService.getImagesListObj2(otherFields, authToken);
					break;
				default:
					logger.error("Invalid or missing action property: {}", action);
					return ResponseEntity.badRequest().body(
							"Invalid or missing action property. Supported: listobj, listobja, listobjb, listobjab, listobj2, listobj2a");
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "listImages() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - listImages() action=" + action);
			logger.info("END - listImages() action={}", action);
			return response;
		} catch (final HVWException e) {
			logger.error("Error in image data result processing: {}", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "listImages()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage() != null && e.getMessage().length() > 250) ? e.getMessage().substring(0, 250)
							: e.getMessage());
			logger.info("END - listImages()");
			return HVWException.createErrorResponseEntity(e);
		} catch (IOException e) {
			logger.info("END - listImages()");
			throw new RuntimeException(e);
		}
	}

	@PostMapping("/indexes/view")
	public ResponseEntity<ByteArrayResource> downloadImage(
			@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) throws HVWException {
		storeRequestId(requestId);
		logger.info("START - view()");
		try {
			loggerService.log("INFO", requestId, 0, 0, loginUser, "view() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "START - view()");
			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

			ResponseEntity<ByteArrayResource> response = imageService.download(otherFields, authToken);

			loggerService.log("INFO", requestId, 0, 0, loginUser, "view() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - view()");

			logger.info("END - view()");
			return response;
		} catch (final HVWException e) {
			logger.error("HVWException while downloading image", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "view()", request.getRequestURI(),
					String.valueOf(HttpStatus.BAD_REQUEST.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - view()");
			return ResponseEntity.badRequest()
					.body(new ByteArrayResource(e.getMessage().getBytes()));
		} catch (final Exception e) {
			logger.error("Unexpected error while downloading image", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "view()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - view()");
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
					.body(new ByteArrayResource("SERVICE_UNAVAILABLE".getBytes()));
		}
	}

	@PostMapping("/copy")
	public ResponseEntity<Object> copy2folder(@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = "RequestId", required = true) final int requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		try {
			logger.info("START - copy()");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "copy() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "START - copy()");

			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

			ResponseEntity<Object> response = imageService.copy2folder(otherFields, authToken);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "copy() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - copy()");

			logger.info("END - copy()");
			return response;

		} catch (final HVWException e) {
			logger.error("HVWException while downloading image", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "copy()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - copy()");
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("");
		} catch (final Exception e) {
			logger.error("Unexpected error while downloading image", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "copy()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - copy()");
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("");
		}
	}

	@PostMapping("/delete-restore")
	public ResponseEntity<Object> deleteRestore(@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = "RequestId", required = true) final int requestId,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken) {
		try {
			logger.info("START - deleteRestore()");
			loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteRestore() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "START - deleteRestore()");

			loginUser = HVWUtils.getUserIdFromJWT(authToken);
			otherFields.entrySet().removeIf(entry -> "undefined".equals(entry.getValue()));

			ResponseEntity<Object> response = imageService.deleteRestore(otherFields, authToken);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteRestore() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - deleteRestore()");

			logger.info("END - deleteRestore()");
			return response;

		} catch (final HVWException e) {
			logger.error("HVWException while downloading image", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteRestore()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - deleteRestore()");
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("");
		} catch (final Exception e) {
			logger.error("Unexpected error while downloading image", e.getMessage(), e);
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "deleteRestore()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage().length() > 250) ? e.getMessage().substring(0, 250) : e.getMessage());
			logger.info("END - deleteRestore()");
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("");
		}
	}

	/**
	 * This method returns the corresponding `Sort.Direction` for the given string
	 * direction. It checks if the input direction is "desc" or not and returns the
	 * appropriate sorting order:
	 * 1. "desc" returns `Sort.Direction.DESC`
	 * 2. Any other value (typically "asc") returns `Sort.Direction.ASC`
	 * 
	 * @param direction The string indicating the desired sort direction ("asc" or
	 *                  "desc").
	 * @return The corresponding `Sort.Direction` (either `Sort.Direction.ASC` or
	 *         `Sort.Direction.DESC`).
	 */
	/*
	 * private Sort.Direction getSortDirection(final String direction) {
	 * // Check if the direction is "desc", return descending order
	 * if (direction.equals("desc"))
	 * return Sort.Direction.DESC;
	 * else
	 * // Default is ascending order
	 * return Sort.Direction.ASC;
	 * }
	 */

	@PostMapping("/img-config-listing")
	public ResponseEntity<Object> imgConfigListing(
			@RequestParam final Map<String, String> otherFields,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {

		storeRequestId(requestId);
		logger.info("START - imgConfigListing()");

		try {
			loginUser = HVWUtils.getUserIdFromJWT(authToken);

			loggerService.log("INFO", requestId, 0, 0, loginUser, "imgConfigListing()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "START - imgConfigListing()");

			otherFields.entrySet().removeIf(e -> "undefined".equals(e.getValue()));

			ListingSearchRequest req = buildListingSearchRequest(otherFields, authToken, requestId);

			final Map<String, Object> responseData = imageConfigListingService.search(req);

			loggerService.log("INFO", requestId, 0, 0, loginUser, "imgConfigListing()", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - imgConfigListing()");
			logger.info("END - imgConfigListing()");
			return ResponseEntity.ok(responseData);

		} catch (final HVWException e) {
			logger.error("HVWException in imgConfigListing", e);
			loggerService.log("ERROR", requestId, 0, 0, HVWConstants.UID, "imgConfigListing()", request.getRequestURI(),
					String.valueOf(HttpStatus.BAD_REQUEST.value()),
					(e.getMessage() != null && e.getMessage().length() > 250)
							? e.getMessage().substring(0, 250)
							: e.getMessage());
			logger.info("END - imgConfigListing()");
			return ResponseEntity.badRequest()
					.body((e.getMessage() != null) ? e.getMessage() : "BAD_REQUEST");
		} catch (final Exception e) {
			logger.error("Unexpected error in imgConfigListing", e);
			loggerService.log("ERROR", requestId, 0, 0, HVWConstants.UID, "imgConfigListing()", request.getRequestURI(),
					String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()),
					(e.getMessage() != null && e.getMessage().length() > 250)
							? e.getMessage().substring(0, 250)
							: String.valueOf(e.getMessage()));
			logger.info("END - imgConfigListing()");
			return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
					.body("SERVICE_UNAVAILABLE");
		}
	}

	private ListingSearchRequest buildListingSearchRequest(Map<String, String> otherFields, String authToken,
			Integer requestId) {
		ListingSearchRequest req = new ListingSearchRequest();

		// Schemas
		String mainSchema = HVWUtils.getCollection(environment); // "DB2INST1";
		String batchSchema = otherFields.get("batchtblschema");
		req.setMainSchema(mainSchema);
		req.setBatchtblschema(batchSchema);

		// Limit
		String limitStr = otherFields.get("limit");
		if (limitStr != null && !limitStr.isBlank()) {
			try {
				req.setLimit(Integer.parseInt(limitStr.trim()));
			} catch (NumberFormatException ignored) {
			}
		}

		// ApplIds
		ResponseEntity<Object> response = service.filter(otherFields, authToken);
		List<Integer> applids = extractApplIds(response);
		req.setUserApplids(applids);

		// Dynamic mapping based on legacy enum
		BeanWrapper bw = new BeanWrapperImpl(req);

		for (ImageConfigListingReqMapping m : ImageConfigListingReqMapping.values()) {
			// Query
			String qVal = getIgnoreCase(otherFields, m.getQueryField().toLowerCase(), "");
			if (qVal != null && !qVal.isBlank()) {
				Class<?> type = bw.getPropertyType(m.getQueryField());
				Object converted = qVal;
				if (type != null && Long.class.isAssignableFrom(type)) {
					try {
						converted = Long.valueOf(qVal.trim());
					} catch (NumberFormatException ignore) {
					}
				}
				bw.setPropertyValue(m.getQueryField(), converted);
			}
			// Display
			String dVal = getIgnoreCase(otherFields, m.getDisplayField().toLowerCase(), "");
			if (dVal != null && !dVal.isBlank()) {
				bw.setPropertyValue(m.getDisplayField(), isAffirmative(dVal));
			}
			// Operator (EXACT/LIKE)
			String opVal = getIgnoreCase(otherFields, m.getSearchStringField().toLowerCase(), "");
			if (opVal != null && !opVal.isBlank() && !"na".equalsIgnoreCase(m.getSearchStringField())) {
				bw.setPropertyValue(m.getSearchStringField(), opVal.trim());
			}
		}
		req.normalize();
		return req;
	}

	private static List<Integer> extractApplIds(ResponseEntity<?> response) {
		Object body = response.getBody();
		if (!(body instanceof List<?> listBody))
			return Collections.emptyList();

		return listBody.stream()
				.filter(Map.class::isInstance)
				.map(m -> ((Map<?, ?>) m).get("key"))
				.filter(Objects::nonNull)
				.map(val -> {
					if (val instanceof Number n)
						return n.intValue();
					try {
						return Integer.parseInt(val.toString());
					} catch (NumberFormatException e) {
						return null;
					}
				})
				.filter(Objects::nonNull)
				.collect(Collectors.toUnmodifiableList());
	}

	private static boolean isAffirmative(String v) {
		String s = v.trim().toLowerCase(Locale.ROOT);
		return s.equals("y") || s.equals("yes") || s.equals("true") || s.equals("1") || s.equals("on");
	}

	public static String getIgnoreCase(Map<String, String> map, String key, String defaultValue) {
		if (key == null || map == null) {
			return defaultValue;
		}
		if (map.containsKey(key)) {
			return map.get(key);
		}

		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(key)) {
				return entry.getValue();
			}
		}

		return defaultValue;
	}

}
