package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.model.*;
import com.hmhs.hvwmid.entity.*;
import com.hmhs.hvwmid.service.CoversheetObjectServiceImpl;
import com.hmhs.hvwmid.service.CoversheetService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import com.hmhs.hvwmid.constants.HVWConstants;
import jakarta.validation.Valid;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * CoversheetController handles coversheet management operations.
 * 
 * This controller provides REST endpoints for coversheet and coversheet override management including:
 * - Coversheet CRUD operations by application ID and name
 * - Coversheet override management with application ID, name, and sequence
 * - Comprehensive logging and error handling for all operations
 * 
 * All operations include comprehensive audit logging using LoggerService.
 * Uses ThreadContext for request tracking across the application.
 * 
 * @author Generated
 * @version 1.0
 * @since 2024
 */
@RestController
@RequestMapping("${controller.path.coversheet}")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CoversheetController {

    @Autowired
    private HttpServletRequest request;

    private static final Logger logger = LogManager.getLogger(CoversheetController.class);

    // Hold for local use
    private String loginUser = HVWConstants.UID;

    @Autowired
    LoggerService loggerService;

    final private CoversheetService coversheetService;
    final private CoversheetObjectServiceImpl coversheetObjectService;

    public CoversheetController(CoversheetService coversheetService, CoversheetObjectServiceImpl coversheetObjectService) {
        this.coversheetService = coversheetService;
        this.coversheetObjectService = coversheetObjectService;
    }

    // Utility method to store requestId in ThreadContext for logging and downstream usage
    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }

    // --- COVER SHEET ---
    /**
     * Get coversheets by application ID.
     * 
     * @param applicationId The application ID to filter coversheets
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return List of CoverSheetDTO objects
     */
    @GetMapping("/coversheets/{applicationId}")
    public List<CoverSheetDTO> getCoversheetByApplicationId(@PathVariable Integer applicationId,
                                                            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getCoversheetByApplicationId()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getCoversheetByApplicationId() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getCoversheetByApplicationId()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        List<CoverSheetDTO> result = coversheetService.getCoversheetByApplicationId(applicationId);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getCoversheetByApplicationId() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getCoversheetByApplicationId()");
        logger.info("END - getCoversheetByApplicationId()");
        return result;
    }


    /**
     * Get coversheet by application ID and coversheet name.
     * 
     * @param applicationId The application ID
     * @param coversheetName The coversheet name
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return CoverSheetDTO object
     */
    @GetMapping("/coversheets/{applicationId}/{coversheetName}")
    public CoverSheetDTO getCoversheetByApplicationIdAndName(@PathVariable Integer applicationId,
                                                            @PathVariable String coversheetName,
                                                            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getCoversheetByApplicationIdAndName()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getCoversheetByApplicationIdAndName() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getCoversheetByApplicationIdAndName()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        CoverSheetDTO result = coversheetService.getCoversheetByApplicationIdAndName(applicationId,coversheetName);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getCoversheetByApplicationIdAndName() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getCoversheetByApplicationIdAndName()");
        logger.info("END - getCoversheetByApplicationIdAndName()");
        return result;
    }


    /**
     * Get all coversheets with optional filtering by active status.
     * 
     * @param activeOnly Whether to return only active coversheets
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return List of CoverSheetDTO objects
     */
    @GetMapping("/coversheets")
    public List<CoverSheetDTO> getAllCoversheets(@RequestParam(defaultValue = "false") boolean activeOnly,
                                                 @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                 @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - getAllCoversheets()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCoversheets() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getAllCoversheets()");
        List<String> groups = HVWUtils.getUserGroups(authToken);
        List<CoverSheetDTO> result = coversheetService.getAllCoverSheets(activeOnly);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllCoversheets() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getAllCoversheets()");
        logger.info("END - getAllCoversheets()");
        return result;
    }


    /**
     * Create a new coversheet.
     * 
     * @param template The coversheet template data
     * @param requestId The request ID for tracking
     * @return Created CoverSheetDTO object
     */
    @PostMapping("/coversheets")
    public CoverSheetDTO createCoversheet(@Valid @RequestBody CoverSheetDTO template,
                                          @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                          @RequestHeader(value = "RequestId", required = false) final Integer requestId) {
        storeRequestId(requestId);
        String loginUser = HVWUtils.getUserIdFromJWT(authToken);
        logger.info("START - createCoversheet()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createCoversheet() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - createCoversheet()");
        CoverSheetDTO result = coversheetService.saveCoverSheet(template);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createCoversheet() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - createCoversheet()");
        logger.info("END - createCoversheet()");
        return result;
    }


    /**
     * Update an existing coversheet.
     * 
     * @param template The coversheet template data to update
     * @param requestId The request ID for tracking
     * @return Updated CoverSheetDTO object
     */
    @PutMapping("/coversheets")
    public CoverSheetDTO updateCoversheet(@Valid @RequestBody CoverSheetDTO template,
                                          @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                          @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - updateCoversheet()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateCoversheet() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - updateCoversheet()");
        CoverSheetDTO result = coversheetService.updateCoverSheet(template);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateCoversheet() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - updateCoversheet()");
        logger.info("END - updateCoversheet()");
        return result;
    }


    /**
     * Soft delete a coversheet by setting it as inactive.
     * 
     * @param id The coversheet ID to delete
     * @param requestId The request ID for tracking
     * @return ResponseEntity with no content
     */
    @DeleteMapping("/coversheets")
    public ResponseEntity<Void> deleteCoversheet(@Valid @RequestBody T117ImgCoverSheetId id,
                                                 @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - deleteCoversheet()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteCoversheet() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - deleteCoversheet()");
        coversheetService.deleteCoverSheet(id);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteCoversheet() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - deleteCoversheet()");
        logger.info("END - deleteCoversheet()");
        return ResponseEntity.noContent().build();
    }


    /**
     * Get all coversheet overrides by application ID.
     * 
     * @param applicationId The application ID to filter overrides
     * @param requestId The request ID for tracking
     * @return List of CoverSheetOverrideDTO objects
     */
    @GetMapping("/overrides/{applicationId}")
    public List<CoverSheetOverrideDTO> getAllOverridesByApplicationId(@PathVariable Integer applicationId,
                                                                     @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getAllOverridesByApplicationId()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllOverridesByApplicationId() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getAllOverridesByApplicationId()");
        List<CoverSheetOverrideDTO> result = coversheetService.getAllOverridesByApplicationId(applicationId);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getAllOverridesByApplicationId() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getAllOverridesByApplicationId()");
        logger.info("END - getAllOverridesByApplicationId()");
        return result;
    }


    /**
     * Get coversheet overrides by application ID and coversheet name.
     * 
     * @param applicationId The application ID
     * @param coversheetName The coversheet name
     * @param requestId The request ID for tracking
     * @return List of CoverSheetOverrideDTO objects
     */
    @GetMapping("/overrides/{applicationId}/{coversheetName}")
    public List<CoverSheetOverrideDTO> getOverridesListByApplicationIdAndName(@PathVariable Integer applicationId, 
                                                                             @PathVariable String coversheetName,
                                                                             @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getOverridesListByApplicationIdAndName()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getOverridesListByApplicationIdAndName() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getOverridesListByApplicationIdAndName()");
        List<CoverSheetOverrideDTO> result = coversheetService.getCoversheetOverrideListByApplicationIdAndName(applicationId,coversheetName);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getOverridesListByApplicationIdAndName() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getOverridesListByApplicationIdAndName()");
        logger.info("END - getOverridesListByApplicationIdAndName()");
        return result;
    }


    /**
     * Get coversheet override by application ID, coversheet name, and sequence.
     * 
     * @param applicationId The application ID
     * @param coversheetName The coversheet name
     * @param sequence The sequence number
     * @param requestId The request ID for tracking
     * @return CoverSheetOverrideDTO object
     */
    @GetMapping("/overrides/{applicationId}/{coversheetName}/{sequence}")
    public CoverSheetOverrideDTO getOverridesByApplicationIdAndName(@PathVariable Integer applicationId, 
                                                                   @PathVariable String coversheetName, 
                                                                   @PathVariable Integer sequence,
                                                                   @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getOverridesByApplicationIdAndName()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getOverridesByApplicationIdAndName() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getOverridesByApplicationIdAndName()");
        CoverSheetOverrideDTO result = coversheetService.getCoversheetOverrideByApplicationIdAndName(applicationId,coversheetName,sequence);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getOverridesByApplicationIdAndName() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - getOverridesByApplicationIdAndName()");
        logger.info("END - getOverridesByApplicationIdAndName()");
        return result;
    }


    /**
     * Create a new coversheet override.
     * 
     * @param override The override data to create
     * @param requestId The request ID for tracking
     * @return Created CoverSheetOverrideDTO object
     */
    @PostMapping("/overrides")
    public CoverSheetOverrideDTO createOverride(@Valid @RequestBody CoverSheetOverrideDTO override,
                                                @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - createOverride()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createOverride() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - createOverride()");
        CoverSheetOverrideDTO result = coversheetService.createNewOveride(override);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "createOverride() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - createOverride()");
        logger.info("END - createOverride()");
        return result;
    }


    /**
     * Update an existing coversheet override.
     * 
     * @param override The override data to update
     * @param requestId The request ID for tracking
     * @return Updated CoverSheetOverrideDTO object
     */
    @PutMapping("/overrides")
    public CoverSheetOverrideDTO updateOverride(@Valid @RequestBody CoverSheetOverrideDTO override,
                                                @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - updateOverride()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateOverride() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - updateOverride()");
        CoverSheetOverrideDTO result = coversheetService.updateOverride(override);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "updateOverride() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - updateOverride()");
        logger.info("END - updateOverride()");
        return result;
    }


    /**
     * Soft delete a coversheet override by setting it as inactive.
     * 
     * @param id The override ID to delete
     * @param requestId The request ID for tracking
     * @return ResponseEntity with no content
     */
    @DeleteMapping("/overrides")
    public ResponseEntity<Void> deleteOverride(@Valid @RequestBody T117ImgCoverSheetOverrideId id,
                                               @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - deleteOverride()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteOverride() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - deleteOverride()");
        coversheetService.deleteOverride(id);
        loggerService.log("INFO", requestId, 0, 0, loginUser, "deleteOverride() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "END - deleteOverride()");
        logger.info("END - deleteOverride()");
        return ResponseEntity.noContent().build();
    }

}
