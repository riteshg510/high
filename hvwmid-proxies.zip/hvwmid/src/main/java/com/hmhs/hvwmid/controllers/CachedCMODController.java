package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.service.CMODDownloadService;
import com.hmhs.hvwmid.service.CodCachingService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.springframework.http.ContentDisposition;

/**
 * CachedCMODController handles cached CMOD document operations.
 * 
 * This controller provides REST endpoints for cached CMOD document management including:
 * - Document streaming and download operations with authorization checking
 * - Upload preparation with token generation
 * - Document token management and retrieval
 * - CMOD API integration for document processing
 * 
 * All operations include comprehensive audit logging using LoggerService.
 * Uses ThreadContext for request tracking across the application.
 * 
 * @author Generated
 * @version 1.0
 * @since 2024
 */
@RestController
@RequestMapping("${controller.path.reports}")
public class CachedCMODController {

	@Autowired
	private HttpServletRequest request;

	private static final Logger logger = LogManager.getLogger(CachedCMODController.class);

	// Hold for local use
	private String loginUser = HVWConstants.UID;

	@Autowired
	LoggerService loggerService;

	private final CodCachingService codCachingService;
	private final CMODDownloadService cmodDownloadService;
	@Value("${api.upload.url}")
	private String cmodUploadUrl;

	@Value("${app.backend.server}")
	private String backendServer;


	public CachedCMODController(CodCachingService codCachingService, CMODDownloadService cmodDownloadService
			) {
		this.codCachingService = codCachingService;
		this.cmodDownloadService = cmodDownloadService;
	}

	/**
	 * Get document stream by REQUEST_ID with authorization checking.
	 * 
	 * @param requestId The request ID of the document to stream
	 * @param authToken The authorization token for user authentication
	 * @return ResponseEntity containing the document stream or error status
	 */
	@GetMapping(value = "/tokens/view/{requestId}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<StreamingResponseBody> getDocumentStream(
			@PathVariable(name = "requestId") Integer requestId,
			@RequestParam(value = "filename", required = false) String filename,
			@RequestParam(value = "authToken", required = false) String authTokenParam,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authTokenHeader) {
		storeRequestId(requestId);
		logger.info("START - getDocumentStream()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - document stream request");
		logger.info("Received download request for document with requestId: {}", requestId);
		try {
			HttpHeaders headers = new HttpHeaders();
			// Prefer authToken param if present, else header
			String authToken = (authTokenParam != null && !authTokenParam.isEmpty()) ? authTokenParam : authTokenHeader;
			TblCodToken tblCodToken = codCachingService.getDocumentToken(requestId, authToken);
			String loginUser = HVWUtils.getUserIdFromJWT(authToken);

			if (!tblCodToken.getUserId().strip().equalsIgnoreCase(loginUser) && !loginUser.equals(HVWConstants.UID)) {
				logger.error("User {} is not authorized to access the document with requestId: {}", loginUser,
						requestId);
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
						String.valueOf(HttpStatus.UNAUTHORIZED.value()), "User not authorized to access document");
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
			}

			if (tblCodToken != null) {
				// Use Optional, Map, Set for concise logic
				String docType = Optional.ofNullable(tblCodToken.getDocumentType()).orElse("").toLowerCase().trim();
				headers.add("file-extension", docType);

				Map<String, MediaType> mimeTypes = Map.ofEntries(
					Map.entry("pdf", MediaType.APPLICATION_PDF),
					Map.entry("afp", MediaType.valueOf("application/afp")),
					Map.entry("tif", MediaType.valueOf("image/tiff")),
					Map.entry("tiff", MediaType.valueOf("image/tiff")),
					Map.entry("jpg", MediaType.IMAGE_JPEG),
					Map.entry("jpeg", MediaType.IMAGE_JPEG),
					Map.entry("bmp", MediaType.valueOf("image/bmp")),
					Map.entry("gif", MediaType.IMAGE_GIF),
					Map.entry("png", MediaType.IMAGE_PNG),
					Map.entry("txt", MediaType.TEXT_PLAIN)
				);
				MediaType mediaType = mimeTypes.getOrDefault(docType, MediaType.APPLICATION_OCTET_STREAM);
				headers.setContentType(mediaType);

				Set<String> inlineTypes = Set.of("pdf", "jpg", "jpeg", "bmp", "gif", "png", "tif", "tiff", "txt");
				String dispositionType = inlineTypes.contains(docType) ? "inline" : "attachment";

				String baseName = (filename != null && !filename.isEmpty()) ? filename : tblCodToken.getDocumentToken();
				java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("MM-dd-yyyy.HH.mm.ss");
				java.time.ZoneId estZone = java.time.ZoneId.of("America/New_York");
				String timestamp = java.time.LocalDateTime.now(estZone).format(formatter);
				String fileNameWithTimestamp = baseName + "_" + timestamp + "." + docType;
				headers.setContentDisposition(ContentDisposition.builder(dispositionType)
						.name(dispositionType)
						.filename(fileNameWithTimestamp)
						.build());
			}

			StreamingResponseBody responseBody = codCachingService.streamDocument(requestId);
			if (responseBody == null) {
				logger.error("Document not found for requestId: {}", requestId);
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
						String.valueOf(HttpStatus.NOT_FOUND.value()), "END - getDocumentStream()");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
			}
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentStream() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getDocumentStream()");
			logger.info("END - getDocumentStream()");
			return new ResponseEntity<>(responseBody, headers, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception occurred", e);
			logger.error("Error while downloading document {}: {}", requestId, e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
					String.valueOf(HttpStatus.NOT_FOUND.value()), "END - getDocumentStream()");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}

	/**
	 * Prepares for upload by generating a CMOD token for the authenticated user.
	 * 
	 * @param authToken The authorization token for user authentication
	 * @param requestId The request ID for tracking
	 * @return ResponseEntity containing the generated token and upload information
	 */
	@GetMapping(value = "/prepare-upload")
	public ResponseEntity<Object> getCodTokenBeforeUpload(
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);
		logger.info("START - getCodTokenBeforeUpload()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getCodTokenBeforeUpload()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getCodTokenBeforeUpload()");
		logger.info("Received store-binary-token request");
		try {
			String loginUser = HVWUtils.getUserIdFromJWT(authToken);
			TblCodToken cacheRequestId = codCachingService.saveToken(loginUser, authToken, "");
			// Build response inline as a map
			Map<String, Object> response = new java.util.HashMap<>();
			response.put("cacheRequestId", cacheRequestId);
			response.put("uploadUrl", cmodUploadUrl);
			response.put("backendServer", backendServer);

			loggerService.log("INFO", requestId, 0, 0, loginUser, "getCodTokenBeforeUpload() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getCodTokenBeforeUpload()");
			logger.info("END - getCodTokenBeforeUpload()");
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while storing token {}", e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getCodTokenBeforeUpload()", request.getRequestURI(),
					String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), "END - getCodTokenBeforeUpload()");
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}

	/**
	 * Retrieves the document request ID for a given document token and folder. if
	 * the document token is not found in the cache, it will call the CMOD API to
	 * get the request ID.
	 *
	 * @param documentToken
	 * @param odFolder
	 * @param authToken
	 * @return TblCodToken
	 */
	@PostMapping(value = "/tokens/view")
	public ResponseEntity<TblCodToken> getDocumentRequestID(@RequestParam("documentToken") final String documentToken,
			@RequestParam("odFolder") final String odFolder,
			@RequestParam(value = "translateType", required = false) final String translateType,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
			@RequestHeader(value = "RequestId", required = true) final Integer requestId) {
		storeRequestId(requestId);
		logger.info("START - getDocumentRequestID()");
		loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentRequestID()", request.getRequestURI(),
				String.valueOf(HttpStatus.OK.value()), "START - getDocumentRequestID()");
		logger.info("Received view request for document with documentToken: {} and odFolder: {}", documentToken, odFolder);

		try {
			String loginUser = HVWUtils.getUserIdFromJWT(authToken);
			if (loginUser == null || loginUser.isEmpty()) {
				logger.error("User not found in JWT token");
				loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentRequestID()", request.getRequestURI(),
						String.valueOf(HttpStatus.UNAUTHORIZED.value()), "User not found in JWT token");
				logger.info("END - getDocumentRequestID()");
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
			}
			String trimmedloginUser = loginUser.length() > 10 ? loginUser.substring(0, 10) : loginUser;

		TblCodToken tblCodToken = codCachingService.getTokenByStatusAndType(trimmedloginUser, documentToken, translateType,authToken);
		if (tblCodToken != null) {
			logger.debug("Token found in DB for userId={}, documentToken={}, translateType={}", trimmedloginUser, documentToken, translateType);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentRequestID() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getDocumentRequestID()");
			logger.info("END - getDocumentRequestID()");
			return ResponseEntity.ok(tblCodToken);
		}
		logger.debug("Token NOT found in DB for userId={}, documentToken={}, translateType={}; calling service.", trimmedloginUser, documentToken, translateType);
		// If not found, call the service (SecurityException block)
		throw new SecurityException("No matching token found");
		} catch (SecurityException e) {
			Map<String, Integer> requestIdMap = cmodDownloadService.getDocumentRequestId(documentToken, odFolder, authToken, translateType);
			TblCodToken tblCodToken = codCachingService.getDocumentToken(requestIdMap.get("REQUEST_ID"), authToken);
			loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentRequestID() ", request.getRequestURI(),
					String.valueOf(HttpStatus.OK.value()), "END - getDocumentRequestID()");
			logger.info("END - getDocumentRequestID()");
			return ResponseEntity.ok(tblCodToken);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while viewing document {}: {}", documentToken, e.getMessage());
			loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentRequestID()", request.getRequestURI(),
					String.valueOf(HttpStatus.NOT_FOUND.value()), "END - getDocumentRequestID()");
			logger.info("END - getDocumentRequestID()");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
	}

	// Utility method to store requestId in ThreadContext for logging and downstream usage
	private void storeRequestId(Integer requestId) {
		if (requestId != null) {
			org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
		}
	}

}
