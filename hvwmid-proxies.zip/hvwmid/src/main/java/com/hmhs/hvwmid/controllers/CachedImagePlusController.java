package com.hmhs.hvwmid.controllers;

import com.hmhs.hvwmid.constants.HVWConstants;
import com.hmhs.hvwmid.entity.TblCodToken;
import com.hmhs.hvwmid.entity.TblImgToken;
import com.hmhs.hvwmid.service.ImageCachingService;
import com.hmhs.hvwmid.service.LoggerService;
import com.hmhs.hvwmid.utils.HVWUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Controller for handling cached image download and upload operations.
 * <p>
 * Endpoints:
 * <ul>
 * <li>Download a document stream by requestId</li>
 * <li>Prepare upload and generate a token</li>
 * </ul>
 * <p>
 * Uses Log4j2 ThreadContext to propagate requestId for logging and downstream
 * services.
 * Authorization header is read using HVWConstants.AUTH_HEADER.
 */
@RestController
@RequestMapping("${controller.path.image}")
public class CachedImagePlusController {
    @Autowired
    private HttpServletRequest request;

    /** Logger for this controller. */
    private static final Logger logger = LogManager.getLogger(CachedImagePlusController.class);

    // Hold for local use
    private String loginUser = HVWConstants.UID;

    @Autowired
    LoggerService loggerService;

    /** Service for image caching and streaming. */
    private ImageCachingService imageCachingService;

    @Value("${api.images.upload.url}")
    private String imgUploadUrl;

    @Value("${app.backend.server}")
    private String backendServer;

    /**
     * Constructor for dependency injection.
     * 
     * @param imageCachingService the image caching service
     */
    public CachedImagePlusController(ImageCachingService imageCachingService) {
        this.imageCachingService = imageCachingService;
    }

    /**
     * Stores the requestId in Log4j2 ThreadContext for logging and downstream
     * usage.
     * 
     * @param requestId the request id to store
     */
    private void storeRequestId(Integer requestId) {
        if (requestId != null) {
            org.apache.logging.log4j.ThreadContext.put("requestId", String.valueOf(requestId));
        }
    }

    /**
     * Downloads a document stream by requestId.
     *
     * @param requestId the request id of the document
     * @param authToken the authorization token
     * @return the document as a streaming response, or error status
     */
    @GetMapping(value = "/tokens/view/{requestId}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<StreamingResponseBody> getDocumentStream(@PathVariable(name = "requestId") Integer requestId,
            @RequestParam(value = "filename", required = false) String filename,
            @RequestParam(value = "authToken", required = false) String authTokenParam,
			@RequestHeader(value = HVWConstants.AUTH_HEADER, required = false) final String authTokenHeader){
        storeRequestId(requestId);
        logger.info("START - getDocumentStream()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentStream() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getDocumentStream()");
        logger.info("Received download request for document with requestId: {}", requestId);
        try {
            HttpHeaders headers = new HttpHeaders();
            // Prefer authToken param if present, else header
			String authToken = (authTokenParam != null && !authTokenParam.isEmpty()) ? authTokenParam : authTokenHeader;
			
            TblImgToken tblImgToken = imageCachingService.getDocumentToken(requestId);
            String user = tblImgToken.getUserId().strip();
            String loginUser = HVWUtils.getUserIdFromJWT(authToken);

            if (!user.equalsIgnoreCase(loginUser) && !loginUser.equals(HVWConstants.UID)) {
                logger.error("User {} is not authorized to access the document with requestId: {}", loginUser,
                        requestId);
                loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
                        String.valueOf(HttpStatus.UNAUTHORIZED.value()), "END - getDocumentStream()");
                logger.info("END - getDocumentStream()");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
            }

           		if (tblImgToken != null) {
				// Use Optional, Map, Set for concise logic
				String docType = Optional.ofNullable(tblImgToken.getDocumentType()).orElse("").toLowerCase().trim();
				headers.add("file-extension", docType);

				Map<String, MediaType> mimeTypes = Map.ofEntries(
					Map.entry("pdf", MediaType.APPLICATION_PDF),
					Map.entry("afp", MediaType.valueOf("application/afp")),
					Map.entry("tif", MediaType.valueOf("image/tiff")),
					Map.entry("tiff", MediaType.valueOf("image/tiff")),
					Map.entry("jpg", MediaType.IMAGE_JPEG),
					Map.entry("jpeg", MediaType.IMAGE_JPEG),
					Map.entry("bmp", MediaType.valueOf("image/bmp")),
					Map.entry("gif", MediaType.IMAGE_GIF),
					Map.entry("png", MediaType.IMAGE_PNG),
					Map.entry("txt", MediaType.TEXT_PLAIN)
				);
				MediaType mediaType = mimeTypes.getOrDefault(docType, MediaType.APPLICATION_OCTET_STREAM);
				headers.setContentType(mediaType);

				Set<String> inlineTypes = Set.of("pdf", "jpg", "jpeg", "bmp", "gif", "png", "tif", "tiff", "txt");
				String dispositionType = inlineTypes.contains(docType) ? "inline" : "attachment";

				String baseName = (filename != null && !filename.isEmpty()) ? filename : tblImgToken.getDocumentToken();
				java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("MM-dd-yyyy.HH.mm.ss");
				java.time.ZoneId estZone = java.time.ZoneId.of("America/New_York");
				String timestamp = java.time.LocalDateTime.now(estZone).format(formatter);
				String fileNameWithTimestamp = baseName + "_" + timestamp + "." + docType;
				headers.setContentDisposition(ContentDisposition.builder(dispositionType)
						.name(dispositionType)
						.filename(fileNameWithTimestamp)
						.build());
			}

            StreamingResponseBody responseBody = imageCachingService.streamDocument(requestId);
            if (responseBody == null) {
                logger.error("Document not found for requestId: {}", requestId);
                loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
                        String.valueOf(HttpStatus.NOT_FOUND.value()), "END - getDocumentStream()");
                logger.info("END - getDocumentStream()");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
            

            loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentStream() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - getDocumentStream()");
            logger.info("END - getDocumentStream()");
            return ResponseEntity.ok().headers(headers).body(responseBody);

        } catch (Exception e) {
            logger.error("Error occurred while processing the request: {}", e.getMessage(), e);
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentStream()", request.getRequestURI(),
                    String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), "END - getDocumentStream()");
            logger.info("END - getDocumentStream()");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }


    /**
     * Retrieves the document request ID for a given document token and folder. if
     * the document token is not found in the cache, it will call the CMOD API to
     * get the request ID.
     *
     * @param documentToken
     * @param authToken
     * @return TblCodToken
     */
    @PostMapping(value = "/tokens/view")
    public ResponseEntity<TblImgToken> getDocumentRequestID(@RequestParam("documentToken") final String documentToken,
                                                            @RequestParam(value = "translateType", required = false) final String translateType,
                                                            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
                                                            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getDocumentRequestID()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentRequestID()", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getDocumentRequestID()");
        logger.info("Received view request for document with documentToken: {}", documentToken);

        try {
            String loginUser = HVWUtils.getUserIdFromJWT(authToken);
            if (loginUser == null || loginUser.isEmpty()) {
                logger.error("User not found in JWT token");
                loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentRequestID()", request.getRequestURI(),
                        String.valueOf(HttpStatus.UNAUTHORIZED.value()), "User not found in JWT token");
                logger.info("END - getDocumentRequestID()");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
            }
            String trimmedloginUser = loginUser.length() > 10 ? loginUser.substring(0, 10) : loginUser;

            TblImgToken tblCodToken = imageCachingService.getTokenByStatusAndType(trimmedloginUser, documentToken, translateType, authToken);
            if (tblCodToken != null) {
                logger.debug("Token found in DB for userId={}, documentToken={}, translateType={}", trimmedloginUser, documentToken, translateType);
                loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentRequestID() ", request.getRequestURI(),
                        String.valueOf(HttpStatus.OK.value()), "END - getDocumentRequestID()");
                logger.info("END - getDocumentRequestID()");
                return ResponseEntity.ok(tblCodToken);
            }
            logger.debug("Token NOT found in DB for userId={}, documentToken={}, translateType={}; calling service.", trimmedloginUser, documentToken, translateType);
            // If not found, call the service (SecurityException block)
            throw new SecurityException("No matching token found");
        } catch (SecurityException e) {
			String effectiveTranslateType = "TOPDF".equalsIgnoreCase(translateType) ? "ANY2PDF" : translateType;
            Map<String, Integer> requestIdMap = imageCachingService.getDocumentRequestId(documentToken, authToken, effectiveTranslateType);
            TblImgToken tblCodToken = imageCachingService.getDocumentToken(requestIdMap.get("REQUEST_ID"), authToken);
            loggerService.log("INFO", requestId, 0, 0, loginUser, "getDocumentRequestID() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - getDocumentRequestID()");
            logger.info("END - getDocumentRequestID()");
            return ResponseEntity.ok(tblCodToken);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Error while viewing document {}: {}", documentToken, e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getDocumentRequestID()", request.getRequestURI(),
                    String.valueOf(HttpStatus.NOT_FOUND.value()), "END - getDocumentRequestID()");
            logger.info("END - getDocumentRequestID()");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }




    /**
     * Prepares for upload and generates a token for the user.
     *
     * @param authToken the authorization token (from HVWConstants.AUTH_HEADER)
     * @param requestId the request id (optional)
     * @return the generated TblImgToken or error status
     */
    /**
     * Prepares for upload by generating a token for the authenticated user.
     * 
     * @param authToken The authorization token for user authentication
     * @param requestId The request ID for tracking
     * @return ResponseEntity containing the generated token and upload information
     */
    @GetMapping(value = "/prepare-upload")
    public ResponseEntity<Object> getCodTokenBeforeUpload(
            @RequestHeader(value = HVWConstants.AUTH_HEADER, required = true) final String authToken,
            @RequestHeader(value = "RequestId", required = true) final Integer requestId) {
        storeRequestId(requestId);
        logger.info("START - getCodTokenBeforeUpload()");
        loggerService.log("INFO", requestId, 0, 0, loginUser, "getCodTokenBeforeUpload() ", request.getRequestURI(),
                String.valueOf(HttpStatus.OK.value()), "START - getCodTokenBeforeUpload()");
        logger.info("Received /prepare-upload request");
        try {
            String loginUser = HVWUtils.getUserIdFromJWT(authToken);
            TblImgToken cacheRequestId = imageCachingService.saveToken(loginUser, authToken, "");
            // Build response inline as a map
            java.util.Map<String, Object> response = new java.util.HashMap<>();
            response.put("cacheRequestId", cacheRequestId);
            response.put("uploadUrl", imgUploadUrl);
            response.put("backendServer", backendServer);

            loggerService.log("INFO", requestId, 0, 0, loginUser, "getCodTokenBeforeUpload() ", request.getRequestURI(),
                    String.valueOf(HttpStatus.OK.value()), "END - getCodTokenBeforeUpload()");
            logger.info("END - getCodTokenBeforeUpload()");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            logger.error("Error while storing token {}", e.getMessage());
            loggerService.log("ERROR", requestId, 0, 0, loginUser, "getCodTokenBeforeUpload()", request.getRequestURI(),
                    String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), "END - getCodTokenBeforeUpload()");
            logger.info("END - getCodTokenBeforeUpload()");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

}
