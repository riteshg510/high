package com.hmhs.hvwmid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@EnableAutoConfiguration
@SpringBootApplication
@ImportResource({"classpath*:applicationContext.xml"})
@ComponentScan
@Controller
@EnableJpaRepositories(basePackages = "com.hmhs.hvwmid.repository")
@EnableWebMvc
public class Application {

	static {
		// use this for log4j2 threadid
		System.setProperty("isThreadContextMapInheritable", "true");
	}

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@GetMapping("cabinets/**")
	public String redirectCabinets() {
		return "forward:/";
	}

	@GetMapping("pages/single-cabinet/**")
	public String redirectPagesSingleCabinet() {
		return "forward:/";
	}
	
	@GetMapping("pages/cabinets-scan/**")
	public String redirectPagesCabinetsScan() {
		return "forward:/";
	}
	
	@GetMapping("pages/workflow/**")
	public String redirectPagesWorkflow() {
		return "forward:/";
	}

	@GetMapping("reports/**")
	public String redirectReports() {
		return "forward:/";
	}

	@GetMapping("single-report/**")
	public String redirectSingleReport() {
		return "forward:/";
	}

	@GetMapping("pages/single-report/**")
	public String redirectPagesSingleReport() {
		return "forward:/";
	}

	@GetMapping("request/**")
	public String redirectRequest() {
		return "forward:/";
	}

	@GetMapping("pages/search/**")
	public String redirectPagesSearch() {
		return "forward:/";
	}

	@GetMapping("search/**")
	public String redirectSearch() {
		return "forward:/";
	}

	@GetMapping("pages/**")
	public String redirectPages() {
		return "forward:/";
	}

}
